##################################################基础数据##################################################
select
	a.org_area_code,
	a.org_area_name,
	a.org_office_code,
	a.org_office_name,
	a.org_principal_code,
	a.org_principal_name,
	a.counter_id,
	a.counter_name,
	a.ba_code,
	a.ba_name,
	ifnull(sum(a.trans_type*ABS(a.real_amt)),0) net_amt,
	ifnull(count(a.order_no),0 ) net_order,
	ifnull(sum(a.trans_type*ABS(a.goods_qty)),0 ) net_goods_qty,
	ifnull(sum(a.trans_type*ABS(a.sk_qty)),0 ) net_sk_qty,
	ifnull(count(distinct m.member_id),0) net_mem_pur,
	ifnull(sum(case when m.member_id is null then 0 else a.trans_type*ABS(a.real_amt) end),0) net_mem_amt,
	ifnull(count(a.order_no),0 ) net_mem_order,
	ifnull(count(distinct case
	when a.org_area_code = c.org_area_id and a.org_office_code = c.org_office_id and a.org_principal_code = c.org_master_id and a.counter_id = c.counter_id and a.ba_code = m.ba_id
	and m.card_issuing_time between '2020-04-21' and DATE_ADD(date('2020-04-21'), INTERVAL 1 DAY )
	then m.member_id end),0) net_mj,
	ifnull(count(distinct case when m.card_issuing_time between '2020-04-01' and DATE_ADD( date('2020-04-21'),INTERVAL 1 DAY ) then m.member_id end),0) net_new_pur,
	ifnull(sum(case when m.card_issuing_time between '2020-04-21' and DATE_ADD( date('2020-04-21'),INTERVAL 1 DAY ) then a.trans_type*ABS(a.real_amt) else 0 end),0) net_new_amt,
	ifnull(count(case when m.card_issuing_time between '2020-04-21' and DATE_ADD( date('2020-04-21'),INTERVAL 1 DAY ) then a.order_no end),0 ) net_new_order,

	ifnull(count(distinct case when m.card_issuing_time < '2020-04-21' then m.member_id end),0) net_vet_pur,
	ifnull(sum(case when m.card_issuing_time < '2020-04-21' then a.trans_type*ABS(a.real_amt) else 0 end),0) net_vet_amt,
	ifnull(count(case when m.card_issuing_time < '2020-04-21' then a.order_no end),0 ) net_vet_order,
	ifnull(count(distinct case when m.member_id is null then a.order_no end),0 ) net_non_mem_order
from t_pos_order a left join t_member_info m on a.member_id = m.member_id
left join t_counter_info c on m.counter_id = c.counter_id
where a.biz_time > '2020-04-21' and a.biz_time < DATE_ADD( date('2020-04-21'),INTERVAL 1 DAY )
and a.counter_id ='Z3001010'
group by
a.org_area_code,
a.org_area_name,
a.org_office_code,
a.org_office_name,
a.org_principal_code,
a.org_principal_name,
a.counter_id,
a.counter_name,
a.ba_code,
a.ba_name;

##################################################销售天数统计#############################################
select
	t.org_area_code,
	t.org_area_name,
	t.org_office_code,
	t.org_office_name,
	t.org_principal_code,
	t.org_principal_name,
	t.counter_id,
	t.counter_name,
	t.ba_code,
	t.ba_name,
	count(t.time)
from (
	select
		a.org_area_code,
		a.org_area_name,
		a.org_office_code,
		a.org_office_name,
		a.org_principal_code,
		a.org_principal_name,
		a.counter_id,
		a.counter_name,
		a.ba_code,
		a.ba_name,
		date(a.biz_time) time,
		ifnull(sum(a.trans_type*ABS(a.real_amt)),0) net_amt
	from t_pos_order a
	where a.biz_time > '2020-04-01' and a.biz_time < DATE_ADD( date('2020-04-21'),INTERVAL 1 DAY )
	and a.counter_id ='Z3001010'
	group by
		a.org_area_code,
		a.org_area_name,
		a.org_office_code,
		a.org_office_name,
		a.org_principal_code,
		a.org_principal_name,
		a.counter_id,
		a.counter_name,
		a.ba_code,
		a.ba_name,
		time
	having
		net_amt != 0
) t
group by
	t.org_area_code,
	t.org_area_name,
	t.org_office_code,
	t.org_office_name,
	t.org_principal_code,
	t.org_principal_name,
	t.counter_id,
	t.counter_name,
	t.ba_code,
	t.ba_name;
##################################################经营新会员##################################################