package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 退库明细Excel导出
 * @author fly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WhReturnItemExcelEvent extends BiReportEvent {

    private String key;

    @Builder
    public WhReturnItemExcelEvent(String key) {
        this.key = key;
    }
}
