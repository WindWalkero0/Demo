package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 支付方式报表excel导出
 *
 * @author ly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class PaymentExcelEvent extends BiReportEvent {

    private String key;
    private String yes;

    @Builder
    public PaymentExcelEvent(String key, String yes) {
        this.key = key;
        this.yes = yes;
    }
}
