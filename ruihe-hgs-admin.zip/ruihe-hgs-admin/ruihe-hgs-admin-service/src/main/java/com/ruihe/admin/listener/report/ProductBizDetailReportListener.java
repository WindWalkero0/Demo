package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.admin.listener.report.core.ReportController;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.ReportProductBizDetailEvent;
import com.ruihe.admin.listener.report.core.HeadProvider;
import com.ruihe.admin.mapper.bi.PrdDetailReportMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.response.bi.PrdDetailERPResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.List;

/***
 * 产品业务明细报表
 * @author lrc
 */
@Component
@RequiredArgsConstructor
public class ProductBizDetailReportListener extends AbstractReportListener<ReportProductBizDetailEvent> {

    private final PrdDetailReportMapper prdDetailReportMapper;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_REPORT)
    @EventListener
    public void onApplicationEvent(ReportProductBizDetailEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    public void doExport(ReportProductBizDetailEvent event, BiReportPo report, boolean flag) {
        TableDefine define = ProductBizDetailDefine.create(event.getRequest());
        HeadProvider headProvider = new ProductBizDetailHeadProvider(prdDetailReportMapper, define, event);

        ReportController controller = new ReportController(define, headProvider);
        controller.name("产品业务明显报表");
        controller.savePath(report.getFilePath());
        List<PrdDetailERPResponse> data = prdDetailReportMapper.prdBizDetailReport(
                null,
                event.getRequest(),
                define.selectCols(),
                define.groupCols(),
                event.getReport().getUid(),
                flag);
        controller.fillData(data);
        controller.totalCalculate();
        controller.write(this.imgPath, report.getPicUrl());
    }
}
