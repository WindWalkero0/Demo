package com.ruihe.admin.event;


import com.ruihe.common.annotation.Ella;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Ella(Describe = "校验u8漏单信息")
@Data
@EqualsAndHashCode(callSuper = false)
public class CheckU8Event {

}
