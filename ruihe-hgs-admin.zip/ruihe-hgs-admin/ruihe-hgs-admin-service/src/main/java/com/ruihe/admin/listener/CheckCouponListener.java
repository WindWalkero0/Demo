package com.ruihe.admin.listener;


import com.ruihe.common.annotation.Ella;
import com.ruihe.common.service.AsynchronousService;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.CheckCouponEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;


@Ella(Describe = "有无超发优惠券监控", Author = "K")
@Slf4j
@Component
public class CheckCouponListener {

    @Autowired
    private AsynchronousService asynchronousService;


    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(CheckCouponEvent event) {
        try {
//            asynchronousService.checkCoupon();
        } catch (Exception e) {
            log.error("查询有误超发优惠券异常", e);
        }
    }

}
