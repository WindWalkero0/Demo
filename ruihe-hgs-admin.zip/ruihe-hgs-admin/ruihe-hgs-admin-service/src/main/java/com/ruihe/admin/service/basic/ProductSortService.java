package com.ruihe.admin.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.mapper.basic.ProductCategoryMapper;
import com.ruihe.admin.request.ProductSortItemRequest;
import com.ruihe.admin.request.ProductSortRequest;
import com.ruihe.admin.request.SelectSortRequest;
import com.ruihe.common.dao.bean.base.ProductCategory;
import com.ruihe.common.dao.bean.base.ProductSortItemPo;
import com.ruihe.common.dao.bean.base.ProductSortMetaPo;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.admin.mapper.basic.ProductSortItemMapper;
import com.ruihe.admin.mapper.basic.ProductSortMetaMapper;
import com.ruihe.admin.vo.ProductSortItemVo;
import com.ruihe.admin.vo.ProductSortMetaVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author 梁远
 * @Description
 * @create 2019-06-18 9:51
 */
@Service
@Slf4j
public class ProductSortService {
    @Autowired
    private ProductSortMetaMapper productSortMetaMapper;
    @Autowired
    private ProductSortItemMapper productSortItemMapper;
    @Autowired
    private ProductCategoryMapper productCategoryMapper;

    /**
     * 查询所有的产品分类
     *
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response showSort() {
        List<ProductSortMetaPo> metaPoList = productSortMetaMapper.selectList(null);
        return Response.success(ObjectUtils.toList(metaPoList, ProductSortMetaVo.class));
    }

    /**
     * 根据分类的id，点击配置之后，产品分类配置展示
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response showSortItem(ProductSortItemRequest request) {
        //查询条件，按照时间倒序排序
        LambdaQueryWrapper<ProductSortItemPo> queryWrapper = Wrappers.<ProductSortItemPo>lambdaQuery()
                .eq(ProductSortItemPo::getMetaCode, request.getCode())
                .orderByDesc(ProductSortItemPo::getCreateTime);
        //分页查询
        Page<ProductSortItemPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        IPage<ProductSortItemPo> itemPoIPage = productSortItemMapper.selectPage(page, queryWrapper);
        //获取查询数据
        List<ProductSortItemPo> itemPoList = itemPoIPage.getRecords();
        //设置查询结果
        PageVO info = PageVO.<ProductSortItemVo>builder().list(ObjectUtils.toList(itemPoList, ProductSortItemVo.class))
                .total(itemPoIPage.getTotal())
                .pageNum(itemPoIPage.getCurrent())
                .pageSize(itemPoIPage.getSize())
                .pages(itemPoIPage.getPages()).build();
        return Response.success(info);
    }

    /**
     * 产品分类配置仅展示无效的
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response showInvalid(ProductSortItemRequest request) {
        //查询条件
        LambdaQueryWrapper<ProductSortItemPo> queryWrapper = Wrappers.<ProductSortItemPo>lambdaQuery()
                .eq(ProductSortItemPo::getMetaCode, request.getCode())
                .eq(ProductSortItemPo::getStatus, CommonStatusEnum.INVALID.getCode());
        //分页查询
        Page<ProductSortItemPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        IPage<ProductSortItemPo> itemPoIPage = productSortItemMapper.selectPage(page, queryWrapper);
        //获取查询数据
        List<ProductSortItemPo> itemPoList = itemPoIPage.getRecords();
        //设置查询结果
        PageVO info = PageVO.<ProductSortItemVo>builder().list(ObjectUtils.toList(itemPoList, ProductSortItemVo.class))
                .total(itemPoIPage.getTotal())
                .pageNum(itemPoIPage.getCurrent())
                .pageSize(itemPoIPage.getSize())
                .pages(itemPoIPage.getPages()).build();
        return Response.success(info);
    }

    /**
     * 添加产品分类配置
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addProductSortItem(ProductSortRequest request) throws BizException {
        //判断分类名称重复
        LambdaQueryWrapper<ProductSortItemPo> queryName = Wrappers.<ProductSortItemPo>lambdaQuery()
                .eq(ProductSortItemPo::getSortName, request.getSortName())
                .eq(ProductSortItemPo::getMetaCode, request.getMetaCode());
        Integer count = productSortItemMapper.selectCount(queryName);
        if (count > 0) {
            return Response.errorMsg("分类名称重复，请确认后重试!");
        }
        //判断属性代码重复
        LambdaQueryWrapper<ProductSortItemPo> queryCode = Wrappers.<ProductSortItemPo>lambdaQuery()
                .eq(ProductSortItemPo::getMetaCode, request.getMetaCode())
                .eq(ProductSortItemPo::getSortCode, request.getSortCode());
        ProductSortItemPo sortItem = productSortItemMapper.selectOne(queryCode);
        if (sortItem != null) {
            return Response.errorMsg("属性代码重复，请确认后重试!");
        }
        //保存分类信息
        ProductSortItemPo itemPo = new ProductSortItemPo();
        BeanUtils.copyProperties(request, itemPo);
        itemPo.setStatus(CommonStatusEnum.EFFECTIVE.getCode());
        itemPo.setCreateTime(LocalDateTime.now());
        itemPo.setUpdateTime(LocalDateTime.now());
        Integer rows = productSortItemMapper.insert(itemPo);
        if (rows == 0) {
            log.error("添加产品分类配置保存失败!request={}", request);
            return Response.errorMsg("添加产品分类配置保存失败!");
        }
        return Response.successMsg("保存成功!");
    }

    /**
     * 产品分类配置更新
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response editProductSortItem(ProductSortRequest request) throws BizException {
        //判断分类名称重复
        LambdaQueryWrapper<ProductSortItemPo> queryName = Wrappers.<ProductSortItemPo>lambdaQuery()
                .eq(ProductSortItemPo::getSortName, request.getSortName())
                .eq(ProductSortItemPo::getMetaCode, request.getMetaCode());
        ProductSortItemPo sortItemPo = productSortItemMapper.selectOne(queryName);
        if (sortItemPo != null && !request.getSortId().equals(sortItemPo.getSortId())) {
            return Response.errorMsg("分类名称重复，请确认后重试!");
        }
        //判断属性代码重复
        LambdaQueryWrapper<ProductSortItemPo> queryCode = Wrappers.<ProductSortItemPo>lambdaQuery()
                .eq(ProductSortItemPo::getMetaCode, request.getMetaCode())
                .eq(ProductSortItemPo::getSortCode, request.getSortCode());
        ProductSortItemPo sortItem = productSortItemMapper.selectOne(queryCode);
        if (sortItem != null && !request.getSortId().equals(sortItem.getSortId())) {
            return Response.errorMsg("属性代码重复，请确认后重试!");
        }
        //更新分类信息
        LambdaUpdateWrapper<ProductSortItemPo> updateWrapper = Wrappers.<ProductSortItemPo>lambdaUpdate()
                .eq(ProductSortItemPo::getSortId, request.getSortId());
        ProductSortItemPo itemPo = new ProductSortItemPo();
        BeanUtils.copyProperties(request, itemPo);
        itemPo.setUpdateTime(LocalDateTime.now());
        Integer update = productSortItemMapper.update(itemPo, updateWrapper);
        if (update == 0) {
            log.error("产品分类配置更新失败!request={}", request);
            return Response.errorMsg("产品分类配置更新失败!");
        }
        return Response.successMsg("更新成功!");
    }

    /**
     * 停用启用
     *
     * @param code
     * @param status
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response updateSortItemStatus(Integer code, Integer status) throws BizException {
        LambdaUpdateWrapper<ProductSortItemPo> updateWrapper = Wrappers.<ProductSortItemPo>lambdaUpdate()
                .eq(ProductSortItemPo::getSortId, code);
        ProductSortItemPo itemPo = new ProductSortItemPo();
        itemPo.setUpdateTime(LocalDateTime.now());
        itemPo.setStatus(status);
        Integer update = productSortItemMapper.update(itemPo, updateWrapper);
        if (update == 0) {
            log.error("产品分类维护处理，更新失败!code={},status={}", code, status);
            return Response.errorMsg("产品分类维护处理，更新失败");
        }
        return Response.successMsg("修改状态成功");
    }

    /**
     * 产品维护中选择分类
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectSort(SelectSortRequest request) {
        //查询条件
        LambdaQueryWrapper<ProductSortItemPo> queryWrapper = Wrappers.<ProductSortItemPo>lambdaQuery()
                .eq(ProductSortItemPo::getMetaCode, request.getType())
                .eq(ProductSortItemPo::getStatus, CommonStatusEnum.EFFECTIVE.getCode());
        //获取上级列表
        List<Integer> sortList = request.getSortList();
        //如果上级不为空
        if (!org.springframework.util.ObjectUtils.isEmpty(sortList)) {
            //如果传入的是绑定的，则进行关联查询
            if (request.getIsPrdBinded() != null && request.getIsPrdBinded().equals(CommonStatusEnum.EFFECTIVE.getCode())) {
                queryWrapper.in(ProductSortItemPo::getParentSortId, request.getSortList())
                        .eq(ProductSortItemPo::getIsPrdBinded, request.getIsPrdBinded());
            } else if (request.getIsPrdBinded() != null && request.getIsPrdBinded().equals(CommonStatusEnum.INVALID.getCode())) {
                //如果不是绑定的，则查询未绑定指定sortId的或者未绑定的数据
                queryWrapper.and(p -> p.notIn(ProductSortItemPo::getParentSortId, request.getSortList())
                        .or().eq(ProductSortItemPo::getIsPrdBinded, request.getIsPrdBinded()));
            }
        } else if (request.getIsPrdBinded() != null) {
            queryWrapper.eq(ProductSortItemPo::getIsPrdBinded, request.getIsPrdBinded());
        }
        if (StringUtils.isNotBlank(request.getSortName())) {
            queryWrapper.and(p -> p.like(ProductSortItemPo::getSortName, request.getSortName())
                    .or().like(ProductSortItemPo::getSortCode, request.getSortName()));
        }
        //分页查询
        Page<ProductSortItemPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        IPage<ProductSortItemPo> itemPoIPage = productSortItemMapper.selectPage(page, queryWrapper);
        //获取查询数据
        List<ProductSortItemPo> itemPoList = itemPoIPage.getRecords();
        //设置查询结果
        PageVO info = PageVO.<ProductSortItemVo>builder().list(ObjectUtils.toList(itemPoList, ProductSortItemVo.class))
                .total(itemPoIPage.getTotal())
                .pageNum(itemPoIPage.getCurrent())
                .pageSize(itemPoIPage.getSize())
                .pages(itemPoIPage.getPages()).build();
        return Response.success(info);
    }

    /**
     * 产品页面显示分类树形结构
     *
     * @param type
     * @param sortId
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response sortTreeOld(Integer type, Integer sortId) {
        //查询条件:类型、绑定、有效、上级ID
        LambdaQueryWrapper<ProductSortItemPo> queryWrapper = Wrappers.<ProductSortItemPo>lambdaQuery()
                .eq(ProductSortItemPo::getMetaCode, type)
                .eq(ProductSortItemPo::getIsPrdBinded, CommonStatusEnum.EFFECTIVE.getCode())
                .eq(ProductSortItemPo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                .eq(ProductSortItemPo::getParentSortId, sortId);
        //查询
        List<ProductSortItemPo> itemPoList = productSortItemMapper.selectList(queryWrapper);
        return Response.success(ObjectUtils.toList(itemPoList, ProductSortItemVo.class));
    }

    @DS(DBConst.SLAVE)
    public Response sortTree(Integer level, Integer parentId) {
        var queryWrapper = Wrappers.lambdaUpdate(ProductCategory.class)
                .eq(ProductCategory::getLevel, level)
                .eq(ProductCategory::getParentId, parentId)
                .eq(ProductCategory::getDeleted, 0);
        List<ProductCategory> list = productCategoryMapper.selectList(queryWrapper);
        var itemPoList = list.stream().map(e -> ProductSortItemVo.builder()
                .isPrdBinded(1)
                .status(1)
                .metaCode(e.getLevel())
                .metaName(e.getName())
                .sortId(e.getId())
                .sortCode("")
                .sortName(e.getName())
                .parentSortId(e.getParentId())
                .parentSortName(e.getParentId() == 0 ? "" : productCategoryMapper.selectById(e.getParentId()).getName())
                .build())
                .collect(Collectors.toList());
        return Response.success(itemPoList);
    }

}
