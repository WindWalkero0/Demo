package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author luojie
 * @program ruihe-top
 * @description 帐号管理查询请求实体类
 * @create: 2021/7/7 13:06
 */
@ApiModel(value = "帐号管理查询参数请求体", description = "帐号管理查询参数请求体")
@Data
public class AccountManagementRequest {
    
    @ApiModelProperty("帐号名称")
    private String accountName;
    
    @ApiModelProperty("是否有效(0 无效 | 1 有效)")
    private Integer status;
    
    @ApiModelProperty("角色菜单权限uid")
    private String menuUid;
    
    @ApiModelProperty("角色功能权限uid")
    private String jurUid;
    
    @ApiModelProperty("帐号")
    private String account;
    
    @ApiModelProperty(value = "页", required = true)
    private Integer pageNumber;
    
    @ApiModelProperty(value = "页数量", required = true)
    private Integer pageSize;
}
