package com.ruihe.admin.listener;


import com.ruihe.common.annotation.Ella;
import com.ruihe.common.service.AdminTaskService;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.CheckIntegralEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;


/**
 * @author Administrator
 */
@Ella(Describe = "检查用户积分", Author = "fly")
@Slf4j
@Component
public class CheckIntegralListener {

    @Autowired
    private AdminTaskService adminTaskService;

    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(CheckIntegralEvent event) {
        try {
            adminTaskService.checkIntegral();
        } catch (Exception e) {
            log.error("检查订单柜台组织机构.error,event={}", event, e);
        }
    }

}
