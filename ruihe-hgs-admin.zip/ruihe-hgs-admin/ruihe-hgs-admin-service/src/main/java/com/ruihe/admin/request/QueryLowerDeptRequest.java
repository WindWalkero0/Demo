package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-25 10:30
 */
@ApiModel(value = "QueryLowerDeptRequest", description = "erp中查询下级部门请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QueryLowerDeptRequest implements Serializable {

    @ApiModelProperty("上级部门代码，选择大区的时候deptId默认传入HZYJ")
    private String deptId;

    @ApiModelProperty(value = "type传参:2大区 3办事处 4柜台主管 5柜台")
    private Integer type;

    @ApiModelProperty("部门状态:0无效，1有效")
    private Integer deptStatus;

    @ApiModelProperty("部门类型：0测试，1正式")
    private Integer deptType;
}
