package com.ruihe.admin.enums;

public enum OperationalModelEnum {
    /**
     * 自营
     **/
    SELFEMPLOYED("10005", "自营"),
    /**
     * 代理商
     **/
    AGENT("10006", "代理商");


    private String code;
    private String msg;


    OperationalModelEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
