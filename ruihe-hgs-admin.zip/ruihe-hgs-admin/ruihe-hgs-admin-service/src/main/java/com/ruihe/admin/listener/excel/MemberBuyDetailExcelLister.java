package com.ruihe.admin.listener.excel;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.enums.order.TransTypeEnum;
import com.ruihe.common.pojo.response.order.MemberOrderItemDetailResponse;
import com.ruihe.common.pojo.response.order.MemberOrderItemResponse;
import com.ruihe.admin.event.MemberBuyDetailEvent;
import com.ruihe.admin.listener.style.ColumnWidthStyleStrategy;
import com.ruihe.admin.mapper.order.PosOrderItemMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.utils.ExcelImgUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static com.alibaba.excel.EasyExcel.write;
import static com.alibaba.excel.EasyExcel.writerSheet;
import static java.util.stream.Collectors.toList;


@Slf4j
@Component
public class MemberBuyDetailExcelLister extends AbstractReportListener<MemberBuyDetailEvent> {


    @Autowired
    private PosOrderItemMapper posOrderItemMapper;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(MemberBuyDetailEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    protected void doExport(MemberBuyDetailEvent event, BiReportPo report, boolean flag) {

        var res = this.queryMemberOrderData(event);

        var excelWriter = write(report.getFilePath())
                .inMemory(true)
                .build();

        var writeSheet = writerSheet("会员销售明细")
                .sheetNo(0)
                .head(MemberOrderItemDetailResponse.class)
                .registerWriteHandler(new ColumnWidthStyleStrategy())
                .automaticMergeHead(true)
                .build();

        excelWriter.write(res, writeSheet);
        ExcelImgUtils.CreatImgSheet(imgPath, report.getPicUrl(), excelWriter);
        excelWriter.finish();
    }

    /**
     * 查询需要导出的数据
     *
     * @param event
     * @return
     */
    private List<MemberOrderItemDetailResponse> queryMemberOrderData(MemberBuyDetailEvent event) {

        var orderRequest = event.getOrderRequest();
        var page = new Page<MemberOrderItemResponse>(0, orderRequest.getPageSize());
        //2、根据条件查询订单主表信息
        var startTime = orderRequest.getStartTime();
        var endTime = orderRequest.getEndTime() == null ? null : orderRequest.getEndTime().plusDays(1);
        var itemPoIPage = posOrderItemMapper.selectOrderDetail(page, orderRequest, startTime, endTime);
        var itemPoList = itemPoIPage.getRecords();

        //4、如果不为空，则进行数据转换
        return itemPoList.stream().map(e -> {
            String proTypeDesc;
            if (e.getIsVirtual() == null || (!e.getIsVirtual().equals(CommonStatusEnum.INVALID.getCode()) && !e.getIsVirtual().equals(CommonStatusEnum.EFFECTIVE.getCode()))) {
                proTypeDesc = null;
            } else if (e.getIsVirtual().equals(CommonStatusEnum.INVALID.getCode())) {
                proTypeDesc = "正常销售";
            } else {
                proTypeDesc = "促销";
            }
            e.setProTypeDesc(proTypeDesc);
            e.setDesc(e.getTransType().equals(TransTypeEnum.GOODS_OUT.getCode()) ? "销售" : "退货");

            var data = new MemberOrderItemDetailResponse();
            BeanUtils.copyProperties(e, data);
            data.setBizTime(e.getBizTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

            DecimalFormat df1 = new DecimalFormat("0.00");
            data.setSalePrice(df1.format(e.getSalePrice()));
            return data;

        }).collect(toList());

    }

}
