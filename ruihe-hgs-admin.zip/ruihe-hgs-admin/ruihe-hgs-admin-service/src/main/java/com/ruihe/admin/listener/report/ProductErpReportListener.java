package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.Report4ProductErpEvent;
import com.ruihe.admin.listener.report.core.ReportController;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.admin.mapper.bi.WhReportMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.request.bi.ProductErpReportRequest;
import com.ruihe.admin.response.bi.ProductErpOtherPo;
import com.ruihe.admin.response.bi.ProductErpReportResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/***
 * 产品进销存报表
 * @author lrc
 */
@Component
@RequiredArgsConstructor
public class ProductErpReportListener extends AbstractReportListener<Report4ProductErpEvent> {

    private final WhReportMapper whReportMapper;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_REPORT)
    @EventListener
    public void onApplicationEvent(Report4ProductErpEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    public void doExport(Report4ProductErpEvent event, BiReportPo report, boolean flag) {
        TableDefine define = ProductErpDefine.create(event.getRequest());

        ReportController controller = new ReportController(define);
        controller.name("产品柜台进销存报表");
        controller.savePath(report.getFilePath());

        List<ProductErpReportResponse> data = whReportMapper.prdErpBase(
                event.getRequest(),
                event.getReport().getUid(),
                null,
                define.selectCols("s.")
                        .replaceAll("s.counter_name","ci.counter_name"),
                define.groupCols("s.")
                        .replaceAll("s.counter_name","ci.counter_name"),
                event.getRequest().getSelectRequest().isPrd(),
                event.getRequest().getSelectRequest().isCounterId(),
                event.getRequest().getSelectRequest().isCounterName(),
                flag);
        Map<String, ProductErpReportResponse> cache = new HashMap<>();
        data.forEach(d -> cache.put(buildKey(d.getCounterId(), d.getCounterName(), d.getPrdBarCode(), event.getRequest()), d));

        //2、其他数据
        List<ProductErpOtherPo> otherData = whReportMapper.prdErpOther(
                event.getRequest(),
                event.getReport().getUid(),
                null,
                define.selectCols("sl."),
                define.groupCols("sl."),
                flag);

        otherData.forEach(d -> {
            String key = buildKey(d.getCounterId(), d.getCounterName(), d.getPrdBarCode(), event.getRequest());
            ProductErpReportResponse response = cache.get(key);
            if(response != null){
                fillResponse(d, response);
            }
        });
        controller.fillData(data);
        controller.totalCalculate();
        controller.write(this.imgPath, report.getPicUrl());
    }

    private String buildKey(String counterId, String counterName, String prdBarCode, ProductErpReportRequest request) {
        if (request.getSelectRequest().isPrd() && request.getSelectRequest().isCounterId() && request.getSelectRequest().isCounterName()) {
            return counterId + "_" + counterName + "_" + prdBarCode;
        } else if (request.getSelectRequest().isCounterId() && request.getSelectRequest().isCounterName()) {
            return counterId + "_" + counterName;
        } else if (request.getSelectRequest().isPrd() && request.getSelectRequest().isCounterId()) {
            return counterId + "_" + prdBarCode;
        } else if (request.getSelectRequest().isPrd() && request.getSelectRequest().isCounterName()) {
            return counterName + "_" + prdBarCode;
        } else if (request.getSelectRequest().isPrd()) {
            return prdBarCode;
        } else if (request.getSelectRequest().isCounterId()) {
            return counterId;
        } else if (request.getSelectRequest().isCounterName()) {
            return counterName;
        } else {
            throw new RuntimeException("至少选择一项");
        }
    }

    private void fillResponse(ProductErpOtherPo e, ProductErpReportResponse response) {
        switch (e.getBizType()) {
            //入库
            case 1:
                response.setEnterQty(e.getQty());
                response.setEnterAmt(e.getAmt());
                break;
            //调入
            case 2:
                response.setInQty(e.getQty());
                response.setInAmt(e.getAmt());
                break;
            //调出
            case 3:
                response.setOutQty(Math.abs(e.getQty()));
                response.setOutAmt(e.getAmt().abs());
                break;
            //退库
            case 5:
                response.setRetreatQty(Math.abs(e.getQty()));
                response.setRetreatAmt(e.getAmt().abs());
                break;
            //销售
            case 6:
                response.setSalesQty(response.getSalesQty() == null ? Math.abs(e.getQty()) : response.getSalesQty() + Math.abs(e.getQty()));
                response.setSalesAmt(response.getSalesAmt() == null ? e.getAmt().abs() : response.getSalesAmt().add(e.getAmt().abs()));
                break;
            //销售退货
            case 7:
                response.setReturnQty(response.getReturnQty() == null ? e.getQty() : response.getReturnQty() + e.getQty());
                response.setReturnAmt(response.getReturnAmt() == null ? e.getAmt() : response.getReturnAmt().add(e.getAmt()));
                break;
            //预订单提货
            case 8:
                response.setSalesQty(response.getSalesQty() == null ? Math.abs(e.getQty()) : response.getSalesQty() + Math.abs(e.getQty()));
                response.setSalesAmt(response.getSalesAmt() == null ? e.getAmt().abs() : response.getSalesAmt().add(e.getAmt().abs()));
                break;
            //预订单提货退货
            case 9:
                response.setReturnQty(response.getReturnQty() == null ? e.getQty() : response.getReturnQty() + e.getQty());
                response.setReturnAmt(response.getReturnAmt() == null ? e.getAmt() : response.getReturnAmt().add(e.getAmt()));
                break;
            //积分兑换
            case 10:
                response.setSalesQty(response.getSalesQty() == null ? Math.abs(e.getQty()) : response.getSalesQty() + Math.abs(e.getQty()));
                response.setSalesAmt(response.getSalesAmt() == null ? e.getAmt().abs() : response.getSalesAmt().add(e.getAmt().abs()));
                break;
            //积分兑换退货
            case 11:
                response.setReturnQty(response.getReturnQty() == null ? e.getQty() : response.getReturnQty() + e.getQty());
                response.setReturnAmt(response.getReturnAmt() == null ? e.getAmt() : response.getReturnAmt().add(e.getAmt()));
                break;
            //盘点
            case 12:
                //盘盈
                if (e.getQty() >= 0) {
                    response.setInventorySurplusQty(e.getQty());
                    response.setInventorySurplusAmt(e.getAmt());
                } else {
                    //盘亏
                    response.setInventoryLossesQty(Math.abs(e.getQty()));
                    response.setInventoryLossesAmt(e.getAmt().abs());
                }
                break;
            default:
                break;
        }
    }
}
