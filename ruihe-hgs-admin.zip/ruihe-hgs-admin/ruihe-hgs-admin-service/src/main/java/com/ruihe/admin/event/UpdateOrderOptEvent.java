package com.ruihe.admin.event;


import com.ruihe.common.annotation.Ella;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 因为order里面有冗余的组织结构用来用于报表方便查询，在修改组织结构的时候需要同步修改订单中的组织结构
 * 2020年5月5日17:56:06
 * @author xyf
 */
@Ella(Describe = "更新订单中的柜台模式类型")
@Data
@EqualsAndHashCode(callSuper = false)
public class UpdateOrderOptEvent {
    private String counterId;
    public UpdateOrderOptEvent(String counterId) {
        this.counterId = counterId;
    }
}
