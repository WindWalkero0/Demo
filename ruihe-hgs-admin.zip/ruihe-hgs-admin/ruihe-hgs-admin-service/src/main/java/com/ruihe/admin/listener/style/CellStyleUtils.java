package com.ruihe.admin.listener.style;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.write.metadata.style.WriteCellStyle;
import com.alibaba.excel.write.metadata.style.WriteFont;
import com.ruihe.common.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Triple;
import org.apache.poi.ss.usermodel.*;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * 自定义单元格样式，解决异常：
 * The maximum number of Cell Styles was exceeded. You can define up to 64000 style in a .xlsx Workbook
 *
 * @author William
 */
@Slf4j
public class CellStyleUtils {

    /**
     * 默认表头样式
     *
     * @return
     */
    private static WriteCellStyle defaultHeadStyle() {
        WriteCellStyle headWriteCellStyle = new WriteCellStyle();
        headWriteCellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        WriteFont headWriteFont = new WriteFont();
        headWriteFont.setFontName("宋体");
        headWriteFont.setFontHeightInPoints((short) 14);
        headWriteFont.setBold(true);
        headWriteCellStyle.setWriteFont(headWriteFont);
        return headWriteCellStyle;
    }

    /**
     * 默认数据区样式
     *
     * @return
     */
    private static WriteCellStyle defaultDataStyle(String headerName, Class clazz, Short dataFormat) {
        WriteCellStyle cellStyle = new WriteCellStyle();
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        cellStyle.setBorderRight(BorderStyle.THIN);
        cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
        //静态表头区域对应的数据区--设置单元格内容水平居中垂直向上
        if (clazz == String.class) {
            cellStyle.setHorizontalAlignment(HorizontalAlignment.CENTER);
            cellStyle.setVerticalAlignment(VerticalAlignment.TOP);
        }
        if (dataFormat != null) {
            cellStyle.setDataFormat(dataFormat);
            return cellStyle;
        }
        if (clazz == BigDecimal.class) {
            if (headerName.contains("占比")) {
                cellStyle.setDataFormat((short) BuiltinFormats.getBuiltinFormat("0.00%"));
            } else {
                //金额千分符
                cellStyle.setDataFormat((short) BuiltinFormats.getBuiltinFormat("#,##0.00"));
            }
        } else if (clazz == Integer.class || clazz == Long.class) {
            //数量设置千分符
            cellStyle.setDataFormat((short) BuiltinFormats.getBuiltinFormat("#,##0"));
        }
        return cellStyle;
    }

    /**
     * 自定义表格样式
     *
     * @param headerNameList 对应数据区的表头，多行表头取最下面的一行
     * @param dataTypes
     * @return
     */
    public static CustomHorizontalCellStyleStrategy customHorizontalCellStyleStrategy(final List<String> headerNameList, final List<Class<?>> dataTypes) {
        if (headerNameList.size() != dataTypes.size()) {
            log.error("表头数量与数据区clazz数量不一致");
            throw new BizException("表头数量与数据区clazz数量不一致");
        }
        WriteCellStyle headWriteCellStyle = defaultHeadStyle();
        final int len = headerNameList.size();
        List<WriteCellStyle> styleList = IntStream.range(0, len).boxed().map(idx ->
                defaultDataStyle(headerNameList.get(idx), dataTypes.get(idx), null)
        ).collect(Collectors.toList());
        return new CustomHorizontalCellStyleStrategy(headWriteCellStyle, styleList);
    }

    public static CustomHorizontalCellStyleStrategy customHorizontalCellStyleStrategy(final Triple<Integer, List<Class<?>>, List<List<String>>> headerCols) {
        final List<String> headerNameList = headerCols.getRight().stream().map(e ->
                e.get(e.size() - 1)
        ).collect(Collectors.toList());
        final List<Class<?>> dataTypes = headerCols.getMiddle();
        return customHorizontalCellStyleStrategy(headerNameList, dataTypes);
    }

    /**
     * 自定义格式，处理表头为实体类的情况
     *
     * @param clazz
     * @param dataTypes
     * @return
     */
    public static CustomHorizontalCellStyleStrategy customHorizontalCellStyleStrategy(final Class clazz, final List<Class<?>> dataTypes) {
        Field[] fields = clazz.getDeclaredFields();
        if (fields.length != dataTypes.size()) {
            log.error("表头数量与数据区clazz数量不一致");
            throw new BizException("表头数量与数据区clazz数量不一致");
        }
        WriteCellStyle headWriteCellStyle = defaultHeadStyle();
        final int len = fields.length;
        List<WriteCellStyle> styleList = IntStream.range(0, len).boxed().map(idx ->
                defaultDataStyle(fields[idx].getAnnotation(ExcelProperty.class).value()[0], dataTypes.get(idx), null)
        ).collect(Collectors.toList());
        return new CustomHorizontalCellStyleStrategy(headWriteCellStyle, styleList);
    }

}
