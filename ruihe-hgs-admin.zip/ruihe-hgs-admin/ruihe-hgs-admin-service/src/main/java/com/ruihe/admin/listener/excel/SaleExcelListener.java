package com.ruihe.admin.listener.excel;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.google.common.collect.Lists;
import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.admin.service.erp.report.PrdSalesQueryElasticSearch;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.SaleExcelEvent;
import com.ruihe.admin.listener.style.CellStyleUtils;
import com.ruihe.admin.listener.style.CustomHorizontalCellStyleStrategy;
import com.ruihe.admin.mapper.erp.report.PrdSalesRecordMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.request.erp.PrdSalesRecordRequest;
import com.ruihe.admin.response.erp.SaleOrderExcelResponse;
import com.ruihe.admin.utils.ColumnWidthStyleStrategy;
import com.ruihe.admin.utils.ExcelImgUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

/***
 * 产品销售记录查询
 * @author fly
 */
@Slf4j
@Component
public class SaleExcelListener extends AbstractReportListener<SaleExcelEvent> {

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    @Autowired
    private PrdSalesRecordMapper prdSalesRecordMapper;

    @Autowired
    private PrdSalesQueryElasticSearch prdElasticSearch;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(SaleExcelEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    protected void doExport(SaleExcelEvent event, BiReportPo report, boolean flag) {
        PrdSalesRecordRequest request = (PrdSalesRecordRequest) redisTemplate.opsForValue().get(event.getKey());
        List<SaleOrderExcelResponse> excelResponseList;
        if (CommonConstant.YES.equals(event.getYes())) {
            //es查询数据
            excelResponseList = prdElasticSearch.saleExcelResponseList(request);
        } else {
            //购买记录分开查询
            excelResponseList = prdSalesRecordMapper.saleExcelResponseList(request, request.getOrgQueryConditionRequest());
        }
        //数据写入到字节流
        List<Class<?>> dataTypes = getDataTypesList();
        CustomHorizontalCellStyleStrategy cellStyle = CellStyleUtils.customHorizontalCellStyleStrategy(SaleOrderExcelResponse.class, dataTypes);
        ExcelWriter excelWriter = EasyExcel.write(report.getFilePath())
                .inMemory(true)
                .build();
        WriteSheet writeSheet = EasyExcel.writerSheet("第1～" + excelResponseList.size() + "条")
                .sheetNo(0)
                .head(SaleOrderExcelResponse.class)
                .registerWriteHandler(cellStyle)
                .registerWriteHandler(new ColumnWidthStyleStrategy())
                .automaticMergeHead(true)
                .build();
        excelWriter.write(excelResponseList, writeSheet);
        ExcelImgUtils.CreatImgSheet(imgPath, report.getPicUrl(), excelWriter);
        excelWriter.finish();
    }

    /**
     * 处理表头数据
     *
     * @return
     */
    private List<Class<?>> getDataTypesList() {
        List<Class<?>> dataType = Lists.newArrayList();
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(BigDecimal.class);
        dataType.add(Integer.class);
        return dataType;
    }
}
