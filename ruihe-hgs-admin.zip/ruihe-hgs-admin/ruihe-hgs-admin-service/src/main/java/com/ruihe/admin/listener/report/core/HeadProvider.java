package com.ruihe.admin.listener.report.core;

import java.util.List;
import java.util.Set;
import java.util.TreeMap;

public interface HeadProvider {

    List<List<String>> head();

    Set<ColKey> colKeys();

    TreeNode<TreeMap<RowKey, CellValue>> colTree();
}
