package com.ruihe.admin.request;

import com.ruihe.common.annotation.EnumValidation;
import com.ruihe.common.annotation.Update;
import com.ruihe.common.enums.sat.SatTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author LiangYuan
 * @date 2021-03-10 9:31
 */
@ApiModel(value = "SatQunQueryVo", description = "新增/编辑问卷请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class SatQunRequest implements Serializable {

    @NotNull(message = "问卷ID不能为空", groups = {Update.class})
    @ApiModelProperty(value = "问卷ID，编辑更新的时候需要传")
    private String id;

    @NotNull(message = "问卷名称不能为空")
    @Size(max = 50, message = "字数超过限制,请核实!")
    @ApiModelProperty(value = "问卷名称")
    private String name;

    @NotNull(message = "问卷类型不能为空")
    @EnumValidation(clazz = SatTypeEnum.class, method = "getKey", message = "问卷类型错误")
    @ApiModelProperty(value = "问卷类型：1销售，2服务，3月度")
    private Integer type;

    @NotNull(message = "问卷总分不能为空")
    @Min(value = 1, message = "最低1分")
    @Max(value = 100, message = "最高100分")
    @ApiModelProperty(value = "问卷总分")
    private BigDecimal totalScore;

    @ApiModelProperty(value = "开头语")
    @Size(max = 300, message = "字数超过限制,请核实!")
    private String prologue;

    @ApiModelProperty(value = "结束语")
    @Size(max = 300, message = "字数超过限制,请核实!")
    private String peroration;

    @NotEmpty(message = "题目不能为空")
    @Valid
    @ApiModelProperty(value = "题目列表")
    private List<SatQunSubjectRequest> subjectRequestList;
}
