package com.ruihe.admin.listener;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.admin.event.CounterOperateEvent;
import com.ruihe.admin.mapper.basic.CounterLocationMapper;
import com.ruihe.admin.mapper.basic.CounterMapper;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.CounterLocation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.time.LocalDateTime;

/**
 * 柜台操作事件监听
 * @author qubin
 * @date 2021/4/26 9:50
 */
@Slf4j
@Component
public class CounterOperateListener {

    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private CounterLocationMapper counterLocationMapper;


    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(CounterOperateEvent event) {
        try {
            String counterId = event.getCounterId();
            CounterInformation counterInformation =  counterMapper.selectOne(Wrappers.<CounterInformation>lambdaQuery()
                   .eq(CounterInformation::getCounterId, counterId));

            CounterLocation counterLocation = counterLocationMapper.selectOne(Wrappers.<CounterLocation>lambdaQuery()
                    .eq(CounterLocation::getCounterId, counterId));
            if(counterLocation == null){
                counterLocationMapper.insert(CounterLocation.builder()
                        .counterId(counterId)
                        .counterName(counterInformation.getCounterName())
                        .counterAddress(counterInformation.getCounterAddress())
                        .status(0)
                        .updateTime(LocalDateTime.now())
                        .createTime(LocalDateTime.now())
                        .build());
                return;
            }
            counterLocationMapper.updateById(CounterLocation.builder()
                    .updateTime(LocalDateTime.now())
                    .status(0)
                    .counterId(counterId)
                    .counterAddress(counterInformation.getCounterAddress())
                    .build());

        } catch (Exception e) {
            log.error("柜台操作事件监听错误： event = " + event);
        }
    }
}
