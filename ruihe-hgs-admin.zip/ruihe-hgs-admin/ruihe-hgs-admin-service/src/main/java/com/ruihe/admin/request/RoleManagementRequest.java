package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author luojie
 * @program ruihe-top
 * @description 角色管理查询请求实体类
 * @create: 2021/7/7 11:01
 */
@Data
@ApiModel(value = "角色管理查询请求体", description = "角色管理查询请求体")
public class RoleManagementRequest {
    @ApiModelProperty(value = "角色名称")
    private String roleName;
    
    @ApiModelProperty("是否有效(0-有效 1-无效)")
    private Integer roleStatus;
    
    @ApiModelProperty("菜单uid")
    private String menuUid;
    
    @ApiModelProperty("按钮功能uid")
    private String jurUid;
    
    @ApiModelProperty(value = "页码", required = true)
    private Integer pageNumber;
    
    @ApiModelProperty(value = "每页数量", required = true)
    private Integer pageSize;
}
