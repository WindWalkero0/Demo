package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.report.core.Column;
import com.ruihe.admin.listener.report.core.ColumnDefine;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.admin.request.bi.ProductBizDetailReportRequest;
import com.ruihe.admin.request.bi.ProductBizDetailSelectRequest;

import java.math.BigDecimal;

public class ProductBizDetailDefine extends TableDefine {
    static Column goodsQty = new Column("实物销售总支数", "goodsQty", Integer.class);
    static Column prdAmt = new Column("产品零售价总金额", "prdAmt", BigDecimal.class);
    static Column realAmt = new Column("销售总金额", "realAmt", BigDecimal.class);

    static Column bigCatName = new Column(
            "产品大类",
            "bigCatName",
            "ifnull({alias}big_cat_name,'未知') as big_cat_name",
            "{alias}big_cat_name");

    static Column mediumCatName = new Column(
            "产品中类",
            "mediumCatName",
            "ifnull({alias}medium_cat_name,'未知') as medium_cat_name",
            "{alias}medium_cat_name");

    static Column smallCatName = new Column(
            "产品小类",
            "smallCatName",
            "ifnull({alias}small_cat_name,'未知') as small_cat_name",
            "{alias}small_cat_name");

    public static TableDefine create(ProductBizDetailReportRequest request) {
        ProductBizDetailSelectRequest selectRequest = request.getSelectRequest();
        ProductBizDetailDefine define = new ProductBizDetailDefine();
        define.addHorizontalColumns(selectRequest);
        define.addVerticalColumns(selectRequest);
        define.addValueColumns(selectRequest);
        define.setStartTime(request.getStartTime());
        define.setEndTime(request.getEndTime());
        define.setMonthly(request.getSelectRequest().isMonthly());
        define.setDaily(request.getSelectRequest().isDaily());
        define.setTotalFlag(TableDefine.TOTAL_ROW_FULL | TableDefine.TOTAL_COL_FULL);
        return define;
    }

    /**
     * 添加查询字段，不包括统计数值字段
     */
    private void addHorizontalColumns(ProductBizDetailSelectRequest req) {
        this.addHorizontalColumn(bigCatName.p("p."), req.isBigCat());
        this.addHorizontalColumn(mediumCatName.p("p."), req.isMediumCat());
        this.addHorizontalColumn(smallCatName.p("p."), req.isSmallCat());

        boolean prd = req.isGoodsBarCode() || req.isPrdBarCode() || req.isPrdName();
        this.addHorizontalColumn(ColumnDefine.prdBarCode.show(req.isPrdBarCode()).pb(), prd);
        this.addHorizontalColumn(ColumnDefine.goodsBarCode.show(req.isGoodsBarCode()).pb(), prd);
        this.addHorizontalColumn(ColumnDefine.prdName.show(req.isPrdName()).pb(), prd);

        this.addHorizontalColumn(ColumnDefine.areaCode.pa(), req.isArea());
        this.addHorizontalColumn(ColumnDefine.areaName.pa(), req.isArea());
        this.addHorizontalColumn(ColumnDefine.officeName.pa(), req.isOffice());
        this.addHorizontalColumn(ColumnDefine.principalName.pa(), req.isPrincipal());
        this.addHorizontalColumn(ColumnDefine.counterId.pa(), req.isCounterId());
        this.addHorizontalColumn(ColumnDefine.counterName.pa(), req.isCounterName());

        boolean isBaCode = req.isBaCode() || req.isBaName();
        this.addHorizontalColumn(ColumnDefine.baCode.show(req.isBaCode()).pa(), isBaCode);
        this.addHorizontalColumn(ColumnDefine.baName.pa(), req.isBaName());
    }

    private void addVerticalColumns(ProductBizDetailSelectRequest req) {
        this.addVerticalColumn(ColumnDefine.month.pa(), req.isMonthly());
        this.addVerticalColumn(ColumnDefine.day.pa(), req.isDaily());

        ProductBizDetailSelectRequest.ColSelect colSelect = req.getColSelect();
        if (colSelect != null) {
            this.addVerticalColumn(bigCatName.pb(), colSelect.isBigCat());
            this.addVerticalColumn(mediumCatName.pb(), colSelect.isMediumCat());
            this.addVerticalColumn(smallCatName.pb(), colSelect.isSmallCat());

            boolean prd = colSelect.isGoodsBarCode() || colSelect.isPrdBarCode() || colSelect.isPrdName();
            this.addVerticalColumn(ColumnDefine.prdBarCode.show(colSelect.isPrdBarCode()).pb(), prd);
            this.addVerticalColumn(ColumnDefine.goodsBarCode.show(colSelect.isGoodsBarCode()).pb(), prd);
            this.addVerticalColumn(ColumnDefine.prdName.show(colSelect.isPrdName()).pb(), prd);
        }
    }

    /**
     * 添加统计数值字段
     */
    private void addValueColumns(ProductBizDetailSelectRequest req) {
        this.addValueColumn(goodsQty, req.isSkQty());
        this.addValueColumn(realAmt, req.isRealAmt());
        this.addValueColumn(prdAmt, req.isPrdAmt());
    }
}
