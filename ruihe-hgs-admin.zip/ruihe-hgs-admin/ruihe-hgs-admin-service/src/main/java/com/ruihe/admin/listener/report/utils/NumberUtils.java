package com.ruihe.admin.listener.report.utils;

import java.math.BigDecimal;
import java.math.BigInteger;

public class NumberUtils {
    public static BigDecimal toBigDecimal(Object value) {
        if (value instanceof Long) {
            return BigDecimal.valueOf((Long) value);
        } else if (value instanceof Integer) {
            return BigDecimal.valueOf((Integer) value);
        } else if (value instanceof Double) {
            return BigDecimal.valueOf((Double) value);
        } else if (value instanceof Float) {
            return BigDecimal.valueOf((Float) value);
        } else if (value instanceof BigDecimal) {
            return (BigDecimal) value;
        } else if (value instanceof BigInteger) {
            return new BigDecimal((BigInteger) value);
        }
        throw new IllegalArgumentException("不支持的类型 " + value);
    }
}
