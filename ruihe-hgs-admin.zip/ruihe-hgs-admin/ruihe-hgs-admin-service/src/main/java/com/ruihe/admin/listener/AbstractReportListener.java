package com.ruihe.admin.listener;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.bean.base.UserConcernPo;
import com.ruihe.common.enums.base.DepartmentEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.admin.event.BiReportEvent;
import com.ruihe.admin.mapper.basic.UserConcernMapper;
import com.ruihe.admin.mapper.bi.BiReportMapper;
import com.ruihe.admin.po.BiReportPo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.io.File;
import java.time.LocalDateTime;

@Slf4j
public abstract class AbstractReportListener<T extends BiReportEvent> {
    @Value("${file-upload.disk-root-path}bi/")
    protected String rootPath;
    @Value("${file-upload.disk-root-path}")
    protected String imgPath;

    @Autowired
    private BiReportMapper biReportMapper;
    @Autowired
    private UserConcernMapper userConcernMapper;

    public void onApplicationEvent(T event) {
        //判断目录有没有创建
        File fileDir = new File(rootPath);
        boolean mkdirs = true;
        if (!fileDir.exists()) {
            mkdirs = fileDir.mkdirs();
        }
        if (!mkdirs) {
            throw new BizException("创建文件夹" + rootPath + "失败！");
        }
        try {
            //根据当前用户的id查询组织机构权限
            //获取到当前登录人的信息查询关注部门信息
            Integer count = userConcernMapper.selectCount(Wrappers.<UserConcernPo>lambdaQuery()
                    .eq(UserConcernPo::getEmpId, event.getReport().getUid())
                    //如果关注部门类型小于等于1，则说明关注的部门是总部以上的，需要查询所有的柜台
                    .le(UserConcernPo::getDeptType, DepartmentEnum.HEADQUARTERS.getKey())
            );
            //是否只能查询关注柜台数据，用户关注部门包含总部节点则表示拥有所有柜台数据查询权限
            boolean flag = count == 0;
            this.doExport(event, event.getReport(), flag);
            //修改t_bi_report的状态为1,如果异常则改为-1
            BiReportPo updateReport = BiReportPo.builder()
                    .status(1)
                    .finishTime(LocalDateTime.now())
                    .updateTime(LocalDateTime.now())
                    .build();
            biReportMapper.update(updateReport, Wrappers.<BiReportPo>lambdaUpdate().eq(BiReportPo::getReportId, event.getReport().getReportId()));
        } catch (Exception e) {
            //更新状态
            BiReportPo updateReport = BiReportPo.builder()
                    .status(-1)
                    .finishTime(LocalDateTime.now())
                    .updateTime(LocalDateTime.now())
                    .build();
            biReportMapper.update(updateReport, Wrappers.<BiReportPo>lambdaUpdate().eq(BiReportPo::getReportId, event.getReport().getReportId()));
            log.error("BI报表导出异常,report={},user={}", event.getReport(), event.getOptor(), e);
        }
    }

    /**
     * 实际导出操作方法
     *
     * @param event
     */
    protected abstract void doExport(T event, BiReportPo report, boolean flag);

}
