package com.ruihe.admin.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 积分维护请求
 */
@Data
@ApiModel(value = "IntegralMaintainRequest", description = "积分维护")
public class IntegralMaintainRequest implements Serializable {
    @ApiModelProperty("会员Id")
    private String memberId;

    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("指定时间日期")
    private LocalDateTime dateTime;

    @ApiModelProperty(value = "积分差值")
    private int diff;

    @ApiModelProperty(value = "积分类型 0老积分  1新积分")
    private int inteType;

    @ApiModelProperty(value = "备注")
    @Size(max = 100,message = "备注最大长度为100个字符")
    private String remark;
}
