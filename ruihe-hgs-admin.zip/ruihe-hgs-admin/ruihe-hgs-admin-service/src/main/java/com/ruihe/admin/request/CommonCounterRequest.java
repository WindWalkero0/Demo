package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-01 14:49
 */
@ApiModel(value = "CommonCounterRequest", description = "通用柜台查询请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class CommonCounterRequest implements Serializable {

    @ApiModelProperty(value = "柜台代码/柜台名称模糊查询条件")
    private String counter;

    @ApiModelProperty(value = "状态--默认查全部，0有效，1无效")
    private Integer status;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
