package com.ruihe.admin.listener.excel;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.common.dao.bean.member.MemberSelect;
import com.ruihe.common.pojo.request.member.MemberSaleRequest;
import com.ruihe.common.pojo.response.member.MemberExcelResponse;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.util.CheckIsEmpty;
import com.ruihe.admin.event.MemberInfoExcelEvent;
import com.ruihe.admin.mapper.member.MemberMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.utils.ColumnWidthStyleStrategy;
import com.ruihe.admin.utils.ExcelImgUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.List;


/***
 * 会员信息excel导出
 * @author ly
 */
@Slf4j
@Component
public class MemberInfoExcelListener extends AbstractReportListener<MemberInfoExcelEvent> {

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;


    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(MemberInfoExcelEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    protected void doExport(MemberInfoExcelEvent event, BiReportPo report, boolean flag) {
        //根据条件查询数据
        MemberSelect memberSelect = (MemberSelect) redisTemplate.opsForValue().get(event.getKey());
        //购买记录分开查询
        MemberSaleRequest memberSaleRequest = this.extractMemberSaleRequest(memberSelect);
        //获取导出实体list
        List<MemberExcelResponse> memberExcelResponseList = memberMapper.memberExcelResponseList(memberSelect, memberSaleRequest);
        //excel导出
        ExcelWriter excelWriter = EasyExcel.write(report.getFilePath())
                .inMemory(true)
                .build();
        WriteSheet writeSheet = EasyExcel.writerSheet("第1～" + memberExcelResponseList.size() + "条")
                .sheetNo(0)
                .head(MemberExcelResponse.class)
                .registerWriteHandler(new ColumnWidthStyleStrategy())
                .automaticMergeHead(true)
                .build();
        excelWriter.write(memberExcelResponseList, writeSheet);
        //查询图片
        ExcelImgUtils.CreatImgSheet(this.imgPath, report.getPicUrl(), excelWriter);
        //释放资源
        excelWriter.finish();
    }

    /**
     * 构建购买记录查询信息
     *
     * @param request
     * @return
     */
    private MemberSaleRequest extractMemberSaleRequest(MemberSelect request) {
        MemberSaleRequest memberSaleRequest = new MemberSaleRequest();
        BeanUtils.copyProperties(request, memberSaleRequest);
        if (org.springframework.util.ObjectUtils.isEmpty(request.getCounterIdList())) {
            memberSaleRequest.setCounterIdList(null);
        }
        if (org.springframework.util.ObjectUtils.isEmpty(request.getPrdBarCodeList())) {
            memberSaleRequest.setPrdBarCodeList(null);
        }
        if (org.springframework.util.ObjectUtils.isEmpty(request.getPrdBarCodeListNo())) {
            memberSaleRequest.setPrdBarCodeListNo(null);
        }
        if (CheckIsEmpty.checkObjAllFieldsIsNull(memberSaleRequest)) {
            memberSaleRequest = null;
        }
        return memberSaleRequest;
    }
}
