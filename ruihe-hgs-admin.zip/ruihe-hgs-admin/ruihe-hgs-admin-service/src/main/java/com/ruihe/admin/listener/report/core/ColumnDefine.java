package com.ruihe.admin.listener.report.core;

/**
 * 一些公用的列定义
 */
public interface ColumnDefine {
    String ALIAS = "{alias}";

    Column bigCatCode = new Column(
            "产品大类编号",
            false,
            "bigCatCode",
            "ifnull({alias}big_cat_code, -1) as big_cat_code",
            "{alias}big_cat_code");
    Column bigCatName = new Column(
            "产品大类",
            "bigCatName",
            "ifnull({alias}big_cat_name,'未知') as big_cat_name",
            "{alias}big_cat_code");

    Column mediumCatCode = new Column(
            "产品中类编号",
            false,
            "mediumCatCode",
            "ifnull({alias}medium_cat_code, -1) as medium_cat_code",
            "{alias}medium_cat_code");
    Column mediumCatName = new Column(
            "产品中类",
            "mediumCatName",
            "ifnull({alias}medium_cat_name,'未知') as medium_cat_name",
            "{alias}medium_cat_code");

    Column smallCatCode = new Column(
            "产品小类编号",
            false,
            "smallCatCode",
            "ifnull({alias}small_cat_code, -1) as small_cat_code",
            "{alias}small_cat_code");
    Column smallCatName = new Column(
            "产品小类",
            "smallCatName",
            "ifnull({alias}small_cat_name,'未知') as small_cat_name",
            "{alias}small_cat_code");

    Column goodsBarCode = new Column(
            "产品条码",
            "goodsBarCode",
            "{alias}goods_bar_code",
            "{alias}prd_bar_code");
    Column prdBarCode = new Column(
            "厂商编码",
            "prdBarCode",
            "{alias}prd_bar_code",
            "{alias}prd_bar_code");
    Column prdName = new Column(
            "产品名称",
            "prdName",
            "{alias}prd_name",
            "{alias}prd_bar_code");
    Column salePrice = new Column(
            "产品价格",
            "salePrice",
            "{alias}sale_price",
            "{alias}prd_bar_code");
    Column stockPrdPrice = new Column(
            "产品价格",
            "salePrice",
            "{alias}prd_price as sale_price",
            "{alias}prd_bar_code");

    Column areaCode = new Column(
            "大区编号",
            false,
            "orgAreaCode",
            "IFNULL(NULLIF({alias}org_area_code, ''),'直属') org_area_code",
            "org_area_code");
    Column areaName = new Column(
            "大区",
            "orgAreaName",
            "IFNULL(NULLIF({alias}org_area_name, ''),'直属') org_area_name",
            "org_area_code");

    Column officeCode = new Column(
            "办事处编号",
            false,
            "orgOfficeCode",
            "IFNULL(NULLIF({alias}org_office_code, ''),'直属') org_office_code",
            "org_office_code");
    Column officeName = new Column(
            "办事处",
            "orgOfficeName",
            "IFNULL(NULLIF({alias}org_office_name, ''),'直属') org_office_name",
            "org_office_code");

    Column principalCode = new Column(
            "柜台主管编号", false,
            "orgPrincipalCode",
            "IFNULL(NULLIF({alias}org_principal_code, ''),'直属') org_principal_code",
            "org_principal_code");
    Column principalName = new Column(
            "柜台主管",
            "orgPrincipalName",
            "IFNULL(NULLIF({alias}org_principal_name, ''),'直属') org_principal_name",
            "org_principal_code");

    Column counterId = new Column(
            "柜台号",
            "counterId",
            "{alias}counter_id",
            "{alias}counter_id");
    Column counterName = new Column(
            "柜台名称",
            "counterName",
            "{alias}counter_name",
            "{alias}counter_name");

    Column baCode = new Column(
            "BA编号",
            "baCode",
            "{alias}ba_code",
            "{alias}ba_code");
    Column baName = new Column(
            "BA姓名",
            "baName",
            "{alias}ba_name",
            "{alias}ba_code");

    Column memberCard = new Column(
            "会员卡号",
            "memberCardNumber",
            "{alias}member_card_number",
            "{alias}member_id");
    Column memberName = new Column(
            "会员姓名",
            "memberName",
            "{alias}member_name",
            "{alias}member_id");
    Column mobilePhone = new Column(
            "手机号",
            "mobilePhone",
            "{alias}mobile_phone",
            "{alias}member_id");

    Column day = new Column(
            "日期",
            "time",
            "DATE_FORMAT({alias}biz_time,'%Y%m%d') time",
            "time");
    Column month = new Column(
            "年月",
            "time",
            "CASE WHEN EXTRACT(DAY FROM {alias}biz_time) > 25 then EXTRACT(YEAR_MONTH FROM DATE_ADD({alias}biz_time, INTERVAL 1 MONTH)) ELSE EXTRACT(YEAR_MONTH FROM {alias}biz_time) END time",
            "time");
}
