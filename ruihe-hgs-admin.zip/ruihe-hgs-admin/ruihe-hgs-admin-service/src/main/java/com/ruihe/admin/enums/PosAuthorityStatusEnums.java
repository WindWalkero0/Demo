package com.ruihe.admin.enums;

/**
 * @author 梁远
 * @Description 空退/补录状态
 * @create 2019-12-10 10:19
 */
public enum PosAuthorityStatusEnums {

    /**
     * 0未下发
     **/
    NOT_ISSUED(0, "未下发"),
    /**
     * 1已下发
     **/
    ALREADY_ISSUED(1, "已下发"),
    /**
     * 2已删除
     **/
    DELETE(2, "已删除");

    private Integer code;
    private String msg;


    PosAuthorityStatusEnums(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
