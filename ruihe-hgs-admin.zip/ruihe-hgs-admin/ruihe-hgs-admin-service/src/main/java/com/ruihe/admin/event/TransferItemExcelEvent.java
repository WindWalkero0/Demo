package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 调拨单子表excel导出
 *
 * @author ly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class TransferItemExcelEvent extends BiReportEvent {

    private String key;

    @Builder
    public TransferItemExcelEvent(String key) {
        this.key = key;
    }
}
