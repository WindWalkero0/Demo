package com.ruihe.admin.request;

import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * 积分查询请求
 *
 * @author William
 */
@ApiModel(value = "IntegralOrderPageQueryRequest", description = "积分查询请求")
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IntegralOrderItemPageQueryRequest extends PageForm implements Serializable {

    @ApiModelProperty("单据日期-开始时间")
    private LocalDate startTime;

    @ApiModelProperty("单据日期-结束时间")
    private LocalDate endTime;

    @ApiModelProperty("会员手机号")
    private String memberPhone;

    @ApiModelProperty("柜台号")
    private String counterId;

    @ApiModelProperty("【会员详情页必填】会员id")
    private String memberId;

    @ApiModelProperty("业务类型(10正常销售,20销售退货,30积分兑换,40积分兑换退货,50积分维护,60积分清零)")
    private String bizType;

    @ApiModelProperty("单据号")
    private String bizNo;

    @ApiModelProperty("积分规则【积分活动id】")
    private Integer activityId;

    @ApiModelProperty("积分范围起")
    private Integer startIntegralQty;

    @ApiModelProperty("积分范围止")
    private Integer endIntegralQty;
}
