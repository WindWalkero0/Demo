package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-12-26 16:20
 */
@ApiModel(value = "UserAccountRequest", description = "用户账号请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class UserAccountRequest implements Serializable {

    @ApiModelProperty(value = "登录帐号")
    @Size(max = 50, message = "登录帐号最大长度为50个字符")
    private String account;

    @ApiModelProperty(value = "登录密码")
    @Size(max = 32, message = "登录密码最大长度为32个字符")
    private String password;

    @ApiModelProperty(value = "当前登录帐号的id")
    private String currentId;

    @ApiModelProperty(value = "当前登录帐号的密码")
    private String currentPassword;

    @ApiModelProperty(value = "帐号状态")
    private Integer accountStatus;
}
