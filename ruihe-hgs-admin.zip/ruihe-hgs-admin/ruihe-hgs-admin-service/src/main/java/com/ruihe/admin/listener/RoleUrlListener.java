package com.ruihe.admin.listener;


import com.ruihe.admin.service.basic.JurisdictionService;
import com.ruihe.common.dao.bean.base.RoleMenu;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.RoleUrlEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Ella(Describe = "当进行授权管理的时候需要更新角色对应的url", Author = "K")
@Slf4j
@Component
public class RoleUrlListener implements ApplicationListener<RoleUrlEvent> {


    private final String KEY = "URL";


    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    @Autowired
    private JurisdictionService jurisdictionService;


    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    public void onApplicationEvent(RoleUrlEvent event) {
        Map<String, String> map = new HashMap<>();
        //先删除所有的url
        redisTemplate.opsForHash().delete(KEY, event.getRoleId());
        List<RoleMenu> roleMenus = jurisdictionService.selectRoleMenus(RoleMenu.builder().roleUid(event.getRoleId()).menuParentUid("0").build());
        if (!roleMenus.isEmpty()) {
            roleMenus.stream().forEach(roleMenu -> {
                jurisdictionService.operationRoleUrl(roleMenu, map, event.getRoleId());
            });
        }
        //存储到redis
        redisTemplate.opsForHash().put(KEY, event.getRoleId(), map);

    }


}
