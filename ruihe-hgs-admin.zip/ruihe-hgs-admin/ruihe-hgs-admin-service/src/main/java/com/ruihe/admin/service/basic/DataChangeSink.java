package com.ruihe.admin.service.basic;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.annotation.TableName;
import com.google.common.base.Splitter;
import com.google.common.collect.Maps;
import com.ruihe.common.annotation.FieldName;
import com.ruihe.common.constant.MaxwellConst;
import com.ruihe.common.dao.bean.base.*;
import com.ruihe.common.dao.bean.member.KbActivity;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.nursing.NursingMemberPO;
import com.ruihe.common.dao.mapper.ChangeFeildMapper;
import com.ruihe.common.utils.IdGenerator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * 处理常规表的异动，会员表比较特殊BA、会员自己、职能后台的人、定时任务都可以操作
 *
 * @author William
 * @date 2020-11-11 15:57
 */
@Slf4j
@Configuration
public class DataChangeSink implements InitializingBean {
    @Autowired
    private ChangeFeildMapper changeFeildMapper;

    /**
     * 数据格式<表名,字段map<表名,字段>,缓存起来
     */
    private final ConcurrentHashMap<String, Map<String, Pair<String, Map<String, String>>>> mapping = new ConcurrentHashMap<String, Map<String, Pair<String, Map<String, String>>>>();
    List<Class<?>> clazzList = List.of(CounterInformation.class,
            Department.class,
            UserInformation.class,
            Product.class,
            MemberInfo.class,
            KbActivity.class,
            NursingMemberPO.class
    );

    @Override
    public void afterPropertiesSet() throws Exception {
        mapping.clear();
        //数据格式map<表名,map<列名,pair<字段描述,枚举map>>>，可优化为TreeBasedTable
        Map<String, Map<String, Pair<String, Map<String, String>>>> collect = clazzList.stream()
                .map(e -> {
                    var key = e.getDeclaredAnnotation(TableName.class).value();
                    //数据格式Map<列名,Pair<字段描述,可能存在的枚举>>
                    Map<String, Pair<String, Map<String, String>>> avlFeildMap = Maps.newHashMap();
                    for (Field field : e.getDeclaredFields()) {
                        FieldName fieldName = field.getAnnotation(FieldName.class);
                        //不是null且不忽略
                        if (fieldName != null && !fieldName.ig()) {
                            String columnName = camel2under(field.getName());
                            if (StringUtils.isBlank(fieldName.enumeration())) {
                                avlFeildMap.put(columnName, Pair.of(fieldName.name(), null));
                            } else {
                                Map<String, String> enumeration = Splitter.on("|").trimResults().omitEmptyStrings().withKeyValueSeparator(":").split(fieldName.enumeration());
                                avlFeildMap.put(columnName, Pair.of(fieldName.name(), enumeration));
                            }
                        }
                    }
                    return Map.entry(key, avlFeildMap);
                }).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        mapping.putAll(collect);
    }


    /***
     * 监听目标表，处理异动
     * maxwell格式
     * http://maxwells-daemon.io/dataformat/
     * @return
     */
    @Bean
    public Consumer<String> processChange() {
        return in -> {
            log.info("DataChangeSink.processChange,{}", in);
            JSONObject json = JSONObject.parseObject(in);
            //提取构造异动字段值
            List<ChangeFeildPo> changeFeildList = this.extract(json);
            if (ObjectUtils.isNotEmpty(changeFeildList)) {
                this.changeFeildMapper.batchInsert(changeFeildList);
            }
        };
    }

    /**
     * 功能：驼峰命名转下划线命名(小写和大写紧挨一起的地方,加上分隔符,然后全部转小写)
     */
    private static String camel2under(String name) {
        String separator = "_";
        name = name.replaceAll("([a-z])([A-Z])", "$1" + separator + "$2").toLowerCase();
        return name;
    }

    /**
     * maxwell格式
     * http://maxwells-daemon.io/dataformat/
     *
     * @param json maxwell json对象
     */
    private <T> List<ChangeFeildPo> extract(JSONObject json) {
        JSONObject data = json.getJSONObject("data");
        //获取旧的的数据
        JSONObject old = json.getJSONObject("old");
        //insert/update/delete/bootstrap-insert
        String type = json.getString("type");
        String table = json.getString("table");
        //异动记录id
        Long changeId = data.getLong("change_id");
        if (changeId == null) {
            log.error(String.format("表%s没有字段change_id", table));
            return List.of();
        }
        //1、找到每个表对应的需要异动记录的字段
        Map<String, Pair<String, Map<String, String>>> avlFeildMap = mapping.get(table);
        //2、根据maxwell数据格式构造异动字段列表
        if (MaxwellConst.INSERT.equals(type)) {
            //没有old
            return avlFeildMap.entrySet().stream()
                    .map(e -> {
                        String fieldAfter = e.getValue().getRight() == null ? data.getString(e.getKey()) : e.getValue().getRight().get(data.getString(e.getKey()));
                        ChangeFeildPo changeFeildPo = ChangeFeildPo.builder()
                                .id(IdGenerator.getLongSerialNo())
                                .changeId(changeId)
                                .columnName(e.getKey())
                                .fieldDesc(e.getValue().getLeft())
                                .fieldAfter(StringUtils.defaultString(fieldAfter))
                                .fieldBefore("")
                                .createTime(LocalDateTime.now())
                                .build();
                        return changeFeildPo;
                    }).collect(Collectors.toList());
        } else if (MaxwellConst.BOOTSTRAP_INSERT.equals(type)) {
            //do nothing
        } else if (MaxwellConst.UPDATE.equals(type)) {
            if (old != null) {
                return avlFeildMap.entrySet().stream()
                        .filter(e -> old.containsKey(e.getKey()))
                        .map(e -> {
                            String fieldAfter = e.getValue().getRight() == null ? data.getString(e.getKey()) : e.getValue().getRight().get(data.getString(e.getKey()));
                            String fieldBefore = e.getValue().getRight() == null ? old.getString(e.getKey()) : e.getValue().getRight().get(old.getString(e.getKey()));
                            ChangeFeildPo changeFeildPo = ChangeFeildPo.builder()
                                    .id(IdGenerator.getLongSerialNo())
                                    .changeId(changeId)
                                    .columnName(e.getKey())
                                    .fieldDesc(e.getValue().getLeft())
                                    .fieldAfter(StringUtils.defaultString(fieldAfter))
                                    .fieldBefore(StringUtils.defaultString(fieldBefore))
                                    .createTime(LocalDateTime.now())
                                    .build();
                            return changeFeildPo;
                        }).collect(Collectors.toList());
            }
        } else if (MaxwellConst.DELETE.equals(type)) {
            //没有old
            //do nothing
        } else {
            //table-create/table-alter
            //ddl不做处理
            //do nothing
        }
        return List.of();
    }

}
