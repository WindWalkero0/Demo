package com.ruihe.admin.request;

import com.ruihe.common.annotation.Update;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author LiangYuan
 * @date 2021-03-24 15:46
 */
@ApiModel(value = "SatImportDetailRequest", description = "调研问卷详情请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class SatImportDetailRequest implements Serializable {

    @NotNull(message = "问卷编号不能为空", groups = {Update.class})
    @ApiModelProperty(value = "问卷编号")
    private String planNo;

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
