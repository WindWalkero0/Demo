package com.ruihe.admin.listener.report.core;

import lombok.Getter;

import java.util.List;
import java.util.Objects;

@Getter
public class Column {
    /**
     * 报表列标题显示内容
     */
    private final String label;

    /**
     * 列名称，和数据库返回对象中的字段名要一致
     */
    private final String name;

    /**
     * 前缀，用于构建查询语句时添加别名前缀
     */
    private final String prefix;

    /**
     * 字段在select中的表示
     */
    private final String select;

    /**
     * 字段在group by 中的表示
     * 对于相关联的字段，比如counter_id，counter_name，group统一用counter_id
     */
    private final String group;

    /**
     * 是否需要在报表中显示，比如分类编号基本都是不需要显示的
     */
    private final boolean show;

    private final boolean autoCalculate;


    /**
     * 字段类型，生成默认数据时用到
     */
    private final Class<?> type;

    /**
     * 该列不直接从数据库查询，需要依赖deps中的列计算得到
     */
    private List<Column> deps;

    /**
     * 计算deps列的函数
     */
    private CalculateFunc calculateFunc;

    public Column(String label, String name, String select, String group) {
        this.label = label;
        this.name = name;
        this.select = select;
        this.group = group;
        this.type = String.class;
        this.prefix = "";
        this.show = true;
        this.autoCalculate = true;
    }

    public Column(String label, boolean show, String name, String select, String group) {
        this.label = label;
        this.name = name;
        this.select = select;
        this.group = group;
        this.type = String.class;
        this.show = show;
        this.autoCalculate = true;
        this.prefix = "";
    }

    public Column(String label, String name, Class<?> type) {
        this.label = label;
        this.name = name;
        this.type = type;
        this.prefix = "";
        this.select = "";
        this.group = "";
        this.show = true;
        this.autoCalculate = true;
    }

    public Column(String label, String name, Class<?> type, boolean show) {
        this.label = label;
        this.name = name;
        this.type = type;
        this.prefix = "";
        this.select = "";
        this.group = "";
        this.show = show;
        this.autoCalculate = true;
    }

    public Column(String label, String name, boolean show, Class<?> type) {
        this.label = label;
        this.name = name;
        this.type = type;
        this.prefix = "";
        this.select = "";
        this.group = "";
        this.show = show;
        this.autoCalculate = true;
    }

    public Column(String label, String name, String select, Class<?> type) {
        this.label = label;
        this.name = name;
        this.select = select;
        this.type = type;
        this.prefix = "";
        this.group = "";
        this.show = true;
        this.autoCalculate = true;
    }

    public Column(String label, String name, String prefix, String select, String group, boolean show, Class<?> type, List<Column> deps, CalculateFunc calculateFunc) {
        this.label = label;
        this.name = name;
        this.prefix = prefix;
        this.select = select;
        this.group = group;
        this.show = show;
        this.type = type;
        this.deps = deps;
        this.calculateFunc = calculateFunc;
        this.autoCalculate = true;
    }

    public Column dep(Column... column) {
        deps = List.of(column);
        return this;
    }

    public Column calculateFunc(CalculateFunc fun) {
        this.calculateFunc = fun;
        return this;
    }

    public Column show(boolean show) {
        if (show) return this;
        return new Column(this.label, this.name, prefix, this.select, this.group, false, this.type, this.deps, this.calculateFunc);
    }

    /**
     * 加上前缀,别名,这里必须复制一份对象出来，因为在ColumnDefine中定义的column是全局公用的
     */
    public Column p(String prefix) {
        return new Column(this.label, this.name, prefix, this.select, this.group, this.show, this.type, this.deps, this.calculateFunc);
    }

    /**
     * 加上a.前缀,对应sql里的别名
     */
    public Column pa() {
        return p("a.");
    }

    public Column pb() {
        return p("b.");
    }

    /**
     * 是否是时间列
     */
    public boolean isTimeColumn() {
        return "time".equals(name);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Column)) {
            return false;
        }
        Column right = (Column) obj;
        return this.name.equals(right.name)
                && this.label.equals(right.label)
                //&& this.select.equals(right.select)
                && this.group.equals(right.group);
    }

    @Override
    public int hashCode() {
        return Objects.hash(label, name, prefix, select, group, type);
    }

    @Override
    public String toString() {
        return "Column{" +
                "label='" + label + '\'' +
                ", name='" + name + '\'' +
                ", prefix='" + prefix + '\'' +
                ", select='" + select + '\'' +
                ", group='" + group + '\'' +
                ", show=" + show +
                ", type=" + type +
                ", deps=" + deps +
                ", calculateFunc=" + calculateFunc +
                '}';
    }
}
