package com.ruihe.admin.listener.report.utils;

import java.lang.management.ManagementFactory;

public class TimeUsed {
    private long start = System.currentTimeMillis();

    private long last = System.currentTimeMillis();

    public void used() {
        used("");
    }

    public void used(String desc) {
        if (!desc.equals("")) {
            desc = desc + " ";
        }
        long now = System.currentTimeMillis();
        System.out.println(desc + "used: " + (now - last)
                + " pid " + ManagementFactory.getRuntimeMXBean().getPid()
                + " free: " + Runtime.getRuntime().freeMemory() / (1024 * 1024) + "mb"
                + " used " + ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed() / (1024 * 1024)
        );
        last = now;
    }

    public void end() {
        long now = System.currentTimeMillis();
        System.out.println("total used: " + (now - start)
                + " pid " + ManagementFactory.getRuntimeMXBean().getPid()
                + " free: " + Runtime.getRuntime().freeMemory() / (1024 * 1024) + "mb"
                + " used " + ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed() / (1024 * 1024)
        );
    }
}
