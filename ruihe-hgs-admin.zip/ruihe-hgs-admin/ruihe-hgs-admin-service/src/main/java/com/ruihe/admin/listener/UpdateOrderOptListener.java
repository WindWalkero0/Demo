package com.ruihe.admin.listener;


import com.ruihe.admin.service.erp.report.PrdSalesRecordService;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.UpdateOrderOptEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;


@Ella(Describe = "更新订单中的组织结构", Author = "fly")
@Slf4j
@Component
public class UpdateOrderOptListener {

    @Autowired
    private PrdSalesRecordService prdSalesRecordService;

    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(UpdateOrderOptEvent event) {
        try {
            prdSalesRecordService.updateOrderOpt(event.getCounterId());
        } catch (Exception e) {
            log.error("根据柜台修改组织结构.error,counterId={}", event.getCounterId(), e);
        }
    }

}
