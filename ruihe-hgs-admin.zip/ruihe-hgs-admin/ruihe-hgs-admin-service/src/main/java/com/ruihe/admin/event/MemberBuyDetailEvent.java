package com.ruihe.admin.event;

import com.ruihe.common.pojo.request.order.OrderRequest;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MemberBuyDetailEvent extends BiReportEvent {

    private OrderRequest orderRequest;

    public MemberBuyDetailEvent() {

    }
    public MemberBuyDetailEvent(OrderRequest orderRequest) {
        this.orderRequest = orderRequest;
    }
}
