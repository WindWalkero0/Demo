package com.ruihe.admin.listener.style;

import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.write.merge.AbstractMergeStrategy;
import com.google.common.collect.Maps;
import com.ruihe.admin.listener.report.core.TableDefine;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;

import java.util.Map;

/**
 * 合并单元格，自动合并列相同的单元格
 * 注意，右边合并的单元格行数必须小于左边合并的行数
 */
@Slf4j
public class CellMergeStrategy extends AbstractMergeStrategy {
    private final TableDefine define;

    /**
     * key 为列Index
     */
    private final Map<Integer, MergeCell> colMergeMap = Maps.newHashMap();

    /**
     * key 为列Index, value 为行Index
     * 存在map中的行列说明已经合并过
     */
    private final Map<Integer, Integer> mergedMap = Maps.newHashMap();

    private int maxColumn = 0;

    private static class MergeCell {
        int startRowIndex;
        String value;

        MergeCell(int rowIndex, String value) {
            this.startRowIndex = rowIndex;
            this.value = value;
        }
    }

    public CellMergeStrategy(TableDefine define) {
        this.define = define;
        this.maxColumn = define.horizontalDisplayColumns().size();
    }

    @Override
    protected void merge(Sheet sheet, Cell cell, Head head, Integer relativeRowIndex) {
        if (cell.getColumnIndex() >= maxColumn) {
            return;
        }

        int curColumnIndex = cell.getColumnIndex();
        int curRowIndex = cell.getRowIndex();
        String cellValue = getObject(cell);

        if (!colMergeMap.containsKey(curColumnIndex)) {
            colMergeMap.put(curColumnIndex, new MergeCell(curRowIndex, cellValue));
            return;
        }

        MergeCell mergeCell = colMergeMap.get(curColumnIndex);
        int startRow = mergeCell.startRowIndex;

        // 不可能执行到
        if (curRowIndex <= startRow) {
            log.error("fuck " + curRowIndex + " " + startRow + " " + mergeCell.value);
            return;
        }

        // 当前行数据和上一行不一样，并且和起始行相差一行，说明只有一行数据不一样，不需要合并
        if (!cellValue.equals(mergeCell.value) && curRowIndex - startRow == 1) {
            colMergeMap.put(curColumnIndex, new MergeCell(curRowIndex, cellValue));
            mergedMap.put(curColumnIndex, curRowIndex - 1);
            return;
        }

        // 当前行数据和上一行不一样，并且和起始行相差大于一行
        if (!cellValue.equals(mergeCell.value) && curRowIndex - startRow > 1) {
            int endRowIndex = curRowIndex - 1;
            CellRangeAddress rangeAddress = new CellRangeAddress(startRow, endRowIndex, curColumnIndex, curColumnIndex);
            sheet.addMergedRegionUnsafe(rangeAddress);
            colMergeMap.put(curColumnIndex, new MergeCell(curRowIndex, cellValue));
            mergedMap.put(curColumnIndex, endRowIndex);
            return;
        }

        // 右边合并的单元格行数必须小于左边合并的行数
        if (cellValue.equals(mergeCell.value) && curRowIndex - startRow >= 1) {
            Integer leftEndRow = mergedMap.get(curColumnIndex - 1);
            if (leftEndRow != null && leftEndRow.equals(curRowIndex - 1)) {
                if (curRowIndex - startRow == 1) {
                    colMergeMap.put(curColumnIndex, new MergeCell(curRowIndex, cellValue));
                    mergedMap.put(curColumnIndex, leftEndRow);
                } else {
                    CellRangeAddress rangeAddress = new CellRangeAddress(startRow, leftEndRow, curColumnIndex, curColumnIndex);
                    sheet.addMergedRegionUnsafe(rangeAddress);
                    colMergeMap.put(curColumnIndex, new MergeCell(curRowIndex, cellValue));
                    mergedMap.put(curColumnIndex, leftEndRow);
                }
            }
        }
    }

    /**
     * 获取单元格java对象
     */
    private String getObject(Cell cell) {
        if (cell.getCellType() == CellType.NUMERIC) {
            return String.valueOf(cell.getNumericCellValue());
        }
        return cell.getStringCellValue();
    }
}
