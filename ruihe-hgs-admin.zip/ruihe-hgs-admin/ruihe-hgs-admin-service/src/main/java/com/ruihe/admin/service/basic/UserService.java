package com.ruihe.admin.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.ruihe.admin.mapper.basic.*;
import com.ruihe.admin.mapper.employee.EmployeeFileImportItemMapper;
import com.ruihe.admin.mapper.employee.EmployeeFileImportMapper;
import com.ruihe.admin.po.EmployeeCounterImportPo;
import com.ruihe.admin.po.EmployeeImportPo;
import com.ruihe.admin.po.EmployeesPo;
import com.ruihe.admin.request.*;
import com.ruihe.admin.request.basic.CounterRequest;
import com.ruihe.admin.request.basic.SelectCounterRequest;
import com.ruihe.admin.request.crm.SelectImportNoRequest;
import com.ruihe.admin.vo.*;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.*;
import com.ruihe.common.dao.bean.employee.EmployeeFileImport;
import com.ruihe.common.dao.bean.employee.EmployeeFileImportItem;
import com.ruihe.common.dao.bean.login.UserAccount;
import com.ruihe.common.dao.mapper.DepartmentMapper;
import com.ruihe.common.dao.mapper.UserAccountMapper;
import com.ruihe.common.dao.mapper.UserInformationMapper;
import com.ruihe.common.enums.base.DepartmentEnum;
import com.ruihe.common.enums.base.EmpOptTypeEnum;
import com.ruihe.common.enums.prefix.PrefixEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;
import com.ruihe.common.pojo.response.basic.EmployeeExcelResponse;
import com.ruihe.common.pojo.response.basic.UserRequest;
import com.ruihe.common.response.Response;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.service.CommonService;
import com.ruihe.common.utils.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;
import org.springframework.web.multipart.MultipartFile;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


/**
 * @author 梁远
 * @Description
 * @create 2019-06-13 17:17
 */
@Service
@Slf4j
public class UserService {

    @Autowired
    private UserInformationMapper userMapper;

    @Autowired
    private UserDepartmentMapper userDepartmentMapper;

    @Autowired
    private UserCounterMapper userCounterMapper;

    @Autowired
    private UserConcernMapper userConcernMapper;

    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private DepartmentMapper departmentMapper;

    @Autowired
    private UserAccountMapper userAccountMapper;

    @Autowired
    private AccountRoleMapper accountRoleMapper;

    @Autowired
    private EmployeeOperationMapper employeeOperationMapper;

    @Autowired
    private EmployeeOperationFieldsMapper employeeOperationFieldsMapper;

    @Autowired
    private PositionMapper positionMapper;

    @Autowired
    private EmployeeMapper employeeMapper;

    @Autowired
    private EmployeeCounterMapper employeeCounterMapper;

    @Autowired
    private EmployeeFileImportMapper employeeFileImportMapper;

    @Autowired
    private EmployeeFileImportItemMapper employeeFileImportItemMapper;

    private static final List<Integer> pros = List.of(0, 1, 2, 3, 4, 5);

    /**
     * 添加用户
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addUser(UserInfoRequest request) throws Exception {
        //判断手机号、身份证号信息
        String result = dealUserInformation(request);
        if (result != null) {
            return Response.errorMsg(result);
        }
        //设置用户的id
        String uid = IdGenerator.getRandomId(PrefixEnum.EMP.getCode(), 6);
        UserInformation userInformation = new UserInformation();
        //判断人员账号是否已存在
        UserAccountRequest userAccountRequest = request.getUserAccountRequest();
        if (userAccountRequest != null) {
            String msg = dealUserAccount(userAccountRequest, uid);
            if (msg != null) {
                return Response.errorMsg(msg);
            }
            //进行数据保存
            UserAccount account = this.extractUserAccount(userAccountRequest, uid, null);
            Integer rows = userAccountMapper.insert(account);
            if (rows == 0) {
                log.error("添加到用户信息失败,account={}", account);
                throw new BizException("添加到用户信息失败");
            }
            //进行角色权限添加
            AccountRole accountRole = this.extractAccountRole(uid, request.getName());
            rows = accountRoleMapper.insert(accountRole);
            if (rows == 0) {
                log.error("添加到用户信息失败,accountRole={}", accountRole);
                throw new BizException("添加到用户信息失败");
            }
            userInformation.setAccount(account.getAccount());
            userInformation.setAccountStatus(account.getStatus());
        }
        //将用户信息添加到用户信息表中
        BeanUtils.copyProperties(request, userInformation);
        //将数据保存到userInformation表中
        userInformation.setEmpId(uid);
        userInformation.setStatus(CommonStatusEnum.EFFECTIVE.getCode());
        userInformation.setCreateTime(LocalDateTime.now());
        userInformation.setUpdateTime(LocalDateTime.now());
        Integer rows = userMapper.insert(userInformation);
        if (rows == 0) {
            log.error("添加到用户信息失败,userInformation={}", userInformation);
            throw new BizException("添加到用户信息失败");
        }
        //将数据复制到修改履历表中
        UserInformationOptVo optVo = new UserInformationOptVo();
        BeanUtils.copyProperties(userInformation, optVo);
        doOpt(null, optVo, EmpOptTypeEnum.ADD.getKey(), userInformation.getEmpId(), userInformation.getName());
        //添加管理部门
        List<UserDepartmentRequest> departmentList = request.getDepartmentList();
        if (!org.springframework.util.ObjectUtils.isEmpty(departmentList)) {
            List<UserDepartment> list = departmentList.stream().map(e -> {
                UserDepartment userDepartment = new UserDepartment();
                BeanUtils.copyProperties(e, userDepartment);
                userDepartment.setEmpId(uid);
                userDepartment.setName(request.getName());
                userDepartment.setCreateTime(LocalDateTime.now());
                userDepartment.setUpdateTime(LocalDateTime.now());
                return userDepartment;
            }).collect(Collectors.toList());
            //批量插入
            rows = userDepartmentMapper.batchInsert(list);
            if (rows != list.size()) {
                log.error("添加部门失败list={}", list);
                throw new BizException("添加部门失败");
            }
        }
        //工作柜台信息
        List<UserCounterRequest> counterList = request.getCounterList();
        if (!org.springframework.util.ObjectUtils.isEmpty(counterList)) {
            List<UserCounter> list = counterList.stream().map(e -> {
                UserCounter counter = new UserCounter();
                BeanUtils.copyProperties(e, counter);
                counter.setEmpId(uid);
                counter.setName(request.getName());
                counter.setPhoneNo(request.getPhoneNo());
                counter.setCreateTime(LocalDateTime.now());
                counter.setUpdateTime(LocalDateTime.now());
                return counter;
            }).collect(Collectors.toList());
            rows = userCounterMapper.batchInsert(list);
            if (rows != counterList.size()) {
                log.error("添加到用户信息失败,list={}", list);
                throw new BizException("添加到用户信息失败!");
            }
        }
        //关注部门信息
        List<UserConcernRequest> userConcernList = request.getUserConcernList();
        if (!org.springframework.util.ObjectUtils.isEmpty(userConcernList)) {
            List<UserConcernPo> concernList = this.extractUserConcern(userConcernList, uid);
            rows = userConcernMapper.batchInsert(concernList);
            if (rows != userConcernList.size()) {
                log.error("关注部门信息,添加到用户信息失败!List={}", userConcernList);
                throw new BizException("关注部门信息,添加到用户信息失败!");
            }
        }
        return Response.successMsg("添加用户成功!");
    }

    /**
     * 员工修改履历---新增和编辑
     *
     * @param before
     * @param after
     * @param type
     * @param empId
     * @param empName
     */
    private void doOpt(UserInformationOptVo before, UserInformationOptVo after, Integer type, String empId, String empName) throws Exception {
        String optId = IdGenerator.getRandomId(PrefixEnum.EO.getCode(), 8);
        List<EmployeeOperationFields> list = new ArrayList<>();
        //根据操作类型进行分类
        if (type.equals(EmpOptTypeEnum.ADD.getKey())) {
            //如果是新增的，那么修改前的数据全部为空，只需要将修改后的数据加入
            Class<?> afterClazz = after.getClass();
            //获取对象的属性列表
            Field[] afterFields = afterClazz.getDeclaredFields();
            for (Field field : afterFields) {
                field.setAccessible(true);
                Object afterValue = field.get(after);
                if (!org.springframework.util.ObjectUtils.isEmpty(afterValue)) {
                    EmployeeOperationFields operationFields = EmployeeOperationFields.builder()
                            .optId(optId)
                            .empId(empId)
                            .field(field.getAnnotation(ApiModelProperty.class).value())
                            .fieldAfter(field.get(after) == null ? null : field.get(after).toString())
                            .build();
                    list.add(operationFields);
                }
            }
            //此处list不会为空，但是为了以防万一，还是判断一下
            if (!list.isEmpty()) {
                //保存主表信息
                EmployeeOperation employeeOperation = extractEmployeeOperation(type, optId, empId, empName);
                Integer rows = employeeOperationMapper.insert(employeeOperation);
                if (rows != 1) {
                    log.error("新增用户修改履历失败!employeeOperation={}", employeeOperation);
                    throw new BizException("新增用户修改履历失败!");
                }
                //最后进行批量插入操作
                rows = employeeOperationFieldsMapper.batchInsert(list);
                if (rows != list.size()) {
                    log.error("新增用户修改履历失败!list={}", list);
                    throw new BizException("新增用户修改履历失败!");
                }
            }
        } else {
            //如果是修改的，则需要进行数据对比
            Class<?> beforeClazz = before.getClass();
            Class<?> afterClazz = after.getClass();
            //获取对象的属性列表
            Field[] beforeFields = beforeClazz.getDeclaredFields();
            Field[] afterFields = afterClazz.getDeclaredFields();
            for (Field beforeField : beforeFields) {
                for (Field afterField : afterFields) {
                    //如果属性名与属性名内容相同
                    if (beforeField.getName().equals(afterField.getName())) {
                        afterField.setAccessible(true);
                        beforeField.setAccessible(true);
                        //如果属性值内容不相同
                        if (!compareTwo(beforeField.get(before), afterField.get(after))) {
                            EmployeeOperationFields operationFields = EmployeeOperationFields.builder()
                                    .optId(optId)
                                    .empId(empId)
                                    .field(afterField.getAnnotation(ApiModelProperty.class).value())
                                    .fieldBefore(beforeField.get(before) == null ? null : beforeField.get(before).toString())
                                    .fieldAfter(afterField.get(after) == null ? null : afterField.get(after).toString())
                                    .build();
                            list.add(operationFields);
                        }
                        break;
                    }
                }
            }
            //对list进行判空，防止前后端传的空值不一致
            if (!list.isEmpty()) {
                //保存主表信息
                EmployeeOperation employeeOperation = extractEmployeeOperation(type, optId, empId, empName);
                Integer rows = employeeOperationMapper.insert(employeeOperation);
                if (rows != 1) {
                    log.error("修改用户修改履历失败!employeeOperation={}", employeeOperation);
                    throw new BizException("修改用户修改履历失败!");
                }
                //最后进行批量插入操作
                rows = employeeOperationFieldsMapper.batchInsert(list);
                if (rows != list.size()) {
                    log.error("修改用户修改履历失败!list={}", list);
                    throw new BizException("修改用户修改履历失败!");
                }
            }
        }
    }

    /**
     * 员工修改履历主表
     *
     * @param type
     * @param optId
     * @param empId
     * @param empName
     * @return
     */
    private EmployeeOperation extractEmployeeOperation(Integer type, String optId, String empId, String empName) {
        return EmployeeOperation.builder()
                .optId(optId)
                .empId(empId)
                .empName(empName)
                .optEmpId(AdminUserContextHolder.get().getEmpId())
                .optEmpName(AdminUserContextHolder.get().getName())
                .type(type)
                .createTime(LocalDateTime.now())
                .build();
    }

    /**
     * 员工修改履历---状态
     *
     * @param before
     * @param after
     * @param type
     * @param empId
     * @param empName
     */
    private void doOptStatus(Integer before, Integer after, Integer type, String empId, String empName) {
        String optId = IdGenerator.getRandomId(PrefixEnum.EO.getCode(), 8);
        EmployeeOperation employeeOperation = EmployeeOperation.builder()
                .optId(optId)
                .empId(empId)
                .empName(empName)
                .optEmpId(AdminUserContextHolder.get().getEmpId())
                .optEmpName(AdminUserContextHolder.get().getName())
                .type(type)
                .createTime(LocalDateTime.now())
                .build();
        //插入到数据库
        Integer rows = employeeOperationMapper.insert(employeeOperation);
        if (rows != 1) {
            log.error("修改用户修改履历失败!employeeOperation={}", employeeOperation);
            throw new BizException("修改用户修改履历失败!");
        }
        EmployeeOperationFields operationFields = EmployeeOperationFields.builder()
                .optId(optId)
                .empId(empId)
                .field("状态")
                .fieldBefore(CommonStatusEnum.instance(before).getMsg())
                .fieldAfter(CommonStatusEnum.instance(after).getMsg())
                .build();
        rows = employeeOperationFieldsMapper.insert(operationFields);
        if (rows != 1) {
            log.error("修改用户修改履历失败!operationFields={}", operationFields);
            throw new BizException("修改用户修改履历失败!");
        }
    }

    /**
     * 对比两个数据是否内容相同
     *
     * @param before
     * @param after
     * @return
     */
    private boolean compareTwo(Object before, Object after) {

        if (org.springframework.util.ObjectUtils.isEmpty(before) && org.springframework.util.ObjectUtils.isEmpty(after)) {
            return true;
        }
        if (org.springframework.util.ObjectUtils.isEmpty(before) && !org.springframework.util.ObjectUtils.isEmpty(after)) {
            return false;
        }
        if (before.equals(after)) {
            return true;
        }
        return false;
    }

    /**
     * 构建用户关注部门信息
     *
     * @param userConcernList
     * @param uid
     * @return
     */
    private List<UserConcernPo> extractUserConcern(List<UserConcernRequest> userConcernList, String uid) {
        return userConcernList.stream().map(e -> {
            UserConcernPo userConcernPo = new UserConcernPo();
            BeanUtils.copyProperties(e, userConcernPo);
            userConcernPo.setEmpId(uid);
            userConcernPo.setCreateTime(LocalDateTime.now());
            userConcernPo.setUpdateTime(LocalDateTime.now());
            return userConcernPo;
        }).collect(Collectors.toList());
    }

    /**
     * 新增/编辑状态下判断手机号和身份证号信息是否合法
     *
     * @param request
     * @return
     */
    private String dealUserInformation(UserInfoRequest request) {
        //判断员工姓名
        if (StringUtils.isBlank(request.getName())) {
            return "员工姓名不能为空!";
        }
        //判断手机号规则
        if (StringUtils.isBlank(request.getPhoneNo())) {
            return "手机号不能为空!";
        }
        if (!request.getPhoneNo().matches(RegularUtil.REGEX_MOBILE)) {
            return "手机号不合法!";
        }
        //判断电话重复
        LambdaQueryWrapper<UserInformation> phoneQuery = Wrappers.<UserInformation>lambdaQuery()
                .eq(UserInformation::getPhoneNo, request.getPhoneNo())
                .eq(UserInformation::getStatus, CommonStatusEnum.EFFECTIVE.getCode());
        if (StringUtils.isNotBlank(request.getEmpId())) {
            phoneQuery.ne(UserInformation::getEmpId, request.getEmpId());
        }
        Integer count = userMapper.selectCount(phoneQuery);
        if (count > 0) {
            return "手机号码重复!";
        }
        //判断身份证号
        if (StringUtils.isBlank(request.getIdCard())) {
            return "身份证号不能为空!";
        }
        if (!request.getIdCard().matches(RegularUtil.REGEX_IDCARD)) {
            return "身份证号不合法!";
        }
        //判断身份证号重复
        LambdaQueryWrapper<UserInformation> queryWrapper = Wrappers.<UserInformation>lambdaQuery()
                .eq(UserInformation::getIdCard, request.getIdCard())
                .eq(UserInformation::getStatus, CommonStatusEnum.EFFECTIVE.getCode());
        if (StringUtils.isNotBlank(request.getEmpId())) {
            queryWrapper.ne(UserInformation::getEmpId, request.getEmpId());
        }
        count = userMapper.selectCount(queryWrapper);
        if (count > 0) {
            return "身份证号重复!";
        }
        return null;
    }

    /**
     * 构建用户角色权限信息
     *
     * @param uid
     * @param name
     * @return
     */
    private AccountRole extractAccountRole(String uid, String name) {
        //获取默认权限--uid为0
        //返回角色权限信息
        return AccountRole.builder()
                .userUid(uid)
                .userName(name)
                .status(StatusEnum.UN_DELETED.getKey())
                //此处直接从数据库拿来写死的
                .roleUid(CommonConstant.ROLE_ID)
                .roleName(CommonConstant.ROLE_NAME)
                .build();
    }

    /**
     * 处理登录账号问题
     *
     * @param request
     * @param uid
     * @return
     */
    private String dealUserAccount(UserAccountRequest request, String uid) {
        //账号不能为空
        if (StringUtils.isBlank(request.getAccount())) {
            return "账号不能为空!";
        }
        //根据用户id查询账号信息是否存在
        UserAccount account = userAccountMapper.selectOne(Wrappers.<UserAccount>lambdaQuery()
                .eq(UserAccount::getAccount, request.getAccount())
                .eq(UserAccount::getUserId, uid));
        //如果根据用户的id和账号未查询到账号信息，说明是新增的,需要对信息进行判空
        if (account == null) {
            //判断是否已存在
            UserAccount userAccount = userAccountMapper.selectOne(Wrappers.<UserAccount>lambdaQuery()
                    .eq(UserAccount::getAccount, request.getAccount())
                    .ne(UserAccount::getUserId, uid));
            if (userAccount != null) {
                return "账号已存在!";
            }
            if (StringUtils.isBlank(request.getPassword())) {
                return "密码不能为空!";
            }
            if (StringUtils.isBlank(request.getCurrentId())) {
                return "当前登录人员账号不能为空!";
            }
            if (StringUtils.isBlank(request.getCurrentPassword())) {
                return "当前登录人员密码不能为空!";
            }
        }
        //判断当前登录账号的账号密码
        UserAccount currentAccount = userAccountMapper.selectOne(Wrappers.<UserAccount>lambdaQuery()
                .eq(UserAccount::getUserId, request.getCurrentId()));
        if (currentAccount == null) {
            return "当前账号不存在!";
        }
        //进行密码比对
        if (StringUtils.isNotBlank(request.getCurrentPassword()) && !currentAccount.getPassword().equals(DigestUtils.md5DigestAsHex(request.getCurrentPassword().getBytes(CommonConstant.UTF_8)))) {
            return "当前账号密码错误!";
        }
        return null;
    }

    /**
     * 构建账号信息
     *
     * @param request
     * @param uid
     * @param status  用户的状态/账号的状态
     * @return
     */
    private UserAccount extractUserAccount(UserAccountRequest request, String uid, Integer status) {
        UserAccount userAccount = UserAccount.builder()
                .account(request.getAccount())
                .password(DigestUtils.md5DigestAsHex(request.getPassword().getBytes(CommonConstant.UTF_8)))
                .userId(uid)
                .createId(request.getCurrentId())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
        //如果传来的状态不为空且为无效，则将用户账号设置为无效，否则按照传来的账号的状态进行设置
        if (status != null && status.equals(CommonStatusEnum.INVALID.getCode())) {
            userAccount.setStatus(status);
        } else {
            userAccount.setStatus(request.getAccountStatus() == null ? CommonStatusEnum.EFFECTIVE.getCode() : request.getAccountStatus());
        }
        return userAccount;
    }

    /**
     * 批量修改用户状态
     *
     * @param empIdList
     * @param status
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response updateUserStatus(List<String> empIdList, Integer status) throws BizException {
        if (org.springframework.util.ObjectUtils.isEmpty(empIdList)) {
            return Response.errorMsg("请选择员工!");
        }
        if (status == null) {
            return Response.errorMsg("未选择状态信息!");
        }
        if (!status.equals(CommonStatusEnum.EFFECTIVE.getCode()) && !status.equals(CommonStatusEnum.INVALID.getCode())) {
            return Response.errorMsg("状态错误!");
        }
        //查询所有员工的信息
        List<UserInformation> userInformationList = userMapper.selectList(Wrappers.<UserInformation>lambdaQuery()
                .in(UserInformation::getEmpId, empIdList));
        //根据状态进行过滤
        long sum = userInformationList.stream().filter(e -> e.getStatus().equals(status)).count();
        if (sum == empIdList.size()) {
            return Response.successMsg("已经修改用户状态!");
        }
        if (sum != 0) {
            return Response.errorMsg("所选员工有效区分状态不一致!");
        }
        //如果是启用的话，对手机号和身份证号进行判断
        if (status.equals(CommonStatusEnum.EFFECTIVE.getCode())) {
            //获取手机号列表
            List<String> phoneNoList = userInformationList.stream().map(UserInformation::getPhoneNo).collect(Collectors.toList());
            if (!phoneNoList.isEmpty()) {
                //查询已启用的，不是当前idList中的员工是否使用了手机号
                List<UserInformation> userPhoneNoList = userMapper.selectList(Wrappers.<UserInformation>lambdaQuery()
                        .notIn(UserInformation::getEmpId, empIdList)
                        .in(UserInformation::getPhoneNo, phoneNoList)
                        .eq(UserInformation::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
                if (!userPhoneNoList.isEmpty()) {
                    return Response.errorMsg("员工手机号与已启用的员工手机号重复!");
                }
            }
            //获取身份证号列表
            List<String> idCardList = userInformationList.stream().map(UserInformation::getIdCard).collect(Collectors.toList());
            if (!idCardList.isEmpty()) {
                List<UserInformation> userIdCardList = userMapper.selectList(Wrappers.<UserInformation>lambdaQuery()
                        .notIn(UserInformation::getEmpId, empIdList)
                        .in(UserInformation::getIdCard, idCardList)
                        .eq(UserInformation::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
                if (!userIdCardList.isEmpty()) {
                    return Response.errorMsg("员工身份证号与已启用的员工身份证号重复!");
                }
            }
        } else {
            //如果停用了员工，则将员工柜台表中数据删除
            Integer count = userCounterMapper.selectCount(Wrappers.<UserCounter>lambdaQuery()
                    .in(UserCounter::getEmpId, empIdList));
            if (count != 0) {
                Integer rows = userCounterMapper.delete(Wrappers.<UserCounter>lambdaQuery()
                        .in(UserCounter::getEmpId, empIdList));
                if (!rows.equals(count)) {
                    log.error("批量删除员工柜台表中数据失败!empIdList={}", empIdList);
                    throw new BizException("批量修改用户状态失败!");
                }
            }
        }
        for (UserInformation userInformation : userInformationList) {
            if (userInformation.getStatus().equals(status)) {
                continue;
            }
            doOptStatus(userInformation.getStatus(), status, EmpOptTypeEnum.EDIT.getKey(), userInformation.getEmpId(), userInformation.getName());
        }
        //构建员工状态修改
        UserInformation userInformation = UserInformation.builder().status(status).accountStatus(status).updateTime(LocalDateTime.now()).build();
        Integer update = userMapper.update(userInformation, Wrappers.<UserInformation>lambdaUpdate().in(UserInformation::getEmpId, empIdList));
        if (update != empIdList.size()) {
            log.error("批量修改用户状态失败!empIdList={}", empIdList);
            throw new BizException("批量修改用户状态失败!");
        }
        //更新柜台信息
        Integer count = counterMapper.selectCount(Wrappers.<CounterInformation>lambdaQuery().in(CounterInformation::getPrincipalEmpId, empIdList));
        if (count != 0) {
            //批量修改柜台相关
            CounterInformation counterInformation = CounterInformation.builder()
                    .principalEmpStatus(status)
                    .updateTime(LocalDateTime.now()).build();
            update = counterMapper.update(counterInformation, Wrappers.<CounterInformation>lambdaUpdate().in(CounterInformation::getPrincipalEmpId, empIdList));
            if (!update.equals(count)) {
                log.error("更新柜台信息,更新状态失败!counterInformation={}", counterInformation);
                throw new BizException("更新柜台信息,更新状态失败!");
            }
        }
        //更新账号信息
        count = userAccountMapper.selectCount(Wrappers.<UserAccount>lambdaQuery().in(UserAccount::getUserId, empIdList));
        if (count != 0) {
            UserAccount userAccount = UserAccount.builder()
                    .status(status)
                    .updateTime(LocalDateTime.now())
                    .build();
            update = userAccountMapper.update(userAccount, Wrappers.<UserAccount>lambdaUpdate().in(UserAccount::getUserId, empIdList));
            if (!update.equals(count)) {
                log.error("更新账号信息,更新状态失败!userAccount={}", userAccount);
                throw new BizException("更新账号信息,更新状态失败!");
            }
        }
        return Response.successMsg("已经修改用户状态!");
    }

    /**
     * 根据条件查询用户
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response queryUser(UserRequest request) {
        PageHelper.startPage(request.getPageNumber(), request.getPageSize());
        //根据条件查询用户信息
        if (request.getCreateTimeEnd() != null) {
            request.setCreateTimeEnd(request.getCreateTimeEnd().plusDays(1));
        }
        if (request.getUpdateTimeEnd() != null) {
            request.setUpdateTimeEnd(request.getUpdateTimeEnd().plusDays(1));
        }
        List<EmployeePo> userInformationList = userMapper.searchUsers(request);
        List<UserInformationVo> collect = userInformationList.parallelStream().map(userInformation -> {
            UserInformationVo userInformationVo = UserInformationVo.builder().build();
            BeanUtils.copyProperties(userInformation, userInformationVo);
            return userInformationVo;
        }).collect(Collectors.toList());
        //组装分页信息
        PageInfo<UserInformationVo> pageInfo = new PageInfo<>(collect);
        Integer total = userMapper.searchUsersCount(request);
        pageInfo.setTotal(total);
        return userInformationList.isEmpty() ? Response.successMsg("暂无数据") : Response.success(pageInfo);
    }


    /**
     * 员工信息excel
     *
     * @param request
     * @return com.ruihe.common.response.Response
     * @author huangjie
     * @date 2021/6/16 9:57
     */
    @DS(DBConst.SLAVE)
    public Response exportEmployee(UserRequest request) {
        //根据条件查询用户信息
        if (request.getCreateTimeEnd() != null) {
            request.setCreateTimeEnd(request.getCreateTimeEnd().plusDays(1));
        }
        if (request.getUpdateTimeEnd() != null) {
            request.setUpdateTimeEnd(request.getUpdateTimeEnd().plusDays(1));
        }
        List<EmployeePos> userInformationList = userMapper.searchUserss(request);
        List<EmployeeExcelResponse> excelResponseList = ObjectUtils.toList(userInformationList, EmployeeExcelResponse.class);
        return Response.success(excelResponseList);
    }


    /**
     * 根据ID返回用户详情
     *
     * @param empId
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectUserById(String empId) {
        LambdaQueryWrapper<UserInformation> queryWrapper = Wrappers.<UserInformation>lambdaQuery().eq(UserInformation::getEmpId, empId);
        //用户的信息
        UserInformation userInformation = userMapper.selectOne(queryWrapper);
        UserInformationVo userInformationVo = new UserInformationVo();
        BeanUtils.copyProperties(userInformation, userInformationVo);
        //用户的管辖部门信息
        LambdaQueryWrapper<UserDepartment> queryDept = Wrappers.<UserDepartment>lambdaQuery().eq(UserDepartment::getEmpId, empId);
        List<UserDepartment> departmentList = userDepartmentMapper.selectList(queryDept);
        if (!departmentList.isEmpty()) {
            userInformationVo.setDepartmentList(ObjectUtils.toList(departmentList, UserDepartmentVo.class));
        }
        //工作柜台
        LambdaQueryWrapper<UserCounter> queryCounter = Wrappers.<UserCounter>lambdaQuery().eq(UserCounter::getEmpId, empId);
        List<UserCounter> counterList = userCounterMapper.selectList(queryCounter);
        if (!counterList.isEmpty()) {
            userInformationVo.setCounterList(ObjectUtils.toList(counterList, UserCounterVo.class));
        }
        //关注部门
        List<UserConcernPo> concernPoList = userConcernMapper.selectList(Wrappers.<UserConcernPo>lambdaQuery().eq(UserConcernPo::getEmpId, empId));
        if (!concernPoList.isEmpty()) {
            userInformationVo.setUserConcernVoList(ObjectUtils.toList(concernPoList, UserConcernVo.class));
        }
        return Response.success(userInformationVo);
    }

    /**
     * 用户信息编辑保存
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response updateUser(UserInfoRequest request) throws Exception {
        //判断手机号、身份证号信息
        String result = dealUserInformation(request);
        if (result != null) {
            return Response.errorMsg(result);
        }
        //判断用户账号
        UserAccountRequest userAccountRequest = request.getUserAccountRequest();
        UserInformation userInformation = new UserInformation();
        //查询该用户之前的信息，用于判断
        UserInformation userInformationOld = userMapper.selectOne(Wrappers.<UserInformation>lambdaQuery()
                .eq(UserInformation::getEmpId, request.getEmpId()));
        if (userAccountRequest != null) {
            String msg = dealUserAccount(userAccountRequest, request.getEmpId());
            if (msg != null) {
                return Response.errorMsg(msg);
            }
            //处理账号信息
            insertOrUpdate(userAccountRequest, request, userInformationOld.getStatus());
            //对用户信息进行处理
            userInformation.setAccount(userAccountRequest.getAccount());
            if (userInformationOld.getStatus().equals(CommonStatusEnum.INVALID.getCode())) {
                userInformation.setAccountStatus(userInformationOld.getStatus());
            } else if (userAccountRequest.getAccountStatus() != null) {
                userInformation.setAccountStatus(userAccountRequest.getAccountStatus());
            } else {
                userInformation.setAccountStatus(CommonStatusEnum.EFFECTIVE.getCode());
            }
        }
        //更新用户信息
        BeanUtils.copyProperties(request, userInformation);
        userInformation.setUpdateTime(LocalDateTime.now());
        //将数据复制到修改履历表中
        UserInformationOptVo optBeforeVo = new UserInformationOptVo();
        BeanUtils.copyProperties(userInformationOld, optBeforeVo);
        //由于在pos端添加的时候，部门中的一些信息可能为空，需要加额外的判断
        if (getFlag(request, userInformationOld)) {
            doUpdateCounterAndDept(request);
        }
        //判断员工姓名是否更改了
        if (request.getName().equals(userInformationOld.getName())) {
            //更新与员工姓名相关的管辖部门、工作柜台中信息
            doEmpName(request);
        }
        //更新保存
        Integer rows = userMapper.update(userInformation, Wrappers.<UserInformation>lambdaUpdate().eq(UserInformation::getEmpId, request.getEmpId()));
        if (rows != 1) {
            log.error("用户更新失败!,userInformation={}", userInformation);
            throw new BizException("用户更新失败!");
        }
        //将数据复制到修改履历表中
        UserInformationOptVo optAfterVo = new UserInformationOptVo();
        BeanUtils.copyProperties(userInformation, optAfterVo);
        if (!optBeforeVo.toString().equals(optAfterVo.toString())) {
            doOpt(optBeforeVo, optAfterVo, EmpOptTypeEnum.EDIT.getKey(), userInformation.getEmpId(), userInformation.getName());
        }
        //对员工管辖部门、关注部门、工作柜台信息进行修改
        doEmpCounterDept(request);
        return Response.successMsg("已经修改用户信息");
    }

    /**
     * 更新与员工姓名相关的管辖部门、工作柜台中信息
     *
     * @param request
     */
    private void doEmpName(UserInfoRequest request) {
        //更新管辖部门
        UserDepartment department = UserDepartment.builder()
                .name(request.getName()).build();
        userDepartmentMapper.update(department, Wrappers.<UserDepartment>lambdaUpdate()
                .eq(UserDepartment::getEmpId, request.getEmpId()));
        //更新工作柜台信息
        UserCounter userCounter = UserCounter.builder().name(request.getName()).build();
        userCounterMapper.update(userCounter, Wrappers.<UserCounter>lambdaUpdate()
                .eq(UserCounter::getEmpId, request.getEmpId()));
    }

    /**
     * 对员工管辖部门、关注部门、工作柜台信息进行修改
     *
     * @param request
     */
    private void doEmpCounterDept(UserInfoRequest request) {
        //更新管辖部门
        List<UserDepartmentRequest> departmentList = request.getDepartmentList();
        //删除管辖部门中的数据
        log.info("删除管辖部门中的数据，员工代号是：" + request.getEmpId());
        Map<String, Object> map = new HashMap<>();
        map.put("emp_id", request.getEmpId());
        userDepartmentMapper.deleteByMap(map);
        if (!org.springframework.util.ObjectUtils.isEmpty(departmentList)) {
            List<UserDepartment> list = departmentList.stream().map(e -> {
                UserDepartment userDepartment = new UserDepartment();
                BeanUtils.copyProperties(e, userDepartment);
                userDepartment.setEmpId(request.getEmpId());
                userDepartment.setName(request.getName());
                userDepartment.setCreateTime(LocalDateTime.now());
                userDepartment.setUpdateTime(LocalDateTime.now());
                return userDepartment;
            }).collect(Collectors.toList());
            Integer rows = userDepartmentMapper.batchInsert(list);
            if (rows != departmentList.size()) {
                log.error("批量插入用户部门数据失败!,list={},effectRows={}", list, rows);
                throw new BizException("批量插入用户部门数据失败!");
            }
        }
        //更新工作柜台信息
        List<UserCounterRequest> counterList = request.getCounterList();
        //删除工作柜台信息
        log.info("删除工作柜台信息中的数据，员工代号是：" + request.getEmpId());
        userCounterMapper.deleteByMap(map);
        if (!org.springframework.util.ObjectUtils.isEmpty(counterList)) {
            List<UserCounter> list = counterList.stream().map(e -> {
                UserCounter counter = new UserCounter();
                BeanUtils.copyProperties(e, counter);
                counter.setEmpId(request.getEmpId());
                counter.setName(request.getName());
                counter.setPhoneNo(request.getPhoneNo());
                counter.setCreateTime(LocalDateTime.now());
                counter.setUpdateTime(LocalDateTime.now());
                return counter;
            }).collect(Collectors.toList());
            Integer rows = userCounterMapper.batchInsert(list);
            if (rows != counterList.size()) {
                log.error("批量插入用户所属柜台失败!,list={},effectRows={}", list, rows);
                throw new BizException("批量插入用户所属柜台失败!");
            }
        }
        //删除关注部门信息
        log.info("删除工关注部门信息中的数据，员工代号是：" + request.getEmpId());
        userConcernMapper.delete(Wrappers.<UserConcernPo>lambdaQuery().eq(UserConcernPo::getEmpId, request.getEmpId()));
        //关注部门信息
        List<UserConcernRequest> userConcernList = request.getUserConcernList();
        if (!org.springframework.util.ObjectUtils.isEmpty(userConcernList)) {
            List<UserConcernPo> concernList = this.extractUserConcern(userConcernList, request.getEmpId());
            Integer rows = userConcernMapper.batchInsert(concernList);
            if (rows != concernList.size()) {
                log.error("批量插入用户关注部门失败!,list={},effectRows={}", concernList, rows);
                throw new BizException("批量插入用户关注部门失败!");
            }
        }
    }

    /**
     * 对部门和柜台信息进行同步更新
     *
     * @param request
     */
    private void doUpdateCounterAndDept(UserInfoRequest request) {
        //查询更新的柜台id
        List<CounterInformation> list = counterMapper.selectList(Wrappers.<CounterInformation>lambdaQuery()
                .select(CounterInformation::getCounterId).eq(CounterInformation::getPrincipalEmpId, request.getEmpId()));
        if (!list.isEmpty()) {
            //获取柜台id的list
            List<String> idList = list.stream().map(CounterInformation::getCounterId).collect(Collectors.toList());
            //部门岗位发生了变化，需要同步修改柜台中信息
            CounterInformation counterInformation = CounterInformation.builder()
                    .principalEmpDeptCode(request.getDeptCode())
                    .principalEmpDeptName(request.getDeptName())
                    .principalEmpPositionCode(request.getPositionCode())
                    .principalEmpPositionName(request.getPositionName())
                    .principalEmpName(request.getName())
                    .updateTime(LocalDateTime.now()).build();
            fillCounterInformation(counterInformation, request);
            Integer rows = counterMapper.update(counterInformation, Wrappers.<CounterInformation>lambdaUpdate()
                    .in(CounterInformation::getCounterId, idList));
            if (rows != idList.size()) {
                log.error("部门岗位发生了变化，需要同步修改柜台中信息,更新失败!counterInformation=" + counterInformation);
                throw new BizException("部门岗位发生了变化，更新失败!");
            }
            //修改部门中的柜台信息
            Department department = Department.builder()
                    .upDeptId(request.getDeptCode())
                    .upDeptName(request.getDeptName())
                    .upDeptType(request.getDeptType())
                    .updateTime(LocalDateTime.now())
                    .build();
            rows = departmentMapper.update(department, Wrappers.<Department>lambdaUpdate().in(Department::getDeptId, idList));
            if (rows != idList.size()) {
                log.error("修改部门中的柜台信息,更新失败!department=" + department);
                throw new BizException("修改部门中的柜台信息,更新失败!");
            }
        }
    }

    /**
     * 根据柜台主管信息设置组织机构
     *
     * @param counterInformation
     * @return
     */
    private void fillCounterInformation(CounterInformation counterInformation, UserInfoRequest request) {
        //先将所有的设置为空
        counterInformation.setOrgMasterId("");
        counterInformation.setOrgMasterName("");
        counterInformation.setOrgOfficeId("");
        counterInformation.setOrgOfficeName("");
        counterInformation.setOrgAreaId("");
        counterInformation.setOrgAreaName("");
        //根据id获取柜台信息
        Department department = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery()
                .eq(Department::getDeptId, request.getDeptCode()));
        //根据部门的类型进行处理
        if (request.getDeptType().equals(DepartmentEnum.COUNTER_SUPERVISOR.getKey())) {
            //如果该部门的类型是柜台主管
            counterInformation.setOrgMasterId(department.getDeptId());
            counterInformation.setOrgMasterName(request.getDeptName());
            //根据上级部门进行查询
            Department updepart = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, department.getUpDeptId()));
            if (updepart.getDeptType().equals(DepartmentEnum.OFFICE.getKey())) {
                counterInformation.setOrgOfficeId(updepart.getDeptId());
                counterInformation.setOrgOfficeName(updepart.getDeptName());
                //根据办事处查询上级部门信息
                Department upDepartment = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, updepart.getUpDeptId()));
                if (upDepartment.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
                    //如果上级部门是大区
                    counterInformation.setOrgAreaId(upDepartment.getDeptId());
                    counterInformation.setOrgAreaName(upDepartment.getDeptName());
                }
            } else if (updepart.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
                counterInformation.setOrgAreaId(updepart.getDeptId());
                counterInformation.setOrgAreaName(updepart.getDeptName());
            }
        } else if (request.getDeptType().equals(DepartmentEnum.OFFICE.getKey())) {
            //如果该部门类型是办事处，设置办事处信息
            counterInformation.setOrgOfficeId(department.getDeptId());
            counterInformation.setOrgOfficeName(request.getDeptName());
            //根据上级部门进行查询
            Department updepart = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, department.getUpDeptId()));
            if (updepart.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
                counterInformation.setOrgAreaId(updepart.getDeptId());
                counterInformation.setOrgAreaName(updepart.getDeptName());
            }
        } else if (request.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
            //如果部门类型是大区，直接设置大区信息
            counterInformation.setOrgAreaId(department.getDeptId());
            counterInformation.setOrgAreaName(request.getDeptName());
        }
    }


    /**
     * 判断用户的部门信息是否发生了改变
     *
     * @param request
     * @param userInformationOld
     * @return
     */
    private boolean getFlag(UserInfoRequest request, UserInformation userInformationOld) {
        if (StringUtils.isNotBlank(userInformationOld.getDeptCode()) && !userInformationOld.getDeptCode().equals(request.getDeptCode())) {
            return true;
        } else if (userInformationOld.getDeptType() != null && !userInformationOld.getDeptType().equals(request.getDeptType())) {
            return true;
        } else if (StringUtils.isNotBlank(userInformationOld.getName()) && !userInformationOld.getName().equals(request.getName())) {
            return true;
        } else if (StringUtils.isNotBlank(userInformationOld.getDeptName()) && !userInformationOld.getDeptName().equals(request.getDeptName())) {
            return true;
        }
        return false;
    }

    /**
     * 对账号进行更新或者新增
     *
     * @param userAccountRequest
     * @param request
     * @throws BizException
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void insertOrUpdate(UserAccountRequest userAccountRequest, UserInfoRequest request, Integer status) throws BizException {
        //根据用户id进行账号查询
        UserAccount account = userAccountMapper.selectOne(Wrappers.<UserAccount>lambdaQuery()
                .eq(UserAccount::getUserId, request.getEmpId()));
        //未查询到账号，说明是新增的
        if (account == null) {
            //进行数据保存
            UserAccount user = this.extractUserAccount(userAccountRequest, request.getEmpId(), status);
            Integer rows = userAccountMapper.insert(user);
            if (rows == 0) {
                log.error("编辑用户信息失败!user={}", user);
                throw new BizException("编辑用户信息失败!");
            }
            //进行角色权限添加
            AccountRole accountRole = this.extractAccountRole(request.getEmpId(), request.getName());
            rows = accountRoleMapper.insert(accountRole);
            if (rows == 0) {
                log.error("编辑用户信息失败!accountRole={}", accountRole);
                throw new BizException("编辑用户信息失败!");
            }
            //添加完成，返回
            return;
        } else if ((userAccountRequest.getAccountStatus() != null && !account.getStatus().equals(userAccountRequest.getAccountStatus()))
                || (StringUtils.isNotBlank(userAccountRequest.getPassword()) && !account.getPassword().equals(DigestUtils.md5DigestAsHex(userAccountRequest.getPassword().getBytes(CommonConstant.UTF_8))))) {
            //此处判断状态或者密码是否修改了
            if (userAccountRequest.getAccountStatus() != null && !account.getStatus().equals(userAccountRequest.getAccountStatus())) {
                account.setStatus(userAccountRequest.getAccountStatus());
            }
            if (StringUtils.isNotBlank(userAccountRequest.getPassword()) && !account.getPassword().equals(DigestUtils.md5DigestAsHex(userAccountRequest.getPassword().getBytes(CommonConstant.UTF_8)))) {
                account.setPassword(DigestUtils.md5DigestAsHex(userAccountRequest.getPassword().getBytes(CommonConstant.UTF_8)));
            }
        } else {
            //未进行数据更新，返回
            return;
        }
        account.setUpdateId(userAccountRequest.getCurrentId());
        account.setUpdateTime(LocalDateTime.now());
        Integer rows = userAccountMapper.update(account, Wrappers.<UserAccount>lambdaUpdate().eq(UserAccount::getUserId, request.getEmpId()));
        if (rows == 0) {
            log.error("编辑用户信息失败!account={}", account);
            throw new BizException("编辑用户信息失败!");
        }
    }

    /**
     * 根据用户为一键查询用户信息（柜台信息中使用)
     */
    public UserInformation selectUserInfoByUid(String empId) {
        LambdaQueryWrapper<UserInformation> queryWrapper = Wrappers.<UserInformation>lambdaQuery()
                .eq(UserInformation::getEmpId, empId);
        return userMapper.selectOne(queryWrapper);
    }

    /**
     * 根据用户的id或者name进行模糊查询
     *
     * @param emp
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectUserByIdOrName(String emp) {
        List<UserInformation> userInformationList = userMapper.selectList(Wrappers.<UserInformation>lambdaQuery()
                .eq(UserInformation::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                .and(u -> u.like(UserInformation::getEmpId, emp).or().like(UserInformation::getName, emp)));
        return Response.success(ObjectUtils.toList(userInformationList, CommonUserVo.class));
    }

    /**
     * 根据柜台查询柜台下的美导
     *
     * @param request
     * @return
     */
    public Response counterBa(CounterBaRequest request) {
        //判断页数和页面
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            return Response.errorMsg("页数、页码不能为空!");
        }
        //设置分页显示条件
        Page<UserInformation> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //分页查询
        IPage<UserInformation> userInformationIPage = userMapper.counterBa(page, request.getCounterId(), request.getCodeName());
        //查询结果转换
        PageVO pageVO = PageVO.<CounterBaVo>builder()
                .list(ObjectUtils.toList(userInformationIPage.getRecords(), CounterBaVo.class))
                .pageNum(userInformationIPage.getCurrent())
                .pageSize(userInformationIPage.getSize())
                .pages(userInformationIPage.getPages())
                .total(userInformationIPage.getTotal())
                .build();
        //返回前端
        return Response.success(pageVO);
    }

    /**
     * 通用员工模糊查询
     *
     * @param request
     * @return
     */
    public Response commonEmp(CommonEmpRequest request) {
        //判断页数和页面
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            return Response.errorMsg("页数、页码不能为空!");
        }
        //设置分页显示条件
        Page<UserInformation> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询条件
        LambdaQueryWrapper<UserInformation> queryWrapper = Wrappers.<UserInformation>lambdaQuery()
                .orderByDesc(UserInformation::getCreateTime)
                .orderByDesc(UserInformation::getEmpId);
        //判断状态
        if (request.getStatus() != null) {
            queryWrapper.eq(UserInformation::getStatus, request.getStatus());
        }
        //判断模糊查询
        if (StringUtils.isNotBlank(request.getEmp())) {
            queryWrapper.and(e -> e.like(UserInformation::getEmpId, request.getEmp())
                    .or().like(UserInformation::getName, request.getEmp()));
        }
        //分页查询
        IPage<UserInformation> userPage = userMapper.selectPage(page, queryWrapper);
        //查询结果转换
        PageVO pageVO = PageVO.<CommonUserVo>builder()
                .list(ObjectUtils.toList(userPage.getRecords(), CommonUserVo.class))
                .pageNum(userPage.getCurrent())
                .pageSize(userPage.getSize())
                .pages(userPage.getPages())
                .total(userPage.getTotal())
                .build();
        //返回前端
        return Response.success(pageVO);
    }

    /**
     * 查询员工修改履历
     *
     * @param empId
     * @param pageSize
     * @param pageNumber
     * @return
     */
    public Response empOpt(String empId, Integer pageSize, Integer pageNumber) {
        //判断页数和页面
        if (pageSize == null || pageNumber == null) {
            return Response.errorMsg("页数、页码不能为空!");
        }
        //设置分页显示条件
        Page<EmployeeOperation> page = new Page<>(pageNumber, pageSize);
        IPage<EmployeeOperation> employeeOperationIPage = employeeOperationMapper.selectPage(page, Wrappers.<EmployeeOperation>lambdaQuery()
                .eq(EmployeeOperation::getEmpId, empId)
                .orderByDesc(EmployeeOperation::getCreateTime));
        if (employeeOperationIPage.getRecords().isEmpty()) {
            return Response.successMsg("暂无信息!");
        }
        //查询结果转换
        PageVO pageVO = PageVO.<CommonUserVo>builder()
                .list(ObjectUtils.toList(employeeOperationIPage.getRecords(), EmployeeOperationVo.class))
                .pageNum(employeeOperationIPage.getCurrent())
                .pageSize(employeeOperationIPage.getSize())
                .pages(employeeOperationIPage.getPages())
                .total(employeeOperationIPage.getTotal())
                .build();
        return Response.success(pageVO);
    }

    /**
     * 查询员工修改履历详情
     *
     * @param optId
     * @return
     */
    public Response empOptFields(String optId) {
        List<EmployeeOperationFields> fieldsList = employeeOperationFieldsMapper.selectList(Wrappers.<EmployeeOperationFields>lambdaQuery()
                .eq(EmployeeOperationFields::getOptId, optId));
        if (fieldsList.isEmpty()) {
            return Response.successMsg("暂无信息!");
        }
        return Response.success(ObjectUtils.toList(fieldsList, EmployeeOperationFieldsVo.class));
    }

    @Ella(Describe = "查询柜台信息")
    public Response selectCounter(SelectCounterRequest request) {
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            log.error("分页信息没传递");
            return Response.errorMsg("分页信息没传递");
        }
        CounterRequest counterRequest = CounterRequest.builder().build();
        //根据输入的信息判断是查询id还是name
        if (StringUtils.isNotBlank(request.getInput())) {
            if (CommonService.isContainChinese(request.getInput())) {
                counterRequest.setCounterName(request.getInput());
            } else {
                counterRequest.setCounterId(request.getInput());
            }
        }
        counterRequest.setCounterStatus(request.getStatus());
        PageHelper.startPage(request.getPageNumber(), request.getPageSize());
        List<CounterInformation> counterInformationList = counterMapper.searchMation(counterRequest);
        PageInfo<CounterInformation> pageInfo = new PageInfo<>(counterInformationList);
        return Response.success(pageInfo);
    }

    /**
     * 2020-12-03 9:54 根据产品经理需求，转柜的时候根据柜台查询ba的时候不能根据工作柜台查询（即counter_ba接口不能使用）
     * 需要根据所属部门进行查询
     *
     * @param request
     * @return
     */
    public Response deptBa(CounterBaRequest request) {
        if (StringUtils.isBlank(request.getCounterId())) {
            return Response.errorMsg("柜台编码不能为空!");
        }
        //设置分页显示条件
        Page<UserInformation> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询提交
        LambdaQueryWrapper<UserInformation> queryWrapper = Wrappers.<UserInformation>lambdaQuery()
                .eq(UserInformation::getDeptCode, request.getCounterId())
                .eq(UserInformation::getStatus, CommonStatusEnum.EFFECTIVE.getCode());
        if (StringUtils.isNotBlank(request.getCodeName())) {
            queryWrapper.like(UserInformation::getName, request.getCodeName());
        }
        //分页查询
        IPage<UserInformation> userPage = userMapper.selectPage(page, queryWrapper);
        //查询结果转换
        PageVO pageVO = PageVO.<CounterBaVo>builder()
                .list(ObjectUtils.toList(userPage.getRecords(), CounterBaVo.class))
                .pageNum(userPage.getCurrent())
                .pageSize(userPage.getSize())
                .pages(userPage.getPages())
                .total(userPage.getTotal())
                .build();
        //返回前端
        return Response.success(pageVO);
    }

    /**
     * 员工excel批量操作(批量添加、批量停用)
     *
     * @param employeeFile,type
     * @return
     */
    @DS(DBConst.MASTER)
    public Response employeeBatchImport(MultipartFile employeeFile, Integer type, String importName) {
        //type(0:批量添加,1:批量停用)
        if (type == null) {
            return Response.errorMsg("操作类型不能为空！");
        }
        //获取所有岗位信息
        List<Position> positionList = positionMapper.selectList(Wrappers.<Position>lambdaQuery()
                .orderByDesc(Position::getCreateTime));
        Map<String, Position> positionListMap = positionList.stream().collect(Collectors.toMap(Position::getPosCode, e -> e));
        //获取所有部门信息
        List<Department> departmentList = departmentMapper.selectList(Wrappers.<Department>lambdaQuery()
                .orderByDesc(Department::getCreateTime));
        Map<String, Department> departmentListMap = departmentList.stream().collect(Collectors.toMap(Department::getDeptId, e -> e));
        List<EmployeeImportPo> employeeList = employeeMapper.selectList(Wrappers.<EmployeeImportPo>lambdaQuery()
                .orderByDesc(EmployeeImportPo::getCreateTime));
        List<String> phoneNoList = employeeList.stream().map(EmployeeImportPo::getPhoneNo).collect(Collectors.toList());
        List<String> IdCardList = employeeList.stream().map(EmployeeImportPo::getIdCard).collect(Collectors.toList());

        try (Workbook workbook = WorkbookFactory.create(employeeFile.getInputStream())) {
            if (workbook.getNumberOfSheets() == 0) {
                return Response.errorMsg("文件格式不正确，没有sheet！");
            }
            List<EmployeeImportPo> itemList = new ArrayList<>();
            if (type == 0) {
                //同步解析
                itemList = extractSheet(workbook, type, positionListMap, departmentListMap, phoneNoList, IdCardList);
            } else {
                List<String> list = new ArrayList<>();
                //同步解析
                itemList = extractSheet(workbook, type, positionListMap, departmentListMap, phoneNoList, IdCardList);
                for (int i = 0; i < itemList.size(); i++) {
                    String empId = itemList.get(i).getEmpId();
                    if (!list.contains(empId)) {
                        list.add(empId);
                    }
                }
                Response response = updateUserStatus(list, CommonStatusEnum.INVALID.getCode());
                if (response.getCodeL() != 200) {
                    Response.errorMsg("批量修改失败!");
                }
            }
            //保存主表
            String importSerialNo = StrategyCommon.timeAlgorithm(StrategyCommon.employeeImport);
            EmployeeFileImport employeeFileImport = EmployeeFileImport.builder()
                    .importSerialNo(importSerialNo)
                    .importMode(type)
                    .importName(importName)
                    .totalCount(itemList.size())
                    .createTime(LocalDateTime.now())
                    .updateTime(LocalDateTime.now())
                    .build();
            //填充操作人
            employeeFileImport.setOptCode(AdminUserContextHolder.get().getEmpId());
            employeeFileImport.setOptName(AdminUserContextHolder.get().getName());
            int insert = employeeFileImportMapper.insert(employeeFileImport);
            if (insert == 0) {
                log.error("用户信息导入更新模式,保存失败employeeFileImport={}", employeeFileImport);
                throw new Exception("保存失败");
            }
            List<EmployeeFileImportItem> employeeFileImportItems = BeanUtil.copyListProperties(itemList, EmployeeFileImportItem.class);
            List<EmployeeFileImportItem> EmployeeFileImportItemPos = employeeFileImportItems.stream().map(e -> {
                EmployeeFileImportItem item = e;
                item.setImportSerialNo(importSerialNo);
                if (type == 1) {
                    item.setCreateTime(LocalDateTime.now());
                    item.setUpdateTime(LocalDateTime.now());
                }
                return item;
            }).collect(Collectors.toList());
            int res = employeeFileImportItemMapper.batchInsert(EmployeeFileImportItemPos);
            if (res != EmployeeFileImportItemPos.size()) {
                throw new BizException("保存失败");
            }
        } catch (Exception e) {
            return Response.errorMsg(e.getMessage());
        }
        return Response.successMsg("批量操作完成！");
    }

    /**
     * 解析Excel
     *
     * @param
     * @param workbook
     */
    public List<EmployeeImportPo> extractSheet(Workbook workbook, Integer type, Map<String, Position> positionListMap, Map<String, Department> departmentListMap, List<String> phoneNoList, List<String> IdCardList) {
        List<EmployeeImportPo> itemList = Lists.newArrayList();
        List<EmployeeCounterImportPo> itemLists = Lists.newArrayList();
        UserService o1 = (UserService) AopContext.currentProxy();
        IntStream.range(0, workbook.getNumberOfSheets()).parallel().forEach(e -> {
            Sheet sheet = workbook.getSheetAt(e);
            for (Row row : sheet) {
                if (row.getRowNum() < 1) {
                    continue;
                }
                EmployeeImportPo item = this.extractRow(row, positionListMap, departmentListMap, type, phoneNoList, IdCardList);
                if (item == null) {
                    continue;
                }
                EmployeeCounterImportPo items = new EmployeeCounterImportPo();
                items.setEmpId(item.getEmpId());
                items.setName(item.getName());
                items.setPhoneNo(item.getPhoneNo());
                items.setCounterCode(item.getDeptCode());
                items.setCounterName(item.getDeptName());
                items.setIsMaster(0);
                items.setCreateTime(LocalDateTime.now());
                items.setUpdateTime(LocalDateTime.now());
                itemList.add(item);
                itemLists.add(items);
                //分段提交
                if (itemList.size() == 10000 && type == 0) {
                    o1.subCommit(itemList, itemLists);
                    //然后置空
                    itemList.clear();
                    itemLists.clear();
                }
            }
        });
        //没有10000个时也提交
        if (type == 0) {
            o1.subCommit(itemList, itemLists);
        }
        return itemList;
    }

    /**
     * 员工批量导入
     *
     * @param row,positionListMap
     * @return
     */
    public EmployeeImportPo extractRow(Row row, Map<String, Position> positionListMap, Map<String, Department> departmentListMap, Integer type, List<String> phoneNoList, List<String> IdCardList) {
        EmployeeImportPo item = new EmployeeImportPo();
        if (type == 0) {
            item = EmployeeImportPo.builder().empId(IdGenerator.getRandomId(PrefixEnum.EMP.getCode(), 6)).status(1).build();
        }
        try {
            List<String> cellValues = Lists.newArrayList();
            for (Cell cell : row) {
                String value = cell.getCellTypeEnum() == CellType.NUMERIC
                        ? Long.toString(((long) cell.getNumericCellValue()))
                        : cell.getStringCellValue();
                cellValues.add(value);
            }
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            //如果整行数据为空则跳过
            String concat = org.apache.commons.lang3.StringUtils.join(cellValues.iterator(), org.apache.commons.lang3.StringUtils.EMPTY);
            if (org.apache.commons.lang3.StringUtils.isBlank(concat)) {
                return null;
            }
            int flag = 0;
            StringBuilder sb = new StringBuilder();
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(flag))) {
                item.setBrandName(cellValues.get(flag).trim());
            } else {
                throw new BizException("所属品牌不正确");
            }
            flag++;
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(flag))) {
                item.setName(cellValues.get(flag).trim());
            } else {
                throw new BizException("姓名不正确");
            }
            flag++;
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(flag))) {
                String positionCode = cellValues.get(flag).trim();
                Position position = positionListMap.get(positionCode);
                if (position != null) {
                    item.setPositionCode(cellValues.get(flag).trim());
                } else {
                    throw new BizException("岗位代码不正确");
                }
            } else {
                throw new BizException("岗位代码不正确");
            }
            flag++;
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(flag))) {
                String positionCode = cellValues.get(flag - 1).trim();
                Position position = positionListMap.get(positionCode);
                if (position.getPosName().equals(cellValues.get(flag).trim())) {
                    item.setPositionName(cellValues.get(flag).trim());
                } else {
                    throw new BizException("岗位名称不正确");
                }
            } else {
                throw new BizException("岗位名称不正确");
            }
            flag++;
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(flag)) && cellValues.get(flag).trim().length() == 11) {
                if (type == 0 && phoneNoList.contains(cellValues.get(flag).trim())) {
                    throw new BizException("手机号已存在!");
                }
                item.setPhoneNo(cellValues.get(flag).trim());
            } else {
                throw new BizException("手机号【%s】格式不正确");
            }
            flag++;
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(flag))) {
                if (type == 0 && IdCardList.contains(cellValues.get(flag).trim())) {
                    throw new BizException("身份证号已存在!");
                }
                item.setIdCard(cellValues.get(flag).trim());
            } else {
                throw new BizException("身份证号不正确");
            }
            flag++;
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(flag))) {
                String deptId = cellValues.get(flag).trim();
                Department department = departmentListMap.get(deptId);
                if (department != null) {
                    item.setDeptCode(cellValues.get(flag).trim());
                } else {
                    throw new BizException("部门代码不正确");
                }
            } else {
                throw new BizException("部门代码不正确");

            }
            flag++;
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(flag))) {
                String deptId = cellValues.get(flag - 1).trim();
                Department department = departmentListMap.get(deptId);
                if (department.getDeptName().equals(cellValues.get(flag).trim())) {
                    item.setDeptName(cellValues.get(flag).trim());
                } else {
                    throw new BizException("部门名称不正确");
                }
            } else {
                throw new BizException("部门名称不正确");
            }
            flag++;
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(flag))) {
                if (pros.contains(Integer.valueOf(cellValues.get(flag).trim()))) {
                    item.setDeptType(Integer.valueOf(cellValues.get(flag).trim()));
                } else {
                    throw new BizException("部门类型不正确");
                }

            } else {
                throw new BizException("部门类型不正确");
            }
            flag++;
            try {
                if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(flag))) {
                    item.setRecentEntryTime(LocalDate.parse(cellValues.get(flag).trim()));
                }
            } catch (Exception e) {
                throw new BizException("入职时间【%s】不正确，格式YYYY-MM-DD");
            }
            if (type == 0) {
                item.setCreateTime(LocalDateTime.now());
                item.setUpdateTime(LocalDateTime.now());
            } else {
                //判断该用户信息是否正确
                EmployeeImportPo employeeImportPo = employeeMapper.selectOne(Wrappers.<EmployeeImportPo>lambdaQuery()
                        .eq(EmployeeImportPo::getBrandName, item.getBrandName())
                        .eq(EmployeeImportPo::getName, item.getName())
                        .eq(EmployeeImportPo::getPositionCode, item.getPositionCode())
                        .eq(EmployeeImportPo::getPositionName, item.getPositionName())
                        .eq(EmployeeImportPo::getPhoneNo, item.getPhoneNo())
                        .eq(EmployeeImportPo::getIdCard, item.getIdCard())
                        .eq(EmployeeImportPo::getDeptCode, item.getDeptCode())
                        .eq(EmployeeImportPo::getDeptName, item.getDeptName())
                );
                if (employeeImportPo == null) {
                    throw new BizException("员工信息填写错误,未查到此员工!");
                } else {
                    item.setEmpId(employeeImportPo.getEmpId());
                }
            }
        } catch (Exception e) {
            log.error("userService.extractSheet.row.error,", e);
            int rows = row.getRowNum() + 1;
            String errMsg = "操作异常，" + e.getMessage() + "，行：" + rows;
            throw new BizException(errMsg);
        }
        return item;
    }

    /**
     * 按条件查询
     */
    @DS(DBConst.SLAVE)
    public Response selectEmployeeImportList(SelectImportNoRequest request) {
        Page<EmployeeFileImport> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询
        LambdaQueryWrapper<EmployeeFileImport> queryWrapper = Wrappers.<EmployeeFileImport>lambdaQuery()
                .orderByDesc(EmployeeFileImport::getCreateTime);
        if (request.getImportMode() != null) {
            queryWrapper.eq(EmployeeFileImport::getImportMode, request.getImportMode());
        }
        if (StringUtils.isNotBlank(request.getImportName())) {
            queryWrapper.like(EmployeeFileImport::getImportName, request.getImportName());
        }
        if (request.getStartTime() != null) {
            queryWrapper.ge(EmployeeFileImport::getCreateTime, request.getStartTime());
        }
        if (request.getEndTime() != null) {
            queryWrapper.lt(EmployeeFileImport::getCreateTime, request.getEndTime().plusDays(1));
        }
        IPage<EmployeeFileImport> importIPage = employeeFileImportMapper.selectPage(page, queryWrapper);
        if (importIPage == null) {
            return Response.successMsg("暂无数据");
        }
        List<EmployeeFileImport> list = importIPage.getRecords();
        PageVO pageVO = PageVO.<MemberFilesImportVo>builder().list(ObjectUtils.toList(list, EmployeeFileImport.class))
                .total(importIPage.getTotal())
                .pageNum(importIPage.getCurrent())
                .pageSize(importIPage.getSize())
                .pages(importIPage.getPages())
                .build();
        return Response.success(pageVO);
    }

    /**
     * 点击导入流水号查看详情->条件查询
     */
    @DS(DBConst.SLAVE)
    public Response listOfResults(String importSerialNo, String idCard, String name, Integer pageSize, Integer pageNumber) {
        PageHelper.startPage(pageNumber, pageSize);
        List<EmployeesPo> employeeImportQueryPosList = employeeFileImportItemMapper.queryImportDetail(importSerialNo, idCard, name);
        PageInfo<EmployeesPo> info = new PageInfo<>(employeeImportQueryPosList);
        info.setTotal(employeeFileImportItemMapper.queryTotal(importSerialNo, idCard, name));
        return Response.success(info);
    }

    /**
     * 详情中的Excel导出
     */
    @DS(DBConst.SLAVE)
    public List<Map<String, String>> exportEmployeeTable(String importSerialNo) {
        try {
            String idCard = null;
            String name = null;
            List<EmployeesPo> employeeImportQueryPosList = employeeFileImportItemMapper.queryImportDetail(importSerialNo, idCard, name);
            if (employeeImportQueryPosList.isEmpty()) {
                log.error("暂无信息");
                return new ArrayList<>();
            }
            List<Map<String, String>> list = new ArrayList<>();
            for (EmployeesPo employeeInfo : employeeImportQueryPosList) {
                Map<String, String> data = new HashMap<>();
                //封装数据
                data.put("BA编号", employeeInfo.getEmpId());
                data.put("门店编号", employeeInfo.getCounterId());
                data.put("所属品牌", employeeInfo.getBrandName());
                data.put("姓名", employeeInfo.getName());
                data.put("岗位", employeeInfo.getPositionName());
                data.put("手机", employeeInfo.getPhoneNo());
                data.put("身份证号", employeeInfo.getIdCard());
                data.put("所属部门", employeeInfo.getDeptName());
                if("10006".equals(employeeInfo.getOperationalModel())){
                    data.put("运营模式", "代理商");
                }else if("10005".equals(employeeInfo.getOperationalModel())){
                    data.put("运营模式", "自营");
                }else{
                    data.put("运营模式", "");
                }
                list.add(data);
            }
            return list;
        } catch (Exception e) {
            log.error("导出表出现异常", e);
            return new ArrayList<>();
        }
    }

    /**
     * 构建新的list 并一起提交
     *
     * @param itemList
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public List<EmployeeImportPo> subCommit(List<EmployeeImportPo> itemList, List<EmployeeCounterImportPo> itemLists) {
        employeeMapper.batchInsert(itemList);
        employeeCounterMapper.batchInsert(itemLists);
        return itemList;
    }

}
