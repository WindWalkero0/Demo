package com.ruihe.admin.listener;


import com.ruihe.common.service.AdminTaskService;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.CheckMemberLevelEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * @author ly
 * @Description 校验当前会员等级与会员等级升降级履历一致性
 */

@Slf4j
@Component
public class CheckMemberLevelListener {

    @Autowired
    private AdminTaskService adminTaskService;

    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(CheckMemberLevelEvent event) {
        try {
            adminTaskService.checkMemberLevel();
        } catch (Exception e) {
            log.error("校验当前会员等级与会员等级升降级履历一致性.error,event={}", event, e);
        }
    }

}
