package com.ruihe.admin.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Data
@ApiModel(description = "日志查询请求对象")
public class LogSearchRequest {

    @ApiModelProperty(value = "操作人ID", required = true)
    @NotBlank(message = "登录人ID不能为空")
    private String operationUserId;

    @ApiModelProperty(value = "操作人姓名", notes = "只针对超级管理员有效,超级管理员可查询其他人操作日志")
    private String operationUserName;

    @ApiModelProperty(value = "请求IP 查询范围请在IP地址后加/ ", example = "10.0.0.0/16")
    private String ip;

    @ApiModelProperty(value = "请求行为关键字,关键字用空格隔开", example = "搜索 活动 促销")
    private String classMethodDesc;

    @ApiModelProperty(value = "操作时间开始时间")
    private String beginTime;

    @ApiModelProperty(value = "操作时间结束时间")
    private String endTime;

    @ApiModelProperty(value = "当前页码")
    @Min(value = 0, message = "当前页码不能小于0")
    private int pageNumber;

    @ApiModelProperty(value = "每页记录数")
    @Min(value = 1, message = "每页条数不能小于1")
    private int pageSize;

}
