package com.ruihe.admin.service.erp.report;

import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.dao.bean.order.PosPaymentOrderPo;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.pojo.response.order.MemberPayChannelResponse;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.admin.constant.ElasticSearchContant;
import com.ruihe.admin.mapper.basic.CounterMapper;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.request.erp.PaymentReportRequest;
import com.ruihe.admin.response.erp.PaymentExcelResponse;
import com.ruihe.admin.response.erp.PaymentItemReportResponse;
import com.ruihe.admin.response.erp.PaymentReportResponse;
import com.ruihe.admin.response.erp.PosOrderItemResponse;
import com.ruihe.admin.utils.PageUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.data.elasticsearch.core.query.NativeSearchQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;


/**
 * 支付方式查询es实现
 *
 * @author William
 */
@Slf4j
@Service
public class PaymentElasticSearch extends ElasticSearchContant {

    @Autowired
    private ElasticsearchRestTemplate elasticsearchRestTemplate;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    @Autowired
    private CounterMapper counterMapper;


    /**
     * 分页查询积分订单，通过from ,size方式,原理是live cursor，很像mysql分页
     * 优点:
     * 1、可往前、往后翻
     * 2、反映实时产生的数据
     * 3、计算资源占用少
     * 缺点：
     * 1、不可跳页
     * 2、客户端需记录当前页第一条和最后一条的sortValues，翻页请求时带入sortValues参数
     * 3、往前翻页时需改变排序方式，如往后翻页是按id倒叙，往前翻页则是按id升序
     * 适用场景：
     * 除不支持跳页外的所有场景
     *
     * @param request
     * @return
     */
    public Mono<Response> list(PaymentReportRequest request) {
        NativeSearchQuery nsq = extractSearchQuery(request);
        SearchHits<PosPaymentOrderPo> orderSearchResult = elasticsearchRestTemplate.search(nsq, PosPaymentOrderPo.class, IndexCoordinates.of(IDX_POS_PMT_ORDER));
        ArrayList<String> bizNoList = (ArrayList<String>) orderSearchResult.toList().parallelStream().map(e -> e.getContent().getOrderNo()).collect(Collectors.toList());

        Map<String, PosOrderPo> collect = null;
        if (bizNoList.size() > 0) {
            NativeSearchQuery nsqOrder = extractSearchQueryForOrder(bizNoList);
            SearchHits<PosOrderPo> orderResult = elasticsearchRestTemplate.search(nsqOrder, PosOrderPo.class, IndexCoordinates.of(IDX_POS_ORDER));
            List<PosOrderPo> orderList = orderResult.toList().parallelStream().map(SearchHit::getContent).collect(Collectors.toList());
            if (orderList.size() == 0) {
                log.error(bizNoList + "存在支付订单不存在订单");
                return Mono.just(Response.errorMsg("es数据同步有问题，请联系管理员！"));
            }
            collect = orderList.stream().collect(Collectors.toMap(PosOrderPo::getOrderNo, Function.identity()));
        }

        String uuid = IdGenerator.getShorterSerialNo("ADMIN:PM");
        redisTemplate.opsForValue().set(uuid, request, 2, TimeUnit.HOURS);
        Map<String, PosOrderPo> finalCollect = collect;
        PageVO<PaymentReportResponse> pageVo = PageUtils.<PosPaymentOrderPo, PaymentReportResponse>convert(orderSearchResult,
                e -> {
                    PaymentReportResponse vo = new PaymentReportResponse();
                    PosOrderPo posOrderPo = finalCollect.get(e.getOrderNo());
                    if (posOrderPo == null) {
                        return vo;
                    }
                    BeanUtils.copyProperties(e, vo);
                    vo.setRealAmt(posOrderPo.getRealAmt());
                    vo.setBizTime(posOrderPo.getBizTime());
                    vo.setBaCode(posOrderPo.getBaCode());
                    vo.setBaName(posOrderPo.getBaName());
                    vo.setOrderChanName(posOrderPo.getOrderChanName());
                    vo.setReceiptNo(posOrderPo.getReceiptNo());
                    vo.setTransType(posOrderPo.getTransType());
                    vo.setOrderType(posOrderPo.getOrderType());
                    return vo;
                }
                , request);
        Map<String, Serializable> resultMap = Map.ofEntries(
                Map.entry("pageVo", pageVo),
                Map.entry("key", uuid)
        );
        return Mono.just(Response.success(resultMap));
    }

    /**
     * 构造搜索条件
     *
     * @param request
     * @return
     */
    private NativeSearchQuery extractSearchQuery(PaymentReportRequest request) {
        this.doOrgQueryConditionRequest(request.getOrgQueryConditionRequest());
        BoolQueryBuilder bqb = this.extractBoolQueryBuilder(request);
        NativeSearchQueryBuilder builder = new NativeSearchQueryBuilder();
        NativeSearchQuery nsq = builder.withFilter(bqb)
                //search_after和scroll_id方式from都是0
                .withPageable(PageRequest.of(0, request.getPageSize()))
                //.withPageable(PageRequest.of(request.getPageNumber(), request.getPageSize()))
                //设置searchAfter的sortValues
                .withSearchAfter(request.getSortValues())
                .withSort(SortBuilders.fieldSort("biz_time").order(CommonConstant.NEXT.equals(request.getDirection()) ? SortOrder.DESC : SortOrder.ASC))
                .withSort(SortBuilders.fieldSort("order_no").order(CommonConstant.NEXT.equals(request.getDirection()) ? SortOrder.DESC : SortOrder.ASC))
                .build();
        //设置最大命中数
        //https://elasticsearch.cn/question/7655
        nsq.setTrackTotalHits(true);
        return nsq;
    }

    /**
     * 构造查询条件BoolQueryBuilder
     *
     * @param request
     * @return
     */
    private BoolQueryBuilder extractBoolQueryBuilder(PaymentReportRequest request) {
        BoolQueryBuilder bqb = QueryBuilders.boolQuery();
        if (request.getPayChannel() != null) {
            bqb.must(QueryBuilders.matchQuery("pay_channel", request.getPayChannel()));
        }

        //单据日期
        RangeQueryBuilder bizTimeRange = QueryBuilders.rangeQuery("biz_time");
        LocalDate endDate = org.apache.commons.lang3.ObjectUtils.getIfNull(request.getEndTime(), LocalDate::now);
        request.setEndTime(endDate.plusDays(1));
        bizTimeRange
                .format("yyyy-MM-dd")
                .gte(org.apache.commons.lang3.ObjectUtils.getIfNull(request.getStartTime(), () -> LocalDate.of(1970, 1, 1)))
                .lt(endDate.plusDays(1));
        bqb.must(bizTimeRange);
        //柜台

        OrgQueryConditionRequest orgQueryConditionRequest = request.getOrgQueryConditionRequest();
        if (orgQueryConditionRequest != null) {
            List<String> counterIds = counterMapper.selectAll(orgQueryConditionRequest);
            bqb.must(QueryBuilders.termsQuery("counter_id", counterIds));
        }

        //单据号
        if (StringUtils.isNotBlank(request.getOrderNo())) {
            bqb.must(QueryBuilders.matchPhraseQuery("order_no", request.getOrderNo().trim()));
        }
        return bqb;
    }


    /**
     * 构造order搜索条件
     *
     * @param orderIds
     * @return
     */
    private NativeSearchQuery extractSearchQueryForOrder(List<String> orderIds) {
        //pmt 永远比 order多 所以按这个分页也没有问题
        NativeSearchQueryBuilder builder = new NativeSearchQueryBuilder();
        builder.withQuery(QueryBuilders.termsQuery("order_no", orderIds));
        return builder.build();
    }

    /**
     * 支付明细
     *
     * @param orderId
     * @return
     */
    public Mono<Response> detail(String orderId) {
        if (orderId == null) {
            return Mono.just(Response.errorMsg("参数错误!"));
        }
        NativeSearchQueryBuilder builder = new NativeSearchQueryBuilder();
        NativeSearchQuery nsq = builder.withFilter(QueryBuilders.matchPhraseQuery("order_no", orderId))
                .withPageable(Pageable.unpaged())
                .withSort(SortBuilders.fieldSort("order_no").order(SortOrder.DESC))
                .build();

        NativeSearchQueryBuilder builderForOrder = new NativeSearchQueryBuilder();
        NativeSearchQuery nsqForOrder = builderForOrder.withFilter(QueryBuilders.matchPhraseQuery("order_no", orderId))
                .withPageable(Pageable.unpaged())
                .withSort(SortBuilders.fieldSort("order_no").order(SortOrder.DESC))
                .build();

        SearchHits<PosPaymentOrderPo> paymentOrderListFlux = elasticsearchRestTemplate.search(nsq, PosPaymentOrderPo.class, IndexCoordinates.of(IDX_POS_PMT_ORDER));
        SearchHits<PosOrderItemPo> orderItemListFlux = elasticsearchRestTemplate.search(nsqForOrder, PosOrderItemPo.class, IndexCoordinates.of(IDX_POS_ORDER_ITEM));


        PaymentItemReportResponse paymentItemReportResponse = new PaymentItemReportResponse();

        //获取支付信息，用list接收
        List<PosPaymentOrderPo> paymentOrderPoList = paymentOrderListFlux.toList().parallelStream().map(SearchHit::getContent).collect(Collectors.toList());
        //转换
        if (!paymentOrderPoList.isEmpty()) {
            paymentItemReportResponse.setMemberPayChannelResponses(ObjectUtils.toList(paymentOrderPoList, MemberPayChannelResponse.class));
        }
        //获取子表信息，用list
        List<PosOrderItemPo> posOrderItemPoList = orderItemListFlux.toList().parallelStream().map(SearchHit::getContent).collect(Collectors.toList());
        //转换
        if (!posOrderItemPoList.isEmpty()) {
            List<PosOrderItemResponse> itemVoList = posOrderItemPoList.stream().map(e -> {
                PosOrderItemResponse posOrderItemResponse = new PosOrderItemResponse();
                BeanUtils.copyProperties(e, posOrderItemResponse);
                if (e.getProType().equals(3)) {
                    posOrderItemResponse.setProType("正常销售");
                } else {
                    posOrderItemResponse.setProType("促销");
                }
                return posOrderItemResponse;
            }).collect(Collectors.toList());
            paymentItemReportResponse.setItemVoList(itemVoList);
        }

        return Mono.just(Response.success(paymentItemReportResponse));
    }

    /**
     * 柜台状态、类型转换
     *
     * @param queryRequest
     */
    private void doOrgQueryConditionRequest(OrgQueryConditionRequest queryRequest) {
        //柜台的状态、类型跟部门的不一致，此处需要转换
        if (queryRequest != null && queryRequest.getOrgType() != null) {
            queryRequest.setOrgType(queryRequest.getOrgType().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CounterEnum.FORMAL_COUNTER.getKey() : CounterEnum.TEST_COUNTER.getKey());
        }
        if (queryRequest != null && queryRequest.getOrgStatus() != null) {
            queryRequest.setOrgStatus(queryRequest.getOrgStatus().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CommonStatusEnum.INVALID.getCode() : CommonStatusEnum.EFFECTIVE.getCode());
        }
    }

    /**
     * 根据条件查询数据数量
     *
     * @param request
     * @return
     */
    public Long queryListCount(PaymentReportRequest request) {
        //根据条件查询支付表的数量（可能会因为特殊情况导致数据有略微差距，比如订单是59分59秒，支付时间可能是下一天）
        SearchHits<PosPaymentOrderPo> orderSearchResult = this.extractExcelQuery(request);
        return orderSearchResult.getTotalHits();
    }

    /**
     * excel导出数据查询
     *
     * @param request
     * @return
     */
    private SearchHits<PosPaymentOrderPo> extractExcelQuery(PaymentReportRequest request) {
        //redis中时间加了一天，需要还原
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().minusDays(1));
        }
        //获取查询条件
        BoolQueryBuilder bqb = this.extractBoolQueryBuilder(request);
        NativeSearchQueryBuilder builder = new NativeSearchQueryBuilder();
        NativeSearchQuery nsq = builder.withFilter(bqb)
                .withPageable(Pageable.unpaged())
                .withSort(SortBuilders.fieldSort("biz_time").order(SortOrder.DESC))
                .withSort(SortBuilders.fieldSort("order_no").order(SortOrder.DESC))
                .build();
        //设置最大命中数
        nsq.setTrackTotalHits(true);
        SearchHits<PosPaymentOrderPo> orderSearchResult = elasticsearchRestTemplate.search(nsq, PosPaymentOrderPo.class, IndexCoordinates.of(IDX_POS_PMT_ORDER));
        return orderSearchResult;
    }

    /**
     * 根据条件查询数据
     *
     * @param request PaymentReportRequest
     * @return List<PaymentExcelResponse>
     */
    public List<PaymentExcelResponse> queryListExcel(PaymentReportRequest request) {
        //查询支付信息
        SearchHits<PosPaymentOrderPo> orderSearchResult = this.extractExcelQuery(request);
        //获取到订单号(去重)
        List<String> bizNoList = orderSearchResult.toList().parallelStream().map(e -> e.getContent().getOrderNo()).distinct().collect(Collectors.toList());
        //获取订单信息
        NativeSearchQuery nsqOrder = extractSearchQueryForOrder(bizNoList);
        SearchHits<PosOrderPo> orderResult = elasticsearchRestTemplate.search(nsqOrder, PosOrderPo.class, IndexCoordinates.of(IDX_POS_ORDER));
        List<PosOrderPo> orderList = orderResult.toList().parallelStream().map(SearchHit::getContent).collect(Collectors.toList());
        Map<String, PosOrderPo> orderMap = orderList.parallelStream().collect(Collectors.toMap(PosOrderPo::getOrderNo, Function.identity()));
        return orderSearchResult.toList().parallelStream().map(e -> {
            PaymentExcelResponse vo = new PaymentExcelResponse();
            PosPaymentOrderPo paymentOrder = e.getContent();
            PosOrderPo posOrderPo = orderMap.get(paymentOrder.getOrderNo());
            if (posOrderPo != null) {
                BeanUtils.copyProperties(posOrderPo, vo);
            }
            vo.setPayAmt(paymentOrder.getPayAmt());
            vo.setPayChannel(paymentOrder.getPayChannel());
            return vo;
        }).collect(Collectors.toList());
    }
}
