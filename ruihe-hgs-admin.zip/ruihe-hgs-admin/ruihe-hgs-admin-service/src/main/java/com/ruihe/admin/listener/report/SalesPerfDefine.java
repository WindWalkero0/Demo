package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.report.core.CalculateFunc;
import com.ruihe.admin.listener.report.core.Column;
import com.ruihe.admin.listener.report.core.ColumnDefine;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.admin.request.bi.SalesPerfReportRequest;
import com.ruihe.admin.request.bi.SalesPerfSelectRequest;

import java.math.BigDecimal;

public class SalesPerfDefine extends TableDefine {
    static Column realAmt = new Column("销售总金额", "realAmt", BigDecimal.class);
    static Column goodsQty = new Column("销售总支数", "goodsQty", Integer.class);
    static Column orderQty = new Column("销售总单数", "orderQty", Integer.class);
    static Column netOrderQty = new Column("销售总单数M", "netOrderQty", false, Integer.class);
    static Column skQty = new Column("销售总支数M", "skQty", false, Integer.class);

    /**
     * 在查询时间段内，只要满足过一次经营新会员定义，则认为符合统计条件，不用关注当前会员等级状态；
     */
    static Column optNewMem = new Column("经营新会员人数", "optNewMem", Integer.class);

    /**
     * 该门店或美导当天净销售额为0，或者没有任何销售或退货订单，不算一个销售天数，只在【总计】中汇总展示
     */
    static Column salesDays = new Column("销售天数", "salesDays", Integer.class);

    /**
     * 销售总金额/销售总单数M
     */
    static Column pct = new Column(
            "客单价",
            "pct",
            BigDecimal.class
    ).dep(realAmt, netOrderQty).calculateFunc(CalculateFunc.DIV);

    /**
     * 销售总支数M/销售总单数M
     * 客单价和连带率排除整单金额为0的单据。
     * 非“护肤品”类产品支数不计入连带率的计算。
     * 销售总单数M=累计实付金额大于0的订单数+累计退货金额大于0的订单数，注意与上面的“销售总单数”的计算区别
     * 销售总支数M=累计“护肤品”大类销售产品数量-累计“护肤品”大类实物退货产品数量，注意与上面的“销售总支数”的计算区别
     */
    static Column jr = new Column(
            "连带率",
            "jr",
            BigDecimal.class
    ).dep(skQty, netOrderQty).calculateFunc(CalculateFunc.DIV);

    static Column optNewAmt = new Column("经营新会员购买金额", "optNewAmt", BigDecimal.class, false);
    static Column optNewOrder = new Column("经营新会员购买单数", "optNewOrder", Integer.class, false);
    static Column optNewPct = new Column(
            "经营新客单",
            "optNewPct",
            BigDecimal.class
    ).dep(optNewAmt, optNewOrder).calculateFunc(CalculateFunc.DIV);

    static Column vetPur = new Column("老会员购买人数", "vetPur", Integer.class);
    static Column vetAmt = new Column("老会员购买金额", "vetAmt", BigDecimal.class, false);
    static Column vetOrder = new Column("老会员购买单数", "vetOrder", Integer.class, false);
    static Column vetPct = new Column(
            "老客单",
            "vetPct",
            BigDecimal.class
    ).dep(vetAmt, vetOrder).calculateFunc(CalculateFunc.DIV);

    static Column newOrder = new Column("新会员购买单数", "newOrder", Integer.class);
    static Column mj = new Column("会员入会数量", "mj", Integer.class);
    static Column newRepurRate = new Column(
            "新会员重复购买率\n(新会员购买单数/会员入会数量)",
            "newRepurRate",
            BigDecimal.class
    ).dep(newOrder, mj).calculateFunc(CalculateFunc.DIV);

    static Column vetRepurRate = new Column(
            "老会员重复购买率\n(老会员购买单数/老会员购买人数)",
            "vetRepurRate",
            BigDecimal.class
    ).dep(vetOrder, vetPur).calculateFunc(CalculateFunc.DIV);

    public static TableDefine create(SalesPerfReportRequest request) {
        SalesPerfSelectRequest selectRequest = request.getSelectRequest();
        SalesPerfDefine define = new SalesPerfDefine();
        define.addHorizontalColumns(selectRequest);
        define.addVerticalColumns(selectRequest);
        define.addValueColumns(selectRequest);
        define.setStartTime(request.getStartTime());
        define.setEndTime(request.getEndTime());
        define.setMonthly(request.getSelectRequest().isMonthly());
        define.setDaily(request.getSelectRequest().isDaily());
        define.setTotalFlag(TableDefine.TOTAL_ALL);
        return define;
    }

    /**
     * 添加查询字段，不包括统计数值字段
     */
    private void addHorizontalColumns(SalesPerfSelectRequest req) {
        this.addHorizontalColumn(ColumnDefine.areaCode, req.isArea());
        this.addHorizontalColumn(ColumnDefine.areaName, req.isArea());
        this.addHorizontalColumn(ColumnDefine.officeCode, req.isOffice());
        this.addHorizontalColumn(ColumnDefine.officeName, req.isOffice());
        this.addHorizontalColumn(ColumnDefine.principalCode, req.isPrincipal());
        this.addHorizontalColumn(ColumnDefine.principalName, req.isPrincipal());
        this.addHorizontalColumn(ColumnDefine.counterId, req.isCounterId());
        this.addHorizontalColumn(ColumnDefine.counterName, req.isCounterName());
        this.addHorizontalColumn(ColumnDefine.baCode.show(req.isBaCode()), req.isBaCode() || req.isBaName());
        this.addHorizontalColumn(ColumnDefine.baName, req.isBaName());
    }

    private void addVerticalColumns(SalesPerfSelectRequest req) {
        this.addVerticalColumn(ColumnDefine.month, req.isMonthly());
        this.addVerticalColumn(ColumnDefine.day, req.isDaily());
    }

    /**
     * 添加统计数值字段
     */
    private void addValueColumns(SalesPerfSelectRequest req) {
        this.addValueColumn(realAmt.show(req.isRealAmt()), req.isRealAmt() || req.isPct());
        this.addValueColumn(goodsQty, req.isGoodsQty());
        this.addValueColumn(orderQty, req.isOrderQty());
        this.addValueColumn(pct, req.isPct());
        this.addValueColumn(jr, req.isJr());
        this.addValueColumn(netOrderQty, req.isPct() || req.isJr());
        this.addValueColumn(skQty, req.isJr());
        this.addValueColumn(optNewMem, req.isOptNewMem());
        this.addValueColumn(salesDays, req.isSalesDays());
        this.addValueColumn(vetPur.show(req.isVetPur()), req.isVetPur() || req.isVetRepurRate());
        this.addValueColumn(vetPct, req.isVetPct());
        this.addValueColumn(vetAmt, req.isVetPct());
        this.addValueColumn(vetOrder, req.isVetPct() || req.isVetRepurRate());
        this.addValueColumn(optNewAmt, req.isOptNewPct());
        this.addValueColumn(optNewOrder, req.isOptNewPct());
        this.addValueColumn(optNewPct, req.isOptNewPct());

        this.addValueColumn(mj.show(false), req.isNewRepurRate());
        this.addValueColumn(newOrder.show(false), req.isNewRepurRate());

        this.addValueColumn(newRepurRate, req.isNewRepurRate());
        this.addValueColumn(vetRepurRate, req.isVetRepurRate());
    }
}
