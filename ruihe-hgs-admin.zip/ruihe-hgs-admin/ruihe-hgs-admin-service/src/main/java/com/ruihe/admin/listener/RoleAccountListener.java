package com.ruihe.admin.listener;


import com.ruihe.admin.service.basic.JurisdictionService;
import com.ruihe.common.dao.bean.base.AccountRole;
import com.ruihe.common.dao.bean.base.RoleMenu;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.RoleAccountEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.List;

@Ella(Describe = "监听到地区下面有柜台发生了变化进行更新", Author = "K")
@Slf4j
@Component
public class RoleAccountListener implements ApplicationListener<RoleAccountEvent> {


    private final String KEY = "ADMIN:ROLE_ACCOUNT";

    @Autowired
    private JurisdictionService jurisdictionService;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;


    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    public void onApplicationEvent(RoleAccountEvent event) {
        //更新之前先删除数据
        redisTemplate.opsForHash().delete(KEY, event.getUserId());
        //查询角色集合
        List<AccountRole> accountRoles = jurisdictionService.selectAccount(event.getUserId());
        List<RoleMenu> roleMenus = null;
        for (AccountRole accountRole : accountRoles) {
            roleMenus = jurisdictionService.selectByRoleUid(accountRole.getRoleUid());
        }
        //进行存储
        redisTemplate.opsForHash().put(KEY, event.getUserId(), roleMenus);
    }
}
