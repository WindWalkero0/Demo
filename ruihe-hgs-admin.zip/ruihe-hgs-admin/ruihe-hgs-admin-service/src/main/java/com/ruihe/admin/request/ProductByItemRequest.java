package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-06 10:18
 */
@ApiModel(value = "ProductByItemRequest", description = "根据分类查询产品请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductByItemRequest implements Serializable {

    @ApiModelProperty(value = "分类代码")
    private Integer sortId;

    @ApiModelProperty(value = "显示分类的类型:1大分类，2中分类，3小分类")
    private Integer type;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
