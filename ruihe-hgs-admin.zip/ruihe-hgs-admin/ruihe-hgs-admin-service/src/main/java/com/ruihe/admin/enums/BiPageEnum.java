package com.ruihe.admin.enums;

/**
 * bi报表名称
 *
 * @author ly
 */
public enum BiPageEnum {

    /**
     * 每页记录
     **/
    PAGE_SIZE(500, "每页记录"),
    /**
     * 页码
     */
    PAGE_NUM(1, "页码"),
    ;


    private Integer code;
    private String msg;


    BiPageEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
