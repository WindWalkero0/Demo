package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 执行记录查询
 *
 * @author LiangYuan
 * @date 2021-02-05 14:51
 */
@ApiModel(value = "ChangePhoneLogRequest", description = "执行记录查询请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ChangePhoneLogRequest implements Serializable {

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
