package com.ruihe.admin.listener.excel;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.google.common.collect.Lists;
import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.common.pojo.response.basic.CounterExcelResponse;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.CounterExcelEvent;
import com.ruihe.admin.listener.style.CellStyleUtils;
import com.ruihe.admin.listener.style.CustomHorizontalCellStyleStrategy;
import com.ruihe.admin.mapper.basic.CounterMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.request.basic.CounterRequest;
import com.ruihe.admin.utils.ColumnWidthStyleStrategy;
import com.ruihe.admin.utils.ExcelImgUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.List;

/***
 * 柜台一览Excel导出
 * @author fly
 */
@Slf4j
@Component
public class CounterExcelListener extends AbstractReportListener<CounterExcelEvent> {

    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;


    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(CounterExcelEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    protected void doExport(CounterExcelEvent event, BiReportPo report, boolean flag) {
        CounterRequest counterRequest = event.getRequest();
        //购买记录分开查询
        List<CounterExcelResponse> counterResponses = counterMapper.searchMationExcel(counterRequest);
        //数据写入到字节流
        List<Class<?>> dataTypes = getDataTypesList();
        CustomHorizontalCellStyleStrategy cellStyle = CellStyleUtils.customHorizontalCellStyleStrategy(CounterExcelResponse.class, dataTypes);
        ExcelWriter excelWriter = EasyExcel.write(report.getFilePath())
                .inMemory(true)
                .build();
        WriteSheet writeSheet = EasyExcel.writerSheet("第1～" + counterResponses.size() + "条")
                .sheetNo(0)
                .head(CounterExcelResponse.class)
                .registerWriteHandler(cellStyle)
                .registerWriteHandler(new ColumnWidthStyleStrategy())
                .automaticMergeHead(true)
                .build();
        excelWriter.write(counterResponses, writeSheet);
        ExcelImgUtils.CreatImgSheet(imgPath, report.getPicUrl(), excelWriter);
        excelWriter.finish();
    }

    /**
     * 处理表头数据
     *
     * @return
     */
    private List<Class<?>> getDataTypesList() {
        List<Class<?>> dataType = Lists.newArrayList();
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        return dataType;
    }
}
