package com.ruihe.admin.event;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class NursingMemberEvent {
}
