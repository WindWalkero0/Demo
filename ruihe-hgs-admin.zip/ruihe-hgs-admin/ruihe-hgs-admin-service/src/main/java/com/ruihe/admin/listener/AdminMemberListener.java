package com.ruihe.admin.listener;

import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.service.AsynchronousService;
import com.ruihe.admin.event.AdminMemberCacheEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

@Slf4j
@Component
public class AdminMemberListener {

    @Autowired
    private AsynchronousService asynchronousService;


    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(AdminMemberCacheEvent event) {
        try {
            asynchronousService.newCache(event.getMemberInfo());
        } catch (Exception e) {
            log.error("新增一个会员进行加入缓存操作.error,member={}", event.getMemberInfo(), e);
        }
    }
}
