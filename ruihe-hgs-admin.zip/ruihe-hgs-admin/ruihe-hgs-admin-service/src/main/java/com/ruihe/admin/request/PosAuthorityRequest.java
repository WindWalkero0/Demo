package com.ruihe.admin.request;

import com.ruihe.common.annotation.EnumValidation;
import com.ruihe.common.enums.order.ProgramTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

/**
 * @author 梁远
 * @Description 新增临时权限请求实体
 * @date 2019-12-10 10:02
 */
@ApiModel(value = "PosAuthorityRequest", description = "新增临时权限请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PosAuthorityRequest implements Serializable {

    @NotNull(message = "名称不能为空")
    @ApiModelProperty(value = "名称")
    @Size(max=50,message = "名称最大字符长度为50个字符")
    private String name;

    @NotNull(message = "开始时间不能为空")
    @ApiModelProperty(value = "开始时间")
    private String startTime;

    @NotNull(message = "结束时间不能为空")
    @ApiModelProperty(value = "结束时间")
    private String endTime;

    @NotNull(message = "类型不能为空")
    @EnumValidation(clazz = ProgramTypeEnum.class, method = "getCode", message = "类型错误")
    @ApiModelProperty(value = "类型：KT--空退，BL--补录，IBC--手输条码，NI--负库存，FI--自由盘点")
    private String type;

    @NotEmpty(message = "无柜台信息，不能保存!")
    @ApiModelProperty(value = "柜台信息")
    @Valid
    private List<PosAuthorityCounterRequest> list;

}
