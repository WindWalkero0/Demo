package com.ruihe.admin.listener.excel;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.RealtimeStockDetailExcelEvent;
import com.ruihe.admin.mapper.erp.report.WhStockMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.request.erp.RealtimeStockRequest;
import com.ruihe.admin.response.erp.WhProductStockDetailVo;
import com.ruihe.admin.response.erp.WhProductStockVo;
import com.ruihe.admin.utils.ColumnWidthStyleStrategy;
import com.ruihe.admin.utils.ExcelImgUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.List;

/***
 * 实时库存明细导出
 */
@Slf4j
@Component
public class RealtimeStockDetailExcelListener extends AbstractReportListener<RealtimeStockDetailExcelEvent> {
    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;
    @Autowired
    private WhStockMapper stockMapper;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(RealtimeStockDetailExcelEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    protected void doExport(RealtimeStockDetailExcelEvent event, BiReportPo report, boolean flag) {
        RealtimeStockRequest request = (RealtimeStockRequest) redisTemplate.opsForValue().get(event.getKey());
        //购买记录分开查询
        List<WhProductStockDetailVo> stockDetails = stockMapper.queryRealtimeStockDetail(request);
        //数据写入到字节流
        ExcelWriter excelWriter = EasyExcel.write(report.getFilePath())
                .inMemory(true)
                .build();
        WriteSheet writeSheet = EasyExcel.writerSheet("第1～" + stockDetails.size() + "条")
                .sheetNo(0)
                .head(WhProductStockVo.class)
                .registerWriteHandler(new ColumnWidthStyleStrategy())
                .automaticMergeHead(true)
                .build();
        excelWriter.write(stockDetails, writeSheet);
        ExcelImgUtils.CreatImgSheet(imgPath, report.getPicUrl(), excelWriter);
        excelWriter.finish();
    }
}
