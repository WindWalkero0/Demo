package com.ruihe.admin.request;

import com.ruihe.common.annotation.EnumValidation;
import com.ruihe.common.enums.sat.SatSubjectRangeEnum;
import com.ruihe.common.enums.sat.SatSubjectTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

/**
 * @author LiangYuan
 * @date 2021-03-10 9:38
 */
@ApiModel(value = "SatQunSubjectVo", description = "问卷题目请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class SatQunSubjectRequest implements Serializable {

    @ApiModelProperty(value = "问卷题目ID，有就传，没有就不传")
    private String id;

    @NotNull(message = "排序序号不能为空")
    @ApiModelProperty(value = "排序序号")
    private Integer sqsNo;

    @NotNull(message = "题目不能为空")
    @ApiModelProperty(value = "题目")
    private String subject;

    @NotNull(message = "题目范围不能为空")
    @EnumValidation(clazz = SatSubjectRangeEnum.class, method = "getKey", message = "题目范围错误")
    @ApiModelProperty(value = "题目范围：1禁令题、2引导题、3总体评价")
    private Integer subjectRange;

    @NotNull(message = "选项类型不能为空")
    @EnumValidation(clazz = SatSubjectTypeEnum.class, method = "getKey", message = "选项类型错误")
    @ApiModelProperty(value = "选项类型：1单选、2多选、3问答题、4判断题、5五星评分题")
    private Integer subjectType;

    @NotNull(message = "选项必填不能为空")
    @ApiModelProperty(value = "选项必填：0否，1是(题型为问答题)")
    private Integer required;

    @Size(max = 50, message = "文字提示最大长度为50个字符")
    @ApiModelProperty(value = "问答题的文字提示")
    private String remark;

    @Valid
    @ApiModelProperty(value = "题目选项列表")
    private List<SatQunOptionRequest> optionRequestList;
}
