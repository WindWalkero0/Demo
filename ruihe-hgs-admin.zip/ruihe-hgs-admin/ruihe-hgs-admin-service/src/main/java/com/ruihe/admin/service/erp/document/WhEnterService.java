package com.ruihe.admin.service.erp.document;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.service.bi.AbstractBiReportPreHandler;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.warehouse.WhAuditPo;
import com.ruihe.common.dao.bean.warehouse.WhEnterItemPo;
import com.ruihe.common.dao.bean.warehouse.WhEnterPo;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.admin.enums.BiReportEnum;
import com.ruihe.admin.event.dispatchExcelEvent;
import com.ruihe.admin.event.dispatchItemExcelEvent;
import com.ruihe.admin.mapper.basic.CounterMapper;
import com.ruihe.admin.mapper.basic.ProductMapper;
import com.ruihe.admin.mapper.erp.document.WhAuditMapper;
import com.ruihe.admin.mapper.erp.document.WhEnterItemMapper;
import com.ruihe.admin.mapper.erp.document.WhEnterMapper;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.request.erp.WhEnterRequest;
import com.ruihe.admin.response.erp.WhEnterQueryResponse;
import com.ruihe.admin.response.erp.WhEnterResponse;
import com.ruihe.admin.response.erp.WhEnterResultResponse;
import com.ruihe.admin.vo.WhEnterItemVo;
import com.ruihe.admin.vo.WhEnterVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * 进销存-发货单处理
 *
 * @Anthor:Fangtao
 * @Date:2020/3/10 10:03
 */
@Service
@Slf4j
public class WhEnterService extends AbstractBiReportPreHandler {

    @Autowired
    private WhEnterMapper whEnterMapper;

    @Autowired
    private WhEnterItemMapper whEnterItemMapper;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private WhAuditMapper whAuditMapper;

    /**
     * 存储域
     */
    private static final String KEY = "ADMIN:ENTER";

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    /**
     * 发货单处理多条件查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectEnter(WhEnterRequest request) {
        //对日期和页码进行判断
        if (request.getStartTime() != null && request.getEndTime() != null && request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("开始时间不能大于结束时间!");
        }
        if (request.getPageNumber() == null || request.getPageSize() == null || request.getPageSize() == 0 || request.getPageNumber() == 0) {
            return Response.errorMsg("页码不合法!");
        }
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        //获取组织条件查询
        OrgQueryConditionRequest queryRequest = request.getOrgQueryConditionRequest();
        //柜台的状态、类型跟部门的不一致，此处需要转换
        if (queryRequest != null && queryRequest.getOrgType() != null) {
            queryRequest.setOrgType(queryRequest.getOrgType().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CounterEnum.FORMAL_COUNTER.getKey() : CounterEnum.TEST_COUNTER.getKey());
        }
        if (queryRequest != null && queryRequest.getOrgStatus() != null) {
            queryRequest.setOrgStatus(queryRequest.getOrgStatus().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CommonStatusEnum.INVALID.getCode() : CommonStatusEnum.EFFECTIVE.getCode());
        }
        //设置分页条件
        Page<WhEnterQueryResponse> page = new Page<>(request.getPageNumber(), request.getPageSize());

        String uuid = IdGenerator.getRandomId(KEY, 6);
        request.setOrgQueryConditionRequest(queryRequest);
        redisTemplate.opsForValue().set(uuid, request, 1, TimeUnit.HOURS);

        IPage<WhEnterQueryResponse> voList = whEnterMapper.queryEnterNo(page, request, queryRequest);
        //分页展示vo
        PageVO pageVO = PageVO.<WhEnterQueryResponse>builder()
                .list(voList.getRecords())
                .pageNum(voList.getCurrent())
                .pageSize(voList.getSize())
                .pages(voList.getPages())
                .total(voList.getTotal())
                .build();

        WhEnterResultResponse whEnterResultResponse = whEnterMapper.queryResult(request, queryRequest);
        return Response.success(WhEnterResponse.builder()
                .whEnterResultResponse(whEnterResultResponse)
                .key(uuid)
                .pageVo(pageVO).build());
    }


    /**
     * 根据发货单查看详情
     *
     * @param deliveryNo
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectItem(String deliveryNo) {
        //获取主表数据
        WhEnterPo whEnterPo = whEnterMapper.selectOne(Wrappers.<WhEnterPo>lambdaQuery()
                .eq(WhEnterPo::getDeliveryNo, deliveryNo));
        //查询子表信息
        List<WhEnterItemPo> whEnterItemPoList = whEnterItemMapper.selectList(Wrappers.<WhEnterItemPo>lambdaQuery()
                .eq(WhEnterItemPo::getEnterNo, whEnterPo.getEnterNo()));

        WhEnterVo whEnterVo = ObjectUtils.toObject(whEnterPo, WhEnterVo.class);
        whEnterVo.setItemVoList(ObjectUtils.toList(whEnterItemPoList, WhEnterItemVo.class));

        WhEnterVo total = whEnterItemPoList.parallelStream()
                .map(e -> WhEnterVo.builder().totalAmt(e.getMemberPrice().multiply(BigDecimal.valueOf(e.getRealQty()))).totalQty(e.getRealQty()).build())
                .reduce((acc, item) -> {
                    acc.setTotalQty(item.getTotalQty() + acc.getTotalQty());
                    acc.setTotalAmt(item.getTotalAmt().add(acc.getTotalAmt()));
                    return acc;
                }).get();
        whEnterItemPoList.stream().map(e -> {
            WhEnterItemVo whEnterItemVo = new WhEnterItemVo();
            BeanUtils.copyProperties(e, whEnterItemVo);
            Product product = productMapper.selectOne(Wrappers.<Product>lambdaQuery().eq(Product::getPrdBarCode, e.getPrdBarCode()));
            whEnterItemVo.setUnitName(product.getUnitName());
            whEnterItemVo.setSpec(product.getSpec());
            return whEnterItemVo;
        }).collect(Collectors.toList());
        CounterInformation counterInformation = counterMapper.selectById(whEnterPo.getCounterId());
        whEnterVo.setCounterAddress(counterInformation.getCounterAddress());
        whEnterVo.setTotalAmt(total.getTotalAmt());
        whEnterVo.setTotalQty(total.getTotalQty());
        return Response.success(whEnterVo);
    }

    /**
     * 单据流程
     *
     * @param enterNo
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response enterAudit(String enterNo) {
        List<WhAuditPo> auditPoList = whAuditMapper.selectList(Wrappers.<WhAuditPo>lambdaQuery()
                .eq(WhAuditPo::getApplyNo, enterNo)
                //审核单号非空
                //.isNotNull(WhAuditPo::getAuditNo)
                //根据id升序排序
                .orderByAsc(WhAuditPo::getId));
        return Response.success(auditPoList);
    }


    /**
     * 单据流程->点击单号查看详情
     *
     * @param enterNo
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response docuFlow(String enterNo) {
        //获取主表数据
        WhEnterPo whEnterPo = whEnterMapper.selectOne(Wrappers.<WhEnterPo>lambdaQuery()
                .eq(WhEnterPo::getEnterNo, enterNo));
        //查询子表信息
        List<WhEnterItemPo> whEnterItemPoList = whEnterItemMapper.selectList(Wrappers.<WhEnterItemPo>lambdaQuery()
                .eq(WhEnterItemPo::getEnterNo, whEnterPo.getEnterNo()));

        WhEnterVo total = whEnterItemPoList.parallelStream()
                .map(e -> WhEnterVo.builder().totalAmt(e.getMemberPrice().multiply(BigDecimal.valueOf(e.getRealQty()))).totalQty(e.getRealQty()).build())
                .reduce((acc, item) -> {
                    acc.setTotalQty(item.getTotalQty() + acc.getTotalQty());
                    acc.setTotalAmt(item.getTotalAmt().add(acc.getTotalAmt()));
                    return acc;
                }).get();

        WhEnterVo whEnterVo = ObjectUtils.toObject(whEnterPo, WhEnterVo.class);
        whEnterVo.setItemVoList(ObjectUtils.toList(whEnterItemPoList, WhEnterItemVo.class));

        whEnterItemPoList.stream().map(e -> {
            WhEnterItemVo whEnterItemVo = new WhEnterItemVo();
            BeanUtils.copyProperties(e, whEnterItemVo);
            Product product = productMapper.selectOne(Wrappers.<Product>lambdaQuery().eq(Product::getPrdBarCode, e.getPrdBarCode()));
            whEnterItemVo.setUnitName(product.getUnitName());
            whEnterItemVo.setSpec(product.getSpec());
            return whEnterItemVo;
        }).collect(Collectors.toList());
        CounterInformation counterInformation = counterMapper.selectById(whEnterPo.getCounterId());
        whEnterVo.setCounterAddress(counterInformation.getCounterAddress());
        whEnterVo.setTotalAmt(total.getTotalAmt());
        whEnterVo.setTotalQty(total.getTotalQty());
        return Response.success(whEnterVo);
    }

    public Response exportTable(String key, String remark, String picUrl) {
        //根据条件查询数据
        WhEnterRequest whEnterRequest = (WhEnterRequest) redisTemplate.opsForValue().get(key);
        //判空
        if (whEnterRequest == null) {
            return Response.error("查询条件不存在请重试！");
        }
        try {
            Long aLong = whEnterMapper.queryEnterCount(whEnterRequest, whEnterRequest.getOrgQueryConditionRequest());
            if (aLong > 50000) {
                return Response.error("只支持5w条导出");
            }
            dispatchExcelEvent event = dispatchExcelEvent.builder().key(key).build();
            publishEvent(BiReportEnum.WH_ENTER, event, remark, picUrl);
            return Response.successMsg("提交成功，请至下载中心下载");
        } catch (Exception e) {
            log.error("发货单导出异常,request={}", whEnterRequest, e);
        }
        return null;
    }

    public Response exportItemTable(String key, String remark, String picUrl) {
        //根据条件查询数据
        WhEnterRequest whEnterRequest = (WhEnterRequest) redisTemplate.opsForValue().get(key);
        //判空
        if (whEnterRequest == null) {
            return Response.error("查询条件不存在请重试！");
        }
        try {
            Long aLong = whEnterMapper.queryEnterItemCount(whEnterRequest, whEnterRequest.getOrgQueryConditionRequest());
            if (aLong > 50000) {
                return Response.error("只支持5w条导出");
            }
            dispatchItemExcelEvent event = dispatchItemExcelEvent.builder().key(key).build();
            publishEvent(BiReportEnum.WH_ENTER_DETAIL, event, remark, picUrl);
            return Response.successMsg("提交成功，请至下载中心下载");
        } catch (Exception e) {
            log.error("发货单导出异常,request={}", whEnterRequest, e);
        }
        return null;
    }
}
