package com.ruihe.admin.listener.report.utils;

import com.google.common.base.CaseFormat;
import com.ruihe.admin.listener.report.core.Column;
import com.ruihe.admin.listener.report.core.ColumnDefine;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Map;

@Slf4j
public class FieldUtils {

    public static Object read(Object target, String fieldName) {
        if (target instanceof Map) {
            return ((Map<String, Object>) target).get(fieldName);
        } else {
            Field field = findField(target, fieldName);
            field.setAccessible(true);
            return ReflectionUtils.getField(field, target);
        }
    }

    public static Object read(Object target, String fieldName, Object defaultVal) {
        Object val = read(target, fieldName);
        return val == null ? defaultVal : val;
    }

    public static String readString(Object target, String fieldName) {
        Object val = read(target, fieldName);
        return val == null ? null : String.valueOf(val);
    }

    public static String readGroupValue(Object target, Column column, String defaultValue) {
        if (!column.getGroup().contains(camel2under(column.getName()))) {
            String groupFieldName = column.getGroup().replace(ColumnDefine.ALIAS, "");
            groupFieldName = under2camel(groupFieldName);
            return readString(target, groupFieldName, defaultValue);
        }
        return defaultValue;
    }

    public static String readString(Object target, String fieldName, String defaultVal) {
        Object val = read(target, fieldName);
        return val == null ? defaultVal : String.valueOf(val);
    }

    public static void write(Object target, String fieldName, Object value) {
        Field field = findField(target, fieldName);
        field.setAccessible(true);
        ReflectionUtils.setField(field, target, value);
    }

    private static Field findField(Object target, String fieldName) {
        Field field = ReflectionUtils.findField(target.getClass(), fieldName);
        if (field == null) {
            throw new RuntimeException("field not found class " + target.getClass() + " column " + fieldName);
        }
        return field;
    }

    public static Object defaultValue(Class<?> cls) {
        if (cls.equals(Integer.class)) {
            return 0;
        } else if (cls.equals(Double.class)) {
            return 0.0;
        } else if (cls.equals(Float.class)) {
            return 0.0;
        } else if (cls.equals(Long.class)) {
            return 0;
        } else if (cls.equals(BigDecimal.class)) {
            return BigDecimal.ZERO;
        } else if (cls.equals(BigInteger.class)) {
            return BigInteger.ZERO;
        } else if (cls.equals(String.class)) {
            return "";
        }
        throw new UnsupportedOperationException("Unsupported class " + cls.getName());
    }

    public static String camel2under(String name) {
        return CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, name);
    }

    private static String under2camel(String columnName) {
        return CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, columnName);
    }
}
