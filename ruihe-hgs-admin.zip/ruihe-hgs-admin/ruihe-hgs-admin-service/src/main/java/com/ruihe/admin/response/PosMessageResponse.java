package com.ruihe.admin.response;

import com.alibaba.fastjson.JSONArray;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Future;
import java.io.Serializable;
import java.time.LocalDateTime;

@ApiModel(value = "PosMessageResponse", description = "消息响应实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosMessageResponse implements Serializable {

    @ApiModelProperty(value = "消息id")
    private Integer msgId;

    @ApiModelProperty(value = "消息序号")
    private Integer seq;

    @ApiModelProperty(value = "消息标题")
    private String title;

    @ApiModelProperty(value = "正文")
    private String content;

    @ApiModelProperty(value = "最后修改用户ID")
    private String lastModifyUserId;

    @ApiModelProperty(value = "最后修改用户Name")
    private String lastModifyUserName;

    @ApiModelProperty(value = "定时发送时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime sendTime;

    @ApiModelProperty(value = "消息有效期结束时间")
    @Future(message = "消息有效期结束时间必须是将来时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endTime;

    @ApiModelProperty(value = "状态")
    private Integer status;

    @ApiModelProperty(value = "消息接收地点")
    JSONArray placeInfo;

    @ApiModelProperty(value = "消息创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "最近更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    @ApiModelProperty(value = "回显字段")
    private String showDescription;
}
