package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author LiangYuan
 * @date 2021-03-10 9:38
 */
@ApiModel(value = "SatQunOptionVo", description = "问卷题目选项请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class SatQunOptionRequest implements Serializable {

    @ApiModelProperty(value = "问卷选项ID，有就传")
    private Integer id;

    @ApiModelProperty(value = "问卷问题id，有就传")
    private String sqsId;

    @NotNull(message = "选项排序不能为空")
    @ApiModelProperty(value = "选项排序")
    private String optionNo;

    @Size(max = 50, message = "答案最大长度为50个字符")
    @ApiModelProperty(value = "选项答案/问卷答案")
    private String description;

    @NotNull(message = "分数不能为空")
    @ApiModelProperty(value = "分数")
    private BigDecimal score;
}
