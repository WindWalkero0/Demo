package com.ruihe.admin.listener.excel;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.google.common.collect.Lists;
import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.FreeInvMasterExcelEvent;
import com.ruihe.admin.listener.style.CellStyleUtils;
import com.ruihe.admin.listener.style.CustomHorizontalCellStyleStrategy;
import com.ruihe.admin.mapper.erp.document.WhFreeInventoryMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.request.erp.WhFreeInventoryQueryRequest;
import com.ruihe.admin.response.erp.FreeInvMasterExcelResponse;
import com.ruihe.admin.utils.ColumnWidthStyleStrategy;
import com.ruihe.admin.utils.ExcelImgUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

/***
 * 盘点主表excel导出
 * @author ly
 */
@Slf4j
@Component
public class FreeInvMasterExcelListener extends AbstractReportListener<FreeInvMasterExcelEvent> {

    @Autowired
    private WhFreeInventoryMapper whFreeInventoryMapper;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(FreeInvMasterExcelEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    protected void doExport(FreeInvMasterExcelEvent event, BiReportPo report, boolean flag) {
        //根据条件查询数据
        WhFreeInventoryQueryRequest request = (WhFreeInventoryQueryRequest) redisTemplate.opsForValue().get(event.getKey());
        //输出格式
        List<Class<?>> dataTypes = getDataTypesList();
        CustomHorizontalCellStyleStrategy cellStyle = CellStyleUtils.customHorizontalCellStyleStrategy(FreeInvMasterExcelResponse.class, dataTypes);
        //获取导出实体list
        List<FreeInvMasterExcelResponse> list = whFreeInventoryMapper.masterListExcel(request, request.getOrgQueryConditionRequest());
        //excel导出
        ExcelWriter excelWriter = EasyExcel.write(report.getFilePath())
                .inMemory(true)
                .build();
        WriteSheet writeSheet = EasyExcel.writerSheet("第1～" + list.size() + "条")
                .sheetNo(0)
                .head(FreeInvMasterExcelResponse.class)
                .registerWriteHandler(cellStyle)
                .registerWriteHandler(new ColumnWidthStyleStrategy())
                .automaticMergeHead(true)
                .build();
        excelWriter.write(list, writeSheet);
        //查询图片
        ExcelImgUtils.CreatImgSheet(this.imgPath, report.getPicUrl(), excelWriter);
        //释放资源
        excelWriter.finish();
    }

    /**
     * 数据类型设置
     *
     * @return
     */
    private List<Class<?>> getDataTypesList() {
        List<Class<?>> dataType = Lists.newArrayList();
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(Integer.class);
        dataType.add(Integer.class);
        dataType.add(String.class);
        dataType.add(BigDecimal.class);
        dataType.add(String.class);
        dataType.add(String.class);
        return dataType;
    }

}
