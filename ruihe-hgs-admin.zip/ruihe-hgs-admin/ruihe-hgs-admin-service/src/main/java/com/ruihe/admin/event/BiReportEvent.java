package com.ruihe.admin.event;

import com.ruihe.admin.po.BiReportPo;
import com.ruihe.common.pojo.context.AdminSessionInfo;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public abstract class BiReportEvent {

    /**
     * 报表实体
     */
    protected BiReportPo report;

    /**
     * 操作员
     */
    protected AdminSessionInfo optor;

    /**
     * 事件触发时间
     */
    protected LocalDateTime fireTime = LocalDateTime.now();

}
