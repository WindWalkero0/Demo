package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-01 14:35
 */
@ApiModel(value = "CommonDeptRequest", description = "通用部门查询请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class CommonDeptRequest implements Serializable {

    @ApiModelProperty(value = "部门代码/部门名称模糊查询条件")
    private String dept;

    @ApiModelProperty(value = "状态---页面没有的时候需要传1，默认选择有效的部门")
    private Integer status;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
