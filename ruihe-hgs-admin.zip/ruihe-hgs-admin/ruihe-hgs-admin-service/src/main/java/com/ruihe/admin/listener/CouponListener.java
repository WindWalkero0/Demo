package com.ruihe.admin.listener;


import com.ruihe.common.annotation.Ella;
import com.ruihe.common.service.AsynchronousService;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.CouponEvent;
import com.ruihe.admin.event.JoinActivityEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;


@Ella(Describe = "发放优惠券", Author = "K")
@Slf4j
@Component
public class CouponListener {

    @Autowired
    private AsynchronousService asynchronousService;


    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(CouponEvent event) {
        try {
            log.info("所有优惠券发放----");
            asynchronousService.addDataCoupon(event.getActivityType());
        } catch (Exception e) {
            log.error("优惠券核发--针对全部会员全部有效活动且未过期的活动.error", e);
        }
    }

    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    //@TransactionalEventListener(fallbackExecution = true)
    @EventListener
    public void onApplicationEvent2(JoinActivityEvent event) {
        try {
            log.info("会员入会礼发券调用----.{}", event);
            asynchronousService.addDataCoupon(event.getActivityType());
        } catch (Exception e) {
            log.error("优惠券核发--针对全部会员全部有效活动且未过期的活动.error", e);
        }
    }

}
