package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 产品销售记录查询
 *
 * @author fly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class SaleExcelEvent extends BiReportEvent {

    private String key;
    private String yes;

    @Builder
    public SaleExcelEvent(String key,String yes) {
        this.key = key;
        this.yes = yes;
    }
}
