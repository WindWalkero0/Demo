package com.ruihe.admin.event;

import com.ruihe.admin.request.bi.ProductBizDetailReportRequest;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class ReportProductBizDetailEvent extends BiReportEvent {

    private ProductBizDetailReportRequest request;

    @Builder
    public ReportProductBizDetailEvent(ProductBizDetailReportRequest request) {
        this.request = request;
    }
}
