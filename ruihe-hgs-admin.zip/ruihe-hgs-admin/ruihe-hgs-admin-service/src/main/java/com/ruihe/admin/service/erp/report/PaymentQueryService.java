package com.ruihe.admin.service.erp.report;

import com.ruihe.common.response.Response;
import com.ruihe.admin.request.erp.PaymentReportRequest;
import reactor.core.publisher.Mono;


/**
 * @author William
 */
public interface PaymentQueryService {

    /**
     * 分页查询支付方式
     *
     * @param request
     * @return
     */
    Mono<Response> list(PaymentReportRequest request);

    /**
     * 支付方式明细查询
     *
     * @param orderId
     * @return
     */
    Mono<Response> detail(String orderId);

}
