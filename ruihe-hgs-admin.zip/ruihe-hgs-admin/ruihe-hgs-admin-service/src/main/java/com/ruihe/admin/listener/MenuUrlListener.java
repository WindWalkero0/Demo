package com.ruihe.admin.listener;


import com.ruihe.admin.service.basic.JurisdictionService;
import com.ruihe.common.dao.bean.base.MenuMation;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.MenuUrlEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Ella(Describe = "当菜单权限修改以后,进行更新", Author = "K")
@Slf4j
@Component
public class MenuUrlListener implements ApplicationListener<MenuUrlEvent> {

    @Autowired
    private JurisdictionService jurisdictionService;


    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    public void onApplicationEvent(MenuUrlEvent event) {
        List<String> list = new ArrayList<>();
        //先删除所有的url
        List<MenuMation> menuMations = jurisdictionService.selectMenus(MenuMation.builder().menuParentUid("0").menuStatus(0).build());
        if (!menuMations.isEmpty()) {
            menuMations.stream().forEach(menuMation -> {
                jurisdictionService.selectSon(menuMation, list);
            });
        }
    }

}
