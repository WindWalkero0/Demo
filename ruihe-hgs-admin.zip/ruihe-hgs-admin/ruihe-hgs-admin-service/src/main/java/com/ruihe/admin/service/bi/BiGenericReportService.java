package com.ruihe.admin.service.bi;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.bean.base.UserConcernPo;
import com.ruihe.common.dao.bean.bi.BiGenericReport;
import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;
import com.ruihe.common.response.Response;
import com.ruihe.admin.enums.BiReportEnum;
import com.ruihe.admin.event.Report4GenericEvent;
import com.ruihe.admin.mapper.basic.UserConcernMapper;
import com.ruihe.admin.mapper.bi.BiGenericReportMapper;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class BiGenericReportService extends AbstractBiReportPreHandler {
    private final BiGenericReportMapper genericReportMapper;
    private final UserConcernMapper userConcernMapper;
    private final BiReportService biReportService;

    /**
     * 生成报表菜单
     */
    public Response menu() {
        List<BiGenericReport> list = genericReportMapper.selectList(null);
        return Response.success(list);
    }

    /**
     * 保存报表配置信息
     */
    public Response save(BiGenericReport report) {
        if (StringUtils.isBlank(report.getSqlTpl())) {
            return Response.error("sql模板不能为空");
        }
        if (StringUtils.isBlank(report.getName())) {
            return Response.error("报表名称不能为空");
        }
        if (report.getId() == null) {
            int exist = genericReportMapper.selectCount(
                    Wrappers.lambdaQuery(BiGenericReport.class)
                            .eq(BiGenericReport::getName, report.getName())
            );
            if (exist > 0) {
                return Response.error("同名报表已经存在");
            }
            genericReportMapper.insert(report);
        } else {
            int exist = genericReportMapper.selectCount(
                    Wrappers.lambdaQuery(BiGenericReport.class)
                            .eq(BiGenericReport::getName, report.getName())
                            .ne(BiGenericReport::getId, report.getId())
            );
            if (exist > 0) {
                return Response.error("同名报表已经存在");
            }
            genericReportMapper.updateById(report);
        }
        return Response.success();
    }

    public Response export(Map<String, String> request) {
        String reportId = request.get("report_id");
        if (StringUtils.isBlank(reportId)) {
            return Response.errorMsg("参数错误!");
        }
        BiGenericReport biGenericReport = genericReportMapper.selectById(Integer.valueOf(reportId));
        if (biGenericReport == null) {
            return Response.errorMsg("报表模板未找到! " + reportId);
        }

        String picUrl = request.get("pic_url");
        String tag = request.get("tag");
        if (StringUtils.isBlank(tag)) {
            return Response.errorMsg("参数错误!tag必填");
        }else if(tag.length()>30){
            return Response.errorMsg("标签最大长度为30个字符");
        }

        //获取到当前登录人的信息查询关注部门信息
        List<UserConcernPo> concernPoList = userConcernMapper.selectList(
                Wrappers.<UserConcernPo>lambdaQuery()
                        .eq(UserConcernPo::getEmpId, AdminUserContextHolder.get().getEmpId())
        );
        //如果关注部门为空，则返回空
        if (concernPoList.isEmpty()) {
            return Response.errorMsg("该账号未关注任何部门，请关注后再查询!");
        }

        Integer count = biReportService.getBiReport();
        if (count > 2) {
            return Response.errorMsg("您已有两个报表导出任务，请稍后再导出该报表!");
        }

        //发射导出事件
        Report4GenericEvent event = new Report4GenericEvent(request);
        event.setBiGenericReport(biGenericReport);
        publishEvent(BiReportEnum.GENERIC, event, tag, picUrl);
        return Response.success();
    }
}
