package com.ruihe.admin.dto;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 终端管理升级管理实体,
 * 终端管理升级逻辑,
 * versionCode:
 * 1、门店app > 服务器端app  --》强制更新降级处理；
 * 2、门店app = 服务器端app  --》不更新也不提示；
 * 3、门店app < 服务器端app  --》根据forceUpgrade配置相应处理更新
 */
@ApiModel(value = "PosUpgradeDto", description = "app升级实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosUpgradeDto implements Serializable {

    @ApiModelProperty(value = "平台，Android安卓,iOS")
    private String platform;

    @ApiModelProperty(value = "app更新url")
    private String upgradeUrl;

    @ApiModelProperty(value = "强制升级标识,Y强制,O提示更新")
    private String forceUpgrade;

    @ApiModelProperty(value = "提示更新频率,0是每天第一次打开提示,1是每次打开提示")
    private Integer tipsFreq;

    @ApiModelProperty(value = "更新说明")
    private String tips;

    @ApiModelProperty(value = "最新版本号")
    private String appVersion;

    @ApiModelProperty(value = "解析apk的code，有序的", hidden = true)
    private Integer versionCode;
}
