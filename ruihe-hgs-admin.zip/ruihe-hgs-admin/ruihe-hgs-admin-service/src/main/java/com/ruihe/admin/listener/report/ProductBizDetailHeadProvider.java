package com.ruihe.admin.listener.report;

import com.ruihe.admin.event.ReportProductBizDetailEvent;
import com.ruihe.admin.listener.report.core.HeadProvider;
import com.ruihe.admin.listener.report.core.HeadProviderByQuery;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.admin.mapper.bi.PrdDetailReportMapper;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

public class ProductBizDetailHeadProvider extends HeadProviderByQuery implements HeadProvider {
    private final PrdDetailReportMapper mapper;
    private final ReportProductBizDetailEvent event;

    public ProductBizDetailHeadProvider(PrdDetailReportMapper mapper, TableDefine define, ReportProductBizDetailEvent event) {
        super(define);
        this.mapper = mapper;
        this.event = event;
    }

    @Override
    protected List<?> queryHeadData() {
        String headSelect = define.headSelectCols();
        if (StringUtils.isEmpty(headSelect)) {
            return null;
        }
        return mapper.prdBizDetailHead(
                event.getRequest(),
                headSelect,
                define.headGroupCols());
    }

}
