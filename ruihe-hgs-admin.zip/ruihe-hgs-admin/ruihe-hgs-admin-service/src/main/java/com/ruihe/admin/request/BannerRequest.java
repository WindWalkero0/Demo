package com.ruihe.admin.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDateTime;

@ApiModel(value = "BannerRequest", description = "新增轮播图实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BannerRequest implements Serializable {
    @ApiModelProperty(value = "banner标题")
    @Size(max = 300,message = "banner标题最大长度为300个字符")
    private String title;
    @ApiModelProperty(value = "所属模块")
    private String bannerType;
    @ApiModelProperty(value = "链接url")
    @Size(max = 300,message = "链接url最大长度为300个字符")
    private String linkUrl;
    @ApiModelProperty(value = "排序序号")
    private Integer sortNum;
    @ApiModelProperty(value = "状态：0有效,1无效")
    private Integer status;
    @ApiModelProperty(value = "图片跳转href")
    private String imgUrl;
}
