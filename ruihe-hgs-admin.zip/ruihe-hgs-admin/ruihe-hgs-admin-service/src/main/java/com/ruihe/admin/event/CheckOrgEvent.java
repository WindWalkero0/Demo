package com.ruihe.admin.event;


import com.ruihe.common.annotation.Ella;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Ella(Describe = "校验订单柜台组织结构信息")
@Data
@EqualsAndHashCode(callSuper = false)
public class CheckOrgEvent {

}
