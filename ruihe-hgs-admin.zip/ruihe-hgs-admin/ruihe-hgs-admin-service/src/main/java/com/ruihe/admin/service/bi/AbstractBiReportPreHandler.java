package com.ruihe.admin.service.bi;


import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;;
import com.ruihe.common.utils.IdUtil;
import com.ruihe.admin.enums.BiReportEnum;
import com.ruihe.admin.event.BiReportEvent;
import com.ruihe.admin.event.Report4GenericEvent;
import com.ruihe.admin.mapper.bi.BiReportMapper;
import com.ruihe.admin.po.BiReportPo;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public abstract class AbstractBiReportPreHandler implements ApplicationContextAware {

    @Autowired
    private BiReportMapper biReportMapper;

    @Value("${file-upload.disk-root-path}bi/%s.xlsx")
    protected String filePath;

    @Value("${file-upload.disk-root-path}bi/")
    protected String rootPath;

    @Value("${file-upload.static-root-url}")
    protected String staticRootUrl;
    /**
     * excel 模板uri
     */
    private static final String uri = "/bi/%s.xlsx";

    private ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    public ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    public void publishEvent(BiReportEnum biReportEnum, BiReportEvent event, String tag, String picUrl) {
        String reportName = biReportEnum.getMsg().concat(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")));
        if (picUrl != null && !"".equals(picUrl)) {
            picUrl = picUrl.replace(staticRootUrl + "/", "");
        }
        //插入初始状态的t_bi_report
        String name = biReportEnum == BiReportEnum.GENERIC ?
                ((Report4GenericEvent) event).getBiGenericReport().getName()
                : reportName;
        Long reportId = IdUtil.nextId();
        BiReportPo report = BiReportPo.builder()
                .reportId(reportId)
                .reportName(name)
                .uid(AdminUserContextHolder.get().getEmpId())
                .filePath(String.format(filePath, name))
                .url(String.format(uri, name))
                .status(0)
                .tag(tag)
                .picUrl(picUrl)
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
        biReportMapper.insert(report);
        event.setReport(report);
        event.setOptor(AdminUserContextHolder.get());
        this.applicationContext.publishEvent(event);
    }

    public void publishEvent(Object event) {
        this.applicationContext.publishEvent(event);
    }
}
