package com.ruihe.admin.event;


import com.ruihe.common.annotation.Ella;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

@Ella(Describe = "菜单权限更新")
@Data
@EqualsAndHashCode(callSuper = false)
public class MenuUrlEvent extends ApplicationEvent {


    public MenuUrlEvent(Object source) {
        super(source);
    }

}
