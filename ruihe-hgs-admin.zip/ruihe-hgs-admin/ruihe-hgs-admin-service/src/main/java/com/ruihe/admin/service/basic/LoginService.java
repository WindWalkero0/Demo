package com.ruihe.admin.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.common.dao.bean.base.AccountRole;
import com.ruihe.common.dao.bean.base.RoleMenu;
import com.ruihe.common.dao.bean.base.UserInformation;
import com.ruihe.common.dao.bean.bi.BiGenericReport;
import com.ruihe.common.dao.bean.login.UserAccount;
import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.pojo.request.base.ChangePasswordRequest;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.MD5;
import com.ruihe.common.utils.UUIDUtils;
import com.ruihe.admin.mapper.bi.BiGenericReportMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class LoginService {
    private final BiGenericReportMapper genericReportMapper;
    private final CustomService customService;
    private final JurisdictionService jurisdictionService;
    private final RedisTemplate<Object, Object> redisTemplate;

    /**
     * 存储域
     */
    private final String KEY = "ADMIN:ROLE_ACCOUNT";


    /**
     * 账号登录校验
     *
     * @param userAccount
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response accountLogin(UserAccount userAccount) {
        try {
            //查询账号是否存在
            UserAccount userAccountOne = selectAccount(userAccount.getAccount());
            if (userAccountOne == null) {
                return Response.errorMsg(StatusEnum.USER_ACCOUNT_NULL.getKey(), StatusEnum.USER_ACCOUNT_NULL.getValue());
            }
            //进行密码比对
            if (!(userAccountOne.getPassword().equals(userAccount.getPassword()))) {
                return Response.errorMsg(StatusEnum.USER_ACCOUNT_PASSWORD_ERROR.getKey(), StatusEnum.USER_ACCOUNT_PASSWORD_ERROR.getValue());
            }
            //将用户信息和权限返回给前端
            UserInformation userInformation = selectUserInformation(userAccountOne.getUserId());
            //获取权限
            List<RoleMenu> roleMenus = (List<RoleMenu>) redisTemplate.opsForHash().get(KEY, userInformation.getEmpId());
            if (roleMenus == null || roleMenus.isEmpty()) {
                roleMenus = new ArrayList<>();
                //继续查询
                List<AccountRole> accountRoles = jurisdictionService.selectAccount(userInformation.getEmpId());
                for (AccountRole accountRole : accountRoles) {
                    List<RoleMenu> roleMenus1 = jurisdictionService.selectByRoleUid(accountRole.getRoleUid());
                    if (!roleMenus1.isEmpty()) {
                        roleMenus.addAll(roleMenus1);
                    }
                }
                //进行存储
                redisTemplate.opsForHash().put(KEY, userInformation.getEmpId(), roleMenus);
            }
            //将用户uid存储到cookie
            String uuid = "COOKIE:" + UUIDUtils.uuid();
            //存储redis
            redisTemplate.opsForValue().set(uuid, userAccount.getAccount(), 8, TimeUnit.HOURS);

            List<RoleMenu> finalRoleMenus = roleMenus;
            List<BiGenericReport> genericReport = genericReportMapper.all()
                    .stream()
                    .filter(e -> deepSearch(finalRoleMenus, e.getPath()))
                    .peek(e-> e.setSqlTpl(""))
                    .collect(Collectors.toList());
            Map<String, Object> data = new HashMap<>();
            data.put("user", userInformation);
            data.put("menus", roleMenus);
            data.put("bi_generic", genericReport);
            data.put("uuid", uuid);
            return Response.success(data);
        } catch (Exception e) {
            log.error(LoginService.class.getName() + ".accountLogin(),userId={}", userAccount.getUserId(), e);
            return Response.errorMsg(StatusEnum.ERROR.getValue());
        }
    }

    private boolean deepSearch(List<RoleMenu> menus, String path) {
        for (RoleMenu menu : menus) {
            if (menu.getMenuUrl().equals(path)) return true;
            if (menu.getRoleMenuList() != null) {
                boolean found = deepSearch(menu.getRoleMenuList(), path);
                if (found) return true;
            }
        }
        return false;
    }

    /**
     * 根据账号查询用户是否存在
     */
    private UserAccount selectAccount(String account) {
        return customService.select(UserAccount.builder()
                .account(account)
                .status(CommonStatusEnum.EFFECTIVE.getCode())
                .build());
    }

    /**
     * 根据userId查询用户信息
     */
    private UserInformation selectUserInformation(String uid) {
        UserInformation build = UserInformation.builder()
                .empId(uid)
                .status(CommonStatusEnum.EFFECTIVE.getCode())
                .build();
        return (UserInformation) customService.select(build);
    }

    /**
     * 根据账号查询权限
     */
    private List<RoleMenu> selectRoleMenu(String userUid) {
        //查询角色集合
        List<AccountRole> accountRoles = jurisdictionService.selectAccount(userUid);
        List<RoleMenu> roleMenus = null;
        if (accountRoles.isEmpty()) {
            return new ArrayList<>();
        }
        for (AccountRole accountRole : accountRoles) {
            roleMenus = jurisdictionService.selectByRoleUid(accountRole.getRoleUid());
        }
        return roleMenus;
    }


    @DS(DBConst.MASTER)
    public Response changePassword(ChangePasswordRequest changePasswordRequest) {
        try {
            //查询账号是否存在
            if (changePasswordRequest.getOldPassword() == null){
                return Response.errorMsg("请输入当前登录密码");
            }
            if (changePasswordRequest.getNewPassword() == null){
                return Response.errorMsg("请输入新密码");
            }
            if (changePasswordRequest.getCheckPassword() == null){
                return Response.errorMsg("请再次输入新密码");
            }
            var userInformation = AdminUserContextHolder.get();
            UserAccount userAccountOne = customService.select(UserAccount.builder().userId(userInformation.getEmpId()).status(CommonStatusEnum.EFFECTIVE.getCode()).build());
            if (userAccountOne == null) {
                return Response.errorMsg(StatusEnum.USER_ACCOUNT_NULL.getKey(), StatusEnum.USER_ACCOUNT_NULL.getValue());
            }
            //进行密码比对
            if (!(userAccountOne.getPassword().equals(changePasswordRequest.getOldPassword()))) {
                return Response.errorMsg("当前登录账号密码错误，请核对后重试");
            }
            //新密码正则
            // 6-20 位，字母、数字、字符
            String reg = "^[a-zA-Z0-9[^ ]]{6,20}$";
            if (!changePasswordRequest.getNewPassword().matches(reg)){
                return Response.errorMsg("新密码格式有误，请核对后重试");
            }
            if (!changePasswordRequest.getNewPassword().equals(changePasswordRequest.getCheckPassword())){
                return Response.errorMsg("新密码两次输入不一致，请核对后重试");
            }
            Integer update = customService.update(UserAccount.builder().password(MD5.hexdigest(changePasswordRequest.getNewPassword())).updateTime(LocalDateTime.now()).updateId(userAccountOne.getUserId()).build()
                                                , UserAccount.builder().account(userAccountOne.getAccount()).build());
            if (update == 0){
                return Response.errorMsg("修改密码错误,请稍后重试！");
            }
        } catch (Exception e) {
            return Response.errorMsg(StatusEnum.ERROR.getValue());
        }
        return Response.success("修改成功！");
    }
}




