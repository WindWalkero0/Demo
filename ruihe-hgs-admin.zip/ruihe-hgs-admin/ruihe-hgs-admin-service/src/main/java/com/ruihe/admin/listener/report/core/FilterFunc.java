package com.ruihe.admin.listener.report.core;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

public class FilterFunc {

    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> exists = ConcurrentHashMap.newKeySet();
        return t -> exists.add(keyExtractor.apply(t));
    }

    public static <T extends Column> Predicate<T> timeFilter(TableDefine define) {
        return timeFilter(define, true);
    }

    public static <T extends Column> Predicate<T> timeFilter(TableDefine define, boolean filter) {
        return c -> {
            if (!c.isTimeColumn()) {
                return true;
            }
            // 时间列不等2，不需要过滤
            if (!filter) return true;

            // 没有选择年月 日期，过滤掉所有时间的查询列
            if (!define.isDaily() && !define.isMonthly()) {
                return !ColumnDefine.day.equals(c) && !ColumnDefine.month.equals(c);
            }
            // 选择日期，可能也选择了年月，这种情况过滤掉年月就好了
            else if (define.isDaily()) {
                return !ColumnDefine.month.equals(c);
            } else {
                return !ColumnDefine.day.equals(c);
            }
        };
    }
}
