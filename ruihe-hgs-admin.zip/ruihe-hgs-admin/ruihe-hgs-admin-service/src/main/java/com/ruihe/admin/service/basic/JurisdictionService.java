package com.ruihe.admin.service.basic;


import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ruihe.admin.request.AccountManagementRequest;
import com.ruihe.admin.request.RoleManagementRequest;
import com.ruihe.admin.request.basic.AccountRoleRequest;
import com.ruihe.admin.request.basic.JursidictionRequest;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.*;
import com.ruihe.common.dao.bean.test.MenuUrl;
import com.ruihe.common.dao.mapper.UserAccountMapper;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.pojo.response.basic.AccountRespone;
import com.ruihe.common.response.Response;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.utils.StrategyCommon;
import com.ruihe.common.utils.TimeUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class JurisdictionService {


    @Autowired
    private CustomService customService;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    @Autowired
    private UserAccountMapper userAccountMapper;

    /**
     * 存储域
     */
    private String KEY = "ADMIN:ROLE_ACCOUNT";

    /**
     * 添加菜单目录
     *
     * @param menuMation
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addMenu(MenuMation menuMation) {
        //路径是唯一的不相同,所以添加的时候做一次健壮判断
        Integer code = checkMenuPath(menuMation.getMenuUrl());
        if (code.equals(StatusEnum.MENU_PATH_EXIT_ERROR.getKey())) {
            return Response.error(code, StatusEnum.instance(code).getValue());
        }
        //填充菜单数据
        menuMation.setUid(StrategyCommon.timeAlgorithm(StrategyCommon.MENU_UID));
        menuMation.setCreateTime(TimeUtils.longFormatString(System.currentTimeMillis()));
        //保存数据
        saveMenu(menuMation);
        return Response.success(menuMation.getUid());
    }

    /**
     * 菜单目录是否唯一检查
     */
    private Integer checkMenuPath(String menuUrl) {
        MenuMation menuMation = customService.select(MenuMation.builder().menuUrl(menuUrl).menuStatus(0).build());
        if (menuMation != null) {
            return StatusEnum.MENU_PATH_EXIT_ERROR.getKey();
        }
        return StatusEnum.SUCCESS.getKey();
    }


    /**
     * 查询菜单目录
     *
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectMenu(Integer type) {
        Map<String, Object> map = new HashMap<>();
        //查询所有菜单目录,及权限
        List<MenuMation> menuMations = searchTopMenu(map);
        return Response.success(menuMations);
    }

    /**
     * 根据角色uid 查询菜单和权限
     *
     * @param roleUid
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectAuthorManage(String roleUid) {
        //根据角色uid查询所有目录
        List<RoleMenu> roleMenuList = selectByRoleUid(roleUid);
        return Response.success(roleMenuList);
    }

    /**
     * 根据角色uid查询所有目录
     */
    @DS(DBConst.SLAVE)
    public List<RoleMenu> selectByRoleUid(String roleUid) {
        List<RoleMenu> roleMenuList = searchMenuByRP(roleUid, "0");
        if (!roleMenuList.isEmpty()) {
            for (RoleMenu roleMenu : roleMenuList) {
//                MenuMation menuMation = customService.select(MenuMation.builder().uid(roleMenu.getMenuUid()).build());
//                roleMenu.setMenuUrl(menuMation.getMenuUrl());
//                roleMenu.setMenuName(menuMation.getMenuName());
                //判断权限
                checkJurExit(roleMenu, roleUid);
                selectSonByRoleUid(roleMenu, roleUid);
            }
        }
        return roleMenuList;
    }

    /**
     * 递归查询下级目录
     */
    private void selectSonByRoleUid(RoleMenu roleMenu, String roleUid) {
        List<RoleMenu> roleMenuList = searchMenuByRP(roleUid, roleMenu.getMenuUid());
        if (!roleMenuList.isEmpty()) {
            for (RoleMenu roleMenuOne : roleMenuList) {
//                MenuMation menuMation = customService.select(MenuMation.builder().uid(roleMenuOne.getMenuUid()).build());
//                roleMenuOne.setMenuUrl(menuMation.getMenuUrl());
                checkJurExit(roleMenuOne, roleUid);
                selectSonByRoleUid(roleMenuOne, roleUid);
            }
            roleMenu.setRoleMenuList(roleMenuList);
        } else {
            roleMenu.setRoleMenuList(new ArrayList<>());
        }
    }

    /**
     * 根据 角色uid 上级菜单uid查询目录
     *
     * @param roleUid
     * @param parentMenuUid
     * @return
     * @throws Exception
     */
    private List<RoleMenu> searchMenuByRP(String roleUid, String parentMenuUid) {
        List<Object> queryListNoTime = customService.selectList(new RoleMenu().builder()
                .roleUid(roleUid)
                .menuParentUid(parentMenuUid)
                .status(StatusEnum.UN_DELETED.getKey())
                .build());
        List<RoleMenu> roleMenuList = new ArrayList<>();
        if (queryListNoTime.isEmpty()) {
            return roleMenuList;
        }
        for (Object o : queryListNoTime) {
            RoleMenu roleMenu = (RoleMenu) o;
            roleMenuList.add(roleMenu);
        }
        return roleMenuList;
    }

    /**
     * 查看是否存在权限
     *
     * @param roleMenu
     */
    private void checkJurExit(RoleMenu roleMenu, String roleUid) {
        if (roleMenu.getMenuType() == 1) {
            //根据角色和菜单uid查询权限
            List<Object> queryListNoTime = customService.selectList(new RoleJurisdiction().builder()
                    .roleUid(roleUid)
                    .menuUid(roleMenu.getMenuUid())
                    .status(StatusEnum.UN_DELETED.getKey())
                    .build());
            //进行填充
            List<RoleJurisdiction> jurisdictionList = new ArrayList<>();
            if (queryListNoTime.isEmpty()) {
                roleMenu.setJurisdictions(jurisdictionList);
            } else {
                for (Object o : queryListNoTime) {
                    RoleJurisdiction roleJurisdiction = (RoleJurisdiction) o;
                    jurisdictionList.add(roleJurisdiction);
                }
                roleMenu.setJurisdictions(jurisdictionList);
            }
        }
    }


    /**
     * 查询所有一级菜单目录
     */
    private List<MenuMation> searchTopMenu(Map<String, Object> map) {
        //查询目录
        List<MenuMation> menuMations = searchMenuByUid("0", "");
        //进行下级查询
        if (!menuMations.isEmpty()) {
            for (MenuMation menuMation : menuMations) {
                fillJur(menuMation, map);
                selectSonMenu(menuMation, map);
            }
            return menuMations;
        }
        return new ArrayList<>();
    }

    /**
     * 判断此目录是否有权限,如果有就填充权限
     */
    private void fillJur(MenuMation menuMation, Map<String, Object> map) {
        if (menuMation.getMenuType() == 1) {
            //获取到权限
            List<MenuJurisdiction> menuJurisdictionList = searchJurByMuid(menuMation.getUid());
            menuMation.setJurisdictions(menuJurisdictionList);
        }
    }

    /**
     * 递归查询下级目录
     */
    private void selectSonMenu(MenuMation menuMation, Map<String, Object> map) {
        List<MenuMation> menuMationList = searchMenuByUid(menuMation.getUid(), menuMation.getMenuName());
        if (!menuMationList.isEmpty()) {
            for (MenuMation menuMationOne : menuMationList) {
                fillJur(menuMationOne, map);
                selectSonMenu(menuMationOne, map);
            }
            menuMation.setMenuMations(menuMationList);
        }
    }

    /**
     * 根据父目录uid查询所有子目录
     */
    private List<MenuMation> searchMenuByUid(String menuParentUid, String parentName) {
        List<MenuMation> menuMations = customService.selectList(MenuMation.builder().menuParentUid(menuParentUid).menuStatus(0).build());
        menuMations.stream().forEach(menuMation -> {
            if (!menuParentUid.equals("0")) {
                menuMation.setMenuParentName(parentName);
            }
        });
        return menuMations;
    }

    /**
     * 删除目录
     *
     * @param menuUid
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response deleteMenu(String menuUid) {
        //根据uid删除菜单目录
        updateByUid(menuUid);
        //清除缓存
        redisTemplate.delete(KEY);
        return Response.successMsg("操作成功");
    }

    /**
     * 根据uid修改菜单目录
     */
    private void updateByUid(String menuUid) {
        //删除角色关联的菜单
        deleteRoleMenu(menuUid);
        //修改状态
        Integer update = customService.update(MenuMation.builder()
                .menuStatus(StatusEnum.DELETED.getKey())
                .build(), MenuMation.builder()
                .uid(menuUid)
                .menuStatus(StatusEnum.UN_DELETED.getKey())
                .build());
        if (update.equals(0)) {
            log.error("删除菜单权限失败,menuUid={}", menuUid);
            throw new BizException("删除菜单权限失败");
        }
    }

    /**
     * 根据菜单uid删除角色关联的菜单
     */
    private void deleteRoleMenu(String uid) {
        //先查询是否有与角色进行关联
        List<RoleMenu> roleMenus = customService.selectList(RoleMenu.builder().menuUid(uid).build());
        if (!roleMenus.isEmpty()) {
            Integer delete = customService.delete(RoleMenu.builder().menuUid(uid).build());
            if (delete.equals(0)) {
                log.error("更新角色菜单失败,uid={}", uid);
                throw new BizException("更新角色菜单失败");
            }
        }
        List<RoleJurisdiction> roleJurisdictions = customService.selectList(RoleJurisdiction.builder().menuUid(uid).build());
        if (!roleJurisdictions.isEmpty()) {
            Integer delete11 = customService.delete(RoleJurisdiction.builder().menuUid(uid).build());
            if (delete11.equals(0)) {
                log.error("更新角色权限失败,uid={}", uid);
                throw new BizException("更新角色权限失败");
            }
        }
    }

    /**
     * 添加菜单权限
     *
     * @param menuJurisdiction
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addMenuJur(MenuJurisdiction menuJurisdiction) {
        //查看名是否重复
        Integer code = checkJurisdiction(menuJurisdiction.getJurisdictionName(), menuJurisdiction.getMenuUid());
        if (code.equals(StatusEnum.JURISDICTION_NAME_EXIT.getKey())) {
            return Response.error(code, StatusEnum.instance(code).getValue());
        }
        //填充数据
        menuJurisdiction.setUid(StrategyCommon.timeAlgorithm(StrategyCommon.JUR_UID));
        menuJurisdiction.setCreateTime(TimeUtils.longFormatString(System.currentTimeMillis()));
        //将对应的菜单目录变成类型为拥有下级权限
//        MenuMation menuMation = new MenuMation();
//        menuMation.setMenuType(1);
        changeMenuType(menuJurisdiction.getMenuUid());
        //保存权限
        Integer save = customService.save(menuJurisdiction);
        if (save.equals(0)) {
            log.error("添加菜单权限失败,menuJurisdiction={}", menuJurisdiction);
            throw new BizException("添加菜单权限失败");
        }
        return Response.successMsg("操作成功");
    }

    /**
     * 将对应的菜单目录变成类型为拥有下级权限
     */
    private void changeMenuType(String menuUid) {
        customService.update(
                MenuMation.builder()
                        .menuType(1)
                        .build(),
                MenuMation.builder()
                        .uid(menuUid)
                        .menuStatus(StatusEnum.UN_DELETED.getKey())
                        .build());
    }

    /**
     * 检测权限的健壮性
     */
    private Integer checkJurisdiction(String name, String menuUid) {
        MenuJurisdiction menuJurisdiction = customService.select(MenuJurisdiction.builder().jurisdictionName(name).menuUid(menuUid).jurisdictionStatus(0).build());
        if (menuJurisdiction != null) {
            return StatusEnum.JURISDICTION_NAME_EXIT.getKey();
        }
        return StatusEnum.SUCCESS.getKey();
    }


    /**
     * 查询菜单权限
     *
     * @param menuUid
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectJur(String menuUid) {
        //查询指定菜单下所有的权限
        List<MenuJurisdiction> menuJurisdictionList = searchJurByMuid(menuUid);
        return Response.success(menuJurisdictionList);
    }

    /**
     * 根据菜单uid查询所有权限
     */
    private List<MenuJurisdiction> searchJurByMuid(String menuUid) {
        List<MenuJurisdiction> menuJurisdictions = customService.selectList(MenuJurisdiction.builder().menuUid(menuUid).jurisdictionStatus(0).build());
        return menuJurisdictions;
    }

    /**
     * 添加角色
     *
     * @param roleMation
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addRole(RoleMation roleMation) {
        //根据角色名称判断是否重复
        Integer code = checkRoleByName(roleMation.getRoleName());
        if (code.equals(StatusEnum.ROLE_NAME_EXIT.getKey())) {
            return Response.error(code, StatusEnum.instance(code).getValue());
        }
        //填充角色数据
        roleMation.setCreateTime(TimeUtils.longFormatString(System.currentTimeMillis()));
        roleMation.setUid(StrategyCommon.timeAlgorithm(StrategyCommon.ROLE_UID));
        //保存角色信息
        Integer save = customService.save(roleMation);
        if (save.equals(0)) {
            log.error("添加角色失败,roleMation={}", roleMation);
            throw new BizException("添加角色失败");
        }
        return Response.success(StatusEnum.SUCCESS.getValue());
    }

    /**
     * 根据角色名称判断是否重复
     */
    public Integer checkRoleByName(String name) {
        RoleMation roleMation = customService.select(RoleMation.builder().roleName(name).roleStatus(0).build());
        if (roleMation != null) {
            return StatusEnum.ROLE_NAME_EXIT.getKey();
        }
        return StatusEnum.SUCCESS.getKey();
    }

    /**
     * 编辑菜单目录
     *
     * @param menuMation
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response editMenu(MenuMation menuMation) {
        List<MenuMation> menuMations = customService.selectList(MenuMation.builder().menuUrl(menuMation.getMenuUrl()).build());
        if (!menuMations.isEmpty()) {
            for (MenuMation mation : menuMations) {
                if (!mation.getUid().equals(menuMation.getUid())) {
                    return Response.error(StatusEnum.MENU_PATH_EXIT_ERROR.getKey(), StatusEnum.MENU_PATH_EXIT_ERROR.getValue());
                }
            }
        }
        //进行保存
        Integer update = customService.update(MenuMation
                .builder()
                .menuUrl(menuMation.getMenuUrl())
                .menuType(menuMation.getMenuType())
                .menuName(menuMation.getMenuName())
                .build(), MenuMation
                .builder()
                .uid(menuMation.getUid())
                .build());
        if (update.equals(0)) {
            log.error("编辑菜单目录,menuMation={}", menuMation);
            throw new BizException("编辑菜单目录");
        }
        //查询权限是否有关联的权限信息
        List<RoleJurisdiction> roleJurisdictions = customService.selectList(RoleJurisdiction.builder().menuUid(menuMation.getUid()).build());
        if (!roleJurisdictions.isEmpty()) {
            //进行角色权限更新
            Integer update1 = customService.update(RoleJurisdiction.builder().menuName(menuMation.getMenuName()).build(), RoleJurisdiction.builder().menuUid(menuMation.getUid()).build());
            if (update1.equals(0)) {
                log.error("编辑菜单目录,更新权限信息失败,menuMation={}", menuMation);
                throw new BizException("更新权限信息失败");
            }
        }
        //查询权限是否有关联的菜单信息
        List<RoleMenu> roleMenus = customService.selectList(RoleMenu.builder().menuUid(menuMation.getUid()).build());
        if (!roleMenus.isEmpty()) {
            //进行角色权限更新
            Integer update2 = customService.update(RoleMenu.builder().menuName(menuMation.getMenuName()).menuUrl(menuMation.getMenuUrl()).build(), RoleMenu.builder().menuUid(menuMation.getUid()).build());
            if (update2.equals(0)) {
                log.error("编辑菜单目录,更新角色菜单信息失败,menuMation={}", menuMation);
                throw new BizException("更新角色菜单信息失败");
            }
        }
        //清除角色菜单缓存
        redisTemplate.delete(KEY);
        return Response.successMsg(StatusEnum.SUCCESS.getValue());
    }

    /**
     * 编辑权限
     *
     * @param menuJurisdiction
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response editJur(MenuJurisdiction menuJurisdiction) {
        List<MenuJurisdiction> menuJurisdictions = customService.selectList(MenuJurisdiction.builder().uid(menuJurisdiction.getUid()).build());
        if (!menuJurisdictions.isEmpty()) {
            for (MenuJurisdiction jurisdiction : menuJurisdictions) {
                if (!jurisdiction.getUid().equals(menuJurisdiction.getUid())) {
                    return Response.errorMsg("编辑权限失败,权限信息重复");
                }
            }
        }
        //进行编辑权限
        Integer update1 = customService.update(menuJurisdiction, MenuJurisdiction.builder().uid(menuJurisdiction.getUid()).build());
        if (update1.equals(0)) {
            log.error("编辑权限失败menuJurisdiction={}", menuJurisdiction);
            throw new BizException("编辑权限失败");
        }
        //进行角色权限更新
        Integer update = customService.update(RoleJurisdiction.builder().jurName(menuJurisdiction.getJurisdictionName()).build(), RoleJurisdiction.builder().jurUid(menuJurisdiction.getUid()).build());
        //查询权限是否有关联的权限信息
        List<RoleJurisdiction> roleJurisdictions = customService.selectList(RoleJurisdiction.builder().jurUid(menuJurisdiction.getUid()).build());
        if (!roleJurisdictions.isEmpty()) {
            if (update.equals(0)) {
                log.error("编辑权限失败,更新权限信息失败,menuJurisdiction={}", menuJurisdiction);
                throw new BizException("更新权限信息失败");
            }
        }
        //清除缓存
        redisTemplate.delete(KEY);
        return Response.successMsg(StatusEnum.SUCCESS.getValue());
    }

    /**
     * 编辑角色
     *
     * @param roleMation
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response editRole(RoleMation roleMation) {
        //检测名称是否重复
        Integer code = checkRoleName(roleMation.getRoleName());
        if (code == StatusEnum.ROLE_NAME_EXIT.getKey()) {
            return Response.error(code, StatusEnum.instance(code).getValue());
        }
        //根据状态修改角色与张华关联的信息
        Integer update = customService.update(AccountRole.builder().status(roleMation.getRoleStatus()).build(), AccountRole.builder().roleUid(roleMation.getUid()).build());
        List<AccountRole> accountRoles = customService.selectList(AccountRole.builder().roleUid(roleMation.getUid()).build());
        if (!accountRoles.isEmpty()) {
            if (update.equals(0)) {
                log.error("根据状态修改角色与张华关联的信息roleMation={}", roleMation);
                throw new BizException("根据状态修改角色关联的信息");
            }
        }
        //进行保存编辑
        customService.update(roleMation, RoleMation.builder().uid(roleMation.getUid()).build());
        //清除缓存
        redisTemplate.delete(KEY);
        return Response.success(StatusEnum.SUCCESS.getValue());
    }

    /**
     * 编辑的时候判断名称是否重复
     */
    public Integer checkRoleName(String name) {
        List<RoleMation> roleMations = customService.selectList(RoleMation.builder().roleName(name).roleStatus(StatusEnum.UN_DELETED.getKey()).build());
        if (!roleMations.isEmpty()) {
            if (roleMations.size() > 1) {
                return StatusEnum.ROLE_NAME_EXIT.getKey();
            }
        }
        return StatusEnum.SUCCESS.getKey();
    }

    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response deleteJur(String uid) {
        Integer update = customService.update(MenuJurisdiction.builder().jurisdictionStatus(1).build(), MenuJurisdiction.builder().uid(uid).build());
        if (update.equals(0)) {
            log.error("删除权限失败,uid={}", uid);
            throw new BizException("删除权限失败");
        }
        //更新角色权限信息
        Integer delete = customService.delete(RoleJurisdiction.builder().jurUid(uid).build());
        //查询该权限是够关联角色
        List<RoleJurisdiction> roleJurisdictions = customService.selectList(RoleJurisdiction.builder().jurUid(uid).build());
        if (!roleJurisdictions.isEmpty()) {
            if (delete.equals(0)) {
                log.error("删除权限时更新权限信息失败,uid={}", uid);
                throw new BizException("删除权限时更新权限信息失败");
            }
        }
        //清除缓存
        redisTemplate.delete(KEY);
        return Response.successMsg(StatusEnum.SUCCESS.getValue());
    }

    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response authorManage(JursidictionRequest jursidictionRequest) {
        //健壮判断
        if (StringUtils.isEmpty(jursidictionRequest.getRoleUid())) {
            return Response.errorMsg(StatusEnum.ROLE_UID_NULL.getValue());
        }
        //删除该角色的所有权限
        deleteAllauthor(jursidictionRequest.getRoleUid());
        if (jursidictionRequest.getRoleMenuList() == null || jursidictionRequest.getRoleMenuList().isEmpty()) {
            return Response.successMsg(StatusEnum.SUCCESS.getValue());
        } else {
            //获取到菜单集合
            List<RoleMenu> roleMenuList = jursidictionRequest.getRoleMenuList();
            for (RoleMenu roleMenu : roleMenuList) {
                //菜单授权
                operation(roleMenu, jursidictionRequest.getRoleUid());
            }
        }
        //清除角色菜单缓存
        redisTemplate.delete(KEY);
        return Response.success(StatusEnum.SUCCESS.getValue());
    }

    /**
     * 菜单授权的业务逻辑
     */
    private void operation(RoleMenu roleMenu, String roleUid) {
        //判断下级是否有操作权限
        if (roleMenu.getMenuType() == 1) {//如果有就对权限进行保存
            //健壮判断
            if (StringUtils.isEmpty(roleMenu.getJurisdictions())) {
                log.error("权限为空roleMenu={}", roleMenu);
                throw new BizException(StatusEnum.JURISDICTION_NULL.getValue());
            }
            List<RoleJurisdiction> jurisdictions = roleMenu.getJurisdictions();
            for (RoleJurisdiction jurisdiction : jurisdictions) {
                jurisdiction.setRoleUid(roleUid);//设置角色uid
                //进行保存
                customService.save(jurisdiction);
            }
        }
        if (roleMenu.getRoleMenuList() != null) {
            List<RoleMenu> roleMenus = roleMenu.getRoleMenuList();
            if (!roleMenus.isEmpty()) {
                for (RoleMenu menu : roleMenus) {
                    //继续菜单授权
                    operation(menu, roleUid);
                }
            }
        }
        customService.save(RoleMenu.builder()
                .menuParentUid(roleMenu.getMenuParentUid())
                .roleUid(roleUid)
                .menuUid(roleMenu.getMenuUid())
                .menuType(roleMenu.getMenuType())
                .menuName(roleMenu.getMenuName())
                .roleName(roleMenu.getRoleName())
                .menuUrl(roleMenu.getMenuUrl())
                .build());


    }

    /**
     * 根据角色uid删除所有权限
     *
     * @param roleUid
     * @throws Exception
     */
    private void deleteAllauthor(String roleUid) {
        customService.delete(RoleMenu.builder().roleUid(roleUid).build());
        List<RoleJurisdiction> roleJurisdictions = customService.selectList(RoleJurisdiction.builder().roleUid(roleUid).build());
        if (!roleJurisdictions.isEmpty()) {
            Integer update = customService.update(RoleJurisdiction.builder().status(StatusEnum.DELETED.getKey()).build(), RoleJurisdiction.builder().roleUid(roleUid).build());
            if (update.equals(0)) {
                log.error("根据角色uid删除所有权限失败,roleUid={}", roleUid);
                throw new BizException("根据角色uid删除所有权限失败");
            }
        }
    }


    /**
     * 根据roleUid查询权限
     */
//    public List<RoleJurisdiction> selectRoleJurisdiction(Map<String, Object> map, String roleUid) throws Exception {
//        List<Object> list = baseMysqlCRUDService.queryListNoTime(new RoleJurisdiction(), map);
//        List<RoleJurisdiction> roleJurisdictions = new ArrayList<>();
//        if (list.isEmpty()) {
//            return roleJurisdictions;
//        }
//        for (Object o : list) {
//            RoleJurisdiction roleJurisdiction = (RoleJurisdiction) o;
//            roleJurisdictions.add(roleJurisdiction);
//        }
//        return roleJurisdictions;
//    }

    /**
     * 根据roleUid查询菜单目录
     */
//    public List<RoleMenu> selectRoleMenuByUid(Map<String, Object> map, String roleUid) throws Exception {
//        List<Object> list = baseMysqlCRUDService.queryListNoTime(new RoleMenu(), map);
//        List<RoleMenu> roleMenuList = new ArrayList<>();
//        if (list.isEmpty()) {
//            return roleMenuList;
//        }
//        for (Object o : list) {
//            RoleMenu roleMenu = (RoleMenu) o;
//            roleMenuList.add(roleMenu);
//        }
//        return roleMenuList;
//    }

    /**
     * 根据名查询角色列表
     *
     * @param request 查询条件请求体
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectRole(RoleManagementRequest request) {
        // 当前页
        if(request.getPageNumber() == null){
            request.setPageNumber(1);
        }
        // 当前页数量
        if(request.getPageSize() == null){
            request.setPageSize(10);
        }
        //查询角色列表
        PageHelper.startPage(request.getPageNumber(), request.getPageSize());
        List<RoleMation> list = userAccountMapper.selectRoles(request.getRoleName(), request.getRoleStatus(), request.getMenuUid(), request.getJurUid());
        PageInfo<RoleMation> pageInfo = new PageInfo<>(list);
        return Response.success(pageInfo);
    }


    @DS(DBConst.MASTER)
    public Response selectAccount(AccountManagementRequest request) {
        // 当前页
        if(request.getPageNumber() == null){
            request.setPageNumber(1);
        }
        // 当前页数量
        if(request.getPageSize() == null){
            request.setPageSize(10);
        }
        //设置分页条件
        Page<AccountRespone> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询出列表
        IPage<AccountRespone> accountResponseIPage = userAccountMapper.selectAccountResponseList(page, request.getAccountName()
                , request.getStatus(), request.getMenuUid(), request.getJurUid(), request.getAccount());
        //如果查询结果不为空
        if (!accountResponseIPage.getRecords().isEmpty()) {
            //循环遍历进行数据填充
            accountResponseIPage.getRecords().forEach(e -> {
                //查询账号角色关联列表
                List<AccountRole> accountRoles = selectAccount(e.getUserUid());
                if (!accountRoles.isEmpty()) {
                    accountRoles.forEach(accountRole -> {
                        //查询角色信息
                        RoleMation roleMation = selectRoleMation(accountRole.getRoleUid());
                        if (roleMation != null) {
                            accountRole.setRoleName(roleMation.getRoleName());
                            //填充响应数据
                            if (StringUtils.isEmpty(e.getRoleDes())) {
                                e.setRoleDes(roleMation.getRoleName());
                            } else {
                                e.setRoleDes(e.getRoleDes() + "," + roleMation.getRoleName());
                            }
                        }
                    });
                    e.setAccountRoleList(AccountRole.convert2DTO(accountRoles));
                }
            });
        }
        //设置查询结果
        PageVO info = PageVO.<AccountRespone>builder().list(accountResponseIPage.getRecords())
                .total(accountResponseIPage.getTotal())
                .pageNum(accountResponseIPage.getCurrent())
                .pageSize(accountResponseIPage.getSize())
                .pages(accountResponseIPage.getPages()).build();
        /*Integer size = 0;
        //设置分页
        PageHelper.startPage(pageNumber, pageSize);
        List<UserAccount> userAccounts = customService.selectList(UserAccount.builder().build());
        List<AccountRespone> accountRespones = new ArrayList<>();
        if (!userAccounts.isEmpty()) {
            if (!StringUtils.isEmpty(accountName)) {
                Iterator<UserAccount> iterator = userAccounts.iterator();
                while (iterator.hasNext()) {
                    UserAccount userAccount = iterator.next();
                    UserInformation userInformation = customService.select(UserInformation.builder().empId(userAccount.getUserId()).build());
                    if (userInformation == null || !userInformation.getName().contains(accountName)) {
                        iterator.remove();
                        size++;
                    }
                }
            }
            if (!userAccounts.isEmpty()) {
                for (UserAccount userAccount : userAccounts) {
                    UserInformation userInformation = customService.select(UserInformation.builder().empId(userAccount.getUserId()).build());

                    if (userInformation != null) {
                        AccountRespone accountRespone = new AccountRespone();
                        //填充响应信息
                        accountRespone.setAccount(userAccount.getAccount());
                        accountRespone.setStatus(userAccount.getStatus());
                        accountRespone.setUserUid(userInformation.getEmpId());
                        accountRespone.setUserName(userInformation.getName());
                        //查询账号角色关联列表
                        List<AccountRole> accountRoles = selectAccount(userAccount.getUserId());
                        if (!accountRoles.isEmpty()) {
                            accountRoles.stream().forEach(accountRole -> {
                                RoleMation roleMation = selectRoleMation(accountRole.getRoleUid());
                                if (roleMation != null) {
                                    accountRole.setRoleName(roleMation.getRoleName());
                                    //填充响应数据
                                    if (StringUtils.isEmpty(accountRespone.getRoleDes())) {
                                        accountRespone.setRoleDes(roleMation.getRoleName());
                                    } else {
                                        accountRespone.setRoleDes(accountRespone.getRoleDes() + "," + roleMation.getRoleName());
                                    }
                                    roleMation.setRoleName(roleMation.getRoleName());
                                }
                            });
                            accountRespone.setAccountRoleList(accountRoles);
                        }
                        accountRespones.add(accountRespone);
                    } else {
                        size++;
                    }
                }
            }
        }
        PageInfo<AccountRespone> info = new PageInfo<>(accountRespones);
        info.setTotal(customService.selectCount(UserAccount.builder().build()) - size);*/
        return Response.success(info);
    }

    /**
     * 根据roleUid查询角色信息
     */
    private RoleMation selectRoleMation(String roleUid) {
        return customService.select(RoleMation.builder().uid(roleUid).roleStatus(StatusEnum.UN_DELETED.getKey()).build());
    }

    /**
     * 角色分配
     *
     * @param accountRoleRequest
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response operationRole(AccountRoleRequest accountRoleRequest) {
        //清除账户存储
        redisTemplate.delete(KEY);
//            Map<String, Object> map = new HashMap<>();
        //健壮判断
        if (accountRoleRequest == null) {
            return Response.error(StatusEnum.SELECT_MATION.getValue());
        }
        if (StringUtils.isEmpty(accountRoleRequest.getUserUid())) {
            return Response.error(StatusEnum.USER_UID_NULL.getKey(), StatusEnum.USER_UID_NULL.getValue());
        }
        if (ObjectUtils.isEmpty(accountRoleRequest.getAccountRoleList())) {
            //如果为空删除全部
            deletaRoleByUid(accountRoleRequest.getUserUid());
            return Response.success(StatusEnum.SUCCESS.getValue());
        } else {
            //先删除之前所有的角色
            deletaRoleByUid(accountRoleRequest.getUserUid());
            List<AccountRole> accountRoleList = accountRoleRequest.getAccountRoleList();
            for (AccountRole accountRole : accountRoleList) {
                accountRole.setUserUid(accountRoleRequest.getUserUid());
                accountRole.setUserName(accountRoleRequest.getUserName());
                //进行保存
                customService.save(accountRole);
            }
            return Response.success(StatusEnum.SUCCESS.getValue());
        }
    }

    /**
     * 根据用户uid 删除关联角色
     */
    private void deletaRoleByUid(String userUid) {
        customService.delete(AccountRole.builder().userUid(userUid).build());
    }

    /**
     * 判断是否存在
     */
    public List<AccountRole> selectAccount(String userUid) {
        List<AccountRole> list = customService.selectList(AccountRole.builder()
                .userUid(userUid)
                .status(StatusEnum.UN_DELETED.getKey())
                .build());
        return list;
    }

    @Ella(Describe = "处理菜单集合", Author = "K")
    @DS(DBConst.MASTER)
    public void selectSon(MenuMation menuMation, List<String> list) {
        List<MenuMation> menuMations = selectMenus(MenuMation.builder().menuParentUid(menuMation.getUid()).menuStatus(0).build());
        if (!menuMations.isEmpty()) {
            menuMations.stream().forEach(menuOther -> {
                menuOther.setMenuUrl(menuMation.getMenuUrl() + menuOther.getMenuUrl());
                selectSon(menuOther, list);
            });
        } else {
            //如果为空--说明是最后一级,进行存储
            list.add(menuMation.getMenuUrl());
            customService.save(MenuUrl.builder().url(menuMation.getMenuUrl()).build());
        }

    }

    @Ella(Describe = "查询菜单集合", Author = "K")
    @DS(DBConst.SLAVE)
    public List<MenuMation> selectMenus(MenuMation menuMation) {
        return customService.selectList(menuMation);
    }

    @Ella(Describe = "处理菜单集合", Author = "K")
    @DS(DBConst.SLAVE)
    public void operationRoleUrl(RoleMenu roleMenu, Map<String, String> map, String roleId) {
        List<RoleMenu> roleMenus = selectRoleMenus(RoleMenu.builder().menuParentUid(roleMenu.getMenuUid()).roleUid(roleId).build());
        if (!roleMenus.isEmpty()) {
            roleMenus.stream().forEach(roleMenuOther -> {
                roleMenuOther.setMenuUrl(roleMenu.getMenuUrl() + roleMenuOther.getMenuUrl());
                operationRoleUrl(roleMenuOther, map, roleId);
            });
        } else {
            //如果为空--说明是最后一级,进行存储
            map.put(roleMenu.getMenuUrl(), roleId);
        }

    }

    @Ella(Describe = "查询角色权限集合", Author = "K")
    @DS(DBConst.SLAVE)
    public List<RoleMenu> selectRoleMenus(RoleMenu roleMenu) {
        return customService.selectList(roleMenu);
    }

    @Ella(Describe = "保存菜单目录", Author = "K")
    @DS(DBConst.MASTER)
    private void saveMenu(MenuMation menuMation) {
        Integer save = customService.save(menuMation);
        if (save.equals(0)) {
            log.error("保存菜单目录失败menuMation={}", menuMation);
            throw new BizException("保存菜单目录失败");
        }
    }

    public Response accountRole() {
        List<RoleMation> roleMations = customService.selectList(RoleMation.builder().roleStatus(0).build());
        return Response.success(roleMations);
    }
}
