package com.ruihe.admin.event;


import com.ruihe.common.annotation.Ella;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

@Ella(Describe = "角色url'")
@Data
@EqualsAndHashCode(callSuper = false)
public class RoleUrlEvent extends ApplicationEvent {


    private String roleId;

    public RoleUrlEvent(Object source, String roleId) {
        super(source);
        this.roleId = roleId;
    }

}
