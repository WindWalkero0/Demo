package com.ruihe.admin.listener.report.core;

import com.ruihe.admin.listener.report.utils.FieldUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public abstract class HeadProviderByQuery extends HeadProviderByDefine implements HeadProvider {

    public HeadProviderByQuery(TableDefine define) {
        super(define);
    }

    protected abstract List<?> queryHeadData();

    /*
     * 构建列层级树，需要对相同group by字段去重
     * 需要根据时间，自定义查询数据构建
     */
    @Override
    protected void buildColTree() {
        super.buildColTree();

        // 数据为空，只构建时间相关的表头
        List<?> data = queryHeadData();
        if (data == null || data.isEmpty()) {
            return;
        }

        // 没有选择时间, 动态树直接从根节点开始构建
        if (timeNodes.isEmpty()) {
            timeNodes.add(rootNode);
        }

        // 根据数据库查询的表头数据，构建列维度的层级树
        List<Column> displayColumns = define.getVerticalColumns().stream()
                .filter(Column::isShow)
                .filter(c -> !c.isTimeColumn())
                .collect(Collectors.toList());

        for (Object item : data) {
            // 需要在每个时间节点下插入，如果没选择时间，会从根节点插入
            for (var node : timeNodes) {
                Set<String> exist = new HashSet<>();
                for (Column column : displayColumns) {
                    String val = FieldUtils.readString(item, column.getName());
                    String groupVal = FieldUtils.readGroupValue(item, column, val);
                    if (exist.add(column.getGroup())) {
                        node = node.findOrCreate(groupVal);
                        node.clearDisplay();
                    }
                    node.addDisplay(val);
                }
            }
        }
    }
}
