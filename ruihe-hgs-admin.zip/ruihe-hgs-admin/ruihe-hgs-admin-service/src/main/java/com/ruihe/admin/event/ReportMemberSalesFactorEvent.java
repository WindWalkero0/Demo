package com.ruihe.admin.event;


import com.ruihe.admin.request.bi.MemberSalesFactorReportRequest;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 会员销售要素报表事件
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ReportMemberSalesFactorEvent extends BiReportEvent {
    private MemberSalesFactorReportRequest request;

    @Builder
    public ReportMemberSalesFactorEvent(MemberSalesFactorReportRequest request) {
        this.request = request;
    }
}
