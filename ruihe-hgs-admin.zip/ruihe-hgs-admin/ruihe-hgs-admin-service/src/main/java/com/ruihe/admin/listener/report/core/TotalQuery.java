package com.ruihe.admin.listener.report.core;

import java.util.List;

public interface TotalQuery {
    List<?> doQuery(String select, String group, int dayOrMonth);

    String alias();
}
