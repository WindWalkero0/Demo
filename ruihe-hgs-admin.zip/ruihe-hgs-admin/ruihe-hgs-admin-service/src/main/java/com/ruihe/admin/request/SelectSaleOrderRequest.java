package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Auther: caichunxiang
 * @Date 2019/12/5
 */
@ApiModel(value = "SelectSaleOrderRequest", description = "会员详情页首页请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SelectSaleOrderRequest implements Serializable {

    @ApiModelProperty("会员id")
    private String memberId;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
