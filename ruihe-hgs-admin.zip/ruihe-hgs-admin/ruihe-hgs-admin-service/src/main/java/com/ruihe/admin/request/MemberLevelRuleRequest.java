package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-11 15:36
 */
@ApiModel(value = "MemberLevelRuleRequest", description = "会员升降级新增/编辑请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberLevelRuleRequest implements Serializable {

    @ApiModelProperty(value = "升降级主键ID,新增的时候不要传")
    private String ruleId;

    @ApiModelProperty(value = "规则名称")
    private String ruleName;

    @ApiModelProperty(value = "规则开始时间")
    private LocalDate startTime;

    @ApiModelProperty(value = "规则结束时间,空的时候传'9999-12-31 00:00:00.000'")
    private LocalDate endTime;

    @ApiModelProperty(value = "建立用户ID")
    private String optUid;

    @ApiModelProperty(value = "建立用户名称")
    private String optName;

    @ApiModelProperty(value = "规则描述，此处是将规则进行拼接")
    private String description;

    @ApiModelProperty(value = "会员等级代码")
    private String levelCode;

    @ApiModelProperty(value = "会员等级名称")
    private String levelName;

    @ApiModelProperty(value = "会员等级有效期，n月/0永久有效")
    private Integer duration;

    @ApiModelProperty(value = "会员等级级别")
    private Integer level;

    @ApiModelProperty(value = "状态：0停用，1启用,新增的时候不要传")
    private Integer status;

    @ApiModelProperty(value = "会员升级")
    private List<MemberLevelUpRequest> memberLevelUpRequestList;

    @ApiModelProperty(value = "会员降级")
    private List<MemberLevelDownRequest> memberLevelDownRequestList;

}
