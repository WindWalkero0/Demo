package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.Report4BaVisitEvent;
import com.ruihe.admin.listener.report.core.ReportController;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.admin.mapper.bi.PosBaVisitReportMapper;
import com.ruihe.admin.po.BiReportPo;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;

/***
 * 服务记录报表
 * @author fly
 */
@Component
@RequiredArgsConstructor
public class PosBaVisitReportListener extends AbstractReportListener<Report4BaVisitEvent> {

    private final PosBaVisitReportMapper posBaVisitReportMapper;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_REPORT)
    @EventListener
    public void onApplicationEvent(Report4BaVisitEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    public void doExport(Report4BaVisitEvent event, BiReportPo report, boolean flag) {
        TableDefine define = PosBaVisitDefine.create(event.getRequest());

        ReportController controller = new ReportController(define);
        controller.name("服务记录报表");
        controller.savePath(report.getFilePath());

        //1、查询基础数据
        List<HashMap> baseData = posBaVisitReportMapper.posBaVisitReport(
                event.getRequest(),
                define.selectCols()
                        .replaceAll("org_area_code", "org_area_id")
                        .replaceAll("org_office_code", "org_office_id")
                        .replaceAll("org_principal_code", "org_master_id")
                        .replaceAll("org_principal_name", "org_master_name"),
                this.createsCols(event),
                define.groupCols()
                        .replaceAll("org_area_code", "org_area_id")
                        .replaceAll("org_office_code", "org_office_id")
                        .replaceAll("org_principal_code", "org_master_id")
                        .replaceAll("org_principal_name", "org_master_name"),
                flag);

        controller.fillData(baseData);
        controller.totalCalculate();
        controller.write(this.imgPath, report.getPicUrl());
    }

    private String createsCols(Report4BaVisitEvent event) {
        List<String> visitTypes = event.getRequest().getSelectRequest().getVisitType();
        StringBuilder sb = new StringBuilder();
        for (String visitType : visitTypes) {
            sb.append(",");
            sb.append("IFNULL( sum( CASE WHEN operation_type = '");
            sb.append(visitType);
            sb.append("' THEN operation_qty END ), 0 ) AS ");
            sb.append(visitType);
        }
        return sb.toString();
    }

}
