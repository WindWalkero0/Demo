package com.ruihe.admin.listener.report.core;

import com.google.common.collect.Lists;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * 用于构建行，列层级树，用于计算小计，总计
 * 树的每一层是根据数据库查询的group by来的
 * 特殊的是时间字段，当选择年月和日期时，一个时间需要分成两层，如：202007/20200712
 * 树的层级会去重，比如，产品名称，产品条码，厂商编码，都代表一个东西，group by是同一个字段
 * 所以只需要一个层级，display 这个 List 保存了去重的那两个字段需要展示在报表中的值
 */
public class TreeNode<V> {
    private Map<String, TreeNode<V>> cached;

    private List<TreeNode<V>> children;

    private TreeNode<V> parent;

    /**
     * 因为层级节点是按group 去重的，所有会丢失掉重复的数据
     * 比如 产品名称，产品条码，厂商编码，group by是同一个字段，会丢失2个数据
     * 所以需要一个层级所有显示的数据到这个list中
     */
    private final List<String> display = new ArrayList<>();

    /**
     * 树节点唯一key，group by 字段值
     * 根节点为null
     */
    private String key;

    /**
     * 存放统计结果数据
     */
    private V value;

    public TreeNode() {
    }

    public TreeNode(String key, V value) {
        this.key = key;
        this.value = value;
    }

    public String key() {
        return key;
    }

    public void key(String key) {
        this.key = key;
    }

    public V value() {
        return value;
    }

    public V value(Supplier<V> supplier) {
        if (this.value == null) {
            this.value = supplier.get();
        }
        return value;
    }

    public void value(V value) {
        this.value = value;
    }

    public void addDisplay(String val) {
        display.add(val);
    }

    public void clearDisplay() {
        display.clear();
    }

    public List<String> display(int len) {
        List<String> list = new ArrayList<>();
        TreeNode<V> n = this;
        while (n.parent() != null) {
            list.addAll(Lists.reverse(n.display));
            n = n.parent();
        }
        List<String> reverse = Lists.reverse(list);
        for (int i = reverse.size(); i < len; i++) {
            reverse.add("");
        }
        return reverse;
    }

    public List<String> displayWithLabel(List<Column> displayColumns) {
        List<String> displayValues = this.display(displayColumns.size());
        if (isLeaf()) return displayValues;
        if (key == null) {
            displayValues.set(0, "总计");
            return displayValues;
        }

        int labelIndex = 0;
        int level = this.popKeys().size();
        Set<String> exist = new HashSet<>();
        for (int i = 0; i < displayValues.size(); i++) {
            Column column = displayColumns.get(i);
            // 时间字段，group值一样，但是层级算两层，这里要区分一下
            String group = column.isTimeColumn()
                    ? column.getGroup() + i
                    : column.getGroup();
            if (exist.add(group) && exist.size() == level) {
                labelIndex = i;
            } else if (exist.size() == level) {
                displayValues.set(i, "");
            }
        }
        displayValues.set(labelIndex, "小计");
        return displayValues;
    }

    public boolean isLeaf() {
        return children == null || children.isEmpty();
    }

    public TreeNode<V> parent() {
        return parent;
    }

    public List<TreeNode<V>> children() {
        return children;
    }

    /**
     * 根据当前节点，向上遍历父节点，构建table的rowKey，colKey用
     */
    public List<String> popKeys() {
        List<String> list = new ArrayList<>();
        TreeNode<V> n = this;
        while (n.parent() != null) {
            list.add(n.key());
            n = n.parent();
        }
        return Lists.reverse(list);
    }

    /**
     * 后续遍历树
     *
     * @param consumer 节点数据消费者
     */
    public void walk(Consumer<TreeNode<V>> consumer) {
        if (!isLeaf()) {
            children.forEach(c -> c.walk(consumer));
        }
        consumer.accept(this);
    }

    public TreeNode<V> find(String key) {
        if (cached == null) cached = new HashMap<>();
        return cached.get(key);
    }

    public TreeNode<V> deepFind(Key key) {
        var node = this;
        for (String group : key.getGroupValues()) {
            if (node == null) {
                System.out.println("TreeNode deepFind failed " + key.key);
                return null;
            }
            node = node.find(group);
        }
        return node;
    }

    public TreeNode<V> findOrCreate(String key) {
        return findOrCreate(key, null);
    }

    public TreeNode<V> findOrCreate(String key, V value) {
        TreeNode<V> child = find(key);
        if (child == null) {
            child = new TreeNode<>(key, value);
            insert(child);
        }
        return child;
    }

    public void insert(TreeNode<V> child) {
        child.parent = this;
        if (children == null) children = new ArrayList<>();
        if (cached == null) cached = new HashMap<>();
        children.add(child);
        cached.put(child.key, child);
    }

    public void delete(TreeNode<V> child) {
        children.remove(child);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TreeNode<?> treeNode = (TreeNode<?>) o;
        return children.equals(treeNode.children) &&
                Objects.equals(key, treeNode.key) &&
                Objects.equals(value, treeNode.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(children, key, value);
    }
}
