package com.ruihe.admin.event;

import lombok.Data;
import lombok.EqualsAndHashCode;


@Data
@EqualsAndHashCode(callSuper = false)
public class CheckCouponEvent {


}
