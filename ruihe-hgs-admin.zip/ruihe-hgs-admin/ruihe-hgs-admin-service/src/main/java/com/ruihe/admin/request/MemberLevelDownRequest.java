package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-11 15:36
 */
@ApiModel(value = "MemberLevelDownRequest", description = "会员降级新增/编辑请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberLevelDownRequest implements Serializable {

    @ApiModelProperty(value = "降级主键ID,新增的时候不要传")
    private Integer downId;

    @ApiModelProperty(value = "规则主表主键ID")
    private String ruleId;

    @ApiModelProperty(value = "降级后等级编码")
    private String afterLevelCode;

    @ApiModelProperty(value = "降级后等级名称")
    private String afterLevelName;

    @ApiModelProperty(value = "降级后会员等级级别")
    private Integer afterLevel;

    @ApiModelProperty(value = "规则描述")
    private String description;

    @ApiModelProperty(value = "累计金额未达到")
    private BigDecimal accAmt;

    @ApiModelProperty(value = "是否包含首单：0不包含，1包含")
    private Integer includeFirst;
}
