package com.ruihe.admin.listener.report.core;

import com.ruihe.admin.listener.report.utils.FieldUtils;
import lombok.Getter;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * RowKey 和 ColKey 两个可以在table中定位CellValue
 */
@Getter
public class RowKey extends Key {

    public RowKey(List<String> groupValues, List<String> displayValues, int type) {
        super(groupValues,displayValues,type);
    }

    /**
     * @param rowData 数据库查询出来的数据对象
     * @param define  报表定义
     */
    public RowKey(Object rowData, TableDefine define) {
        this.key = buildKey(rowData, define);
    }

    private String buildKey(Object rowData, TableDefine define) {
        StringBuilder key = new StringBuilder();
        Set<String> exist = new HashSet<>();
        define.getHorizontalColumns().forEach(c -> {
            String cv = FieldUtils.readString(rowData, c.getName(), "");
            if (exist.add(c.getGroup())) {
                key.append(cv);
                this.groupValues.add(cv);
            }
            if (c.isShow()) displayValues.add(cv);
        });
        return key.toString();
    }
}
