package com.ruihe.admin.request;

import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * 规则设置-》查询结果一览请求
 *
 * @author William
 */
@ApiModel(value = "IntegralActivityPageQueryRequest", description = "积分规则分页查询请求")
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IntegralActivityPageQueryRequest extends PageForm implements Serializable {
    @ApiModelProperty("活动时间-开始时间")
    private LocalDate startTime;

    @ApiModelProperty("活动时间-结束时间")
    private LocalDate endTime;

    @ApiModelProperty("活动状态,0未开始,1进行中,2已结束,3已停用")
    private Integer status;

}
