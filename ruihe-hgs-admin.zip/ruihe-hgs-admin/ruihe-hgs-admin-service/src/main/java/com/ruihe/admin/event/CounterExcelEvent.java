package com.ruihe.admin.event;


import com.ruihe.admin.request.basic.CounterRequest;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 柜台一览Excel导出
 * @author fly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CounterExcelEvent extends BiReportEvent {

    private CounterRequest request;

    @Builder
    public CounterExcelEvent(CounterRequest request) {
        this.request = request;
    }
}
