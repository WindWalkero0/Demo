package com.ruihe.admin.response;

import com.ruihe.common.annotation.Ella;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Ella(Describe = "可参加活动响应类", Author = "K")
public class ActivitiesAvailableResponse {

    //子活动名称
    public String name;

    //子活动名称
    public String activityId;

    //主题活动名称
    public String subName;

    //主题活动id
    public String subActivityId;

    //主题活动描述
    public String detail;

    //活动类型--对应的是小的类型
    public Integer activityType;

    //主题活动---活动开始时间
    public String startTime;

    //主题活动---活动结束时间
    public String stopTime;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;


}
