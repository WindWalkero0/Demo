package com.ruihe.admin.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.common.dao.bean.base.Region;
import com.ruihe.common.enums.base.RegEnum;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.pojo.response.basic.RegionVo;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.common.service.CustomService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
public class RegionService {

    @Autowired
    private CustomService customService;

    /**
     * 添加柜台区域信息查询
     *
     * @param parentCode
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectRegion(String parentCode, Integer type) {
        List<Region> regions = selectRegByParentCode(parentCode);
        if (regions.isEmpty()) {
            return Response.success(new ArrayList<RegionVo>());
        }
        List<RegionVo> regionVoList = ObjectUtils.toList(regions, RegionVo.class);
        if (!Objects.isNull(type)) {
            //添加柜台需要查询两级
            fillRegion(regionVoList);
        }
        return Response.success(regionVoList);
    }

    /**
     *
     */
    private void fillRegion(List<RegionVo> regionalManages) {
        regionalManages.forEach(e -> {
            for (RegionVo regionVo : regionalManages) {
                if (regionVo.getLevel().equals(RegEnum.LEA_LEVEL.getKey())) {
                    //如果是大区就继续查询下级
                    List<Region> regionList = selectRegByParentCode(regionVo.getRegionCode());
                    regionVo.setRegionList(Region.convert2DTO(regionList));
                }
            }
        });
    }

    /**
     * 查询根据上级code查询下级信息
     *
     * @param parentCode
     * @return
     */
    private List<Region> selectRegByParentCode(String parentCode) {

        return customService.selectList(Region.builder().parentCode(parentCode).isDel(StatusEnum.UN_DELETED.getKey()).type(0).build());
    }
}
