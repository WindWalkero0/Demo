package com.ruihe.admin.request;

import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * 积分导入分页查询请求
 *
 * @author William
 */
@ApiModel(value = "IntegralImportPageRequest", description = "积分导入分页查询请求")
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IntegralImportPageRequest extends PageForm implements Serializable {
    @ApiModelProperty("导入日期-开始时间")
    private LocalDate startTime;

    @ApiModelProperty("导入日期-结束时间")
    private LocalDate endTime;

    @ApiModelProperty("导入名称")
    private String name;
}
