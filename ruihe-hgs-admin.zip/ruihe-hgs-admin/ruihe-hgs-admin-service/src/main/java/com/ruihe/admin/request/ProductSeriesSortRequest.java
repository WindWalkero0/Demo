package com.ruihe.admin.request;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author luojie
 * @program ruihe-top
 * @description 排序修改请求实体类
 * @create: 2021/7/6 16:58
 */
@Data
@ApiOperation(notes = "排序修改请求体", value = "排序修改请求体")
public class ProductSeriesSortRequest implements Serializable {
    @NotNull(message = "id入参不能为空")
    @ApiModelProperty(value = "系列Id, 修改的时候id不能为空")
    private Integer id;
    
    @NotNull(message = "排序值不能为空")
    @Range(min = 1, max = 999, message = "排序值范围为 1~999")
    @ApiModelProperty("排序值 (1-999)")
    private Integer sort;
    
    @NotNull(message = "旧排序值不能为空")
    @Range(min = 1, max = 999, message = "旧排序值范围为 1~999")
    @ApiModelProperty("该系列之前的排序值")
    private Integer oldSort;
}
