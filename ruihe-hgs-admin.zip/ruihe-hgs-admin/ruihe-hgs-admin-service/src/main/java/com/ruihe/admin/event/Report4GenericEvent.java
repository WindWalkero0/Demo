package com.ruihe.admin.event;

import com.ruihe.common.dao.bean.bi.BiGenericReport;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Map;

/**
 * 通用报表事件
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class Report4GenericEvent extends BiReportEvent {
    private Map<String,String> request;
    private BiGenericReport biGenericReport;

    @Builder
    public Report4GenericEvent(Map<String,String> request) {
        this.request = request;
    }
}
