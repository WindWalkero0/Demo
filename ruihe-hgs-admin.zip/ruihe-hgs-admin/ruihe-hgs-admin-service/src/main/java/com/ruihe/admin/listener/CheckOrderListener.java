package com.ruihe.admin.listener;


import com.ruihe.common.annotation.Ella;
import com.ruihe.common.service.AdminTaskService;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.CheckOrderEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;


@Ella(Describe = "校验订单积分库存", Author = "fly")
@Slf4j
@Component
public class CheckOrderListener {

    @Autowired
    private AdminTaskService adminTaskService;

    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(CheckOrderEvent event) {
        try {
            adminTaskService.checkOrder();
        } catch (Exception e) {
            log.error("检查订单积分库存.error,event={}", event, e);
        }
    }

}
