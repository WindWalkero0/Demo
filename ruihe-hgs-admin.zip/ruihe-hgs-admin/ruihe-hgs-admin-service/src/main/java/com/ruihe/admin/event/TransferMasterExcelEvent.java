package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 调拨单主表excel导出
 *
 * @author ly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class TransferMasterExcelEvent extends BiReportEvent {

    private String key;

    @Builder
    public TransferMasterExcelEvent(String key) {
        this.key = key;
    }
}
