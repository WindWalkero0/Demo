package com.ruihe.admin.event;


import com.ruihe.common.annotation.Ella;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Ella(Describe = "校验积分订单会员手机号信息")
@Data
@EqualsAndHashCode(callSuper = false)
public class CheckPhoneEvent {

}
