package com.ruihe.admin.listener;

import com.ruihe.common.annotation.Ella;
import com.ruihe.common.service.AdminTaskService;
import com.ruihe.common.service.PromotionalTaskService;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.OperationStatusEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;


@Ella(Describe = "发放优惠券", Author = "K")
@Slf4j
@Component
public class OperationStatusListener {

    @Autowired
    private AdminTaskService adminTaskService;

    @Autowired
    private PromotionalTaskService promotionalTaskService;

    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(OperationStatusEvent event) {
        try {
            //修改会员活动状态
            adminTaskService.changeActivityStatus();
            //修改促销活动状态
            promotionalTaskService.changePromotionStatus();
            //定时修改发券活动状态
            adminTaskService.changeProCouponStatus();
            //定时修改所有优惠券的状态
            adminTaskService.changeCouponStatus();
            log.info("所有状态修改完毕");
        } catch (Exception e) {
            log.error("发放优惠券.error", e);
        }
    }

}
