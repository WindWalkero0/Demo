package com.ruihe.admin.service.bi;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.UserConcernPo;
import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.admin.enums.BiReportEnum;
import com.ruihe.admin.event.Report4CounterErpEvent;
import com.ruihe.admin.event.Report4ProductErpEvent;
import com.ruihe.admin.mapper.basic.CounterMapper;
import com.ruihe.admin.mapper.basic.UserConcernMapper;
import com.ruihe.admin.request.bi.CounterErpReportRequest;
import com.ruihe.admin.request.bi.CounterErpSelectRequest;
import com.ruihe.admin.request.bi.ProductErpReportRequest;
import com.ruihe.admin.request.bi.ProductErpSelectRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author: ly
 * @Date: 2020-02-06 11:43
 * @Description 1.0
 */
@Service
@Slf4j
public class WhReportService extends AbstractBiReportPreHandler {

    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private UserConcernMapper userConcernMapper;

    @Autowired
    private BiReportService biReportService;

    /**
     * 产品进销存报表查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    public Response productErpReport(ProductErpReportRequest request) {
        //判断时间
        if (request.getStartTime() == null || request.getEndTime() == null) {
            return Response.errorMsg("查询时间不能为空!");
        }
        if (request.getEndTime().isAfter(LocalDate.now())) {
            return Response.errorMsg("查询结束时间不能超过当前时间!");
        }
        if (request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("开始时间不能大于结束时间!");
        }
        //判断柜台是否存在(防止有重名的柜台，使用list进行接收)
        if (StringUtils.isNotBlank(request.getCounterName())) {
            List<CounterInformation> counterInformationList = counterMapper.selectList(Wrappers.<CounterInformation>lambdaQuery()
                    .eq(CounterInformation::getCounterName, request.getCounterName()));
            if (counterInformationList.isEmpty()) {
                return Response.errorMsg("柜台名称有误，请核对后重试!");
            }
        }
        //获取输出信息
        ProductErpSelectRequest productRequest = request.getSelectRequest();
        if (productRequest == null) {
            return Response.errorMsg("输出信息不能为空!");
        }
        if (!productRequest.isPrd() && !productRequest.isCounterId() && !productRequest.isCounterName()) {
            return Response.errorMsg("行不能为空!");
        }
        //获取到当前登录人的信息查询关注部门信息
        List<UserConcernPo> concernPoList = userConcernMapper.selectList(Wrappers.<UserConcernPo>lambdaQuery()
                .eq(UserConcernPo::getEmpId, AdminUserContextHolder.get().getEmpId()));
        //如果关注部门为空，则返回空
        if (concernPoList.isEmpty()) {
            return Response.errorMsg("该账号未关注任何部门，请关注后再查询!");
        }
        //查询正在导出报表的数量
        Integer count = biReportService.getBiReport();
        if (count > 2) {
            return Response.errorMsg("您已有两个报表导出任务，请稍后再导出该报表!");
        }
        //发射导出事件
        Report4ProductErpEvent event = Report4ProductErpEvent
                .builder()
                .request(request)
                .build();
        publishEvent(BiReportEnum.PRODUCT_ERP, event, request.getTag(), request.getPicUrl());
        return Response.success();
    }


    /**
     * 柜台进销存报表查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    public Response counterErpReport(CounterErpReportRequest request) {
        //判断时间
        if (request.getStartTime() == null || request.getEndTime() == null) {
            return Response.errorMsg("查询时间不能为空!");
        }
        if (request.getEndTime().isAfter(LocalDate.now())) {
            return Response.errorMsg("查询结束时间不能超过当前时间!");
        }
        if (request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("开始时间不能大于结束时间!");
        }
        //设置结束时间
        request.setEndTime(request.getEndTime().plusDays(1));
        //判断柜台是否存在（根据产品原型此处是全称查找）
        if (StringUtils.isNotBlank(request.getCounterName())) {
            List<CounterInformation> counterInformationList = counterMapper.selectList(Wrappers.<CounterInformation>lambdaQuery()
                    .eq(CounterInformation::getCounterName, request.getCounterName()));
            if (counterInformationList.isEmpty()) {
                return Response.errorMsg("柜台名称有误，请核对后重试!");
            }
        }
        //获取输出信息
        CounterErpSelectRequest counterRequest = request.getSelectRequest();
        if (counterRequest == null) {
            return Response.errorMsg("输出信息不能为空!");
        }
        if (!counterRequest.isCounter()) {
            return Response.errorMsg("行不能为空!");
        }
        //获取到当前登录人的信息查询关注部门信息
        List<UserConcernPo> concernPoList = userConcernMapper.selectList(Wrappers.<UserConcernPo>lambdaQuery()
                .eq(UserConcernPo::getEmpId, AdminUserContextHolder.get().getEmpId()));
        //如果关注部门为空，则返回空
        if (concernPoList.isEmpty()) {
            return Response.errorMsg("该账号未关注任何部门，请关注后再查询!");
        }
        //查询正在导出报表的数量
        Integer count = biReportService.getBiReport();
        if (count > 2) {
            return Response.errorMsg("您已有两个报表导出任务，请稍后再导出该报表!");
        }
        //发射导出事件
        Report4CounterErpEvent event = Report4CounterErpEvent
                .builder()
                .request(request)
                .build();
        publishEvent(BiReportEnum.COUNTER_ERP, event, request.getTag(), request.getPicUrl());
        return Response.success();
    }
}
