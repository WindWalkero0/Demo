package com.ruihe.admin.service.erp.document;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.request.ExportExcelRequest;
import com.ruihe.admin.service.bi.AbstractBiReportPreHandler;
import com.ruihe.app.client.AppClient;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.warehouse.WhAuditPo;
import com.ruihe.common.dao.bean.warehouse.WhFreeInventoryItemPo;
import com.ruihe.common.dao.bean.warehouse.WhFreeInventoryPo;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.app.dto.CheckFreeInventroyDto;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.pojo.ResultVO;
import com.ruihe.admin.enums.BiReportEnum;
import com.ruihe.admin.event.FreeInvApplyExcelEvent;
import com.ruihe.admin.event.FreeInvItemExcelEvent;
import com.ruihe.admin.event.FreeInvMasterExcelEvent;
import com.ruihe.admin.mapper.basic.ProductMapper;
import com.ruihe.admin.mapper.erp.document.WhAuditMapper;
import com.ruihe.admin.mapper.erp.document.WhFreeInventoryItemMapper;
import com.ruihe.admin.mapper.erp.document.WhFreeInventoryMapper;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.request.erp.WhFreeInventoryApplyRequest;
import com.ruihe.admin.request.erp.WhFreeInventoryQueryRequest;
import com.ruihe.admin.response.erp.WhFreeInventoryApplyResponse;
import com.ruihe.admin.response.erp.WhFreeInventoryQueryResponse;
import com.ruihe.admin.response.erp.WhFreeInventoryResponse;
import com.ruihe.admin.response.erp.WhFreeInventoryResultResponse;
import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;
import com.ruihe.admin.vo.WhFreeInventoryAndItemVo;
import com.ruihe.admin.vo.WhFreeInventoryAuditVo;
import com.ruihe.admin.vo.WhFreeInventoryItemResultVo;
import com.ruihe.admin.vo.WhFreeInventoryItemVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-21 17:53
 */
@Service
@Slf4j
public class FreeInventoryService extends AbstractBiReportPreHandler {

    @Autowired
    private WhFreeInventoryMapper whFreeInventoryMapper;

    @Autowired
    private WhFreeInventoryItemMapper whFreeInventoryItemMapper;

    @Autowired
    private AppClient appClient;

    @Autowired
    private WhAuditMapper whAuditMapper;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;


    /**
     * 自由盘点查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response queryFreeInventory(WhFreeInventoryQueryRequest request) {
        //对日期和页码进行判断
        if (request.getStartTime() != null && request.getEndTime() != null && request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("开始时间不能大于结束时间!");
        }
        if (request.getPageNumber() == null || request.getPageSize() == null || request.getPageSize() == 0 || request.getPageNumber() == 0) {
            return Response.errorMsg("页码不合法!");
        }
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        //获取组织条件查询
        OrgQueryConditionRequest queryRequest = request.getOrgQueryConditionRequest();
        //柜台的状态、类型跟部门的不一致，此处需要转换
        if (queryRequest != null && queryRequest.getOrgType() != null) {
            queryRequest.setOrgType(queryRequest.getOrgType().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CounterEnum.FORMAL_COUNTER.getKey() : CounterEnum.TEST_COUNTER.getKey());
        }
        if (queryRequest != null && queryRequest.getOrgStatus() != null) {
            queryRequest.setOrgStatus(queryRequest.getOrgStatus().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CommonStatusEnum.INVALID.getCode() : CommonStatusEnum.EFFECTIVE.getCode());
        }
        //设置分页条件
        Page<WhFreeInventoryQueryResponse> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询出列表
        IPage<WhFreeInventoryQueryResponse> whFreeInventoryVoIPage = whFreeInventoryMapper.queryFreeInventory(page, request, queryRequest);
        //查询出数据结果
        WhFreeInventoryResultResponse whFreeInventoryResultResponse = whFreeInventoryMapper.queryResult(request, queryRequest);
        //分页展示vo
        PageVO pageVO = PageVO.<WhFreeInventoryQueryResponse>builder()
                .list(whFreeInventoryVoIPage.getRecords())
                .pageNum(whFreeInventoryVoIPage.getCurrent())
                .pageSize(whFreeInventoryVoIPage.getSize())
                .pages(whFreeInventoryVoIPage.getPages())
                .total(whFreeInventoryVoIPage.getTotal())
                .build();
        //记录查询条件
        String uuid = IdGenerator.getShorterSerialNo("ADMIN:FI");
        //存储redis
        redisTemplate.opsForValue().set(uuid, request, 2, TimeUnit.HOURS);
        //返回结果
        return Response.success(WhFreeInventoryResponse.builder()
                .whFreeInventoryResultResponse(whFreeInventoryResultResponse)
                .pageVo(pageVO).key(uuid).build());
    }

    /**
     * 自由盘点申请单查询详情
     *
     * @param applyNo
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response applyItem(String applyNo) {
        //查询主表信息
        WhFreeInventoryPo whFreeInventoryPo = whFreeInventoryMapper.selectById(applyNo);
        //根据主表信息查询子表信息
        List<WhFreeInventoryItemPo> inventoryItemPoList = whFreeInventoryItemMapper.selectList(Wrappers.<WhFreeInventoryItemPo>lambdaQuery()
                .eq(WhFreeInventoryItemPo::getApplyNo, applyNo));
        //设置返回的0.00
        BigDecimal zero = BigDecimal.valueOf(0, 2);
        //查询子表信息中的结果数据
        WhFreeInventoryItemResultVo itemResultVo = inventoryItemPoList.stream().map(e -> {
            WhFreeInventoryItemResultVo resultVo = new WhFreeInventoryItemResultVo();
            resultVo.setBookQty(e.getBookQty());
            resultVo.setRealQty(e.getRealQty());
            if (e.getDiffQty() < 0) {
                resultVo.setInventoryLossesQty(e.getDiffQty());
                resultVo.setInventorySurplusQty(0);
            } else {
                resultVo.setInventoryLossesQty(0);
                resultVo.setInventorySurplusQty(e.getDiffQty());
            }
            if (e.getDiffAmt().compareTo(BigDecimal.ZERO) < 0) {
                resultVo.setInventoryLossesAmt(e.getDiffAmt());
                resultVo.setInventorySurplusAmt(zero);
            } else {
                resultVo.setInventoryLossesAmt(zero);
                resultVo.setInventorySurplusAmt(e.getDiffAmt());
            }
            return resultVo;
        }).reduce((a, b) -> {
            a.setBookQty(a.getBookQty() + b.getBookQty());
            a.setRealQty(a.getRealQty() + b.getRealQty());
            if (a.getInventorySurplusQty() == null) {
                a.setInventorySurplusQty(0);
            }
            if (b.getInventorySurplusQty() == null) {
                b.setInventorySurplusQty(0);
            }
            if (a.getInventorySurplusAmt() == null) {
                a.setInventorySurplusAmt(zero);
            }
            if (b.getInventorySurplusAmt() == null) {
                b.setInventorySurplusAmt(zero);
            }
            if (a.getInventoryLossesQty() == null) {
                a.setInventoryLossesQty(0);
            }
            if (b.getInventoryLossesQty() == null) {
                b.setInventoryLossesQty(0);
            }
            if (a.getInventoryLossesAmt() == null) {
                a.setInventoryLossesAmt(zero);
            }
            if (b.getInventoryLossesAmt() == null) {
                b.setInventoryLossesAmt(zero);
            }
            a.setInventorySurplusQty(a.getInventorySurplusQty() + b.getInventorySurplusQty());
            a.setInventorySurplusAmt(a.getInventorySurplusAmt().add(b.getInventorySurplusAmt()));
            a.setInventoryLossesQty(a.getInventoryLossesQty() + b.getInventoryLossesQty());
            a.setInventoryLossesAmt(a.getInventoryLossesAmt().add(b.getInventoryLossesAmt()));
            return a;
        }).get();
        //获取子表返回信息
        List<WhFreeInventoryItemVo> itemVoList = inventoryItemPoList.stream().map(e -> {
            WhFreeInventoryItemVo whFreeInventoryItemVo = new WhFreeInventoryItemVo();
            BeanUtils.copyProperties(e, whFreeInventoryItemVo);
            //根据产品条码查询产品规格和单位信息
            Product product = productMapper.selectOne(Wrappers.<Product>lambdaQuery().eq(Product::getPrdBarCode, e.getPrdBarCode()));
            whFreeInventoryItemVo.setUnitName(product.getUnitName());
            whFreeInventoryItemVo.setSpec(product.getSpec());
            return whFreeInventoryItemVo;
        }).collect(Collectors.toList());
        //返回前端
        WhFreeInventoryAndItemVo vo = WhFreeInventoryAndItemVo.builder()
                .whFreeInventoryQueryResponse(ObjectUtils.toObject(whFreeInventoryPo, WhFreeInventoryQueryResponse.class))
                .itemVoList(itemVoList)
                .itemResultVo(itemResultVo).build();
        return Response.success(vo);
    }

    /**
     * 自由盘点申请审核
     *
     * @param status
     * @param applyNo
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response invAudit(Integer status, String applyNo) {
        //审核实体类
        CheckFreeInventroyDto checkFreeInventroyDto = CheckFreeInventroyDto.builder()
                .auditCode(AdminUserContextHolder.get().getEmpId())
                .auditName(AdminUserContextHolder.get().getName())
                .deptId(AdminUserContextHolder.get().getDeptCode())
                .deptName(AdminUserContextHolder.get().getDeptName())
                .status(status)
                .applyNo(applyNo).build();
        try {
            ResultVO<?> resultVo = appClient.freeInventoryAudit(checkFreeInventroyDto);
            if (!resultVo.getCode().equals(200)) {
                return Response.error(resultVo.getCode(), resultVo.getData());
            }
            return Response.successMsg("操作成功!");
        } catch (Exception e) {
            log.error("自由盘点处理单审核异常单号,applyNo{},e{}", applyNo, e);
            return Response.errorMsg("审核异常");
        }
    }

    /**
     * 自由盘点申请查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response applyList(WhFreeInventoryApplyRequest request) {
        //对日期和页码进行判断
        if (request.getStartTime() != null && request.getEndTime() != null && request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("开始时间不能大于结束时间!");
        }
        if (request.getPageNumber() == null || request.getPageSize() == null || request.getPageSize() == 0 || request.getPageNumber() == 0) {
            return Response.errorMsg("页码不合法!");
        }
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        //获取组织条件查询
        OrgQueryConditionRequest queryRequest = request.getOrgQueryConditionRequest();
        //柜台的状态、类型跟部门的不一致，此处需要转换
        doOrgQueryConditionRequest(queryRequest);
        //设置分页条件
        Page<WhFreeInventoryApplyResponse> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询出列表
        IPage<WhFreeInventoryApplyResponse> whFreeInventoryVoIPage = whFreeInventoryMapper.applyList(page, request, queryRequest);
        //查询出数据结果
        WhFreeInventoryResultResponse whFreeInventoryResultResponse = whFreeInventoryMapper.applyListResult(request, queryRequest);
        //分页展示vo
        PageVO pageVO = PageVO.<WhFreeInventoryApplyResponse>builder()
                .list(whFreeInventoryVoIPage.getRecords())
                .pageNum(whFreeInventoryVoIPage.getCurrent())
                .pageSize(whFreeInventoryVoIPage.getSize())
                .pages(whFreeInventoryVoIPage.getPages())
                .total(whFreeInventoryVoIPage.getTotal())
                .build();
        //记录查询条件
        String uuid = IdGenerator.getShorterSerialNo("ADMIN:FI");
        //存储redis
        redisTemplate.opsForValue().set(uuid, request, 2, TimeUnit.HOURS);
        //返回结果
        return Response.success(WhFreeInventoryResponse.builder()
                .whFreeInventoryResultResponse(whFreeInventoryResultResponse)
                .pageVo(pageVO).key(uuid).build());
    }

    /**
     * 获取盘点审核数据
     *
     * @param applyNo
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response auditDetail(String applyNo) {
        List<WhAuditPo> auditPoList = whAuditMapper.selectList(Wrappers.<WhAuditPo>lambdaQuery()
                .eq(WhAuditPo::getApplyNo, applyNo)
                //审核单号不为空
                .isNotNull(WhAuditPo::getAuditNo)
                .orderByAsc(WhAuditPo::getId));
        return Response.success(ObjectUtils.toList(auditPoList, WhFreeInventoryAuditVo.class));
    }

    /**
     * 盘点单详情查询
     *
     * @param invNo
     * @return
     */
    public Response invItem(String invNo) {
        //查询主表信息
        WhFreeInventoryPo whFreeInventoryPo = whFreeInventoryMapper.selectOne(Wrappers.<WhFreeInventoryPo>lambdaQuery().eq(WhFreeInventoryPo::getInvNo, invNo));
        //根据主表信息查询子表信息
        List<WhFreeInventoryItemPo> inventoryItemPoList = whFreeInventoryItemMapper.selectList(Wrappers.<WhFreeInventoryItemPo>lambdaQuery()
                .eq(WhFreeInventoryItemPo::getApplyNo, whFreeInventoryPo.getApplyNo()));
        //设置返回的0.00
        BigDecimal zero = BigDecimal.valueOf(0, 2);
        //查询子表信息中的结果数据
        WhFreeInventoryItemResultVo itemResultVo = inventoryItemPoList.stream().map(e -> {
            WhFreeInventoryItemResultVo resultVo = new WhFreeInventoryItemResultVo();
            resultVo.setBookQty(e.getBookQty());
            resultVo.setRealQty(e.getRealQty());
            if (e.getDiffQty() < 0) {
                resultVo.setInventoryLossesQty(e.getDiffQty());
                resultVo.setInventorySurplusQty(0);
            } else {
                resultVo.setInventoryLossesQty(0);
                resultVo.setInventorySurplusQty(e.getDiffQty());
            }
            if (e.getDiffAmt().compareTo(BigDecimal.ZERO) < 0) {
                resultVo.setInventoryLossesAmt(e.getDiffAmt());
                resultVo.setInventorySurplusAmt(zero);
            } else {
                resultVo.setInventoryLossesAmt(zero);
                resultVo.setInventorySurplusAmt(e.getDiffAmt());
            }
            return resultVo;
        }).reduce((a, b) -> {
            a.setBookQty(a.getBookQty() + b.getBookQty());
            a.setRealQty(a.getRealQty() + b.getRealQty());
            if (a.getInventorySurplusQty() == null) {
                a.setInventorySurplusQty(0);
            }
            if (b.getInventorySurplusQty() == null) {
                b.setInventorySurplusQty(0);
            }
            if (a.getInventorySurplusAmt() == null) {
                a.setInventorySurplusAmt(zero);
            }
            if (b.getInventorySurplusAmt() == null) {
                b.setInventorySurplusAmt(zero);
            }
            if (a.getInventoryLossesQty() == null) {
                a.setInventoryLossesQty(0);
            }
            if (b.getInventoryLossesQty() == null) {
                b.setInventoryLossesQty(0);
            }
            if (a.getInventoryLossesAmt() == null) {
                a.setInventoryLossesAmt(zero);
            }
            if (b.getInventoryLossesAmt() == null) {
                b.setInventoryLossesAmt(zero);
            }
            a.setInventorySurplusQty(a.getInventorySurplusQty() + b.getInventorySurplusQty());
            a.setInventorySurplusAmt(a.getInventorySurplusAmt().add(b.getInventorySurplusAmt()));
            a.setInventoryLossesQty(a.getInventoryLossesQty() + b.getInventoryLossesQty());
            a.setInventoryLossesAmt(a.getInventoryLossesAmt().add(b.getInventoryLossesAmt()));
            return a;
        }).get();
        //获取子表返回信息
        List<WhFreeInventoryItemVo> itemVoList = inventoryItemPoList.stream().map(e -> {
            WhFreeInventoryItemVo whFreeInventoryItemVo = new WhFreeInventoryItemVo();
            BeanUtils.copyProperties(e, whFreeInventoryItemVo);
            //根据产品条码查询产品规格和单位信息
            Product product = productMapper.selectOne(Wrappers.<Product>lambdaQuery().eq(Product::getPrdBarCode, e.getPrdBarCode()));
            whFreeInventoryItemVo.setUnitName(product.getUnitName());
            whFreeInventoryItemVo.setSpec(product.getSpec());
            return whFreeInventoryItemVo;
        }).collect(Collectors.toList());
        //返回前端
        WhFreeInventoryAndItemVo vo = WhFreeInventoryAndItemVo.builder()
                .whFreeInventoryQueryResponse(ObjectUtils.toObject(whFreeInventoryPo, WhFreeInventoryQueryResponse.class))
                .itemVoList(itemVoList)
                .itemResultVo(itemResultVo).build();
        return Response.success(vo);
    }

    /**
     * 对柜台状态进行处理转换
     *
     * @param queryRequest
     */
    private void doOrgQueryConditionRequest(OrgQueryConditionRequest queryRequest) {
        //柜台的状态、类型跟部门的不一致，此处需要转换
        if (queryRequest != null && queryRequest.getOrgType() != null) {
            queryRequest.setOrgType(queryRequest.getOrgType().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CounterEnum.FORMAL_COUNTER.getKey() : CounterEnum.TEST_COUNTER.getKey());
        }
        if (queryRequest != null && queryRequest.getOrgStatus() != null) {
            queryRequest.setOrgStatus(queryRequest.getOrgStatus().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CommonStatusEnum.INVALID.getCode() : CommonStatusEnum.EFFECTIVE.getCode());
        }
    }

    /**
     * 自由盘点申请详情导出
     *
     * @param request
     * @return
     */
    public Response exportApply(ExportExcelRequest request) {
        //根据条件查询数据
        WhFreeInventoryApplyRequest applyRequest = (WhFreeInventoryApplyRequest) redisTemplate.opsForValue().get(request.getKey());
        //判空
        if (applyRequest == null) {
            return Response.errorMsg("查询条件已过期，请重新进行查询!");
        }
        //获取组织条件查询
        OrgQueryConditionRequest queryRequest = applyRequest.getOrgQueryConditionRequest();
        //获取导出数据总量
        Long count = whFreeInventoryMapper.applyListCount(applyRequest, queryRequest);
        if (count > 50000) {
            return Response.errorMsg("导出数据不能超过5万条!");
        }
        if (count == 0) {
            return Response.errorMsg("未查询到数据!");
        }
        FreeInvApplyExcelEvent event = FreeInvApplyExcelEvent.builder().key(request.getKey()).build();
        publishEvent(BiReportEnum.INVENTORY_APPLY, event, request.getRemark(), request.getPicUrl());
        return Response.successMsg("导出成功，请到下载中心进行下载!");
    }

    /**
     * 自由盘点主表导出
     *
     * @param request
     * @return
     */
    public Response exportMaster(ExportExcelRequest request) {
        //根据条件查询数据
        WhFreeInventoryQueryRequest applyRequest = (WhFreeInventoryQueryRequest) redisTemplate.opsForValue().get(request.getKey());
        //判空
        if (applyRequest == null) {
            return Response.errorMsg("查询条件已过期，请重新进行查询!");
        }
        //获取组织条件查询
        OrgQueryConditionRequest queryRequest = applyRequest.getOrgQueryConditionRequest();
        //获取导出数据总量
        Long count = whFreeInventoryMapper.queryMasterListCount(applyRequest, queryRequest);
        if (count > 50000) {
            return Response.errorMsg("导出数据不能超过5万条!");
        }
        if (count == 0) {
            return Response.errorMsg("未查询到数据!");
        }
        FreeInvMasterExcelEvent event = FreeInvMasterExcelEvent.builder().key(request.getKey()).build();
        publishEvent(BiReportEnum.INVENTORY_MASTER, event, request.getRemark(), request.getPicUrl());
        return Response.successMsg("导出成功，请到下载中心进行下载!");
    }

    /**
     * 自由盘点子表导出
     *
     * @param request
     * @return
     */
    public Response exportItem(ExportExcelRequest request) {
        //根据条件查询数据
        WhFreeInventoryQueryRequest applyRequest = (WhFreeInventoryQueryRequest) redisTemplate.opsForValue().get(request.getKey());
        //判空
        if (applyRequest == null) {
            return Response.errorMsg("查询条件已过期，请重新进行查询!");
        }
        //获取组织条件查询
        OrgQueryConditionRequest queryRequest = applyRequest.getOrgQueryConditionRequest();
        //获取导出数据总量
        Long count = whFreeInventoryMapper.queryItemListCount(applyRequest, queryRequest);
        if (count > 50000) {
            return Response.errorMsg("导出数据不能超过5万条!");
        }
        if (count == 0) {
            return Response.errorMsg("未查询到数据!");
        }
        //发射事件进行导出处理
        FreeInvItemExcelEvent event = FreeInvItemExcelEvent.builder().key(request.getKey()).build();
        publishEvent(BiReportEnum.INVENTORY_ITEM, event, request.getRemark(), request.getPicUrl());
        return Response.successMsg("导出成功，请到下载中心进行下载!");
    }
}
