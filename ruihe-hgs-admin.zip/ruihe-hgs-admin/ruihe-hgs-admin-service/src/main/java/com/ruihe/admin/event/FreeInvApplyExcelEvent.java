package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 盘点申请详情excel导出
 *
 * @author ly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class FreeInvApplyExcelEvent extends BiReportEvent {

    private String key;

    @Builder
    public FreeInvApplyExcelEvent(String key) {
        this.key = key;
    }
}
