package com.ruihe.admin.listener.report.core;

import com.ruihe.admin.listener.report.utils.NumberUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/**
 * 列依赖计算相关
 * 有些列数据需要依赖其他列计算得到，不需要从数据库中查询
 * 比如 客单价 = 销售总金额 / 销售总单数
 */
public enum CalculateFunc {
    DIV,
    ;

    public void divide(CellValue cellValue, Column column, TableDefine define) {
        List<Column> deps = column.getDeps();
        int targetIndex = define.indexValueColumn(column);
        int indexFz = define.indexValueColumn(deps.get(0));
        int indexFm = define.indexValueColumn(deps.get(1));
        BigDecimal fz = NumberUtils.toBigDecimal(cellValue.data().get(indexFz));
        BigDecimal fm = NumberUtils.toBigDecimal(cellValue.data().get(indexFm));
        BigDecimal result = BigDecimal.ZERO;
        if (fm.compareTo(BigDecimal.ZERO) != 0) {
            result = fz.divide(fm, 3, RoundingMode.HALF_UP);
        }
        cellValue.data().set(targetIndex, result);
    }
}
