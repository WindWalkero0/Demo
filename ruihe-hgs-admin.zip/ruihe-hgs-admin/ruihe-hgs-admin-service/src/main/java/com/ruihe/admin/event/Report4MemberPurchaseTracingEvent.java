package com.ruihe.admin.event;

import com.ruihe.admin.request.bi.MemberPurchaseTraceReportRequest;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 会员购买跟踪报表事件
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class Report4MemberPurchaseTracingEvent extends BiReportEvent {

    private MemberPurchaseTraceReportRequest request;

    @Builder
    public Report4MemberPurchaseTracingEvent(MemberPurchaseTraceReportRequest request) {
        this.request = request;
    }
}
