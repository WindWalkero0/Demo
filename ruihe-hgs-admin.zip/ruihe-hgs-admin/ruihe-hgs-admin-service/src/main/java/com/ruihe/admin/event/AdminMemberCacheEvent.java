package com.ruihe.admin.event;

import com.ruihe.common.dao.bean.member.MemberInfo;
import lombok.Data;


@Data
public class AdminMemberCacheEvent {

    private MemberInfo memberInfo;


    public AdminMemberCacheEvent(MemberInfo memberInfo) {
        this.memberInfo = memberInfo;
    }

}
