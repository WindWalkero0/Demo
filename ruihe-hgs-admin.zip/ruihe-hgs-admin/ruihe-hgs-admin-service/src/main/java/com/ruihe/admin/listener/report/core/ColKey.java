package com.ruihe.admin.listener.report.core;

import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.listener.report.utils.DateUtils;
import com.ruihe.admin.listener.report.utils.FieldUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 构建 TreeBasedTable 所需的列索引
 */
public class ColKey extends Key {

    public ColKey(List<String> groupValues, List<String> displayValues, int type) {
        super(groupValues, displayValues, type);
    }

    /**
     * @param rowData 数据库查询出来的行数据对象
     * @param define  报表定义
     */
    public ColKey(Object rowData, TableDefine define) {
        this.key = this.buildKey(rowData, define);
    }

    private String buildKey(Object rowData, TableDefine define) {
        final StringBuilder key = new StringBuilder();
        Set<String> exist = new HashSet<>();
        define.getVerticalColumns().forEach(col -> {
            String value = FieldUtils.readString(rowData, col.getName(), "");
            String month = null;
            String day = null;
            if (exist.add(col.getGroup())) {
                // 处理时间字段
                if (col.isTimeColumn()) {
                    String[] time = timeParse(define, value);
                    month = time[0];
                    day = time[1];
                    if (month != null) {
                        key.append(month);
                        groupValues.add(month);
                    }
                    if (day != null) {
                        key.append(day);
                        groupValues.add(day);
                    }
                } else {
                    String groupVal = FieldUtils.readGroupValue(rowData, col, value);
                    key.append(groupVal);
                    groupValues.add(groupVal);
                }
            }

            if (col.isTimeColumn()) {
                if (month != null) {
                    displayValues.add(month);
                }
                if (day != null) {
                    displayValues.add(day);
                }
            } else if (col.isShow()) {
                displayValues.add(value);
            }
        });
        return key.toString();
    }

    private String[] timeParse(TableDefine define, String value) {
        String month = null;
        String day = null;
        String[] time = {null, null};
        if (define.isMonthly() && define.isDaily()) {
            if (!StringUtils.isBlank(value)) {
                // 202006
                if (value.length() == 6) {
                    month = value;
                } else {
                    LocalDate localDate = DateUtils.toDay(value);
                    // 25号是财务日，需要将25号以后的归到下个月
                    if (localDate.getDayOfMonth() > CommonConstant.TEWENTY_FIVE) {
                        month = DateUtils.formatMonth(localDate.plusMonths(1));
                    } else {
                        month = DateUtils.formatMonth(localDate);
                    }
                    day = value;
                }
            }
        } else if (define.isMonthly()) {
            month = value;
        } else if (define.isDaily()) {
            day = value;
        }
        time[0] = month;
        time[1] = day;
        return time;
    }
}