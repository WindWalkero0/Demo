package com.ruihe.admin.event;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 柜台操作（包括新增和修改）事件
 * @author qubin
 * @date 2021/4/26 9:45
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class CounterOperateEvent {

    private String counterId;

    @Builder
    public CounterOperateEvent(String counterId) {
        this.counterId = counterId;
    }
}
