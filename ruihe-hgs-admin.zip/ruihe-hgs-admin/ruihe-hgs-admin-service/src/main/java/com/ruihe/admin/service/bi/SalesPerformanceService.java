package com.ruihe.admin.service.bi;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.bean.base.UserConcernPo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.admin.enums.BiReportEnum;
import com.ruihe.admin.event.Report4SalesPerfEvent;
import com.ruihe.admin.mapper.basic.UserConcernMapper;
import com.ruihe.admin.request.bi.SalesPerfReportRequest;
import com.ruihe.admin.request.bi.SalesPerfSelectRequest;
import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

/**
 * 销售业绩分析报表
 *
 * @Anthor:Fangtao
 * @Date:2020/2/5 10:47
 */
@Service
@Slf4j
public class SalesPerformanceService extends AbstractBiReportPreHandler {

    @Autowired
    private UserConcernMapper userConcernMapper;

    @Autowired
    private BiReportService biReportService;

    /**
     * 销售业绩报表
     */
    @DS(DBConst.MASTER)
    public Response saleAchievement(SalesPerfReportRequest request) {
        //判断输出项
        SalesPerfSelectRequest selectRequest = request.getSelectRequest();
        if (selectRequest == null) {
            return Response.errorMsg("没有选择任何的输出项!");
        }
        //行选择判断
        if (!isRowItemSelected(selectRequest)) {
            return Response.errorMsg("请选择行!");
        }
        if (!isStatItemSelected(selectRequest)) {
            return Response.errorMsg("请选择统计项!");
        }
        //日期设置判断
        if (request.getStartTime() == null || request.getEndTime() == null) {
            return Response.errorMsg("购买查询时间不能大于为空!");
        }
        if (request.getEndTime().isAfter(LocalDate.now())) {
            return Response.errorMsg("结束时间不能大于当前时间!");
        }
        if (request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("开始时间不能大于结束时间!");
        }
        //获取到当前登录人的信息查询关注部门信息
        List<UserConcernPo> concernPoList = userConcernMapper.selectList(Wrappers.<UserConcernPo>lambdaQuery()
                .eq(UserConcernPo::getEmpId, AdminUserContextHolder.get().getEmpId()));
        //如果关注部门为空，则返回空
        if (concernPoList.isEmpty()) {
            return Response.errorMsg("该账号未关注任何部门，请关注后再查询!");
        }
        //查询正在导出报表的数量
        Integer count = biReportService.getBiReport();
        if (count > 2) {
            return Response.errorMsg("您已有两个报表导出任务，请稍后再导出该报表!");
        }
        Report4SalesPerfEvent event = Report4SalesPerfEvent.builder().request(request).build();
        publishEvent(BiReportEnum.SALES_ERP, event, request.getTag(), request.getPicUrl());
        return Response.success();
    }

    /**
     * 有没有选择组织结构项
     *
     * @param selectRequest
     * @return
     */
    private boolean isRowItemSelected(SalesPerfSelectRequest selectRequest) {
        boolean bValid = selectRequest.isArea();
        bValid = bValid || selectRequest.isOffice();
        bValid = bValid || selectRequest.isPrincipal();
        bValid = bValid || selectRequest.isCounterId();
        bValid = bValid || selectRequest.isCounterName();
        bValid = bValid || selectRequest.isBaCode();
        bValid = bValid || selectRequest.isBaName();
        return bValid;
    }

    /**
     * 有没有选择统计项
     *
     * @param selectRequest
     * @return
     */
    private boolean isStatItemSelected(SalesPerfSelectRequest selectRequest) {
        boolean bValid = selectRequest.isRealAmt();
        bValid = bValid || selectRequest.isGoodsQty();
        bValid = bValid || selectRequest.isOrderQty();
        bValid = bValid || selectRequest.isPct();
        bValid = bValid || selectRequest.isJr();
        bValid = bValid || selectRequest.isOptNewMem();
        bValid = bValid || selectRequest.isSalesDays();
        bValid = bValid || selectRequest.isVetPct();
        bValid = bValid || selectRequest.isVetPur();
        bValid = bValid || selectRequest.isOptNewPct();
        bValid = bValid || selectRequest.isNewRepurRate();
        bValid = bValid || selectRequest.isVetRepurRate();
        return bValid;
    }
}
