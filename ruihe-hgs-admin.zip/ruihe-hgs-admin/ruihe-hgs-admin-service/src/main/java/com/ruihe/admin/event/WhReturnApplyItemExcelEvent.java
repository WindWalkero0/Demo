package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 退库申请明细Excel导出
 * @author fly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WhReturnApplyItemExcelEvent extends BiReportEvent {

    private String key;

    @Builder
    public WhReturnApplyItemExcelEvent(String key) {
        this.key = key;
    }
}
