package com.ruihe.admin.response;

import com.ruihe.common.dao.bean.member.MemberActivityProduct;
import com.ruihe.common.dao.bean.member.MemberActivitySon;
import com.ruihe.common.annotation.Ella;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@Ella(Describe = "可参加活动详情响应类", Author = "K")
public class ActivitiesAvailableDetailResponse extends MemberActivitySon {

    @ApiModelProperty(value = "奖励商品集合")
    List<MemberActivityProduct> products;
}
