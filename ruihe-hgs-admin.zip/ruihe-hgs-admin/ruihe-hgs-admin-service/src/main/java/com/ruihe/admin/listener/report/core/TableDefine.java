package com.ruihe.admin.listener.report.core;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Getter
@Setter
public abstract class TableDefine {
    public static final int TOTAL_NONE = 0x0000;
    public static final int TOTAL_ROW_SUB = 0x0001;
    public static final int TOTAL_ROW_FULL = 0x0010;
    public static final int TOTAL_COL_SUB = 0x0100;
    public static final int TOTAL_COL_FULL = 0x1000;
    public static final int TOTAL_ROW = TOTAL_ROW_SUB | TOTAL_ROW_FULL;
    public static final int TOTAL_COL = TOTAL_COL_SUB | TOTAL_COL_FULL;
    public static final int TOTAL_ALL = TOTAL_ROW_SUB | TOTAL_ROW_FULL | TOTAL_COL_SUB | TOTAL_COL_FULL;

    public static final int DEFAULT_ROW_START = 0;

    /**
     * 查询需要的列，行维度，不包含统计数据字段，统计字段在valueColumn中
     */
    private final List<Column> horizontalColumns = new ArrayList<>();

    /**
     * 查询需要的列，列维度，不包含统计数据字段，统计字段在valueColumn中
     */
    private final List<Column> verticalColumns = new ArrayList<>();

    /**
     * 只包含groupBy的列, 去除重复group by 字段，比如柜台号，柜台名group by都是counter_id
     */
    private final List<Column> groupColumns = new ArrayList<>();

    /**
     * 统计结果的列，构建CellValue
     */
    private final List<Column> valueColumns = new ArrayList<>();

    private Map<Column, Integer> valueColumnIndexCache = new HashMap<>();

    /**
     * 是否计算行小计，行总计,列小计，列总计
     */
    private int totalFlag = 0;

    /**
     * 距离sheet第一行的偏移量
     */
    private int rowStart = TableDefine.DEFAULT_ROW_START;

    /**
     * 是否统计年月
     */
    private boolean monthly = false;
    /**
     * 是否统计日期
     */
    private boolean daily = false;

    private LocalDate startTime;
    private LocalDate endTime;

    /**
     * 行维度字段
     */
    public void addHorizontalColumn(Column c, boolean add) {
        if (add) {
            this.horizontalColumns.add(c);
            this.addGroupColumn(c);
        }
    }

    /**
     * 列维度字段
     */
    public void addVerticalColumn(Column c, boolean add) {
        if (add) {
            verticalColumns.add(c);
            this.addGroupColumn(c);
        }
    }

    private void addGroupColumn(Column c) {
        if (groupColumns.stream().noneMatch(e -> e.getGroup().equals(c.getGroup()))) {
            this.groupColumns.add(c);
        }
    }

    /**
     * 添加统计字段
     */
    public void addValueColumn(Column c, boolean add) {
        if (add) {
            valueColumns.add(c);
            valueColumnIndexCache.put(c, valueColumns.size() - 1);
        }
    }

    public int indexValueColumn(Column column) {
        return valueColumnIndexCache.get(column);
    }

    /**
     * 构建自定义表头所需的数据库查询字段，排除时间字段
     */
    public String headSelectCols() {
        return verticalColumns.stream()
                .filter(c -> !c.isTimeColumn())
                .map(c -> c.getSelect().replace(ColumnDefine.ALIAS, c.getPrefix()))
                .collect(Collectors.joining(","));
    }

    /**
     * 构建自定义表头所需的数据库group by 字段，排除时间字段
     */
    public String headGroupCols() {
        return verticalColumns.stream()
                .filter(c -> !c.isTimeColumn())
                .filter(FilterFunc.distinctByKey(Column::getGroup))
                .map(c -> c.getGroup().replace(ColumnDefine.ALIAS, c.getPrefix()))
                .collect(Collectors.joining(","));
    }

    public String selectCols() {
        return selectCols(Column::getPrefix);
    }

    public String selectCols(String alias) {
        return selectCols(c -> alias);
    }

    public String selectCols(Function<Column, String> func) {
        return Stream.concat(horizontalColumns.stream(), verticalColumns.stream())
                .filter(c -> !StringUtils.isEmpty(c.getSelect()))
                .filter(FilterFunc.timeFilter(this))
                .map(c -> c.getSelect().replace(ColumnDefine.ALIAS, func.apply(c)))
                .collect(Collectors.joining(","));
    }

    public String selectCols(int hl, int vl, String alias) {
        List<Column> list = levelColumns(hl,vl);
        int tc = (int)list.stream().filter(c->c.getGroup().equals("time")).count();
        return list.stream()
                .filter(c -> !StringUtils.isEmpty(c.getSelect()))
                .filter(FilterFunc.timeFilter(this, tc == 2))
                .map(c -> c.getSelect().replace(ColumnDefine.ALIAS, alias))
                .collect(Collectors.joining(","));
    }

    public String groupCols() {
        return groupCols(Column::getPrefix);
    }

    public String groupCols(String alias) {
        return groupCols(c -> alias);
    }

    public String groupCols(Function<Column, String> func) {
        return groupColumns.stream()
                .filter(c -> !StringUtils.isEmpty(c.getGroup()))
                .map(c -> c.getGroup().replace(ColumnDefine.ALIAS, func.apply(c)))
                .collect(Collectors.joining(","));
    }

    public String groupCols(int hl, int vl, String alias) {
        return levelColumns(hl,vl).stream()
                .filter(c -> !StringUtils.isEmpty(c.getGroup()))
                .filter(FilterFunc.distinctByKey(Column::getGroup))
                .map(c -> c.getGroup().replace(ColumnDefine.ALIAS, alias))
                .collect(Collectors.joining(","));
    }

    private List<Column> levelColumns(int hl, int vl) {
        List<Column> list = new ArrayList<>();
        int level = 0;
        String group = "";
        for (Column column : horizontalColumns) {
            if (!column.getGroup().equals(group)) level++;
            if (level <= hl) list.add(column);
            group = column.getGroup();
        }

        level = 0;
        group = "";
        for (Column column : verticalColumns) {
            if (column.isTimeColumn()) {
                level++;
            } else if (!column.getGroup().equals(group)) {
                level++;
            }
            if (level <= vl) list.add(column);
            group = column.getGroup();
        }
        return list;
    }

    public List<Column> horizontalDisplayColumns() {
        return horizontalColumns.stream()
                .filter(Column::isShow)
                .collect(Collectors.toList());
    }

    public List<Column> verticalDisplayColumns() {
        return verticalColumns.stream()
                .filter(Column::isShow)
                .collect(Collectors.toList());
    }

    public List<Column> valueDisplayColumns() {
        return valueColumns.stream()
                .filter(Column::isShow)
                .collect(Collectors.toList());
    }

    public int horizontalLevel() {
        return (int) horizontalColumns.stream()
                .filter(FilterFunc.distinctByKey(Column::getGroup))
                .count();
    }

    public int verticalLevel() {
        int level = (int) verticalColumns.stream()
                .filter(c -> !c.isTimeColumn())
                .filter(FilterFunc.distinctByKey(Column::getGroup))
                .count();
        if (monthly) level++;
        if (daily) level++;
        return level;
    }

    /**
     * 是否不需要统计小计和总计
     */
    public boolean totalNone() {
        return totalFlag == 0;
    }

    /**
     * 是否需要统计行小计
     */
    public boolean rowSubtotal() {
        return (totalFlag & TOTAL_ROW_SUB) != 0;
    }

    /**
     * 是否需要统计行总计
     */
    public boolean rowTotal() {
        return (totalFlag & TOTAL_ROW_FULL) != 0;
    }

    /**
     * 是否需要统计列小计
     */
    public boolean colSubtotal() {
        return (totalFlag & TOTAL_COL_SUB) != 0;
    }

    /**
     * 是否需要统计列总计
     */
    public boolean colTotal() {
        return (totalFlag & TOTAL_COL_FULL) != 0;
    }
}
