package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-31 11:14
 */
@ApiModel(value = "DepartmentQueryRequest", description = "部门管理请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class DepartmentRequest implements Serializable {

    @ApiModelProperty(value = "部门代码--必填")
    private String deptId;

    @ApiModelProperty(value = "所属品牌--必填")
    private String brandName;

    @ApiModelProperty(value = "部门类型--必填")
    private Integer deptType;

    @ApiModelProperty(value = "上级部门id--必填")
    private String upDeptId;

    @ApiModelProperty(value = "上级部门名称--必填")
    private String upDeptName;

    @ApiModelProperty(value = "上级部门类型--必填")
    private Integer upDeptType;

    @ApiModelProperty(value = "测试区分--必填")
    private Integer isTest;

    @ApiModelProperty(value = "部门名称--必填")
    @Size(max = 50,message = "部门名称最大长度为50个字符")
    private String deptName;

    @ApiModelProperty(value = "状态：1启用/0停用")
    private Integer status;
}
