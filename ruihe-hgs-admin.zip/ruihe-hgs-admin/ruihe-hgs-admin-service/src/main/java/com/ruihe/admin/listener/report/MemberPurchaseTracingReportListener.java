package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.admin.listener.report.core.ReportController;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.Report4MemberPurchaseTracingEvent;
import com.ruihe.admin.mapper.bi.MemberReportMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.response.bi.MemberPurchaseResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.List;

/***
 * 产品业务明细报表
 * @author lrc
 */
@Component
@RequiredArgsConstructor
public class MemberPurchaseTracingReportListener extends AbstractReportListener<Report4MemberPurchaseTracingEvent> {
    private final MemberReportMapper memberReportMapper;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_REPORT)
    @EventListener
    public void onApplicationEvent(Report4MemberPurchaseTracingEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    public void doExport(Report4MemberPurchaseTracingEvent event, BiReportPo report, boolean flag) {
        TableDefine define = MemberPurchaseTracingDefine.create(event.getRequest());

        ReportController controller = new ReportController(define);
        controller.name("会员购买跟踪报表");
        controller.savePath(report.getFilePath());

        List<MemberPurchaseResponse> base = memberReportMapper.memberPurchaseTrace(
                null,
                event.getRequest(),
                null,
                define.selectCols(),
                define.groupCols(),
                event.getReport().getUid(),
                flag);
        controller.fillData(base);
        controller.totalCalculate();
        controller.write(this.imgPath, report.getPicUrl());
    }
}
