package com.ruihe.admin.listener.report.core;

import com.google.common.collect.TreeBasedTable;

import java.util.*;
import java.util.stream.Collectors;

public class BiReport {
    /**
     * 保存数据的核心对象
     */
    final TreeBasedTable<RowKey, ColKey, CellValue> table = TreeBasedTable.create();

    /**
     * 行层级树,用于计算行小记，行总计
     * 可以理解为，excel表左侧外面有个根节点，每一层对于RowKey的一个层级
     */
    private final TreeNode<TreeMap<ColKey, CellValue>> rowTree = new TreeNode<>();

    /**
     * 列层级树
     */
    private final TreeNode<TreeMap<RowKey, CellValue>> colTree;

    private final TableDefine define;

    private final HeadProvider provider;
    private final CellValue defaultValue;

    public BiReport(TableDefine define) {
        this.define = define;
        this.provider = new HeadProviderByDefine(define);
        this.defaultValue = new CellValue(define.getValueColumns());
        this.colTree = this.provider.colTree();
    }

    public BiReport(TableDefine define, HeadProvider provider) {
        this.define = define;
        this.provider = provider;
        this.defaultValue = new CellValue(define.getValueColumns());
        this.colTree = this.provider.colTree();
    }

    /**
     * 返回表格一行的完整数据,用于excel行写入，包括需要显示的列，以及统计结果数据
     *
     * @param rowKey 行索引
     * @return 表格一行的完整数据, 基础数据+统计数据
     */
    public List<Object> readRow(RowKey rowKey, Map<ColKey, CellValue> colMap) {
        if (!rowKey.showable(define.getTotalFlag())) {
            return null;
        }

        // 先复制基础数据
        List<Object> rowData = new ArrayList<>(rowKey.displayValues());

        // 再添加统计数据部分
        Set<ColKey> headCols = provider.colKeys();
        headCols.forEach(ck -> {
            CellValue value = colMap.get(ck);
            if (value == null) {
                value = defaultValue;
            }
            if (ck.showable(define.getTotalFlag())) {
                value.read(rowData::add);
            }
        });
        return rowData;
    }

    public List<List<String>> head() {
        return provider.head();
    }

    public void fillData(List<?>... data) {
        for (List<?> list : data) {
            fillData(list);
        }
    }

    /**
     * 数据库查询出来的数据填充到table中，
     * 并按照行列层级构建层级树，用于计算小计，总计
     *
     * @param list 数据库查询结果集
     */
    public void fillData(List<?> list) {
        for (Object item : list) {
            RowKey rowKey = new RowKey(item, define);
            ColKey colKey = new ColKey(item, define);
            CellValue cv = table.get(rowKey, colKey);
            if (cv == null) {
                cv = new CellValue(item, define.getValueColumns());
                table.put(rowKey, colKey, cv);
                setColTreeNodeValue(rowKey, colKey, cv);
                insertRowTreeNode(rowKey, colKey, cv);
            } else {
                cv.fill(item);
            }
            cv.calculate(define);
        }
    }

    /**
     * 自定义查询填充小计总计
     */
    public void fillTotal(TotalQuery query) {
        int hl = define.horizontalLevel();
        int vl = define.verticalLevel();
        for (int h = 0; h <= hl; h++) {
            for (int v = 0; v <= vl; v++) {
                // 全量数据不需要查询
                if ((h == hl && v == vl)) {
                    break;
                }
                String selectCols = define.selectCols(h, v, query.alias());
                String groupCols = define.groupCols(h, v, query.alias());

                int dayOrMonth = 0;
                if (selectCols.contains("DATE_FORMAT")) {
                    dayOrMonth = 1;
                } else if (selectCols.contains(" > 25 ")) {
                    dayOrMonth = 2;
                }

                List<?> data = query.doQuery(selectCols, groupCols, dayOrMonth);
                fillTotal(data);
            }
        }
    }

    public void fillTotal(List<?> data) {
        data.forEach(item -> {
            RowKey rowKey = new RowKey(item, define);
            ColKey colKey = new ColKey(item, define);
            CellValue cv = table.get(rowKey, colKey);
            if (cv == null) {
                cv = new CellValue(item, define.getValueColumns());
                table.put(rowKey, colKey, cv);
            } else {
                cv.fill(item);
            }
            cv.calculate(define);
        });
    }

    /**
     * 找到列维度树叶子节点对象，将cellValue设置为节点value
     * colTree 已经在Head中构建好了
     */
    private void setColTreeNodeValue(RowKey rowKey, ColKey colKey, CellValue cv) {
        var colNode = colTree.deepFind(colKey);
        if (colNode != null) {
            colNode.value(TreeMap::new).put(rowKey, cv);
        }
    }

    /**
     * 构建行节点树
     */
    public void insertRowTreeNode(RowKey rowKey, ColKey colKey, CellValue cv) {
        TreeNode<TreeMap<ColKey, CellValue>> rowNode = rowTree;

        // 像柜台号 柜台名 或者 BA编号 BA姓名,这种group by是一个字段，相当与一个层级
        Set<String> exist = new HashSet<>();
        List<Column> columns = define.horizontalDisplayColumns();
        for (int i = 0; i < columns.size(); i++) {
            Column column = columns.get(i);
            String display = rowKey.getDisplayValues().get(i);
            if (exist.add(column.getGroup())) {
                String group = rowKey.getGroupValues().get(exist.size() - 1);
                rowNode = rowNode.findOrCreate(group);
                rowNode.clearDisplay();
            }
            rowNode.addDisplay(display);
        }
        rowNode.value(TreeMap::new).put(colKey, cv);
    }

    public void totalCalculate() {
        if (define.totalNone()) {
            return;
        }

        if (define.rowSubtotal()) {
            rowTree.walk(this::calculateRow);
        } else if (define.rowTotal()) {
            calculateRowTotal();
        }

        colTree.walk(this::calculateCol);
    }

    /**
     * 只计算行总计
     */
    private void calculateRowTotal() {
        List<Column> columns = define.horizontalDisplayColumns();
        List<String> displayValues = columns.stream().map(c -> "").collect(Collectors.toList());
        displayValues.set(0, "总计");

        RowKey totalKey = new RowKey(List.of(""), displayValues, Key.TYPE_TOTAL);
        Map<ColKey, CellValue> totalRow = new TreeMap<>();
        for (RowKey rk : table.rowKeySet()) {
            Map<ColKey, CellValue> row = table.row(rk);
            for (var c : row.entrySet()) {
                CellValue cellValue = totalRow.computeIfAbsent(c.getKey(), ck -> new CellValue(define.getValueColumns()));
                cellValue.plus(c.getValue());
            }
        }
        totalRow.forEach((ck, cv) -> {
            table.put(totalKey, ck, cv);
            // 行总计要放入到列的层级树中，后面计算列总计的时候可以遍历到
            var colNode = colTree.deepFind(ck);
            if (colNode != null) {
                colNode.value(TreeMap::new).put(totalKey, cv);
            }
        });
    }

    /**
     * 计算行小计,总计
     */
    private void calculateRow(TreeNode<TreeMap<ColKey, CellValue>> curNode) {
        // 树的叶子节点是原始数据，不需要计算小计,总计
        if (curNode.isLeaf()) {
            return;
        }
        int type = rowTree == curNode ? Key.TYPE_TOTAL : Key.TYPE_SUB_TOTAL;
        // 不统计行总计
        if (type == Key.TYPE_TOTAL && !define.rowTotal()) {
            return;
        }
        // 不统计行小计
        if (type == Key.TYPE_SUB_TOTAL && !define.rowSubtotal()) {
            return;
        }

        // 对子节点的数据做聚合计算
        TreeMap<ColKey, CellValue> totalled = aggregate(curNode);

        // 将下一层的汇总结果放入当前层的节点
        curNode.value(totalled);

        // 构建table的rowKey，用于插入table中
        List<Column> columns = define.horizontalDisplayColumns();
        List<String> groupValues = curNode.popKeys();
        List<String> displayValues = curNode.displayWithLabel(columns);
        for (ColKey ck : totalled.keySet()) {
            CellValue cellValue = totalled.get(ck);
            RowKey rk = new RowKey(groupValues, displayValues, type);
            table.put(rk, ck, cellValue);

            // 行小计计算的结果要放入到列的层级树中，后面计算列小计的时候可以遍历到
            var colNode = colTree.deepFind(ck);
            if (colNode != null) {
                colNode.value(TreeMap::new).put(rk, cellValue);
            }
        }
    }

    /**
     * 计算列小计，总计
     */
    private void calculateCol(TreeNode<TreeMap<RowKey, CellValue>> curNode) {
        // 树的叶子节点是原始数据，不需要计算小计,总计
        if (curNode.isLeaf()) {
            return;
        }
        int type = curNode == colTree ? Key.TYPE_TOTAL : Key.TYPE_SUB_TOTAL;

        // 不统计列总计
        if (type == Key.TYPE_TOTAL && !define.colTotal()) {
            return;
        }
        // 不统计列小计并且也不统计列总计
        if (type == Key.TYPE_SUB_TOTAL && !define.colSubtotal() && !define.colTotal()) {
            return;
        }

        // 对子节点数据做聚合计算
        TreeMap<RowKey, CellValue> totalled = aggregate(curNode);

        // 将子节点的汇总结果放入当前节点
        curNode.value(totalled);

        // 构建table的colKey，用于插入table中
        int len = define.verticalDisplayColumns().size();
        List<String> groupValues = curNode.popKeys();
        List<String> display = curNode.display(len);
        for (RowKey rowKey : totalled.keySet()) {
            CellValue cellValue = totalled.get(rowKey);
            ColKey colKey = new ColKey(groupValues, display, type);
            table.put(rowKey, colKey, cellValue);
        }
    }

    /**
     * 聚合子节点的统计数据
     */
    private <K> TreeMap<K, CellValue> aggregate(TreeNode<TreeMap<K, CellValue>> curNode) {
        // 对子节点的数据做聚合计算
        TreeMap<K, CellValue> totalled = new TreeMap<>();
        for (var child : curNode.children()) {
            TreeMap<K, CellValue> values = child.value();
            if (values == null) {
                continue;
            }
            values.forEach((k, v) -> {
                CellValue cv = totalled.computeIfAbsent(k, a -> new CellValue(define.getValueColumns()));
                cv.plus(v);
            });
        }
        // 对统计数据的依赖列计算
        totalled.values().forEach(c -> c.calculate(define));
        return totalled;
    }
}
