package com.ruihe.admin.listener.report.core;

import com.ruihe.admin.listener.report.utils.DateUtils;

import java.time.LocalDate;
import java.util.*;

public class HeadProviderByDefine implements HeadProvider {
    protected final TableDefine define;
    protected final TreeNode<TreeMap<RowKey, CellValue>> rootNode = new TreeNode<>();
    protected final List<TreeNode<TreeMap<RowKey, CellValue>>> timeNodes = new ArrayList<>();
    protected final List<List<String>> head = new ArrayList<>();
    //protected final Map<ColKey, CellValue> colKeyMap = new TreeMap<>();
    protected final Set<ColKey> colKeys = new TreeSet<>();
    private boolean init = false;

    public HeadProviderByDefine(TableDefine define) {
        this.define = define;
    }

    @Override
    public List<List<String>> head() {
        if (!init) {
            init();
        }
        return head;
    }

    @Override
    public Set<ColKey> colKeys() {
        if (!init) {
            init();
        }
        return colKeys;
    }

    @Override
    public TreeNode<TreeMap<RowKey, CellValue>> colTree() {
        if (!init) {
            init();
        }
        return rootNode;
    }

    protected void init() {
        buildStaticHead();
        buildColTree();
        buildColKey();
        buildHeadFromColKey();
        init = true;
    }

    /*
     * 构建固定表头
     */
    protected void buildStaticHead() {
        List<Column> displayColumns = define.horizontalDisplayColumns();
        for (int i = 0; i < displayColumns.size(); i++) {
            Column column = displayColumns.get(i);
            List<String> cols = new ArrayList<>();
            // 年月, 日期等标签列放在最后一列字段上面
            if (i == displayColumns.size() - 1) {
                define.verticalDisplayColumns().forEach(c -> cols.add(c.getLabel()));
            } else {
                define.verticalDisplayColumns().forEach(c -> cols.add(""));
            }
            cols.add(column.getLabel());
            head.add(cols);
        }
    }

    /*
     * 根据时间构建列层级树
     */
    protected void buildColTree() {
        LocalDate startTime = define.getStartTime();
        LocalDate endTime = define.getEndTime();

        if (define.isMonthly()) {
            DateUtils.stepByMonth(startTime, endTime, d -> {
                var node = insertMonthNode(d);
                timeNodes.add(node);
            });
        }
        if (define.isDaily()) {
            timeNodes.clear();
            DateUtils.stepByDay(startTime, endTime, d -> {
                var node = insertDayNode(d, define.isMonthly());
                timeNodes.add(node);
            });
        }
    }

    protected void buildColKey() {
        List<Column> columns = define.verticalDisplayColumns();
        rootNode.walk(n -> {
            // 不统计列总计
            if (n == rootNode && !n.isLeaf() && !define.colTotal()) return;
            // 不统计列小计
            if (n != rootNode && !n.isLeaf() && !define.colSubtotal()) return;

            int type = Key.TYPE_NORMAL;
            // 是根节点，并且根节点有叶子节点，说明列维度大于一层，只有一层没有小计总计
            if (n == rootNode && !n.isLeaf()) type = Key.TYPE_TOTAL;
            else if (!n.isLeaf()) type = Key.TYPE_SUB_TOTAL;

            List<String> groupValues = n.popKeys();
            List<String> displayValues = n.displayWithLabel(columns);
            ColKey colKey = new ColKey(groupValues, displayValues, type);
            colKeys.add(colKey);
        });
    }

    protected void buildHeadFromColKey() {
        for (ColKey colKey : colKeys) {
            define.valueDisplayColumns().forEach(c -> {
                List<String> headCol = new ArrayList<>(colKey.displayValues());
                headCol.add(c.getLabel());
                head.add(headCol);
            });
        }
    }

    private TreeNode<TreeMap<RowKey, CellValue>> insertMonthNode(LocalDate date) {
        String time = DateUtils.formatMonth(date);
        var node = rootNode.findOrCreate(time);
        node.addDisplay(time);
        return node;
    }

    private TreeNode<TreeMap<RowKey, CellValue>> insertDayNode(LocalDate date, boolean monthly) {
        String day = DateUtils.formatDay(date);
        if (monthly) {
            String month = DateUtils.formatMonth25(date);
            var node = rootNode.find(month);
            node = node.findOrCreate(day);
            node.addDisplay(day);
            return node;
        } else {
            var node = rootNode.findOrCreate(day);
            node.addDisplay(day);
            return node;
        }
    }

}
