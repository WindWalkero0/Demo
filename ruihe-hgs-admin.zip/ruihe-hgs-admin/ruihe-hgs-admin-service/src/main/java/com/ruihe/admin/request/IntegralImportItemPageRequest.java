package com.ruihe.admin.request;

import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 积分导入明细分页查询请求
 *
 * @author William
 */
@ApiModel(value = "IntegralImportItemPageRequest", description = "积分导入明细分页查询请求")
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IntegralImportItemPageRequest extends PageForm implements Serializable {

    @ApiModelProperty("积分导入流水号")
    private String orderNo;

    @ApiModelProperty("会员手机号")
    private String memberPhone;
}
