package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-05 14:01
 */
@ApiModel(value = "ProductAndSortRequest", description = "产品分类信息和产品信息查询请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductAndSortRequest implements Serializable {

    @ApiModelProperty(value = "分类元数据代码:1大分类，2中分类，3小分类")
    private Integer metaCode;

    @ApiModelProperty(value = "分类id")
    private List<Integer> sortId;

    @ApiModelProperty(value = "模糊查询条件：产品名称或者商品/产品条码")
    private String prdName;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
