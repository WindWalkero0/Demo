package com.ruihe.admin.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDateTime;

@ApiModel(value = "EditBannerRequest", description = "编辑轮播图实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EditBannerRequest implements Serializable {
    @ApiModelProperty(value = "主键id")
    private Integer bannerId;
    @ApiModelProperty(value = "banner标题")
    @Size(max = 300,message = "banner标题最大长度为300个字符")
    private String title;
    @ApiModelProperty(value = "所属模块")
    private String bannerType;
    @Size(max = 300,message = "链接url最大长度为300个字符")
    @ApiModelProperty(value = "链接url")
    private String linkUrl;
    @ApiModelProperty(value = "图片地址")
    private String imgUrl;
    @ApiModelProperty(value = "banner描述/广告描述")
    private String description;
    @ApiModelProperty(value = "排序序号")
    @NotNull(message = "排序序号传参不能为空")
    @Min(value = 1,message = "排序序号最小值为1")
    private Integer sortNum;
    @NotNull(message = "状态传参不能为空")
    @ApiModelProperty(value = "状态：0有效,1无效")
    private Integer status;
    @ApiModelProperty(value = "修改时间")
    private LocalDateTime updateTime;
}
