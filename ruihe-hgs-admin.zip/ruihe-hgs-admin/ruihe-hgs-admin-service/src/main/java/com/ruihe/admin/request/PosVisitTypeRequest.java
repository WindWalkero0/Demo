package com.ruihe.admin.request;

import com.ruihe.common.annotation.Create;
import com.ruihe.common.annotation.Update;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * pos菜单配置表
 *
 * @author William
 */
@ApiModel(value = "PosVisitTypeRequest", description = "pos服务项目请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosVisitTypeRequest implements Serializable {
    /**
     * id
     **/
    @ApiModelProperty(value = "id")
    @NotNull(message = "id不能为空", groups = {Update.class})
    private Integer id;
    /**
     * 操作类型
     **/
    @ApiModelProperty(value = "操作类型")
    @NotBlank(message = "类型不能为空", groups = {Create.class})
    @Size(max=20,message = "任务名称最大长度为20个字符")
    private String operationType;
    /**
     * 排序
     **/
    @ApiModelProperty(value = "排序")
    @NotNull(message = "排序不能为空", groups = {Create.class})
    private Integer sort;
    /**
     * 有效状态 0无效  1有效
     **/
    @ApiModelProperty(value = "有效状态 0无效  1有效")
    @NotNull(message = "有效状态不能为空", groups = {Create.class})
    private Boolean status;
    /**
     * 是否可以修改数量 0不能 1可以
     **/
    @ApiModelProperty(value = "是否可以修改数量 0不能 1可以")
    @NotNull(message = "修改数量不能为空", groups = {Create.class})
    private Boolean updateStatus;
    
    @ApiModelProperty("顾客信息是否必填(0-否 1-是)")
    private Boolean required;
}
