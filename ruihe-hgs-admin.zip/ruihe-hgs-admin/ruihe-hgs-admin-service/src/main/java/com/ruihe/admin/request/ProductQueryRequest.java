package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-05 14:45
 */
@ApiModel(value = "ProductQueryRequest", description = "产品按条件查询请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductQueryRequest implements Serializable {

    @ApiModelProperty(value = "品牌名称")
    private String brandName;

    @ApiModelProperty(value = "产品条码")
    private String prdBarCode;

    @ApiModelProperty(value = "厂商编码")
    private String goodsBarCode;

    @ApiModelProperty(value = "产品名称")
    private String prdName;

    @ApiModelProperty(value = " 状态:0不启用，1启用")
    private Integer status;

    @ApiModelProperty(value = " 销售状态:1 可以销售，0下架")
    private Integer saleStatus;

    @ApiModelProperty(value = "可否用于积分兑换：0不可以，1可以")
    private Integer exchPermit;

    @ApiModelProperty(value = "大类代码")
    private List<Integer> bigCatCode;

    @ApiModelProperty(value = "中类代码")
    private List<Integer> mediumCatCode;

    @ApiModelProperty(value = "小类代码")
    private List<Integer> smallCatCode;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;

    @ApiModelProperty(name = "系列代码")
    private Integer seriesCode;

}
