package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author 梁远
 * @Description 临时权限列表请求实体
 * @date 2019-12-10 10:02
 */
@ApiModel(value = "PosAuthorityListRequest", description = "临时权限列表请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PosAuthorityListRequest implements Serializable {

    @ApiModelProperty(value = "查询类型：1进行中，2已过期，3未开始")
    private Integer bizType;

    @ApiModelProperty(value = "类型：KT--空退，BL--补录，IBC--手输条码，NI--负库存，FI--自由盘点")
    private String type;

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;

}
