package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 发货单查询
 * @author fly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class dispatchExcelEvent extends BiReportEvent {

    private String key;

    @Builder
    public dispatchExcelEvent(String key) {
        this.key = key;
    }
}
