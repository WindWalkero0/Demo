package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.Report4SalesPerfEvent;
import com.ruihe.admin.listener.report.core.ReportController;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.admin.listener.report.core.TotalQuery;
import com.ruihe.admin.mapper.bi.SaleReportNewMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.response.bi.BaSalesTimeReportPo;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.List;

/***
 * BI报表销售业绩分析
 * @author lrc
 */
@Component
@RequiredArgsConstructor
public class SalesPerfReportListener extends AbstractReportListener<Report4SalesPerfEvent> {

    private final SaleReportNewMapper saleReportNewMapper;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_REPORT)
    @EventListener
    public void onApplicationEvent(Report4SalesPerfEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    public void doExport(Report4SalesPerfEvent event, BiReportPo report, boolean flag) {
        TableDefine define = SalesPerfDefine.create(event.getRequest());
        ReportController controller = new ReportController(define);
        controller.name("销售业绩分析报表");
        controller.savePath(report.getFilePath());

        int dayOrMonth = 0;
        if (define.isDaily()) {
            dayOrMonth = 1;
        } else if (define.isMonthly()) {
            dayOrMonth = 2;
        }

        List<BaSalesTimeReportPo> base = saleReportNewMapper.queryBase(
                event.getRequest(),
                define.selectCols("o."),
                define.groupCols("o."),
                event.getReport().getUid(),
                dayOrMonth,
                flag);

        List<BaSalesTimeReportPo> salesDays = saleReportNewMapper.querySalesDays(
                event.getRequest(),
                define.selectCols("o."),
                define.groupCols("o."),
                define.selectCols("t."),
                define.groupCols("t."),
                event.getReport().getUid(),
                flag);

        //4、会员入会数量
        List<BaSalesTimeReportPo> mjData = saleReportNewMapper.queryMj(
                event.getRequest(),
                define.selectCols("c.")
                        .replace("c.biz_time", "m.card_issuing_time")
                        .replace("c.org_area_code", "c.org_area_id")
                        .replace("c.org_office_code", "c.org_office_id")
                        .replace("c.org_principal_code", "c.org_master_id")
                        .replace("c.org_principal_name", "c.org_master_name")
                        .replace("c.ba_code", "m.ba_id as ba_code")
                        .replace("c.ba_name", "m.ba_name"),
                define.groupCols("c.").replace("c.ba_code", "ba_code"),
                event.getReport().getUid(),
                flag);
        controller.fillData(mjData);

        //经营新会员数据
        List<BaSalesTimeReportPo> optNewMem = saleReportNewMapper.queryOptNewMem(
                event.getRequest(),
                dayOrMonth,
                define.selectCols("o."),
                define.groupCols("o."),
                event.getReport().getUid(),
                flag);

        //老客单
        List<BaSalesTimeReportPo> vet = saleReportNewMapper.queryVet(
                event.getRequest(),
                define.selectCols("o."),
                define.groupCols("o."),
                event.getReport().getUid(),
                dayOrMonth,
                flag);

        controller.fillData(base, salesDays, mjData, optNewMem, vet);
        controller.totalCalculate();

        //老客单
        controller.fillTotal(new TotalQuery() {
            @Override
            public List<?> doQuery(String select, String group, int dayOrMonth) {
                return saleReportNewMapper.queryVet(
                        event.getRequest(),
                        select,
                        group,
                        event.getReport().getUid(),
                        dayOrMonth,
                        flag);
            }

            @Override
            public String alias() {
                return "o.";
            }
        });

        //经营新会员小计总计数据
        controller.fillTotal(new TotalQuery() {
            @Override
            public List<?> doQuery(String select, String group, int dayOrMonth) {
                return saleReportNewMapper.queryOptNewMem(
                        event.getRequest(),
                        dayOrMonth,
                        select,
                        group,
                        event.getReport().getUid(),
                        flag);
            }

            @Override
            public String alias() {
                return "o.";
            }
        });

        controller.write(this.imgPath, report.getPicUrl());
    }
}
