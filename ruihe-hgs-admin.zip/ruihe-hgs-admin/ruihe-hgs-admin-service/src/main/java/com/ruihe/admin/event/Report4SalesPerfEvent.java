package com.ruihe.admin.event;


import com.ruihe.admin.request.bi.SalesPerfReportRequest;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 销售业绩分析报表
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class Report4SalesPerfEvent extends BiReportEvent {

    private SalesPerfReportRequest request;

    @Builder
    public Report4SalesPerfEvent(SalesPerfReportRequest request) {
        this.request = request;
    }
}
