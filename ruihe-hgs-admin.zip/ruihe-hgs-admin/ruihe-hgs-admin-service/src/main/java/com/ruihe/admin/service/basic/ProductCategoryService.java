package com.ruihe.admin.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.mapper.basic.ProductCategoryMapper;
import com.ruihe.admin.mapper.basic.ProductMapper;
import com.ruihe.admin.request.ProductAndSortRequest;
import com.ruihe.admin.request.ProductCategorySaveRequest;
import com.ruihe.admin.request.SelectSortRequest;
import com.ruihe.admin.response.ProductCategoryVo;
import com.ruihe.admin.vo.CommonPrdSortItemVo;
import com.ruihe.admin.vo.CommonPrdVo;
import com.ruihe.admin.vo.PrdAndSortVo;
import com.ruihe.admin.vo.ProductSortItemVo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.base.ProductCategory;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.response.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Slf4j
@Service
@RequiredArgsConstructor
public class ProductCategoryService {
    private final ProductMapper productMapper;
    private final ProductCategoryMapper categoryMapper;

    @DS(DBConst.SLAVE)
    @Transactional
    public Response children(Integer parentId) {
        List<ProductCategory> list = getChildren(parentId);
        return Response.success(list);
    }

    /**
     * 按条件搜索分类
     */
    @DS(DBConst.SLAVE)
    @Transactional
    public Response query(SelectSortRequest request) {
        var queryWrapper = Wrappers.lambdaUpdate(ProductCategory.class)
                .like(StringUtils.isNotBlank(request.getSortName()), ProductCategory::getName, request.getSortName())
                .in(ObjectUtils.isNotEmpty(request.getSortList()), ProductCategory::getParentId, request.getSortList())
                .eq(ProductCategory::getLevel, request.getType())
                .eq(ProductCategory::getDeleted, 0);
        // 分类产品绑定判断
        if (request.getIsPrdBinded() != null) {
            var products = productMapper.selectList(Wrappers.lambdaQuery(Product.class));
            var categoryList = products.stream().map(p -> {
                if (request.getType() == 1) return p.getBigCatCode();
                else if (request.getType() == 2) return p.getMediumCatCode();
                else return p.getSmallCatCode();
            }).collect(Collectors.toList());
            // 没有绑定过产品的分类
            queryWrapper.notIn(request.getIsPrdBinded() == 0, ProductCategory::getId, categoryList);
            // 已经绑定过产品的分类
            queryWrapper.in(request.getIsPrdBinded() == 1, ProductCategory::getId, categoryList);
        }

        Page<ProductCategory> page = new Page<>(request.getPageNumber(), request.getPageSize());
        categoryMapper.selectPage(page, queryWrapper);

        var list = page.getRecords().stream().map(e -> {
            var parent = categoryMapper.selectById(e.getParentId());
            return ProductSortItemVo.builder()
                    .isPrdBinded(request.getIsPrdBinded())
                    .metaCode(request.getType()) // 老的分类系统中该值其实是层级编号
                    .metaName(String.valueOf(request.getType())) //老的分类系统中该值其实层级名称，第一级大分类，目前用不到
                    .parentSortId(e.getParentId())
                    .parentSortName(parent == null ? "" : parent.getName())
                    .sortId(e.getId())
                    .sortCode(String.valueOf(e.getId()))
                    .sortName(e.getName())
                    .status(e.getDeleted() == 0 ? 1 : 0)
                    .build();
        }).collect(Collectors.toList());
        PageVO<ProductSortItemVo> info = PageVO.<ProductSortItemVo>builder().list(list)
                .total(page.getTotal())
                .pageNum(page.getCurrent())
                .pageSize(page.getSize())
                .pages(page.getPages()).build();
        return Response.success(info);
    }

    @DS(DBConst.SLAVE)
    public Response selectProductAndSort(ProductAndSortRequest request) {
        //获取编码id的list
        List<Integer> sortIdList = request.getSortId();
        //1、进入页面，除了分类、pagesize和number不为空，其它都是空
        if (org.springframework.util.ObjectUtils.isEmpty(sortIdList) && StringUtils.isBlank(request.getPrdName())) {
            //查询产品
            if (request.getPageSize() == null || request.getPageNumber() == null) {
                return Response.errorMsg("页数||页面不能为空!");
            }
            Page<Product> page = new Page<>(request.getPageNumber(), request.getPageSize());
            LambdaQueryWrapper<Product> queryProduct = Wrappers.<Product>lambdaQuery()
                    .eq(Product::getSaleStatus, 1);
            IPage<Product> productIPage = productMapper.selectPage(page, queryProduct);
            //获取查询数据
            var info = PageVO.<CommonPrdVo>builder().list(com.ruihe.common.utils.ObjectUtils.toList(productIPage.getRecords(), CommonPrdVo.class))
                    .total(productIPage.getTotal())
                    .pageNum(productIPage.getCurrent())
                    .pageSize(productIPage.getSize())
                    .pages(productIPage.getPages()).build();
            //查询产品分类
            List<ProductCategory> sortItemPoList = categoryMapper.selectList(Wrappers.<ProductCategory>lambdaQuery()
                    .eq(ProductCategory::getDeleted, 0)
                    .eq(ProductCategory::getLevel, request.getMetaCode()));
            List<CommonPrdSortItemVo> list = sortItemPoList.stream()
                    .map(item -> CommonPrdSortItemVo.builder()
                            .metaCode(item.getLevel())
                            .sortName(item.getName())
                            .sortId(item.getId())
                            .build()).collect(Collectors.toList());
            return Response.success(PrdAndSortVo.builder()
                    .pageVo(info)
                    .prdSortItemVoList(list)
                    .build());
        }
        //2、单独查询下级分类，此时pagesize和number为空即可
        else if (request.getPageNumber() == null && request.getPageSize() == null) {
            List<ProductCategory> sortItemPoList = categoryMapper.selectList(Wrappers.<ProductCategory>lambdaQuery()
                    .eq(ProductCategory::getDeleted, 0)
                    .in(ProductCategory::getParentId, sortIdList));
            List<CommonPrdSortItemVo> list = sortItemPoList.stream()
                    .map(item -> CommonPrdSortItemVo.builder()
                            .metaCode(item.getLevel())
                            .sortName(item.getName())
                            .sortId(item.getId())
                            .build()).collect(Collectors.toList());
            return Response.success(list);
        }
        //3、根据分类查询产品信息(包括模糊查询)，或者直接进行模糊查询
        else {
            if (request.getPageSize() == null || request.getPageNumber() == null) {
                return Response.errorMsg("页数||页面不能为空!");
            }
            Page<Product> page = new Page<>(request.getPageNumber(), request.getPageSize());
            LambdaQueryWrapper<Product> queryWrapper = Wrappers.<Product>lambdaQuery()
                    .eq(Product::getSaleStatus, 1);
            if (!org.springframework.util.ObjectUtils.isEmpty(sortIdList)) {
                queryWrapper.and(p -> p.in(Product::getBigCatCode, sortIdList)
                        .or().in(Product::getMediumCatCode, sortIdList)
                        .or().in(Product::getSmallCatCode, sortIdList));
            }
            if (StringUtils.isNotBlank(request.getPrdName())) {
                queryWrapper.and(p -> p.like(Product::getPrdBarCode, request.getPrdName())
                        .or().like(Product::getGoodsBarCode, request.getPrdName())
                        .or().like(Product::getPrdName, request.getPrdName()));
            }
            IPage<Product> productIPage = productMapper.selectPage(page, queryWrapper);
            //获取查询数据
            var info = PageVO.<CommonPrdVo>builder().list(com.ruihe.common.utils.ObjectUtils.toList(productIPage.getRecords(), CommonPrdVo.class))
                    .total(productIPage.getTotal())
                    .pageNum(productIPage.getCurrent())
                    .pageSize(productIPage.getSize())
                    .pages(productIPage.getPages()).build();
            return Response.success(info);
        }
    }

    @DS(DBConst.SLAVE)
    public Response categoryTree(Boolean deleted) throws BizException {
        var queryWrapper = Wrappers.lambdaQuery(ProductCategory.class)
                .orderByAsc(ProductCategory::getLevel)
                .orderByAsc(ProductCategory::getSort);
         if(deleted != null ){
             queryWrapper.eq(ProductCategory::getDeleted, deleted);
         }
        var all = categoryMapper.selectList(queryWrapper);
        ProductCategoryVo root = new ProductCategoryVo();
        root.setId(0);
        root.setLevel(0);
        root.setName("");
        root.setSort(0);
        root.setDeleted(0);
        root.setParentId(null);
        for (ProductCategory c : all) {
            addChild(c, root);
        }
        return Response.success(root);
    }

    private void addChild(ProductCategory category, ProductCategoryVo node) {
        var children = node.getChildren();
        if (children == null) {
            children = new ArrayList<>();
            node.setChildren(children);
        }

        if (category.getLevel() - 1 == node.getLevel()
                && category.getParentId().equals(node.getId())) {
            ProductCategoryVo vo = new ProductCategoryVo();
            vo.setId(category.getId());
            vo.setLevel(category.getLevel());
            vo.setName(category.getName());
            vo.setDeleted(category.getDeleted());
            vo.setSort(category.getSort());
            vo.setParentId(category.getParentId());
            children.add(vo);
        } else if (category.getLevel() - 1 != node.getLevel()) {
            for (var n : children) {
                addChild(category, n);
            }
        }
    }

    /**
     * 添加/修改产品分类
     */
    @DS(DBConst.MASTER)
    @Transactional
    public Response save(ProductCategorySaveRequest request) throws BizException {
//        if (checkNameExists(request)) {
//            return Response.errorMsg("分类已存在");
//        }
        ProductCategory category = null;
        if (request.getId() != null && request.getId() > 0) {
            category = categoryMapper.selectById(request.getId());
        }
        //修改
        if (category != null) {
            category.setName(request.getName());
            //为了兼容
            if(request.getDeleted() == null){
                request.setDeleted(category.getDeleted());
            }
            if(request.getDeleted() == 1){
                //如果要编辑为无效，则需判断分类下是否还有产品
                var list = productMapper.selectList(Wrappers.lambdaQuery(Product.class)
                        .or().eq(Product::getBigCatCode, request.getId())
                        .or().eq(Product::getMediumCatCode, request.getId())
                        .or().eq(Product::getSmallCatCode, request.getId())
                );
                if (!list.isEmpty()) {
                    return Response.errorMsg("该分类下还存在关联的产品，无法设置为无效");
                }
            }
            category.setDeleted(request.getDeleted());
            categoryMapper.updateById(category);
            // 修改关联产品的分类名称
            productMapper.updateCategoryName(category);
        }
        // 新增
        else {
            int level = 1;
            if (request.getParentId() != 0) {
                ProductCategory parent = categoryMapper.selectById(request.getParentId());
                if (parent == null || parent.getDeleted() == 1)
                    return Response.errorMsg("上级分类不存在");
                level = parent.getLevel() + 1;
            }
            var count = categoryMapper.selectCount(Wrappers
                    .lambdaQuery(ProductCategory.class)
                    .eq(ProductCategory::getParentId, request.getParentId()));
            category = ProductCategory.builder()
                    .sort(count)
                    .name(request.getName())
                    .parentId(request.getParentId())
                    .level(level)
                    .deleted(0)
                    .updateTime(LocalDateTime.now())
                    .createTime(LocalDateTime.now())
                    .build();
            if (request.getId() != null && request.getId() > 0) {
                category.setId(request.getId());
            } else {
                category.setId(categoryMapper.nextId());
            }
            categoryMapper.insert(category);
        }
        return Response.success(category);
    }

    private boolean checkNameExists(ProductCategorySaveRequest req) {
        if (req.getId() != null && req.getId() > 0) {
            return categoryMapper.selectCount(Wrappers.lambdaQuery(ProductCategory.class)
                    .eq(ProductCategory::getName, req.getName())
                    .eq(ProductCategory::getParentId, req.getParentId())
                    .ne(ProductCategory::getId, req.getId())) > 0;
        } else {
            return categoryMapper.selectCount(Wrappers.lambdaQuery(ProductCategory.class)
                    .eq(ProductCategory::getParentId, req.getParentId())
                    .eq(ProductCategory::getName, req.getName())) > 0;
        }
    }

    @DS(DBConst.MASTER)
    @Transactional
    public Response exchange(Integer sourceId, Integer targetId) throws BizException {
        int sourceIndex = -1;
        int targetIndex = -1;
        List<ProductCategory> neighbors = getNeighbors(sourceId);
        for (int i = 0; i < neighbors.size(); i++) {
            ProductCategory item = neighbors.get(i);
            if (item.getId().equals(sourceId)) sourceIndex = i;
            if (item.getId().equals(targetId)) targetIndex = i;
        }
        if (sourceIndex == -1 || targetIndex == -1) {
            return Response.errorMsg("分类不存在");
        }

        ProductCategory source = neighbors.remove(sourceIndex);
        neighbors.add(targetIndex, source);
        for (int i = 0; i < neighbors.size(); i++) {
            ProductCategory item = neighbors.get(i);
            item.setSort(i);
            categoryMapper.updateById(item);
        }

        return Response.success();
    }

    private List<ProductCategory> getNeighbors(Integer categoryId) {
        ProductCategory category = categoryMapper.selectById(categoryId);
        if (category == null) throw new BizException("分类不存在 " + categoryId);
        return categoryMapper.selectList(Wrappers.lambdaQuery(ProductCategory.class)
                .eq(ProductCategory::getParentId, category.getParentId())
                .eq(ProductCategory::getDeleted, 0)
                .orderByAsc(ProductCategory::getSort)
        );
    }

    private List<ProductCategory> getChildren(Integer parentId) {
        return categoryMapper.selectList(Wrappers.lambdaQuery(ProductCategory.class)
                .eq(ProductCategory::getParentId, parentId)
                .eq(ProductCategory::getDeleted, 0)
                .orderByAsc(ProductCategory::getSort)
        );
    }

    @DS(DBConst.MASTER)
    @Transactional
    public Response delete(Integer id) throws BizException {
        var list = productMapper.selectList(Wrappers.lambdaQuery(Product.class)
                .or().eq(Product::getBigCatCode, id)
                .or().eq(Product::getMediumCatCode, id)
                .or().eq(Product::getSmallCatCode, id)
        );
        if (!list.isEmpty()) {
            String msg = "该分类下面有还有" + list.size() + "件商品，请先将商品移动到其他分类后再删除分类";
            return Response.errorMsg(msg);
        }

        var category = categoryMapper.selectById(id);
        if (category.getLevel() < 3) {
            if (!getChildren(category.getId()).isEmpty()) {
                return Response.errorMsg("改分类下还有子分类，不能删除");
            }
        }

        category.setDeleted(1);
        categoryMapper.updateById(category);
        return Response.success();
    }
}
