package com.ruihe.admin.event;

import lombok.Data;


@Data
public class MemberInfoChangeEvent {

    private String memberId;


    public MemberInfoChangeEvent(String memberId) {
        this.memberId = memberId;
    }

}
