package com.ruihe.admin.service.communicate;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.admin.mapper.communicate.MsgMapper;
import com.ruihe.admin.mapper.communicate.RecordMapper;
import com.ruihe.admin.po.MsgTemplatePo;
import com.ruihe.admin.po.MsgRecordPo;
import com.ruihe.admin.vo.MsgRecordVo;
import com.ruihe.admin.vo.MsgTemplateVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 沟通管理
 *
 * @author:Fangtao
 * @Date:2019/11/15 19:43
 */
@Service
@Slf4j
public class CommunicateService {
    @Autowired
    private MsgMapper msgMapper;

    @Autowired
    private RecordMapper recordMapper;

    /**
     * 模板管理查询
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectTemplate() {
        List<MsgTemplatePo> msgTemplatePos = msgMapper.queryTemplate();
        return Response.success(ObjectUtils.toList(msgTemplatePos, MsgTemplateVo.class));
    }

    /**
     * 查询发送记录
     * @param contact
     * @param status
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectSendRecord(String contact, Integer status,Integer pageSize,Integer pageNumber) {
        PageHelper.startPage(pageNumber,pageSize);
        List<MsgRecordPo> msgRecordPos = recordMapper.queryRecord(contact, status);
        PageInfo<MsgRecordPo> info = new PageInfo<>(ObjectUtils.toList(msgRecordPos, MsgRecordVo.class));
        info.setTotal(recordMapper.queryTotal(contact,status));
        return Response.success(info);
    }
}
