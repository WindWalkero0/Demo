package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-11 15:36
 */
@ApiModel(value = "MemberLevelUpRequest", description = "会员升级新增/编辑请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberLevelUpRequest implements Serializable {

    @ApiModelProperty(value = "子表主键ID,新增的时候不要传")
    private Integer upId;

    @ApiModelProperty(value = "规则主表主键ID")
    private String ruleId;

    @ApiModelProperty(value = "升级后等级编码")
    private String afterLevelCode;

    @ApiModelProperty(value = "升级后等级名称")
    private String afterLevelName;

    @ApiModelProperty(value = "升级后会员等级级别")
    private Integer afterLevel;

    @ApiModelProperty(value = "规则描述")
    private String description;

    @ApiModelProperty(value = "单次购买：0否，1是")
    private Integer single;

    @ApiModelProperty(value = "消费金额大于")
    private BigDecimal fromAmt;

    @ApiModelProperty(value = "消费金额低于")
    private BigDecimal toAmt;

    @ApiModelProperty(value = "累积购买：0否，1是")
    private Integer acc;

    @ApiModelProperty(value = "连续n月内，此处不为空，则说明选择的是累计开始时间，否则默认为选择会员有效期内")
    private Integer duration;

    @ApiModelProperty(value = "累计金额达到或超过")
    private BigDecimal accFromAmt;

    @ApiModelProperty(value = "累计金额低于")
    private BigDecimal accToAmt;

    @ApiModelProperty(value = "是否包含首单：0不包含，1包含")
    private Integer includeFirst;
}
