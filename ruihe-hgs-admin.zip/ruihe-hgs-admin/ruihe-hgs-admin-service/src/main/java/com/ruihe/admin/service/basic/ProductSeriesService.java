package com.ruihe.admin.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruihe.admin.mapper.basic.ProductSeriesMapper;
import com.ruihe.admin.request.ProductSeriesSaveRequest;
import com.ruihe.admin.request.ProductSeriesSortRequest;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.ProductSeries;
import com.ruihe.common.dao.bean.member.MemberLevelLog;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.PageForm;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.response.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


@Slf4j
@Service
@RequiredArgsConstructor
public class ProductSeriesService extends ServiceImpl<ProductSeriesMapper, ProductSeries> {
    private final ProductSeriesMapper seriesMapper;

    /**
     * 按条件搜索分类
     */
    @DS(DBConst.SLAVE)
    @Transactional
    public Response query(PageForm pageForm) {
        Page<ProductSeries> page = new Page<>(pageForm.getPageNumber(), pageForm.getPageSize());
        seriesMapper.selectPage(page, Wrappers.lambdaQuery(ProductSeries.class)
                .eq(ProductSeries::getDeleted, 0)
                .orderByAsc(ProductSeries::getSort).orderByAsc(ProductSeries::getId));
        PageVO<ProductSeries> info = PageVO.<ProductSeries>builder().list(page.getRecords())
                .total(page.getTotal())
                .pageNum(page.getCurrent())
                .pageSize(page.getSize())
                .pages(page.getPages()).build();
        return Response.success(info);
    }

    /**
     * 按条件搜索分类
     */
    @DS(DBConst.SLAVE)
    public Response selectList() {
        return Response.success(seriesMapper.selectList(Wrappers.<ProductSeries>lambdaQuery()
                .eq(ProductSeries::getDeleted, 0).orderByAsc(ProductSeries::getSort).orderByAsc(ProductSeries::getId)));

    }

    /**
     * 添加/修改产品分类
     */
    @DS(DBConst.MASTER)
    @Transactional
    public Response save(ProductSeriesSaveRequest request) throws BizException {
        ProductSeries series;
        if (checkNameExists(request)) {
            return Response.errorMsg("系列已经存在");
        }
        // 修改
        if (request.getId() != null && request.getId() > 0) {
            series = seriesMapper.selectById(request.getId());
            series.setName(request.getName());
            series.setFlag(request.getFlag());
            series.setUpdateTime(LocalDateTime.now());
            seriesMapper.updateById(series);
        } else {  // 新增
            series = ProductSeries.builder()
                    .name(request.getName())
                    .deleted(0)
                    .flag(request.getFlag())
                    .updateTime(LocalDateTime.now())
                    .createTime(LocalDateTime.now())
                    .build();
            seriesMapper.insert(series);
            setAddSort();
        }
        return Response.success(series);
    }

    private boolean checkNameExists(ProductSeriesSaveRequest req) {
        if (req.getId() != null && req.getId() > 0) {
            return seriesMapper.selectCount(Wrappers.lambdaQuery(ProductSeries.class)
                    .eq(ProductSeries::getName, req.getName())
                    .ne(ProductSeries::getId, req.getId())) > 0;
        } else {
            return seriesMapper.selectCount(Wrappers.lambdaQuery(ProductSeries.class)
                    .eq(ProductSeries::getName, req.getName())) > 0;
        }
    }

    @DS(DBConst.MASTER)
    @Transactional
    public Response delete(Integer id) throws BizException {
        var series = seriesMapper.selectById(id);
        series.setDeleted(1);
        seriesMapper.updateById(series);
        return Response.success();
    }

    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response updateSort(ProductSeriesSortRequest request) throws BizException {
        ProductSeries productSeries = baseMapper.selectById(request.getId());
        if (productSeries == null) {
            return Response.errorMsg("该系列不存在");
        }
        productSeries.setSort(request.getSort());
        productSeries.setUpdateTime(LocalDateTime.now());
        baseMapper.updateById(productSeries);
        setUpdateSort(request.getSort().compareTo(request.getOldSort()) > 0);
        return Response.success();
    }

    /**
     * 更新 新增 排序值
     */
    void setAddSort() {
        List<ProductSeries> list = baseMapper.selectList(new QueryWrapper<ProductSeries>().lambda()
                .eq(ProductSeries::getDeleted, 0)
                .orderByAsc(ProductSeries::getSort).orderByAsc(ProductSeries::getUpdateTime));
        List<ProductSeries> newList = list.stream().filter(u -> u.getSort() != 0).collect(Collectors.toList());
        List<ProductSeries> zeroList = list.stream().filter(u -> u.getSort() == 0).collect(Collectors.toList());
        zeroList.sort(Comparator.comparingInt(ProductSeries::getId));
        newList.addAll(zeroList);
        for (int i = 0; i < newList.size(); i++) {
            newList.get(i).setSort(i + 1);
        }
        updateBatchById(newList);
    }

    /**
     * 更新 修改 排序值
     */
    void setUpdateSort(boolean isDown) {
        LambdaQueryWrapper<ProductSeries> query;
        if (isDown) {
            query = Wrappers.lambdaQuery(ProductSeries.class)
                    .eq(ProductSeries::getDeleted, 0)
                    .orderByAsc(ProductSeries::getSort)
                    .orderByAsc(ProductSeries::getUpdateTime);
        } else {
            query = Wrappers.lambdaQuery(ProductSeries.class)
                    .eq(ProductSeries::getDeleted, 0)
                    .orderByAsc(ProductSeries::getSort)
                    .orderByDesc(ProductSeries::getUpdateTime);
        }
        List<ProductSeries> list = baseMapper.selectList(query);
        for (int i = 0; i < list.size(); i++) {
            list.get(i).setSort(i + 1);
        }
        updateBatchById(list);
    }
}
