package com.ruihe.admin.listener;


import com.ruihe.common.annotation.Ella;
import com.ruihe.common.service.AdminTaskService;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.CheckPhoneEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;


@Ella(Describe = "校验订单积分用户信息中手机号一致", Author = "fly")
@Slf4j
@Component
public class CheckPhoneListener {

    @Autowired
    private AdminTaskService adminTaskService;

    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(CheckPhoneEvent event) {
        try {
            adminTaskService.checkPhone();
        } catch (Exception e) {
            log.error("校验订单积分用户信息中手机号一致.error,event={}", event, e);
        }
    }

}
