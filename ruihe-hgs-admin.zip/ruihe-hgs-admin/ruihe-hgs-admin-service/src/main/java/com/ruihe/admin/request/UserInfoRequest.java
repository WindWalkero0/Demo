package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-30 15:22
 */
@ApiModel(value = "UserInfoRequest", description = "用户管理请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class UserInfoRequest implements Serializable {

    @ApiModelProperty(value = "用户ID--必填")
    private String empId;

    @ApiModelProperty(value = "所属品牌")
    private String brandName;

    @ApiModelProperty(value = "姓名--必填")
    @Size(max = 20,message = "姓名最大长度为20个字符")
    private String name;

    @ApiModelProperty(value = "岗位代码--必填")
    private String positionCode;

    @ApiModelProperty(value = "岗位名称--必填")
    private String positionName;

    @ApiModelProperty(value = "联系电话--必填")
    @Size(max = 15,message = "手机号码最大长度为15个字符")
    private String telephone;

    @ApiModelProperty(value = "部门代码--必填")
    private String deptCode;

    @ApiModelProperty(value = "部门名称--必填")
    private String deptName;

    @ApiModelProperty(value = "部门类型--必填")
    private Integer deptType;

    @ApiModelProperty(value = "手机号码--必填")
    @Size(max = 12,message = "手机号码最大长度为12个字符")
    private String phoneNo;

    @ApiModelProperty(value = "email--必填")
    @Size(max = 50,message = "email最大长度为50个字符")
    private String email;

    @ApiModelProperty(value = "身份证--必填")
    @Size(max = 18,message = "姓名最大长度为18个字符")
    private String idCard;

    @ApiModelProperty(value = "状态:0无效，1有效")
    private Integer status;

    @ApiModelProperty(value = "最近一次入职日期")
    private LocalDate recentEntryTime;

    @ApiModelProperty(value = "最近一次离职日期")
    private LocalDate recentLeaveTime;

    @ApiModelProperty(value = "管辖部门")
    private List<UserDepartmentRequest> departmentList;

    @ApiModelProperty(value = "工作柜台，新增的时候不填")
    private List<UserCounterRequest> counterList;

    @ApiModelProperty(value = "登录帐号")
    private UserAccountRequest userAccountRequest;

    @ApiModelProperty(value = "关注部门")
    private List<UserConcernRequest> userConcernList;

}
