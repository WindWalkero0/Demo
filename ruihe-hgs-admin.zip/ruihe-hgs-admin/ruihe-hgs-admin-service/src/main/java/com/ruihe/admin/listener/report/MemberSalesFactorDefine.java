package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.report.core.CalculateFunc;
import com.ruihe.admin.listener.report.core.Column;
import com.ruihe.admin.listener.report.core.ColumnDefine;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.admin.request.bi.MemberSalesFactorReportRequest;
import com.ruihe.admin.request.bi.MemberSalesFactorSelectRequest;

import java.math.BigDecimal;

/**
 * 会员销售要素统计报表
 */
public class MemberSalesFactorDefine extends TableDefine {
    static Column saleDays = new Column("销售天数", "saleDays", Integer.class);
    static Column salesAmt = new Column("销售总金额", "salesAmt", BigDecimal.class);
    static Column salesOrderQty = new Column("销售总单数", "salesOrderQty", Integer.class);
    static Column salesGoodsQty = new Column("销售总支数", "salesGoodsQty", Integer.class);
    static Column memPur = new Column("会员购买人数", "memPur", Integer.class);
    static Column memAmt = new Column("会员购买金额", "memAmt", BigDecimal.class);
    static Column memOrder = new Column("会员购买单数", "memOrder", Integer.class);
    static Column mj = new Column("会员入会数量", "mj", Integer.class);
    static Column newPur = new Column("新会员购买人数", "newPur", Integer.class);
    static Column newAmt = new Column("新会员购买金额", "newAmt", BigDecimal.class);
    static Column newOrder = new Column("新会员购买单数", "newOrder", Integer.class);
    static Column vetPur = new Column("老会员购买人数", "vetPur", Integer.class);
    static Column vetAmt = new Column("老会员购买金额", "vetAmt", BigDecimal.class);
    static Column vetOrder = new Column("老会员购买单数", "vetOrder", Integer.class);
    static Column optNew = new Column("经营新会员人数", "optNew", Integer.class);
    static Column optNewAmt = new Column("经营新会员购买金额", "optNewAmt", BigDecimal.class);
    static Column optNewOrder = new Column("经营新会员购买单数", "optNewOrder", Integer.class);
    static Column nonMemOrder = new Column("非会员购买人数", "nonMemOrder", Integer.class);

    static Column newPct = new Column(
            "新客单\n（新会员购买金额/新会员购买单数）",
            "newPct",
            BigDecimal.class
    ).dep(newAmt, newOrder).calculateFunc(CalculateFunc.DIV);

    static Column vetPct = new Column(
            "老客单\n（老会员购买金额/老会员购买单数）",
            "vetPct",
            BigDecimal.class
    ).dep(vetAmt, vetOrder).calculateFunc(CalculateFunc.DIV);

    static Column optNewPct = new Column(
            "经营新客单\n（经营新会员购买金额/经营新会员购买单数）",
            "optNewPct",
            BigDecimal.class
    ).dep(optNewAmt, optNewOrder).calculateFunc(CalculateFunc.DIV);

    static Column pct = new Column(
            "平均客单价\n(销售总金额/销售总单数)",
            "pct",
            BigDecimal.class
    ).dep(salesAmt, salesOrderQty).calculateFunc(CalculateFunc.DIV);

    static Column newAmtPp = new Column(
            "新会员购买金额占比\n(新会员购买金额/会员购买金额)",
            "newAmtPp",
            BigDecimal.class
    ).dep(newAmt, memAmt).calculateFunc(CalculateFunc.DIV);

    static Column vetAmtPp = new Column(
            "老会员购买金额占比\n(老会员购买金额/会员购买金额)",
            "vetAmtPp",
            BigDecimal.class
    ).dep(vetAmt, memAmt).calculateFunc(CalculateFunc.DIV);

    static Column newRepurRate = new Column(
            "新会员重复购买率\n(新会员购买单数/会员入会数量)",
            "newRepurRate",
            BigDecimal.class
    ).dep(newOrder, mj).calculateFunc(CalculateFunc.DIV);

    static Column vetRepurRate = new Column(
            "老会员重复购买率\n(老会员购买单数/老会员购买人数)",
            "vetRepurRate",
            BigDecimal.class
    ).dep(vetOrder, vetPur).calculateFunc(CalculateFunc.DIV);

    static Column optNewRepurRate = new Column(
            "经营新会员重复购买率",
            "optNewRepurRate",
            BigDecimal.class
    ).dep(optNewOrder, optNew).calculateFunc(CalculateFunc.DIV);

    static Column jr = new Column(
            "连带率\n(销售总支数/销售总单数)",
            "jr",
            BigDecimal.class
    ).dep(salesGoodsQty, salesOrderQty).calculateFunc(CalculateFunc.DIV);

    public static MemberSalesFactorDefine create(MemberSalesFactorReportRequest request) {
        MemberSalesFactorSelectRequest selectRequest = request.getSelectRequest();
        MemberSalesFactorDefine define = new MemberSalesFactorDefine();
        define.addHorizontalColumns(selectRequest);
        define.addValueColumns(selectRequest);
        define.setStartTime(request.getStartTime());
        define.setEndTime(request.getEndTime());
        define.setTotalFlag(TableDefine.TOTAL_ROW);
        return define;
    }

    /**
     * 添加查询字段，不包括统计数值字段
     */
    private void addHorizontalColumns(MemberSalesFactorSelectRequest req) {
        this.addHorizontalColumn(ColumnDefine.areaCode, req.isArea());
        this.addHorizontalColumn(ColumnDefine.areaName, req.isArea());
        this.addHorizontalColumn(ColumnDefine.officeCode, req.isOffice());
        this.addHorizontalColumn(ColumnDefine.officeName, req.isOffice());
        this.addHorizontalColumn(ColumnDefine.principalCode, req.isPrincipal());
        this.addHorizontalColumn(ColumnDefine.principalName, req.isPrincipal());
        this.addHorizontalColumn(ColumnDefine.counterId, req.isCounterId());
        this.addHorizontalColumn(ColumnDefine.counterName, req.isCounterName());
        this.addHorizontalColumn(ColumnDefine.baCode.show(req.isBaCode()), req.isBaCode() || req.isBaName());
        this.addHorizontalColumn(ColumnDefine.baName, req.isBaName());
    }

    /**
     * 添加统计数值字段
     */
    private void addValueColumns(MemberSalesFactorSelectRequest req) {
        this.addValueColumn(saleDays, req.isSalesDays());
        this.addValueColumn(salesOrderQty.show(req.isSalesOrderQty()), req.isSalesOrderQty() || req.isPct() || req.isJr());
        this.addValueColumn(salesGoodsQty.show(req.isSalesGoodsQty()), req.isSalesGoodsQty() || req.isJr());
        this.addValueColumn(salesAmt.show(req.isSalesAmt()), req.isSalesAmt() || req.isPct());
        this.addValueColumn(memPur, req.isMemPur());
        this.addValueColumn(nonMemOrder, req.isNonMemOrder());
        this.addValueColumn(memOrder, req.isMemOrder());
        this.addValueColumn(memAmt.show(req.isMemAmt()), req.isMemAmt() || req.isNewAmtPp() || req.isVetAmtPp());
        this.addValueColumn(mj.show(req.isMj()), req.isMj() || req.isNewRepurRate());
        this.addValueColumn(newPur, req.isNewPur());
        this.addValueColumn(newOrder.show(req.isNewOrder()), req.isNewOrder() || req.isNewPct() || req.isNewPur() || req.isNewRepurRate());
        this.addValueColumn(newAmt.show(req.isNewAmt()), req.isNewAmt() || req.isNewPct() || req.isNewPur() || req.isNewAmtPp());
        this.addValueColumn(optNew.show(req.isOptNew()), req.isOptNew() || req.isOptNewRepurRate());
        this.addValueColumn(optNewOrder.show(req.isOptNewOrder()), req.isOptNewOrder() || req.isOptNewRepurRate() || req.isOptNewPct());
        this.addValueColumn(optNewAmt.show(req.isOptNewAmt()), req.isOptNewAmt() || req.isOptNewPct());
        this.addValueColumn(optNewPct, req.isOptNewPct());
        this.addValueColumn(vetPur.show(req.isVetPur()), req.isVetPur() || req.isVetRepurRate());
        this.addValueColumn(vetOrder.show(req.isVetOrder()), req.isVetOrder() || req.isVetPct() || req.isVetRepurRate());
        this.addValueColumn(vetAmt.show(req.isVetAmt()), req.isVetAmt() || req.isVetAmtPp() || req.isVetPct());
        this.addValueColumn(newPct, req.isNewPct());
        this.addValueColumn(vetPct, req.isVetPct());
        this.addValueColumn(pct, req.isPct());
        this.addValueColumn(newAmtPp, req.isNewAmtPp());
        this.addValueColumn(vetAmtPp, req.isVetAmtPp());
        this.addValueColumn(jr, req.isJr());
        this.addValueColumn(newRepurRate, req.isNewRepurRate());
        this.addValueColumn(vetRepurRate, req.isVetRepurRate());
        this.addValueColumn(optNewRepurRate, req.isOptNewRepurRate());
    }
}
