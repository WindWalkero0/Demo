package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 会员销售信息excel导出
 *
 * @author ly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class MemberSalesExcelEvent extends BiReportEvent {

    private String key;

    @Builder
    public MemberSalesExcelEvent(String key) {
        this.key = key;
    }
}
