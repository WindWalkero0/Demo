package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * 会员微信换卡请求实体
 *
 * @author LiangYuan
 * @date 2021-01-26 9:31
 */
@ApiModel(value = "ChangePhoneRequest", description = "会员微信换卡请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ChangePhoneRequest implements Serializable {

    @NotBlank(message = "已激活的手机号不能为空")
    @ApiModelProperty(value = "已激活的手机号")
    @Size(max=100,message = "已激活的手机号最大长度为100字符")
    private String beforePhone;

    @NotBlank(message = "新手机号不能为空")
    @ApiModelProperty(value = "新手机号")
    @Size(max=100,message = "新手机号最大长度为100字符")
    private String afterPhone;

    @NotBlank(message = "备注不能为空")
    @ApiModelProperty(value = "备注")
    @Size(max=100,message = "备注最大长度为100字符")
    private String remark;
}