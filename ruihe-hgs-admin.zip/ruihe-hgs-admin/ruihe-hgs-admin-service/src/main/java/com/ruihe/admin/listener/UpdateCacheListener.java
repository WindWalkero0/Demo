package com.ruihe.admin.listener;


import com.ruihe.common.annotation.Ella;
import com.ruihe.common.service.AsynchronousService;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.UpdateCacheEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;


@Ella(Describe = "更新缓存中的会员信息", Author = "K")
@Slf4j
@Component
public class UpdateCacheListener {

    @Autowired
    private AsynchronousService asynchronousService;

    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(UpdateCacheEvent event) {
        try {
            asynchronousService.updateCacheMember();
        } catch (Exception e) {
            log.error("更新缓存会员信息.error", e);
        }
    }

}
