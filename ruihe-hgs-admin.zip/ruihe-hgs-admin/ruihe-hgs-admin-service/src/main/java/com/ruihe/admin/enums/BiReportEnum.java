package com.ruihe.admin.enums;

/**
 * bi报表名称
 *
 * @author ly
 */
public enum BiReportEnum {

    GENERIC(0, "通用报表"),

    /**
     * 1，会员购买跟踪报表
     **/
    MEMBER_PURCHASE(1, "2-D-04.会员购买跟踪报表"),

    /**
     * 2，产品进销存报表查询报表
     **/
    PRODUCT_ERP(2, "3-01.产品柜台进销存报表"),

    /**
     * 3，柜台进销存报表查询报表
     **/
    COUNTER_ERP(3, "3-08.柜台进销存报表"),

    /**
     * 4.销售业绩分析查询报表
     */
    SALES_ERP(4, "1-A-01.销售业绩分析报表"),

    /**
     * 4.5.销售业绩分析查询报表
     */
    VISIT_ERP(402, "1-A-02.服务记录导出"),

    /**
     * 5.产品业务明细报表
     */
    PRD_DETAIL_ERP(5, "1-B-03产品业务明细报表"),

    /**
     * 6.会员销售要素统计报表
     */
    PRD_MEMBER_SALES(6, "2-C-03会员销售要素统计报表"),

    /**
     * 7，会员信息导出表
     **/
    MEMBER_INFO(7, "会员信息导出表"),

    /**
     * 8，会员销售记录
     **/
    MEMBER_SALES(8, "会员销售记录"),

    /**
     * 9，盘点申请明细
     **/
    INVENTORY_APPLY(9, "盘点申请明细"),

    /**
     * 10，盘点单主表
     **/
    INVENTORY_MASTER(10, "盘点单主表"),

    /**
     * 11，盘点单明细
     **/
    INVENTORY_ITEM(11, "盘点单明细"),

    /**
     * 12，调拨单主表
     **/
    TRANSFER_MASTER(12, "调拨单主表"),

    /**
     * 13，调拨单明细
     **/
    TRANSFER_ITEM(13, "调拨单明细"),

    /**
     * 14，支付方式报表
     **/
    PAYMENT(14, "支付方式报表"),

    /**
     * 15，产品销售记录查询
     **/
    PRD_SALES(15, "产品销售记录查询报表"),

    /**
     * 16，预订单查询
     **/
    LADING_ORDER(16, "预订单查询Excel"),

    /**
     * 17，退库申请单
     **/
    WH_RETURN_APPLY(17, "退库申请单"),

    /**
     * 18，退库单主表
     **/
    WH_RETURN_APPLY_ITEM(18, "退库申请单明细"),

    /**
     * 19，退库单明细
     **/
    WH_RETURN_DETAIL(19, "退库单明细"),

    /**
     * 20，发货单
     **/
    WH_ENTER(20, "发货单"),

    /**
     * 21，发货单明细
     **/
    WH_ENTER_DETAIL(21, "发货单明细"),

    /**
     * 21，柜台
     **/
    COUNTER_INFO(22, "柜台明细"),

    /**
     * 22 会员购买详情
     */
    MEMBER_Buy_Detail(23, "会员购买详情"),

    /**
     * 24 实时库存
     */
    REALTIME_STOCK_LIST(24, "实时库存"),

    /**
     * 25 实时库存明细
     */
    REALTIME_STOCK_LIST_DETAIL(25, "实时库存明细")
    ;


    private Integer code;
    private String msg;


    BiReportEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
