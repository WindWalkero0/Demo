package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description 根据条件搜索部门信息
 * @author 梁远
 * @create 2019-07-09 9:47
 */
@ApiModel(value = "DepartmentQueryRequest", description = "部门管理查询请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class DepartmentQueryRequest implements Serializable {

    @ApiModelProperty(value = "状态")
    private Integer status;

    @ApiModelProperty(value = "部门代码")
    private String deptId;

    @ApiModelProperty(value = "部门类型")
    private Integer deptType;

    @ApiModelProperty(value = "部门名称")
    private String deptName;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
