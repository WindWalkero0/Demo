package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-12 14:47
 */
@ApiModel(value = "MemberRuleRequest", description = "会员入会新增/编辑实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberRuleRequest implements Serializable {

    @ApiModelProperty(value = "规则id，新增的时候不需要填写")
    private Integer ruleId;

    @ApiModelProperty(value = "规则名称")
    @NotBlank(message = "规则名称不能为空")
    @Size(max= 30, message = "规则名称最大长度为30个字符")
    private String ruleName;

    @ApiModelProperty(value = "会员等级代码")
    private String levelCode;

    @ApiModelProperty(value = "会员等级名称")
    private String levelName;

    @ApiModelProperty(value = "会员等级级别")
    private Integer level;

    @ApiModelProperty(value = "开始时间")
    private LocalDate startTime;

    @ApiModelProperty(value = "结束时间，空的时候传'9999-12-31 00:00:00.000'")
    private LocalDate endTime;

    @ApiModelProperty(value = "有效期,x月/0永久有效")
    private Integer duration;

    @ApiModelProperty(value = "消费金额范围起")
    private BigDecimal fromAmt;

    @ApiModelProperty(value = "消费金额范围止，无上限的时候传入999999")
    private BigDecimal toAmt;

    @ApiModelProperty(value = "创建uid")
    private String optUid;

    @ApiModelProperty(value = "创建人")
    private String optName;

    @ApiModelProperty(value = "规则描述")
    @Size(max = 100,message = "规则描述最多为100个字符")
    private String description;

    @ApiModelProperty(value = "状态")
    private Integer status;
}
