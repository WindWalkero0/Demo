package com.ruihe.admin.service.bi;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.bean.base.UserConcernPo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.admin.enums.BiReportEnum;
import com.ruihe.admin.event.Report4MemberPurchaseTracingEvent;
import com.ruihe.admin.event.ReportMemberSalesFactorEvent;
import com.ruihe.admin.mapper.basic.UserConcernMapper;
import com.ruihe.admin.request.bi.MemberPurchaseSelectRequest;
import com.ruihe.admin.request.bi.MemberPurchaseTraceReportRequest;
import com.ruihe.admin.request.bi.MemberSalesFactorReportRequest;
import com.ruihe.admin.request.bi.MemberSalesFactorSelectRequest;
import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2020-02-05 11:02
 */
@Service
@Slf4j
public class MemberReportService extends AbstractBiReportPreHandler {

    @Resource
    private UserConcernMapper userConcernMapper;

    @Autowired
    private BiReportService biReportService;

    /**
     * 会员购买跟踪报表查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    public Response memberPurchaseTrace(MemberPurchaseTraceReportRequest request) {
        //输出项判断
        MemberPurchaseSelectRequest selectRequest = request.getSelectRequest();
        if (selectRequest == null) {
            return Response.errorMsg("没有选择任何的输出项!");
        }
        //行选择判断
        if (!isRowItemSelected(selectRequest)) {
            return Response.errorMsg("请选择行!");
        }
        if (!isStatItemSelected(selectRequest)) {
            return Response.errorMsg("请选择统计项!");
        }
        //日期设置判断
        if (request.getJoinStartTime() == null || request.getJoinEndTime() == null) {
            return Response.errorMsg("入会查询时间不能为空!");
        }
        if (request.getJoinStartTime().isAfter(LocalDate.now())) {
            return Response.errorMsg("入会结束时间不能大于当前时间!");
        }
        if (request.getJoinStartTime().isAfter(request.getJoinEndTime())) {
            return Response.errorMsg("入会开始时间不能大于结束时间!");
        }
        if (request.getStartTime() == null || request.getEndTime() == null) {
            return Response.errorMsg("购买查询时间不能为空!");
        }
        if (request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("购买开始时间不能大于结束时间!");
        }
        if (request.getEndTime().isAfter(LocalDate.now())) {
            return Response.errorMsg("购买结束时间不能大于当前时间!");
        }
        //获取到当前登录人的信息查询关注部门信息
        List<UserConcernPo> concernPoList = userConcernMapper.selectList(Wrappers.<UserConcernPo>lambdaQuery()
                .eq(UserConcernPo::getEmpId, AdminUserContextHolder.get().getEmpId()));
        //如果关注部门为空，则返回空
        if (concernPoList.isEmpty()) {
            return Response.errorMsg("该账号未关注任何部门，请关注后再查询!");
        }
        //查询正在导出报表的数量
        Integer count = biReportService.getBiReport();
        if (count > 2) {
            return Response.errorMsg("您已有两个报表导出任务，请稍后再导出该报表!");
        }
        //发射导出事件
        Report4MemberPurchaseTracingEvent event = Report4MemberPurchaseTracingEvent
                .builder()
                .request(request)
                .build();
        publishEvent(BiReportEnum.MEMBER_PURCHASE, event, request.getTag(), request.getPicUrl());
        return Response.success();
    }

    /**
     * 有没有选择组织结构项
     *
     * @param selectRequest
     * @return
     */
    private boolean isRowItemSelected(MemberPurchaseSelectRequest selectRequest) {
        boolean bValid = selectRequest.isArea();
        bValid = bValid || selectRequest.isOffice();
        bValid = bValid || selectRequest.isPrincipal();
        bValid = bValid || selectRequest.isCounterId();
        bValid = bValid || selectRequest.isCounterName();
        bValid = bValid || selectRequest.isMemberCardNumber();
        bValid = bValid || selectRequest.isMemberName();
        bValid = bValid || selectRequest.isMobilePhone();
        return bValid;
    }

    /**
     * 有没有选择统计项
     *
     * @param selectRequest
     * @return
     */
    private boolean isStatItemSelected(MemberPurchaseSelectRequest selectRequest) {
        boolean bValid = selectRequest.isRealAmt();
        bValid = bValid || selectRequest.isSkQty();
        bValid = bValid || selectRequest.isOrderQty();
        return bValid;
    }

    /**
     * 会员销售要素统计报表
     *
     * @param request
     * @return fangtao
     */
    @DS(DBConst.MASTER)
    public Response memberSalesFactor(MemberSalesFactorReportRequest request) {
        //输出项判断
        MemberSalesFactorSelectRequest selectRequest = request.getSelectRequest();
        if (selectRequest == null) {
            return Response.errorMsg("没有选择任何的输出项!");
        }
        //行选择判断
        if (!isRowItemSelected(selectRequest)) {
            return Response.errorMsg("请选择行!");
        }
        if (!isStatItemSelected(selectRequest)) {
            return Response.errorMsg("请选择统计项!");
        }
        //日期设置判断
        if (request.getStartTime() == null || request.getEndTime() == null) {
            return Response.errorMsg("购买查询时间不能大于为空!");
        }
        if (request.getEndTime().isAfter(LocalDate.now())) {
            return Response.errorMsg("结束时间不能晚于当前时间!");
        }
        if (request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("时间选择错误!");
        }
        //获取到当前登录人的信息查询关注部门信息
        List<UserConcernPo> concernPoList = userConcernMapper.selectList(Wrappers.<UserConcernPo>lambdaQuery()
                .eq(UserConcernPo::getEmpId, AdminUserContextHolder.get().getEmpId()));
        //如果关注部门为空，则返回空
        if (concernPoList.isEmpty()) {
            return Response.errorMsg("该账号未关注任何部门，请关注后再查询!");
        }
        //查询正在导出报表的数量
        Integer count = biReportService.getBiReport();
        if (count > 2) {
            return Response.errorMsg("您已有两个报表导出任务，请稍后再导出该报表!");
        }
        //发射导出事件
        ReportMemberSalesFactorEvent event = ReportMemberSalesFactorEvent
                .builder()
                .request(request)
                .build();
        publishEvent(BiReportEnum.PRD_MEMBER_SALES, event, request.getTag(),request.getPicUrl());
        return Response.success();
    }

    /**
     * 有没有选择组织结构项
     *
     * @param selectRequest
     * @return
     */
    private boolean isRowItemSelected(MemberSalesFactorSelectRequest selectRequest) {
        boolean bValid = selectRequest.isArea();
        bValid = bValid || selectRequest.isOffice();
        bValid = bValid || selectRequest.isPrincipal();
        bValid = bValid || selectRequest.isCounterId();
        bValid = bValid || selectRequest.isCounterName();
        bValid = bValid || selectRequest.isBaCode();
        bValid = bValid || selectRequest.isBaName();
        return bValid;
    }

    /**
     * 有没有选择统计项
     *
     * @param selectRequest
     * @return
     */
    private boolean isStatItemSelected(MemberSalesFactorSelectRequest selectRequest) {
        boolean bValid = selectRequest.isSalesDays();
        bValid = bValid || selectRequest.isSalesAmt();
        bValid = bValid || selectRequest.isSalesOrderQty();
        bValid = bValid || selectRequest.isSalesGoodsQty();
        bValid = bValid || selectRequest.isMemPur();
        bValid = bValid || selectRequest.isMemAmt();
        bValid = bValid || selectRequest.isMemOrder();
        bValid = bValid || selectRequest.isMj();
        bValid = bValid || selectRequest.isNewPur();
        bValid = bValid || selectRequest.isNewAmt();
        bValid = bValid || selectRequest.isNewOrder();
        bValid = bValid || selectRequest.isNewPct();
        bValid = bValid || selectRequest.isVetPur();
        bValid = bValid || selectRequest.isVetAmt();
        bValid = bValid || selectRequest.isVetOrder();
        bValid = bValid || selectRequest.isVetPct();
        bValid = bValid || selectRequest.isMemAmtPp();
        bValid = bValid || selectRequest.isMemOrderPp();
        bValid = bValid || selectRequest.isPct();
        bValid = bValid || selectRequest.isJr();
        bValid = bValid || selectRequest.isNewAmtPp();
        bValid = bValid || selectRequest.isNewOrderPp();
        bValid = bValid || selectRequest.isNewRepurRate();
        bValid = bValid || selectRequest.isNonMemOrder();
        bValid = bValid || selectRequest.isVetAmtPp();
        bValid = bValid || selectRequest.isVetOrderPp();
        bValid = bValid || selectRequest.isVetRepurRate();
        bValid = bValid || selectRequest.isOptNew();
        bValid = bValid || selectRequest.isOptNewAmt();
        bValid = bValid || selectRequest.isOptNewOrder();
        bValid = bValid || selectRequest.isOptNewRepurRate();
        bValid = bValid || selectRequest.isOptNewPct();
        return bValid;
    }
}
