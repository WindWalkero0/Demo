package com.ruihe.admin.event;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 定时检查微信会员卡菜单rabbit发送事件的时间
 *
 * @author LiangYuan
 * @date 2021-03-22 16:04
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SendRabbitMsgEvent {
}
