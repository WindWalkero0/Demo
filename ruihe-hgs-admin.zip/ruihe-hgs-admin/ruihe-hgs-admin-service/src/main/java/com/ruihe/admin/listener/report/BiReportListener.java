package com.ruihe.admin.listener.report;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.admin.listener.style.ColumnWidthStyleStrategy;
import com.ruihe.common.dao.bean.bi.BiGenericReport;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.Report4GenericEvent;
import com.ruihe.admin.mapper.bi.BiGenericReportMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.utils.ExcelImgUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/***
 * 通用报表消息接收器
 * @author lrc
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class BiReportListener extends AbstractReportListener<Report4GenericEvent> {
    private final BiGenericReportMapper genericReportMapper;
    private final SqlSessionFactory sessionFactory;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_REPORT)
    @EventListener
    public void onApplicationEvent(Report4GenericEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    public void doExport(Report4GenericEvent event, BiReportPo report, boolean flag) {
        Map<String, String> params = event.getRequest();
        Integer reportId = Integer.valueOf(params.get("report_id"));
        BiGenericReport genericReport = genericReportMapper.selectById(reportId);
        if (genericReport == null) {
            throw new RuntimeException("报表模板找不到 " + reportId);
        }

        SqlSession sqlSession = sessionFactory.openSession();
        Connection conn = sqlSession.getConnection();
        try (sqlSession) {
            String sql = buildSql(genericReport, params);
            PreparedStatement statement = conn.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            handleResult(rs, genericReport, report);
        } catch (SQLException e) {
            throw new RuntimeException("sql模板错误 " + reportId);
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                log.error("close connection", e);
            }
        }
    }

    private String buildSql(BiGenericReport design, Map<String, String> params) {
        String[] sqls = design.getSqlTpl().split(";");
        String sql;
        if (sqls.length > 1) {
            sql = sqls[1];
        } else {
            sql = sqls[0];
        }
        for (var e : params.entrySet()) {
            sql = sql.replaceAll("@" + e.getKey(), "'" + e.getValue() + "'");
        }
        return sql;
    }

    private void handleResult(ResultSet rs, BiGenericReport report, BiReportPo reportPo) {
        try {
            ResultSetMetaData metaData = rs.getMetaData();
            List<List<String>> head = buildHead(metaData);
            List<List<Object>> rows = buildRows(rs);
            write(reportPo, head, rows, reportPo.getPicUrl(), reportPo.getPicUrl());
        } catch (SQLException e) {
            throw new RuntimeException("读取数据失败", e);
        }
    }

    private List<List<String>> buildHead(ResultSetMetaData metaData) throws SQLException {
        List<List<String>> head = new ArrayList<>();
        int c = metaData.getColumnCount();
        for (int i = 1; i <= c; i++) {
            String label = metaData.getColumnLabel(i);
            head.add(List.of(label));
        }
        return head;
    }

    private List<List<Object>> buildRows(ResultSet rs) throws SQLException {
        List<List<Object>> rows = new ArrayList<>();
        ResultSetMetaData metaData = rs.getMetaData();
        int c = metaData.getColumnCount();

        while (rs.next()) {
            List<Object> row = new ArrayList<>();
            for (int i = 1; i <= c; i++) {
                row.add(rs.getObject(i));
            }
            rows.add(row);
        }
        return rows;
    }

    public void write(BiReportPo report, List<List<String>> head, List<List<Object>> rows, String staticRootUrl, String picUrl) {
        ExcelWriter excelWriter = EasyExcel.write(report.getFilePath()).build();
        WriteSheet writeSheet = EasyExcel.writerSheet(report.getReportName())
                .head(head)
                .registerWriteHandler(new ColumnWidthStyleStrategy())
                .automaticMergeHead(true)
                .relativeHeadRowIndex(1)
                .build();

        excelWriter.write(rows, writeSheet);
        if (StringUtils.isNotBlank(staticRootUrl)) {
            ExcelImgUtils.CreatImgSheet(staticRootUrl, picUrl, excelWriter);
        }
        excelWriter.finish();
    }
}
