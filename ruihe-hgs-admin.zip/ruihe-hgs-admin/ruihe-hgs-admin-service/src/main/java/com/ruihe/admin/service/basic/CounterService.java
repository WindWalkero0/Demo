package com.ruihe.admin.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.base.Joiner;
import com.ruihe.admin.enums.BiReportEnum;
import com.ruihe.admin.event.CounterExcelEvent;
import com.ruihe.admin.event.CounterOperateEvent;
import com.ruihe.admin.event.UpdateOrderOptEvent;
import com.ruihe.admin.event.UpdateOrderOrgEvent;
import com.ruihe.admin.mapper.basic.CounterMapper;
import com.ruihe.admin.request.CommonCounterRequest;
import com.ruihe.admin.request.basic.CounterOptRequest;
import com.ruihe.admin.request.basic.CounterRequest;
import com.ruihe.admin.service.bi.AbstractBiReportPreHandler;
import com.ruihe.admin.vo.CounterCommonVo;
import com.ruihe.admin.vo.CounterOperationFieldsVo;
import com.ruihe.admin.vo.CounterOperationVo;
import com.ruihe.common.annotation.FieldName;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.*;
import com.ruihe.common.dao.bean.rgebox.DepositBoxPo;
import com.ruihe.common.dao.mapper.CounterOperationFieldsMapper;
import com.ruihe.common.dao.mapper.CounterOperationMapper;
import com.ruihe.common.dao.mapper.DepartmentMapper;
import com.ruihe.common.dao.mapper.DepositBoxMapper;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.base.CounterOptEnum;
import com.ruihe.common.enums.base.DepartmentEnum;
import com.ruihe.common.enums.base.DepartmentTestEnum;
import com.ruihe.common.enums.prefix.PrefixEnum;
import com.ruihe.common.enums.redis.RedisEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;
import com.ruihe.common.pojo.dto.UserInformationDTO;
import com.ruihe.common.pojo.response.basic.CounterVo;
import com.ruihe.common.response.Response;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.service.ChangeService;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 柜台管理业务逻辑层
 *
 * @Author 胡坤
 * @Date 2019年6月13日13:55:07
 */
@Slf4j
@Service
public class CounterService extends AbstractBiReportPreHandler {

    @Autowired
    private CustomService customService;

    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private CounterOperationMapper counterOperationMapper;

    @Autowired
    private CounterOperationFieldsMapper counterOperationFieldsMapper;

    @Autowired
    private DepositBoxMapper depositBoxMapper;

    @Autowired
    private UserService userService;

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private DepartmentMapper departmentMapper;

    @Autowired
    private ChangeService changeService;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    /**
     * 添加柜台信息
     *
     * @param counterInformation counterInformation
     * @return Response
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addCounter(CounterInformation counterInformation) throws Exception {
        //对SN编号进行判断
        if (StringUtils.isNotBlank(counterInformation.getSn()) && counterInformation.getSn().length() > 25) {
            return Response.errorMsg("长度超过限制，请确认后重试!");
        }
        //检测柜台信息是否重复
//        List<CounterInformation> counterInformationList = checkCounter(counterInformation);
//        if (!counterInformationList.isEmpty()) {
//            return Response.errorMsg(CounterEnum.COUNTER_NAME_EXIT.getValue());
//        }
        //根据柜台主管填充办事处和大区信息
        if (StringUtils.isNotBlank(counterInformation.getPrincipalEmpDeptCode())) {
            fillCounterInformation(counterInformation);
        }
        //填充柜台数据
        //填充创建时间
        counterInformation.setCreateTime(LocalDateTime.now());
        counterInformation.setCounterId(IdGenerator.getRandomId(PrefixEnum.COUNTER.getCode(), 6));
        fillCounter(counterInformation);
        //修改履历--added by William 2020.11.13
        Long counterChangeId = changeService.insert(CounterInformation.class, counterInformation.getCounterId(), "新建柜台");
        counterInformation.setChangeId(counterChangeId);
        Integer save = customService.save(counterInformation);
        if (save == 0) {
            log.error("填充柜台数据,添加柜台失败counterInformation={}", counterInformation);
            throw new Exception("添加柜台失败");
        }
        this.saveChangeRecord(counterInformation, counterInformation.getCounterId(), CounterOptEnum.ADD.getKey());
        //删除缓redis存记录
        redisTemplate.delete(RedisEnum.REGION_COUNTER.getKey());
        redisTemplate.delete(RedisEnum.REGION_NULL.getKey());
        //添加寄存箱
        addRge(counterInformation);
        //填充部门信息
        Department department = this.extractDepartment(counterInformation);
        //修改履历--added by William 2020.11.13
        Long deptChangeId = changeService.insert(Department.class, department.getDeptId(), "新增柜台");
        department.setChangeId(deptChangeId);
        Integer rows = departmentMapper.insert(department);
        if (rows == 0) {
            log.error("填充部门信息,添加柜台失败:department={}", department);
            throw new Exception("添加柜台失败");
        }
        //发布事件
        CounterOperateEvent counterOperateEvent = new CounterOperateEvent(counterInformation.getCounterId());
        this.publishEvent(counterOperateEvent);
        return Response.success(StatusEnum.SUCCESS.getValue());
    }

    /**
     * 根据柜台主管信息设置组织机构
     *
     * @param counterInformation
     * @return 是否需要修改t_pos_order的组织结构
     */
    private boolean fillCounterInformation(CounterInformation counterInformation) {
        CounterInformation oldCounterInformation = counterMapper.selectById(counterInformation.getCounterId());
        String oldStr = null;
        if (oldCounterInformation != null) {
            //添加的时候不需要修改order里面的东西
            List<String> joinList = List.of(oldCounterInformation.getOrgAreaId() + "", oldCounterInformation.getOrgAreaName() + "",
                    oldCounterInformation.getOrgOfficeId() + "", oldCounterInformation.getOrgOfficeName() + "",
                    oldCounterInformation.getOrgMasterId() + "", oldCounterInformation.getOrgMasterName() + "");
            oldStr = Joiner.on("").skipNulls().join(joinList);
        }
        //根据id获取柜台信息
        Department department = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery()
                .eq(Department::getDeptId, counterInformation.getPrincipalEmpDeptCode()));
        //先将所有的设置为空
        counterInformation.setOrgMasterId("");
        counterInformation.setOrgMasterName("");
        counterInformation.setOrgOfficeId("");
        counterInformation.setOrgOfficeName("");
        counterInformation.setOrgAreaId("");
        counterInformation.setOrgAreaName("");

        //根据部门的类型进行处理
        if (department.getDeptType().equals(DepartmentEnum.COUNTER_SUPERVISOR.getKey())) {
            //如果该部门的类型是柜台主管
            counterInformation.setOrgMasterId(department.getDeptId());
            counterInformation.setOrgMasterName(department.getDeptName());
            //根据上级部门进行查询
            Department updepart = upDepartment(department.getUpDeptId());
            if (updepart.getDeptType().equals(DepartmentEnum.OFFICE.getKey())) {
                counterInformation.setOrgOfficeId(updepart.getDeptId());
                counterInformation.setOrgOfficeName(updepart.getDeptName());
                //根据办事处查询上级部门信息
                Department upDepartment = upDepartment(updepart.getUpDeptId());
                if (upDepartment.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
                    //如果上级部门是大区
                    counterInformation.setOrgAreaId(upDepartment.getDeptId());
                    counterInformation.setOrgAreaName(upDepartment.getDeptName());
                }
            } else if (updepart.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
                counterInformation.setOrgAreaId(updepart.getDeptId());
                counterInformation.setOrgAreaName(updepart.getDeptName());
            }
        } else if (department.getDeptType().equals(DepartmentEnum.OFFICE.getKey())) {
            //如果该部门类型是办事处，设置办事处信息
            counterInformation.setOrgOfficeId(department.getDeptId());
            counterInformation.setOrgOfficeName(department.getDeptName());
            //根据上级部门进行查询
            Department updepart = upDepartment(department.getUpDeptId());
            if (updepart.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
                counterInformation.setOrgAreaId(updepart.getDeptId());
                counterInformation.setOrgAreaName(updepart.getDeptName());
            }
        } else if (department.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
            //如果部门类型是大区，直接设置大区信息
            counterInformation.setOrgAreaId(department.getDeptId());
            counterInformation.setOrgAreaName(department.getDeptName());
        }
        List<String> newJoinList = List.of(counterInformation.getOrgAreaId() + "", counterInformation.getOrgAreaName() + "",
                counterInformation.getOrgOfficeId() + "", counterInformation.getOrgOfficeName() + "",
                counterInformation.getOrgMasterId() + "", counterInformation.getOrgMasterName() + "");
        String newStr = Joiner.on("").skipNulls().join(newJoinList);
        if (oldStr == null) {
            return false;
        }
        return !newStr.equals(oldStr);
    }

    private Department upDepartment(String upDeptId) {
        Department department = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, upDeptId));
        return department;
    }

    /**
     * 构建新增保存部门数据
     *
     * @param counterInformation
     * @return Department
     */
    private Department extractDepartment(CounterInformation counterInformation) {
        Department department = upDepartment(counterInformation.getPrincipalEmpDeptCode());
        return Department.builder()
                .deptId(counterInformation.getCounterId())
                .deptName(counterInformation.getCounterName())
                .deptType(DepartmentEnum.COUNTER.getKey())
                .brandName(counterInformation.getBrandName())
                .isTest(getDepartmentIsTest(counterInformation.getCounterType()))
                .status(getDepartmentStatus(StatusEnum.UN_DELETED.getKey()))
                .upDeptId(department.getDeptId())
                .upDeptName(department.getDeptName())
                .upDeptType(department.getDeptType())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
    }

    /**
     * 将柜台的测试区分转换为柜台的测试区分
     *
     * @param isTest
     * @return
     */
    private Integer getDepartmentIsTest(Integer isTest) {
        return isTest.equals(CounterEnum.FORMAL_COUNTER.getKey()) ? DepartmentTestEnum.FORMAL_DEPARTMENT.getKey() : DepartmentTestEnum.TEST_DEPARTMENT.getKey();
    }


    /**
     * 查询柜台
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectCounter(CounterRequest request) {
        //设置分页条件
        PageHelper.startPage(request.getPageNumber(), request.getPageSize());
        List<CounterInformation> counterResponses = counterMapper.searchMation(request);
        PageInfo<CounterInformation> info = new PageInfo<>(counterResponses);
        return Response.success(info);
    }

    /**
     * 查询柜台详细信息
     *
     * @param counterId
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectDetail(String counterId) {
        CounterInformation counterInformation = selectCounterInfo(counterId);
        List<UserInformationDTO> userInformationList = new ArrayList<>();
        //查询柜台下面的人员信息信息
        List<UserCounter> userCounters = selectUserCounter(counterInformation.getCounterId());
        if (!userCounters.isEmpty()) {
            userCounters.forEach(userCounter -> {
                UserInformation userInformation = userService.selectUserInfoByUid(userCounter.getEmpId());
                if (userInformation == null) {
                    return;
                }
                userInformationList.add(userInformation.convert2DTO());
            });
        }
        CounterVo counterVo = new CounterVo();
        counterVo.setCounterInformation(counterInformation.convert2DTO());
        counterVo.setUserInformationList(userInformationList);
        return Response.success(counterVo);
    }

    /**
     * 停用或者启用柜台
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response disableEnable(CounterRequest request) throws Exception {
        List<String> counterIds = request.getCounterIds();
        if (counterIds == null || counterIds.isEmpty()) {
            return Response.errorMsg("请选择需要停用/启用柜台!");
        }
        for (String counterId : counterIds) {
            CounterInformation build = CounterInformation
                    .builder()
                    .isDel(request.getIsDel())
                    .updateTime(LocalDateTime.now())
                    .build();
            if (request.getIsDel().equals(1)) {//停业
                build.setStopTime(LocalDateTime.now());
            } else {
                CounterInformation counterInformation = selectCounterInfo(counterId);
                if (!counterInformation.getIsDel().equals(request.getIsDel())) {
                    build.setReopenTime(LocalDateTime.now());
                }
            }
            //更新柜台信息
            updateCounter(build, CounterInformation.builder().counterId(counterId).build());
        }
        //更新部门信息
        updateDepartStatus(request.getIsDel(), counterIds);
        //删除缓redis存记录
        redisTemplate.delete(RedisEnum.REGION_COUNTER.getKey());
        redisTemplate.delete(RedisEnum.REGION_NULL.getKey());
        return Response.success(StatusEnum.SUCCESS.getValue());
    }

    /**
     * 更新部门状态信息
     *
     * @param isDel
     * @param counterIds
     * @throws Exception
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void updateDepartStatus(Integer isDel, List<String> counterIds) throws Exception {
        //兼容信息：由于数据的关系，可能存在柜台在柜台表中，而不在部门表中，此时直接更新部门信息会报错
        Integer count = departmentMapper.selectCount(Wrappers.<Department>lambdaQuery()
                .in(Department::getDeptId, counterIds));
        //不在部门表中，则不进行处理
        if (count == 0) {
            return;
        }
        //修改履历--added by William 2020.11.17
        counterIds.forEach(e -> {
            Department dept = Department.builder().status(getDepartmentStatus(isDel)).updateTime(LocalDateTime.now()).build();
            Long changeId = changeService.update(Department.class, e.trim(), "启用停用柜台");
            dept.setChangeId(changeId);
            int update = departmentMapper.update(dept, Wrappers.<Department>lambdaUpdate().eq(Department::getDeptId, e));
            if (update == 0) {
                log.error("更改部门是否停用状态失败" + e);
                throw new BizException("更改部门是否停用状态失败");
            }
        });
        /*//在部门表中查询到数据，则进行更新
        Integer update = departmentMapper.update(Department.builder().status(getDepartmentStatus(isDel)).build(), Wrappers.<Department>lambdaUpdate()
                .in(Department::getDeptId, counterIds));
        //这个地方理论上应该是  !update.equals(counterIds.size()) 或者  !update.equals(count)
        if (update == 0) {
            log.error("更改部门是否停用状态失败" + counterIds);
            throw new BizException("更改部门是否停用状态失败");
        }*/
    }

    /**
     * 将柜台的状态转换成部门的状态
     *
     * @param isDel
     * @return
     */
    private Integer getDepartmentStatus(Integer isDel) {
        return isDel == 0 ? CommonStatusEnum.EFFECTIVE.getCode() : CommonStatusEnum.INVALID.getCode();
    }

    /**
     * 保存编辑柜台信息
     *
     * @param counterInformation
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response saveCounter(CounterInformation counterInformation) throws Exception {
        //对SN编号进行判断
        if (StringUtils.isNotBlank(counterInformation.getSn()) && counterInformation.getSn().length() > 25) {
            return Response.errorMsg("长度超过限制，请确认后重试!");
        }
        CounterInformation oldCounterInformation = counterMapper.selectById(counterInformation.getCounterId());
        if (!oldCounterInformation.getOperationalModel().equals(counterInformation.getOperationalModel()) || !oldCounterInformation.getCounterType().equals(counterInformation.getCounterType())) {
            this.publishEvent(new UpdateOrderOptEvent(counterInformation.getCounterId()));
        }
        //检测柜台信息
//        List<CounterInformation> counterInformations = checkCounter(counterInformation);
//        if (!counterInformations.isEmpty()) {
//            for (CounterInformation information : counterInformations) {
//                if (!information.getCounterId().equals(counterInformation.getCounterId())) {
//                    return Response.errorMsg(CounterEnum.COUNTER_NAME_EXIT.getValue());
//                }
//            }
//        }
        //根据柜台主管填充办事处和大区信息
        if (StringUtils.isNotBlank(counterInformation.getPrincipalEmpDeptCode())) {
            boolean flag = fillCounterInformation(counterInformation);
            if (flag) {
                this.publishEvent(new UpdateOrderOrgEvent(counterInformation.getCounterId()));
            }
        }
        //提醒发送事件
        compareCounter(counterInformation);
        //填充柜台数据
        fillCounter(counterInformation);
        //更新柜台信息
        this.saveChangeRecord(counterInformation, counterInformation.getCounterId(), CounterOptEnum.EDIT.getKey());
        //修改履历--added by William 2020.11.17
        Long counterChangeId = changeService.update(CounterInformation.class, counterInformation.getCounterId(), "编辑柜台");
        counterInformation.setChangeId(counterChangeId);
        int rows = counterMapper.updateById(counterInformation);
        if (rows == 0) {
            log.error("更改柜台信息失败，counterInformation={}", counterInformation);
            throw new BizException("更改柜台信息失败");
        }
        //updateCounter(counterInformation, CounterInformation.builder().counterId(counterInformation.getCounterId()).build());
        //更新部门信息
        Department department = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery()
                .eq(Department::getDeptId, counterInformation.getCounterId()));
        if (department != null) {
            updateDepartment(counterInformation);
        }
        //发布事件
        CounterOperateEvent counterOperateEvent = new CounterOperateEvent(counterInformation.getCounterId());
        this.publishEvent(counterOperateEvent);
        return Response.success(StatusEnum.SUCCESS.getValue());
    }

    /**
     * 更新部门信息
     *
     * @param counterInformation
     * @throws Exception
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void updateDepartment(CounterInformation counterInformation) throws Exception {
        //根据柜台主管所属部门获取上级部门信息
        Department dept = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery()
                .eq(Department::getDeptId, counterInformation.getPrincipalEmpDeptCode()));
        Department department = Department.builder()
                .deptName(counterInformation.getCounterName())
                .brandName(counterInformation.getBrandName())
                .isTest(getDepartmentIsTest(counterInformation.getCounterType()))
                .upDeptId(dept.getDeptId())
                .upDeptName(dept.getDeptName())
                .upDeptType(dept.getDeptType())
                .updateTime(LocalDateTime.now())
                .build();
        if (counterInformation.getCounterType() != null) {
            department.setStatus(getDepartmentStatus(counterInformation.getIsDel()));
        }
        //修改履历--added by William 2020.11.17
        Long changeId = changeService.insert(Department.class, counterInformation.getCounterId(), "编辑柜台-更新部门");
        department.setChangeId(changeId);
        int update = departmentMapper.update(department, Wrappers.<Department>lambdaUpdate()
                .eq(Department::getDeptId, counterInformation.getCounterId()));
        if (update == 0) {
            log.error("更改单个柜台信息失败" + counterInformation);
            throw new BizException("更改单个柜台信息失败");
        }
    }

    /**
     * 查看柜台名称和区域是否有变化
     */
    private void compareCounter(CounterInformation newCounterInformation) throws Exception {
        //查询原柜台
        CounterInformation counterInformation = selectCounterInfo(newCounterInformation.getCounterId());
        //原柜台与现在柜台进行对比---柜台名称&&区域信息任何发生了变化 进行事件推送
        if (!counterInformation.getCounterName().equals(newCounterInformation.getCounterName()) ||
                counterInformation.getLargeAreaCode().equals(newCounterInformation.getLargeAreaCode()) ||
                counterInformation.getProvinceCode().equals(newCounterInformation.getProvinceCode()) ||
                counterInformation.getCityCode().equals(newCounterInformation.getCityCode()) ||
                counterInformation.getCountyCode().equals(newCounterInformation.getCountyCode())
        ) {
            //删除缓redis存记录
            redisTemplate.delete(RedisEnum.REGION_COUNTER.getKey());
            redisTemplate.delete(RedisEnum.REGION_NULL.getKey());
        }
    }

    /**
     * 更新柜台信息
     */
    private void updateCounter(CounterInformation counterInformation, CounterInformation counterInformationOther) throws Exception {
        this.saveChangeRecord(counterInformation, counterInformationOther.getCounterId(), CounterOptEnum.EDIT.getKey());
        //修改履历--added by William 2020.11.17
        Long counterChangeId = changeService.update(CounterInformation.class, counterInformationOther.getCounterId(), "启用停用柜台");
        counterInformation.setChangeId(counterChangeId);
        Integer update = customService.update(counterInformation, counterInformationOther);
        if (update == 0) {
            log.error("更改柜台信息失败，counterInformation={}，counterInformationOther={}", counterInformation, counterInformationOther);
            throw new BizException("更改柜台信息失败");
        }
    }

    /**
     * 根据柜台id 查询柜台信息
     */
    @DS(DBConst.SLAVE)
    public CounterInformation selectCounterInfo(String counterId) {
        return customService.select(CounterInformation.builder().counterId(counterId).build());
    }


    /**
     * 填充柜台数据
     */
    private void fillCounter(CounterInformation counterInformation) {
        //时间填充
        if (counterInformation.getCounterType().equals(CounterEnum.CLOSE_COUNTER.getKey())) {
            counterInformation.setStopTime(LocalDateTime.now());
        }
        counterInformation.setUpdateTime(LocalDateTime.now());
        //填充组织信息
        //fillDepartment(counterInformation.getOrgMasterId(), counterInformation);
    }

    /**
     * 填充组织信息
     */
    private void fillDepartment(String departmentId, CounterInformation counterInformation) {
        Department department = departmentService.selectDepByID(departmentId);
        if (department != null) {
            //填充办事出信息
            if (department.getDeptType().equals(DepartmentEnum.OFFICE.getKey())) {
                counterInformation.setOrgOfficeId(department.getDeptId());
                counterInformation.setOrgOfficeName(department.getDeptName());
            }
            //填充大区信息
            if (department.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
                counterInformation.setOrgAreaId(department.getDeptId());
                counterInformation.setOrgAreaName(department.getDeptName());
            }
            fillDepartment(department.getUpDeptId(), counterInformation);
        }
    }

    /**
     * 检测柜台信息是否重复
     * 更新，新需求要求柜台名称可以重复
     */
    @Deprecated
    private List<CounterInformation> checkCounter(CounterInformation counterInformation) {
        return customService.selectList(CounterInformation
                .builder()
                .counterName(counterInformation.getCounterName())
                .build());
    }


    /**
     * 根据柜台编号查询下面的人员信息信息
     */
    private List<UserCounter> selectUserCounter(String counterId) {
        return customService.selectList(UserCounter
                .builder()
                .counterCode(counterId)
                .build());
    }

    /**
     * 添加用户页面选择工作柜台
     * 查询柜台
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectCounter(CommonCounterRequest request) {
        //判断页数和页面
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            return Response.errorMsg("页数、页码不能为空!");
        }
        Page<CounterInformation> page = new Page<>(request.getPageNumber(), request.getPageSize());
        LambdaQueryWrapper<CounterInformation> queryWrapper = Wrappers.<CounterInformation>lambdaQuery().eq(CounterInformation::getIsDel, 0);
        if (StringUtils.isNotBlank(request.getCounter())) {
            queryWrapper.and(c -> c.like(CounterInformation::getCounterId, request.getCounter())
                    .or().like(CounterInformation::getCounterName, request.getCounter()));
        }
        IPage<CounterInformation> counterIPage = counterMapper.selectPage(page, queryWrapper);
        List<CounterInformation> counterList = counterIPage.getRecords();
        PageVO pageVO = PageVO.<CounterCommonVo>builder().list(ObjectUtils.toList(counterList, CounterCommonVo.class))
                .total(counterIPage.getTotal())
                .pageNum(counterIPage.getCurrent())
                .pageSize(counterIPage.getSize())
                .pages(counterIPage.getPages()).build();
        return Response.success(pageVO);
    }

    /**
     * 添加寄存箱
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void addRge(CounterInformation counterInformation) {
        List<DepositBoxPo> list = new ArrayList<>();
        for (int i = 1; i < 1000; i++) {
            DepositBoxPo depositBox = DepositBoxPo
                    .builder()
                    .counterId(counterInformation.getCounterId())
                    .counterName(counterInformation.getCounterName())
                    .status(StatusEnum.UN_DELETED.getKey())
                    .boxNo(String.valueOf(i))
                    .build();
            list.add(depositBox);
        }
        Integer save = depositBoxMapper.batchInsert(list);
        if (save != list.size()) {
            String errorMsg = String.format("添加柜台寄存箱失败，counterId=%s，counterName=%s", counterInformation.getCounterId(), counterInformation.getCounterName());
            log.error(errorMsg);
            throw new BizException("添加柜台寄存箱失败");
        }
    }


    /**
     * 根据渠道编码查询柜台列表
     *
     * @param channelCode
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response channelCounter(String channelCode) {
        List<CounterInformation> list = counterMapper.selectList(Wrappers.<CounterInformation>lambdaQuery()
                .eq(CounterInformation::getChannelCode, channelCode));
        return Response.success(ObjectUtils.toList(list, CounterCommonVo.class));
    }

    /**
     * 通用柜台模糊查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response commonCounter(CommonCounterRequest request) {
        //判断页数和页面
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            return Response.errorMsg("页数、页码不能为空!");
        }
        Page<CounterInformation> page = new Page<>(request.getPageNumber(), request.getPageSize());
        LambdaQueryWrapper<CounterInformation> queryWrapper = Wrappers.<CounterInformation>lambdaQuery()
                .orderByDesc(CounterInformation::getCreateTime)
                .orderByDesc(CounterInformation::getCounterId);
        //状态
        if (request.getStatus() != null) {
            queryWrapper.eq(CounterInformation::getIsDel, request.getStatus());
        }
        //柜台名称/编码模糊查询
        if (StringUtils.isNotBlank(request.getCounter())) {
            queryWrapper.and(c -> c.like(CounterInformation::getCounterId, request.getCounter())
                    .or().like(CounterInformation::getCounterName, request.getCounter()));
        }
        IPage<CounterInformation> counterIPage = counterMapper.selectPage(page, queryWrapper);
        List<CounterInformation> counterList = counterIPage.getRecords();
        PageVO pageVO = PageVO.<CounterCommonVo>builder().list(ObjectUtils.toList(counterList, CounterCommonVo.class))
                .total(counterIPage.getTotal())
                .pageNum(counterIPage.getCurrent())
                .pageSize(counterIPage.getSize())
                .pages(counterIPage.getPages()).build();
        return Response.success(pageVO);
    }

    public Response exportTable(CounterRequest request) {
        CounterExcelEvent event = CounterExcelEvent.builder().request(request).build();
        publishEvent(BiReportEnum.COUNTER_INFO, event, request.getRemark(), request.getPicUrl());
        return Response.successMsg("提交成功，请至下载中心下载");
    }

    /**
     * 更改柜台前存一份柜台的修改记录
     *
     * @param newModel
     * @param counterId
     * @throws NoSuchMethodException
     * @throws InvocationTargetException
     * @throws IllegalAccessException
     */
    private void saveChangeRecord(CounterInformation newModel, String counterId, Integer type) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        //id获取老的柜台属性
        CounterInformation oldModel;
        if (CounterOptEnum.ADD.getKey().equals(type)) {
            oldModel = newModel;
        } else {
            oldModel = counterMapper.selectById(counterId);
        }
        var userInformation = AdminUserContextHolder.get();
        Field[] field = newModel.getClass().getDeclaredFields();
        //生成操作id
        String logId = IdGenerator.getLongSerialNo().toString();
        String empId = userInformation.getEmpId();
        String empName = userInformation.getName();

        List<CounterOperationFields> fields = new ArrayList<>();
        for (Field value : field) {
            String name = value.getName();
            String methodName = name.substring(0, 1).toUpperCase() + name.substring(1);
            Method m = newModel.getClass().getMethod("get" + methodName);
            Object invoke = m.invoke(newModel);
            //空属性不记录 也不会修改
            if (!"".equals(invoke + "") && !"null".equals(invoke + "")) {
                Method oldM = newModel.getClass().getMethod("get" + methodName);
                value.setAccessible(true);
                FieldName annotation = value.getAnnotation(FieldName.class);
                Object oldInvoke = oldM.invoke(oldModel);
                //时间类型就不记录了,时间就是这个修改发生的时间  没有那种时间范围的
                if (value.getGenericType().toString().equals("class java.time.LocalDateTime")) {
                    //时间就转换格式
                    LocalDateTime newDateTime = (LocalDateTime) oldM.invoke(newModel);
                    LocalDateTime oldDateTime = (LocalDateTime) oldM.invoke(oldModel);
                    if (newDateTime == null || oldDateTime == null) {
                        continue;
                    }
                    oldInvoke = oldDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                    invoke = newDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                }

                //2020年10月20日14:10:36 瑞敏认为只暂时修改的可见字段
                String[] strArray = {"brandName", "channelName", "cityName", "counterAbbrev",
                        "counterAddress", "counterCooperative", "counterName", "counterType",
                        "countyName", "isDel", "isPosExit", "counterPhone", "sn",
                        "principalEmpName", "principalEmpId", "largeAreaName", "provinceName", "operationalModel"};
                //需要展示的字段
                List showList = Arrays.asList(strArray);
                if (!showList.contains(name)) {
                    continue;
                }

                if ("IsDel".equals(methodName)) {
                    //字段存的方式转换
                    oldInvoke = "1".equals(oldInvoke + "") ? "停用" : "启用";
                    invoke = "1".equals(invoke + "") ? "停用" : "启用";
                }
                if ("OperationalModel".equals(methodName)) {
                    //字段存的方式转换
                    oldInvoke = "10005".equals(oldInvoke + "") ? "直营" : "加盟";
                    invoke = "10005".equals(invoke + "") ? "直营" : "加盟";
                }
                if ("CounterType".equals(methodName)) {
                    //字段存的方式转换
                    oldInvoke = "10001".equals(oldInvoke + "") ? "正式" : "测试";
                    invoke = "10001".equals(invoke + "") ? "正式" : "测试";
                }
                if ("CounterCooperative".equals(methodName)) {
                    //字段存的方式转换
                    oldInvoke = "10009".equals(oldInvoke + "") ? "协同" : "不协同";
                    invoke = "10009".equals(invoke + "") ? "协同" : "不协同";
                }
                if ("IsPosExit".equals(methodName)) {
                    //字段存的方式转换
                    oldInvoke = "10008".equals(oldInvoke + "") ? "否" : "是";
                    invoke = "10008".equals(invoke + "") ? "否" : "是";
                }
                if ("UpdateTime".equals(methodName)) {
                    //更新时间类型跳过
                    continue;
                }

                if (CounterOptEnum.ADD.getKey().equals(type)) {
                    CounterOperationFields counterOperationFields = new CounterOperationFields();
                    counterOperationFields.setCounterId(oldModel.getCounterId());
                    counterOperationFields.setField(annotation.name());
                    counterOperationFields.setFieldBefore("");
                    counterOperationFields.setFieldAfter(invoke + "");
                    counterOperationFields.setOperationId(logId);
                    fields.add(counterOperationFields);
                } else {
                    if (!(oldInvoke + "").equals(invoke + "")) {
                        //不相等时存入
                        CounterOperationFields counterOperationFields = new CounterOperationFields();
                        counterOperationFields.setCounterId(oldModel.getCounterId());
                        counterOperationFields.setField(annotation.name());
                        counterOperationFields.setFieldBefore(oldInvoke + "");
                        counterOperationFields.setFieldAfter(invoke + "");
                        counterOperationFields.setOperationId(logId);
                        fields.add(counterOperationFields);
                    }
                }
            }
        }
        if (fields.size() > 0) {
            CounterOperation counterOperation = new CounterOperation();
            counterOperation.setCounterId(oldModel.getCounterId());
            counterOperation.setCounterName(oldModel.getCounterName());
            counterOperation.setEmpId(empId);
            counterOperation.setEmpName(empName);
            counterOperation.setType(type);
            counterOperation.setOperationId(logId);
            counterOperation.setCreateTime(LocalDateTime.now());

            counterOperationMapper.insert(counterOperation);
            counterOperationFieldsMapper.batchInsert(fields);
        }
    }

    /**
     * 查询柜台修改履历
     *
     * @param counterOptRequest
     * @return
     */
    public Response counterOperation(CounterOptRequest counterOptRequest) {
        Page<CounterOperation> page = new Page<>(counterOptRequest.getPageNumber(), counterOptRequest.getPageSize());
        IPage<CounterOperation> counterOperationPage = counterOperationMapper.selectPage(page, Wrappers.<CounterOperation>lambdaQuery()
                .eq(CounterOperation::getCounterId, counterOptRequest.getCounterId())
                .orderByDesc(CounterOperation::getCreateTime));
        List<CounterOperation> counterOperationList = counterOperationPage.getRecords();
        PageVO info = PageVO.<CounterOperationVo>builder().list(ObjectUtils.toList(counterOperationList, CounterOperationVo.class))
                .total(counterOperationPage.getTotal())
                .pageNum(counterOperationPage.getCurrent())
                .pageSize(counterOperationPage.getSize())
                .pages(counterOperationPage.getPages()).build();
        return Response.success(info);
    }

    /**
     * 根据操作ID获取操作详情
     *
     * @param operationId
     * @return
     */
    public Response counterOperationField(String operationId) {
        List<CounterOperationFields> fields = counterOperationFieldsMapper.selectList(Wrappers.<CounterOperationFields>lambdaQuery()
                .eq(CounterOperationFields::getOperationId, operationId));
        return Response.success(ObjectUtils.toList(fields, CounterOperationFieldsVo.class));
    }
}
