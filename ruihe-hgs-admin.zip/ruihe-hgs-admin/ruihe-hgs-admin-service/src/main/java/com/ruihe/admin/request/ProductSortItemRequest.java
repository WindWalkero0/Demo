package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-05 13:52
 */
@ApiModel(value = "ProductSortItemRequest", description = "产品分类信息查询请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductSortItemRequest implements Serializable {

    @ApiModelProperty(value = "产品分类主表主键")
    private Integer code;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
