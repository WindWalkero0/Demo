package com.ruihe.admin.service.activity;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.admin.mapper.order.PosOrderItemMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Service
@Repository
@Slf4j
public class PosOrderItemService extends ServiceImpl<PosOrderItemMapper, PosOrderItemPo> {


}
