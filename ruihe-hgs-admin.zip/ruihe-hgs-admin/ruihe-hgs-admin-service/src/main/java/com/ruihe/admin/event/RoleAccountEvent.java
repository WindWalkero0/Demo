package com.ruihe.admin.event;


import com.ruihe.common.annotation.Ella;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

@Ella(Describe = "用户权限查询")
@Data
@EqualsAndHashCode(callSuper = false)
public class RoleAccountEvent extends ApplicationEvent {

    //用户id
    private String userId;

    public RoleAccountEvent(Object source, String userId) {
        super(source);
        this.userId = userId;
    }

}
