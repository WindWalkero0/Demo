package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.report.core.Column;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.admin.request.bi.PosBaVisitReportRequest;
import com.ruihe.admin.request.bi.PosBaVisitSelectRequest;

import java.util.List;

/**
 * 柜台进销存报表
 *
 * @author Administrator
 */
public class PosBaVisitDefine extends TableDefine {
    Column areaCode = new Column(
            "大区编号",
            false,
            "org_area_id",
            "IFNULL(NULLIF({alias}org_area_id, ''),'直属') org_area_id",
            "org_area_id");
    Column areaName = new Column(
            "大区",
            "org_area_name",
            "IFNULL(NULLIF({alias}org_area_name, ''),'直属') org_area_name",
            "org_area_id");

    Column officeCode = new Column(
            "办事处编号",
            false,
            "org_office_id",
            "IFNULL(NULLIF({alias}org_office_id, ''),'直属') org_office_id",
            "org_office_id");
    Column officeName = new Column(
            "办事处",
            "org_office_name",
            "IFNULL(NULLIF({alias}org_office_name, ''),'直属') org_office_name",
            "org_office_id");

    Column principalCode = new Column(
            "柜台主管编号", false,
            "org_master_id",
            "IFNULL(NULLIF({alias}org_master_id, ''),'直属') org_master_id",
            "org_master_id");
    Column principalName = new Column(
            "柜台主管",
            "org_master_name",
            "IFNULL(NULLIF({alias}org_master_name, ''),'直属') org_master_name",
            "org_master_id");

    Column counterId = new Column(
            "柜台号",
            "counter_id",
            "{alias}counter_id",
            "{alias}counter_id");
    Column counterName = new Column(
            "柜台名称",
            "counter_name",
            "{alias}counter_name",
            "{alias}counter_name");
    Column baCode = new Column(
            "BA编号",
            "ba_code",
            "{alias}ba_code",
            "{alias}ba_code");
    Column baName = new Column(
            "BA姓名",
            "ba_name",
            "{alias}ba_name",
            "{alias}ba_code");

    public static TableDefine create(PosBaVisitReportRequest request) {
        PosBaVisitSelectRequest selectRequest = request.getSelectRequest();
        PosBaVisitDefine define = new PosBaVisitDefine();
        define.addHorizontalColumns(selectRequest);
        define.addValueColumns(selectRequest);
        define.setStartTime(request.getStartTime());
        define.setEndTime(request.getEndTime());
        define.setTotalFlag(TableDefine.TOTAL_ROW);
        return define;
    }

    /**
     * 添加查询字段，不包括统计数值字段
     */
    private void addHorizontalColumns(PosBaVisitSelectRequest req) {
        this.addHorizontalColumn(areaCode, req.isArea());
        this.addHorizontalColumn(areaName, req.isArea());
        this.addHorizontalColumn(officeCode, req.isOffice());
        this.addHorizontalColumn(officeName, req.isOffice());
        this.addHorizontalColumn(principalCode, req.isPrincipal());
        this.addHorizontalColumn(principalName, req.isPrincipal());
        this.addHorizontalColumn(counterId.pa(), req.isCounterId());
        this.addHorizontalColumn(counterName.pa(), req.isCounterName());
        this.addHorizontalColumn(baCode.pa().show(req.isBaCode()), req.isBaCode() || req.isBaName());
        this.addHorizontalColumn(baName.pa(), req.isBaName());
    }

    /**
     * 添加统计数值字段
     */
    private void addValueColumns(PosBaVisitSelectRequest req) {
        List<String> visitTypes = req.getVisitType();
        for (String visitType : visitTypes) {
            this.addValueColumn(new Column(visitType, visitType, Integer.class), true);
        }
    }
}
