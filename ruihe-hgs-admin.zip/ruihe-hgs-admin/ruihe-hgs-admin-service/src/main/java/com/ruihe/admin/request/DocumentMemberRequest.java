package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-30 15:40
 */
@ApiModel(value = "DocumentMemberRequest", description = "erp模块根据会员卡号、姓名、手机号查询请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class DocumentMemberRequest implements Serializable {

    @ApiModelProperty("会员卡号")
    private String memberCardNumber;

    @ApiModelProperty("会员姓名")
    private String memberName;

    @ApiModelProperty("手机号")
    private String mobilePhone;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
