package com.ruihe.admin.service.erp.document;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.mapper.erp.document.*;
import com.ruihe.admin.request.ExportExcelRequest;
import com.ruihe.admin.service.bi.AbstractBiReportPreHandler;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.warehouse.*;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.admin.enums.BiReportEnum;
import com.ruihe.admin.event.WhReturnApplyExcelEvent;
import com.ruihe.admin.event.WhReturnApplyItemExcelEvent;
import com.ruihe.admin.event.WhReturnItemExcelEvent;
import com.ruihe.admin.mapper.basic.CounterMapper;
import com.ruihe.admin.mapper.basic.ProductMapper;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.request.erp.WhReturnApplyRequest;
import com.ruihe.admin.request.erp.WhReturnRequest;
import com.ruihe.admin.response.erp.WhReturnApplyResponse;
import com.ruihe.admin.response.erp.WhReturnResponse;
import com.ruihe.admin.response.erp.WhReturnResultResponse;
import com.ruihe.admin.vo.WhReturnItemVo;
import com.ruihe.admin.vo.WhReturnVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author 梁远
 * @Description
 * @create 2020-03-05 9:38
 */
@Service
@Slf4j
public class WhReturnService extends AbstractBiReportPreHandler {

    @Autowired
    private WhReturnMapper whReturnMapper;

    @Autowired
    private WhReturnItemMapepr whReturnItemMapepr;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private WhAuditMapper whAuditMapper;

    @Autowired
    private WhReturnLogMapper whReturnLogMapper;

    @Autowired
    private WhReturnItemLogMapepr whReturnItemLogMapepr;

    @Autowired
    private CounterMapper counterMapper;
    /**
     * 存储域
     */
    private static final String KEY = "ADMIN:RETURN";

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    /**
     * 退库申请单查询列表
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response applyList(WhReturnApplyRequest request) {
        //对日期和页码进行判断
        if (request.getStartTime() != null && request.getEndTime() != null && request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("开始时间不能大于结束时间!");
        }
        if (request.getPageNumber() == null || request.getPageSize() == null || request.getPageSize() == 0 || request.getPageNumber() == 0) {
            return Response.errorMsg("页码不合法!");
        }
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        //获取组织条件查询
        OrgQueryConditionRequest queryRequest = request.getOrgQueryConditionRequest();
        //柜台的状态、类型跟部门的不一致，此处需要转换
        if (queryRequest != null && queryRequest.getOrgType() != null) {
            queryRequest.setOrgType(queryRequest.getOrgType().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CounterEnum.FORMAL_COUNTER.getKey() : CounterEnum.TEST_COUNTER.getKey());
        }
        if (queryRequest != null && queryRequest.getOrgStatus() != null) {
            queryRequest.setOrgStatus(queryRequest.getOrgStatus().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CommonStatusEnum.INVALID.getCode() : CommonStatusEnum.EFFECTIVE.getCode());
        }
        //设置分页条件
        Page<WhReturnApplyResponse> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询出列表
        IPage<WhReturnApplyResponse> whFreeInventoryVoIPage = whReturnMapper.applyList(page, request, queryRequest);
        //查询出总数和金额
        WhReturnResultResponse whReturnResultResponse = whReturnMapper.applyResult(request, queryRequest);
        if (!whFreeInventoryVoIPage.getRecords().isEmpty()) {
            whFreeInventoryVoIPage.getRecords().forEach(e ->
                    e.setApplyTime(e.getCreateTime().toLocalDate()));
        }
        String uuid = IdGenerator.getRandomId(KEY, 6);
        //存储redis
        request.setOrgQueryConditionRequest(queryRequest);
        redisTemplate.opsForValue().set(uuid, request, 1, TimeUnit.HOURS);
        //分页展示vo
        PageVO pageVO = PageVO.<WhReturnApplyResponse>builder()
                .list(whFreeInventoryVoIPage.getRecords())
                .pageNum(whFreeInventoryVoIPage.getCurrent())
                .pageSize(whFreeInventoryVoIPage.getSize())
                .pages(whFreeInventoryVoIPage.getPages())
                .total(whFreeInventoryVoIPage.getTotal())
                .build();
        //返回结果
        return Response.success(WhReturnResponse.builder()
                .whReturnResultResponse(whReturnResultResponse)
                .key(uuid)
                .pageVo(pageVO).build());
    }

    /**
     * 根据单号查询退库申请单详情
     *
     * @param returnNo
     * @return
     */
    public Response applyItem(String returnNo) {
        //根据申请单号查询主表信息
        WhReturnPo whReturnPo = whReturnMapper.selectOne(Wrappers.<WhReturnPo>lambdaQuery().eq(WhReturnPo::getReturnNo, returnNo));
        if (whReturnPo == null) {
            return Response.errorMsg("查询失败，请刷新后重试!");
        }
        //转换主表信息
        WhReturnApplyResponse whReturnApplyResponse = this.extractWhReturnApplyItemResponse(whReturnPo);
        //根据单号查询详情
        List<WhReturnItemPo> itemPoList = whReturnItemMapepr.selectList(Wrappers.<WhReturnItemPo>lambdaQuery()
                .eq(WhReturnItemPo::getReturnNo, returnNo));
        if (itemPoList.isEmpty()) {
            return Response.errorMsg("查询失败，请刷新后重试!");
        }
        //设置产品信息
        List<WhReturnItemVo> voList = itemPoList.stream().map(e -> {
            WhReturnItemVo whReturnItemVo = new WhReturnItemVo();
            BeanUtils.copyProperties(e, whReturnItemVo);
            //根据产品条码查询产品规格和单位信息
            Product product = productMapper.selectOne(Wrappers.<Product>lambdaQuery().eq(Product::getPrdBarCode, e.getPrdBarCode()));
            whReturnItemVo.setUnitName(product.getUnitName());
            whReturnItemVo.setSpec(product.getSpec());
            return whReturnItemVo;
        }).collect(Collectors.toList());
        return Response.success(WhReturnVo.builder()
                .whReturnApplyResponse(whReturnApplyResponse)
                .voList(voList).build());
    }

    /**
     * 构建退库申请主表信息
     *
     * @param whReturnPo
     * @return
     */
    private WhReturnApplyResponse extractWhReturnApplyItemResponse(WhReturnPo whReturnPo) {
        CounterInformation counterInformation = counterMapper.selectOne(Wrappers.<CounterInformation>lambdaQuery()
                .eq(CounterInformation::getCounterId, whReturnPo.getCounterId())
                .select(CounterInformation::getOperationalModel));
        return WhReturnApplyResponse.builder()
                .applyAmt(whReturnPo.getApplyAmt())
                .applyQty(whReturnPo.getApplyQty())
                .applyTime(whReturnPo.getCreateTime().toLocalDate())
                .auditCode(whReturnPo.getAuditCode())
                .auditName(whReturnPo.getAuditName())
                .baCode(whReturnPo.getBaCode())
                .baName(whReturnPo.getBaName())
                .counterId(whReturnPo.getCounterId())
                .counterName(whReturnPo.getCounterName())
                .reason(whReturnPo.getReason())
                .status(whReturnPo.getStatus())
                .operationalModel(counterInformation.getOperationalModel())
                .returnNo(whReturnPo.getReturnNo())
                .u8OrderNo(whReturnPo.getU8OrderNo())
                .trackingNo(whReturnPo.getTrackingNo())
                .build();
    }

    /**
     * 审核查询
     *
     * @param returnNo
     * @return
     */
    public Response returnAudit(String returnNo) {
        List<WhAuditPo> auditPoList = whAuditMapper.selectList(Wrappers.<WhAuditPo>lambdaQuery()
                .eq(WhAuditPo::getApplyNo, returnNo)
                //审核单号非空
                .isNotNull(WhAuditPo::getAuditNo)
                //根据id升序排序
                .orderByAsc(WhAuditPo::getId));
        return Response.success(auditPoList);
    }

    /**
     * 退库单查询
     *
     * @param request
     * @return
     */
    public Response returnList(WhReturnRequest request) {
        //对日期和页码进行判断
        if (request.getStartTime() != null && request.getEndTime() != null && request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("开始时间不能大于结束时间!");
        }
        if (request.getPageNumber() == null || request.getPageSize() == null || request.getPageSize() == 0 || request.getPageNumber() == 0) {
            return Response.errorMsg("页码不合法!");
        }
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        //获取组织条件查询
        OrgQueryConditionRequest queryRequest = request.getOrgQueryConditionRequest();
        //柜台的状态、类型跟部门的不一致，此处需要转换
        if (queryRequest != null && queryRequest.getOrgType() != null) {
            queryRequest.setOrgType(queryRequest.getOrgType().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CounterEnum.FORMAL_COUNTER.getKey() : CounterEnum.TEST_COUNTER.getKey());
        }
        if (queryRequest != null && queryRequest.getOrgStatus() != null) {
            queryRequest.setOrgStatus(queryRequest.getOrgStatus().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CommonStatusEnum.INVALID.getCode() : CommonStatusEnum.EFFECTIVE.getCode());
        }
        //设置分页条件
        Page<WhReturnApplyResponse> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询出列表
        IPage<WhReturnApplyResponse> whFreeInventoryVoIPage = whReturnMapper.returnList(page, request, queryRequest);
        //查询出总数和金额
        WhReturnResultResponse whReturnResultResponse = whReturnMapper.returnResult(request, queryRequest);
        if (!whFreeInventoryVoIPage.getRecords().isEmpty()) {
            whFreeInventoryVoIPage.getRecords().forEach(e ->
                    e.setApplyTime(e.getCreateTime().toLocalDate()));
        }
        String uuid = IdGenerator.getRandomId(KEY, 6);
        //存储redis
        request.setOrgQueryConditionRequest(queryRequest);
        redisTemplate.opsForValue().set(uuid, request, 1, TimeUnit.HOURS);
        //分页展示vo
        PageVO pageVO = PageVO.<WhReturnApplyResponse>builder()
                .list(whFreeInventoryVoIPage.getRecords())
                .pageNum(whFreeInventoryVoIPage.getCurrent())
                .pageSize(whFreeInventoryVoIPage.getSize())
                .pages(whFreeInventoryVoIPage.getPages())
                .total(whFreeInventoryVoIPage.getTotal())
                .build();
        //返回结果
        return Response.success(WhReturnResponse.builder()
                .whReturnResultResponse(whReturnResultResponse)
                .key(uuid)
                .pageVo(pageVO).build());
    }

    /**
     * 退库单详情
     *
     * @param confirmReturnNo
     * @return
     */
    public Response returnItem(String confirmReturnNo) {
        //根据单号查主表
        WhReturnLogPo whReturnLogPo = whReturnLogMapper.selectOne(Wrappers.<WhReturnLogPo>lambdaQuery().eq(WhReturnLogPo::getReturnNo, confirmReturnNo));
        if (whReturnLogPo == null) {
            return Response.errorMsg("查询失败，请刷新后重试!");
        }
        //将主表信息转换
        WhReturnApplyResponse whReturnApplyResponse = this.extractWhReturnResponse(whReturnLogPo);
        //设置产品信息
        List<WhReturnItemVo> voList = this.extractWhReturnItemVo(whReturnLogPo);
        //返回前端
        return Response.success(WhReturnVo.builder()
                .whReturnApplyResponse(whReturnApplyResponse)
                .voList(voList).build());
    }

    /**
     * 根据确认单号查询详情
     *
     * @param whReturnLogPo
     * @return
     */
    private WhReturnApplyResponse extractWhReturnResponse(WhReturnLogPo whReturnLogPo) {
        //根据id查询柜台，获取柜台的类型
        CounterInformation counterInformation = counterMapper.selectOne(Wrappers.<CounterInformation>lambdaQuery()
                .eq(CounterInformation::getCounterId, whReturnLogPo.getCounterId())
                .select(CounterInformation::getOperationalModel));
        //根据关联单号查询log表，用于获取申请单号
        WhReturnLogPo logPo = whReturnLogMapper.selectOne(Wrappers.<WhReturnLogPo>lambdaQuery()
                .eq(WhReturnLogPo::getReturnNo, whReturnLogPo.getAssociatedNo())
                .select(WhReturnLogPo::getAssociatedNo));
        //返回信息
        return WhReturnApplyResponse.builder()
                .applyAmt(whReturnLogPo.getConfirmAmt())
                .applyQty(whReturnLogPo.getConfirmQty())
                .applyTime(whReturnLogPo.getCreateTime().toLocalDate())
                .auditCode(whReturnLogPo.getAuditId())
                .auditName(whReturnLogPo.getAuditName())
                .baCode(whReturnLogPo.getBaCode())
                .baName(whReturnLogPo.getBaName())
                .counterId(whReturnLogPo.getCounterId())
                .counterName(whReturnLogPo.getCounterName())
                .reason(whReturnLogPo.getReason())
                .status(whReturnLogPo.getStatus())
                .operationalModel(counterInformation.getOperationalModel())
                //单号是SAP审核单号的关联单号
                .returnNo(logPo.getAssociatedNo())
                .u8OrderNo(whReturnLogPo.getAssociatedNo())
                .confirmReturnNo(whReturnLogPo.getReturnNo())
                .build();
    }

    /**
     * 根据SAP确认单号查询信息
     *
     * @param u8OrderNo
     * @return
     */
    public Response querySapItem(String u8OrderNo) {
        WhReturnLogPo whReturnLogPo = whReturnLogMapper.selectOne(Wrappers.<WhReturnLogPo>lambdaQuery().eq(WhReturnLogPo::getReturnNo, u8OrderNo));
        if (whReturnLogPo == null) {
            return Response.errorMsg("查询失败，请刷新后重试!");
        }
        WhReturnApplyResponse whReturnApplyResponse = this.extractWhReturnApplyResponse(whReturnLogPo);
        //设置产品信息
        List<WhReturnItemVo> voList = this.extractWhReturnItemVo(whReturnLogPo);
        return Response.success(WhReturnVo.builder()
                .whReturnApplyResponse(whReturnApplyResponse)
                .voList(voList).build());
    }

    /**
     * 构建sap确认单号查询的子表详情
     *
     * @param whReturnLogPo
     * @return
     */
    private WhReturnApplyResponse extractWhReturnApplyResponse(WhReturnLogPo whReturnLogPo) {
        CounterInformation counterInformation = counterMapper.selectOne(Wrappers.<CounterInformation>lambdaQuery()
                .eq(CounterInformation::getCounterId, whReturnLogPo.getCounterId())
                .select(CounterInformation::getOperationalModel));
        return WhReturnApplyResponse.builder()
                .applyAmt(whReturnLogPo.getConfirmAmt())
                .applyQty(whReturnLogPo.getConfirmQty())
                .applyTime(whReturnLogPo.getCreateTime().toLocalDate())
                .auditCode(whReturnLogPo.getAuditId())
                .auditName(whReturnLogPo.getAuditName())
                .baCode(whReturnLogPo.getBaCode())
                .baName(whReturnLogPo.getBaName())
                .counterId(whReturnLogPo.getCounterId())
                .counterName(whReturnLogPo.getCounterName())
                .reason(whReturnLogPo.getReason())
                .status(whReturnLogPo.getStatus())
                .operationalModel(counterInformation.getOperationalModel())
                .returnNo(whReturnLogPo.getAssociatedNo())
                .u8OrderNo(whReturnLogPo.getReturnNo())
                .build();
    }

    /**
     * 构建退库log子表返回
     *
     * @param whReturnLogPo
     * @return
     */
    private List<WhReturnItemVo> extractWhReturnItemVo(WhReturnLogPo whReturnLogPo) {
        //根据单号查询详情
        List<WhReturnItemLogPo> itemPoList = whReturnItemLogMapepr.selectList(Wrappers.<WhReturnItemLogPo>lambdaQuery()
                .eq(WhReturnItemLogPo::getReturnNo, whReturnLogPo.getReturnNo()));
        if (!itemPoList.isEmpty()) {
            return itemPoList.stream().map(e -> {
                WhReturnItemVo whReturnItemVo = new WhReturnItemVo();
                BeanUtils.copyProperties(e, whReturnItemVo);
                whReturnItemVo.setApplyAmt(e.getRealAmt());
                whReturnItemVo.setApplyQty(e.getRealQty());
                //根据产品条码查询产品规格和单位信息
                Product product = productMapper.selectOne(Wrappers.<Product>lambdaQuery().eq(Product::getPrdBarCode, e.getPrdBarCode()));
                whReturnItemVo.setUnitName(product.getUnitName());
                whReturnItemVo.setSpec(product.getSpec());
                return whReturnItemVo;
            }).collect(Collectors.toList());
        } else {
            log.info("查询子表数据为空!,whReturnLogPo={}", whReturnLogPo);
            return new ArrayList<>();
        }
    }

    public Response applyExcel(ExportExcelRequest exportExcelRequest) {
        try {
            //根据条件查询数据
            WhReturnApplyRequest whReturnApplyRequest = (WhReturnApplyRequest) redisTemplate.opsForValue().get(exportExcelRequest.getKey());
            //判空
            if (whReturnApplyRequest == null) {
                return Response.error("查询条件不存在请重试！");
            }
            Long aLong = whReturnMapper.applyCountExcel(whReturnApplyRequest, whReturnApplyRequest.getOrgQueryConditionRequest());
            if (aLong > 50000) {
                return Response.error("只支持5w条导出");
            }
            WhReturnApplyExcelEvent event = WhReturnApplyExcelEvent.builder().key(exportExcelRequest.getKey()).build();
            publishEvent(BiReportEnum.WH_RETURN_APPLY, event, exportExcelRequest.getRemark(), exportExcelRequest.getPicUrl());
            return Response.successMsg("提交成功，请至下载中心下载");
        } catch (Exception e) {
            log.error("退库申请单导出异常,request={}", exportExcelRequest, e);
        }
        return null;
    }

    public Response applyItemExcel(ExportExcelRequest exportExcelRequest) {
        try {
            //根据条件查询数据
            WhReturnApplyRequest whReturnApplyRequest = (WhReturnApplyRequest) redisTemplate.opsForValue().get(exportExcelRequest.getKey());
            //判空
            if (whReturnApplyRequest == null) {
                return Response.error("查询条件不存在请重试！");
            }
            Long aLong = whReturnMapper.applyItemCountExcel(whReturnApplyRequest, whReturnApplyRequest.getOrgQueryConditionRequest());
            if (aLong > 50000) {
                return Response.error("只支持5w条导出");
            }
            WhReturnApplyItemExcelEvent event = WhReturnApplyItemExcelEvent.builder().key(exportExcelRequest.getKey()).build();
            publishEvent(BiReportEnum.WH_RETURN_APPLY_ITEM, event, exportExcelRequest.getRemark(), exportExcelRequest.getPicUrl());
            return Response.successMsg("提交成功，请至下载中心下载");
        } catch (Exception e) {
            log.error("退库申请单明细导出异常,request={}", exportExcelRequest, e);
        }
        return null;
    }

    public Response itemExcel(ExportExcelRequest exportExcelRequest) {
        try {
            //根据条件查询数据
            WhReturnRequest whReturnRequest = (WhReturnRequest) redisTemplate.opsForValue().get(exportExcelRequest.getKey());
            //判空
            if (whReturnRequest == null) {
                return Response.error("查询条件不存在请重试！");
            }
            Long aLong = whReturnMapper.returnItemCountExcel(whReturnRequest, whReturnRequest.getOrgQueryConditionRequest());
            if (aLong > 50000) {
                return Response.error("只支持5w条导出");
            }
            WhReturnItemExcelEvent event = WhReturnItemExcelEvent.builder().key(exportExcelRequest.getKey()).build();
            publishEvent(BiReportEnum.WH_RETURN_DETAIL, event, exportExcelRequest.getRemark(), exportExcelRequest.getPicUrl());
            return Response.successMsg("提交成功，请至下载中心下载");
        } catch (Exception e) {
            log.error("退库单导出异常，request={}", exportExcelRequest, e);
        }
        return null;
    }
}
