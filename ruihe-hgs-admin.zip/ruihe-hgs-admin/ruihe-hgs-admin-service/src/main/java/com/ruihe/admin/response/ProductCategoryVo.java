package com.ruihe.admin.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
@ApiModel("产品分类")
public class ProductCategoryVo {
    @ApiModelProperty(value = "Id")
    private Integer id;

    @ApiModelProperty(value = "分类名称")
    private String name;

    @ApiModelProperty(value = "分类层级")
    private int level;

    @ApiModelProperty(value = "父级层级Id")
    private Integer parentId;

    @ApiModelProperty(value = "排序")
    private int sort;

    @ApiModelProperty(value = "是否有效， 0无效，1有效")
    private int deleted;

    @ApiModelProperty(value = "子类别")
    private List<ProductCategoryVo> children;
}
