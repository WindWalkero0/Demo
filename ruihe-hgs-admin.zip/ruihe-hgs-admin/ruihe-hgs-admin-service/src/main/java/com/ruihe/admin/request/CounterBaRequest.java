package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-01 14:49
 */
@ApiModel(value = "CounterBaRequest", description = "会员转柜查询ba请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class CounterBaRequest implements Serializable {

    @ApiModelProperty(value = "柜台代码")
    private String counterId;

    @ApiModelProperty(value = "模糊查询")
    private String codeName;

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
