package com.ruihe.admin.listener;

import com.ruihe.admin.event.SendRabbitMsgEvent;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.dao.bean.wx.WxCardMenuPo;
import com.ruihe.common.dao.mapper.WxCardMenuMapper;
import com.ruihe.common.enums.rabbit.ListenerServiceEnum;
import com.ruihe.common.service.rabbitmq.CustomMessage;
import com.ruihe.common.service.rabbitmq.RabbitmqClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

/**
 * 定时检查微信会员卡菜单rabbit发送事件的时间
 *
 * @author LiangYuan
 * @date 2021-03-22 16:05
 */
@Slf4j
@Component
public class SendRabbitMsgListener {

    @Autowired
    private RabbitmqClient rabbitmqClient;

    @Autowired
    private WxCardMenuMapper wxCardMenuMapper;

    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(SendRabbitMsgEvent event) {
        try {
            LocalDateTime startTime = LocalDateTime.of(LocalDate.now(), LocalTime.MIN);
            LocalDateTime endTime = startTime.plusDays(1);
            //查询微信会员卡菜单信息
            List<WxCardMenuPo> wxCardMenuPoList = wxCardMenuMapper.selectWxCardMenuList(startTime, endTime);
            if (wxCardMenuPoList.isEmpty()) {
                return;
            }
            for (WxCardMenuPo wxCardMenuPo : wxCardMenuPoList) {
                //开始时间处在区间内
                if (wxCardMenuPo.getStartTime().compareTo(startTime) > 0 && wxCardMenuPo.getStartTime().compareTo(endTime) <= 0) {
                    Duration between = Duration.between(LocalDateTime.now(), wxCardMenuPo.getStartTime());
                    CustomMessage cm = CustomMessage.builder()
                            .serviceName(ListenerServiceEnum.WX_CARD_MENU_SHOW_CONTROLL.getName())
                            .bizNo(wxCardMenuPo.getMenuId())
                            .build();
                    rabbitmqClient.produce(cm, (int) between.toMillis());
                }
                //结束时间在时间范围内的，同时排除开始结束时间在同一天的情况(由监听处理)
                if (wxCardMenuPo.getEndTime().compareTo(startTime) > 0 && wxCardMenuPo.getEndTime().compareTo(endTime) <= 0 && !wxCardMenuPo.getEndTime().toLocalDate().equals(wxCardMenuPo.getStartTime().toLocalDate())) {
                    Duration between = Duration.between(LocalDateTime.now(), wxCardMenuPo.getEndTime());
                    CustomMessage cm = CustomMessage.builder()
                            .serviceName(ListenerServiceEnum.WX_CARD_MENU_SHOW_CONTROLL.getName())
                            .bizNo(wxCardMenuPo.getMenuId())
                            .build();
                    rabbitmqClient.produce(cm, (int) between.toMillis());
                }
            }
        } catch (Exception e) {
            log.error("定时检查rabbit发送事件的时间.error={},event={}", e, event);
        }
    }
}
