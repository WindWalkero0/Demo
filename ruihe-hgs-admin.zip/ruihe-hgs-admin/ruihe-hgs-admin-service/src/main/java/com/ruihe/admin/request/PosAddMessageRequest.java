package com.ruihe.admin.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruihe.common.dao.bean.terminal.MessagePlaceInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Future;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/3 16:55
 */
@ApiModel(value = "PosAddMessageRequest", description = "消息新增")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosAddMessageRequest implements Serializable {


    @ApiModelProperty(value = "消息序号")
    @NotNull(message="消息序号传参不能为空")
    @Min(value = 1,message = "消息序号最小值为1")
    private Integer seq;

    @ApiModelProperty(value = "消息标题")
    @Size(max = 40,message = "消息标题最大长度为40个字符")
    private String title;

    @ApiModelProperty(value = "正文")
    private String content;

    @ApiModelProperty(value = "消息有效期开始时间")
    @Future(message = "消息有效期开始时间必须是将来时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @NotNull
    private LocalDateTime sendTime;

    @ApiModelProperty(value = "消息有效期结束时间")
    @Future(message = "消息有效期结束时间必须是将来时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @NotNull
    private LocalDateTime endTime;

    @ApiModelProperty(value = "消息接收地点")
    private List<MessagePlaceInfo> activityPlaceList;

    @ApiModelProperty(value = "组织机构回显字段")
    private String showDescription;
}
