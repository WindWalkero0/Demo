package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-05 14:01
 */
@ApiModel(value = "FuzzyQueryProductRequest", description = "模糊查询产品信息请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FuzzyQueryProductRequest implements Serializable {

    @NotBlank(message = "产品信息不能为空")
    @ApiModelProperty(value = "模糊查询条件：产品名称或者商品/产品条码")
    private String prd;

    @ApiModelProperty(value = "每页显示数量")
    @Builder.Default
    private Integer pageSize = 10;

    @ApiModelProperty(value = "页码")
    @Builder.Default
    private Integer pageNumber = 1;
}
