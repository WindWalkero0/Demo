package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.ReportMemberSalesFactorEvent;
import com.ruihe.admin.listener.report.core.ReportController;
import com.ruihe.admin.listener.report.core.TotalQuery;
import com.ruihe.admin.mapper.bi.MemberReportMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.response.bi.MemberSalesResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.List;

/***
 * 会员销售要素统计报表
 * @author lrc
 */
@Component
@RequiredArgsConstructor
public class MemberSalesFactorReportListener extends AbstractReportListener<ReportMemberSalesFactorEvent> {
    private final MemberReportMapper memberReportMapper;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_REPORT)
    @EventListener
    public void onApplicationEvent(ReportMemberSalesFactorEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    public void doExport(ReportMemberSalesFactorEvent event, BiReportPo report, boolean flag) {
        MemberSalesFactorDefine define = MemberSalesFactorDefine.create(event.getRequest());

        ReportController controller = new ReportController(define);
        controller.name("会员销售要素统计报表");
        controller.savePath(report.getFilePath());

        //1、查询基础数据
        List<MemberSalesResponse> base = memberReportMapper.memberSalesFactor4BaseData(
                null,
                event.getRequest(),
                null,
                define.selectCols("a."),
                define.groupCols("a."),
                event.getReport().getUid(),
                flag);
        controller.fillData(base);

        //2、销售天数
        List<MemberSalesResponse> saleDays = memberReportMapper.memberSalesFactor4SaleDays(
                null,
                event.getRequest(),
                null,
                define.selectCols("a."),
                define.groupCols("a."),
                define.selectCols("t."),
                define.groupCols("t."),
                event.getReport().getUid(),
                flag);
        controller.fillData(saleDays);

        //3、经营新会员数据
        List<MemberSalesResponse> optNewData = memberReportMapper.memberSalesFactor4OptNew(
                null,
                event.getRequest(),
                null,
                define.selectCols("o."),
                define.groupCols("o."),
                event.getReport().getUid(),
                flag);
        controller.fillData(optNewData);

        //4、会员入会数量
        List<MemberSalesResponse> mjData = memberReportMapper.memberSalesFactor4Mj(
                null,
                event.getRequest(),
                null,
                define.selectCols("c.")
                        .replace("c.org_area_code", "c.org_area_id")
                        .replace("c.org_office_code", "c.org_office_id")
                        .replace("c.org_principal_code", "c.org_master_id")
                        .replace("c.org_principal_name", "c.org_master_name")
                        .replace("c.ba_code", "m.ba_id as ba_code")
                        .replace("c.ba_name", "m.ba_name"),
                define.groupCols("c.").replace("c.ba_code", "ba_code"),
                event.getReport().getUid(),
                flag);
        controller.fillData(mjData);

        controller.totalCalculate();

        //基础数据小计总计
        controller.fillTotal(new TotalQuery() {
            @Override
            public List<?> doQuery(String select, String group, int dayOrMonth) {
                return memberReportMapper.memberSalesFactor4BaseData(
                        null,
                        event.getRequest(),
                        null,
                        select,
                        group,
                        event.getReport().getUid(),
                        flag);
            }

            @Override
            public String alias() {
                return "a.";
            }
        });

        //经营新会员小计总计
        controller.fillTotal(new TotalQuery() {
            @Override
            public List<?> doQuery(String select, String group, int dayOrMonth) {
                return memberReportMapper.memberSalesFactor4OptNew(
                        null,
                        event.getRequest(),
                        null,
                        select,
                        group,
                        event.getReport().getUid(),
                        flag);
            }

            @Override
            public String alias() {
                return "o.";
            }
        });

        //会员入会数量小计总计
        controller.fillTotal(new TotalQuery() {
            @Override
            public List<?> doQuery(String select, String group, int dayOrMonth) {
                return memberReportMapper.memberSalesFactor4Mj(
                        null,
                        event.getRequest(),
                        null,
                        select.replace("c.org_area_code", "c.org_area_id")
                                .replace("c.org_office_code", "c.org_office_id")
                                .replace("c.org_principal_code", "c.org_master_id")
                                .replace("c.org_principal_name", "c.org_master_name")
                                .replace("c.ba_code", "m.ba_id as ba_code")
                                .replace("c.ba_name", "m.ba_name"),
                        group.replace("c.ba_code", "ba_code"),
                        event.getReport().getUid(),
                        flag);
            }

            @Override
            public String alias() {
                return "c.";
            }
        });

        controller.write(this.imgPath, report.getPicUrl());
    }
}
