package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-01 14:35
 */
@ApiModel(value = "CommonEmpRequest", description = "通用员工模糊查询请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class CommonEmpRequest implements Serializable {

    @ApiModelProperty(value = "员工代码/员工名称模糊查询条件")
    private String emp;

    @ApiModelProperty(value = "状态---默认查全部，0无效，1有效")
    private Integer status;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
