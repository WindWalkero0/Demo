package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @author ly
 * @Description 校验会员寄存日志汇总与寄存箱库存是否一致
 */

@Data
@EqualsAndHashCode(callSuper = false)
public class CheckDepositEvent {
    private List<Integer> list;

    @Builder
    public CheckDepositEvent(List<Integer> list) {
        this.list = list;
    }
}
