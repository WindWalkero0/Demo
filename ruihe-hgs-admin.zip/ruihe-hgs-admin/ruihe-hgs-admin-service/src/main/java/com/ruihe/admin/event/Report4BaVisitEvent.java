package com.ruihe.admin.event;

import com.ruihe.admin.request.bi.PosBaVisitReportRequest;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 服务记录
 * @author fly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class Report4BaVisitEvent extends BiReportEvent {

    private PosBaVisitReportRequest request;

    @Builder
    public Report4BaVisitEvent(PosBaVisitReportRequest request) {
        this.request = request;
    }
}
