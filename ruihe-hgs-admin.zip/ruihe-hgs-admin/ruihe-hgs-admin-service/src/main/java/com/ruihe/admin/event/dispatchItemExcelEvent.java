package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 发货单明细查询
 * @author fly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class dispatchItemExcelEvent extends BiReportEvent {

    private String key;

    @Builder
    public dispatchItemExcelEvent(String key) {
        this.key = key;
    }
}
