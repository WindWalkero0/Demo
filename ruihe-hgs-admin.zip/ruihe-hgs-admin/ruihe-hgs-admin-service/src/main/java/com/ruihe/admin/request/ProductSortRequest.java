package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-05 14:01
 */
@ApiModel(value = "ProductSortRequest", description = "产品分类信息新增请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductSortRequest implements Serializable {

    @ApiModelProperty(value = "分类id，新增的时候不需要填写")
    private Integer sortId;

    @ApiModelProperty("属性代码")
    @Size(max = 20,message = "属性代码最大长度为20个字符")
    private String sortCode;

    @ApiModelProperty(value = "分类名称")
    @Size(max = 20,message = "分类名称最大长度为20个字符")
    private String sortName;

    @ApiModelProperty(value = "分类元数据代码")
    private Integer metaCode;

    @ApiModelProperty(value = "分类元数据名称")
    private String metaName;

}
