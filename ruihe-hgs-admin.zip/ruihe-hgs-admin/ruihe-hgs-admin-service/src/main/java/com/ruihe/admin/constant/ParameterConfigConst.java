package com.ruihe.admin.constant;

/**
 * fa配置参数表key的常量
 *
 * @author William
 */
public class ParameterConfigConst {
    /**
     * app版本升级配置
     **/
    public static final String APP_UPGRADE_CONF = "APP_UPGRADE_CONF";
}
