package com.ruihe.admin.listener;


import com.ruihe.common.service.AdminTaskService;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.CheckDepositEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * @author ly
 * @Description 校验会员寄存日志汇总与寄存箱库存是否一致
 */

@Slf4j
@Component
public class CheckDepositListener {

    @Autowired
    private AdminTaskService adminTaskService;

    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(CheckDepositEvent event) {
        try {
            adminTaskService.checkDeposit(event.getList());
        } catch (Exception e) {
            log.error("校验会员寄存日志汇总与寄存箱库存是否一致.error", e);
        }
    }

}
