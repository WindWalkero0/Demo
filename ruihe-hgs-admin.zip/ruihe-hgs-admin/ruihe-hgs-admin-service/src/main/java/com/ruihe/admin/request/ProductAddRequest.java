package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-05 14:29
 */
@ApiModel(value = "ProductAddRequest", description = "产品新增请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductAddRequest implements Serializable {

    @ApiModelProperty(value = "产品条码")
    @Size(max = 30,message = "产品条码最大长度为30个字符")
    private String prdBarCode;

    @ApiModelProperty(value = "厂商编码")
    @Size(max = 30,message = "厂商编码最大长度为30个字符")
    private String goodsBarCode;

    @ApiModelProperty(value = "品牌名称")
    private String brandName;

    @ApiModelProperty(value = "产品名称")
    @Size(max = 50,message = "产品名称最大长度为50个字符")
    private String prdName;

    @ApiModelProperty(value = "产品规格,20ml/20g")
    @Size(max = 50,message = "产品规格最大长度为50个字符")
    private String spec;

    @ApiModelProperty(value = "基本单位数量")
    private Integer unitQty;

    @ApiModelProperty(value = "基本单位名称,毫升/克/袋")
    @Size(max = 8,message = "产品规格最大长度为8个字符")
    private String unitName;

    @ApiModelProperty(value = "可否用于积分兑换：0不可以，1可以")
    private Integer exchPermit;

    @ApiModelProperty(value = "大类代码")
    private Integer bigCatCode;

    @ApiModelProperty(value = "大类名称")
    private String bigCatName;

    @ApiModelProperty(value = "中类代码")
    private Integer mediumCatCode;

    @ApiModelProperty(value = "中类名称")
    private String mediumCatName;

    @ApiModelProperty(value = "小类代码")
    private Integer smallCatCode;

    @ApiModelProperty(value = "小类名称")
    private String smallCatName;

    @NotNull
    @ApiModelProperty(value = "系列代码")
    private Integer seriesCode;

    @ApiModelProperty(value = "系列名称")
    private String seriesName;

    @ApiModelProperty(value = "小图片")
    private String smallPic;

    @ApiModelProperty(value = "大图片")
    private String bigPic;

    @ApiModelProperty(value = " 图文介绍")
    @Size(max = 21844,message = "图文介绍最大长度为21844个字符")
    private String content;

    @ApiModelProperty(value = "零售价")
    private BigDecimal salePrice;

    @ApiModelProperty(value = "会员价")
    private BigDecimal memberPrice;

    @ApiModelProperty(value = " 状态:0不启用，1启用")
    private Integer status;

    @ApiModelProperty(value = " 状态:0下架，1在售")
    private Integer saleStatus;

    @ApiModelProperty(value = "产品等级")
    private String level;

    @ApiModelProperty(value = "物料价")
    private BigDecimal materialPrice;

}
