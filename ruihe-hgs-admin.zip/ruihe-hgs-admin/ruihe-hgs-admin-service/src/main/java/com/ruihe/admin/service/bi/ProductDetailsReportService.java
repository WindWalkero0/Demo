package com.ruihe.admin.service.bi;


import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.bean.base.ChannelInfo;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.base.UserConcernPo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.admin.enums.BiReportEnum;
import com.ruihe.admin.event.ReportProductBizDetailEvent;
import com.ruihe.admin.mapper.basic.ChannelMapper;
import com.ruihe.admin.mapper.basic.ProductMapper;
import com.ruihe.admin.mapper.basic.UserConcernMapper;
import com.ruihe.admin.request.bi.ProductBizDetailReportRequest;
import com.ruihe.admin.request.bi.ProductBizDetailSelectRequest;
import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;


/**
 * BI报表产品业务明细报表分析
 *
 * @Anthor:Fangtao
 * @Date:2020/2/11 9:47
 */
@Service
@Slf4j
public class ProductDetailsReportService extends AbstractBiReportPreHandler {

    @Autowired
    private ChannelMapper channelMapper;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private UserConcernMapper userConcernMapper;

    @Autowired
    private BiReportService biReportService;


    /**
     * 产品业务明细报表分析
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    public Response productReport(ProductBizDetailReportRequest request) {
        //获取输出信息
        ProductBizDetailSelectRequest selectRequest = request.getSelectRequest();
        if (selectRequest == null) {
            return Response.errorMsg("输出信息不能为空!");
        }
        //行选择判断
        if (!isRowItemSelected(selectRequest)) {
            return Response.errorMsg("请选择行!");
        }
        if (!isStatItemSelected(selectRequest)) {
            return Response.errorMsg("请选择统计项!");
        }
        //判断时间
        if (request.getStartTime() == null || request.getEndTime() == null) {
            return Response.errorMsg("查询时间不能为空!");
        }
        if (request.getEndTime().isAfter(LocalDate.now())) {
            return Response.errorMsg("查询时间不能超过当前时间!");
        }
        if (request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("开始时间不能大于结束时间!");
        }
        if (!checkProdParam(request)) {
            return Response.errorMsg("产品维度不能同时在行列中选中!");
        }

        //判断渠道和产品是否存在
        if (StringUtils.isNotBlank(request.getChannelCode())) {
            List<ChannelInfo> channelInfoList = channelMapper.selectList(Wrappers.<ChannelInfo>lambdaQuery().eq(ChannelInfo::getChannelCode, request.getChannelCode()));
            if (channelInfoList.isEmpty()) {
                return Response.errorMsg("渠道名称有误，请核对后重试!");
            }
        }
        //产品查询
        if (StringUtils.isNotBlank(request.getPrdName())) {
            List<Product> prdList = productMapper.selectList(Wrappers.<Product>lambdaQuery().like(Product::getPrdName, request.getPrdName()));
            if (prdList.isEmpty()) {
                return Response.errorMsg("产品名称有误，请核对后重试!");
            }
        }
        if (StringUtils.isNotBlank(request.getGoodsBarCode())) {
            List<Product> prdList = productMapper.selectList(Wrappers.<Product>lambdaQuery().like(Product::getGoodsBarCode, request.getGoodsBarCode()));
            if (prdList.isEmpty()) {
                return Response.errorMsg("产品条码不存在，请核对后重试!");
            }
        }
        //获取到当前登录人的信息查询关注部门信息
        List<UserConcernPo> concernPoList = userConcernMapper.selectList(Wrappers.<UserConcernPo>lambdaQuery()
                .eq(UserConcernPo::getEmpId, AdminUserContextHolder.get().getEmpId()));
        //如果关注部门为空，则返回空
        if (concernPoList.isEmpty()) {
            return Response.errorMsg("该账号未关注任何部门，请关注后再查询!");
        }
        //查询正在导出报表的数量
        Integer count = biReportService.getBiReport();
        if (count > 2) {
            return Response.errorMsg("您已有两个报表导出任务，请稍后再导出该报表!");
        }
        //发射导出事件
        ReportProductBizDetailEvent event = ReportProductBizDetailEvent
                .builder()
                .request(request)
                .build();
        publishEvent(BiReportEnum.PRD_DETAIL_ERP, event, request.getTag(), request.getPicUrl());
        return Response.success();
    }

    /**
     * 产品维度行列维度只能选中一个
     */
    private boolean checkProdParam(ProductBizDetailReportRequest request) {
        ProductBizDetailSelectRequest select = request.getSelectRequest();
        ProductBizDetailSelectRequest.ColSelect colSelect = select.getColSelect();
        if (colSelect == null) return true;
        if ((select.isBigCat() || select.isMediumCat() || select.isSmallCat()) && (
                colSelect.isBigCat() || colSelect.isMediumCat() || colSelect.isSmallCat())) {
            return false;
        }
        if ((select.isGoodsBarCode() || select.isPrdBarCode() || select.isPrdName()) && (
                colSelect.isGoodsBarCode() || colSelect.isPrdBarCode() || colSelect.isPrdName())) {
            return false;
        }
        return true;
    }

    /**
     * 有没有选择组织结构项
     *
     * @param selectRequest
     * @return
     */
    private boolean isRowItemSelected(ProductBizDetailSelectRequest selectRequest) {
        boolean bValid = selectRequest.isArea();
        bValid = bValid || selectRequest.isBigCat();
        bValid = bValid || selectRequest.isMediumCat();
        bValid = bValid || selectRequest.isSmallCat();
        bValid = bValid || selectRequest.isPrdBarCode();
        bValid = bValid || selectRequest.isGoodsBarCode();
        bValid = bValid || selectRequest.isPrdName();
        bValid = bValid || selectRequest.isOffice();
        bValid = bValid || selectRequest.isPrincipal();
        bValid = bValid || selectRequest.isCounterId();
        bValid = bValid || selectRequest.isCounterName();
        bValid = bValid || selectRequest.isBaCode();
        bValid = bValid || selectRequest.isBaName();
        return bValid;
    }

    /**
     * 有没有选择统计项
     *
     * @param selectRequest
     * @return
     */
    private boolean isStatItemSelected(ProductBizDetailSelectRequest selectRequest) {
        boolean bValid = selectRequest.isRealAmt();
        bValid = bValid || selectRequest.isSkQty();
        bValid = bValid || selectRequest.isPrdAmt();
        return bValid;
    }
}
