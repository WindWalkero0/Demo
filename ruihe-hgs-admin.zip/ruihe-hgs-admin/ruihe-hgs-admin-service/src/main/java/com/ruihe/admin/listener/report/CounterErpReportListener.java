package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.Report4CounterErpEvent;
import com.ruihe.admin.listener.report.core.ReportController;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.admin.mapper.bi.WhReportMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.response.bi.CounterErpOtherPo;
import com.ruihe.admin.response.bi.CounterErpReportResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/***
 * 柜台进销存报表
 * @author lrc
 */
@Component
@RequiredArgsConstructor
@Deprecated
public class CounterErpReportListener extends AbstractReportListener<Report4CounterErpEvent> {

    private final WhReportMapper whReportMapper;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_REPORT)
    @EventListener
    public void onApplicationEvent(Report4CounterErpEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    public void doExport(Report4CounterErpEvent event, BiReportPo report, boolean flag) {
        TableDefine define = CounterErpDefine.create(event.getRequest());

        ReportController controller = new ReportController(define);
        controller.name("柜台进销存报表");
        controller.savePath(report.getFilePath());

        //1、查询基础数据
        //根据上一级别的组织结构查询出该级别下所有的数据
        List<CounterErpReportResponse> baseData = whReportMapper.counterErpBase(
                event.getRequest(),
                event.getReport().getUid(),
                null,
                define.selectCols("c."),
                define.groupCols("c."),
                flag);

        Map<String, CounterErpReportResponse> cache = new HashMap<>();
        baseData.forEach(d -> cache.put(d.getCounterId(), d));
        
        //2、其他数据
        List<CounterErpOtherPo> otherData = whReportMapper.counterErpOther(
                event.getRequest(),
                event.getReport().getUid(),
                null,
                define.selectCols("c."),
                define.groupCols("c."),
                flag);
        otherData.forEach(d -> {
            CounterErpReportResponse response = cache.get(d.getCounterId());
            fillResponse(d, response);
        });
        controller.fillData(baseData);
        controller.totalCalculate();
        controller.write(this.imgPath, report.getPicUrl());
    }

    private void fillResponse(CounterErpOtherPo e, CounterErpReportResponse response) {
        switch (e.getBizType()) {
            //入库
            case 1:
                response.setEnterQty(e.getQty());
                response.setEnterAmt(e.getAmt());
                break;
            //调入
            case 2:
                response.setInQty(e.getQty());
                response.setInAmt(e.getAmt());
                break;
            //调出
            case 3:
                response.setOutQty(Math.abs(e.getQty()));
                response.setOutAmt(e.getAmt().abs());
                break;
            //退库
            case 5:
                response.setRetreatQty(Math.abs(e.getQty()));
                response.setRetreatAmt(e.getAmt().abs());
                break;
            //销售
            case 6:
                response.setSalesQty(response.getSalesQty() == null ? Math.abs(e.getQty()) : response.getSalesQty() + Math.abs(e.getQty()));
                response.setSalesAmt(response.getSalesAmt() == null ? e.getAmt().abs() : response.getSalesAmt().add(e.getAmt().abs()));
                break;
            //销售退货
            case 7:
                response.setReturnQty(response.getReturnQty() == null ? e.getQty() : response.getReturnQty() + e.getQty());
                response.setReturnAmt(response.getReturnAmt() == null ? e.getAmt() : response.getReturnAmt().add(e.getAmt()));
                break;
            //预订单提货
            case 8:
                response.setSalesQty(response.getSalesQty() == null ? Math.abs(e.getQty()) : response.getSalesQty() + Math.abs(e.getQty()));
                response.setSalesAmt(response.getSalesAmt() == null ? e.getAmt().abs() : response.getSalesAmt().add(e.getAmt().abs()));
                break;
            //预订单提货退货
            case 9:
                response.setReturnQty(response.getReturnQty() == null ? e.getQty() : response.getReturnQty() + e.getQty());
                response.setReturnAmt(response.getReturnAmt() == null ? e.getAmt() : response.getReturnAmt().add(e.getAmt()));
                break;
            //积分兑换
            case 10:
                response.setSalesQty(response.getSalesQty() == null ? Math.abs(e.getQty()) : response.getSalesQty() + Math.abs(e.getQty()));
                response.setSalesAmt(response.getSalesAmt() == null ? e.getAmt().abs() : response.getSalesAmt().add(e.getAmt().abs()));
                break;
            //积分兑换退货
            case 11:
                response.setReturnQty(response.getReturnQty() == null ? e.getQty() : response.getReturnQty() + e.getQty());
                response.setReturnAmt(response.getReturnAmt() == null ? e.getAmt() : response.getReturnAmt().add(e.getAmt()));
                break;
            //盘点
            case 12:
                //盘盈
                if (e.getQty() >= 0) {
                    response.setInventorySurplusQty(e.getQty());
                    response.setInventorySurplusAmt(e.getAmt());
                } else {
                    //盘亏
                    response.setInventoryLossesQty(Math.abs(e.getQty()));
                    response.setInventoryLossesAmt(e.getAmt().abs());
                }
                break;
            default:
                break;
        }
    }
}
