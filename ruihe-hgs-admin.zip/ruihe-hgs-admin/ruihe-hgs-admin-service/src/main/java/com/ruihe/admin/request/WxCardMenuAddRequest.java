package com.ruihe.admin.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruihe.common.annotation.EnumValidation;
import com.ruihe.common.enums.wx.WxCardMenuTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author LiangYuan
 * @date 2021-03-18 10:51
 */
@ApiModel(value = "WxCardMenuAddRequest", description = "微信会员卡新增菜单请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class WxCardMenuAddRequest implements Serializable {

    @NotBlank(message = "微信菜单名称不能为空")
    @ApiModelProperty(value = "微信菜单名称")
    @Size(max=16,message = "微信菜单名称最大长度为16个字符")
    private String menuName;

    @NotBlank(message = "微信菜单链接不能为空")
    @ApiModelProperty(value = "微信菜单链接")
    @Size(max=128,message = "微信菜单链接最大长度为128个字符")
    private String menuUrl;

    @NotNull(message = "微信菜单类型不能为空")
    @EnumValidation(clazz = WxCardMenuTypeEnum.class, method = "getCode", message = "微信菜单类型错误")
    @ApiModelProperty(value = "微信菜单类型：0 H5页面，1小程序页面")
    private Integer menuType;

    /**
     * 微信小程序id
     */
    @ApiModelProperty(value = "微信小程序id，菜单类型为小程序的时候必填，格式：原始id+@app")
    private String miniApp;

    @NotNull(message = "菜单有效时间起不能为空")
    @ApiModelProperty(value = "菜单有效时间起")
    @Future(message = "开始时间必须是将来时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startTime;

    @NotNull(message = "菜单有效时间止不能为空")
    @ApiModelProperty(value = "菜单有效时间止")
    @Future(message = "结束时间必须是将来时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endTime;
}
