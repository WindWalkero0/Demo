package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.report.core.Column;
import com.ruihe.admin.listener.report.core.ColumnDefine;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.admin.request.bi.CounterErpReportRequest;
import com.ruihe.admin.request.bi.CounterErpSelectRequest;

import java.math.BigDecimal;

/**
 * 柜台进销存报表
 */
@Deprecated
public class CounterErpDefine extends TableDefine {
    static Column oiQty = new Column("期初库存", "oiQty", Integer.class);
    static Column oiAmt = new Column("期初库存金额", "oiAmt", BigDecimal.class);
    static Column salesQty = new Column("销售数量", "salesQty", Integer.class);
    static Column salesAmt = new Column("销售金额", "salesAmt", BigDecimal.class);
    static Column returnQty = new Column("退货数量", "returnQty", Integer.class);
    static Column returnAmt = new Column("退货金额", "returnAmt", BigDecimal.class);
    static Column enterQty = new Column("入库数量", "enterQty", Integer.class);
    static Column enterAmt = new Column("入库金额", "enterAmt", BigDecimal.class);
    static Column retreatQty = new Column("退库数量", "retreatQty", Integer.class);
    static Column retreatAmt = new Column("退库金额", "retreatAmt", BigDecimal.class);
    static Column outQty = new Column("调出数量", "outQty", Integer.class);
    static Column outAmt = new Column("调出金额", "outAmt", BigDecimal.class);
    static Column inQty = new Column("调入数量", "inQty", Integer.class);
    static Column inAmt = new Column("调入金额", "inAmt", BigDecimal.class);
    static Column inventorySurplusQty = new Column("盘盈数量", "inventorySurplusQty", Integer.class);
    static Column inventorySurplusAmt = new Column("盘盈金额", "inventorySurplusAmt", BigDecimal.class);
    static Column inventoryLossesQty = new Column("盘亏数量", "inventoryLossesQty", Integer.class);
    static Column inventoryLossesAmt = new Column("盘亏金额", "inventoryLossesAmt", BigDecimal.class);
    static Column orderQty = new Column("订货数量", "orderQty", Integer.class);
    static Column orderAmt = new Column("订货金额", "orderAmt", BigDecimal.class);
    static Column giftQty = new Column("礼品领用数量", "giftQty", Integer.class);
    static Column giftAmt = new Column("礼品领用金额", "giftAmt", BigDecimal.class);
    static Column eiQty = new Column("期末库存数量", "eiQty", Integer.class);
    static Column eiAmt = new Column("期末库存金额", "eiAmt", BigDecimal.class);

    public static TableDefine create(CounterErpReportRequest request) {
        CounterErpSelectRequest selectRequest = request.getSelectRequest();
        CounterErpDefine define = new CounterErpDefine();
        define.addHorizontalColumns(selectRequest);
        define.addValueColumns(selectRequest);
        define.setStartTime(request.getStartTime());
        define.setEndTime(request.getEndTime());
        define.setTotalFlag(TableDefine.TOTAL_ROW_FULL);
        return define;
    }

    /**
     * 添加查询字段，不包括统计数值字段
     */
    private void addHorizontalColumns(CounterErpSelectRequest req) {
        this.addHorizontalColumn(ColumnDefine.counterId, req.isCounter());
        this.addHorizontalColumn(ColumnDefine.counterName, req.isCounter());
    }

    /**
     * 添加统计数值字段
     */
    private void addValueColumns(CounterErpSelectRequest req) {
        this.addValueColumn(oiQty, req.isBeginningStocks());
        this.addValueColumn(oiAmt, req.isBeginningAmt());
        this.addValueColumn(eiQty, req.isEndingQty());
        this.addValueColumn(eiAmt, req.isEndingAmt());
        this.addValueColumn(salesQty, req.isSalesQty());
        this.addValueColumn(salesAmt, req.isSalesAmt());
        this.addValueColumn(returnQty, req.isReturnQty());
        this.addValueColumn(returnAmt, req.isReturnAmt());
        this.addValueColumn(enterQty, req.isEnterQty());
        this.addValueColumn(enterAmt, req.isEnterAmt());
        this.addValueColumn(retreatQty, req.isRetreatQty());
        this.addValueColumn(retreatAmt, req.isRetreatAmt());
        this.addValueColumn(outQty, req.isOutQty());
        this.addValueColumn(outAmt, req.isOutAmt());
        this.addValueColumn(inQty, req.isInQty());
        this.addValueColumn(inAmt, req.isInAmt());
        this.addValueColumn(inventorySurplusQty, req.isInventorySurplusQty());
        this.addValueColumn(inventorySurplusAmt, req.isInventorySurplusAmt());
        this.addValueColumn(inventoryLossesQty, req.isInventoryLossesQty());
        this.addValueColumn(inventoryLossesAmt, req.isInventoryLossesAmt());
        this.addValueColumn(orderQty, req.isOrderQty());
        this.addValueColumn(orderAmt, req.isOrderAmt());
        this.addValueColumn(giftQty, req.isGiftQty());
        this.addValueColumn(giftAmt, req.isGiftAmt());
    }
}
