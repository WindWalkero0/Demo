package com.ruihe.admin.service.basic;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.admin.request.ProductCategorySaveRequest;
import com.ruihe.admin.request.ProductSeriesSaveRequest;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.base.ProductCategory;
import com.ruihe.common.dao.bean.base.ProductSeries;
import com.ruihe.common.exception.BizException;
import com.ruihe.admin.mapper.basic.ProductCategoryMapper;
import com.ruihe.admin.mapper.basic.ProductMapper;
import com.ruihe.admin.mapper.basic.ProductSeriesMapper;
import com.ruihe.common.response.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;

/**
 * 导入产品分类以及更新产品对应的分类
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ProductCategoryImporter {
    private final ProductMapper productMapper;
    private final ProductCategoryMapper productCategoryMapper;
    private final ProductCategoryService productCategoryService;
    private final ProductSeriesMapper productSeriesMapper;
    private final ProductSeriesService productSeriesService;

    public void importCategory(MultipartFile file) {
        Workbook workbook;
        try {
            workbook = WorkbookFactory.create(file.getInputStream());
        } catch (IOException e) {
            throw new BizException("打开文件失败");
        }

        Sheet sheetProduct = workbook.getSheet("商品明细");
        updateProductCategory(sheetProduct);
    }

    public void importCategory2(MultipartFile file) {
        Workbook workbook;
        try {
            workbook = WorkbookFactory.create(file.getInputStream());
        } catch (IOException e) {
            throw new BizException("打开文件失败");
        }

        Sheet sheetProduct = workbook.getSheet("t_product");
        updateProductCategory2(sheetProduct);
    }

    /**
     * 更新产品分类
     */
    private void updateProductCategory2(Sheet sheet) {
        int skip = 1;
        for (Row row : sheet) {
            if (skip-- > 0) continue;
            String prdCode = getValue(row.getCell(0));
            Integer bigCode = getNum(row.getCell(7));
            String bigName = getValue(row.getCell(8));
            Integer mediumCode = getNum(row.getCell(9));
            String mediumName = getValue(row.getCell(10));
            Integer smallCode = getNum(row.getCell(11));
            String smallName = getValue(row.getCell(12));

            String series = getValue(row.getCell(20));

            bigCode = findOrAddCategory(bigCode, bigName, 0);
            mediumCode = findOrAddCategory(mediumCode, mediumName, bigCode);
            smallCode = findOrAddCategory(smallCode, smallName, mediumCode);
            int sid = findOrAddSeries(series);

            Product product = productMapper.selectById(prdCode);
            if (product == null) {
                log.error("产品不存在 {}", prdCode);
                continue;
            }
            product.setBigCatCode(bigCode);
            product.setBigCatName(bigName);
            product.setMediumCatCode(mediumCode);
            product.setMediumCatName(mediumName);
            product.setSmallCatCode(smallCode);
            product.setSmallCatName(smallName);
            product.setSeriesCode(sid);
            product.setSeriesName(series);
            productMapper.updateById(product);
        }
    }

    /**
     * 更新产品分类
     */
    private void updateProductCategory(Sheet sheet) {
        int skip = 1;
        for (Row row : sheet) {
            if (skip-- > 0) continue;
            String prdCode = getValue(row.getCell(1));
            String big = getValue(row.getCell(4));
            String medium = getValue(row.getCell(5));
            String small = getValue(row.getCell(6));
            String series = getValue(row.getCell(7));

            int bigCode = findOrAddCategory(null, big, 0);
            int mediumCode = findOrAddCategory(null, medium, bigCode);
            int smallCode = findOrAddCategory(null, small, mediumCode);
            int sid = findOrAddSeries(series);

            Product product = productMapper.selectById(prdCode);
            if (product == null) {
                log.error("产品不存在 {}", prdCode);
                continue;
            }
            product.setBigCatCode(bigCode);
            product.setBigCatName(big);
            product.setMediumCatCode(mediumCode);
            product.setMediumCatName(medium);
            product.setSmallCatCode(smallCode);
            product.setSmallCatName(small);
            product.setSeriesCode(sid);
            product.setSeriesName(series);
            product.setUpdateTime(LocalDateTime.now());
            productMapper.updateById(product);
        }
    }

    private int findOrAddCategory(Integer code, String name, int parent) {
        LambdaQueryWrapper<ProductCategory> query = Wrappers.lambdaQuery(ProductCategory.class)
                .eq(ProductCategory::getName, name)
                .eq(code != null, ProductCategory::getId, code)
                .eq(ProductCategory::getParentId, parent);
        ProductCategory pc = productCategoryMapper.selectOne(query);
        if (pc == null) {
            var save = new ProductCategorySaveRequest();
            if (code != null) {
                save.setId(code);
            }
            save.setName(name);
            save.setParentId(parent);
            Response response = productCategoryService.save(save);
            pc = (ProductCategory) response.getData();
        }
        return pc.getId();
    }

    private int findOrAddSeries(String name) {
        if (!StringUtils.hasText(name)) return 0;
        LambdaQueryWrapper<ProductSeries> query = Wrappers.lambdaQuery(ProductSeries.class)
                .eq(ProductSeries::getName, name);
        ProductSeries ps = productSeriesMapper.selectOne(query);
        if (ps == null) {
            var req = new ProductSeriesSaveRequest();
            req.setName(name);
            Response response = productSeriesService.save(req);
            ps = (ProductSeries) response.getData();
        }
        return ps.getId();
    }

    private String getValue(Cell cell) {
        if (cell == null) return "";
        switch (cell.getCellType()) {
            case STRING:
                String sv = cell.getStringCellValue();
                return sv == null ? "" : sv.trim();
            case NUMERIC:
                return String.valueOf(cell.getNumericCellValue());
            case BOOLEAN:
                return cell.getBooleanCellValue() ? "true" : "false";
            default:
                return "";
        }
    }

    private Integer getNum(Cell cell) {
        if (cell == null) return 0;
        return ((Double) cell.getNumericCellValue()).intValue();
    }
}
