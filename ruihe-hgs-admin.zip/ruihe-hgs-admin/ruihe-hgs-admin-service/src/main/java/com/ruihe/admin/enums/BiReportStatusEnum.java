package com.ruihe.admin.enums;

/**
 * bi报表状态枚举
 *
 * @author ly
 */
public enum BiReportStatusEnum {

    /**
     * 状态:-1导出失败/异常,0初始化/导出中,1导出完成
     */
    FAIL(-1, "导出失败/异常"),
    INITIALIZATION(0, "初始化/导出中"),
    COMPLETE(1, "导出完成"),

    ;


    private Integer code;
    private String msg;


    BiReportStatusEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
