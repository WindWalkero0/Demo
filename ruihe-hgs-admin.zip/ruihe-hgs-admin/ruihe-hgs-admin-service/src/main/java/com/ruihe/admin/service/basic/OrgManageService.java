package com.ruihe.admin.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ruihe.common.dao.bean.base.Brand;
import com.ruihe.common.dao.bean.base.Position;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
@Slf4j
public class OrgManageService {
    @Autowired
    private CustomService customService;

    @DS(DBConst.SLAVE)
    public Response selectBrand() {
        try {
            List<Object> list = customService.selectList(Brand.builder()
                    .status(0)
                    .build());
            if (list.isEmpty()) {
                return Response.successMsg("暂无数据");
            }
            List<Brand> brands = new ArrayList<>();
            for (Object o : list) {
                Brand brand = (Brand) o;
                brands.add(brand);
            }
            return Response.success(brands);
        } catch (Exception e) {
            log.error("查询品牌信息报错", e);
            return Response.errorMsg("网络繁忙,请稍后重试");
        }
    }

    @DS(DBConst.SLAVE)
    public Response searchBrand(String brandCode, String brandName, Integer status) {
        try {
//            Brand brandOne = new Brand();
//            brandOne.setBrandCode(brandCode);
//            brandOne.setBrandName(brandName);
//            if (status != null) {
//                brandOne.setStatus(status);
//            } else {
//                brandOne.setStatus(0);
//            }
            List<Object> list = customService.selectList(Brand.builder()
                    .brandCode(brandCode)
                    .brandName(brandName)
                    .status(status)
                    .build());
            if (list.isEmpty()) {
                return Response.successMsg("暂无数据");
            }
            List<Brand> brands = new ArrayList<>();
            for (Object o : list) {
                Brand brand = (Brand) o;
                brands.add(brand);
            }
            return Response.success(brands);
        } catch (Exception e) {
            log.error("searchBrand.ERROR", e);
            return Response.errorMsg("网络繁忙,请稍后重试");
        }
    }

    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response editBrand(Integer id, Integer status) {
        try {
            Brand brand = new Brand();
            brand.setStatus(status);
            Integer update = customService.update(brand, Brand.builder()
                    .id(id)
                    .build());
            if (update == 0) {
                log.error("修改品牌状态失败,id={},status={}", id, status);
                throw new Exception("修改品牌状态失败");
            }
            return Response.successMsg("操作成功");
        } catch (Exception e) {
            log.error("修改品牌状态异常,id={},status={},e={}", id, status, e);
            return Response.errorMsg("网络繁忙,请稍后重试");
        }
    }

    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addBrand(Brand brand) {
        try {
            List<Object> list = customService.selectList(Brand.builder()
                    .brandCode(brand.getBrandCode())
                    .build());
            if (list.size() > 1) {
                return Response.errorMsg("品牌代码重复");
            }
            List<Object> list1 = customService.selectList(Brand.builder()
                    .brandName(brand.getBrandName())
                    .build());
            if (list1.size() > 1) {
                return Response.errorMsg("品牌名称重复");
            }
            //进行添加
            Integer save = customService.save(brand);
            if (save == -1) {
                log.error("添加品牌失败,brand={}", brand);
                throw new Exception("添加品牌失败");
            }
            return Response.successMsg("添加成功");
        } catch (Exception e) {
            log.error("添加品牌异常,brand={},{}", brand, e);
            return Response.errorMsg("网络繁忙,请稍后重试");
        }
    }

    @DS(DBConst.SLAVE)
    public Response selectPos(Integer status, Integer pageNumber, Integer pageSize, String posCode, String posName) {
        //分页条件
        PageHelper.startPage(pageNumber, pageSize);
//        Position position1 = new Position();
//        position1.setPosCode(posCode);
//        position1.setPosName(posName);
//        if (status == null) {
//            position1.setStatus(0);
//        } else {
//            position1.setStatus(status);
//        }
        List<Position> list = customService.selectList(Position.builder()
                .posCode(posCode)
                .posName(posName)
                .status(status)
                .build());
        list.sort(new Comparator<Position>() {
            @Override
            public int compare(Position position, Position positionOther) {
                return new BigDecimal(position.getPosLevel()).compareTo(new BigDecimal(positionOther.getPosLevel()));
            }
        });

        PageInfo<Position> info = new PageInfo<>(list);
        Long count = customService.selectCount(Position.builder()
                .status(status)
                .posName(posName)
                .posCode(posCode)
                .build());
        info.setTotal(count);
        return Response.success(info);
    }

    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addPos(Position position) {
        if (position.getPosLevel() >= 0) {
            Position query1 = customService.select(Position.builder()
                    .posName(position.getPosName())
                    .build());
            if (query1 != null) {
                return Response.errorMsg("岗位名称重复");
            }
            List<Position> positionLevels = customService.selectList(Position.builder().posLevel(position.getPosLevel()).build());
            if (positionLevels != null && !positionLevels.isEmpty()) {
                return Response.errorMsg("岗位级别已经存在，请重新填写");
            }
            List<Position> positionCodes = customService.selectList(Position.builder().posCode(position.getPosCode()).build());
            if (positionCodes != null && !positionCodes.isEmpty()) {
                return Response.errorMsg("岗位代码已经存在，请重新填写");
            }
            //填充完信息后进行添加
            position.setCreateTime(LocalDateTime.now());
            position.setStatus(1);
            Integer save = customService.save(position);
            if (save.equals(0)) {
                log.error("添加岗位信息失败,position={}", position);
                throw new BizException("添加岗位信息失败");
            }
            return Response.successMsg("添加岗位成功");
        } else {
            return Response.errorMsg("岗位级别只能输入正整数");
        }

    }

    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response editPos(Position position) {
        try {
            if (position.getPosLevel() > 0) {
                List<Object> list = customService.selectListByTime(Position.builder()
                        .posName(position.getPosName())
                        .build());
                for (Object o : list) {
                    Position position1 = (Position) o;
                    if (!position1.getId().equals(position.getId())) {
                        return Response.errorMsg("岗位名称已存在,请重新编辑");
                    }
                }
                List<Position> positions = customService.selectList(Position.builder().posCode(position.getPosCode()).build());
                for (Position position1 : positions) {
                    if (!position1.getId().equals(position.getId())) {
                        return Response.errorMsg("岗位代码已存在,请重新编辑");
                    }
                }
                List<Position> positionList = customService.selectList(Position.builder().posLevel(position.getPosLevel()).build());
                for (Position position1 : positionList) {
                    if (!position1.getId().equals(position.getId())) {
                        return Response.errorMsg("岗位等级已存在,请重新编辑");
                    }
                }
                //正常保存
                Integer update = customService.update(position, Position.builder()
                        .id(position.getId())
                        .build());
                if (update == 0) {
                    log.error("修改岗位信息失败,position={}", position);
                    throw new Exception("修改岗位信息失败");
                }
            } else {
                return Response.errorMsg("岗位级别不能为0或小于0");
            }
            return Response.successMsg("编辑成功");
        } catch (Exception e) {
            log.error("编辑岗位信息异常e={}", e);
            return Response.errorMsg("网络繁忙,请稍候重试");
        }
    }

    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response modifyStatus(String ids, Integer status) {
        try {
            String[] split = ids.split(",");
            for (String id : split) {
                Position position = new Position();
                position.setStatus(status);
                Integer update = customService.update(position, Position.builder()
                        .id(Integer.parseInt(id))
                        .build());
                if (update == 0) {
                    log.error("停用或启用岗位失败ids={}", ids);
                    throw new Exception("停用或启用岗位失败");
                }
            }
            return Response.successMsg("操作成功");
        } catch (Exception e) {
            log.error("状态修改失败,ids={},{}", ids, e);
            return Response.errorMsg("网络繁忙,请稍后重试");
        }
    }

    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response saveBrand(Brand brand) {
        try {
            String brandName = brand.getBrandName();
            List<Object> list = customService.selectList(Brand.builder()
                    .brandName(brandName)
                    .build());
            if (list.size() > 1) {
                return Response.errorMsg("品牌名称已经存在");
            }
            Integer update = customService.update(brand, Brand.builder()
                    .id(brand.getId())
                    .build());
            if (update == 0) {
                log.error("保存品牌失败,brand={}", brand);
                throw new BizException("保存品牌失败");
            }
            return Response.successMsg("操作成功");
        } catch (Exception e) {
            log.error("品牌名称修改失败", e);
            return Response.errorMsg("网络繁忙,请稍后重试");
        }
    }

}
