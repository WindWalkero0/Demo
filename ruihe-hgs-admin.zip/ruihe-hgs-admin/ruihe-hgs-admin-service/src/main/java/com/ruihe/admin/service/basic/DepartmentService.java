package com.ruihe.admin.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.mapper.basic.CounterMapper;
import com.ruihe.admin.mapper.basic.UserConcernMapper;
import com.ruihe.admin.mapper.basic.UserCounterMapper;
import com.ruihe.admin.mapper.basic.UserDepartmentMapper;
import com.ruihe.admin.mapper.order.PosOrderMapper;
import com.ruihe.admin.request.*;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.vo.*;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.*;
import com.ruihe.common.dao.mapper.DepartmentMapper;
import com.ruihe.common.dao.mapper.UserInformationMapper;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.base.DepartmentEnum;
import com.ruihe.common.enums.prefix.PrefixEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;
import com.ruihe.common.response.Response;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.service.ChangeService;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author 梁远
 * @Description
 * @create 2019-06-15 14:48
 */
@Service
@Slf4j
public class DepartmentService {

    @Autowired
    private DepartmentMapper departmentMapper;

    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private UserInformationMapper userInformationMapper;

    @Autowired
    private UserDepartmentMapper userDepartmentMapper;

    @Autowired
    private UserConcernMapper userConcernMapper;

    @Autowired
    private UserCounterMapper userCounterMapper;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private ChangeService changeService;

    /**
     * 查询所有部门主管信息
     * 注：此处2019-12-14根据产品经理需求按照部门类型进行过滤（以后无论需求如何更改此处代码不会再改）
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectMaster(CommonDeptRequest request) {
        //判断页数和页面
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            return Response.errorMsg("页数、页码不能为空!");
        }
        //查询所有的部门主管
        LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery()
                .eq(Department::getDeptType, DepartmentEnum.COUNTER_SUPERVISOR.getKey())
                .eq(Department::getStatus, CommonStatusEnum.EFFECTIVE.getCode());
        List<Department> departmentList = departmentMapper.selectList(queryWrapper);
        //获取所有的柜台主管的部门编码
        List<String> deptCodeList = departmentList.stream().map(e -> e.getDeptId()).collect(Collectors.toList());
        //设置分页条件
        Page<UserInformation> page = new Page<>(request.getPageNumber(), request.getPageSize());
        LambdaQueryWrapper<UserInformation> wrapper = Wrappers.<UserInformation>lambdaQuery()
                .in(UserInformation::getDeptCode, deptCodeList)
                .eq(UserInformation::getStatus, CommonStatusEnum.EFFECTIVE.getCode());
        if (StringUtils.isNotBlank(request.getDept())) {
            wrapper.and(q -> q.like(UserInformation::getEmpId, request.getDept()).or().like(UserInformation::getName, request.getDept()));
        }
        //分页查询
        IPage<UserInformation> userIPage = userInformationMapper.selectPage(page, wrapper);
        //获取查询数据
        List<UserInformation> userList = userIPage.getRecords();
        //设置查询结果
        PageVO info = PageVO.<DeptUserVo>builder().list(ObjectUtils.toList(userList, DeptUserVo.class))
                .total(userIPage.getTotal())
                .pageNum(userIPage.getCurrent())
                .pageSize(userIPage.getSize())
                .pages(userIPage.getPages()).build();
        return Response.success(info);
    }

    /**
     * 添加部门
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addDepartment(DepartmentRequest request) throws BizException {
        //判断条件
        if (StringUtils.isNotBlank(request.getDeptId())) {
            LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, request.getDeptId());
            Department Query = departmentMapper.selectOne(queryWrapper);
            if (Query != null) {
                log.error("部门代码重复！depId={}", request.getDeptId());
                throw new BizException("部门代码重复");
            }
        }
        if (StringUtils.isNotBlank(request.getDeptName())) {
            LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery().eq(Department::getDeptName, request.getDeptName());
            Department Query = (departmentMapper.selectOne(queryWrapper));
            if (Query != null) {
                log.error("部门名称重复！depId=" + request.getDeptId());
                throw new BizException("部门名称重复!");
            }
        }
        //修改履历--added by William 2020.11.13
        //部门代码
        String deptId = IdGenerator.getRandomId(PrefixEnum.DEPT.getCode(), 6);
        Long changeId = changeService.insert(Department.class, deptId, "新增部门");
        //将基础信息添加到部门信息表
        Department department = new Department();
        BeanUtils.copyProperties(request, department);
        department.setDeptId(deptId);
        department.setCreateTime(LocalDateTime.now());
        department.setUpdateTime(LocalDateTime.now());
        department.setChangeId(changeId);
        Integer rows = departmentMapper.insert(department);
        if (rows == 0) {
            log.error("添加部门失败！部门入参={}", request.toString());
            throw new BizException("添加部门失败！");
        }
        return Response.successMsg("添加部门成功!");
    }

    /**
     * 根据部门类型查询上级部门
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectUpDepartment(UpDepartmentRequest request) {
        //判断页数和页面
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            return Response.errorMsg("页数、页码不能为空!");
        }
        //设置分页显示条件
        Page<Department> page = new Page<>(request.getPageNumber(), request.getPageSize());
        LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery()
                .lt(Department::getDeptType, request.getDeptType())
                .eq(Department::getStatus, CommonStatusEnum.EFFECTIVE.getCode());
        IPage<Department> departmentIPage = departmentMapper.selectPage(page, queryWrapper);
        List<Department> departmentList = departmentIPage.getRecords();
        PageVO pageVO = PageVO.<DepartmentVo>builder().list(ObjectUtils.toList(departmentList, DepartmentVo.class))
                .total(departmentIPage.getTotal())
                .pageNum(departmentIPage.getCurrent())
                .pageSize(departmentIPage.getSize())
                .pages(departmentIPage.getPages()).build();
        return Response.success(pageVO);
    }

    /**
     * 根据名称/ID模糊查询部门
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response queryUpDepartment(UpDepartmentRequest request) {
        //判断页数和页面
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            return Response.errorMsg("页数、页码不能为空!");
        }
        //设置分页显示条件
        Page<Department> page = new Page<>(request.getPageNumber(), request.getPageSize());
        LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery()
                //2020年5月9日16:28:55 不能越级选择 保证3层结构
                .eq(Department::getDeptType, request.getDeptType() - 1);
        if (StringUtils.isNotBlank(request.getDeptName())) {
            queryWrapper.and(d -> d.like(Department::getDeptName, request.getDeptName())
                    .or().like(Department::getDeptId, request.getDeptName()));
        }
        IPage<Department> departmentIPage = departmentMapper.selectPage(page, queryWrapper);
        List<Department> departmentList = departmentIPage.getRecords();
        PageVO pageVO = PageVO.<DepartmentVo>builder().list(ObjectUtils.toList(departmentList, DepartmentVo.class))
                .total(departmentIPage.getTotal())
                .pageNum(departmentIPage.getCurrent())
                .pageSize(departmentIPage.getSize())
                .pages(departmentIPage.getPages()).build();
        return Response.success(pageVO);
    }

    /**
     * 更新状态
     *
     * @param list
     * @param status
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response updateDepartmentStatus(List<String> list, Integer status) throws BizException {
        if (org.springframework.util.ObjectUtils.isEmpty(list)) {
            return Response.errorMsg("请选择部门!");
        }
        if (status == null) {
            return Response.errorMsg("请传入状态信息!");
        }
        if (!status.equals(CommonStatusEnum.EFFECTIVE.getCode()) && !status.equals(CommonStatusEnum.INVALID.getCode())) {
            return Response.errorMsg("状态错误!");
        }
        //异动记录改造,updated by William 2020.11.13
        String desc = status == 0 ? "停用部门" : "启用部门";
        List<Long> changeIdList = this.changeService.batchUpdate(Department.class, list, desc);
        list.forEach(e -> {
            int index = list.indexOf(e);
            Department department = Department.builder().status(status).changeId(changeIdList.get(index)).updateTime(LocalDateTime.now()).build();
            Integer up = departmentMapper.update(department, Wrappers.<Department>lambdaUpdate().eq(Department::getDeptId, e));
            if (up != 1) {
                log.error("批量修改部门状态失败！departmentIds={},status={}", e, status);
                throw new BizException("批量修改部门状态失败");
            }
        });
        //更新用户关注部门信息
        userConcernMapper.update(UserConcernPo.builder().deptStatus(status).build(), Wrappers.<UserConcernPo>lambdaUpdate()
                .in(UserConcernPo::getDeptCode, list));
        //更新用户管辖部门信息
        userDepartmentMapper.update(UserDepartment.builder().status(status).build(), Wrappers.<UserDepartment>lambdaUpdate()
                .in(UserDepartment::getDeptCode, list));
        //修改柜台的状态
        List<CounterInformation> counterInformationList = counterMapper.selectList(Wrappers.<CounterInformation>lambdaQuery()
                .select(CounterInformation::getCounterId).in(CounterInformation::getCounterId, list));
        if (!counterInformationList.isEmpty()) {
            //如果查询到了柜台，则对柜台的状态进行修改
            Integer isDel = getCounterStatus(status);
            List<String> idList = counterInformationList.stream().map(CounterInformation::getCounterId).collect(Collectors.toList());
            CounterInformation build = CounterInformation.builder()
                    .isDel(isDel)
                    .updateTime(LocalDateTime.now())
                    .build();
            if (isDel.equals(StatusEnum.DELETED.getKey())) {
                //停业
                build.setStopTime(LocalDateTime.now());
            } else {
                //停业重开
                build.setReopenTime(LocalDateTime.now());
            }
            //柜台异动记录改造,updated by William 2020.11.13
            String counterChangeDesc = status == 0 ? "停用部门" : "启用部门";
            List<Long> counterChangeIdList = this.changeService.batchUpdate(CounterInformation.class, idList, counterChangeDesc);
            idList.forEach(e -> {
                int index = idList.indexOf(e);
                build.setChangeId(counterChangeIdList.get(index));
                Integer update = counterMapper.update(build, Wrappers.<CounterInformation>lambdaUpdate().eq(CounterInformation::getCounterId, e));
                if (update == 0) {
                    log.error("批量更新部门状态失败,counterId={}", e);
                    throw new BizException("批量更新部门状态失败");
                }
            });
            /*Integer update = counterMapper.update(build, Wrappers.<CounterInformation>lambdaUpdate().in(CounterInformation::getCounterId, idList));
            if (update == 0) {
                log.error("批量更新部门状态失败,idList={}", idList);
                throw new BizException("批量更新部门状态失败");
            }*/
        }
        return Response.successMsg("已经修改状态!");
    }

    /**
     * 将柜台的状态转换成部门的状态
     *
     * @param status
     * @return
     */
    private Integer getCounterStatus(Integer status) {
        return status.equals(CommonStatusEnum.EFFECTIVE.getCode()) ? StatusEnum.UN_DELETED.getKey() : StatusEnum.DELETED.getKey();
    }

    /**
     * 根据条件查找
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response queryDepartment(DepartmentQueryRequest request) {
        //判断页数和页面
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            return Response.errorMsg("页数、页码不能为空!");
        }
        //设置分页显示条件
        Page<Department> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //设置查询条件
        LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery()
                .orderByDesc(Department::getCreateTime)
                .orderByAsc(Department::getDeptId);
        if (request.getStatus() != null) {
            queryWrapper.eq(Department::getStatus, request.getStatus());
        }
        if (StringUtils.isNotBlank(request.getDeptId())) {
            queryWrapper.like(Department::getDeptId, request.getDeptId());
        }
        if (StringUtils.isNotBlank(request.getDeptName())) {
            queryWrapper.like(Department::getDeptName, request.getDeptName());
        }
        if (request.getDeptType() != null) {
            queryWrapper.like(Department::getDeptType, request.getDeptType());
        }
        IPage<Department> departmentIPage = departmentMapper.selectPage(page, queryWrapper);
        List<Department> departmentList = departmentIPage.getRecords();
        PageVO pageVO = PageVO.<DepartmentVo>builder().list(ObjectUtils.toList(departmentList, DepartmentVo.class))
                .total(departmentIPage.getTotal())
                .pageNum(departmentIPage.getCurrent())
                .pageSize(departmentIPage.getSize())
                .pages(departmentIPage.getPages()).build();
        return Response.success(pageVO);
    }

    /**
     * 根据ID查找,返回部门相关信息
     *
     * @param deptId
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectDepartmentById(String deptId) {
        //查询部门信息
        LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, deptId);
        Department department = departmentMapper.selectOne(queryWrapper);
        if (department == null) {
            return Response.successMsg("暂无信息!");
        }
        DepartmentVo departmentVo = new DepartmentVo();
        BeanUtils.copyProperties(department, departmentVo);
        //查询部门下人员信息
        LambdaQueryWrapper<UserInformation> wrapper = Wrappers.<UserInformation>lambdaQuery().eq(UserInformation::getDeptCode, deptId);
        List<UserInformation> userInformationList = userInformationMapper.selectList(wrapper);
        if (!userInformationList.isEmpty()) {
            departmentVo.setDeptUserVoList(ObjectUtils.toList(userInformationList, DeptUserVo.class));
        }
        //查询管辖部门的用户
        LambdaQueryWrapper<UserDepartment> queryDept = Wrappers.<UserDepartment>lambdaQuery().eq(UserDepartment::getDeptCode, deptId);
        List<UserDepartment> userDepartmentList = userDepartmentMapper.selectList(queryDept);
        if (!userDepartmentList.isEmpty()) {
            //获取用户代码list
            List<String> list = userDepartmentList.stream().map(UserDepartment::getEmpId).collect(Collectors.toList());
            //根据用户代码查询用户信息
            LambdaQueryWrapper<UserInformation> queryUser = Wrappers.<UserInformation>lambdaQuery().in(UserInformation::getEmpId, list);
            List<UserInformation> userList = userInformationMapper.selectList(queryUser);
            departmentVo.setManageVoList(ObjectUtils.toList(userList, DeptUserVo.class));
        }
        return Response.success(departmentVo);
    }

    /**
     * 更新部门信息
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response updateDepartment(DepartmentRequest request) throws BizException {
        //根据部门代码进行判断重复
        Department department = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, request.getDeptId()));
        //判断是否修改了部门名称
        if (!request.getDeptName().equals(department.getDeptName())) {
            //判断部门名称是否重复了
            Department dept = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery().eq(Department::getDeptName, request.getDeptName()));
            if (dept != null) {
                return Response.errorMsg("部门名称重复!");
            }
        }
        //update by William 修改部门
        Long changeId = this.changeService.update(Department.class, request.getDeptId(), "更新");
        //更新部门信息
        Department dept = new Department();
        BeanUtils.copyProperties(request, dept);
        dept.setUpdateTime(LocalDateTime.now());
        dept.setChangeId(changeId);
        LambdaUpdateWrapper<Department> updateWrapper = Wrappers.<Department>lambdaUpdate().eq(Department::getDeptId, request.getDeptId());
        Integer rows = departmentMapper.update(dept, updateWrapper);
        if (rows == 0) {
            log.error("更新部门信息失败!" + request.getDeptId());
            throw new BizException("更新部门信息失败!");
        }
        //判断部门名称和类型是否发生了改变
        if (!department.getDeptType().equals(request.getDeptType()) || !department.getDeptName().equals(request.getDeptName())) {
            //更新下级部门信息
            updateLoweDepartment(request);
            //更新用户信息
            updateUserInfo(request);
        }
        //更新柜台组织机构信息
        updateCounterInfo(dept);
        //2020年5月9日16:32:44 更新订单组织信息
        updatePosOrder(dept);

        return Response.successMsg("已经修改信息!");
    }

    /**
     * 更新柜台组织机构信息
     *
     * @param dept
     */
    private void updatePosOrder(Department dept) {
        //筛选了条件之后  只能修改上级或者本级的名字 不能修改等级
        //每次只能改一次等级  要么二级变了 要么三级变了
        Department department = departmentMapper.selectById(dept.getUpDeptId());
        int update = posOrderMapper.updateDepartment(dept, department.getUpDeptId(), department.getUpDeptName());
        //2020年5月11日10:14:38 有时候会没有订单 update是0好像也没有毛病
        log.info("更新订单中的柜台组织机构！本次修改 {} 笔订单", update);
    }

    /**
     * 更新柜台组织机构信息
     *
     * @param dept
     */
    private void updateCounterInfo(Department dept) {


        Department department = departmentMapper.selectById(dept.getUpDeptId());
        int update = counterMapper.updateDepartment(dept, department.getUpDeptId(), department.getUpDeptName());
        log.info("更新柜台的组织机构！本次修改 {} 个柜台", update);

//        List<CounterInformation> list = counterMapper.selectList(Wrappers.<CounterInformation>lambdaQuery()
//                .eq(CounterInformation::getPrincipalEmpDeptCode, request.getDeptId())
//                .or(c -> c.eq(CounterInformation::getOrgMasterId, request.getDeptId())
//                        .or().eq(CounterInformation::getOrgOfficeId, request.getDeptId())
//                        .or().eq(CounterInformation::getOrgAreaId, request.getDeptId())));
//        if (!list.isEmpty()) {
//            for (CounterInformation counterInformation : list) {
//                fillCounterInformation(counterInformation, request, deptType);
//                counterInformation.setUpdateTime(LocalDateTime.now());
//                int update = counterMapper.update(counterInformation, Wrappers.<CounterInformation>lambdaUpdate()
//                        .eq(CounterInformation::getCounterId, counterInformation.getCounterId()));
//                if (update != 1) {
//                    log.error("更新柜台组织机构信息失败！counterId={}", counterInformation.getCounterId());
//                    throw new BizException("更新柜台组织机构信息失败！");
//                }
//            }
//        }
    }

    /**
     * 根据柜台主管信息设置组织机构
     *
     * @param counterInformation
     * @param deptType
     * @return
     */
    private void fillCounterInformation(CounterInformation counterInformation, DepartmentRequest request, Integer deptType) {
        //如果部门状态未改变，则直接修改名称
        if (request.getDeptType().equals(deptType)) {
            if (request.getDeptType().equals(DepartmentEnum.COUNTER_SUPERVISOR.getKey())) {
                //如果该部门的类型是柜台主管
                counterInformation.setOrgMasterName(request.getDeptName());
            } else if (request.getDeptType().equals(DepartmentEnum.OFFICE.getKey())) {
                //如果该部门类型是办事处，设置办事处信息
                counterInformation.setOrgOfficeName(request.getDeptName());
            } else if (request.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
                //如果部门类型是大区，直接设置大区信息
                counterInformation.setOrgAreaName(request.getDeptName());
            }
        } else {
            //部门类型发生改变暂时未处理
            /*//根据部门的类型进行处理
            if (request.getDeptType().equals(DepartmentEnum.COUNTER_SUPERVISOR.getKey())) {
                //如果该部门的类型是柜台主管
                counterInformation.setOrgMasterId(request.getDeptId());
                counterInformation.setOrgMasterName(request.getDeptName());
                //根据上级部门进行查询
                Department updepart = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, request.getUpDeptId()));
                if (updepart.getDeptType().equals(DepartmentEnum.OFFICE.getKey())) {
                    counterInformation.setOrgOfficeId(updepart.getDeptId());
                    counterInformation.setOrgOfficeName(updepart.getDeptName());
                    //根据办事处查询上级部门信息
                    Department upDepartment = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, updepart.getUpDeptId()));
                    if (upDepartment.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
                        //如果上级部门是大区
                        counterInformation.setOrgAreaId(upDepartment.getDeptId());
                        counterInformation.setOrgAreaName(upDepartment.getDeptName());
                    }
                } else if (updepart.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
                    counterInformation.setOrgAreaId(updepart.getDeptId());
                    counterInformation.setOrgAreaName(updepart.getDeptName());
                }
            } else if (request.getDeptType().equals(DepartmentEnum.OFFICE.getKey())) {
                //如果该部门类型是办事处，则将之前办事处信息修改到柜台主管信息中
                counterInformation.setOrgMasterId(counterInformation.getOrgOfficeId());
                counterInformation.setOrgMasterName(counterInformation.getOrgOfficeName());
                //设置办事处信息
                counterInformation.setOrgOfficeId(request.getDeptId());
                counterInformation.setOrgOfficeName(request.getDeptName());
                //根据上级部门进行查询
                Department updepart = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, request.getUpDeptId()));
                if (updepart.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
                    counterInformation.setOrgAreaId(updepart.getDeptId());
                    counterInformation.setOrgAreaName(updepart.getDeptName());
                }
            } else if (request.getDeptType().equals(DepartmentEnum.REGION.getKey())) {
                //如果部门类型是大区，将之前办事处信息修改到柜台主管信息中
                counterInformation.setOrgMasterId(counterInformation.getOrgOfficeId());
                counterInformation.setOrgMasterName(counterInformation.getOrgOfficeName());
                // 将办事处信息设置到柜台主管中
                // 直接设置大区信息
                counterInformation.setOrgAreaId(request.getDeptId());
                counterInformation.setOrgAreaName(request.getDeptName());
            }*/
        }
    }

    /**
     * 更新用户信息
     *
     * @param request
     * @throws BizException
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void updateUserInfo(DepartmentRequest request) throws BizException {
        //查询用户的部门
        List<UserInformation> userInformationList = userInformationMapper.selectList(Wrappers.<UserInformation>lambdaQuery()
                .select(UserInformation::getEmpId).eq(UserInformation::getDeptCode, request.getDeptId()));
        if (!userInformationList.isEmpty()) {
            //不为空，则进行更新
            List<String> collect = userInformationList.stream().map(UserInformation::getEmpId).collect(Collectors.toList());
            UserInformation build = UserInformation.builder()
                    .deptName(request.getDeptName())
                    .deptType(request.getDeptType()).build();
            Integer rows = userInformationMapper.update(build, Wrappers.<UserInformation>lambdaUpdate().in(UserInformation::getEmpId, collect));
            if (rows != collect.size()) {
                log.error("更新信息失败，collect={}", collect);
                throw new BizException("更新信息失败");
            }
            //是否需要更新柜台信息---废弃,已在上面进行更新
            //updateCounter(collect, request);
        }
        //更新用户关注部门信息
        userConcernMapper.update(UserConcernPo.builder().deptName(request.getDeptName()).deptType(request.getDeptType()).build(), Wrappers.<UserConcernPo>lambdaUpdate()
                .eq(UserConcernPo::getDeptCode, request.getDeptId()));
        //更新用户管辖部门信息
        userDepartmentMapper.update(UserDepartment.builder().deptName(request.getDeptName()).deptType(request.getDeptType()).build(), Wrappers.<UserDepartment>lambdaUpdate()
                .eq(UserDepartment::getDeptCode, request.getDeptId()));
    }


    /**
     * 更新柜台信息
     *
     * @param collect
     * @param request
     * @throws BizException
     */
    private void updateCounter(List<String> collect, DepartmentRequest request) throws BizException {
        List<CounterInformation> list = counterMapper.selectList(Wrappers.<CounterInformation>lambdaQuery()
                .select(CounterInformation::getCounterId).in(CounterInformation::getPrincipalEmpId, collect));
        if (!list.isEmpty()) {
            List<String> idList = list.stream().map(CounterInformation::getCounterId).collect(Collectors.toList());
            CounterInformation counterInformation = CounterInformation.builder()
                    .principalEmpDeptName(request.getDeptName())
                    .updateTime(LocalDateTime.now()).build();
            Integer rows = counterMapper.update(counterInformation, Wrappers.<CounterInformation>lambdaUpdate().in(CounterInformation::getCounterId, idList));
            if (rows != idList.size()) {
                log.error("更新柜台信息失败!,idList={}", idList);
                throw new BizException("更新柜台信息失败!");
            }
        }
    }

    /**
     * 更新下级部门信息
     *
     * @param request
     * @throws BizException
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void updateLoweDepartment(DepartmentRequest request) throws BizException {
        //更新下级部门信息
        List<Department> list = departmentMapper.selectList(Wrappers.<Department>lambdaQuery()
                .select(Department::getDeptId).eq(Department::getUpDeptId, request.getDeptId()));
        if (!list.isEmpty()) {
            /*List<String> collect = list.stream().map(Department::getDeptId).collect(Collectors.toList());
            Department build = Department.builder()
                    .upDeptType(request.getDeptType())
                    .upDeptName(request.getDeptName())
                    .updateTime(LocalDateTime.now())
                    .build();
            Integer rows = departmentMapper.update(build, Wrappers.<Department>lambdaUpdate().in(Department::getDeptId, collect));
            if (rows != collect.size()) {
                log.error("更新下级部门信息!collect={}", collect.toString());
                throw new BizException("更新下级部门信息!");
            }*/
            //update by William，新增异动记录
            list.forEach(e -> {
                Long changeId = changeService.update(Department.class, e.getDeptId(), "更新上级部门");
                Department dept = Department.builder()
                        .upDeptType(request.getDeptType())
                        .upDeptName(request.getDeptName())
                        .updateTime(LocalDateTime.now())
                        .changeId(changeId)
                        .build();
                Integer rows = departmentMapper.update(dept, Wrappers.<Department>lambdaUpdate().eq(Department::getDeptId, e.getDeptId()));
                if (rows != 1) {
                    log.error("更新下级部门信息!collect={}", e.getDeptId());
                    throw new BizException("更新下级部门信息!");
                }
            });
        }
        //更新柜台组织机构信息
    }

    /**
     * 查询组织结构下部门管理的树结构
     *
     * @param deptId
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response departmentTree(String deptId) {
        //设置返回前端的数据
        List<DeptVo> deptVoList = new ArrayList<>();
        //查询部门信息
        LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery().eq(Department::getUpDeptId, deptId);
        List<Department> list = departmentMapper.selectList(queryWrapper);
        if (!list.isEmpty()) {
            deptVoList = ObjectUtils.toList(list, DeptVo.class);
        }
        /* 此处代码先留着
       //有可能办事处是某个柜台的主管
        LambdaQueryWrapper<CounterInformation> wrapper = Wrappers.<CounterInformation>lambdaQuery()
                .eq(CounterInformation::getOrgMasterId, deptId);
        List<CounterInformation> informationList = counterMapper.selectList(wrapper);
        if (!informationList.isEmpty()) {
            for (CounterInformation counterInformation : informationList) {
                deptVoList.add(DeptVo.builder()
                        .orgType(DepartmentEnum.COUNTER.getKey())
                        .deptName(counterInformation.getCounterName())
                        .deptId(counterInformation.getCounterId()).build());
            }
        }*/
        return Response.success(ObjectUtils.toList(deptVoList, DeptVo.class));
    }

    /**
     * 查询组织结构下部门管理的树结构
     *
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response departmentAll() {
        //设置返回前端的数据
        List<DeptVo> deptVoList = new ArrayList<>();
        //查询部门信息
        List<Department> list = departmentMapper.selectList(Wrappers.<Department>lambdaQuery());
        if (!list.isEmpty()) {
            deptVoList = ObjectUtils.toList(list, DeptAllVo.class);
        }
        return Response.success(deptVoList);
    }

    /**
     * 根据下级信息查询询上级
     */
    @DS(DBConst.SLAVE)
    public Department selectDepByID(String departmentId) {
        //根据ID号查询出柜台的信息
        Department department = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, departmentId));
        if (department == null) {
            return null;
        }
        //根据柜台主管信息查询大区和办事处的信息
        LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, department.getUpDeptId());
        return departmentMapper.selectOne(queryWrapper);
    }


    /**
     * 添加用户页面选择部门
     * 查询部门
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectDepartment(CommonDeptRequest request) {
        //判断页数和页码
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            return Response.errorMsg("页数、页码不能为空!");
        }
        //设置分页显示条件
        Page<Department> page = new Page<>(request.getPageNumber(), request.getPageSize());
        LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery()
                //如果createTime一样的话，查询会出现错误的情况
                .orderByAsc(Department::getDeptId)
                .orderByAsc(Department::getCreateTime);
        if (request.getStatus() != null) {
            queryWrapper.eq(Department::getStatus, request.getStatus());
        }
        if (StringUtils.isNotBlank(request.getDept())) {
            queryWrapper.and(d -> d.like(Department::getDeptId, request.getDept())
                    .or().like(Department::getDeptName, request.getDept()));
        }
        IPage<Department> departmentIPage = departmentMapper.selectPage(page, queryWrapper);
        List<Department> departmentList = departmentIPage.getRecords();
        PageVO pageVO = PageVO.<DeptVo>builder().list(ObjectUtils.toList(departmentList, DeptVo.class))
                .total(departmentIPage.getTotal())
                .pageNum(departmentIPage.getCurrent())
                .pageSize(departmentIPage.getSize())
                .pages(departmentIPage.getPages()).build();
        return Response.success(pageVO);
    }

    /**
     * 组织模式选择柜台
     *
     * @param request
     * @return 柜台的id的list
     */
    public List<CounterInformation> queryDepAndCounter(OrgQueryConditionRequest request) {
        //设置柜台的状态和类型(部门和柜台有所区别，所以在此处需要设置)
        Integer deptType = null;
        Integer deptStatus = null;
        if (request.getOrgType() != null) {
            deptType = request.getOrgType().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CounterEnum.FORMAL_COUNTER.getKey() : CounterEnum.TEST_COUNTER.getKey();
        }
        if (request.getOrgStatus() != null) {
            deptStatus = request.getOrgStatus().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CommonStatusEnum.INVALID.getCode() : CommonStatusEnum.EFFECTIVE.getCode();
        }
        //返回前端的list
        List<CounterInformation> list = new ArrayList<>();
        //如果所有的参数都为空，而说明是直接选择柜台的
        if (StringUtils.isBlank(request.getOrgAreaCode()) && StringUtils.isBlank(request.getOrgOfficeCode()) && StringUtils.isBlank(request.getOrgPrincipalCode())) {
            LambdaQueryWrapper<CounterInformation> queryWrapper = Wrappers.<CounterInformation>lambdaQuery();
            if (request.getOrgType() != null) {
                queryWrapper.eq(CounterInformation::getCounterType, deptType);
            }
            if (request.getOrgStatus() != null) {
                queryWrapper.eq(CounterInformation::getIsDel, deptStatus);
            }
            //如果模糊查询条件不为空
            if (StringUtils.isNotBlank(request.getCounterId())) {
                queryWrapper.and(c -> c.like(CounterInformation::getCounterId, request.getCounterId())
                        .or().like(CounterInformation::getCounterName, request.getCounterId()));
            }
            list = counterMapper.selectList(queryWrapper);
        } else if (StringUtils.isNotBlank(request.getOrgPrincipalCode())) {
            //如果柜台主管不为空，则根据条件进行查询
            LambdaQueryWrapper<CounterInformation> queryWrapper = Wrappers.<CounterInformation>lambdaQuery()
                    .eq(CounterInformation::getOrgAreaId, request.getOrgAreaCode())
                    .eq(CounterInformation::getOrgOfficeId, request.getOrgOfficeCode())
                    .eq(CounterInformation::getOrgMasterId, request.getOrgPrincipalCode());
            if (StringUtils.isNotBlank(request.getCounterId())) {
                queryWrapper.and(c -> c.like(CounterInformation::getCounterId, request.getCounterId())
                        .or().like(CounterInformation::getCounterName, request.getCounterId()));
            }
            if (request.getOrgType() != null) {
                queryWrapper.eq(CounterInformation::getCounterType, deptType);
            }
            if (request.getOrgStatus() != null) {
                queryWrapper.eq(CounterInformation::getIsDel, deptStatus);
            }
            list = counterMapper.selectList(queryWrapper);
        } else if (StringUtils.isNotBlank(request.getOrgOfficeCode()) && StringUtils.isBlank(request.getOrgPrincipalCode())) {
            //如果办事处不为空，柜台主管为空
            LambdaQueryWrapper<CounterInformation> queryWrapper = Wrappers.<CounterInformation>lambdaQuery()
                    .eq(CounterInformation::getOrgAreaId, request.getOrgAreaCode())
                    .eq(CounterInformation::getOrgOfficeId, request.getOrgOfficeCode());
            if (StringUtils.isNotBlank(request.getCounterId())) {
                queryWrapper.and(c -> c.like(CounterInformation::getCounterId, request.getCounterId())
                        .or().like(CounterInformation::getCounterName, request.getCounterId()));
            }
            if (request.getOrgType() != null) {
                queryWrapper.eq(CounterInformation::getCounterType, deptType);
            }
            if (request.getOrgStatus() != null) {
                queryWrapper.eq(CounterInformation::getIsDel, deptStatus);
            }
            list = counterMapper.selectList(queryWrapper);
        } else if (StringUtils.isNotBlank(request.getOrgAreaCode()) && StringUtils.isBlank(request.getOrgOfficeCode()) && StringUtils.isBlank(request.getOrgPrincipalCode())) {
            //如果大区不为空，柜台主管和办事处为空
            LambdaQueryWrapper<CounterInformation> queryWrapper = Wrappers.<CounterInformation>lambdaQuery()
                    .eq(CounterInformation::getOrgAreaId, request.getOrgAreaCode());
            if (StringUtils.isNotBlank(request.getCounterId())) {
                queryWrapper.and(c -> c.like(CounterInformation::getCounterId, request.getCounterId())
                        .or().like(CounterInformation::getCounterName, request.getCounterId()));
            }
            if (request.getOrgType() != null) {
                queryWrapper.eq(CounterInformation::getCounterType, deptType);
            }
            if (request.getOrgStatus() != null) {
                queryWrapper.eq(CounterInformation::getIsDel, deptStatus);
            }
            list = counterMapper.selectList(queryWrapper);
        }
        /*
        //此处代码先留着，如果上面的代码查询结果不正确，则用下面的方法
        //如果大区不为空,判断办事处不为空
        else if (StringUtils.isNotBlank(request.getOrgOfficeCode())) {
            //如果柜台主管不为空
            if (StringUtils.isNotBlank(request.getOrgPrincipalCode())) {
                //查询所有的柜台
                LambdaQueryWrapper<CounterInformation> queryWrapper = Wrappers.<CounterInformation>lambdaQuery()
                        .eq(CounterInformation::getOrgMasterId, request.getOrgPrincipalCode());
                if (request.getOrgType() != null) {
                    queryWrapper.eq(CounterInformation::getCounterType, deptType);
                }
                if (request.getOrgStatus() != null) {
                    queryWrapper.eq(CounterInformation::getIsDel, deptStatus);
                }
                list = counterMapper.selectList(queryWrapper);
            } else {
                //查询下属所有的柜台主管
                LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery()
                        .eq(Department::getUpDeptId, request.getOrgOfficeCode())
                        .eq(Department::getDeptType, DepartmentEnum.COUNTER_SUPERVISOR.getKey());
                if (request.getOrgType() != null) {
                    queryWrapper.eq(Department::getIsTest, request.getOrgType());
                }
                if (request.getOrgStatus() != null) {
                    queryWrapper.eq(Department::getStatus, request.getOrgStatus());
                }
                List<Department> masterList = departmentMapper.selectList(queryWrapper);
                //柜台
                list = getCounterList(masterList, deptStatus, deptType);
            }
        } else {
            //办事处为空，则查询下属所有的办事处
            LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery()
                    .eq(Department::getUpDeptId, request.getOrgAreaCode())
                    .eq(Department::getDeptType, DepartmentEnum.OFFICE.getKey());
            if (request.getOrgType() != null) {
                queryWrapper.eq(Department::getIsTest, request.getOrgType());
            }
            if (request.getOrgStatus() != null) {
                queryWrapper.eq(Department::getStatus, request.getOrgStatus());
            }
            List<Department> officeList = departmentMapper.selectList(queryWrapper);
            //获取办事处的id列表
            List<String> officeIdList = officeList.stream().map(e -> e.getDeptId()).collect(Collectors.toList());
            //查询下属所有的柜台主管
            LambdaQueryWrapper<Department> wrapper = Wrappers.<Department>lambdaQuery()
                    .in(Department::getUpDeptId, officeIdList)
                    .eq(Department::getDeptType, DepartmentEnum.COUNTER_SUPERVISOR.getKey());
            if (request.getOrgType() != null) {
                wrapper.eq(Department::getIsTest, request.getOrgType());
            }
            if (request.getOrgStatus() != null) {
                wrapper.eq(Department::getStatus, request.getOrgStatus());
            }
            List<Department> masterList = departmentMapper.selectList(wrapper);
            //柜台
            list = getCounterList(masterList, deptStatus, deptType);
        }*/
        return list;
    }

    /**
     * 根据部门主管id获取柜台
     *
     * @param masterList
     * @return
     */
    private List<CounterInformation> getCounterList(List<Department> masterList, Integer deptStatus, Integer deptType) {
        //获取柜台主管的id列表
        List<String> masterIdList = masterList.stream().map(Department::getDeptId).collect(Collectors.toList());
        //查询条件
        LambdaQueryWrapper<CounterInformation> queryWrapper = Wrappers.<CounterInformation>lambdaQuery()
                .in(CounterInformation::getOrgMasterId, masterIdList);
        if (deptType != null) {
            queryWrapper.eq(CounterInformation::getCounterType, deptType);
        }
        if (deptStatus != null) {
            queryWrapper.eq(CounterInformation::getIsDel, deptStatus);
        }
        //查询所有的柜台
        List<CounterInformation> counterInfoList = counterMapper.selectList(queryWrapper);
        return counterInfoList;
    }

    /**
     * erp模块中查询条件：获取柜台,部门不支持跳级选择，选择大区的时候默认传入HZYJ
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response queryLowerDept(QueryLowerDeptRequest request) {
        List<Department> masterList = this.extractDepartmentList(request);
        return Response.success(ObjectUtils.toList(masterList, DeptVo.class));
    }

    /**
     * 构建部门查询结果
     *
     * @param request
     * @return
     */
    private List<Department> extractDepartmentList(QueryLowerDeptRequest request) {
        //查询条件
        LambdaQueryWrapper<Department> queryWrapper = Wrappers.<Department>lambdaQuery()
                .eq(Department::getUpDeptId, request.getDeptId())
                .eq(Department::getDeptType, request.getType());
        if (request.getDeptStatus() != null) {
            queryWrapper.eq(Department::getStatus, request.getDeptStatus());
        }
        if (request.getDeptType() != null) {
            queryWrapper.eq(Department::getIsTest, request.getDeptType());
        }
        return departmentMapper.selectList(queryWrapper);
    }

    /**
     * erp模块中查询条件：柜台查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response queryCounter(OrgQueryConditionRequest request) {
        List<CounterInformation> list = queryDepAndCounter(request);
        return Response.success(ObjectUtils.toList(list, CounterCommonVo.class));
    }

    /**
     * BI报表中组织机构查询
     *
     * @param request
     * @return
     */
    public Response biDept(QueryLowerDeptRequest request) {
        //返回前端列表
        List<DeptVo> voList = new ArrayList<>();
        //获取到当前登录人的信息查询关注部门信息
        List<UserConcernPo> concernPoList = userConcernMapper.selectList(Wrappers.<UserConcernPo>lambdaQuery()
                .eq(UserConcernPo::getEmpId, AdminUserContextHolder.get().getEmpId())
                //根据部门类型升序排序
                .orderByAsc(UserConcernPo::getDeptType));
        //如果关注部门为空，则返回空
        if (concernPoList.isEmpty()) {
            return Response.success(voList);
        }
        //如果不为空，则进行遍历判断
        for (UserConcernPo userConcernPo : concernPoList) {
            //如果该部门类型为品牌总部，则直接进行数据查询，同时将结果返回
            if (userConcernPo.getDeptType().equals(DepartmentEnum.HEADQUARTERS.getKey())) {
                //数据查询
                List<Department> masterList = departmentMapper.selectList(Wrappers.<Department>lambdaQuery()
                        .eq(Department::getUpDeptId, request.getDeptId()));
                return Response.success(ObjectUtils.toList(masterList, DeptVo.class));
            }
            //根据部门id查询部门信息
            Department department = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery()
                    .eq(Department::getDeptId, userConcernPo.getDeptCode())
                    .select(Department::getUpDeptId));
            //未查询到信息则结束当前查询，继续循环查询
            if (department == null || StringUtils.isBlank(department.getUpDeptId())) {
                continue;
            }
            //根据部门类型进行判断
            if (request.getType().equals(userConcernPo.getDeptType()) && department.getUpDeptId().equals(request.getDeptId())) {
                //如果相等就转换成vo并添加
                DeptVo deptVo = DeptVo.builder()
                        .deptId(userConcernPo.getDeptCode())
                        .deptName(userConcernPo.getDeptName())
                        .deptType(userConcernPo.getDeptType()).build();
                //添加到list表中，需要进行判断是否已存在，不存在就添加进去
                if (!voList.contains(deptVo)) {
                    voList.add(deptVo);
                }
            } else if (request.getType() < userConcernPo.getDeptType()) {
                //如果小于关注部门的类型，则需要查询上级部门进行判断
                DeptVo deptVo = getUpDept(request.getType(), department.getUpDeptId(), request.getDeptId());
                //添加到list表中，需要进行判断是否已存在，不存在就添加进去
                if (deptVo != null && !voList.contains(deptVo)) {
                    voList.add(deptVo);
                }
            } else {
                //如果大于关注部门的类型，则需要查询下级部门进行判断
                List<DeptVo> deptVoList = getLowerDept(request.getType(), userConcernPo.getDeptCode(), request.getDeptId());
                //添加到list表中，需要进行判断是否已存在，不存在就添加进去
                if (!deptVoList.isEmpty()) {
                    for (DeptVo deptVo : deptVoList) {
                        if (!voList.contains(deptVo)) {
                            voList.add(deptVo);
                        }
                    }
                }
            }
        }
        return Response.success(voList);
    }

    /**
     * 递归查询部门的上级部门，直到查询到类型相等的情况
     *
     * @param type
     * @param deptCode
     * @return
     */
    private List<DeptVo> getLowerDept(Integer type, String deptCode, String deptId) {
        //返回前端列表
        List<DeptVo> voList = new ArrayList<>();
        //根据当前部门信息查询上级部门信息
        List<Department> departmentList = departmentMapper.selectList(Wrappers.<Department>lambdaQuery()
                .eq(Department::getUpDeptId, deptCode));
        for (Department department : departmentList) {
            //如果下级部门的类型与查询的类型一致，则添加到返回list中
            if (department.getDeptType().equals(type) && department.getUpDeptId().equals(deptId)) {
                //如果相等就转换成vo并添加
                DeptVo deptVo = DeptVo.builder()
                        .deptId(department.getDeptId())
                        .deptName(department.getDeptName())
                        .deptType(department.getDeptType()).build();
                //添加到list表中，需要进行判断是否已存在，不存在就添加进去
                if (!voList.contains(deptVo)) {
                    voList.add(deptVo);
                }
            } else if (department.getDeptType() < type) {
                //如果查询出来类型仍大于，则递归查询
                List<DeptVo> lowerDept = getLowerDept(type, department.getDeptId(), deptId);
                //将查询出来的结果加到返回list中
                for (DeptVo deptVo : lowerDept) {
                    if (!voList.contains(deptVo)) {
                        voList.add(deptVo);
                    }
                }
            } else {
                continue;
            }
        }
        return voList;
    }

    /**
     * 递归查询部门的上级部门，直到查询到类型相等的情况
     *
     * @param type
     * @param deptCode
     * @return
     */
    private DeptVo getUpDept(Integer type, String deptCode, String deptId) {
        //根据当前部门信息查询上级部门信息
        Department upDept = departmentMapper.selectOne(Wrappers.<Department>lambdaQuery().eq(Department::getDeptId, deptCode));
        if (upDept.getDeptType().equals(type) && upDept.getUpDeptId().equals(deptId)) {
            return DeptVo.builder()
                    .deptId(upDept.getDeptId())
                    .deptName(upDept.getDeptName())
                    .deptType(upDept.getDeptType()).build();
        } else if (upDept.getDeptType() < type) {
            return null;
        } else {
            return getUpDept(type, upDept.getUpDeptId(), deptId);
        }
    }

    /**
     * BI报表中查询：获取BA
     *
     * @param request
     * @return
     */
    public Response biBa(QueryLowerDeptRequest request) {
        List<UserCounter> userCounters = userCounterMapper.selectList(Wrappers.<UserCounter>lambdaQuery()
                .eq(UserCounter::getCounterCode, request.getDeptId()));
        if (userCounters.isEmpty()) {
            return Response.success();
        }
        return Response.success(ObjectUtils.toList(userCounters, CommonUserVo.class));
    }

    /**
     * 临时权限中查询组织机构使用
     *
     * @param status 状态
     * @return deptVoList
     */
    public Response departmentAuthority(Integer status) {
        //查询部门信息
        List<Department> list = departmentMapper.selectList(Wrappers.<Department>lambdaQuery()
                .eq(Department::getStatus, status));
        //返回
        List<DeptVo> deptVoList = ObjectUtils.toList(list, DeptAllVo.class);
        return Response.success(deptVoList);
    }
}
