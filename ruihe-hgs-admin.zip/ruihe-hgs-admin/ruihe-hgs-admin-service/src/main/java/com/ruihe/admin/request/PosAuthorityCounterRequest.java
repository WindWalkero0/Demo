package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author 梁远
 * @Description 新增临时权限子表请求实体
 * @date 2019-12-10 10:07
 */
@ApiModel(value = "PosAuthorityCounterRequest", description = "新增临时权限子表请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PosAuthorityCounterRequest implements Serializable {

    @ApiModelProperty(value = "柜台id")
    private String counterId;

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "等级类型")
    @NotNull(message = "等级类型不能为空")
    private Integer deptType;

    @ApiModelProperty(value = "大区code")
    private String areaCode;

    @ApiModelProperty(value = "大区名称")
    private String areaName;
}
