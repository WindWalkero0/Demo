package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-31 11:29
 */
@ApiModel(value = "UpDepartmentRequest", description = "上级部门选择请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class UpDepartmentRequest implements Serializable {

    @ApiModelProperty(value = "部门类型")
    private Integer deptType;
    @ApiModelProperty(value = "部门名称")
    private String deptName;
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
