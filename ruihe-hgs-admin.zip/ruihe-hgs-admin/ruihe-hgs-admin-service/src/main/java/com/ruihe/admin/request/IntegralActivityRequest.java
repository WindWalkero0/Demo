package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * <p>
 * 积分规则新增/修改请求
 * </p>
 *
 * @author William
 * @since 2019-10-28
 */
@ApiModel(value = "IntegralActivityRequest", description = "积分规则新增/修改请求")
@Data
@Builder
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
public class IntegralActivityRequest implements Serializable {

    @ApiModelProperty(value = "积分规则id")
    private Integer integralActivityId;

    @ApiModelProperty(value = "积分规则名称")
    @NotBlank(message = "积分规则名称不能为空")
    @Size(max=60,message = "积分规则名称最大长度为60个字符")
    private String activityName;

    @ApiModelProperty(value = "规则开始时间")
    private LocalDate startTime;

    @ApiModelProperty(value = "规则结束时间")
    @Builder.Default
    private LocalDate endTime = LocalDate.of(9999, 12, 31);

    @ApiModelProperty(value = "规则停用时间")
    @Builder.Default
    private LocalDate disableTime = LocalDate.of(9999, 12, 31 );

    @ApiModelProperty(value = "规则类型,1普通规则,2附属规则,3默认规则")
    private Integer ruleType;

    @ApiModelProperty(value = "规则模板：normal一般积分,birthday会员生日,special_goods特定商品,special_time特定时间,default默认规则")
    private String ruleTpl;

    @ApiModelProperty(value = "附属方式：0无,1替换主规则计算结果,2累加主规则计算结果")
    private Integer attachWay;

    @ApiModelProperty(value = "规则描述")
    @Size(max=100,message = "规则描述最大长度为100个字符")
    private String activityDesc;

    @ApiModelProperty(value = "是否同时执行默认规则,false不执行,true执行，默认不执行")
    private Boolean runDefaultRule;

    @ApiModelProperty(value = "规则json配置")
    private String ruleConf;

}
