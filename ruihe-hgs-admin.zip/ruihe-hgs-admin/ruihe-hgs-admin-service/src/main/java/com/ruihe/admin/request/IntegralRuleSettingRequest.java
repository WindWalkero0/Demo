package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 积分规则设置请求实体
 *
 * @author William
 */
@ApiModel(value = "IntegralRuleSettingRequest", description = "积分规则设置请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IntegralRuleSettingRequest implements Serializable {
    @ApiModelProperty(value = "主规则调序id列表")
    private List<Integer> seq;
    @ApiModelProperty(value = "停用规则id列表")
    private List<Integer> disableList;
    @ApiModelProperty(value = "主附属修改附属规则映射")
    private Map<String, List<Integer>> relation;
}
