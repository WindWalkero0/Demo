package com.ruihe.admin.event;

import com.ruihe.msger.dto.MsgerRequestDto;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * @author LiangYuan
 * @date 2021-03-16 9:33
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class MsgEvent extends ApplicationEvent {

    private MsgerRequestDto msgerRequestDto;

    public MsgEvent(Object source, MsgerRequestDto msgerRequestDto) {
        super(source);
        this.msgerRequestDto = msgerRequestDto;
    }
}
