package com.ruihe.admin.listener.excel;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.google.common.collect.Lists;
import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.TransferItemExcelEvent;
import com.ruihe.admin.listener.style.CellStyleUtils;
import com.ruihe.admin.listener.style.CustomHorizontalCellStyleStrategy;
import com.ruihe.admin.mapper.erp.document.WhTransferMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.request.erp.TransferRequest;
import com.ruihe.admin.response.erp.TransferItemExcelResponse;
import com.ruihe.admin.utils.ColumnWidthStyleStrategy;
import com.ruihe.admin.utils.ExcelImgUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

/***
 * 调拨单主表excel导出
 * @author ly
 */
@Slf4j
@Component
public class TransferItemExcelListener extends AbstractReportListener<TransferItemExcelEvent> {

    @Autowired
    private WhTransferMapper whTransferMapper;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(TransferItemExcelEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    protected void doExport(TransferItemExcelEvent event, BiReportPo report, boolean flag) {
        //根据条件查询数据
        TransferRequest request = (TransferRequest) redisTemplate.opsForValue().get(event.getKey());
        //输出格式
        List<Class<?>> dataTypes = getDataTypesList();
        CustomHorizontalCellStyleStrategy cellStyle = CellStyleUtils.customHorizontalCellStyleStrategy(TransferItemExcelResponse.class, dataTypes);
        //获取导出实体list
        List<TransferItemExcelResponse> list = whTransferMapper.itemListExcel(request, request.getOrgQueryConditionRequest());
        //excel导出
        ExcelWriter excelWriter = EasyExcel.write(report.getFilePath())
                .inMemory(true)
                .build();
        WriteSheet writeSheet = EasyExcel.writerSheet("第1～" + list.size() + "条")
                .sheetNo(0)
                .head(TransferItemExcelResponse.class)
                .registerWriteHandler(cellStyle)
                .registerWriteHandler(new ColumnWidthStyleStrategy())
                .automaticMergeHead(true)
                .build();
        excelWriter.write(list, writeSheet);
        //查询图片
        ExcelImgUtils.CreatImgSheet(this.imgPath, report.getPicUrl(), excelWriter);
        //释放资源
        excelWriter.finish();
    }

    /**
     * 数据类型设置
     *
     * @return
     */
    private List<Class<?>> getDataTypesList() {
        List<Class<?>> dataType = Lists.newArrayList();
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(Integer.class);
        dataType.add(BigDecimal.class);
        dataType.add(BigDecimal.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        return dataType;
    }

}
