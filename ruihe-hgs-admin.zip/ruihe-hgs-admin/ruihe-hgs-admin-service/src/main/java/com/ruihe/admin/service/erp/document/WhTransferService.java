package com.ruihe.admin.service.erp.document;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.request.ExportExcelRequest;
import com.ruihe.admin.service.bi.AbstractBiReportPreHandler;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.warehouse.WhTransferItemPo;
import com.ruihe.common.dao.bean.warehouse.WhTransferPo;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.admin.enums.BiReportEnum;
import com.ruihe.admin.event.TransferItemExcelEvent;
import com.ruihe.admin.event.TransferMasterExcelEvent;
import com.ruihe.admin.mapper.basic.ProductMapper;
import com.ruihe.admin.mapper.erp.document.WhTransferItemMapper;
import com.ruihe.admin.mapper.erp.document.WhTransferMapper;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.request.erp.TransferRequest;
import com.ruihe.admin.response.erp.WhTransferQueryResponse;
import com.ruihe.admin.response.erp.WhTransferResponse;
import com.ruihe.admin.response.erp.WhTransferResultResponse;
import com.ruihe.admin.vo.WhTransferItemVo;
import com.ruihe.admin.vo.WhTransferVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * 进销存管理->调拨单处理
 *
 * @Anthor:Fangtao
 * @Date:2019/11/22 9:30
 */
@Service
@Slf4j
public class WhTransferService extends AbstractBiReportPreHandler {
    @Autowired
    private WhTransferMapper whTransferMapper;

    @Autowired
    private WhTransferItemMapper whTransferItemMapper;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    /**
     * 通过申请单号查看详情
     */
    @DS(DBConst.SLAVE)
    public Response selectDetail(String transferOrderNo) {
        //获取主表信息
        WhTransferPo whTransferPo = whTransferMapper.selectOne(Wrappers.<WhTransferPo>lambdaQuery()
                .eq(WhTransferPo::getTransferOrderNo, transferOrderNo));
        //查询子表信息
        List<WhTransferItemPo> itemPoList = whTransferItemMapper.selectList(Wrappers.<WhTransferItemPo>lambdaQuery()
                .eq(WhTransferItemPo::getTransferOrderNo, transferOrderNo));
        List<WhTransferItemVo> list = ObjectUtils.toList(itemPoList, WhTransferItemVo.class);
        list.forEach(e -> {
            e.setRealAmt(e.getMemberPrice().multiply(BigDecimal.valueOf(e.getInQty())));
        });
        //返回前端
        WhTransferVo whTransferVo = ObjectUtils.toObject(whTransferPo, WhTransferVo.class);
        whTransferVo.setItemVoList(list);
        WhTransferVo total = itemPoList.parallelStream()
                .map(e -> WhTransferVo.builder().ackAmount(e.getMemberPrice().multiply(BigDecimal.valueOf(e.getInQty()))).inGoodsQty(e.getInQty()).build())
                .reduce((acc, item) -> {
                    acc.setInGoodsQty(item.getInGoodsQty() + acc.getInGoodsQty());
                    acc.setAckAmount(item.getAckAmount().add(acc.getAckAmount()));
                    return acc;
                }).get();
        itemPoList.stream().map(e -> {
            WhTransferItemVo whTransferItemVo = new WhTransferItemVo();
            BeanUtils.copyProperties(e, whTransferItemVo);
            Product product = productMapper.selectOne(Wrappers.<Product>lambdaQuery().eq(Product::getPrdBarCode, e.getPrdBarCode()));
            whTransferItemVo.setUnitName(product.getUnitName());
            whTransferItemVo.setSpec(product.getSpec());
            whTransferItemVo.setMemberPrice(e.getMemberPrice().multiply(BigDecimal.valueOf(e.getInQty())));
            return whTransferItemVo;
        }).collect(Collectors.toList());
        whTransferVo.setAckAmount(total.getAckAmount());
        whTransferVo.setInGoodsQty(total.getInGoodsQty());
        return Response.success(whTransferVo);
    }

    /**
     * 调拨单处理条件查询
     */
    @DS(DBConst.SLAVE)
    public Response selectTransfer(TransferRequest request) {
        //对日期和页码进行判断
        if (request.getStartTime() != null && request.getEndTime() != null && request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("开始时间不能大于结束时间!");
        }
        if (request.getPageNumber() == null || request.getPageSize() == null || request.getPageSize() == 0 || request.getPageNumber() == 0) {
            return Response.errorMsg("页码不合法!");
        }
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        //获取组织条件查询
        OrgQueryConditionRequest queryRequest = request.getOrgQueryConditionRequest();
        //柜台的状态、类型跟部门的不一致，此处需要转换
        doOrgQueryConditionRequest(queryRequest);
        //设置分页条件
        Page<WhTransferQueryResponse> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询出列表
        IPage<WhTransferQueryResponse> voList = whTransferMapper.queryWhTransfer(page, request, queryRequest);
        //分页展示vo
        PageVO pageVO = PageVO.<WhTransferQueryResponse>builder()
                .list(voList.getRecords())
                .pageNum(voList.getCurrent())
                .pageSize(voList.getSize())
                .pages(voList.getPages())
                .total(voList.getTotal())
                .build();
        //记录查询条件
        String uuid = IdGenerator.getShorterSerialNo("ADMIN:TF");
        //存储redis
        redisTemplate.opsForValue().set(uuid, request, 2, TimeUnit.HOURS);
        WhTransferResultResponse whTransferResultResponse = whTransferMapper.queryResult(request, queryRequest);
        return Response.success(WhTransferResponse.builder()
                .whTransferResultResponse(whTransferResultResponse)
                .pageVo(pageVO).key(uuid).build());
    }

    /**
     * 调拨单主表导出
     *
     * @param request
     * @return
     */
    public Response exportMaster(ExportExcelRequest request) {
        TransferRequest transferRequest = (TransferRequest) redisTemplate.opsForValue().get(request.getKey());
        //判空
        if (transferRequest == null) {
            return Response.errorMsg("查询条件已过期，请重新进行查询!");
        }
        //获取组织条件查询
        OrgQueryConditionRequest queryRequest = transferRequest.getOrgQueryConditionRequest();
        //查询总数量
        Long count = whTransferMapper.queryListCount(transferRequest, queryRequest);
        if (count > 50000) {
            return Response.errorMsg("导出数据不能超过5万条!");
        }
        if (count == 0) {
            return Response.errorMsg("未查询到数据!");
        }
        TransferMasterExcelEvent event = TransferMasterExcelEvent.builder().key(request.getKey()).build();
        publishEvent(BiReportEnum.TRANSFER_MASTER, event, request.getRemark(), request.getPicUrl());
        return Response.successMsg("导出成功，请到下载中心进行下载!");
    }

    /**
     * 对柜台状态进行处理转换
     *
     * @param queryRequest
     */
    private void doOrgQueryConditionRequest(OrgQueryConditionRequest queryRequest) {
        //柜台的状态、类型跟部门的不一致，此处需要转换
        if (queryRequest != null && queryRequest.getOrgType() != null) {
            queryRequest.setOrgType(queryRequest.getOrgType().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CounterEnum.FORMAL_COUNTER.getKey() : CounterEnum.TEST_COUNTER.getKey());
        }
        if (queryRequest != null && queryRequest.getOrgStatus() != null) {
            queryRequest.setOrgStatus(queryRequest.getOrgStatus().equals(CommonStatusEnum.EFFECTIVE.getCode()) ? CommonStatusEnum.INVALID.getCode() : CommonStatusEnum.EFFECTIVE.getCode());
        }
    }

    /**
     * 调拨单子表导出
     *
     * @param request
     * @return
     */
    public Response exportItem(ExportExcelRequest request) {
        TransferRequest transferRequest = (TransferRequest) redisTemplate.opsForValue().get(request.getKey());
        //判空
        if (transferRequest == null) {
            return Response.errorMsg("查询条件已过期，请重新进行查询!");
        }
        //获取组织条件查询
        OrgQueryConditionRequest queryRequest = transferRequest.getOrgQueryConditionRequest();
        //查询总数量
        Long count = whTransferMapper.queryItemListCount(transferRequest, queryRequest);
        if (count > 50000) {
            return Response.errorMsg("导出数据不能超过5万条!");
        }
        if (count == 0) {
            return Response.errorMsg("未查询到数据!");
        }
        TransferItemExcelEvent event = TransferItemExcelEvent.builder().key(request.getKey()).build();
        publishEvent(BiReportEnum.TRANSFER_ITEM, event, request.getRemark(), request.getPicUrl());
        return Response.successMsg("导出成功，请到下载中心进行下载!");
    }
}
