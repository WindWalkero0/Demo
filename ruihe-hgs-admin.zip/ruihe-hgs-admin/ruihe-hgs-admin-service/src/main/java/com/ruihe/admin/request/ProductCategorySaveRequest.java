package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Data
@ApiModel(description = "添加/修改产品分类")
public class ProductCategorySaveRequest implements Serializable {
    @ApiModelProperty(value = "分类Id, 修改的时候id不能为空")
    private Integer id;

    @NotBlank
    @Size(min = 1, max = 15, message = "分类名称长度只能在1到15个字之间")
    @ApiModelProperty(value = "分类名称")
    private String name;

    @ApiModelProperty(value = "父类Id,如果是第一级分类，传0, 修改的时候可以不传")
    private Integer parentId;

    @ApiModelProperty(value = "有效无效，0表示无效，1表示有效")
    private Integer deleted;
}
