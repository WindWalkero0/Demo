package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 自由盘点主表excel导出
 *
 * @author ly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class FreeInvItemExcelEvent extends BiReportEvent {

    private String key;

    @Builder
    public FreeInvItemExcelEvent(String key) {
        this.key = key;
    }
}
