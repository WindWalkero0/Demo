package com.ruihe.admin.response;


import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

@ApiModel(value = "PosMessageResponse", description = "消息响应实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosBannerResponse implements Serializable {
    @ApiModelProperty(value = "bannerId")
    private Integer bannerId;
    @ApiModelProperty(value = "banner标题")
    private String title;
    @ApiModelProperty(value = "所属模块")
    private String bannerType;
    @ApiModelProperty(value = "链接url")
    private String linkUrl;
    @ApiModelProperty(value = "排序序号")
    private Integer sortNum;
    @ApiModelProperty(value = "状态：0有效,1无效")
    private Integer status;
    @ApiModelProperty(value = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;
    @ApiModelProperty(value = "图片url")
    private String imgUrl;
}
