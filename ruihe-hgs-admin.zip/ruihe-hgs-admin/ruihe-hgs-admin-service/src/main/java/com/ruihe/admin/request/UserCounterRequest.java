package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-30 15:41
 */
@ApiModel(value = "UserCounterRequest", description = "用户工作柜台请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class UserCounterRequest implements Serializable {

    @ApiModelProperty("用户唯一键")
    private Integer empId;

    @ApiModelProperty("员工姓名")
    private String name;

    @ApiModelProperty("手机号码")
    private String phoneNo;

    @ApiModelProperty("部门代码")
    private String counterCode;

    @ApiModelProperty("部门名称")
    private String counterName;

    @ApiModelProperty("是否是店长")
    private Integer isMaster;
}
