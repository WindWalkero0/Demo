package com.ruihe.admin.listener.report.utils;

import com.ruihe.common.constant.CommonConstant;
import lombok.val;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.SignStyle;
import java.time.temporal.ChronoField;
import java.util.function.Consumer;

public class DateUtils {
    public static final DateTimeFormatter dfDay = DateTimeFormatter.ofPattern("yyyyMMdd");
    public static final DateTimeFormatter dfMonth = DateTimeFormatter.ofPattern("yyyyMM");

    public static String formatMonth(LocalDate date) {
        return dfMonth.format(date);
    }

    public static String formatDay(LocalDate date) {
        return dfDay.format(date);
    }

    public static String formatMonth25(LocalDate date) {
        if (date.getDayOfMonth() > CommonConstant.TEWENTY_FIVE) {
            date = date.plusMonths(1);
        }
        return dfMonth.format(date);
    }


    public static LocalDate toMonth(String txt) {
        DateTimeFormatter dtf = new DateTimeFormatterBuilder()
                .appendValue(ChronoField.YEAR, 4, 10, SignStyle.EXCEEDS_PAD)
                .appendValue(ChronoField.MONTH_OF_YEAR, 2)
                .toFormatter();
        val temporalAccessor = dtf.parse("202006");
        val year = temporalAccessor.get(ChronoField.YEAR);
        val month = temporalAccessor.get(ChronoField.MONTH_OF_YEAR);
        return LocalDate.of(year, month, 1);
    }

    public static LocalDate toDay(String txt) {
        return LocalDate.parse(txt, dfDay);
    }

    public static void stepByDay(LocalDate startTime, LocalDate endTime, Consumer<LocalDate> consumer) {
        LocalDate tempDate = startTime;
        while (tempDate.isBefore(endTime.plusDays(1)) && !tempDate.isAfter(LocalDate.now())) {
            consumer.accept(tempDate);
            tempDate = tempDate.plusDays(1);
        }
    }

    public static void stepByMonth(LocalDate startTime, LocalDate endTime, Consumer<LocalDate> consumer) {
        LocalDate tempDate = startTime;
        LocalDate month = null;
        LocalDate end = endTime.plusDays(1);
        while (tempDate.isBefore(end) && !tempDate.isAfter(LocalDate.now())) {
            LocalDate m = LocalDate.of(tempDate.getYear(), tempDate.getMonth(), 1);
            if (tempDate.getDayOfMonth() > CommonConstant.TEWENTY_FIVE) {
                m = m.plusMonths(1);
            }
            if (month == null || m.isAfter(month)) {
                month = m;
                consumer.accept(month);
            }
            tempDate = tempDate.plusDays(1);
        }
    }
}
