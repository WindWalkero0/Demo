package com.ruihe.admin.service.bi;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.request.BiReportRequest;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.admin.enums.BiReportStatusEnum;
import com.ruihe.admin.mapper.bi.BiReportMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;
import com.ruihe.admin.vo.BiReportVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author: ly
 * @Date: 2020-02-13 9:47
 * @Description 下载中心
 */
@Service
@Slf4j
public class BiReportService {

    @Autowired
    private BiReportMapper biReportMapper;

    @Value("${file-upload.static-root-url}%s")
    protected String rootUrl;

    public Response search(BiReportRequest request) {
        //查询时间判断
        if (request.getStartTime() == null || request.getEndTime() == null) {
            return Response.errorMsg("查询时间不能为空!");
        }
        if (request.getStartTime().isAfter(request.getEndTime())) {
            return Response.errorMsg("开始时间不能大于结束时间!");
        }
        if (request.getEndTime().isAfter(LocalDate.now())) {
            return Response.errorMsg("查询时间不能大于当前时间!");
        }
        //判断页数和页码
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            return Response.errorMsg("页数||页码不能为空!");
        }
        //设置分页显示条件
        Page<BiReportPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //上面已经对时间进行了判空，此处直接设置查询时间
        request.setEndTime(request.getEndTime().plusDays(1));
        //查询条件
        LambdaQueryWrapper<BiReportPo> queryWrapper = Wrappers.<BiReportPo>lambdaQuery()
                //用户信息
                .eq(BiReportPo::getUid, AdminUserContextHolder.get().getEmpId())
                //时间范围
                .between(BiReportPo::getCreateTime, request.getStartTime(), request.getEndTime())
                //查询时间倒序
                .orderByDesc(BiReportPo::getCreateTime);
        //模糊查询报表名称
        if (StringUtils.isNotBlank(request.getReportName())) {
            queryWrapper.like(BiReportPo::getReportName, request.getReportName());
        }
        //分页查询
        IPage<BiReportPo> biReportPoIPage = biReportMapper.selectPage(page, queryWrapper);
        if (biReportPoIPage.getRecords().isEmpty()) {
            return Response.successMsg("暂无数据!");
        }
        List<BiReportVo> list = ObjectUtils.toList(biReportPoIPage.getRecords(), BiReportVo.class);
        list.parallelStream().forEach(e -> e.setUrl(String.format(rootUrl, e.getUrl())));
        //转成VO返回前端
        PageVO pageVO = PageVO.<BiReportVo>builder()
                .list(list)
                .total(biReportPoIPage.getTotal())
                .pageNum(biReportPoIPage.getCurrent())
                .pageSize(biReportPoIPage.getSize())
                .pages(biReportPoIPage.getPages()).build();
        return Response.success(pageVO);
    }

    /**
     * 查询正在导出报表的数量
     *
     * @return
     */
    public Integer getBiReport() {
        return biReportMapper.selectCount(Wrappers.<BiReportPo>lambdaQuery()
                .eq(BiReportPo::getUid, AdminUserContextHolder.get().getEmpId())
                .eq(BiReportPo::getStatus, BiReportStatusEnum.INITIALIZATION.getCode()));
    }

}
