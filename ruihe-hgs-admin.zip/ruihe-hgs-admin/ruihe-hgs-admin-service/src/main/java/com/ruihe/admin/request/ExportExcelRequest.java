package com.ruihe.admin.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@ApiModel(value = "ExportExcelRequest", description = "报表下载请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExportExcelRequest implements Serializable {
    @ApiModelProperty(value = "key值")
    @NotBlank(message = "key不能为空")
    private String key;

    @ApiModelProperty(value = "备注")
    @NotBlank(message = "备注不能为空")
    private String remark;

    @ApiModelProperty(value = "图片地址")
    private String picUrl;
}
