package com.ruihe.admin.event;

import com.ruihe.admin.request.bi.ProductErpReportRequest;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 产品导出
 *
 * @author ly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class Report4ProductErpEvent extends BiReportEvent {

    private ProductErpReportRequest request;

    @Builder
    public Report4ProductErpEvent(ProductErpReportRequest request) {
        this.request = request;
    }
}
