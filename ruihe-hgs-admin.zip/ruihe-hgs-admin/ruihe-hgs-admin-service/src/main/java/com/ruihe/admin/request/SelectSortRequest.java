package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-06 9:03
 */
@ApiModel(value = "SelectSortRequest", description = "查询产品分类信息请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SelectSortRequest implements Serializable {

    @ApiModelProperty(value = "上级分类代码，默认传0，查询全部的时候设置为空")
    private List<Integer> sortList;

    @ApiModelProperty(value = "显示分类的类型:1大分类，2中分类，3小分类")
    private Integer type;

    @ApiModelProperty("是否绑定：0不绑定，1绑定，查询全部的时候设置为空")
    private Integer isPrdBinded;

    @ApiModelProperty("名称模糊查询")
    private String sortName;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
