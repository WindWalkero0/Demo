package com.ruihe.admin.service.basic;

import com.ruihe.admin.listener.report.utils.DateUtils;
import com.ruihe.admin.mapper.basic.ProductCategoryMapper;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.response.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.LocalDateTime;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;


@Slf4j
@Service
@RequiredArgsConstructor
public class ProductCategoryUpdater {
    private final ProductCategoryMapper categoryMapper;
    private final TransactionTemplate transactionTemplate;
    private volatile boolean stop = false;
    private final ExecutorService executorService = Executors.newFixedThreadPool(3);

    public Response stop() throws BizException {
        stop = true;
        running1.set(false);
        running2.set(false);
        running3.set(false);
        return Response.success();
    }


    private final AtomicBoolean running1 = new AtomicBoolean(false);

    public void updateStock() throws BizException {
        if (!running1.compareAndSet(false, true)) {
            return;
        }

        executorService.submit(() -> {
            LocalDateTime start = LocalDateTime.of(2020, 5, 26, 0, 0, 0);
            LocalDateTime end = LocalDateTime.now().plusDays(1);
            int count = 0;
            while (!stop && start.isBefore(end)) {
                var start1Tmp = start;
                try {
                    Integer num = transactionTemplate.execute(s -> categoryMapper.updateStockCategory(start1Tmp, start1Tmp.plusDays(1)));
                    if (num != null)
                        count += num;
                    log.info("updateStockCategory count " + count + " time " + DateUtils.formatDay(start1Tmp.toLocalDate()));

                } catch (Exception e) {
                    log.error("更新库存分类出错", e);
                }
                start = start.plusDays(1);
            }
            stop = false;
            running1.set(false);
        });
    }

    private final AtomicBoolean running2 = new AtomicBoolean(false);

    public void updateStockLog() throws BizException {
        if (!running2.compareAndSet(false, true)) {
            return;
        }

        executorService.submit(() -> {
            LocalDateTime start = LocalDateTime.of(2020, 5, 26, 0, 0, 0);
            LocalDateTime end = LocalDateTime.now().plusDays(1);
            int count = 0;
            while (!stop && start.isBefore(end)) {
                var start1Tmp = start;
                try {
                    Integer num = transactionTemplate.execute(s -> categoryMapper.updateStockLogCategory(start1Tmp, start1Tmp.plusDays(1)));
                    if (num != null)
                        count += num;
                    log.info("updateStockCategory count " + count + " time " + DateUtils.formatDay(start1Tmp.toLocalDate()));

                } catch (Exception e) {
                    log.error("更新库存日志分类出错", e);
                }
                start = start.plusDays(1);
            }
            stop = false;
            running2.set(false);
        });
    }

    private final AtomicBoolean running3 = new AtomicBoolean(false);

    public void updateOrderItem() throws BizException {
        if (!running3.compareAndSet(false, true)) {
            return;
        }

        executorService.submit(() -> {
            LocalDateTime start = LocalDateTime.of(2017, 5, 23, 0, 0, 0);
            LocalDateTime end = LocalDateTime.now().plusDays(1);
            int count = 0;
            while (!stop && start.isBefore(end)) {
                var start1Tmp = start;
                try {
                    Integer num = transactionTemplate.execute(s -> categoryMapper.updateOrderItemCategory(start1Tmp, start1Tmp.plusDays(1)));
                    if (num != null)
                        count += num;
                    log.info("updateOrderItemCategory count " + count + " time " + DateUtils.formatDay(start1Tmp.toLocalDate()));

                } catch (Exception e) {
                    log.error("更新订单子表分类出错", e);
                }
                start = start.plusDays(1);
            }
            stop = false;
            running3.set(false);
        });
    }
}
