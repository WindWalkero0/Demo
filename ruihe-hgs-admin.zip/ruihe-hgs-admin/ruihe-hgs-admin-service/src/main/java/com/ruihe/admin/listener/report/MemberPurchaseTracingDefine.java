package com.ruihe.admin.listener.report;

import com.ruihe.admin.listener.report.core.Column;
import com.ruihe.admin.listener.report.core.ColumnDefine;
import com.ruihe.admin.listener.report.core.TableDefine;
import com.ruihe.admin.request.bi.MemberPurchaseSelectRequest;
import com.ruihe.admin.request.bi.MemberPurchaseTraceReportRequest;

import java.math.BigDecimal;

/**
 * 会员购买跟踪报表
 */
public class MemberPurchaseTracingDefine extends TableDefine {
    static Column realAmt = new Column("购买金额", "realAmt", BigDecimal.class);
    static Column goodsQty = new Column("购买数量", "goodsQty", Integer.class);
    static Column orderQty = new Column("购买单数", "orderQty", Integer.class);

    public static TableDefine create(MemberPurchaseTraceReportRequest request) {
        MemberPurchaseSelectRequest selectRequest = request.getSelectRequest();
        MemberPurchaseTracingDefine define = new MemberPurchaseTracingDefine();
        define.addHorizontalColumns(selectRequest);
        define.addVerticalColumns(selectRequest);
        define.addValueColumns(selectRequest);
        define.setStartTime(request.getStartTime());
        define.setEndTime(request.getEndTime());
        define.setMonthly(request.getSelectRequest().isMonthly());
        define.setTotalFlag(TableDefine.TOTAL_ROW);
        return define;
    }

    /**
     * 添加查询字段，不包括统计数值字段
     */
    private void addHorizontalColumns(MemberPurchaseSelectRequest req) {
        this.addHorizontalColumn(ColumnDefine.areaCode.pa(), req.isArea());
        this.addHorizontalColumn(ColumnDefine.areaName.pa(), req.isArea());
        this.addHorizontalColumn(ColumnDefine.officeCode.pa(), req.isOffice());
        this.addHorizontalColumn(ColumnDefine.officeName.pa(), req.isOffice());
        this.addHorizontalColumn(ColumnDefine.principalCode.pa(), req.isPrincipal());
        this.addHorizontalColumn(ColumnDefine.principalName.pa(), req.isPrincipal());
        this.addHorizontalColumn(ColumnDefine.counterId.pa(), req.isCounterId());
        this.addHorizontalColumn(ColumnDefine.counterName.pa(), req.isCounterName());
        this.addHorizontalColumn(ColumnDefine.memberCard.pb(), req.isMemberCardNumber());
        this.addHorizontalColumn(ColumnDefine.memberName.pb(), req.isMemberName());
        this.addHorizontalColumn(ColumnDefine.mobilePhone.pb(), req.isMobilePhone());
    }

    private void addVerticalColumns(MemberPurchaseSelectRequest req) {
        this.addVerticalColumn(ColumnDefine.month, req.isMonthly());
    }

    /**
     * 添加统计数值字段
     */
    private void addValueColumns(MemberPurchaseSelectRequest req) {
        this.addValueColumn(goodsQty, req.isOrderQty());
        this.addValueColumn(realAmt, req.isRealAmt());
        this.addValueColumn(orderQty, req.isOrderQty());
    }
}
