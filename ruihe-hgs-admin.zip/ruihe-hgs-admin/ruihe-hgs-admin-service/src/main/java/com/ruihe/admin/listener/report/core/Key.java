package com.ruihe.admin.listener.report.core;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

@Getter
@Setter
public abstract class Key implements Comparable<Key> {
    /**
     * 普通数据
     */
    public static final int TYPE_NORMAL = 0;

    /**
     * 小计
     */
    public static final int TYPE_SUB_TOTAL = 1;

    /**
     * 总计
     */
    public static final int TYPE_TOTAL = 2;

    // 由 group by 字段的值构建的key，不包括日期相关字段
    // 去除重复的group by，比如柜台号，柜台名group by都是counter_id
    protected String key = "";

    /**
     * 普通数据, 小计, 总计
     */
    protected int type = TYPE_NORMAL;

    protected List<String> displayValues = new ArrayList<>();
    protected List<String> groupValues = new ArrayList<>();

    public Key(){}

    public Key(List<String> groupValues, List<String> displayValues, int type) {
        this.groupValues = groupValues;
        this.displayValues = displayValues;
        this.type = type;
        this.key = String.join("", groupValues);
    }

    /**
     * 针对小计,总计，根据报表配置是否统计小计,总计判断是否输出
     *
     * @param flag TableDefine中定义的totalFlag
     * @return 是否输出到excel
     */
    public boolean showable(int flag) {
        if (this.type == TYPE_NORMAL) {
            return true;
        }
        if (this instanceof RowKey) {
            if (type == TYPE_TOTAL) {
                return (flag & TableDefine.TOTAL_ROW_FULL) != 0;
            } else if (type == TYPE_SUB_TOTAL) {
                return (flag & TableDefine.TOTAL_ROW_SUB) != 0;
            }
        } else if (this instanceof ColKey) {
            if (type == TYPE_TOTAL) {
                return (flag & TableDefine.TOTAL_COL_FULL) != 0;
            } else if (type == TYPE_SUB_TOTAL) {
                return (flag & TableDefine.TOTAL_COL_SUB) != 0;
            }
        }
        return true;
    }

    public boolean isEmpty() {
        return StringUtils.isBlank(key);
    }

    public List<String> displayValues() {
        return displayValues;
    }

    @Override
    public String toString() {
        return this.key;
    }

    @Override
    public int compareTo(Key key) {
        if (key.getKey().equals(this.getKey())) {
            return 0;
        }
        if (this.getKey().startsWith(key.getKey())) {
            return -1;
        }
        if (key.getKey().startsWith(this.getKey())) {
            return 1;
        }
        return this.getKey().compareTo(key.getKey());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Key key = (Key) o;
        return this.key.equals(key.key);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key);
    }
}
