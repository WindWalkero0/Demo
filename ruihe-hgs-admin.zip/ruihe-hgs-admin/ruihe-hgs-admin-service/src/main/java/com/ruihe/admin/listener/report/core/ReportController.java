package com.ruihe.admin.listener.report.core;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.ruihe.admin.listener.style.CellMergeStrategy;
import com.ruihe.admin.listener.style.CellStyle;
import com.ruihe.admin.listener.style.ColumnWidthStyleStrategy;
import com.ruihe.admin.utils.ExcelImgUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.SpreadsheetVersion;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ReportController {
    private String name;
    private String savePath;

    private final TableDefine define;
    private final BiReport biReport;

    public void name(String name) {
        this.name = name;
    }

    public void savePath(String savePath) {
        this.savePath = savePath;
    }

    public ReportController(TableDefine define) {
        this.define = define;
        this.biReport = new BiReport(define);
    }

    public ReportController(TableDefine define, HeadProvider headProvider) {
        this.define = define;
        this.biReport = new BiReport(define, headProvider);
    }

    public void fillData(List<?>... data) {
        biReport.fillData(data);
    }

    public void fillTotal(TotalQuery query) {
        biReport.fillTotal(query);
    }

    public void totalCalculate() {
        biReport.totalCalculate();
    }

    public void write(String staticRootUrl, String picUrl) {
        ExcelWriter excelWriter = EasyExcel.write(savePath).build();
        WriteSheet writeSheet = EasyExcel.writerSheet(name)
                .head(biReport.head())
                .registerWriteHandler(CellStyle.cellStyleStrategy(biReport.head(), define))
                .registerWriteHandler(new ColumnWidthStyleStrategy())
                .registerWriteHandler(new CellMergeStrategy(define))
                .automaticMergeHead(true)
                .relativeHeadRowIndex(define.getRowStart())
                .build();
        //超出excel行数限制判断
        if (biReport.table.rowKeySet().size() > SpreadsheetVersion.EXCEL2007.getMaxRows()) {
            throw new IllegalArgumentException(String.format("超出EXCEL最大列数%d，请缩减行选择条件重新导出", SpreadsheetVersion.EXCEL2007.getMaxRows()));
        }
        List<List<?>> rows = new ArrayList<>(biReport.table.rowKeySet().size());
        biReport.table.rowMap().forEach((rk, colMap) -> {
            List<?> row = biReport.readRow(rk, colMap);
            if (row != null) {
                rows.add(row);
            }
        });

        // 没有行小计或总计的时候，自动合并单元格时因为没法找到不相等的值，第一列合并都不会成功，加一空白行
        if (!rows.isEmpty() && (!define.rowTotal() && !define.rowSubtotal())) {
            rows.add(newEmptyRow(rows.get(0).size()));
        }
        
        excelWriter.write(rows, writeSheet);

        if (StringUtils.isNotBlank(staticRootUrl)) {
            ExcelImgUtils.CreatImgSheet(staticRootUrl, picUrl, excelWriter);
        }
        excelWriter.finish();
    }

    private List<Object> newEmptyRow(int column) {
        return IntStream.range(0, column).mapToObj(i -> "").collect(Collectors.toList());
    }
}
