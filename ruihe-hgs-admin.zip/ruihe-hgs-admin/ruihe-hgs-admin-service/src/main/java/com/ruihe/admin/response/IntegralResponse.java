package com.ruihe.admin.response;

import com.ruihe.admin.vo.IntegralOrderItemVo;
import com.ruihe.admin.vo.IntegralOrderVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@ApiModel(value = "IntegralResponse", description = "积分订单和明细一并返回的实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IntegralResponse implements Serializable {

    @ApiModelProperty(value = "积分订单")
    private IntegralOrderVo integralOrderVo;

    @ApiModelProperty(value = "积分详情")
    private List<IntegralOrderItemVo> integralItemList;
}
