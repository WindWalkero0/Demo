package com.ruihe.admin.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.mapper.basic.ProductMapper;
import com.ruihe.admin.mapper.basic.ProductSortItemMapper;
import com.ruihe.admin.mapper.erp.report.WhStockMapper;
import com.ruihe.admin.request.*;
import com.ruihe.admin.vo.*;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.base.ProductSortItemPo;
import com.ruihe.common.enums.base.ProductSortEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.pojo.response.basic.ProductExcelResponse;
import com.ruihe.common.response.Response;
import com.ruihe.common.service.ChangeService;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.utils.MD5;
import com.ruihe.common.utils.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2019-06-17 15:28
 */
@Service
@Slf4j
public class ProductService {
    @Autowired
    private ProductMapper productMapper;
    @Autowired
    private WhStockMapper stockMapper;
    @Autowired
    private ProductSortItemMapper productSortItemMapper;
    @Autowired
    private CustomService customService;
    @Autowired
    private ChangeService changeService;

    /**
     * 添加产品信息
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addProduct(ProductAddRequest request) throws BizException {
        //判断产品编码是否重复
        LambdaQueryWrapper<Product> queryCode = Wrappers.<Product>lambdaQuery().eq(Product::getPrdBarCode, request.getPrdBarCode());
        Product code = productMapper.selectOne(queryCode);
        if (code != null) {
            return Response.errorMsg("产品条码重复!");
        }
        //查询名称是否重复
        LambdaQueryWrapper<Product> queryName = Wrappers.<Product>lambdaQuery().eq(Product::getPrdName, request.getPrdName());
        Product name = productMapper.selectOne(queryName);
        if (name != null) {
            return Response.errorMsg("产品名称重复!");
        }
        //added by William,产品修改履历
        Long changeId = this.changeService.insert(Product.class, request.getPrdBarCode().trim(), "新增产品");
        //将产品基本信息保存到产品信息表中
        Product product = new Product();
        BeanUtils.copyProperties(request, product);
        product.setChangeId(changeId);
        product.setCreateTime(LocalDateTime.now());
        product.setUpdateTime(LocalDateTime.now());
        //保存信息
        Integer rows = productMapper.insert(product);
        if (rows == 0) {
            return Response.errorMsg("添加产品信息失败!");
        }
        return Response.successMsg("添加产品信息成功!");
    }

    private  LambdaQueryWrapper<Product> createProductQueryWrapper(ProductQueryRequest request){
        //查询条件
        LambdaQueryWrapper<Product> queryWrapper = Wrappers.<Product>lambdaQuery()
                //按照时间排序
                .orderByDesc(Product::getCreateTime)
                //单独时间排序会导致查询出来的数据翻页的时候出现重复数据
                .orderByDesc(Product::getGoodsBarCode);
        //查询条件
        if (StringUtils.isNotBlank(request.getBrandName())) {
            queryWrapper.eq(Product::getBrandName, request.getBrandName());
        }
        if (StringUtils.isNotBlank(request.getPrdBarCode())) {
            queryWrapper.like(Product::getPrdBarCode, request.getPrdBarCode());
        }
        if (StringUtils.isNotBlank(request.getGoodsBarCode())) {
            queryWrapper.like(Product::getGoodsBarCode, request.getGoodsBarCode());
        }
        if (StringUtils.isNotBlank(request.getPrdName())) {
            queryWrapper.like(Product::getPrdName, request.getPrdName());
        }
        if(request.getSeriesCode() != null){
            queryWrapper.eq(Product::getSeriesCode, request.getSeriesCode());
        }
        //&& request.getStatus().equals(CommonStatusEnum.EFFECTIVE.getCode())
        if (request.getStatus() != null) {
            queryWrapper.eq(Product::getStatus, request.getStatus());
        }
        if (request.getSaleStatus() != null) {
            queryWrapper.eq(Product::getSaleStatus, request.getSaleStatus());
        }
        if (request.getExchPermit() != null) {
            queryWrapper.eq(Product::getExchPermit, request.getExchPermit());
        }
        List<Integer> bigCatCodeList = request.getBigCatCode();
        if (!org.springframework.util.ObjectUtils.isEmpty(bigCatCodeList)) {
            queryWrapper.in(Product::getBigCatCode, request.getBigCatCode());
        }
        List<Integer> mediumCatCodeList = request.getMediumCatCode();
        if (!org.springframework.util.ObjectUtils.isEmpty(mediumCatCodeList)) {
            queryWrapper.in(Product::getMediumCatCode, request.getMediumCatCode());
        }
        List<Integer> smallCatCodeList = request.getSmallCatCode();
        if (!org.springframework.util.ObjectUtils.isEmpty(smallCatCodeList)) {
            queryWrapper.in(Product::getSmallCatCode, request.getSmallCatCode());
        }
        return queryWrapper;
    }

    /**
     * 导出产品excel
     * @author qubin
     * @date 2021/5/17 9:22
 * @param request
 * @return com.ruihe.common.response.Response
     */
    @DS(DBConst.SLAVE)
    public Response exportProduct(ProductQueryRequest request) {

        LambdaQueryWrapper<Product> queryWrapper = createProductQueryWrapper(request);
        List<Product> productList = productMapper.selectList(queryWrapper);
        List<ProductExcelResponse> excelResponseList = ObjectUtils.toList(productList, ProductExcelResponse.class);
        return  Response.success(excelResponseList);
    }


    /**
     * 产品条件查询并分页展示
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response queryProduct(ProductQueryRequest request) {

        LambdaQueryWrapper<Product> queryWrapper = createProductQueryWrapper(request);
        //分页查询
        Page<Product> page = new Page<>(request.getPageNumber(), request.getPageSize());
        IPage<Product> productIPage = productMapper.selectPage(page, queryWrapper);
        //获取查询数据
        List<Product> productList = productIPage.getRecords();
        //设置查询结果
        PageVO info = PageVO.<ProductVo>builder().list(ObjectUtils.toList(productList, ProductVo.class))
                .total(productIPage.getTotal())
                .pageNum(productIPage.getCurrent())
                .pageSize(productIPage.getSize())
                .pages(productIPage.getPages()).build();
        return Response.success(info);
    }

    /**
     * 点击产品名称返回产品信息
     *
     * @param prdBarCode
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response searchProduct(String prdBarCode) {
        //开始查询
        Product product = productMapper.selectOne(Wrappers.<Product>lambdaQuery().eq(Product::getPrdBarCode, prdBarCode));
        if (product == null) {
            return Response.successMsg("未查询到信息");
        }
        ProductVo productVo = new ProductVo();
        BeanUtils.copyProperties(product, productVo);
        return Response.success(productVo);
    }

    /**
     * 批量更改产品状态
     *
     * @param prdBarCodeList
     * @param status
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response updateStatus(List<String> prdBarCodeList, final Integer status) throws BizException {
        if (org.springframework.util.ObjectUtils.isEmpty(prdBarCodeList)) {
            return Response.errorMsg("未选择产品!");
        }
        if (status == null) {
            return Response.errorMsg("未选择状态!");
        }
        /*Product product = Product.builder()
                .status(status)
                .updateTime(LocalDateTime.now())
                .build();
        Integer rows = productMapper.update(product, Wrappers.<Product>lambdaUpdate().in(Product::getPrdBarCode, prdBarCodeList));
        if (rows != prdBarCodeList.size()) {
            log.error("批量更改产品状态失败,ids={}", prdBarCodeList);
            throw new BizException("批量更改产品状态失败");
        }*/
        //updated by William,产品修改履历
        String desc = status == 1 ? "启用产品" : "停用产品";
        prdBarCodeList.forEach(e -> {
            Long changeId = this.changeService.update(Product.class, e.trim(), desc);
            Product product = Product.builder()
                    .status(status)
                    .changeId(changeId)
                    .updateTime(LocalDateTime.now())
                    .build();
            Integer rows = productMapper.update(product, Wrappers.<Product>lambdaUpdate().eq(Product::getPrdBarCode, e.trim()).ne(Product::getStatus, status));
            if (rows != 1) {
                log.error("批量更改产品状态失败,ids={}", e.trim());
                throw new BizException("批量更改产品状态失败");
            }
        });
        return Response.successMsg("已经修改状态");
    }

    /**
     * 编辑信息并保存
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response editProduct(ProductAddRequest request) throws BizException {
        //查询名称是否重复
        LambdaQueryWrapper<Product> queryWrapper = Wrappers.<Product>lambdaQuery().eq(Product::getPrdName, request.getPrdName());
        Product product = productMapper.selectOne(queryWrapper);
        if (product != null && !product.getPrdBarCode().equals(request.getPrdBarCode())) {
            return Response.errorMsg("产品名称重复!");
        }
        //没有对产品分类的强制绑定进行处理，此处涉及到绑定的产品分类已有上级分类等各种情况的处理
        //暂时判断价格是否进行了变动
        //updated by William,产品修改履历.2020.11.16
        Product save = productMapper.selectById(request.getPrdBarCode());
        //对原始的对象进行MD5
        String updateBeforeMd5String = getProductMD5String(save);
        BeanUtils.copyProperties(request, save);
        //对修改的对象进行MD5
        String updateAfterMd5String  = getProductMD5String(save);
        //比较是否一致
        if(updateAfterMd5String.equals(updateBeforeMd5String)){
            return Response.successMsg("产品更新成功!");
        }
        Long changeId = this.changeService.update(Product.class, request.getPrdBarCode().trim(), "编辑产品档案");
        save.setChangeId(changeId);
        save.setUpdateTime(LocalDateTime.now());
        LambdaUpdateWrapper<Product> updateWrapper = Wrappers.<Product>lambdaUpdate().eq(Product::getPrdBarCode, request.getPrdBarCode());
        int rows = productMapper.update(save, updateWrapper);
        if (rows == 0) {
            log.error("编辑产品失败!request={}", request);
            return Response.errorMsg("产品更新失败!");
        }
        stockMapper.updateCategoryInfo(save);
        return Response.successMsg("产品更新成功!");
    }

    //对对象进行MD5签名，看是否修改了
    private String getProductMD5String(Product product){
        StringBuffer content = new StringBuffer();
        content.append(product.getPrdBarCode()).append(product.getBigCatCode()).append(product.getFchAvlWh()).append(product.getMaterialPrice())
                .append(product.getOrderPrice()).append(product.getGoodsBarCode()).append(product.getLevel()).append(product.getPrdName())
                .append(product.getUnitName()).append(product.getStatus()).append(product.getSaleStatus()).append(product.getExchPermit())
                .append(product.getSeriesCode()).append(product.getSeriesName()).append(product.getSalePrice()).append(product.getMemberPrice())
                .append(product.getBigPic()).append(product.getSmallPic()).append(product.getContent()).append(product.getBigCatName())
                .append(product.getMediumCatCode()).append(product.getMediumCatName()).append(product.getSmallCatCode())
                .append(product.getSmallCatName());
        return MD5.hexdigest(content.toString());
    }
    /**
     * 根据产品分类信息获取产品
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectProductByItem(ProductByItemRequest request) {
        //对传来的分类类型进行判断（暂时不考虑外购赠品这一分类）
        if (request.getType() > ProductSortEnum.SMALL_CLASS.getKey() || request.getType() < ProductSortEnum.BIG_CLASS.getKey()) {
            return Response.errorMsg("分类类型错误!");
        }
        //查询条件
        LambdaQueryWrapper<Product> queryWrapper = Wrappers.<Product>lambdaQuery();
        queryWrapper.eq(Product::getSaleStatus, 1);
        switch (request.getType()) {
            case 1:
                queryWrapper.eq(Product::getBigCatCode, request.getSortId());
                break;
            case 2:
                queryWrapper.eq(Product::getMediumCatCode, request.getSortId());
                break;
            case 3:
                queryWrapper.eq(Product::getSmallCatCode, request.getSortId());
                break;
            default:
                break;
        }
        //分页查询
        Page<Product> page = new Page<>(request.getPageNumber(), request.getPageSize());
        IPage<Product> productIPage = productMapper.selectPage(page, queryWrapper);
        //获取查询数据
        List<Product> productList = productIPage.getRecords();
        //设置查询结果
        PageVO info = PageVO.<ProductVo>builder().list(ObjectUtils.toList(productList, ProductVo.class))
                .total(productIPage.getTotal())
                .pageNum(productIPage.getCurrent())
                .pageSize(productIPage.getSize())
                .pages(productIPage.getPages()).build();
        return Response.success(info);
    }

    /**
     * 左边分类，右边产品综合查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectProductAndSort(ProductAndSortRequest request) {
        //获取编码id的list
        List<Integer> sortIdList = request.getSortId();
        //1、进入页面，除了分类、pagesize和number不为空，其它都是空
        if (org.springframework.util.ObjectUtils.isEmpty(sortIdList) && StringUtils.isBlank(request.getPrdName())) {
            //查询产品
            if (request.getPageSize() == null || request.getPageNumber() == null) {
                return Response.errorMsg("页数||页面不能为空!");
            }
            Page<Product> page = new Page<>(request.getPageNumber(), request.getPageSize());
            LambdaQueryWrapper<Product> queryProduct = Wrappers.<Product>lambdaQuery()
                    .eq(Product::getSaleStatus, 1);
            /**
             * modify by qubin
             * 2021-04-29 去除有关status相关的查询
             */
            //.eq(Product::getStatus, CommonStatusEnum.EFFECTIVE.getCode());
            IPage<Product> productIPage = productMapper.selectPage(page, queryProduct);
            //获取查询数据
            PageVO info = PageVO.<CommonPrdVo>builder().list(ObjectUtils.toList(productIPage.getRecords(), CommonPrdVo.class))
                    .total(productIPage.getTotal())
                    .pageNum(productIPage.getCurrent())
                    .pageSize(productIPage.getSize())
                    .pages(productIPage.getPages()).build();
            //查询产品分类
            List<ProductSortItemPo> sortItemPoList = productSortItemMapper.selectList(Wrappers.<ProductSortItemPo>lambdaQuery()
                    .eq(ProductSortItemPo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                    .eq(ProductSortItemPo::getIsPrdBinded, CommonStatusEnum.EFFECTIVE.getCode())
                    .eq(ProductSortItemPo::getMetaCode, request.getMetaCode()));
            return Response.success(PrdAndSortVo.builder()
                    .pageVo(info)
                    .prdSortItemVoList(ObjectUtils.toList(sortItemPoList, CommonPrdSortItemVo.class))
                    .build());
        }
        //2、单独查询下级分类，此时pagesize和number为空即可
        else if (request.getPageNumber() == null && request.getPageSize() == null) {
            List<ProductSortItemPo> sortItemPoList = productSortItemMapper.selectList(Wrappers.<ProductSortItemPo>lambdaQuery()
                    .eq(ProductSortItemPo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                    .eq(ProductSortItemPo::getIsPrdBinded, CommonStatusEnum.EFFECTIVE.getCode())
                    .in(ProductSortItemPo::getParentSortId, sortIdList));
            return Response.success(ObjectUtils.toList(sortItemPoList, CommonPrdSortItemVo.class));
        }
        //3、根据分类查询产品信息(包括模糊查询)，或者直接进行模糊查询
        else {
            if (request.getPageSize() == null || request.getPageNumber() == null) {
                return Response.errorMsg("页数||页面不能为空!");
            }
            Page<Product> page = new Page<>(request.getPageNumber(), request.getPageSize());
            LambdaQueryWrapper<Product> queryWrapper = Wrappers.<Product>lambdaQuery()
                    .eq(Product::getSaleStatus, 1);
            if (!org.springframework.util.ObjectUtils.isEmpty(sortIdList)) {
                queryWrapper.and(p -> p.in(Product::getBigCatCode, sortIdList)
                        .or().in(Product::getMediumCatCode, sortIdList)
                        .or().in(Product::getSmallCatCode, sortIdList));
            }
            if (StringUtils.isNotBlank(request.getPrdName())) {
                queryWrapper.and(p -> p.like(Product::getPrdBarCode, request.getPrdName())
                        .or().like(Product::getGoodsBarCode, request.getPrdName())
                        .or().like(Product::getPrdName, request.getPrdName()));
            }
            IPage<Product> productIPage = productMapper.selectPage(page, queryWrapper);
            //获取查询数据
            PageVO info = PageVO.<CommonPrdVo>builder().list(ObjectUtils.toList(productIPage.getRecords(), CommonPrdVo.class))
                    .total(productIPage.getTotal())
                    .pageNum(productIPage.getCurrent())
                    .pageSize(productIPage.getSize())
                    .pages(productIPage.getPages()).build();
            return Response.success(info);
        }
    }

    /**
     * 模糊查询产品信息--查询有效、在售的
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response fuzzyQueryProduct(FuzzyQueryProductRequest request) {
        Page<Product> page = new Page<>(request.getPageNumber(), request.getPageSize());
        IPage<Product> productIPage = productMapper.selectPage(page, Wrappers.<Product>lambdaQuery()
                /**
                 * modify by qubin
                 * 2021-04-29 去除有关status相关的查询
                 */
                //.eq(Product::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                .eq(Product::getSaleStatus, 1)
                .and(p -> p.like(Product::getPrdBarCode, request.getPrd())
                        .or().like(Product::getGoodsBarCode, request.getPrd())
                        .or().like(Product::getPrdName, request.getPrd())));
        PageVO info = PageVO.<FuzzyQueryProductVo>builder().list(ObjectUtils.toList(productIPage.getRecords(), FuzzyQueryProductVo.class))
                .total(productIPage.getTotal())
                .pageNum(productIPage.getCurrent())
                .pageSize(productIPage.getSize())
                .pages(productIPage.getPages()).build();
        return Response.success(info);
    }

    /**
     * 根据产品名称模糊查询产品信息--查询有效的
     *
     * @param request
     * @return
     */
    public Response fuzzyEffectiveProduct(FuzzyQueryProductRequest request) {
        Page<Product> page = new Page<>(request.getPageNumber(), request.getPageSize());
        IPage<Product> productPage = productMapper.selectPage(page, Wrappers.<Product>lambdaQuery()
                /**
                 * modify by qubin
                 * 2021-04-29 去除有关status相关的查询
                 */
                //.eq(Product::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                .eq(Product::getSaleStatus, 1)
                .like(Product::getPrdName, request.getPrd())
                .orderByAsc(Product::getPrdName));
        PageVO info = PageVO.<FuzzyQueryProductVo>builder()
                .list(ObjectUtils.toList(productPage.getRecords(), FuzzyQueryProductVo.class))
                .total(productPage.getTotal())
                .pageNum(productPage.getCurrent())
                .pageSize(productPage.getSize())
                .pages(productPage.getPages()).build();
        return Response.success(info);
    }

    /**********************************************************zhangyu begin************************************************************************/
    /**
     * 获取产品详情
     *
     * @param productCodes 产品条码集合
     * @return 产品集合
     */
    public List<Product> findAllProducts(List<String> productCodes) {

        if (CollectionUtils.isEmpty(productCodes)) {
            return Collections.emptyList();
        }
        var condition = Wrappers.<Product>lambdaQuery()
                .in(Product::getPrdBarCode, productCodes);
        return productMapper.selectList(condition);
    }
}
