package com.ruihe.admin.event;


import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 预订单查询
 * @author fly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class SaleLadingExcelEvent extends BiReportEvent {

    private String key;

    @Builder
    public SaleLadingExcelEvent(String key) {
        this.key = key;
    }
}
