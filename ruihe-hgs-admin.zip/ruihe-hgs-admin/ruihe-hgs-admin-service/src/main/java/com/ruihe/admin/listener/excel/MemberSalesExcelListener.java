package com.ruihe.admin.listener.excel;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.google.common.collect.Lists;
import com.ruihe.admin.event.MemberSalesExcelEvent;
import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.admin.listener.style.CellStyleUtils;
import com.ruihe.admin.listener.style.CustomHorizontalCellStyleStrategy;
import com.ruihe.admin.mapper.member.MemberMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.utils.ColumnWidthStyleStrategy;
import com.ruihe.admin.utils.ExcelImgUtils;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.dao.bean.member.MemberSelect;
import com.ruihe.common.pojo.request.member.MemberSearchRequest;
import com.ruihe.common.pojo.response.member.MemberSalesExcelResponse;
import com.ruihe.common.util.CheckIsEmpty;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

/***
 * 会员销售信息excel导出
 * @author ly
 */
@Slf4j
@Component
public class MemberSalesExcelListener extends AbstractReportListener<MemberSalesExcelEvent> {

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;


    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(MemberSalesExcelEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    protected void doExport(MemberSalesExcelEvent event, BiReportPo report, boolean flag) {
        //根据条件查询数据
        MemberSelect memberSelect = (MemberSelect) redisTemplate.opsForValue().get(event.getKey());
        List<Class<?>> dataTypes = getDataTypesList();
        CustomHorizontalCellStyleStrategy cellStyle = CellStyleUtils.customHorizontalCellStyleStrategy(MemberSalesExcelResponse.class, dataTypes);
        //上半部会员信息查询分开
        MemberSearchRequest memberSearchRequest = this.extractMemberSearchRequest(memberSelect);
        //获取导出实体list
        List<MemberSalesExcelResponse> memberSalesList = memberMapper.memberSalesList(memberSelect, memberSearchRequest);
        //excel导出
        ExcelWriter excelWriter = EasyExcel.write(report.getFilePath())
                .inMemory(true)
                .build();
        WriteSheet writeSheet = EasyExcel.writerSheet("第1～" + memberSalesList.size() + "条")
                .sheetNo(0)
                .head(MemberSalesExcelResponse.class)
                .registerWriteHandler(cellStyle)
                .registerWriteHandler(new ColumnWidthStyleStrategy())
                .automaticMergeHead(true)
                .build();
        excelWriter.write(memberSalesList, writeSheet);
        //查询图片
        ExcelImgUtils.CreatImgSheet(this.imgPath, report.getPicUrl(), excelWriter);
        //释放资源
        excelWriter.finish();
    }

    /**
     * 上半部会员信息查询构建
     *
     * @param request
     * @return
     */
    private MemberSearchRequest extractMemberSearchRequest(MemberSelect request) {
        MemberSearchRequest memberSearchRequest = new MemberSearchRequest();
        BeanUtils.copyProperties(request, memberSearchRequest);
        if (org.springframework.util.ObjectUtils.isEmpty(request.getMemberLevelCodeList())) {
            memberSearchRequest.setMemberLevelCodeList(null);
        }
        if (CheckIsEmpty.checkObjAllFieldsIsNull(memberSearchRequest)) {
            memberSearchRequest = null;
        }
        return memberSearchRequest;
    }

    /**
     * 处理表头数据
     *
     * @return
     */
    private List<Class<?>> getDataTypesList() {
        List<Class<?>> dataType = Lists.newArrayList();
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(BigDecimal.class);
        dataType.add(Integer.class);
        return dataType;
    }
}
