package com.ruihe.admin.event;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author ly
 * @Description 校验当前会员等级与会员等级升降级履历一致性
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class CheckMemberLevelEvent {
}
