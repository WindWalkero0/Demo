package com.ruihe.admin.constant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * ES对应常量
 *
 * @author William
 */
@Component
public class ElasticSearchContant {

    @Value("${spring.data.elasticsearch.db:hgs}")
    public String DB;
    /**
     * 积分账户
     **/
    @Value("${spring.data.elasticsearch.db:hgs}.t_integral_account")
    public String IDX_INTEGRAL_ACCOUNT;
    /**
     * 积分主表
     **/
    @Value("${spring.data.elasticsearch.db:hgs}.t_integral_order")
    public String IDX_INTEGRAL_ORDER;
    /**
     * 积分子表
     **/
    @Value("${spring.data.elasticsearch.db:hgs}.t_integral_order_item")
    public String IDX_INTEGRAL_ORDER_ITEM;
    /**
     * 支付方式表
     **/
    @Value("${spring.data.elasticsearch.db:hgs}.t_pos_pmt_order")
    public String IDX_POS_PMT_ORDER;
    /**
     * 订单表
     **/
    @Value("${spring.data.elasticsearch.db:hgs}.t_pos_order")
    public String IDX_POS_ORDER;
    /**
     * 订单子表
     **/
    @Value("${spring.data.elasticsearch.db:hgs}.t_pos_order_item")
    public String IDX_POS_ORDER_ITEM;
    /**
     * 订单子表
     **/
    @Value("${spring.data.elasticsearch.db:hgs}.t_member_info")
    public String IDX_MEMBER_INFO;
}
