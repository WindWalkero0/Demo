package com.ruihe.admin.listener.excel;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.google.common.collect.Lists;
import com.ruihe.admin.listener.AbstractReportListener;
import com.ruihe.common.pojo.response.stock.WhReturnItemExcelResponse;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.admin.event.WhReturnItemExcelEvent;
import com.ruihe.admin.listener.style.CellStyleUtils;
import com.ruihe.admin.listener.style.CustomHorizontalCellStyleStrategy;
import com.ruihe.admin.mapper.erp.document.WhReturnMapper;
import com.ruihe.admin.po.BiReportPo;
import com.ruihe.admin.request.erp.WhReturnRequest;
import com.ruihe.admin.utils.ColumnWidthStyleStrategy;
import com.ruihe.admin.utils.ExcelImgUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

/***
 * 退库单明细Excel导出
 * @author fly
 */
@Slf4j
@Component
public class WhReturnItemExcelListener extends AbstractReportListener<WhReturnItemExcelEvent> {

    @Autowired
    private WhReturnMapper whReturnMapper;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;


    @Override
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(WhReturnItemExcelEvent event) {
        super.onApplicationEvent(event);
    }

    @Override
    protected void doExport(WhReturnItemExcelEvent event, BiReportPo report, boolean flag) {
        WhReturnRequest whReturnRequest = (WhReturnRequest) redisTemplate.opsForValue().get(event.getKey());
        //购买记录分开查询
        List<WhReturnItemExcelResponse> whReturnItemExcelResponses = whReturnMapper.returnItemExcel(whReturnRequest, whReturnRequest.getOrgQueryConditionRequest());
        //数据写入到字节流
        List<Class<?>> dataTypes = getDataTypesList();
        CustomHorizontalCellStyleStrategy cellStyle = CellStyleUtils.customHorizontalCellStyleStrategy(WhReturnItemExcelResponse.class, dataTypes);
        ExcelWriter excelWriter = EasyExcel.write(report.getFilePath())
                .inMemory(true)
                .build();
        WriteSheet writeSheet = EasyExcel.writerSheet("第1～" + whReturnItemExcelResponses.size() + "条")
                .sheetNo(0)
                .head(WhReturnItemExcelResponse.class)
                .registerWriteHandler(cellStyle)
                .registerWriteHandler(new ColumnWidthStyleStrategy())
                .automaticMergeHead(true)
                .build();
        excelWriter.write(whReturnItemExcelResponses, writeSheet);
        ExcelImgUtils.CreatImgSheet(imgPath, report.getPicUrl(), excelWriter);
        excelWriter.finish();
    }

    /**
     * 处理表头数据
     *
     * @return
     */
    private List<Class<?>> getDataTypesList() {
        List<Class<?>> dataType = Lists.newArrayList();
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(String.class);
        dataType.add(Integer.class);
        dataType.add(BigDecimal.class);
        dataType.add(BigDecimal.class);
        dataType.add(BigDecimal.class);
        dataType.add(String.class);
        dataType.add(String.class);
        return dataType;
    }
}
