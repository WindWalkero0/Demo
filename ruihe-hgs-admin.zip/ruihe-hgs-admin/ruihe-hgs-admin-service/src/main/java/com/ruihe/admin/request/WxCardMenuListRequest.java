package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author LiangYuan
 * @date 2021-03-18 10:39
 */
@ApiModel(value = "WxCardMenuListRequest", description = "微信会员卡菜单列表查询请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class WxCardMenuListRequest implements Serializable {

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
