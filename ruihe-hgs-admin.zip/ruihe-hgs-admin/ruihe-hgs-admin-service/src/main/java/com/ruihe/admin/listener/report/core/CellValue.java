package com.ruihe.admin.listener.report.core;

import com.ruihe.admin.listener.report.utils.FieldUtils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * 保存报表统计数值
 */
public class CellValue {
    private final List<Number> data;
    private final List<Column> valueColumns;

    /**
     * 根据报表定义的数据字段通过反射从数据库返回的对象中取出列数据存入data中
     *
     * @param obj          数据库查询出来的数据对象
     * @param valueColumns 报表定义的数据字段
     */
    public CellValue(Object obj, List<Column> valueColumns) {
        this.valueColumns = valueColumns;
        this.data = new ArrayList<>(valueColumns.size());
        valueColumns.forEach(c -> {
            Object v = FieldUtils.read(obj, c.getName());
            if (v == null) {
                v = FieldUtils.defaultValue(c.getType());
            }
            data.add((Number) v);
        });
    }

    /**
     * 设置data为默认数值，用于填充空数据
     *
     * @param valueColumns 报表定义的数据字段
     */
    public CellValue(List<Column> valueColumns) {
        this.valueColumns = valueColumns;
        this.data = new ArrayList<>(valueColumns.size());
        valueColumns.forEach(c -> data.add((Number) FieldUtils.defaultValue(c.getType())));
    }

    public void fill(Object obj) {
        for (int i = 0; i < valueColumns.size(); i++) {
            Column column = valueColumns.get(i);
            Number v = (Number) FieldUtils.read(obj, column.getName());
            if (v != null) {
                data.set(i, v);
            }
        }
    }

    public void plus(CellValue cv) {
        for (int i = 0; i < data.size(); i++) {
            Number total = data.get(i);
            Number addValue = cv.data.get(i);
            Column c = valueColumns.get(i);
            if (!c.isAutoCalculate()) {
                continue;
            }
            if (c.getType() == Long.class) {
                data.set(i, total.longValue() + addValue.longValue());
            } else if (c.getType() == Integer.class) {
                data.set(i, total.intValue() + addValue.intValue());
            } else if (c.getType() == Double.class) {
                data.set(i, total.doubleValue() + addValue.doubleValue());
            } else if (c.getType() == Float.class) {
                data.set(i, total.floatValue() + addValue.floatValue());
            } else if (c.getType() == BigDecimal.class) {
                data.set(i, ((BigDecimal) total).add((BigDecimal) addValue));
            } else if (c.getType() == BigInteger.class) {
                data.set(i, ((BigInteger) total).add((BigInteger) addValue));
            }
        }
    }

    /**
     * 有些列数据需要依赖其他列计算得到，不需要从数据库中查询
     * 比如 客单价 = 销售总金额 / 销售总单数
     */
    public void calculate(TableDefine define) {
        valueColumns.forEach(c -> {
            if (CalculateFunc.DIV.equals(c.getCalculateFunc())) {
                CalculateFunc.DIV.divide(this, c, define);
            }
        });
    }

    public List<Number> data() {
        return data;
    }

    public void read(Consumer<Number> consumer) {
        for (int i = 0; i < valueColumns.size(); i++) {
            Column column = valueColumns.get(i);
            if (column.isShow()) {
                consumer.accept(data.get(i));
            }
        }
    }
}
