package com.ruihe.admin.listener.style;

import com.alibaba.excel.write.metadata.style.WriteCellStyle;
import com.alibaba.excel.write.metadata.style.WriteFont;
import com.ruihe.admin.listener.report.core.Column;
import com.ruihe.admin.listener.report.core.TableDefine;
import org.apache.poi.ss.SpreadsheetVersion;
import org.apache.poi.ss.usermodel.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class CellStyle {
    private static WriteCellStyle defaultHeadStyle() {
        WriteCellStyle cellStyle = new WriteCellStyle();
        cellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());

        WriteFont headWriteFont = new WriteFont();
        headWriteFont.setFontName("宋体");
        headWriteFont.setFontHeightInPoints((short) 14);
        headWriteFont.setBold(true);
        cellStyle.setWriteFont(headWriteFont);
        return cellStyle;
    }

    private static WriteCellStyle defaultDataStyle(String headerName, Class<?> clazz, Short dataFormat) {
        WriteCellStyle cellStyle = new WriteCellStyle();
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        cellStyle.setBorderRight(BorderStyle.THIN);
        cellStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());

        WriteFont headWriteFont = new WriteFont();
        headWriteFont.setFontHeightInPoints((short) 11);
        headWriteFont.setFontName("宋体");
        headWriteFont.setBold(false);
        cellStyle.setWriteFont(headWriteFont);

        //静态表头区域对应的数据区--设置单元格内容水平居中垂直向上
        if (clazz == String.class) {
            cellStyle.setHorizontalAlignment(HorizontalAlignment.CENTER);
            cellStyle.setVerticalAlignment(VerticalAlignment.TOP);
        }
        if (dataFormat != null) {
            cellStyle.setDataFormat(dataFormat);
            return cellStyle;
        }

        if (clazz == BigDecimal.class) {
            if (headerName.contains("占比")) {
                cellStyle.setDataFormat((short) BuiltinFormats.getBuiltinFormat("0.00%"));
            } else {
                //金额千分符
                cellStyle.setDataFormat((short) BuiltinFormats.getBuiltinFormat("#,##0.00"));
            }
        } else if (clazz == Integer.class || clazz == Long.class) {
            //数量设置千分符
            cellStyle.setDataFormat((short) BuiltinFormats.getBuiltinFormat("#,##0"));
        }
        return cellStyle;
    }

    /**
     * 自定义表格样式
     */
    public static CustomHorizontalCellStyleStrategy cellStyleStrategy(final List<List<String>> head, TableDefine define) {
        WriteCellStyle headWriteCellStyle = defaultHeadStyle();
        List<WriteCellStyle> contentStyleList = new ArrayList<>();

        List<Column> staticColumns = define.horizontalDisplayColumns();
        List<Column> valueColumns = define.valueDisplayColumns();
        //判断即将生成的excel列数是否超过限制
        var maxCols = staticColumns.size() + valueColumns.size();
        if (maxCols > SpreadsheetVersion.EXCEL2007.getMaxCellStyles() || maxCols > SpreadsheetVersion.EXCEL2007.getMaxColumns()) {
            throw new IllegalArgumentException(String.format("超出EXCEL最大列数%s，请缩小日期范围重新导出", SpreadsheetVersion.EXCEL2007.getMaxColumns()));
        }
        staticColumns.forEach(c -> {
            WriteCellStyle style = defaultDataStyle(c.getLabel(), c.getType(), null);
            contentStyleList.add(style);
        });
        for (int i = staticColumns.size(); i < head.size(); i += valueColumns.size()) {
            valueColumns.forEach(c -> {
                WriteCellStyle style = defaultDataStyle(c.getLabel(), c.getType(), null);
                contentStyleList.add(style);
            });
        }
        return new CustomHorizontalCellStyleStrategy(headWriteCellStyle, contentStyleList);
    }
}
