package com.ruihe.admin.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ruihe.common.dao.bean.base.ChannelInfo;
import com.ruihe.common.enums.base.ChannelEnum;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.TimeUtils;
import com.ruihe.admin.mapper.basic.ChannelMapper;
import com.ruihe.admin.request.basic.ChannelRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import java.util.List;

@Service
@Slf4j
public class ChannelService {

    @Autowired
    private CustomService customService;

    @Autowired
    private ChannelMapper channelMapper;

    /**
     * 添加渠道
     *
     * @param channelInfo
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addChannel(ChannelInfo channelInfo) {
        if (StringUtils.isBlank(channelInfo.getChannelCode())) {
            return Response.errorMsg("渠道编码为空!");
        }
        if (StringUtils.isBlank(channelInfo.getChannelName())) {
            return Response.errorMsg("渠道名称为空!");
        }
        //检测渠道信息
        boolean exsits = checkChannel(channelInfo);
        if (exsits) {
            return Response.errorMsg(ChannelEnum.CHANNEL_EXIST.getKey(), ChannelEnum.CHANNEL_EXIST.getValue());
        }
        channelInfo.setCreateTime(TimeUtils.longFormatString(System.currentTimeMillis()));
        Integer save = customService.save(channelInfo);
        if (save.equals(0)) {
            log.error("添加渠道失败，channelInf={}", channelInfo);
            throw new BizException("添加渠道失败");
        }
        return Response.success(StatusEnum.SUCCESS.getValue());
    }

    /**
     * 查询渠道信息
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectChannel(ChannelRequest request) {
        PageHelper.startPage(request.getPageNumber(), request.getPageSize());
        List<ChannelInfo> channelInfos = customService.selectListByTime(ChannelInfo.builder()
                .channelName(StringUtils.defaultString(request.getChannelName(), null))
                .channelCode(StringUtils.defaultString(request.getChannelCode(), null))
                .isDel(request.getIsDel())
                .build()
        );
        PageInfo<ChannelInfo> infoPageInfo = new PageInfo<>(channelInfos);
        Long count = customService.selectCount(ChannelInfo.builder().isDel(request.getIsDel()).build());
        infoPageInfo.setTotal(count);
        return Response.success(infoPageInfo);
    }


    /**
     * 停用启用渠道
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response disableEnable(ChannelRequest request) {
        if (ObjectUtils.isEmpty(request.getChannelCodes())) {
            return Response.errorMsg(ChannelEnum.CHANNEL_CODE_ISNULL.getKey(), ChannelEnum.CHANNEL_CODE_ISNULL.getValue());
        }
        List<String> channelCodes = request.getChannelCodes();
        for (String channelCode : channelCodes) {
            updateChannel(
                    ChannelInfo.builder().isDel(request.getIsDel()).build(),
                    ChannelInfo.builder().channelCode(channelCode).build());
        }
        return Response.success(StatusEnum.SUCCESS.getValue());
    }

    /**
     * 保存编辑信息
     *
     * @param channelInfo channelInfo
     * @return Response
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response saveChannel(ChannelInfo channelInfo) {
        //检测渠道信息
        boolean exists = checkChannel(channelInfo);
        if (exists) {
            return Response.errorMsg(ChannelEnum.CHANNEL_EXIST.getKey(), ChannelEnum.CHANNEL_EXIST.getValue());
        }
        //更新渠道信息
        updateChannel(channelInfo, ChannelInfo.builder().channelCode(channelInfo.getChannelCode()).build());
        return Response.success(StatusEnum.SUCCESS.getValue());
    }

    /**
     * 更新渠道信息
     */
    @DS(DBConst.MASTER)
    public void updateChannel(ChannelInfo channelInfo, ChannelInfo channelInfoOther) {
        Integer update = customService.update(channelInfo, channelInfoOther);
        if (update.equals(0)) {
            log.error("更新渠道信息失败，channelInfo={}channelInfoOther={}", channelInfo, channelInfoOther);
            throw new BizException("更新渠道信息失败，channelInfo：" + channelInfo.toString() + "channelInfoOther：" + channelInfo);
        }
    }

    /**
     * 检测渠道名称是否重复
     */
    @DS(DBConst.SLAVE)
    public boolean checkChannel(ChannelInfo channelInfo) {
        LambdaQueryWrapper<ChannelInfo> wrapper = Wrappers.<ChannelInfo>lambdaQuery()
                .eq(ChannelInfo::getChannelCode, channelInfo.getChannelCode())
                .or()
                .eq(ChannelInfo::getChannelName, channelInfo.getChannelName());
        int count = channelMapper.selectCount(wrapper);
        return count > 0;
    }
}
