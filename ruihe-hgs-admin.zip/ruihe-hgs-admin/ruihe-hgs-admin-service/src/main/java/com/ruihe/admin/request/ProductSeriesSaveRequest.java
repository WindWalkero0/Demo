package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Data
@ApiModel(description = "添加/修改产品系列")
public class ProductSeriesSaveRequest implements Serializable {
    @ApiModelProperty(value = "系列Id, 修改的时候id不能为空")
    private Integer id;

    @NotBlank
    @Size(min = 1, max = 20, message = "系列名称长度只能在1到20个字之间")
    @ApiModelProperty(value = "系列名称")
    private String name;
    
    @NotNull(message = "是否有效 不能为空")
    @ApiModelProperty("是否有效(0-无效 1-有效)")
    private Integer flag;
}
