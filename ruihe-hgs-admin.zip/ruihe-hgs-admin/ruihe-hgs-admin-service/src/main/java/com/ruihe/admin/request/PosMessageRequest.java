package com.ruihe.admin.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruihe.common.dao.bean.terminal.MessagePlaceInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@ApiModel(value = "PosMessageRequest", description = "修改实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosMessageRequest implements Serializable {

    @ApiModelProperty(value = "消息id")
    private Integer msgId;

    @ApiModelProperty(value = "消息序号")
    private Integer seq;

    @ApiModelProperty(value = "消息标题")
    private String title;

    @ApiModelProperty(value = "正文")
    private String content;

    @ApiModelProperty(value = "消息有效期开始时间")
    @Future(message = "消息有效期开始时间必须是将来时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @NotEmpty
    private LocalDateTime sendTime;

    @ApiModelProperty(value = "消息有效期结束时间")
    @Future(message = "消息有效期结束时间必须是将来时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @NotEmpty
    private LocalDateTime endTime;

    @ApiModelProperty(value = "消息接收地点")
    List<MessagePlaceInfo> activityPlaceList;

    @ApiModelProperty(value = "组织机构回显字段")
    private String showDescription;
}
