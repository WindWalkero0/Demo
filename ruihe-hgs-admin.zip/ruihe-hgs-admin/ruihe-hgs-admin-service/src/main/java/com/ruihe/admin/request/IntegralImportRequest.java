package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 积分导入请求
 *
 * @author William
 */
@ApiModel(value = "IntegralImportRequest", description = "积分导入请求")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IntegralImportRequest implements Serializable {

    @ApiModelProperty("导入名称")
    private String name;

    @ApiModelProperty("导入类型 0老积分  1新积分")
    private int inteType;

    @ApiModelProperty("导入原因")
    private String reason;

    @ApiModelProperty(value = "是否导入重复会员")
    private Boolean isRepeated;

}
