package com.ruihe.admin.enums;

/**
 * @author 梁远
 * @Description 空退/补录/手输条码，查询类型：1进行中，2已过期，3未开始
 * @create 2020-05-12 14:30
 */
public enum PosAuthorityBizTypeEnums {

    /**
     * 1进行中
     **/
    ONGOING(1, "进行中"),
    /**
     * 2已过期
     **/
    EXPIRED(2, "已过期"),
    /**
     * 3未开始
     **/
    NOT_STARTED(3, "未开始");

    private Integer code;
    private String msg;


    PosAuthorityBizTypeEnums(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
