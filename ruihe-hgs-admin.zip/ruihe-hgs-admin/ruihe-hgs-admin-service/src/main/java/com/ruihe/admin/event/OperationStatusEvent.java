package com.ruihe.admin.event;

import lombok.Data;


@Data
public class OperationStatusEvent {

}
