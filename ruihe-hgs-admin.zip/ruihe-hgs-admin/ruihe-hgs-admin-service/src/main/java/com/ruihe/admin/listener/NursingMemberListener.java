package com.ruihe.admin.listener;

import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Lists;
import com.ruihe.admin.event.NursingMemberEvent;
import com.ruihe.admin.service.nursing.NursingChildConfigService;
import com.ruihe.admin.service.nursing.NursingConfigService;
import com.ruihe.admin.service.nursing.NursingMemberService;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.constant.NursingConstant;
import com.ruihe.common.dao.bean.nursing.NursingChildConfigPO;
import com.ruihe.common.dao.bean.nursing.NursingMemberPO;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.response.nursing.OrderMemberNursingRes;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.BeanUtils;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Stream;

import static java.util.stream.Collectors.*;

@Slf4j
@Component
public class NursingMemberListener {

    private final NursingConfigService nursingConfigService;
    private final NursingChildConfigService nursingChildConfigService;
    private final NursingMemberService nursingMemberService;

    public NursingMemberListener(NursingConfigService nursingConfigService,
                                 NursingChildConfigService nursingChildConfigService,
                                 NursingMemberService nursingMemberService) {
        this.nursingConfigService = nursingConfigService;
        this.nursingChildConfigService = nursingChildConfigService;
        this.nursingMemberService = nursingMemberService;
    }

    /**
     * 1.从数据库获取护理配置信息+订单商品关联的护理信息
     * 2.对订单数据进行分组
     * 3.对分组后的数据进行整理(确认护理类型 + 确认护理BA + 转化为数据库可以存储的数据格式)
     * 4.针对需求的不同逻辑进行数据新增或更新
     *
     * @param event event
     */
    @Async(CommonConstant.ADMIN_THREAD_POOL_NAME)
    @EventListener
    @Transactional
    public void onApplicationEvent(NursingMemberEvent event) {

        //第1步
        var nursingChildConfig = nursingChildConfigService.getNurseChildConfigMapByParentId();//获取护理项目配置信息
        var nursingMembersExist = nursingMemberService.getBaseMapper().selectList(Wrappers.lambdaQuery());//已存在的会员护理信息
        var isFirstRun = nursingMembersExist.size() < 1; //是否为第一次执行

        var orderTime = isFirstRun ? LocalDateTime.now().minusYears(1) : LocalDateTime.now().minusMonths(1);
        var nursingMemberDataLinkedOrder = nursingConfigService.getBaseMapper().getNursingMemberData(orderTime);//从数据库中获取每个会员的有效订单产品对应的护理项目
        //第2步
        var afterGroupingMemberWaitingConvert = nursingMemberDataLinkedOrder.stream()
                .collect(groupingBy(e -> String.format("%s:%s", e.getCounterId(), e.getMemberId()), //group1 counterId+memberId
                        groupingBy(OrderMemberNursingRes::getNursingId, LinkedHashMap::new, toList()))); //group2 nursingId  orderBy bizTimeDesc

        //第3步
        var sortedWaitingInsertOrUpdateMember = afterGroupingMemberWaitingConvert.values().parallelStream() //任意会员M(x)在任意柜台T(x)下的所有购买产品详情
                .map(e -> e//会员M1在柜台T1下所有护理项目对应的产品购买记录详情  key 护理项目 value 产品每次的购买记录列表 (购买时间 + 购买数量 + 购买产品 + 会员M1信息 + 柜台T1信息)
                        .entrySet().stream()
                        .map(f -> this.confirmFinalNursingItem(f, nursingChildConfig)) //会员M1针对某一种护理项目N1的名称做最终确认
                        .filter(ObjectUtils::isNotEmpty)    //由于护理项目N1的产品数量不够无法达到确认名称要求,因此要将护理项目N1排除掉
                        .reduce(NursingMemberListener::mergeNursingItem)//对未被排除掉的护理项目N2,N3,N4,N4,N5,....做数据合并操作
                        .map(NursingMemberListener::convertRes2PO)//合并操作完成后将护理项目数据转化为数据库可以存储的PO对象
                        .orElse(null))//由于会员M1在柜台T1下所有购买产品的数量都无法满足护理要求(N1,N2,N3,...都被过滤掉), 最终该会员M1在T1柜台下的护理项目N为NUll
                .filter(ObjectUtils::isNotEmpty) //过滤掉任意会员M(x)在任意柜台T(x)下都无法产生护理项目的数据
                .collect(toList());

        //第4步
        if (isFirstRun) {
            //首次执行任务的护理会员直接插入
            nursingMemberService.saveBatch(sortedWaitingInsertOrUpdateMember, 1000);
        } else {
            var insertOrUpdateData = this.theLogicWhenNursingMemberExistData(nursingMembersExist, sortedWaitingInsertOrUpdateMember);

            var willInsertData = insertOrUpdateData.getLeft();
            var willUpdateData = insertOrUpdateData.getRight();
            if (CollectionUtils.isNotEmpty(willInsertData)) {
                nursingMemberService.saveBatch(willInsertData, 1000);
            }
            if (CollectionUtils.isNotEmpty(willUpdateData)) {
                nursingMemberService.updateBatchById(willUpdateData, 1000);
            }
        }

    }


    /**
     * @param nursingParentItem  与订单表关联查询出来的护理项目 MAP(key：nursingId，value：buyRecordList)
     * @param nursingChildConfig 从数据库配置表查询出来并整理好的护理子项目
     * @return 从护理项目的总数量里确认到底使用哪个子项目(filter逻辑)
     */
    private OrderMemberNursingRes confirmFinalNursingItem(Map.Entry<Integer, List<OrderMemberNursingRes>> nursingParentItem,
                                                          Map<Integer, List<NursingChildConfigPO>> nursingChildConfig) {

        var item = nursingParentItem.getKey();//当前护理类型
        var itemProductBuyDetail = nursingParentItem.getValue(); //当前护理类型购买详情

        if (CollectionUtils.isEmpty(itemProductBuyDetail)) {
            log.error("处理护理会员数据失败,某个柜台下某个会员购买了产品出现了没有对应的护理项目!,实际情况不可能存在,若出现,请仔细检查是否是代码处理逻辑是否有问题(1)!");
            throw new BizException("处理护理会员数据失败!");
        }

        final int itemProductBuyCount = itemProductBuyDetail.stream().mapToInt(OrderMemberNursingRes::getPurQty).sum(); //当前护理类型对应产品购买的总次数
        //根据产品数量确定护理项目最终的类型
        var itemFinal = nursingChildConfig.get(item).stream()
                .filter(x -> itemProductBuyCount >= x.getProductCountMin() && itemProductBuyCount <= x.getProductCountMax())//看当前item是否满足nursing_child的配置规则,确定nursing最终的名称
                .findFirst()
                .orElse(null);

        if (ObjectUtils.isEmpty(itemFinal)) {
            return null;
        }

        var latestItem = itemProductBuyDetail.get(0);
        //确定最终的护理项目(条件:产品+数量) 后续mergeNursingItem方法会确定最终的护理BA(对所有护理项目的最近购买时间做一次比较,取所有护理项目中最后一次购买时间的BA信息)
        latestItem.setNursingId(itemFinal.getId());
        latestItem.setNursingName(itemFinal.getItemChild());
        //最终护理集合的初始化操作(因为只有一种护理项目,是不会走接下来的mergeNursingItem方法的)
        latestItem.setNursingIdCombine(Lists.newArrayList(itemFinal.getId()));
        latestItem.setNursingNameCombine(Lists.newArrayList(itemFinal.getItemChild()));

        return latestItem;
    }

    /**
     * @param nursingMemberPre 上一条护理项目
     * @param nursingMember    当前护理项目
     * @return 将多条护理记录整合成一条护理项目输出
     */
    private static OrderMemberNursingRes mergeNursingItem(OrderMemberNursingRes nursingMemberPre, OrderMemberNursingRes nursingMember) {

        var _temp = new OrderMemberNursingRes();
        BeanUtils.copyProperties(nursingMemberPre, _temp);
        if (nursingMember.getBizTime().isAfter(nursingMemberPre.getBizTime())) {
            //取最后一次购买记录的BA数据
            _temp.setBizTime(nursingMember.getBizTime());
            _temp.setBaCode(nursingMember.getBaCode());
            _temp.setBaName(nursingMember.getBaName());
        }
        _temp.getNursingIdCombine().add(nursingMember.getNursingId());
        _temp.getNursingNameCombine().add(nursingMember.getNursingName());
        return _temp;
    }

    /**
     * @param nursingRes merge后的Item
     * @return 最后要插入到数据库DB的PO
     */
    private static NursingMemberPO convertRes2PO(OrderMemberNursingRes nursingRes) {

        var nursingIdS = new JSONArray();
        nursingIdS.addAll(nursingRes.getNursingIdCombine());
        var nursingNameS = new JSONArray();
        nursingNameS.addAll(nursingRes.getNursingNameCombine());

        return NursingMemberPO.builder()
                .memberId(nursingRes.getMemberId())
                .memberName(nursingRes.getMemberName())
                .mobile(nursingRes.getMobile())
                .baCode(nursingRes.getBaCode())
                .baName(nursingRes.getBaName())
                .counterId(nursingRes.getCounterId())
                .counterName(nursingRes.getCounterName())
                .nursingId(nursingIdS)
                .nursingItem(nursingNameS)
                .status(NursingConstant.NURSING_MEMBER_STATUS_WAITING)
                .type(NursingConstant.NURSING_MEMBER_TYPE_SYSTEM)
                .build();
    }

    /**
     * 当存护理会员表存在数据时的业务处理逻辑如下:
     * <p>
     * 后续更新时，对于存量的用户，只更新护理包类型信息，且只在原有的护理包类型基础之上新增护理项目。
     * 举例：系统第一次上线，A用户根据销售记录系统得到护理项目有1、2、3，美导根据实际情况调整为：1、3；
     * 后续更新时，如果用户新买了产品对应的护理项目为：2、3、4；则更新后用户的护理项目应该为：1、2、3、4.
     *
     * @param nursingMembersExist               护理会员已存在的数据
     * @param sortedWaitingInsertOrUpdateMember 每个月定时任务跑出来将要对其处理的数据
     * @return 将要新增的数据 + 将要更新的数据
     */
    private Pair<List<NursingMemberPO>, List<NursingMemberPO>> theLogicWhenNursingMemberExistData(List<NursingMemberPO> nursingMembersExist,
                                                                                                  List<NursingMemberPO> sortedWaitingInsertOrUpdateMember) {

        var nursingChildConfig = nursingChildConfigService.getNurseChildConfigMapById();//获取护理项目配置信息

        //对已存在的护理会员进行分组
        var memberExistedMap = nursingMembersExist.stream()
                .collect(toMap(e -> String.format("%s:%s", e.getCounterId(), e.getMemberId()), Function.identity()));

        //对转换完之后等待新增或更新的护理会员进行分组
        var memberWaitingMap = sortedWaitingInsertOrUpdateMember.stream()
                .collect(toMap(e -> String.format("%s:%s", e.getCounterId(), e.getMemberId()), Function.identity()));


        var sortedWaitingInsertMember = new ArrayList<NursingMemberPO>();
        var sortedWaitingUpdateMember = new ArrayList<NursingMemberPO>();

        memberWaitingMap.forEach((key, value) -> {

            var memberExisted = memberExistedMap.get(key);

            //不存在会员护理记录
            if (ObjectUtils.isEmpty(memberExisted)) {
                sortedWaitingInsertMember.add(value);
            } else {

                JSONArray nursingIdExist = memberExisted.getNursingId();
                JSONArray nursingIdWaiting = value.getNursingId();

                var nursingIdWaitingUpdate = Stream.of(nursingIdExist, nursingIdWaiting).flatMap(Collection::stream).sorted().distinct().collect(toList());

                //若有新的护理项目添加进来,则更新护理会员,否者不更新
                if (nursingIdWaitingUpdate.size() > nursingIdExist.size()) {

                    final JSONArray newNursingId = new JSONArray();
                    newNursingId.addAll(nursingIdWaitingUpdate);
                    final JSONArray newNursingName = new JSONArray();
                    newNursingName.addAll(newNursingId.stream().map(e -> nursingChildConfig.get(e).getItemChild()).collect(toList()));

                    memberExisted.setNursingId(newNursingId);
                    memberExisted.setNursingItem(newNursingName);

                    sortedWaitingUpdateMember.add(memberExisted);
                }
            }
        });

        return Pair.of(sortedWaitingInsertMember, sortedWaitingUpdateMember);
    }


}
