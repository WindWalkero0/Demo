package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author LiangYuan
 * @date 2021-03-10 9:12
 */
@ApiModel(value = "QueryQunRequest", description = "查询问卷请求实体")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class QueryQunRequest implements Serializable {

    @ApiModelProperty(value = "问卷名称")
    private String name;

    @ApiModelProperty(value = "创建时间开始")
    private LocalDate startTime;

    @ApiModelProperty(value = "创建时间结束")
    private LocalDate endTime;

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
