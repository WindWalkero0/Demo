package com.ruihe.admin.event;


import com.ruihe.common.annotation.Ella;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Ella(Describe = "更新缓存中的会员信息")
@Data
@EqualsAndHashCode(callSuper = false)
public class UpdateCacheEvent {

}
