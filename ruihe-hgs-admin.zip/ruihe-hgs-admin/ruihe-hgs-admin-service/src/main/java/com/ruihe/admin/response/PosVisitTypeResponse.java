package com.ruihe.admin.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * pos菜单配置表
 *
 * @author William
 */
@ApiModel(value = "PosVisitTypeResponse", description = "pos服务项目配置响应实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosVisitTypeResponse implements Serializable {
    /**
     * id
     **/
    @ApiModelProperty(value = "id")
    private Integer id;
    /**
     * 功能名称
     **/
    @ApiModelProperty(value = "功能名称")
    private String operationType;
    /**
     * 创建时间
     **/
    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
    /**
     * 有效状态 0无效  1有效
     **/
    @ApiModelProperty(value = "有效状态")
    private Boolean status;
    /**
     * 是否可以修改数量 0不能 1可以
     **/
    @ApiModelProperty(value = "是否可以修改数量")
    private Boolean updateStatus;
    
    @ApiModelProperty("顾客信息是否必填(0-否 1-是)")
    private Boolean required; 
    
    /**
     * 排序
     **/
    @ApiModelProperty(value = "排序")
    private Integer sort;

}
