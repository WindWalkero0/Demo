package com.ruihe.admin.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description
 * @author 梁远
 * @create 2019-06-26 11:39
 */
@ApiModel(value = "MemberLevelRequest", description = "会员等级请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberLevelRequest implements Serializable {

    @ApiModelProperty(value = "会员等级编码")
    private String levelCode;

    @ApiModelProperty(value = "会员等级名称")
    private String levelName;

    @ApiModelProperty(value = "品牌")
    private String brandName;

    @ApiModelProperty(value = "是否是默认等级")
    private Integer isDefaultLevel;

    @ApiModelProperty(value = "会员等级级别")
    private Integer level;

    @ApiModelProperty(value = "有效期")
    private Integer duration;

    @ApiModelProperty(value = "会员描述")
    private String description;

    @ApiModelProperty(value = "状态")
    private Integer status;
}
