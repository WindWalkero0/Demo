package com.ruihe.admin.event;

import com.ruihe.admin.request.bi.CounterErpReportRequest;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 柜台导出
 *
 * @author ly
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class Report4CounterErpEvent extends BiReportEvent {

    private CounterErpReportRequest request;

    @Builder
    public Report4CounterErpEvent(CounterErpReportRequest request) {
        this.request = request;
    }
}
