package com.ruihe.admin.mapper.homepage;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.home.RealTimeAccPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author cxt
 * @since 2019-11-27
 */
@Mapper
public interface RealTimeAccMapper extends BaseMapper<RealTimeAccPo> {

    Integer batchInsert(@Param("list") List<RealTimeAccPo> list);
}
