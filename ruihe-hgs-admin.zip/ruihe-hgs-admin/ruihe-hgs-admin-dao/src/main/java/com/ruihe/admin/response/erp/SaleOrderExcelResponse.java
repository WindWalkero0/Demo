package com.ruihe.admin.response.erp;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.ruihe.common.converter.LocalDateTimeConverter;
import com.ruihe.common.converter.OrderTypeConverter;
import com.ruihe.common.converter.TransTypeConverter;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author:fly
 * @Date:2020年7月17日17:03:43
 */
@ApiModel(value = "SaleOrderExcelResponse", description = "销售excel导出实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SaleOrderExcelResponse implements Serializable {

    @ExcelProperty(value = "手机号", index = 0)
    @ColumnWidth(15)
    private String memberPhone;

    @ExcelProperty(value = "会员名称", index = 1)
    @ColumnWidth(20)
    private String memberName;

    @ExcelProperty(value = "单据号", index = 2)
    @ColumnWidth(30)
    private String orderNo;

    @ExcelProperty(value = "订单类型", index = 3, converter = OrderTypeConverter.class)
    @ColumnWidth(15)
    private Integer orderType;

    @ExcelProperty(value = "交易类型", index = 4, converter = TransTypeConverter.class)
    @ColumnWidth(15)
    private Integer transType;

    @ExcelProperty(value = "购买时间", index = 5, converter = LocalDateTimeConverter.class)
    @ColumnWidth(30)
    public LocalDateTime bizTime;

    @ExcelProperty(value = "柜台号", index = 6)
    @ColumnWidth(15)
    public String counterId;

    @ExcelProperty(value = "柜台名称", index = 7)
    @ColumnWidth(30)
    private String counterName;

    @ExcelProperty(value = "金额", index = 8)
    @ColumnWidth(10)
    private BigDecimal realAmt;

    @ExcelProperty(value = "数量", index = 9)
    @ColumnWidth(10)
    private Integer goodsQty;

}
