package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Anthor:fly
 * @Date:2020年7月10日09:15:13
 */
@ApiModel(value = "PosLaingResultResponse", description = "销量总数,销量金额,订单数,会员数结果返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PosLaingResultResponse implements Serializable {
    @ApiModelProperty(value = "购买数量")
    private Integer saleQty;

    @ApiModelProperty(value = "购买金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal saleAmt;

    @ApiModelProperty(value = "已退数量")
    private Integer returnQty;

    @ApiModelProperty(value = "已退金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal returnAmt;

    @ApiModelProperty(value = "已提数量")
    private Integer extractQty;

    @ApiModelProperty(value = "剩余数量")
    private Integer surplusQty;
}
