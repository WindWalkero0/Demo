package com.ruihe.admin.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.ProductCategory;
import org.apache.ibatis.annotations.Mapper;

import java.time.LocalDateTime;

@Mapper
public interface ProductCategoryMapper extends BaseMapper<ProductCategory> {
    int updateStockCategory(LocalDateTime startTime, LocalDateTime endTime);

    int updateStockLogCategory(LocalDateTime startTime, LocalDateTime endTime);

    int updateOrderItemCategory(LocalDateTime startTime, LocalDateTime endTime);

    int nextId();

}
