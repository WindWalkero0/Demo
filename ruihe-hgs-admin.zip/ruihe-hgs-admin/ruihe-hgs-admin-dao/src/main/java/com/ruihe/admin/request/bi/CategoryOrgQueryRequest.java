package com.ruihe.admin.request.bi;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 产品业务明细报表，抽取条件查询结构体，不要随便动这个代码
 *
 * @author William
 */
@ApiModel(value = "CategoryOrgQueryRequest", description = "产品分类&组织结构查询实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CategoryOrgQueryRequest implements Serializable {
    @ApiModelProperty("大类代码")
    private Integer bigCatCode;

    @ApiModelProperty("中类代码")
    private Integer mediumCatCode;

    @ApiModelProperty("小类代码")
    private Integer smallCatCode;

    @ApiModelProperty("产商编码-产品名称")
    private String goodsBarCode;

    @ApiModelProperty("大区")
    private String orgAreaCode;

    @ApiModelProperty("办事处")
    private String orgOfficeCode;

    @ApiModelProperty("柜台主管")
    private String orgPrincipalCode;

    @ApiModelProperty("柜台")
    private String counterId;

    @ApiModelProperty("BA代码")
    private String baCode;
}
