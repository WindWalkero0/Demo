package com.ruihe.admin.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.EmployeeOperation;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 梁远
 * @Description 用户修改履历主表
 * @create 2020-06-29 11:36
 */
@Mapper
public interface EmployeeOperationMapper extends BaseMapper<EmployeeOperation> {
}
