package com.ruihe.admin.response.bi;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Author: ly
 * @Date: 2020-02-05 14:51
 * @Description 1.0
 */
@ApiModel(value = "MemberPurchaseResponse", description = "会员购买跟踪vo")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberPurchaseResponse implements Serializable {

    @ApiModelProperty(value = "年月/日期")
    private String time;

    @ApiModelProperty("大区代码")
    private String orgAreaCode;

    @ApiModelProperty("大区名称")
    private String orgAreaName;

    @ApiModelProperty("办事处代码")
    private String orgOfficeCode;

    @ApiModelProperty("办事处名称")
    private String orgOfficeName;

    @ApiModelProperty("柜台主管代码")
    private String orgPrincipalCode;

    @ApiModelProperty("柜台主管姓名")
    private String orgPrincipalName;

    @ApiModelProperty("柜台id")
    private String counterId;

    @ApiModelProperty("柜台")
    private String counterName;

    @ApiModelProperty("会员卡号")
    private String memberCardNumber;

    @ApiModelProperty("会员姓名")
    private String memberName;

    @ApiModelProperty("手机号")
    private String mobilePhone;

    @ApiModelProperty("购买金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal realAmt;

    @ApiModelProperty("实物总购买数量")
    private Integer goodsQty;

    @ApiModelProperty("护肤品类购买数量")
    private Integer skQty;

    @ApiModelProperty("购买单数,销售+退货")
    private Integer orderQty;
}
