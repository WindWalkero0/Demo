package com.ruihe.admin.mapper.promotional;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.promotion.ProductScope;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductScopeMapper extends BaseMapper<ProductScope> {
}

