package com.ruihe.admin.response.erp;

import com.ruihe.common.pojo.PageVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


@ApiModel(description = "产品库存包括在途库存 分页数据")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhProductStockResponse implements Serializable {

    @ApiModelProperty(value = "分页数据")
    private PageVO<WhProductStockVo> page;

    @ApiModelProperty(value = "查询缓存key")
    private String key;
}
