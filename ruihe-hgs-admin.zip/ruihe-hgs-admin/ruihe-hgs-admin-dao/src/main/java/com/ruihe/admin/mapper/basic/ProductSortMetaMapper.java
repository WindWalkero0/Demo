package com.ruihe.admin.mapper.basic;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.ProductSortMetaPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-05 11:45
 */
@Mapper
public interface ProductSortMetaMapper extends BaseMapper<ProductSortMetaPo> {
}
