package com.ruihe.admin.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.member.*;
import com.ruihe.common.pojo.request.member.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MemberActivityMapper extends BaseMapper<MemberActivity> {

    @Ella(Describe = "查询所有正在进行中和未开始的活动", Author = "K")
    List<MemberActivity> selectMemberActivityByQuery(@Param("statusList") List<Integer> statusList);

    @Ella(Describe = "查询所有正在进行中和未开始的活动", Author = "K")
    Long selectCount(@Param("statusList") List<Integer> statusList);

    @Ella(Describe = "根据子活动集合查询优惠券信息", Author = "K")
    List<MemberCoupon> selectMemberCouponByQuery(@Param("request") MemberActivityCouponRequest request);

    @Ella(Describe = "查询优惠券使用情况", Author = "K")
    List<MemberCouponResult> memberCouponResultQuery(@Param("request") MemberCouponResultRequest request);

    @Ella(Describe = "查询优惠券履历", Author = "K")
    List<MemberCouponLog> couponLogQuery(@Param("request") MemberCouponLogRequest request);


    @Ella(Describe = "查询兑换结果信息", Author = "K")
    List<MemberIntegralResult> IntegralResultQuery(@Param("request") MemberIntegralResultRequest request);

    @Ella(Describe = "查询会员活动", Author = "T")
    List<MemberActivity> queryMemberActivity(@Param("name") String name, @Param("isDel") Integer isDel);

    @Ella(Describe = "计算条数", Author = "T")
    Long queryCount(@Param("name") String name, @Param("isDel") Integer isDel);

    List<MemberActivity> selectActivities(@Param("request") MemberQueryRequest request);
}
