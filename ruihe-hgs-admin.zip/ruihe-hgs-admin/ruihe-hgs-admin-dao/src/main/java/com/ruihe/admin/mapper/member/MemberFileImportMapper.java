package com.ruihe.admin.mapper.member;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.po.MemberImportQueryPo;
import com.ruihe.common.dao.bean.member.MemberFilesImport;
import com.ruihe.admin.po.MemberImportQtyPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * fangtao
 */
@Mapper
public interface MemberFileImportMapper extends BaseMapper<MemberFilesImport> {

    /**
     * 点击导入流水号查看详情->条件查询
     */
    List<MemberImportQueryPo> queryImportDetail(@Param("importSerialNo") String importSerialNo,
                                                @Param("memberCardNumber") String memberCardNumber,
                                                @Param("importResult") Integer importResult);

    /**
     * 计算导入成功数量,失败数量和处理数量
     */
    MemberImportQtyPo calculatedSuccessQty(@Param("importSerialNo") String importSerialNo, @Param("importResult") Integer importResult);

    MemberImportQtyPo calculatedFailureQty(@Param("importSerialNo") String importSerialNo, @Param("importResult") Integer importResult);

    MemberImportQtyPo calculatedProcessingQty(@Param("importSerialNo") String importSerialNo, @Param("importResult") Integer importResult);


    /**
     * 设置页码
     */
    Long queryTotal(@Param("importSerialNo") String importSerialNo,
                    @Param("memberCardNumber") String memberCardNumber,
                    @Param("importResult") Integer importResult);

}
