package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @Anthor:Fangtao
 * @Date:2019/11/28 14:14
 */
@ApiModel(value = "PrdSalesAndRecordResponse", description = "产品销售记录返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PrdSalesAndRecordResponse implements Serializable {
    @ApiModelProperty(value = "销售单号")
    private String orderNo;
    @ApiModelProperty(value = "柜台编号")
    private String counterId;
    @ApiModelProperty(value = "柜台名称")
    private String counterName;
    @ApiModelProperty(value = "BA编码")
    private String baCode;
    @ApiModelProperty(value = "BA名称")
    private String baName;
    @ApiModelProperty(value = "单据会员卡号")
    private String memberPhone;
    @ApiModelProperty(value = "会员编码")
    private String memberId;
    @ApiModelProperty(value = "交易类型 1销售,-1退货")
    private Integer transType;
    @ApiModelProperty("活动类型  0 积分兑换 1优惠券活动  2促销活动 3无活动 4发券")
    private Integer activityType;
    @ApiModelProperty(value = "订单类型，1正常销售,2预定单")
    private Integer orderType;
    @ApiModelProperty(value = "主单数量")
    private Integer goodsQty;
    @ApiModelProperty(value = "订单金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal orderAmt;
    @ApiModelProperty(value = "主单金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal realAmt;
    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
    @ApiModelProperty(value = "销售时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime bizTime;
    @ApiModelProperty(value = "小票号")
    private String receiptNo;
    @ApiModelProperty(value = "订单来源")
    private String orderChanName;
    @ApiModelProperty("redis存储的Key")
    private String key;
    @ApiModelProperty("描述，销售,预定单,积分兑换,退货。。。")
    private String desc;
}
