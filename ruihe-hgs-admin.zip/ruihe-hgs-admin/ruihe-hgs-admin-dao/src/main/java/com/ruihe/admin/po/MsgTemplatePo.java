package com.ruihe.admin.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author:Fangtao
 * @Date:2019/11/15 19:56
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_msg_template")
public class MsgTemplatePo implements Serializable {
    private Long id;
    /* 业务类型 */
    private String bizType;
    /* 模板代码 */
    private String templateCode;
    /* 语言_国家,zh_CN */
    private String locale;
    /* 标题 */
    private String subject;
    /* 模板内容 */
    private String content;
    /* 模板代码 */
    private String remark;
    /* 状态,0启用,1弃用 */
    private Boolean status;
    /* 备注 */
    private LocalDateTime createTime;
    /* 创建时间 */
    private LocalDateTime updateTime;
}
