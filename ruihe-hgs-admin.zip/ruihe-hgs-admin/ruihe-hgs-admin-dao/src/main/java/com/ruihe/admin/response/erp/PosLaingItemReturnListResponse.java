package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @Anthor:fly
 * @Date:2020年7月10日09:15:13
 */
@ApiModel(value = "PosLaingItemReturnListResponse", description = "预订单退货单详情返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PosLaingItemReturnListResponse implements Serializable {
    @ApiModelProperty(value = "产品条码(对外标准条码)")
    private String prdBarCode;
    @ApiModelProperty(value = "产品名称")
    private String prdName;
    @ApiModelProperty(value = "商品条码")
    private String goodsBarCode;
    @ApiModelProperty("退货金额")
    private BigDecimal amount;
    @ApiModelProperty(value = "退货数量")
    private Integer purQty;
    @ApiModelProperty(value = "退货时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime bizTime;
    @ApiModelProperty(value = "退货单号")
    private String orderNo;
    @ApiModelProperty(value = "退货柜台编码")
    private String counterId;
    @ApiModelProperty(value = "退货柜台名称")
    private String counterName;
    @ApiModelProperty(value = "ba编码")
    private String baCode;
    @ApiModelProperty(value = "ba名称")
    private String baName;
    @ApiModelProperty(value = "虚拟商品")
    private Integer isVirtual;
}
