package com.ruihe.admin.response.member;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/5 18:03
 */
@ApiModel(value = "SmallCatProportionResponse", description = "产品小分类占比图响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SmallCatProportionResponse implements Serializable {
    @ApiModelProperty(value = "小分类名称")
    private String smallCatName;
    @ApiModelProperty(value = "每个小分类对应的数量")
    private Integer qty;
    @ApiModelProperty(value = "小分类编码")
    private Integer smallCatCode;
}
