package com.ruihe.admin.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.member.MemberLevelLog;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-21 10:47
 */
@Mapper
public interface MemberLevelLogMapper extends BaseMapper<MemberLevelLog> {
}
