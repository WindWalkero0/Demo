package com.ruihe.admin.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.request.basic.CounterRequest;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.Department;
import com.ruihe.common.pojo.response.basic.CounterExcelResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CounterMapper extends BaseMapper<CounterInformation> {
    /**
     * 根据条件查询信息
     *
     * @param request
     * @return
     */
    List<CounterInformation> searchMation(@Param("request") CounterRequest request);

    List<CounterExcelResponse> searchMationExcel(@Param("request") CounterRequest request);


    /**
     * 修改counter的组织结构
     *
     * @param dept
     * @param topDeptId
     * @param topDeptName
     * @return
     */
    int updateDepartment(@Param("dept") Department dept,
                         @Param("topDeptId") String topDeptId,
                         @Param("topDeptName") String topDeptName);

    List<String> selectAll(@Param("request") OrgQueryConditionRequest request);
}
