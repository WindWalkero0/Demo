package com.ruihe.admin.mapper.bi;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.common.constant.DBConst;
import com.ruihe.admin.request.bi.SalesPerfReportRequest;
import com.ruihe.admin.response.bi.BaSalesTimeReportPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
@DS(DBConst.SLAVE)
public interface SaleReportNewMapper {

    /**
     * 基础数据 +【销售总金额，销售总支数，销售总单数，客单价，连带率】
     */
    List<BaSalesTimeReportPo> queryBase(
            @Param("request") SalesPerfReportRequest request,
            @Param("scols") String scols,
            @Param("gcols") String gcols,
            @Param("empId") String empId,
            @Param("dayOrMonth") int dayOrMonth,
            @Param("flag") boolean flag);

    /**
     * 经营新会员
     */
    List<BaSalesTimeReportPo> queryOptNewMem(
            @Param("request") SalesPerfReportRequest request,
            @Param("dayOrMonth") int dayOrMonth,
            @Param("scols") String scols,
            @Param("gcols") String gcols,
            @Param("empId") String empId,
            @Param("flag") boolean flag);

    List<BaSalesTimeReportPo> queryVet(
            @Param("request") SalesPerfReportRequest request,
            @Param("scols") String scols,
            @Param("gcols") String gcols,
            @Param("empId") String empId,
            @Param("dayOrMonth") int dayOrMonth,
            @Param("flag") boolean flag);

    /**
     * 销售天数
     */
    List<BaSalesTimeReportPo> querySalesDays(
            @Param("request") SalesPerfReportRequest request,
            @Param("inScols") String inScols,
            @Param("inGcols") String inGcols,
            @Param("outScols") String outScols,
            @Param("outGcols") String outGcols,
            @Param("empId") String empId,
            @Param("flag") boolean flag);

    /**
     * 会员入会数量
     *
     * @param request
     * @param
     * @return
     */
    List<BaSalesTimeReportPo> queryMj(@Param("request") SalesPerfReportRequest request,
                                      @Param("scols") String scols,
                                      @Param("gcols") String gcols,
                                      @Param("empId") String empId,
                                      @Param("flag") boolean flag);
}
