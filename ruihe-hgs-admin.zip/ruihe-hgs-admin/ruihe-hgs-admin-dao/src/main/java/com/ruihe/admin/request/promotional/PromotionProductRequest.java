package com.ruihe.admin.request.promotional;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PromotionProductRequest {

    @ApiModelProperty(value = "特定产品  记录产品的id")
    public String specificProductId;

    @ApiModelProperty(value = "产品名称")
    public String specificProductName;

    @ApiModelProperty(value = "商品条码")
    public String goodsBarCode;

}
