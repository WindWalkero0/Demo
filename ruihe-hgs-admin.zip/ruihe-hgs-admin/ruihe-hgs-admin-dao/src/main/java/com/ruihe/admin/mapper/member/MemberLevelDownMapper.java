package com.ruihe.admin.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.member.MemberLevelDownPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-14 11:06
 */
@Mapper
public interface MemberLevelDownMapper extends BaseMapper<MemberLevelDownPo> {
    Integer batchInsert(@Param("list") List<MemberLevelDownPo> list);
}
