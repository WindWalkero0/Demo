package com.ruihe.admin.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.UserConcernPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-30 17:14
 */
@Mapper
public interface UserConcernMapper extends BaseMapper<UserConcernPo> {
    /**
     * 批量插入用户关注部门信息
     *
     * @param list
     * @return
     */
    Integer batchInsert(@Param("list") List<UserConcernPo> list);
}
