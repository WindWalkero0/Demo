package com.ruihe.admin.mapper.terminal;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.order.PosAuthorityCounterPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author 梁远
 * @Description 临时权限子表
 * @date 2019-12-10 10:00
 */
@Mapper
public interface PosAuthorityCounterMapper extends BaseMapper<PosAuthorityCounterPo> {
    /**
     * 批量插入临时权限子表
     *
     * @param counterPoList 子表列表
     * @return 插入条数
     */
    Integer batchInsert(@Param("list") List<PosAuthorityCounterPo> counterPoList);
}
