package com.ruihe.admin.mapper.bi;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.admin.response.bi.CounterErpOtherPo;
import com.ruihe.admin.response.bi.CounterErpReportResponse;
import com.ruihe.admin.response.bi.ProductErpOtherPo;
import com.ruihe.admin.response.bi.ProductErpReportResponse;
import com.ruihe.common.constant.DBConst;
import com.ruihe.admin.request.bi.CounterErpReportRequest;
import com.ruihe.admin.request.bi.ProductErpReportRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Author: ly
 * @Date: 2020-02-06 11:44
 * @Description 1.0
 */
@Mapper
@DS(DBConst.SLAVE)
public interface WhReportMapper {

    /**
     * @param request
     * @param empId
     * @param orgId   目前只有两个层级，总计-》柜台
     * @param scols
     * @param gcols
     * @param flag
     * @return
     */
    List<CounterErpReportResponse> counterErpBase(@Param("request") CounterErpReportRequest request,
                                                  @Param("empId") String empId,
                                                  @Param("orgId") String orgId,
                                                  @Param("scols") String scols,
                                                  @Param("gcols") String gcols,
                                                  @Param("flag") boolean flag);
    /**
     * @param request
     * @param empId
     * @param orgId   目前只有两个层级，总计-》柜台
     * @param scols
     * @param gcols
     * @param flag
     * @return
     */
    List<CounterErpOtherPo> counterErpOther(@Param("request") CounterErpReportRequest request,
                                            @Param("empId") String empId,
                                            @Param("orgId") String orgId,
                                            @Param("scols") String scols,
                                            @Param("gcols") String gcols,
                                            @Param("flag") boolean flag);
    /**
     * @param request
     * @param empId
     * @param orgId   目前只有两个层级，总计-》产品
     * @param scols
     * @param gcols
     * @param flag
     * @return
     */
    List<ProductErpReportResponse> prdErpBase(@Param("request") ProductErpReportRequest request,
                                              @Param("empId") String empId,
                                              @Param("orgId") String orgId,
                                              @Param("scols") String scols,
                                              @Param("gcols") String gcols,
                                              @Param("prd") boolean prd,
                                              @Param("counterId") boolean counterId,
                                              @Param("counterName") boolean counterName,
                                              @Param("flag") boolean flag);
    /**
     * @param request
     * @param empId
     * @param orgId   目前只有两个层级，总计-》产品
     * @param scols
     * @param gcols
     * @param flag
     * @return
     */
    List<ProductErpOtherPo> prdErpOther(@Param("request") ProductErpReportRequest request,
                                        @Param("empId") String empId,
                                        @Param("orgId") String orgId,
                                        @Param("scols") String scols,
                                        @Param("gcols") String gcols,
                                        @Param("flag") boolean flag);
}
