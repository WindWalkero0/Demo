package com.ruihe.admin.request.basic;

import com.ruihe.common.dao.bean.base.RoleMenu;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@ApiModel("授权管理接收实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JursidictionRequest {
    @ApiModelProperty("菜单目录集合(有就传没有就不传)")
    List<RoleMenu> roleMenuList;

    @ApiModelProperty("角色uid(必传)")
    public String roleUid;
}
