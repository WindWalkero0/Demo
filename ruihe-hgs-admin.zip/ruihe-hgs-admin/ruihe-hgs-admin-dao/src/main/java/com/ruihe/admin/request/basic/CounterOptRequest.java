package com.ruihe.admin.request.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author fly
 * @Date:2020年7月10日09:47:31
 */
@Data
@ApiModel("柜台修改履历接收类")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CounterOptRequest {

    @ApiModelProperty("柜台编号")
    public String counterId;

    @ApiModelProperty("分页大小")
    private Integer pageSize;

    @ApiModelProperty("当前页数")
    private Integer pageNumber;

}
