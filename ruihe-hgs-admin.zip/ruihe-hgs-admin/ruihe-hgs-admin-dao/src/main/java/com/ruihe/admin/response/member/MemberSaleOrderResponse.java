package com.ruihe.admin.response.member;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Auther: caichunxiang
 * @Date 2019/12/5
 */
@ApiModel(value = "MemberSaleOrderResponse", description = "会员首页购买总数量和总金额")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberSaleOrderResponse implements Serializable {
    @ApiModelProperty(value = "总金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal totalAmt;
    @ApiModelProperty(value = "总数量")
    private Integer totalQty;
    @ApiModelProperty(value = "交易类型，1销售,-1退货")
    private  Integer transType;
}
