package com.ruihe.admin.response.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/13 14:59
 */
@ApiModel(value = "QueryRegionResponse", description = "会员档案导入查询省市区code")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QueryRegionResponse implements Serializable {
    @ApiModelProperty("区域代码")
    public String regionCode;

    @ApiModelProperty("区域名称")
    public String regionName;

    @ApiModelProperty("是否删除  0正常  1删除")
    public Integer isDel;

    @ApiModelProperty("上级区域code")
    public String parentCode;

    @ApiModelProperty("区域等级  0大区  1省份   2市级   3区县")
    public Integer level;
}
