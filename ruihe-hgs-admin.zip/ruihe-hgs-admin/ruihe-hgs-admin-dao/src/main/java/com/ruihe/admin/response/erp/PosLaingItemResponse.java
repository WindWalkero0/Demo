package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruihe.common.pojo.response.order.MemberPayChannelResponse;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author:fly
 * @Date:2020年7月10日09:15:13
 */
@ApiModel(value = "PosLaingItemResponse", description = "预订单详情返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PosLaingItemResponse implements Serializable {
    @ApiModelProperty("该订单支付信息")
    private List<MemberPayChannelResponse> memberPayChannelResponseList;

    @ApiModelProperty(value = "订单明细")
    private List<PosLaingItemListResponse> itemVoList;

    @ApiModelProperty(value = "提货单明细")
    private List<PosLaingitemExtractListResponse> extractItemVoList;

    @ApiModelProperty(value = "退货单明细")
    private List<PosLaingItemReturnListResponse> returnItemVoList;

    @ApiModelProperty(value = "下次提货时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime extractTime;
}
