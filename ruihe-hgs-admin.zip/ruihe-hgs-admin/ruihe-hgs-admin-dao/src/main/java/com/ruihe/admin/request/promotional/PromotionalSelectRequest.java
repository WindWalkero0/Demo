package com.ruihe.admin.request.promotional;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(value = "查询活动接收类")
public class PromotionalSelectRequest implements Serializable {

    @ApiModelProperty(value = "活动名称")
    String name;

    @ApiModelProperty(value = "活动开始日期")
    String startTime;

    @ApiModelProperty(value = "活动结束日期")
    String stopTime;

    @ApiModelProperty(value = "促销活动状态")
    String activityStatus;

    @ApiModelProperty(value = "设置着名称")
    String createAuthor;

    @ApiModelProperty(value = "是否是模板")
    Integer templateType;

    @ApiModelProperty(value = "是否停用")
    Integer isDel;

    @ApiModelProperty(value = "分页大小")
    Integer pageSize;

    @ApiModelProperty(value = "当前页数")
    Integer pageNumber;

}
