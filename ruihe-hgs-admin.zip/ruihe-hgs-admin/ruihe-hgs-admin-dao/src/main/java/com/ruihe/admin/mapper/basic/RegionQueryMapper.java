package com.ruihe.admin.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.Region;
import com.ruihe.admin.response.basic.QueryRegionResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/13 14:42
 */
@Mapper
public interface RegionQueryMapper extends BaseMapper<Region> {

    /**
     * 根据等级和名称查询地区信息
     *
     * @param regionName
     * @param level
     * @return
     */
    QueryRegionResponse queryProvinceCode(@Param("regionName") String regionName,
                                          @Param("level") Integer level);
}
