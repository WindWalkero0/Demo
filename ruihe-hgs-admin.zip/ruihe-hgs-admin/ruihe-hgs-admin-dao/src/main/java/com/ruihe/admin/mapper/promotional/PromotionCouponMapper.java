package com.ruihe.admin.mapper.promotional;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.promotion.PromotionCoupon;
import com.ruihe.common.pojo.request.promotion.CouponSearchRequest;
import com.ruihe.common.pojo.request.promotion.SelectProCouponManageRequest;
import com.ruihe.common.pojo.response.promotion.PromotionCouponResponse;
import com.ruihe.common.pojo.response.promotion.SelectProCouponManageResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.io.Serializable;
import java.util.List;

/**
 * @author Administrator
 */
@Mapper
@Ella(Describe = "促销发券mapper")
public interface PromotionCouponMapper extends BaseMapper<PromotionCoupon> {

    @Override
    PromotionCoupon selectById(Serializable id);

    List<PromotionCouponResponse> selectPromotionCoupons(@Param("request") CouponSearchRequest request);

    List<SelectProCouponManageResponse> selectManageCoupon(@Param("request") SelectProCouponManageRequest request);

}
