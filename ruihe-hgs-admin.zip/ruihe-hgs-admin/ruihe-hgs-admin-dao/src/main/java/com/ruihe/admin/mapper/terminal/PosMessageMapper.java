package com.ruihe.admin.mapper.terminal;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.po.PosMessagePo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 参数配置表
 *
 * @author William
 */
@Mapper
public interface PosMessageMapper extends BaseMapper<PosMessagePo> {
    /**
     * 查询消息列表
     *
     * @return
     */
    List<PosMessagePo> selectMessage();
}
