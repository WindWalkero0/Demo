package com.ruihe.admin.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.UserDepartment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-30 15:57
 */
@Mapper
public interface UserDepartmentMapper extends BaseMapper<UserDepartment> {
    Integer batchInsert(@Param("list") List<UserDepartment> list);
}
