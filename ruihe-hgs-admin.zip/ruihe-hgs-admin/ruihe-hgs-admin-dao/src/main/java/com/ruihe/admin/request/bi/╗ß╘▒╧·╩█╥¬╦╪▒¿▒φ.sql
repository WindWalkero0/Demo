select
t.org_area_code,
t.org_area_name,
t.ba_code,
t.ba_name,
ifnull(sum(case when t.daily_net_amt!=0 then 1 else 0 end),0) sale_days,
ifnull(sum(t.daily_net_amt),0) sales_amt,
ifnull(sum(t.daily_net_order),0) sales_order_qty,
ifnull(sum(t.daily_net_goods_qty),0) sales_goods_qty,
ifnull(sum(t.daily_net_sk_qty),0) sales_sk_qty,
#会员数据
ifnull(sum(t.daily_net_mem_pur),0) mem_pur,
ifnull(sum(t.daily_net_mem_amt),0) mem_amt,
ifnull(sum(t.daily_net_mem_order),0) mem_order,
#会员入会数量
ifnull(sum(t.daily_net_mj),0) mj,
#新会员数据
ifnull(sum(t.daily_net_new_pur),0) new_pur,
ifnull(sum(t.daily_net_new_amt),0) new_amt,
ifnull(sum(t.daily_net_new_order),0) new_order,
#老会员数据
ifnull(sum(t.daily_net_vet_pur),0) vet_pur,
ifnull(sum(t.daily_net_vet_amt),0) vet_amt,
ifnull(sum(t.daily_net_vet_order),0) vet_order,
#非会员购买人数
ifnull(sum(t.daily_net_non_mem_order),0) no_mem_order
from (
	select
	a.org_area_code,
	a.org_area_name,
	a.ba_code,
	a.ba_name,
	date(a.biz_time) time,
	#所有数据(新会员、老会员、非会员)
	ifnull(sum(distinct case when a.trans_type= 1 then ABS(a.real_amt) when a.trans_type = -1 then -ABS(a.real_amt) end),0)  daily_net_amt,
	ifnull(sum(distinct case when a.trans_type= 1 then ABS(a.goods_qty) when a.trans_type = -1 then -ABS(a.goods_qty) end),0 ) daily_net_goods_qty,
	ifnull(sum(distinct case when a.trans_type= 1 then ABS(a.sk_qty) when a.trans_type = -1 then -ABS(a.sk_qty) end),0 ) daily_net_sk_qty,
	ifnull(count(distinct a.order_no),0 ) daily_net_order,
	##会员数据
	ifnull(sum(distinct case when m.member_id is null then 0 else 1 end),0)  daily_net_mem_pur,
	ifnull(sum(distinct case when m.member_id is null then 0 when a.trans_type= 1 then ABS(a.real_amt) when a.trans_type = -1 then -ABS(a.real_amt) end),0)  daily_net_mem_amt,
	ifnull(count(distinct a.order_no),0 ) daily_net_mem_order,
	#会员入会数量
	ifnull(sum(distinct case when m.ba_id = a.ba_code and m.create_time between '2020-01-25' and '2020-03-26' then 1 else 0 end),0)  daily_net_mj,
	#新会员数据,差新客单
	ifnull(sum(distinct case when m.create_time between '2020-01-25' and '2020-03-26' then m.member_id else 0 end),0)  daily_net_new_pur,
	ifnull(sum(distinct case when m.create_time between '2020-01-25' and '2020-03-26' then a.trans_type*ABS(a.real_amt) else 0 end),0)  daily_net_new_amt,
	ifnull(sum(distinct case when m.create_time between '2020-01-25' and '2020-03-26' then a.order_no else 0 end),0 ) daily_net_new_order,
	#老会员数据,差老客单
	ifnull(sum(distinct case when m.create_time < '2020-01-25' then m.member_id else 0 end),0)  daily_net_vet_pur,
	ifnull(sum(distinct case when m.create_time < '2020-01-25' then a.trans_type*ABS(a.real_amt) else 0 end),0)  daily_net_vet_amt,
	ifnull(sum(distinct case when m.create_time < '2020-01-25' then a.order_no else 0 end),0 ) daily_net_vet_order,
	#非会员购买人数
	ifnull(sum(distinct case when m.member_id is null then 1 else 0 end),0 ) daily_net_non_mem_order
	from t_pos_order a inner join t_member_info m on a.member_id = m.member_id
	where a.biz_time between  '2020-01-25' and '2020-03-26'
	group by
	a.org_area_code,
	a.org_area_name,
	a.ba_code,
	a.ba_name,
	time
) t
group by
t.org_area_code,
t.org_area_name,
t.ba_code,
t.ba_name;