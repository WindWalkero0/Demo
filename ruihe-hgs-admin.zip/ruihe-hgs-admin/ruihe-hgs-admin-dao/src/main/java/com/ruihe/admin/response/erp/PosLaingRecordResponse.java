package com.ruihe.admin.response.erp;

import com.github.pagehelper.PageInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author:fly
 * @Date:2020年7月10日09:18:15
 */
@ApiModel(value = "PosLaingRecordResponse", description = "预订单查询")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosLaingRecordResponse implements Serializable {
    @ApiModelProperty(value = "预订单返回前端Vo")
    private PageInfo<PosLaingSaleResponse> info;

    @ApiModelProperty(value = "预订单结果返回前端Vo")
    PosLaingResultResponse posLaingResultResponse;

    @ApiModelProperty(value = "redis查询缓存")
    String key;
}
