package com.ruihe.admin.response.basic;

import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.Region;
import lombok.Data;

import java.util.List;

@Data
public class DisResponse {

    //1已分配  0未分配
    public Integer type;

    //信息等级 0区.1省,2市,3县区
    public Integer level;

    //地区信息集合
    List<Region> regions;

    //柜台信息集合
    List<CounterInformation> counterInformationList;
}
