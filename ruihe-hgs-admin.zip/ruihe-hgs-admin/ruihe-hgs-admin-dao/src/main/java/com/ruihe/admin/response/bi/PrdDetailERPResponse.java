package com.ruihe.admin.response.bi;


import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Author: ly
 * @Date: 2020-02-05 14:51
 * @Description 1.0
 */
@ApiModel(value = "PrdDetailERPResponse", description = "产品业务明细报表vo")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PrdDetailERPResponse implements Serializable {
    @ApiModelProperty(value = "时间")
    private String time;

    @ApiModelProperty("大类代码")
    private Integer bigCatCode;

    @ApiModelProperty("大类名称")
    private String bigCatName;

    @ApiModelProperty("中类代码")
    private Integer mediumCatCode;

    @ApiModelProperty("中类名称")
    private String mediumCatName;

    @ApiModelProperty("小类代码")
    private Integer smallCatCode;

    @ApiModelProperty("小类名称")
    private String smallCatName;

    @ApiModelProperty("产品条码")
    private String goodsBarCode;

    @ApiModelProperty("厂商编码")
    private String prdBarCode;

    @ApiModelProperty("产品名称")
    private String prdName;

    @ApiModelProperty("柜台")
    private String counterName;

    @ApiModelProperty("柜台id")
    private String counterId;

    @ApiModelProperty("大区代码")
    private String orgAreaCode;

    @ApiModelProperty("大区名称")
    private String orgAreaName;

    @ApiModelProperty("办事处代码")
    private String orgOfficeCode;

    @ApiModelProperty("办事处名称")
    private String orgOfficeName;

    @ApiModelProperty("柜台主管代码")
    private String orgPrincipalCode;

    @ApiModelProperty("柜台主管姓名")
    private String orgPrincipalName;

    @ApiModelProperty("ba编码")
    private String baCode;

    @ApiModelProperty("ba名称")
    private String baName;

    @ApiModelProperty(value = "销售总金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal realAmt;

    @ApiModelProperty(value = "实物销售总支数")
    private Integer goodsQty;

    @ApiModelProperty(value = "产品总金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal prdAmt;
}
