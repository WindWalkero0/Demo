package com.ruihe.admin.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * BI报表生成记录
 * </p>
 *
 * @author William
 * @since 2020-02-10
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_bi_report")
public class BiReportPo implements Serializable {

    @TableId(value = "report_id", type = IdType.NONE)
    private Long reportId;

    /**
     * emp_id员工id,报表发起人
     */
    private String uid;
    /**
     * 报表名称,枚举描述
     */
    private String reportName;
    /**
     * 文件存储路径
     */
    private String filePath;
    /**
     * http下载请求路径
     */
    private String url;
    /**
     * 状态:-1导出失败/异常,0初始化/导出中,1导出完成
     */
    private Integer status;

    /**
     * 标签
     */
    private String tag;

    /**
     * 查询页面截图地址
     */
    private String picUrl;

    /**
     * 完成时间
     */
    private LocalDateTime finishTime;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 修改时间
     */
    private LocalDateTime updateTime;
}
