package com.ruihe.admin.request.bi;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2020-02-05 09:50
 */
@ApiModel(value = "MemberPurchaseSelectRequest", description = "会员购买跟踪输出对象")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberPurchaseSelectRequest implements Serializable {

    @ApiModelProperty(value = "年月")
    private boolean monthly;

    @ApiModelProperty("大区，一级")
    private boolean area;

    @ApiModelProperty("办事处，二级")
    private boolean office;

    @ApiModelProperty("柜台主管，三级")
    private boolean principal;

    @ApiModelProperty("柜台id，四级")
    private boolean counterId;

    @ApiModelProperty("柜台")
    private boolean counterName;

    @ApiModelProperty("会员卡号")
    private boolean memberCardNumber;

    @ApiModelProperty("会员姓名")
    private boolean memberName;

    @ApiModelProperty("手机号")
    private boolean mobilePhone;

    @ApiModelProperty("购买数量")
    private boolean skQty;

    @ApiModelProperty("购买金额")
    private boolean realAmt;

    @ApiModelProperty("购买单数")
    private boolean orderQty;
}
