package com.ruihe.admin.request.erp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author fly
 * @Date:2020年7月15日10:05:57
 */
@ApiModel(description = "产品记录多条件查询接收类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosLadingSaleRequest implements Serializable {
    @ApiModelProperty("销售单号")
    private String orderNo;
    @ApiModelProperty("会员卡号")
    private String memberPhone;
    @ApiModelProperty("提货状态，0已全部提货 ,1部分提货 ,2未提货, 3全部退货")
    private Integer ladingStatus;
    @ApiModelProperty(value = "开始时间")
    private String startTime;
    @ApiModelProperty(value = "结束时间")
    private String endTime;
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
    @ApiModelProperty(value = "组织模式查询条件")
    private OrgQueryConditionRequest orgQueryConditionRequest;
}
