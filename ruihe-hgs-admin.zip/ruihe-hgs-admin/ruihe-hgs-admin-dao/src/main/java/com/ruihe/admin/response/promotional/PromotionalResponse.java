package com.ruihe.admin.response.promotional;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;

@Data
public class PromotionalResponse {

    @ApiModelProperty("促销活动名称")
    public String name;

    @ApiModelProperty("促销活动编码")
    public String uid;

    @ApiModelProperty("活动开始时间")
    public String startTime;

    @ApiModelProperty("活动结束时间")
    public String stopTime;

    @ApiModelProperty("活动结束时间")
    public String activityName;

    @ApiModelProperty("购买条件")
    public String buyConditionType;

    @ApiModelProperty("创建者")
    public String createAuthor;

    @ApiModelProperty("有效区分")
    public Integer isDel;


}
