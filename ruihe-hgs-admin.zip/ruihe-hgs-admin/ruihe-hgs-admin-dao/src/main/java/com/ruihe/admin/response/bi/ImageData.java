package com.ruihe.admin.response.bi;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import lombok.Data;

import java.io.File;

/**
 * @author Administrator
 */
@Data
@ColumnWidth(200)
public class ImageData {

    @ExcelProperty("查询条件")
    private File file;
//
//    private InputStream inputStream;
//    /**
//     * 如果string类型 必须指定转换器，string默认转换成string
//     */
//    @ExcelProperty(converter = StringImageConverter.class)
//    private String string;
//    private byte[] byteArray;
//    /**
//     * 根据url导出
//     *
//     * @since 2.1.1
//     */
//    @ExcelProperty("查询条件")
//    private URL url;
}