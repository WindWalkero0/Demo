package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author 梁远
 * @Description
 * @create 2020-02-27 14:51
 */
@ApiModel(value = "PosOrderItemResponse", description = "订单子表返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PosOrderItemResponse implements Serializable {

    @ApiModelProperty(value = "产品条码")
    private String prdBarCode;

    @ApiModelProperty(value = "商品条码")
    private String goodsBarCode;

    @ApiModelProperty(value = "商品名称")
    private String prdName;

    @ApiModelProperty(value = "计量单位")
    private String unitName;

    @ApiModelProperty(value = "原价")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal prdPrice;

    @ApiModelProperty(value = "销售价")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal salePrice;

    @ApiModelProperty(value = "购买数量")
    private Integer purQty;

    @ApiModelProperty(value = "应付金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal amount;

    @ApiModelProperty(value = "分摊后金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal shareAmt;

    @ApiModelProperty(value = "活动描述")
    private String activityDesc;

    @ApiModelProperty(value = "商品类型 0兑换活动 1优惠券 2促销  3正常商品 4发券用券 5空退促销")
    private String proType;
}
