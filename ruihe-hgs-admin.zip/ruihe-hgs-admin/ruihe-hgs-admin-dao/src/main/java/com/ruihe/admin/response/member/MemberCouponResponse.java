package com.ruihe.admin.response.member;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class MemberCouponResponse {

    //使用结果id或者优惠券id
    public String id;

    //主题活动id
    public String subActivityId;

    //子活动id
    public String activityId;

    //柜台id
    public String counterId;

    //会员id
    public String memberId;

    //会员名称
    public String memberName;

    //会员手机号
    public String memberPhone;

    //创建时间
    public LocalDateTime createTime;

    //优惠券状态
    public Integer status;

    //活动名称
    public String subActivityName;

    //活动名称
    public String activityName;

    //活动类型
    public Integer activityType;

    //柜台名称
    public String counterName;

}
