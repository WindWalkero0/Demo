package com.ruihe.admin.mapper.order;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.order.PosLadingOrderItemPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * pos销售订单子表 Mapper 接口
 * </p>
 *
 * @author William
 * @since 2019-10-18
 */
@Mapper
public interface PosLadingOrderItemMapper extends BaseMapper<PosLadingOrderItemPo> {

}
