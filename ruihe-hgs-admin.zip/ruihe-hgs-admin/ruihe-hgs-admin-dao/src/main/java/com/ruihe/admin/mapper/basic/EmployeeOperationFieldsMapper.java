package com.ruihe.admin.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.EmployeeOperationFields;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author 梁远
 * @Description 用户修改履历子表
 * @create 2020-06-29 11:36
 */
@Mapper
public interface EmployeeOperationFieldsMapper extends BaseMapper<EmployeeOperationFields> {
    /**
     * 批量插入用户修改履历子表
     *
     * @param list
     * @return
     */
    Integer batchInsert(@Param("list") List<EmployeeOperationFields> list);
}
