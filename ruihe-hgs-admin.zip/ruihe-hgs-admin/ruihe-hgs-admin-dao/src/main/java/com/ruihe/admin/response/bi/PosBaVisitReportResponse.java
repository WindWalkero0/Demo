package com.ruihe.admin.response.bi;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.HashMap;

/**
 * @author fly
 * @Date 2020年10月20日10:38:25
 */
@ApiModel(value = "PosBaVisitReportResponse", description = "服务记录报表查询vo")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosBaVisitReportResponse implements Serializable {

    @ApiModelProperty("大区代码")
    private String orgAreaCode;

    @ApiModelProperty("大区名称")
    private String orgAreaName;

    @ApiModelProperty("办事处代码")
    private String orgOfficeCode;

    @ApiModelProperty("办事处名称")
    private String orgOfficeName;

    @ApiModelProperty("柜台主管代码")
    private String orgPrincipalCode;

    @ApiModelProperty("柜台主管姓名")
    private String orgPrincipalName;

    @ApiModelProperty("柜台id")
    private String counterId;

    @ApiModelProperty("柜台")
    private String counterName;

    @ApiModelProperty("Ba编号")
    private String baCode;

    @ApiModelProperty("Ba姓名")
    private String baName;

    /**
     * ------------核心数据------------
     **/
    @ApiModelProperty("动态数据")
    private HashMap dataMap;
}
