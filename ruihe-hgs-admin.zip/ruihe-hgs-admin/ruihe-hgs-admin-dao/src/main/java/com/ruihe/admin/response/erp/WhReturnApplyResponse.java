package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-22 9:54
 */
@ApiModel(value = "WhReturnApplyResponse", description = "退库申请单列表查询返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class WhReturnApplyResponse implements Serializable {

    @ApiModelProperty(value = "申请单号")
    private String returnNo;

    @ApiModelProperty(value = "u8其他出库单号")
    private String u8OrderNo;

    @ApiModelProperty(value = "退库单号")
    private String confirmReturnNo;

    @ApiModelProperty(value = "柜台ID")
    private String counterId;

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "门店类型:自营10005/加盟10006")
    private String operationalModel;

    @ApiModelProperty(value = "原因：0可用试用装退回，1报废试用装退回，2转店退回，,质量问题退回，4过敏退回，5公司召回，6到货少货，7活动赠品退回，8其他")
    private Integer reason;

    @ApiModelProperty(value = "审核状态：1未审核，2SAP确认，3确认退库，4已废弃")
    private Integer status;

    @ApiModelProperty(value = "数量")
    private Integer applyQty;

    @ApiModelProperty(value = "金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal applyAmt;

    @ApiModelProperty(value = "柜员id")
    private String baCode;

    @ApiModelProperty(value = "柜员名称")
    private String baName;

    @ApiModelProperty(value = "审核人id")
    private String auditCode;

    @ApiModelProperty(value = "审核人名称")
    private String auditName;

    @ApiModelProperty(value = "快递单号")
    private String trackingNo;

    @ApiModelProperty(value = "盘点时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "申请时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate applyTime;

}
