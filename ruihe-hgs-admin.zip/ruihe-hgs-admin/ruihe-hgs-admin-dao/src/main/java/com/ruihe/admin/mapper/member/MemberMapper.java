package com.ruihe.admin.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.request.MemberActivityCouponLogRequest;
import com.ruihe.admin.response.member.MemberCouponResponse;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.member.*;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.pojo.request.member.MemOpeSelectRequest;
import com.ruihe.common.pojo.request.member.MemberSaleRequest;
import com.ruihe.common.pojo.request.member.MemberSearchRequest;
import com.ruihe.common.pojo.request.order.OrderRequest;
import com.ruihe.common.pojo.response.member.MemOpeSelectResponse;
import com.ruihe.common.pojo.response.member.MemberExcelResponse;
import com.ruihe.common.pojo.response.member.MemberSalesExcelResponse;
import com.ruihe.common.pojo.response.order.OrderResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Ella(Describe = "会员详情操作", Author = "K")
@Mapper
public interface MemberMapper extends BaseMapper<MemberInfo> {

    @Ella(Describe = "根据条件查询修改履历集合", Author = "K")
    List<MemOpeSelectResponse> searchOperation(@Param("request") MemOpeSelectRequest request);

    @Ella(Describe = "查询会员购买记录", Author = "K")
    List<OrderResponse> selectOrder(@Param("request") OrderRequest request, @Param("startTime") LocalDate startTime, @Param("endTime") LocalDate endTime);

    @Ella(Describe = "查询会员购买记录总条数", Author = "LY")
    Integer selectOrderCount(@Param("request") OrderRequest orderRequest, @Param("startTime") LocalDate startTime, @Param("endTime") LocalDate endTime);

    @Ella(Describe = "查询会员购买记录总金额", Author = "LY")
    List<Map<Integer, Object>> selectOrderAmt(@Param("request") OrderRequest request, @Param("startTime") LocalDate startTime, @Param("endTime") LocalDate endTime);

    @Ella(Describe = "查询会员购买记录总数", Author = "LY")
    List<Map<Integer, Object>> selectOrderQty(@Param("request") OrderRequest request, @Param("startTime") LocalDate startTime, @Param("endTime") LocalDate endTime);

    @Ella(Describe = "查询会员活动履历", Author = "K")
    List<MemberCouponResponse> selectActivityLog(@Param("request") MemberActivityCouponLogRequest request);

    @Ella(Describe = "批量插入操作数据", Author = "K")
    Integer insertOperation(@Param("list") List<MemberOperation> list);

    @Ella(Describe = "批量插入操作字段数据", Author = "K")
    Integer insertFields(@Param("list") List<MemberOperationFields> list);


    @Ella(Describe = "批量修改会员数据", Author = "K")
    Integer updateMemberInfos(@Param("memberInfo") MemberInfo memberInfo, @Param("list") List<MemberInfo> list);

    @Ella(Describe = "批量修改会员数据", Author = "K")
    Integer updateMemberInfo(@Param("list") List<MemberInfo> list);

    /**
     * 会员excel导出数据总量查询
     *
     * @param request
     * @param memberSelect
     * @return
     */
    Long memberExcelResponseCount(@Param("request") MemberSelect request,
                                  @Param("memberSelect") MemberSaleRequest memberSelect);

    /**
     * 会员excel导出数据查询
     *
     * @param request
     * @param memberSelect
     * @return
     */
    List<MemberExcelResponse> memberExcelResponseList(@Param("request") MemberSelect request,
                                                      @Param("memberSelect") MemberSaleRequest memberSelect);


    /**
     * 会员销售excel导出总数查询
     *
     * @param request
     * @return
     */
    Long memberSalesCount(@Param("request") MemberSelect request,
                          @Param("memberSearchRequest") MemberSearchRequest memberSearchRequest);

    /**
     * 会员销售excel导出数据查询
     *
     * @param request
     * @return
     */
    List<MemberSalesExcelResponse> memberSalesList(@Param("request") MemberSelect request,
                                                   @Param("memberSearchRequest") MemberSearchRequest memberSearchRequest);


    /**
     * 手动升级之后退货，不能自动降级
     *
     * @param startTime
     * @param endTime
     * @param memberIdList
     * @return
     */
    List<MemberLevelLog> upReturn(@Param("startTime") LocalDateTime startTime,
                                  @Param("endTime") LocalDateTime endTime,
                                  @Param("memberIdList") List<String> memberIdList);

    List<PosOrderPo> selectCounter(@Param("memberId") String memberId);

    /**
     * 更新excel导入会员信息
     *
     * @param memberInfo
     * @return
     */
    Integer updateExcelMember(@Param("memberInfo") MemberInfo memberInfo);

    Integer updateWxMember(@Param("memberInfo") MemberInfo memberUpdate);

    Integer updateForWxMemberCard(@Param("memberId") String memberId);
}
