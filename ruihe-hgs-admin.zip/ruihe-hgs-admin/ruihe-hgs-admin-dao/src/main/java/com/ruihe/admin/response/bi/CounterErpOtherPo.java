package com.ruihe.admin.response.bi;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

@ApiModel(value = "CounterErpOtherPo", description = "柜台进销存报表-其他数量&金额")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CounterErpOtherPo implements Serializable {
    @ApiModelProperty(value = "柜台id")
    private String counterId;

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "业务类型")
    private Integer bizType;

    @ApiModelProperty("数量")
    private Integer qty;

    @ApiModelProperty("金额")
    private BigDecimal amt;
}
