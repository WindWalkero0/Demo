package com.ruihe.admin.mapper.order;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.response.member.BigCatProportionResponse;
import com.ruihe.admin.response.member.MediumCatProportionResponse;
import com.ruihe.admin.response.member.SmallCatProportionResponse;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.pojo.request.order.OrderRequest;
import com.ruihe.common.pojo.response.order.MemberOrderItemResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.util.List;

/**
 * <p>
 * pos销售订单子表 Mapper 接口
 * </p>
 *
 * @author William
 * @since 2019-10-18
 */
@Mapper
public interface PosOrderItemMapper extends BaseMapper<PosOrderItemPo> {
    /**
     * 产品大分类占比图
     */
    List<BigCatProportionResponse> queryBigCat(@Param("memberId") String memberId);

    /**
     * 产品中分类占比图
     */
    List<MediumCatProportionResponse> queryMediumCat(@Param("memberId") String memberId);

    /**
     * 产品小分类占比图
     */
    List<SmallCatProportionResponse> querySmallCat(@Param("memberId") String memberId);

    /**
     * 会员详情--购买记录的明细模式查询
     *
     * @param page
     * @param request
     * @param startTime
     * @param endTime
     * @return
     */
    IPage<MemberOrderItemResponse> selectOrderDetail(@Param("page") Page<MemberOrderItemResponse> page,
                                                     @Param("request") OrderRequest request,
                                                     @Param("startTime") LocalDate startTime,
                                                     @Param("endTime") LocalDate endTime);

    Long selectOrderDetailCount(@Param("request") OrderRequest request,
                                @Param("startTime") LocalDate startTime,
                                @Param("endTime") LocalDate endTime);
}
