package com.ruihe.admin.po;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author:Fangtao
 * @Date:2019/11/11 9:50
 */
/**
 * 点击导入流水号查看详情->条件查询
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberImportQueryPo implements Serializable {
    @ApiModelProperty("会员卡号")
    private String memberCardNumber;

    @ApiModelProperty("会员姓名")
    private String memberName;

    @ApiModelProperty("手机号")
    private String mobilePhone;

    @ApiModelProperty("生日")
    private String birthday;

    @ApiModelProperty("性别")
    private String sex;

    @ApiModelProperty("发卡BA（发卡人）")
    private String baId;

    @ApiModelProperty("发卡柜台")
    private String counterId;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("会员档案导入结果(0为,失败,1为,成功,2为处理中,3为,提示)")
    private Integer importResult;

    @ApiModelProperty("会员档案导入结果信息")
    private String resultMsg;
}
