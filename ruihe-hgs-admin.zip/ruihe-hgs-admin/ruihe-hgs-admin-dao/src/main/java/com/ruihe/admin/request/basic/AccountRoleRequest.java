package com.ruihe.admin.request.basic;

import com.ruihe.common.dao.bean.base.AccountRole;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@ApiModel("角色分配接收实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountRoleRequest {

    @ApiModelProperty("用户uid")
    public String userUid;
    @ApiModelProperty("用户名称")
    public String userName;

    @ApiModelProperty("角色集合")
    List<AccountRole> accountRoleList;


}

