package com.ruihe.admin.request.bi;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@ApiModel(value = "ProductBizDetailSelectRequest", description = "产品业务明细输出对象")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductBizDetailSelectRequest implements Serializable {

    @ApiModelProperty(value = "年月")
    private boolean monthly;

    @ApiModelProperty(value = "日期")
    private boolean daily;

    @ApiModelProperty("大类代码")
    private boolean bigCat;

    @ApiModelProperty("中类代码")
    private boolean mediumCat;

    @ApiModelProperty("小类代码")
    private boolean smallCat;

    @ApiModelProperty("厂商编码")
    private boolean prdBarCode;

    @ApiModelProperty("产品条码")
    private boolean goodsBarCode;

    @ApiModelProperty("产品名称")
    private boolean prdName;

    @ApiModelProperty("大区，一级")
    private boolean area;

    @ApiModelProperty("办事处，二级")
    private boolean office;

    @ApiModelProperty("柜台主管，三级")
    private boolean principal;

    @ApiModelProperty("柜台id")
    private boolean counterId;

    @ApiModelProperty("柜台")
    private boolean counterName;

    @ApiModelProperty("ba编码")
    private boolean baCode;

    @ApiModelProperty("ba名称")
    private boolean baName;

    @ApiModelProperty(value = "销售总金额")
    private boolean realAmt;

    @ApiModelProperty(value = "销售总支数")
    private boolean skQty;

    @ApiModelProperty(value = "产品总金额")
    private boolean prdAmt;

    @ApiModelProperty(value = "列维度选项")
    private ColSelect colSelect;

    @ApiModel(value = "ColSelect", description = "产品业务明细输出对象")
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ColSelect implements Serializable {
        @ApiModelProperty(value = "年月")
        private boolean monthly;

        @ApiModelProperty(value = "日期")
        private boolean daily;

        @ApiModelProperty("大类代码")
        private boolean bigCat;

        @ApiModelProperty("中类代码")
        private boolean mediumCat;

        @ApiModelProperty("小类代码")
        private boolean smallCat;

        @ApiModelProperty("厂商编码")
        private boolean prdBarCode;

        @ApiModelProperty("产品条码")
        private boolean goodsBarCode;

        @ApiModelProperty("产品名称")
        private boolean prdName;
    }
}
