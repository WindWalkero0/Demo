package com.ruihe.admin.request.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiModel("柜台操作接收类")
public class SelectCounterRequest {

    @ApiModelProperty("输入的查询信息")
    public String input;

    @ApiModelProperty("柜台状态")
    public Integer status;

    @ApiModelProperty("分页大小")
    public Integer pageSize;

    @ApiModelProperty("当前页数")
    public Integer pageNumber;

}
