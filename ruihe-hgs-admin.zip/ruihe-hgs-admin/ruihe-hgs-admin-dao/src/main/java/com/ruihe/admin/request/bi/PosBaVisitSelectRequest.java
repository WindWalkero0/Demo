package com.ruihe.admin.request.bi;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author fly
 * @Description
 * @create 2020年10月19日18:05:57
 */
@ApiModel(value = "PosBaVisitSelectRequest", description = "服务记录报表输出")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosBaVisitSelectRequest implements Serializable {

    /*----------------行----------------*/

    @ApiModelProperty("大区，一级")
    private boolean area;

    @ApiModelProperty("办事处，二级")
    private boolean office;

    @ApiModelProperty("柜台主管，三级")
    private boolean principal;

    @ApiModelProperty("柜台id")
    private boolean counterId;

    @ApiModelProperty("柜台")
    private boolean counterName;

    @ApiModelProperty("ba编号")
    private boolean baCode;

    @ApiModelProperty("ba姓名")
    private boolean baName;

    /*----------------列----------------*/

    @ApiModelProperty("统计类别")
    private List<String> visitType;

}
