package com.ruihe.admin.mapper.communicate;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.po.MsgTemplatePo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author:Fangtao
 * @Date:2019/11/15 19:55
 */
@Mapper
public interface MsgMapper extends BaseMapper<MsgTemplatePo> {
    /**
     * 模板管理查询
     *
     * @return
     */
    List<MsgTemplatePo> queryTemplate();
}
