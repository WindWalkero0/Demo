package com.ruihe.admin.response.erp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;


@ApiModel(description = "产品库存明细包括在途库存 列表数据")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhProductStockDetailResponse implements Serializable {

    @ApiModelProperty(value = "列表数据")
    private List<WhProductStockDetailVo> list;

    @ApiModelProperty(value = "累计库存")
    private Integer totalStock;

    @ApiModelProperty(value = "查询缓存key")
    private String key;
}
