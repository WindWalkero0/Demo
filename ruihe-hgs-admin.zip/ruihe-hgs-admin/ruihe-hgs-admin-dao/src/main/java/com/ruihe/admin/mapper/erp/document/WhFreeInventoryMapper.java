package com.ruihe.admin.mapper.erp.document;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.response.erp.*;
import com.ruihe.common.dao.bean.warehouse.WhFreeInventoryPo;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.request.erp.WhFreeInventoryApplyRequest;
import com.ruihe.admin.request.erp.WhFreeInventoryQueryRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-21 17:53
 */
@Mapper
public interface WhFreeInventoryMapper extends BaseMapper<WhFreeInventoryPo> {
    /**
     * 根据条件查询盘点单申请
     *
     * @param page
     * @param request
     * @param queryRequest
     * @return
     */
    IPage<WhFreeInventoryApplyResponse> applyList(@Param("page") Page<WhFreeInventoryApplyResponse> page,
                                                  @Param("request") WhFreeInventoryApplyRequest request,
                                                  @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 查询出盘点单申请结果数据
     *
     * @param request
     * @param queryRequest
     * @return
     */
    WhFreeInventoryResultResponse applyListResult(@Param("request") WhFreeInventoryApplyRequest request,
                                                  @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 根据条件查询盘点单
     *
     * @param page
     * @param request
     * @param queryRequest
     * @return
     */
    IPage<WhFreeInventoryQueryResponse> queryFreeInventory(@Param("page") Page<WhFreeInventoryQueryResponse> page,
                                                           @Param("request") WhFreeInventoryQueryRequest request,
                                                           @Param("queryRequest") OrgQueryConditionRequest queryRequest);


    /**
     * 查询出盘点单结果数据
     *
     * @param request
     * @param queryRequest
     * @return
     */
    WhFreeInventoryResultResponse queryResult(@Param("request") WhFreeInventoryQueryRequest request,
                                              @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 查询数据导出总量
     *
     * @param request
     * @param queryRequest
     * @return
     */
    Long applyListCount(@Param("request") WhFreeInventoryApplyRequest request,
                        @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 盘点申请详情excel导出查询
     *
     * @param request
     * @param queryRequest
     * @return
     */
    List<FreeInvApplyExcelResponse> applyListExcel(@Param("request") WhFreeInventoryApplyRequest request,
                                                   @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 自由盘点单据主表查询数量
     *
     * @param request
     * @param queryRequest
     * @return
     */
    Long queryMasterListCount(@Param("request") WhFreeInventoryQueryRequest request,
                              @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 自由盘点单据主表查询数量
     *
     * @param request
     * @param queryRequest
     * @return
     */
    List<FreeInvMasterExcelResponse> masterListExcel(@Param("request") WhFreeInventoryQueryRequest request,
                                                     @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 自由盘点单据子表查询数量
     *
     * @param request
     * @param queryRequest
     * @return
     */
    Long queryItemListCount(@Param("request") WhFreeInventoryQueryRequest request,
                            @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 自由盘点单据子表查询excel导出
     *
     * @param request
     * @param queryRequest
     * @return
     */
    List<FreeInvItemExcelResponse> itemListExcel(@Param("request") WhFreeInventoryQueryRequest request,
                                                 @Param("queryRequest") OrgQueryConditionRequest queryRequest);
}
