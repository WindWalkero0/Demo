package com.ruihe.admin.request.bi;

import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author 梁远
 * @Description
 * @create 2020-02-05 09:50
 */
@ApiModel(value = "MemberPurchaseTraceReportRequest", description = "会员购买跟踪报表请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberPurchaseTraceReportRequest implements Serializable {

    @ApiModelProperty(value = "输出项")
    @NotNull(message = "输出项不能为空")
    private MemberPurchaseSelectRequest selectRequest;

    @ApiModelProperty(value = "入会开始时间")
    private LocalDate joinStartTime;

    @ApiModelProperty(value = "入会结束时间")
    private LocalDate joinEndTime;

    @ApiModelProperty(value = "购买开始时间")
    private LocalDate startTime;

    @ApiModelProperty(value = "购买结束时间")
    private LocalDate endTime;

    @ApiModelProperty(value = "渠道")
    private String channelCode;

    @ApiModelProperty("标签")
    @NotBlank(message = "标签不能为空")
    @Size(max=30,message = "标签最大长度为30个字符")
    private String tag;

    @ApiModelProperty("查询图片地址")
    private String picUrl;

    @ApiModelProperty("组织模式查询条件")
    @Builder.Default
    private OrgQueryConditionRequest orgQueryConditionRequest = new OrgQueryConditionRequest();
}
