package com.ruihe.admin.request.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@ApiModel("渠道接收类")
public class ChannelRequest implements Serializable {

    @ApiModelProperty("渠道code")
    public String channelCode;

    @ApiModelProperty("渠道名称")
    public String channelName;

    @ApiModelProperty("是否删除")
    public Integer isDel;

    @ApiModelProperty("渠道code集合")
    List<String> channelCodes;

    @ApiModelProperty("当前页数")
    public Integer pageNumber;

    @ApiModelProperty("分页大小")
    public Integer pageSize;


}
