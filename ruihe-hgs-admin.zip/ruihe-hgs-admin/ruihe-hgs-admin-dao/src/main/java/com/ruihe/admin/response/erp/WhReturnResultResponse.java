package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-22 9:54
 */
@ApiModel(value = "WhReturnResultResponse", description = "退库单数量金额返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class WhReturnResultResponse implements Serializable {

    @ApiModelProperty(value = "申请数量")
    private Integer applyQty;

    @ApiModelProperty(value = "申请金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal applyAmt;

}
