package com.ruihe.admin.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.AccountRole;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 梁远
 * @Description
 * @create 2020-01-02 10:28
 */
@Mapper
public interface AccountRoleMapper extends BaseMapper<AccountRole> {
}
