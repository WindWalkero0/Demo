package com.ruihe.admin.mapper.terminal;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.po.PosBannerPo;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface PosBannerMapper extends BaseMapper<PosBannerPo> {

}
