package com.ruihe.admin.response.basic;

import lombok.Data;

/**
 * @author 梁远
 * @Description
 * @create 2019-06-19 10:38
 */
@Data
public class AgentResponse {

    private Integer id;

    //所属品牌
    private String brandId;

    //代理商代码
    private String agentId;

    //代理商名称
    private String agentName;

    //代理商简称
    private String agentShortName;

    //代理商等级
    private Integer agentLevel;

    //所属省份ID
    private Integer provinceId;

    //所属城市ID
    private Integer cityId;

    //上级代理商ID
    private Integer upAgentId;

    //代理商类别
    private Integer agentType;

    //产品价格适用区分
    private Integer priceApplicable;

    //联系人手机
    private String mobilphone;

    //联系电话
    private String telphone;

    //法人代表
    private String representative;

    //有效区分
    private Integer status;


    //建立日期
    private String createTime;

    //更新日期
    private String updateTime;


    /*
    代理商展示信息需要的字段
     */
    //所属区域
    private String regional;

    //上级代理商人名称
    private String upAgentName;
    //省份
    private String provinceName;
    //城市
    private String cityName;
}
