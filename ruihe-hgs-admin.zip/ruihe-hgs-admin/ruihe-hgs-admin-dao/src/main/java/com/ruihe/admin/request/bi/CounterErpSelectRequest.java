package com.ruihe.admin.request.bi;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2020-02-05 09:50
 */
@ApiModel(value = "CounterErpSelectRequest", description = "柜台进销存输出对象")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CounterErpSelectRequest implements Serializable {

    @ApiModelProperty(value = "柜台")
    private boolean counter;

    @ApiModelProperty("期初库存")
    private boolean beginningStocks;

    @ApiModelProperty("期初库存金额")
    private boolean beginningAmt;

    @ApiModelProperty("销售数量")
    private boolean salesQty;

    @ApiModelProperty("销售金额")
    private boolean salesAmt;

    @ApiModelProperty("退货数量")
    private boolean returnQty;

    @ApiModelProperty("退货金额")
    private boolean returnAmt;

    @ApiModelProperty("入库数量")
    private boolean enterQty;

    @ApiModelProperty("入库金额")
    private boolean enterAmt;

    @ApiModelProperty("退库数量")
    private boolean retreatQty;

    @ApiModelProperty("退库金额")
    private boolean retreatAmt;

    @ApiModelProperty("调出数量")
    private boolean outQty;

    @ApiModelProperty("调出金额")
    private boolean outAmt;

    @ApiModelProperty("调入数量")
    private boolean inQty;

    @ApiModelProperty("调入金额")
    private boolean inAmt;

    @ApiModelProperty("盘盈数量")
    private boolean inventorySurplusQty;

    @ApiModelProperty("盘盈金额")
    private boolean inventorySurplusAmt;

    @ApiModelProperty("盘亏数量")
    private boolean inventoryLossesQty;

    @ApiModelProperty("盘亏金额")
    private boolean inventoryLossesAmt;

    @ApiModelProperty("订货数量")
    private boolean orderQty;

    @ApiModelProperty("订货金额")
    private boolean orderAmt;

    @ApiModelProperty("礼品领用数量")
    private boolean giftQty;

    @ApiModelProperty("礼品领用金额")
    private boolean giftAmt;

    @ApiModelProperty("期末库存数量")
    private boolean endingQty;

    @ApiModelProperty("期末库存金额")
    private boolean endingAmt;
}
