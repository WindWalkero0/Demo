package com.ruihe.admin.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.integral.IntegralOrderPo;
import com.ruihe.admin.response.member.IntegralRecordResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员详情页首页->积分记录
 *
 * @Anthor:Fangtao
 * @Date:2019/12/5 20:17
 */
@Mapper
public interface MemberIntegralRecordMapper extends BaseMapper<IntegralOrderPo> {
    /**
     * 查询会员积分记录
     */
    List<IntegralRecordResponse> queryRecord(@Param("memberId") String memberId);
}
