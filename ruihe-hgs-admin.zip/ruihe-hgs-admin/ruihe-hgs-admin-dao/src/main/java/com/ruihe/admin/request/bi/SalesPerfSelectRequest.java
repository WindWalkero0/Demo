package com.ruihe.admin.request.bi;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Anthor:Fangtao
 * @Date:2020/2/5 11:06
 */
@ApiModel(value = "SalesPerfSelectRequest", description = "销售业绩跟踪输出对象")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SalesPerfSelectRequest implements Serializable {
    @ApiModelProperty(value = "年月")
    private boolean monthly;

    @ApiModelProperty(value = "日期")
    private boolean daily;

    @ApiModelProperty("大区，一级")
    private boolean area;

    @ApiModelProperty("办事处，二级")
    private boolean office;

    @ApiModelProperty("柜台主管，三级")
    private boolean principal;

    @ApiModelProperty("柜台id，四级")
    private boolean counterId;

    @ApiModelProperty("柜台")
    private boolean counterName;

    @ApiModelProperty("ba编号")
    private boolean baCode;

    @ApiModelProperty("ba姓名")
    private boolean baName;

    @ApiModelProperty("销售总金额")
    private boolean realAmt;

    @ApiModelProperty("实物销售总支数")
    private boolean goodsQty;

    @ApiModelProperty("护肤品类销售总支数")
    private boolean skQty;

    @ApiModelProperty("销售总单数")
    private boolean orderQty;

    @ApiModelProperty("客单价")
    private boolean pct;

    @ApiModelProperty("连带率")
    private boolean jr;

    @ApiModelProperty("经营新会员人数")
    private boolean optNewMem;

    @ApiModelProperty("销售天数")
    private boolean salesDays;

    @ApiModelProperty("老会员购买人数")
    private boolean vetPur;
    @ApiModelProperty("老客单")
    private boolean vetPct;
    @ApiModelProperty("经营新客单")
    private boolean optNewPct;

    @ApiModelProperty("老会员重复购买率（老会员购买单数/老会员购买人数）,老会员复购率")
    private boolean vetRepurRate;
    @ApiModelProperty("新会员重复购买率（新会员购买单数/会员入会数量）")
    private boolean newRepurRate;
}
