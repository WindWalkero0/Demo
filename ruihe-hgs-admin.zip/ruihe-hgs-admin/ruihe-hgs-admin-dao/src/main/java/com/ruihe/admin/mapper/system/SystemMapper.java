package com.ruihe.admin.mapper.system;

import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.system.SystemConfigPo;
import com.ruihe.common.pojo.request.system.SearchConfigRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface SystemMapper {

    @Ella(Describe = "查询配置信息")
    List<SystemConfigPo> searchConfig(@Param("request") SearchConfigRequest request);
}
