package com.ruihe.admin.request.erp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@ApiModel(description = "实时库存查询接收类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RealtimeStockRequest implements Serializable {
    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("厂商编码，在查询列表的时候不进行参数校验")
    @NotBlank(message = "产品编码不能为空")
    private String prdBarCode;

    @ApiModelProperty(value = "当前页数")
    @Builder.Default
    private Integer pageNumber = 1;

    @ApiModelProperty(value = "每页记录数", hidden = true)
    @Builder.Default
    private Integer pageSize = 50;

    @ApiModelProperty(value = "组织模式查询条件")
    private OrgQueryConditionRequest orgQueryConditionRequest;
}
