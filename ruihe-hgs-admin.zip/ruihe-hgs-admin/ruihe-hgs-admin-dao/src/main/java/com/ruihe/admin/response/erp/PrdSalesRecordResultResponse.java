package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Anthor:Fangtao
 * @Date:2019/11/28 15:23
 */
@ApiModel(value = "PrdSalesRecordResultResponse", description = "销量总数,销量金额,订单数,会员数结果返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PrdSalesRecordResultResponse implements Serializable {
    @ApiModelProperty(value = "销售总数量")
    private Integer saleQty;

    @ApiModelProperty(value = "销售总金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal saleAmt;

    @ApiModelProperty(value = "订单数")
    private Integer orderQty;

    @ApiModelProperty(value = "会员数")
    private Integer memberQty;
}
