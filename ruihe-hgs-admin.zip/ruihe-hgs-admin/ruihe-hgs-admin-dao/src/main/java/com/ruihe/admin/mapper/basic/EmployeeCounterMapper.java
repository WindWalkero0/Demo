package com.ruihe.admin.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.po.EmployeeCounterImportPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


/**
 * @author huangjie
 * @Description
 * @create 2021-06-29 17:14
 */
@Mapper
public interface EmployeeCounterMapper extends BaseMapper<EmployeeCounterImportPo> {

    int batchInsert(@Param("list") List<EmployeeCounterImportPo> list);
}
