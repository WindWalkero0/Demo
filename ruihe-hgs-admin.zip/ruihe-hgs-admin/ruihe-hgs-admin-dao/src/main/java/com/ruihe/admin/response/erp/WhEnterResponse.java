package com.ruihe.admin.response.erp;

import com.ruihe.common.pojo.PageVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Anthor:Fangtao
 * @Date:2020/3/10 14:49
 */
@ApiModel(value = "WhEnterResponse", description = "查询发货单响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhEnterResponse implements Serializable {
    @ApiModelProperty(value = "发货单返回前端Vo")
    private PageVO pageVo;

    @ApiModelProperty(value = "发货单数据结果返回前端Vo")
    private WhEnterResultResponse whEnterResultResponse;

    @ApiModelProperty(value = "查询缓存key")
    private String key;
}
