package com.ruihe.admin.response.erp;

import com.ruihe.common.pojo.PageVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Anthor:Fangtao
 * @Date:2019/11/28 15:45
 */
@ApiModel(value = "PrdSalesRecordResponse", description = "查询产品销售记录单响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PrdSalesRecordResponse implements Serializable {
    @ApiModelProperty(value = "产品销售返回前端Vo")
    private PageVO<PrdSalesAndRecordResponse> info;

    @ApiModelProperty(value = "产品记录数据结果返回前端Vo")
    PrdSalesRecordResultResponse prdSalesRecordResultResponse;

    @ApiModelProperty(value = "查询缓存key")
    String key;
}
