package com.ruihe.admin.response.erp;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-22 11:03
 */
@ApiModel(value = "FreeInvMasterExcelResponse", description = "自由盘点主表excel导出")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class FreeInvMasterExcelResponse implements Serializable {

    @ExcelProperty(value = "盘点单号", index = 0)
    private String invNo;

    @ExcelProperty(value = "盘点部门编号", index = 1)
    private String counterId;

    @ExcelProperty(value = "盘点部门名称", index = 2)
    private String counterName;

    @ExcelProperty(value = "实盘数量", index = 3)
    private Integer realQty;

    @ExcelProperty(value = "盘差数量", index = 4)
    private Integer diffQty;

    @ExcelProperty(value = "盘点日期", index = 5)
    private String createTime;

    @ExcelProperty(value = "盘差金额", index = 6)
    private BigDecimal diffAmt;

    @ExcelProperty(value = "操作员", index = 7)
    private String baName;

    @ExcelProperty(value = "盘点原因", index = 8)
    private String invRsn;
}
