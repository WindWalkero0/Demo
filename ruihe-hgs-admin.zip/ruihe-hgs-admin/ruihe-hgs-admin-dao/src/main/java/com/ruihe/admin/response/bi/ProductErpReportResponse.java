package com.ruihe.admin.response.bi;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Author: ly
 * @Date: 2020-02-05 14:51
 * @Description 1.0
 */
@ApiModel(value = "ProductErpReportResponse", description = "产品进销存报表查询vo")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductErpReportResponse implements Serializable {

    @ApiModelProperty(value = "厂商编码")
    private String prdBarCode;

    @ApiModelProperty(value = "产品条码")
    private String goodsBarCode;

    @ApiModelProperty(value = "产品名称")
    private String prdName;

    @ApiModelProperty(value = "产品价格")
    private String salePrice;

    @ApiModelProperty(value = "产品")
    private String prd;

    @ApiModelProperty(value = "柜台id")
    private String counterId;

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty("期初库存")
    private Integer oiQty;

    @ApiModelProperty("期初库存金额")
    private BigDecimal oiAmt;

    @ApiModelProperty("销售数量")
    private Integer salesQty;

    @ApiModelProperty("销售金额")
    private BigDecimal salesAmt;

    @ApiModelProperty("退货数量")
    private Integer returnQty;

    @ApiModelProperty("退货金额")
    private BigDecimal returnAmt;

    @ApiModelProperty("入库数量")
    private Integer enterQty;

    @ApiModelProperty("入库金额")
    private BigDecimal enterAmt;

    @ApiModelProperty("退库数量")
    private Integer retreatQty;

    @ApiModelProperty("退库金额")
    private BigDecimal retreatAmt;

    @ApiModelProperty("调出数量")
    private Integer outQty;

    @ApiModelProperty("调出金额")
    private BigDecimal outAmt;

    @ApiModelProperty("调入数量")
    private Integer inQty;

    @ApiModelProperty("调入金额")
    private BigDecimal inAmt;

    @ApiModelProperty("盘盈数量")
    private Integer inventorySurplusQty;

    @ApiModelProperty("盘盈金额")
    private BigDecimal inventorySurplusAmt;

    @ApiModelProperty("盘亏数量")
    private Integer inventoryLossesQty;

    @ApiModelProperty("盘亏金额")
    private BigDecimal inventoryLossesAmt;

    @ApiModelProperty("订货数量")
    private Integer orderQty;

    @ApiModelProperty("订货金额")
    private BigDecimal orderAmt;

    @ApiModelProperty("礼品领用数量")
    private Integer giftQty;

    @ApiModelProperty("礼品领用金额")
    private BigDecimal giftAmt;

    @ApiModelProperty("期末库存数量")
    private Integer eiQty;

    @ApiModelProperty("期末库存金额")
    private BigDecimal eiAmt;
}
