package com.ruihe.admin.response.member;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/5 14:35
 */
@ApiModel(value = "MemberAnalysisResponse", description = "会员首页总计响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberAnalysisResponse implements Serializable {
    @ApiModelProperty(value = "月份数据")
    private String month;
    @ApiModelProperty(value = "购买次数")
    private Integer buyCount;
    @ApiModelProperty(value = "购买金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal buyAmt;
    @ApiModelProperty(value = "购买数量")
    private Integer buyQty;
}
