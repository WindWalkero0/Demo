package com.ruihe.admin.response.erp;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;


@ApiModel(description = "产品库存包括在途库存")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhProductStockVo implements Serializable {
    @ExcelProperty(value = "产品编码", index = 0)
    @ColumnWidth(20)
    @ApiModelProperty(value = "产品编码")
    private String prdBarCode;

    @ExcelProperty(value = "商品编码", index = 1)
    @ColumnWidth(20)
    @ApiModelProperty(value = "商品编码")
    private String goodsBarCode;

    @ExcelProperty(value = "产品名称", index = 2)
    @ColumnWidth(15)
    @ApiModelProperty(value = "产品名称")
    private String prdName;

    @ExcelProperty(value = "零售价格", index = 3)
    @ColumnWidth(15)
    @ApiModelProperty(value = "普通价格")
    @ExcelIgnore
    private BigDecimal prdPrice;

    @ExcelProperty(value = "会员价格", index = 3)
    @ColumnWidth(15)
    @ApiModelProperty(value = "会员价格")
    private BigDecimal memberPrice;

    @ExcelProperty(value = "大类代码", index = 5)
    @ColumnWidth(15)
    @ApiModelProperty(value = "大类代码")
    @ExcelIgnore
    private Integer bigCatCode;

    @ExcelProperty(value = "大类名称", index = 6)
    @ColumnWidth(15)
    @ApiModelProperty(value = "大类名称")
    @ExcelIgnore
    private String bigCatName;

    @ExcelProperty(value = "中类代码", index = 7)
    @ColumnWidth(15)
    @ApiModelProperty(value = "中类代码")
    @ExcelIgnore
    private Integer mediumCatCode;

    @ExcelProperty(value = "中类名称", index = 8)
    @ColumnWidth(15)
    @ApiModelProperty(value = "中类名称")
    @ExcelIgnore
    private String mediumCatName;

    @ExcelProperty(value = "小类代码", index = 9)
    @ColumnWidth(15)
    @ApiModelProperty(value = "小类代码")
    @ExcelIgnore
    private Integer smallCatCode;

    @ExcelProperty(value = "小类名称", index = 10)
    @ColumnWidth(15)
    @ApiModelProperty(value = "小类名称")
    @ExcelIgnore
    private String smallCatName;

    @ExcelProperty(value = "实时库存", index = 4)
    @ColumnWidth(15)
    @ApiModelProperty(value = "实时库存")
    private Integer stock;

    @ExcelProperty(value = "在途库存", index = 5)
    @ColumnWidth(15)
    @ApiModelProperty(value = "在途库存")
    private Integer stockOnRoad;
}
