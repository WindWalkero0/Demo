package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @Anthor:Fangtao
 * @Date:2019/11/25 17:10
 */
@ApiModel(value = "WhTransferQueryResponse", description = "调拨单处理返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class WhTransferQueryResponse implements Serializable {
    @ApiModelProperty(value = "申请调入柜台号")
    private String inCounterId;
    @ApiModelProperty(value = "申请调入柜台名称")
    private String inCounterName;
    @ApiModelProperty(value = "调出柜台ID")
    private String outCounterId;
    @ApiModelProperty(value = "调出柜台名称")
    private String outCounterName;
    @ApiModelProperty(value = "申请总数")
    private Integer ackInQty;
    @ApiModelProperty(value = "申请单号")
    private String transferOrderNo;
    @ApiModelProperty(value = "时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:dd:ss")
    private LocalDateTime createTime;
    @ApiModelProperty(value = "状态")
    private Integer status;
}
