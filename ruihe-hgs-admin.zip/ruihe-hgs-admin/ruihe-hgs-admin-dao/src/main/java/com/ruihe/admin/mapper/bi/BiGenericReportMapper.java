package com.ruihe.admin.mapper.bi;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.bi.BiGenericReport;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BiGenericReportMapper extends BaseMapper<BiGenericReport> {

    default List<BiGenericReport> all() {
        return selectList(null);
    }
}
