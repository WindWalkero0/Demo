package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Anthor:Fangtao
 * @Date:2020/3/10 14:45
 */
@ApiModel(value = "WhEnterResultResponse", description = "发货单总数与总金额处理返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class WhEnterResultResponse implements Serializable {
    @ApiModelProperty(value = "总数量")
    private Integer qty;
    @ApiModelProperty(value = "总金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal amt;
}
