package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Anthor:fly
 * @Date:2020年7月10日09:15:13
 */
@ApiModel(value = "PosLaingItemListResponse", description = "预订单订单详情返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PosLaingItemListResponse implements Serializable {
    @ApiModelProperty(value = "产品条码(对外标准条码)")
    private String prdBarCode;
    @ApiModelProperty(value = "产品名称")
    private String prdName;
    @ApiModelProperty(value = "商品条码")
    private String goodsBarCode;
    @ApiModelProperty(value = "销售价")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal salePrice;
    @ApiModelProperty(value = "购买数量")
    private Integer purQty;
    @ApiModelProperty("金额")
    private BigDecimal amount;
    @ApiModelProperty(value = "已提数量")
    private Integer extractQty;
    @ApiModelProperty(value = "剩余数量")
    private Integer surplusQty;
    @ApiModelProperty(value = "已退货数量")
    private Integer returnQty;
    @ApiModelProperty(value = "已退金额")
    private BigDecimal returnAmt;
    @ApiModelProperty(value = "虚拟商品")
    private Integer isVirtual;
}
