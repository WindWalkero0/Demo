package com.ruihe.admin.response.erp;

import com.alibaba.excel.annotation.ExcelProperty;
import com.ruihe.common.converter.LocalDateTimeConverter;
import com.ruihe.common.converter.PayChannelConverter;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author 梁远
 * @description
 * @date 2019-11-22 11:03
 */
@ApiModel(value = "PaymentExcelResponse", description = "支付方式报表excel导出")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PaymentExcelResponse implements Serializable {

    @ExcelProperty(value = "销售单号", index = 0)
    private String orderNo;

    @ExcelProperty(value = "销售时间", index = 1, converter = LocalDateTimeConverter.class)
    private LocalDateTime bizTime;

    @ExcelProperty(value = "柜台编码", index = 2)
    private String counterId;

    @ExcelProperty(value = "柜台名称", index = 3)
    private String counterName;

    @ExcelProperty(value = "BA编码", index = 4)
    private String baCode;

    @ExcelProperty(value = "BA名称", index = 5)
    private String baName;

    @ExcelProperty(value = "支付方式", index = 6, converter = PayChannelConverter.class)
    private String payChannel;

    @ExcelProperty(value = "支付金额", index = 7)
    private BigDecimal payAmt;

    @ExcelProperty(value = "订单金额", index = 8)
    private BigDecimal realAmt;

}
