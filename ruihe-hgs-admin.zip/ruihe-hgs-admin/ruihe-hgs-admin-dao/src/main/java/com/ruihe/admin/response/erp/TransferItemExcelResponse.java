package com.ruihe.admin.response.erp;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-22 11:03
 */
@ApiModel(value = "TransferItemExcelResponse", description = "调拨单子表excel导出")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class TransferItemExcelResponse implements Serializable {

    @ExcelProperty(value = "调拨申请单号", index = 0)
    private String transferOrderNo;

    @ExcelProperty(value = "申请部门代码", index = 1)
    private String inCounterId;

    @ExcelProperty(value = "申请部门名称", index = 2)
    private String inCounterName;

    @ExcelProperty(value = "申请人代号", index = 3)
    private String inBaCode;

    @ExcelProperty(value = "申请人名称", index = 4)
    private String inBaName;

    @ExcelProperty(value = "调出部门编号", index = 5)
    private String outCounterId;

    @ExcelProperty(value = "调出部门名称", index = 6)
    private String outCounterName;

    @ExcelProperty(value = "厂商编码", index = 7)
    private String prdBarCode;

    @ExcelProperty(value = "产品条码", index = 8)
    private String goodsBarCode;

    @ExcelProperty(value = "产品名称", index = 9)
    private String prdName;

    @ExcelProperty(value = "调拨数量", index = 10)
    private Integer inQty;

    @ExcelProperty(value = "产品价格", index = 11)
    private BigDecimal memberPrice;

    @ExcelProperty(value = "调拨金额", index = 12)
    private BigDecimal inAmt;

    @ExcelProperty(value = "处理状态", index = 13)
    private String status;

    @ExcelProperty(value = "调拨申请日期", index = 14)
    private String createTime;

    @ExcelProperty(value = "调出日期", index = 15)
    private String ackOutTime;
}
