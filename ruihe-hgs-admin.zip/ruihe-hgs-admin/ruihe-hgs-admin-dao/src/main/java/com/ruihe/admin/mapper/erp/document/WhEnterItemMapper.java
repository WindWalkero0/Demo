package com.ruihe.admin.mapper.erp.document;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhEnterItemPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Anthor:Fangtao
 * @Date:2020/3/10 11:07
 */
@Mapper
public interface WhEnterItemMapper extends BaseMapper<WhEnterItemPo> {
}
