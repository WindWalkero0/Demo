package com.ruihe.admin.response.member;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @Auther: caichunxiang
 * @Date 2019/12/5
 */
@ApiModel(value = "MemberSaleOrderResponse", description = "会员首页购买记录详情")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberSaleOrderInfoResponse implements Serializable {

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "实付金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal realAmt;

    @ApiModelProperty(value = "购买商品总数量")
    private Integer goodsQty;

    @ApiModelProperty(value = "交易类型，1销售,-1退货")
    private Integer transType;

    @ApiModelProperty(value = "订单类型，1销售,2预定单")
    private Integer orderType;

    @ApiModelProperty("描述，销售,预定单,积分兑换,退货。。。")
    private String desc;

    @ApiModelProperty(value = "活动类型 0兑换活动  1优惠券  2促销活动  3 不参加活动  4 发券活动 5秉坤多活动")
    private Integer activityType;

    @ApiModelProperty(value = "订单创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
}
