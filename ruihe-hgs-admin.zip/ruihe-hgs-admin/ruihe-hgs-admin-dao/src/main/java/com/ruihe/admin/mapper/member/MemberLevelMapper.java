package com.ruihe.admin.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.member.MemberLevel;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-29 13:37
 */
@Mapper
public interface MemberLevelMapper extends BaseMapper<MemberLevel> {
}
