package com.ruihe.admin.response.bi;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@ApiModel(value = "ProductErpOtherPo", description = "产品进销存报表-其他数量&金额")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductErpOtherPo implements Serializable {
    @ApiModelProperty(value = "厂商编码")
    private String prdBarCode;

    @ApiModelProperty(value = "产品条码")
    private String goodsBarCode;

    @ApiModelProperty(value = "产品名称")
    private String prdName;

    @ApiModelProperty(value = "产品价格")
    private String salePrice;

    @ApiModelProperty(value = "柜台id")
    private String counterId;

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "业务类型")
    private Integer bizType;

    @ApiModelProperty("数量")
    private Integer qty;

    @ApiModelProperty("金额")
    private BigDecimal amt;
}
