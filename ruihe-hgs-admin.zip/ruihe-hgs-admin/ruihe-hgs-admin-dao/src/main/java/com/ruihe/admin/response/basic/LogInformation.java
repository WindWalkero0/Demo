package com.ruihe.admin.response.basic;


import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class LogInformation {

    public final static String field_index = "admin_request_log";
    public final static String field_operationUserId = "operationUserId";
    public final static String field_operationUserName = "operationUserName";
    public final static String field_ip = "ip";
    public final static String field_url = "url";
    public final static String field_httpMethod = "httpMethod";
    public final static String field_classMethod = "classMethod";
    public final static String field_classMethodDesc = "classMethodDesc";
    public final static String field_requestParams = "requestParams";
    public final static String field_result = "result";
    public final static String field_timeCost = "timeCost";
    public final static String field_createTime = "createTime";
    public final static String field_administrator = "brandadminHZYJ";


    private String operationUserId;
    private String operationUserName;
    private String ip;
    private String url;
    private String httpMethod;
    private String classMethod;
    private List<String> classMethodDesc;
    private Object requestParams;
    private Object result;
    private Long timeCost;
    private Date createTime;
}
