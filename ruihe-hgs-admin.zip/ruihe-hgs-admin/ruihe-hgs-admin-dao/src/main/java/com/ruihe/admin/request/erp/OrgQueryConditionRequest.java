package com.ruihe.admin.request.erp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-22 17:39
 */
@ApiModel(value = "OrgQueryConditionRequest", description = "erp模块通用查询组织模式请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrgQueryConditionRequest implements Serializable {

    @ApiModelProperty("大区")
    private String orgAreaCode;

    @ApiModelProperty("办事处")
    private String orgOfficeCode;

    @ApiModelProperty("柜台主管")
    private String orgPrincipalCode;

    @ApiModelProperty("柜台")
    private String counterId;

    @ApiModelProperty("BA代码")
    private String baCode;

    @ApiModelProperty("部门状态:0无效，1有效")
    private Integer orgStatus;

    @ApiModelProperty("部门类型：0测试，1正式")
    private Integer orgType;

    @ApiModelProperty(value = "产品系列编号列表")
    private List<Integer> seriesCodeList;

    @ApiModelProperty(value = "分类编号列表")
    private List<Integer> categoryCodeList;

    @ApiModelProperty(value = "发卡柜台id list9")
    @NotEmpty(message = "组织结构必选")
    private List<String> issueCounterIdList;
}
