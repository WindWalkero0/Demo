package com.ruihe.admin.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.ProductSortItemPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-05 13:39
 */
@Mapper
public interface ProductSortItemMapper extends BaseMapper<ProductSortItemPo> {
}
