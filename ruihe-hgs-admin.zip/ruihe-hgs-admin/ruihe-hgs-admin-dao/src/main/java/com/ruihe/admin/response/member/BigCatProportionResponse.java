package com.ruihe.admin.response.member;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 产品各类占比图->产品大分类
 *
 * @Anthor:Fangtao
 * @Date:2019/12/5 17:31
 */
@ApiModel(value = "BigCatProportionResponse", description = "产品大分类占比图响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BigCatProportionResponse implements Serializable {
    @ApiModelProperty(value = "大分类名称")
    private String bigCatName;
    @ApiModelProperty(value = "每个大分类对应的数量")
    private Integer qty;
    @ApiModelProperty(value = "大分类编码")
    private Integer bigCatCode;
}
