package com.ruihe.admin.mapper.erp.document;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.common.dao.bean.warehouse.WhReturnPo;
import com.ruihe.common.pojo.response.stock.WhReturnApplyExcelResponse;
import com.ruihe.common.pojo.response.stock.WhReturnApplyItemExcelResponse;
import com.ruihe.common.pojo.response.stock.WhReturnItemExcelResponse;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.request.erp.WhReturnApplyRequest;
import com.ruihe.admin.request.erp.WhReturnRequest;
import com.ruihe.admin.response.erp.WhReturnApplyResponse;
import com.ruihe.admin.response.erp.WhReturnResultResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-23 18:03
 */
@Mapper
public interface WhReturnMapper extends BaseMapper<WhReturnPo> {
    /**
     * 退库申请单查询
     *
     * @param page
     * @param request
     * @param queryRequest
     * @return
     */
    IPage<WhReturnApplyResponse> applyList(@Param("page") Page<WhReturnApplyResponse> page,
                                           @Param("request") WhReturnApplyRequest request,
                                           @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 退库申请结果查询
     *
     * @param request
     * @param queryRequest
     * @return
     */
    WhReturnResultResponse applyResult(@Param("request") WhReturnApplyRequest request,
                                       @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 退库单查询
     *
     * @param page
     * @param request
     * @param queryRequest
     * @return
     */
    IPage<WhReturnApplyResponse> returnList(@Param("page") Page<WhReturnApplyResponse> page,
                                            @Param("request") WhReturnRequest request,
                                            @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    WhReturnResultResponse returnResult(@Param("request") WhReturnRequest request,
                                        @Param("queryRequest") OrgQueryConditionRequest queryRequest);


    /**
     * excel导出
     *
     * @param request
     * @param queryRequest
     * @return
     */
    List<WhReturnApplyItemExcelResponse> applyItemExcel(@Param("request") WhReturnApplyRequest request,
                                                                 @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * excel导出计数
     *
     * @param request
     * @param queryRequest
     * @return
     */
    Long applyItemCountExcel(@Param("request") WhReturnApplyRequest request,
                                                        @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * excel导出
     *
     * @param request
     * @param queryRequest
     * @return
     */
    List<WhReturnApplyExcelResponse> applyExcel(@Param("request") WhReturnApplyRequest request,
                                               @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * excel导出计数
     *
     * @param request
     * @param queryRequest
     * @return
     */
    Long applyCountExcel(@Param("request") WhReturnApplyRequest request,
                                                @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * excel导出
     *
     * @param request
     * @param queryRequest
     * @return
     */
    List<WhReturnItemExcelResponse> returnItemExcel(@Param("request") WhReturnRequest request,
                                       @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * excel导出计数
     *
     * @param request
     * @param queryRequest
     * @return
     */
    Long returnItemCountExcel(@Param("request") WhReturnRequest request,
                                                    @Param("queryRequest") OrgQueryConditionRequest queryRequest);

}
