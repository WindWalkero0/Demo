package com.ruihe.admin.request.promotional;

import lombok.Data;

import java.io.Serializable;

@Data
public class HistoryRequest implements Serializable {

    //开始时间
    String startTime;

    //结束时间
    String endTime;

    //消息码
    Integer messageCode;

    //活动uid
    String uid;

    Integer pageSize;

    Integer pageNumber;
}
