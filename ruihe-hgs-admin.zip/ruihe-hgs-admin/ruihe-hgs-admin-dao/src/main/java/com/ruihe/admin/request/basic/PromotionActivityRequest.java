package com.ruihe.admin.request.basic;

import com.baomidou.mybatisplus.annotation.TableId;
import com.ruihe.common.dao.bean.activity.ActivityPlace;
import com.ruihe.common.dao.bean.member.MemberSelect;
import com.ruihe.common.dao.bean.promotion.PromotionActivity;
import com.ruihe.common.dao.bean.promotion.PromotionProduct;
import com.ruihe.common.dao.bean.promotion.RewardCloud;
import com.ruihe.common.pojo.dto.PromotionActivityDTO;
import com.ruihe.common.pojo.request.promotion.SalesProductRequest;
import com.ruihe.common.pojo.response.promotion.ActivityProductResponse;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PromotionActivityRequest implements Serializable {

    @ApiModelProperty(value = "规则名称")
    public String name;

    @ApiModelProperty(value = "活动类型  2默认的促销")
    public Integer activityType;

    @ApiModelProperty(value = "所属品牌")
    public String brandName;

    @ApiModelProperty(value = "所属主活动名称")
    public String activityName;

    @ApiModelProperty(value = "所属子品牌")
    public String sonBrandName;

    @ApiModelProperty(value = "每单最大匹配次数")
    public Integer matchingCount;

    @ApiModelProperty(value = "校验方式")
    public Integer checkType;

    @ApiModelProperty(value = "活动描述")
    public String activityDesc;

    @ApiModelProperty(value = "活动地点类型")
    public Integer activityPlaceType;

    @ApiModelProperty(value = "活动对象类型")
    public Integer activityObjectType;

    @ApiModelProperty(value = "活动开始时间")
    public String startTime;

    @ApiModelProperty(value = "活动结束时间")
    public String stopTime;

    @ApiModelProperty(value = "购买条件类型")
    public Integer buyConditionType;

    @ApiModelProperty(value = "总金额/总数量 0总金额  1总数量")
    public Integer total;

    @ApiModelProperty(value = "总金额/总数量 所对应的值")
    public String inputValues;


    /**
     * 奖励内容
     * JIANGLI2(14, "赠送礼品"),
     * JIANGLI4(16, "加价购"),
     * JIANGLI5(17, "套装特价"),
     * JIANGLI6(18, "第N件折扣"),
     * JIANGLI7(19, "整单优惠"),//针对于整单条件  2020年01月11日17:34:57 新增
     * JIANGLI8(20,"整单改价")//2020-05-14 09:25:29新增
     * JIANGLI9(21, "整单买送")
     */
    @ApiModelProperty(value = "奖励内容类型")
    public Integer rewardType;

    /*
     * 整单改价
     */
    @ApiModelProperty(value = "整单改价最小值")
    public BigDecimal priceChangeMin;

    @ApiModelProperty(value = "整单改价最大值")
    public BigDecimal priceChangeMax;

    /**
     * 整单买送
     */
    @ApiModelProperty(value = "整单买送最大总价值不超过多少元")
    public BigDecimal moreMoney;

    /**
     * 整单优惠
     */
    @ApiModelProperty(value = "整单优惠抵扣的金额")
    public BigDecimal preferentialAmount;

    /**
     * 第N件折扣
     */
    @ApiModelProperty(value = "第多少件折扣")
    public Integer discountCount;

    @ApiModelProperty(value = "第N件折扣--打多少折")
    public BigDecimal discount;

    /**
     * 整单买送的条件
     */
    @ApiModelProperty(value = "礼品最大价值不超过多少元")
    public BigDecimal maxOverMoney;

    /**
     * 加价购
     */
    @ApiModelProperty(value = "加价购中追加钱数")
    public BigDecimal markupMoney;

    /**
     * 套装特价
     */
    @ApiModelProperty(value = "套装特价---不能大于购买的商品价格")
    public BigDecimal setPrice;

    @ApiModelProperty(value = "套装特价,允许套装价格大于组件价格总和 0不允许 1 允许--- 默认不允许")
    public Integer allow;

    @ApiModelProperty(value = "促销活动是否生效  0生效  1不生效 默认不生效")
    public Integer status;

    @ApiModelProperty(value = "促销活动的状态 0进行中  2已结束  1未开始")
    public Integer activityStatus;

    @ApiModelProperty(value = "是否是模板 0否  1是")
    public Integer templateType;

    @ApiModelProperty(value = "设置者的账号")
    public String account;

    @ApiModelProperty(value = "活动创建人")
    public String createAuthor;

    @ApiModelProperty(value = "活动唯一标识")
    @TableId
    public String uid;

    @ApiModelProperty(value = "活动创建时间")
    public String createTime;

    @ApiModelProperty(value = "是否删除 0有效 1无效")
    public Integer isDel;

    /**
     * 嘉文让加的
     */
    public String memberSelectString;

    public String memberSelectOrigin;

    @ApiModelProperty(value = "记录限定商品集合")
    List<PromotionProduct> promotionProducts;

    @ApiModelProperty(value = "记录排除商品集合")
    List<PromotionProduct> excludeList;

    @ApiModelProperty(value = "接收组合数据")
    List<RewardCloud> rewardCloudList;

    @ApiModelProperty(value = "接收会员选择条件")
    MemberSelect memberSelect;

    @ApiModelProperty(value = "接收活动地点")
    List<ActivityPlace> activityPlaceList;

    @ApiModelProperty(value = "复制或者编辑类型判断 1复制  2编辑")
    public Integer type;


    /**
     * 用户非整单条件--整单特价
     */
    @ApiModelProperty(value = "套装特价组合数据")
    List<ActivityProductResponse> activityProductResponses;

    @ApiModelProperty(value = "匹配次数")
    public Integer count;

    @ApiModelProperty(value = "会员优惠总金额")
    public BigDecimal memberTotalMoney;

    @ApiModelProperty(value = "零售优惠总金额")
    public BigDecimal normalTotalMoney;

    Integer sortCounter;

    //类型排序
    Integer sortType;

    //时间排序
    Integer sortTime;

    /**
     * 非整单条件
     */
    Map<String, ActivityProductResponse> map;

    /**
     * 第N件折扣活动商品map暂存集合
     */
    Map<String, SalesProductRequest> activitiesMap;

    /**
     * 第N件折扣活动商品集合
     */
    List<SalesProductRequest> discountActivities;

    /**
     * 第N件折优惠商品集合
     */
    List<SalesProductRequest> abatementList;

    /**
     * 加价购活动商品
     */
    List<SalesProductRequest> increaseActivities;

    /**
     * 赠送礼品活动商品
     */
    List<SalesProductRequest> bestowedActivities;

    /**
     * 判断是不是会员 是会员为true  不是会员为false
     */
    public Boolean isMember;


    /**
     * 柜台excel导入的标识
     */
    @ApiModelProperty("柜台excel导入的标识")
    public String counterExcelImportKey;

    @ApiModelProperty(value = "1我们自己的  2秉坤迁移的数据")
    public Integer customType;

    public static PromotionActivityDTO convert2DTO(PromotionActivity activity) {
        PromotionActivityDTO dto = new PromotionActivityDTO();
        BeanUtils.copyProperties(activity, dto);
        return dto;
    }

    /**
     * 是否能够被选择 0否 1是
     */

    public Integer checkJudge;
}

