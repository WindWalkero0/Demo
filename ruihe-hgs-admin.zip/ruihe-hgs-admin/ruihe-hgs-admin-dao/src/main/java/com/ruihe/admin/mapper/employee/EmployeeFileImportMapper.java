package com.ruihe.admin.mapper.employee;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.employee.EmployeeFileImport;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @Description
 * @author huangjei
 * @create 2021-06-23
 */
@Mapper
public interface EmployeeFileImportMapper extends BaseMapper<EmployeeFileImport> {


}
