package com.ruihe.admin.response.member;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/5 17:57
 */
@ApiModel(value = "MediumCatProportionResponse", description = "产品中分类占比图响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MediumCatProportionResponse implements Serializable {
    @ApiModelProperty(value = "中分类名称")
    private String mediumCatName;
    @ApiModelProperty(value = "每个中分类对应的数量")
    private Integer qty;
    @ApiModelProperty(value = "中分类编码")
    private Integer mediumCatCode;
}
