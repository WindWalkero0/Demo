package com.ruihe.admin.response.member;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @Anthor:Fangtao
 * @Date:2020/2/26 10:50
 */
@ApiModel(value = "MemberDiffTimeResponse", description = "会员一览excel导出响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberDiffTimeResponse implements Serializable {
    @ApiModelProperty("最近一次购买时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastTime;
    @ApiModelProperty("最近一次购买柜台号")
    private String counterId;
    @ApiModelProperty("最近一次购买柜台名称")
    private String counterName;
    @ApiModelProperty("首次购买时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime firstTime;
    @ApiModelProperty("首次购买柜台号")
    private String firstCounterId;
    @ApiModelProperty("首次购买柜台名称")
    private String firstCounterName;
    @ApiModelProperty("可兑换积分")
    private Integer avlQty;

}
