package com.ruihe.admin.response.member;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @Anthor:Fangtao
 * @Date:2020/3/25 16:18
 */
@ApiModel(value = "MemberTimeResponse", description = "会员一览excel导出响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberTimeResponse implements Serializable {
    @ApiModelProperty("等级调整日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;
}
