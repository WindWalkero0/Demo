package com.ruihe.admin.mapper.communicate;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.po.MsgRecordPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 查询发送记录
 *
 * @Anthor:Fangtao
 * @Date:2019/11/25 14:22
 */
@Mapper
public interface RecordMapper extends BaseMapper<MsgRecordPo> {

    /**
     * 查询发送记录
     */
    List<MsgRecordPo> queryRecord(@Param("contact") String contact,
                                  @Param("status") Integer status);

    /**
     * 计算页数
     */
    Long queryTotal(@Param("contact") String contact,
                    @Param("status") Integer status);

}
