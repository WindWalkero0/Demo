package com.ruihe.admin.request.bi;


import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;

@ApiModel(value = "ProductBizDetailsReportRequest", description = "BI报表产品业务明细报表分析请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductBizDetailReportRequest implements Serializable {
    @ApiModelProperty(value = "输出项")
    @NotNull(message = "输出项不能为空")
    private ProductBizDetailSelectRequest selectRequest;

    @NotNull(message = "开始时间不能为空")
    @ApiModelProperty(value = "开始时间")
    private LocalDate startTime;

    @NotNull(message = "结束时间不能为空")
    @ApiModelProperty(value = "结束时间")
    private LocalDate endTime;

    @ApiModelProperty(value = "渠道代码")
    private String channelCode;

    @ApiModelProperty("产品名称(中间一致)")
    @Size(max = 50,message = "产品名称最大长度为50个字符")
    private String prdName;

    @ApiModelProperty("产品条码-69码")
    @Size(max = 30,message = "产品条码最大长度为30个字符")
    private String goodsBarCode;

    @NotBlank(message = "标签不能为空")
    @ApiModelProperty("标签")
    @Size(max = 30,message = "标签最大长度为30个字符")
    private String tag;

    @ApiModelProperty("查询图片地址")
    private String picUrl;

    @ApiModelProperty("产品分类")
    @Builder.Default
    private CategoryOrgQueryRequest extractCondition = new CategoryOrgQueryRequest();

    @ApiModelProperty("组织模式查询条件")
    @Builder.Default
    private OrgQueryConditionRequest orgQueryConditionRequest = new OrgQueryConditionRequest();

    @ApiModel(value = "CategoryOrgQueryRequest", description = "产品分类查询实体")
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CategoryOrgQueryRequest implements Serializable {
        @ApiModelProperty("大类代码")
        private Integer bigCatCode;

        @ApiModelProperty("中类代码")
        private Integer mediumCatCode;

        @ApiModelProperty("小类代码")
        private Integer smallCatCode;

        @ApiModelProperty("厂商编码-唯一性")
        private String prdBarCode;
    }
}
