package com.ruihe.admin.request.promotional;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class ActivityPlaceRequest implements Serializable {

    @ApiModelProperty(value = "活动类型 0会员活动;1促销活动;2发券活动")
    public Integer activityType;

    @ApiModelProperty(value = "活动地点类型  促销活动---(21-按组织结构指定到柜台 32-按渠道指定柜台 33-)   会员活动---(全部类型都可以)")
    public Integer placeType;

    @ApiModelProperty(value = "会员活动-----县区code")
    private String regionCode;

    @ApiModelProperty(value = "会员活动-----县区名称")
    private String regionName;

    @ApiModelProperty(value = "会员活动-----大区code")
    private String areaCode;

    @ApiModelProperty(value = "会员活动-----大区名称")
    private String areaName;

    @ApiModelProperty(value = "促销活动;会员活动-----记录主管编号(看具体选择)")
    private String departmentId;

    @ApiModelProperty(value = "促销活动;会员活动-----记录主管名称(看具体选择)")
    private String departmentName;

    @ApiModelProperty(value = "促销活动;会员活动-----记录渠道编码(看具体选择)")
    private String channelCode;

    @ApiModelProperty(value = "促销活动;会员活动-----记录渠道名称(看具体选择)")
    private String channelName;

    @ApiModelProperty(value = "适用于会员和促销活动----记录的柜台的编号(看具体选择)")
    public String counterId;

    @ApiModelProperty(value = "适用于会员和促销活动-----柜台名称(看具体选择)")
    public String counterName;


}
