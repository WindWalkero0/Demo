package com.ruihe.admin.response.employee;

import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruihe.common.annotation.FieldName;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;



/**
 * @author:huangjie
 * @Date:2021年6月16日09:15:13
 */
@ApiModel(value = "EmployeeResponse", description = "员工信息excel导出")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class EmployeeResponse implements Serializable {
    /**
     * 用户ID
     */
    @TableId(value = "emp_id", type = IdType.NONE)
    private String empId;

    /**
     * 用户账号
     */
    @FieldName(name = "登录账号")
    private String account;

    /**
     * 用户账号状态
     */
    @FieldName(name = "账号状态", enumeration = "0:无效|1:有效")
    private Integer accountStatus;

    /**
     * 所属品牌
     */
    @FieldName(name = "所属品牌")
    private String brandName;

    /**
     * 姓名
     */
    @FieldName(name = "姓名")
    private String name;

    /**
     * 岗位代码
     */
    private String positionCode;

    /**
     * 岗位名称
     */
    @FieldName(name = "岗位")
    private String positionName;

    /**
     * 联系电话
     */
    @TableField(whereStrategy = FieldStrategy.IGNORED, insertStrategy = FieldStrategy.IGNORED, updateStrategy = FieldStrategy.IGNORED)
    private String telephone;

    /**
     * 部门代码
     */
    private String deptCode;

    /**
     * 部门名称
     */
    @FieldName(name = "部门")
    private String deptName;

    /**
     * 部门类型
     */
    @FieldName(name = "部门类型", enumeration = "0:集团总部|1:品牌总部|2:大区|3:办事处|4:柜台主管|5:柜台")
    private Integer deptType;

    /**
     * 手机号码
     */
    @FieldName(name = "手机")
    private String phoneNo;

    /**
     * email
     */
    @TableField(whereStrategy = FieldStrategy.IGNORED, insertStrategy = FieldStrategy.IGNORED, updateStrategy = FieldStrategy.IGNORED)
    @FieldName(name = "邮箱")
    private String email;

    /**
     * 身份证
     */
    @FieldName(name = "身份证")
    private String idCard;

    /**
     * 状态,柜员状态：0无效，1有效
     */
    @FieldName(name = "状态", enumeration = "0:无效|1:有效")
    private Integer status;

    /**
     * 最近一次入职日期
     */
    @TableField(whereStrategy = FieldStrategy.IGNORED, insertStrategy = FieldStrategy.IGNORED, updateStrategy = FieldStrategy.IGNORED)
    @FieldName(name = "最近一次入职日期")
    private LocalDate recentEntryTime;

    /**
     * 最近一次离职日期
     */
    @TableField(whereStrategy = FieldStrategy.IGNORED, insertStrategy = FieldStrategy.IGNORED, updateStrategy = FieldStrategy.IGNORED)
    @FieldName(name = "最近一次离职日期")
    private LocalDate recentLeaveTime;

    /**
     * 建立日期
     */
    @FieldName(name = "建档时间")
    private LocalDateTime createTime;

    /**
     * 更新日期
     */
    private LocalDateTime updateTime;

    /**
     * 管辖部门
     */
    @FieldName(name = "管辖部门")
    private String departmentList;

    /**
     * 关注部门
     */
    @FieldName(name = "关注部门")
    private String userConcernVoList;


}
