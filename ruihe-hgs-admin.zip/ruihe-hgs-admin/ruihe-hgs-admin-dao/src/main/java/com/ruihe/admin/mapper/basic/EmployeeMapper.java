package com.ruihe.admin.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.po.EmployeeImportPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


/**
 * @author huangjie
 * @Description
 * @create 2021-06-17 17:14
 */
@Mapper
public interface EmployeeMapper extends BaseMapper<EmployeeImportPo> {

    int batchInsert(@Param("list") List<EmployeeImportPo> list);


}
