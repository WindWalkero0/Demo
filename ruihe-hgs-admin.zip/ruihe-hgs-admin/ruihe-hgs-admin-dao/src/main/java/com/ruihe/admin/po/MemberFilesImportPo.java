package com.ruihe.admin.po;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author:Fangtao
 * @Date:2019/11/8 16:29
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberFilesImportPo implements Serializable {
    /**
     * 会员档案导入流水号
     */
    private String importSerialNo;
    /**
     * 导入名称
     */
    private String importName;
    /**
     * 导入模式(0,新增模式 1,更新模式)
     */
    private Integer importMode;
    /**
     * 导入原因
     */
    private String importReason;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
}
