package com.ruihe.admin.response.bi;


import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class Report001Data implements Serializable {
    private String memberId;
    private String orderNo;
    private LocalDateTime bizTime;
    private String prdBarCode;
    private String prdName;
    private String operationalModel;//运营模式   自营 10005/代理商10006
    private BigDecimal amount;
    private Integer purQty;
}
