package com.ruihe.admin.mapper.promotional;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.request.promotional.HistoryRequest;
import com.ruihe.admin.request.promotional.PromotionalSelectRequest;
import com.ruihe.admin.response.promotional.PromotionalResponse;
import com.ruihe.common.dao.bean.promotion.PromotionActivity;
import com.ruihe.common.dao.bean.promotion.PromotionTakeEffectLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PromotionalMapper extends BaseMapper<PromotionActivity> {

    List<PromotionalResponse> selectMation(@Param("request") PromotionalSelectRequest request);

    List<PromotionTakeEffectLog> selectHistory(@Param("request") HistoryRequest request);


    /**
     * 促销活动名称查询
     */
    List<PromotionActivity> queryPromotionActivity(@Param("name") String name, @Param("isDel") Integer isDel);


    /**
     * 促销活动名称查询
     */
    PromotionActivity activityName(@Param("name") String name);

    /**
     * 计算页数
     */
    Long queryCount(@Param("name") String name, @Param("isDel") Integer isDel);
}
