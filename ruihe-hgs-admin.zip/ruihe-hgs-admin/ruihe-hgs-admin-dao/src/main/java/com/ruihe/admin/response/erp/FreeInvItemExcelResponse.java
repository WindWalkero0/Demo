package com.ruihe.admin.response.erp;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-22 11:03
 */
@ApiModel(value = "FreeInvItemExcelResponse", description = "自由盘点子表excel导出")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class FreeInvItemExcelResponse implements Serializable {

    @ExcelProperty(value = "大区", index = 0)
    private String orgAreaName;

    @ExcelProperty(value = "区域", index = 1)
    private String largeAreaName;

    @ExcelProperty(value = "城市", index = 2)
    private String cityName;

    @ExcelProperty(value = "盘点单号", index = 3)
    private String invNo;

    @ExcelProperty(value = "盘点部门代码", index = 4)
    private String counterId;

    @ExcelProperty(value = "盘点部门名称", index = 5)
    private String counterName;

    @ExcelProperty(value = "操作人员代码", index = 6)
    private String baCode;

    @ExcelProperty(value = "操作人员名称", index = 7)
    private String baName;

    @ExcelProperty(value = "厂商编码", index = 8)
    private String prdBarCode;

    @ExcelProperty(value = "产品条码", index = 9)
    private String goodsBarCode;

    @ExcelProperty(value = "产品名称", index = 10)
    private String prdName;

    @ExcelProperty(value = "账面数量", index = 11)
    private Integer bookQty;

    @ExcelProperty(value = "实盘数量", index = 12)
    private Integer realQty;

    @ExcelProperty(value = "盘差数量", index = 13)
    private Integer diffQty;

    @ExcelProperty(value = "产品价格", index = 14)
    private BigDecimal memberPrice;

    @ExcelProperty(value = "盘差金额", index = 15)
    private BigDecimal diffAmt;

    @ExcelProperty(value = "盈亏情况", index = 16)
    private String profitLoss;

    @ExcelProperty(value = "盘点类型", index = 17)
    private String invType;

    @ExcelProperty(value = "盘点时间", index = 18)
    private String createTime;

    @ExcelProperty(value = "盘点原因", index = 19)
    private String invRsn;
}
