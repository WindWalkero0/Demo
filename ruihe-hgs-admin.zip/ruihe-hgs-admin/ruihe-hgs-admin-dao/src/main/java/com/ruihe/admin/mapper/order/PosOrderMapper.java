package com.ruihe.admin.mapper.order;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.common.dao.bean.base.Department;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.request.erp.PaymentReportRequest;
import com.ruihe.admin.response.erp.PaymentExcelResponse;
import com.ruihe.admin.response.erp.PaymentReportResponse;
import com.ruihe.admin.response.member.MemberAnalysisResponse;
import com.ruihe.admin.response.member.MemberDiffTimeResponse;
import com.ruihe.admin.response.member.MemberTimeResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/27 16:07
 */
@Mapper
public interface PosOrderMapper extends BaseMapper<PosOrderPo> {
    /**
     * 会员导出->最近购买的时间,柜台
     */
    MemberDiffTimeResponse queryLatelyTime(@Param("memberId") String memberId);

    /**
     * 会员导出->首次购买时间
     */
    MemberDiffTimeResponse queryFirstTime(@Param("memberId") String memberId);

    /**
     * 计算三个月,六个月,十二个月内的购买次数,购买金额,购买数量
     */
    MemberAnalysisResponse queryDate(@Param("memberId") String memberId,
                                     @Param("startDate") LocalDate startDate,
                                     @Param("endDate") LocalDateTime endDate);

    /**
     * 查询支付方式报表
     *
     * @param page
     * @param request
     * @param queryRequest
     * @return
     */
    IPage<PaymentReportResponse> list(@Param("page") Page<PaymentReportResponse> page,
                                      @Param("request") PaymentReportRequest request,
                                      @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    MemberDiffTimeResponse queryAvlQty(@Param("memberId") String memberId);

    MemberTimeResponse queryTime(@Param("memberId") String memberId);

    List<PosOrderItemPo> queryWithNoReturnByOldMember(@Param("startTime") LocalDate start,
                                                      @Param("endTime") LocalDate end);

    List<PosOrderItemPo> queryWithNoReturn(@Param("startTime") LocalDate start,
                                             @Param("endTime") LocalDate end);
    /**
     * 修改订单的柜台信息
     *
     * @param dept
     * @param topDeptId
     * @param topDeptName
     * @return
     */
    int updateDepartment(@Param("dept") Department dept,
                         @Param("topDeptId") String topDeptId,
                         @Param("topDeptName") String topDeptName);

    /**
     * 支付方式报表导出查询总数
     *
     * @param request
     * @param queryRequest
     * @return
     */
    Long queryListCount(@Param("request") PaymentReportRequest request,
                        @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 支付方式报表导出查询
     *
     * @param request
     * @param queryRequest
     * @return
     */
    List<PaymentExcelResponse> queryListExcel(@Param("request") PaymentReportRequest request,
                                              @Param("queryRequest") OrgQueryConditionRequest queryRequest);
}
