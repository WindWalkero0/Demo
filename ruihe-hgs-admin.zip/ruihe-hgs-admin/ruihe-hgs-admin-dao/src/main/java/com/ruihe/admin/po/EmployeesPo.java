package com.ruihe.admin.po;


import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_employee")
public class EmployeesPo implements Serializable {
    /**
     * emp_id员工id
     */
    private String empId;

    /**
     * 所属品牌
     */
    private String brandName;

    /**
     * 姓名
     */
    private String name;

    /**
     * 岗位代码
     */
    private String positionCode;

    /**
     * 岗位名称
     */
    private String positionName;

    /**
     * 手机号码
     */
    private String phoneNo;

    /**
     * 身份证号
     */
    private String idCard;

    /**
     * 部门代码
     */
    private String deptCode;

    /**
     * 部门名称
     */
    private String deptName;

    /**
     * 部门类型
     */
    private Integer deptType;

    /**
     * 柜员状态：0无效，1有效
     */
    private Integer status;

    /**
     * 入职日期
     */
    private LocalDate recentEntryTime;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;


    //运营模式   自营/代理商
    private String operationalModel;

    /**
     * 门店编号
     */
    private String counterId;
}
