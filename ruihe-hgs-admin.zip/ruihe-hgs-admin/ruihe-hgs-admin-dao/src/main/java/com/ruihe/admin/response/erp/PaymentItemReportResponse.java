package com.ruihe.admin.response.erp;

import com.ruihe.common.pojo.response.order.MemberPayChannelResponse;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2020-02-27 10:07
 */
@ApiModel(value = "PaymentItemReportResponse", description = "支付方式报表详情返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PaymentItemReportResponse implements Serializable {

    @ApiModelProperty(value = "支付方式")
    private List<MemberPayChannelResponse> memberPayChannelResponses;

    @ApiModelProperty(value = "订单列表")
    private List<PosOrderItemResponse> itemVoList;
}
