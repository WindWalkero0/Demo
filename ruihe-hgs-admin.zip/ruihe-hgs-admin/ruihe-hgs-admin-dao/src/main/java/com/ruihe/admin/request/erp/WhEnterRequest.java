package com.ruihe.admin.request.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @Anthor:Fangtao
 * @Date:2020/3/10 10:45
 */
@ApiModel(description = "进销存-发货单处理多条件查询接收类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhEnterRequest implements Serializable {
    @ApiModelProperty("发货单号")
    private String deliveryNo;

    @ApiModelProperty("状态(1,待确认;2,已确认)")
    private Integer status;

    @ApiModelProperty("开始时间")
    //@JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate startTime;

    @ApiModelProperty("结束时间")
    //@JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate endTime;

    @ApiModelProperty("审核状态 0编辑中，1未审核，2已通过，3已拒绝，4已废弃")
    private Integer auditStatus;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;

    @ApiModelProperty(value = "组织模式查询条件")
    private OrgQueryConditionRequest orgQueryConditionRequest;

}
