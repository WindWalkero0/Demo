package com.ruihe.admin.mapper.erp.report;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.response.erp.*;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.pojo.response.order.SaleLadingOrderExcelResponse;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.request.erp.PosLadingSaleRequest;
import com.ruihe.admin.request.erp.PrdSalesRecordRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Anthor:Fangtao
 * @Date:2019/11/28 11:34
 */
@Mapper
public interface PrdSalesRecordMapper extends BaseMapper<PosOrderPo> {

    /**
     * 产品销售记录多条件查询
     *
     * @param request
     * @param queryRequest
     * @return
     */
    List<PrdSalesAndRecordResponse> querySalesRecord(@Param("request") PrdSalesRecordRequest request,
                                                     @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 计算数据总条数
     */
    Long querySalesRecordCount(@Param("request") PrdSalesRecordRequest request,
                               @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 统计销售数量,销售金额,会员数,订单数
     */
    PrdSalesRecordResultResponse queryResult(@Param("request") PrdSalesRecordRequest request,
                                             @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 根据柜台修改组织结构
     */
    int updateOrderOrg(@Param("counterInformation") CounterInformation counterInformation);

    /**
     * 根据柜台修改模式结构
     */
    int updateOrderOpt(@Param("counterInformation") CounterInformation counterInformation);


    /**
     * 预订单多条记录查询
     */
    List<PosLaingSaleResponse> queryLading(PosLadingSaleRequest request, OrgQueryConditionRequest queryRequest);


    Long queryLadingCount(@Param("request") PosLadingSaleRequest request,
                               @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 预订单Excel导出
     */
    List<SaleLadingOrderExcelResponse> queryLadingExcel(PosLadingSaleRequest request, OrgQueryConditionRequest queryRequest);


    /**
     * 统计销售数量,销售金额,会员数,订单数
     */
    PosLaingResultResponse queryLadingResult(@Param("request") PosLadingSaleRequest request,
                                       @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    PosLaingResultResponse queryReturnLadingResult(@Param("request") PosLadingSaleRequest request,
                                             @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    List<SaleOrderExcelResponse> saleExcelResponseList(@Param("request") PrdSalesRecordRequest request,
                                                       @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    List<PosLaingitemExtractListResponse> selectLadingItemList(@Param("orderNo") String orderNo);
}
