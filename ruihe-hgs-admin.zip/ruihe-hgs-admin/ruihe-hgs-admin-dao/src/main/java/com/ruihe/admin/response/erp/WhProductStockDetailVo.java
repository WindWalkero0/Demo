package com.ruihe.admin.response.erp;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@ApiModel(description = "产品库存明细包括在途库存")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhProductStockDetailVo implements Serializable {
    @ExcelProperty(value = "柜台编号", index = 0)
    @ColumnWidth(15)
    @ApiModelProperty(value = "柜台编号")
    private String counterId;

    @ExcelProperty(value = "柜台名称", index = 1)
    @ColumnWidth(30)
    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ExcelProperty(value = "柜台启停用状态", index = 2)
    @ColumnWidth(30)
    @ApiModelProperty(value = "柜台启停用状态")
    private String counterStatus;

    @ExcelProperty(value = "运营模式", index = 3)
    @ColumnWidth(15)
    @ApiModelProperty(value = "运营模式")
    private String counterOpt;

    @ExcelProperty(value = "实时库存", index = 4)
    @ColumnWidth(15)
    @ApiModelProperty(value = "实时库存")
    private Integer stock;

    @ExcelProperty(value = "在途库存", index = 5)
    @ColumnWidth(15)
    @ApiModelProperty(value = "在途库存")
    private Integer stockOnRoad;
}
