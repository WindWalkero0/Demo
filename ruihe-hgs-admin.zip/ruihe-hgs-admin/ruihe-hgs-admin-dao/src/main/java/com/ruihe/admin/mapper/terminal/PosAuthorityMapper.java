package com.ruihe.admin.mapper.terminal;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.order.PosAuthorityPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 梁远
 * @Description
 * @create 2019-12-10 9:59
 */
@Mapper
public interface PosAuthorityMapper extends BaseMapper<PosAuthorityPo> {
}
