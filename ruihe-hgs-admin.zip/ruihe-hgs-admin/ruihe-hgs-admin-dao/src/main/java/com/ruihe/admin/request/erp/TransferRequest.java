package com.ruihe.admin.request.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @Anthor:Fangtao
 * @Date:2019/11/22 16:24
 */
@ApiModel(description = "调拨单处理多条件查询接收类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferRequest implements Serializable {

    @ApiModelProperty("品牌名称")
    private String brandName;

    @ApiModelProperty("柜台名称")
    private String counterName;

    @ApiModelProperty("申请单号")
    private String transferOrderNo;

    @ApiModelProperty("产品名称")
    private String prdName;

    @ApiModelProperty("开始时间")
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate startTime;

    @ApiModelProperty("结束时间")
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate endTime;

    @ApiModelProperty("处理状态 1编辑,2待调出,3已完成,4拒绝")
    private Integer status;

    @ApiModelProperty("审核状态 0编辑中，1未审核，2已通过，3已拒绝，4已废弃")
    private Integer auditStatus;

    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    private Integer pageNumber;

    @ApiModelProperty(value = "组织模式查询条件")
    private OrgQueryConditionRequest orgQueryConditionRequest;
}
