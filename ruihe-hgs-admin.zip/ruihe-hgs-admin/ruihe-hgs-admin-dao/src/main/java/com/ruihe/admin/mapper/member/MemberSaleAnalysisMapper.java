package com.ruihe.admin.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.admin.response.member.MemberSaleOrderInfoResponse;
import com.ruihe.admin.response.member.MemberSaleOrderResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员销售分析
 * 会员详情页首页
 *
 * @Date:2019/12/5 11:45
 */
@Mapper
public interface MemberSaleAnalysisMapper extends BaseMapper<PosOrderPo> {


    /**
     * 计算会员首页详情销售的总数量和购买的总金额
     */
    List<MemberSaleOrderResponse> sumTotal(@Param("memberId") String memberId);

    /**
     * 查询会员首页详情购买记录详情
     */
    List<MemberSaleOrderInfoResponse> purchaseDetails(@Param("memberId") String memberId);

}
