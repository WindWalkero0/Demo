package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-22 9:54
 */
@ApiModel(value = "WhFreeInventoryApplyResponse", description = "自由盘点申请返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class WhFreeInventoryApplyResponse implements Serializable {

    @ApiModelProperty(value = "申请单号")
    private String applyNo;

    @ApiModelProperty(value = "盘点单号")
    private String invNo;

    @ApiModelProperty(value = "柜台ID")
    private String counterId;

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "门店类型:自营10005/加盟10006")
    private String operationalModel;

    @ApiModelProperty(value = "盘点原因:0财务盘点，1正常盘点，2月末盘点，3抽盘，4修改库存，5区域经理盘点")
    private Integer invRsn;

    @ApiModelProperty(value = "审核状态：0编辑中，1未审核，2已通过，3已拒绝，4已废弃")
    private Integer status;

    @ApiModelProperty(value = "实盘数")
    private Integer realQty;

    @ApiModelProperty(value = "盘差数")
    private Integer diffQty;

    @ApiModelProperty(value = "盘差金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal diffAmt;

    @ApiModelProperty(value = "柜员id")
    private String baCode;

    @ApiModelProperty(value = "柜员名称")
    private String baName;

    @ApiModelProperty(value = "审核人id")
    private String auditCode;

    @ApiModelProperty(value = "审核人名称")
    private String auditName;

    @ApiModelProperty(value = "盘点时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

}
