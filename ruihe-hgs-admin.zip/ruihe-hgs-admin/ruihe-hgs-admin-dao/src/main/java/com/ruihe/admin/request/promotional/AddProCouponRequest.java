package com.ruihe.admin.request.promotional;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruihe.common.annotation.Update;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ApiModel("新建发券活动接收类")
public class AddProCouponRequest implements Serializable {

    @NotBlank(message = "活动Id不能为空",groups = {Update.class})
    private String id;

    //活动名称
    @NotBlank(message = "活动名称不能为空")
    @Size(max=50,message = "活动名称最大长度为50个字符")
    private String couponName;

    //活动开始日期
    @NotNull(message = "活动开始时间不能为空")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startTime;

    //活动结束日期
    @NotNull(message = "活动结束时间不能为空")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime stopTime;

    //检验方式  0无校验  1coupon校验
    @NotNull(message = "校验方式不能为空")
    private Integer checkType;

    //优惠券有效类型  0指定时间  1相对时间
    @NotNull(message = "优惠券有效类型不能为空")
    private Integer useType;

    //相对时间--第多少天开始
    private Long startDay;

    //相对时间--多少天内有效
    private Long effectiveDay;

    //优惠券有效期开始时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime couponStartTime;

    //优惠券有效期结束时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime couponStopTime;

    //优惠券发放方式  0事件触发 1其他
    @NotNull(message = "优惠券发放方式不能为空")
    private Integer sendMethod;

    //优惠券发放类型  0购买 1其他
    @NotNull(message = "优惠券发放类型不能为空")
    private Integer sendType;

    //最大匹配次数数量
    @NotNull(message = "最大匹配次数不能为空")
    public Integer couponCount;

    //活动描述
    @Size(max = 500,message = "活动描述最大长度为500个字符")
    private String couponDescribe;

    //活动地点类
    @NotNull(message = "活动地点类型不能为空")
    private Integer activityPlaceType;

    //对象类型
    @NotNull(message = "活动对象信息不能为空")
    private Integer activityObjectType;

    //购买条件类型
    @NotNull(message = "购买条件类型不能为空")
    private Integer buyConditionType;

    //已参加优惠的订单不在发券?  0否  1是
    @NotNull(message = "已参加优惠的订单能否参加不能为空")
    private Integer checkDiscount;

    //奖励方式 0礼品抵用券  1金额抵用券
    @NotNull(message = "购买条件类型不能为空")
    private Integer rewardType;

    //抵扣金额
    @NotNull(message = "抵扣金额不能为空")
    private BigDecimal deductionMoney;

    //本次领用需要购买的金额
    @NotNull(message = "领用金额不能为空")
    private BigDecimal needMoney;

    /**
     * 产品使用范围 0无限制  1限定产品
     */
    @NotNull(message = "产品使用范围不能为空")
    private Integer proRange;


    /**
     * 活动地点集合
     */
    private List<ActivityPlaceRequest> activityPlaceList;

    /**
     * 购买条件限定商品集合
     */
    @NotNull(message = "购买条件不能为空")
    private List<RewardCloudRequest> rewardCloudList;

    /**
     * 使用时限定商品集合
     */
    private List<PromotionProductRequest> promotionProductRequests;

    /**
     * 嘉文让加的
     */
    public String memberSelectString;

    public String memberSelectOrigin;

    /**
     *  柜台导入excel key
     */
    private String counterExcelImportKey;

    /**
     *  复制活动id
     */
    private String copyUid;


}
