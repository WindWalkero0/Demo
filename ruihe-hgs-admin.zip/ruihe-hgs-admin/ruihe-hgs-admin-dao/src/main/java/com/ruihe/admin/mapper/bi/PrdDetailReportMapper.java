package com.ruihe.admin.mapper.bi;


import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.common.constant.DBConst;
import com.ruihe.admin.request.bi.ProductBizDetailReportRequest;
import com.ruihe.admin.response.bi.PrdDetailERPResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * fangtao
 */
@Mapper
@DS(DBConst.SLAVE)
public interface PrdDetailReportMapper {

    /**
     * 产品业务明细报表查询
     *
     * @param page
     * @param request
     * @return
     */
    List<PrdDetailERPResponse> prdBizDetailReport(@Param("page") Page page,
                                                  @Param("request") ProductBizDetailReportRequest request,
                                                  @Param("scols") String scols,
                                                  @Param("gcols") String gcols,
                                                  @Param("empId") String empId,
                                                  @Param("flag") boolean flag);

    List<PrdDetailERPResponse> prdBizDetailHead(@Param("request") ProductBizDetailReportRequest request,
                                                @Param("scols") String scols,
                                                @Param("gcols") String gcols);
}
