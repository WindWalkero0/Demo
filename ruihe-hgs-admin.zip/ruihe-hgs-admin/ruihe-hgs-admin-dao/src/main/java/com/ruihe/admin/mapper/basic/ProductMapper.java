package com.ruihe.admin.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.base.ProductCategory;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @author 梁远
 * @Description
 * @create 2019-06-17 16:00
 */
@Mapper
public interface ProductMapper extends BaseMapper<Product> {
    int updateCategoryName(@Param("category") ProductCategory category);
}
