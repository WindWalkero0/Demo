package com.ruihe.admin.request.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author Fangtao
 * @date 2019/11/26 16:01
 */
@ApiModel(description = "产品记录多条件查询接收类")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PrdSalesRecordRequest extends PageForm implements Serializable {

    @ApiModelProperty("销售单号")
    private String orderNo;

    @ApiModelProperty("交易类型(1销售,2退货)")
    private Integer transType;

    @ApiModelProperty("订单类型，1正常销售,2预定单")
    private Integer orderType;

    @ApiModelProperty("活动类型  0 积分兑换 1优惠券活动  2促销活动 3无活动 4发券")
    private Integer activityType;

    @ApiModelProperty("会员主题活动id")
    private String subActivityId;

    @ApiModelProperty("小票号")
    private String receiptNo;

    @ApiModelProperty("会员卡号")
    private String memberPhone;

    @ApiModelProperty(value = "BA编码")
    private String baCode;

    @ApiModelProperty(value = "ba名称")
    private String baName;

    @ApiModelProperty(value = "促销活动id")
    private String promotionId;

    @ApiModelProperty(value = "开始时间")
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate startTime;

    @ApiModelProperty(value = "结束时间")
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate endTime;

    @ApiModelProperty(value = "组织模式查询条件")
    private OrgQueryConditionRequest orgQueryConditionRequest;
}
