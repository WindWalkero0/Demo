package com.ruihe.admin.request.promotional;


import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RewardCloudRequest {

    public String rewardUid;

    @ApiModelProperty(value = "购买/奖励类型的组合要区别开来  0购买  1奖励")
    private Integer cloudMethod;

    @ApiModelProperty(value = "固定组合还是选择组合 0 固定  1选择")
    private Integer cloudType;

    @ApiModelProperty(value = "相同组合类型的排序规则  以最终提交结果为准1,2,3,4,5,,,顺序排下去")
    private Integer count;

    @ApiModelProperty(value = " 条件类型  7:产品范围 8:指定产品 12 产品小类")
    private Integer conditionType;

    @ApiModelProperty(value = " 产品范围类型(常用) 7:产品范围 8:指定产品 12 产品小类")
    private Integer proRange;

    //目前非整单的只限定了数量 default=1
    @ApiModelProperty(value = "0 金额 1数量 2金额范围")
    private Integer type;

    //目前非整单的只限定了 (购买条件 default 1)(奖励条件 default=2)
    @ApiModelProperty(value = "大于/大于等于  0大于  1大于等于 2 等于")
    private Integer compareType;

    //目前非整单的只限定了数量的值
    @ApiModelProperty(value = "组合产品的数量/金额")
    private String inputValues;

    @ApiModelProperty(value = "特定产品 id")
    private String specificProductId;

    @ApiModelProperty(value = "特定产品 名称")
    private String specificProductName;


}
