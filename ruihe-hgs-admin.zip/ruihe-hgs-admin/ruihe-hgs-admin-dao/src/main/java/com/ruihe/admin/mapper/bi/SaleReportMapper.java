package com.ruihe.admin.mapper.bi;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.admin.request.bi.SalesPerfReportRequest;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.response.bi.BaSalesTimeReportPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Anthor:Fangtao
 * @Date:2020/2/5 11:15
 */
@Mapper
public interface SaleReportMapper {

    /**
     * 动态查询sql-基础数据【销售总金额，
     * 销售总支数，
     * 销售总单数，
     * 客单价，
     * 连带率】
     *
     * @param page
     * @param request
     * @param org
     * @param scols
     * @param gcols
     * @param empId
     * @param flag
     * @return
     */
    List<BaSalesTimeReportPo> dynamicQuery(
            @Param("page") Page page,
            @Param("request") SalesPerfReportRequest request,
            @Param("org") OrgQueryConditionRequest org,
            @Param("scols") String scols,
            @Param("gcols") String gcols,
            @Param("empId") String empId,
            @Param("flag") boolean flag);

    /**
     * 动态查询-经营新会员人数
     *
     * @param request
     * @param org
     * @param scols
     * @param gcols
     * @param empId
     * @param flag
     * @return
     */
    List<BaSalesTimeReportPo> dynamicQueryOptNewMem(
            @Param("request") SalesPerfReportRequest request,
            @Param("org") OrgQueryConditionRequest org,
            @Param("scols") String scols,
            @Param("gcols") String gcols,
            @Param("empId") String empId,
            @Param("flag") boolean flag);

    /**
     * 动态分组-销售天数
     *
     * @param request
     * @param org
     * @param inScols
     * @param inGcols
     * @param outScols
     * @param outGcols
     * @param empId
     * @param flag
     * @return
     */
    List<BaSalesTimeReportPo> dynamicQuerySalesDays(
            @Param("request") SalesPerfReportRequest request,
            @Param("org") OrgQueryConditionRequest org,
            @Param("inScols") String inScols,
            @Param("inGcols") String inGcols,
            @Param("outScols") String outScols,
            @Param("outGcols") String outGcols,
            @Param("empId") String empId,
            @Param("flag") boolean flag);
}
