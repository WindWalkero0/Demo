package com.ruihe.admin.response.member;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 会员详情页首页->积分记录
 *
 * @Anthor:Fangtao
 * @Date:2019/12/5 20:24
 */
@ApiModel(value = "IntegralRecordResponse", description = "积分记录响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IntegralRecordResponse implements Serializable {
    @ApiModelProperty(value = "柜台名称")
    private String counterName;
    @ApiModelProperty(value = "业务类型(10正常销售,20销售退货,30积分兑换,40积分兑换退货,50积分维护,60积分清零)")
    private String bizType;
    @ApiModelProperty(value = "发生时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime bizTime;
    @ApiModelProperty(value = "金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal bizAmt;
    @ApiModelProperty(value = "业务对应的积分值")
    private Integer integralQty;
    @ApiModelProperty(value = "数量")
    private Integer bizQty;
}
