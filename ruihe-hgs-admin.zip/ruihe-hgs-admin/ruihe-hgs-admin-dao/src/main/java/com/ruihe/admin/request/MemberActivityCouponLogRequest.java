package com.ruihe.admin.request;

import com.ruihe.common.annotation.FieldName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "会员详情-参加活动履历")
public class MemberActivityCouponLogRequest {

    @ApiModelProperty(value = "会员id--必传")
    @FieldName(name = "会员id")
    public String memberId;

    @ApiModelProperty(value = "分页大小--必传")
    @FieldName(name = "分页大小")
    public Integer pageSize;

    @ApiModelProperty(value = "当前分页--必传")
    @FieldName(name = "当前分页")
    public Integer pageNumber;

    @ApiModelProperty(value = "活动名称")
    public String activityName;

    @ApiModelProperty(value = "开始时间")
    public String startTime;

    @ApiModelProperty(value = "结束时间")
    public String stopTime;

    @ApiModelProperty(value = "单据号")
    public String id;

    @ApiModelProperty(value = "单据状态")
    public Integer status;

    @ApiModelProperty(value = "柜台编码")
    public String counterId;

}
