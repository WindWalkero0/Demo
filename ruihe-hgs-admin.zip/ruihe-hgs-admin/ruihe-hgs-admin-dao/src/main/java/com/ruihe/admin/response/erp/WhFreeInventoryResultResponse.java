package com.ruihe.admin.response.erp;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-22 9:54
 */
@ApiModel(value = "WhFreeInventoryResultResponse", description = "自由盘点结果返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class WhFreeInventoryResultResponse implements Serializable {

    @ApiModelProperty(value = "实盘总数")
    private Integer realQty;

    @ApiModelProperty(value = "盘差总数")
    private Integer diffQty;

    @ApiModelProperty(value = "盘差总金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal diffAmt;
}
