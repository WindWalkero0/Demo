package com.ruihe.admin.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.member.MemberLevelRulePo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-11 14:46
 */
@Mapper
public interface MemberLevelRuleMapper extends BaseMapper<MemberLevelRulePo> {
}
