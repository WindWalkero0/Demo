package com.ruihe.admin.mapper.order;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.order.PosPaymentOrderPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 支付订单表 Mapper 接口
 * </p>
 *
 * @author William
 * @since 2019-10-19
 */
@Mapper
public interface PosPaymentOrderMapper extends BaseMapper<PosPaymentOrderPo> {
}
