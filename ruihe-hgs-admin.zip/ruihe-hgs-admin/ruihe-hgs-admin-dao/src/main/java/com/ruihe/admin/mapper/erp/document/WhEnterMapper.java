package com.ruihe.admin.mapper.erp.document;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.common.dao.bean.warehouse.WhEnterPo;
import com.ruihe.common.pojo.response.stock.DispatchExcelResponse;
import com.ruihe.common.pojo.response.stock.DispatchItemExcelResponse;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.request.erp.WhEnterRequest;
import com.ruihe.admin.response.erp.WhEnterQueryResponse;
import com.ruihe.admin.response.erp.WhEnterResultResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Anthor:Fangtao
 * @Date:2020/3/10 11:07
 */
@Mapper
public interface WhEnterMapper extends BaseMapper<WhEnterPo> {

    /**
     * 多条件查询发货单
     *
     * @param page
     * @param request
     * @param queryRequest
     * @return
     */
    IPage<WhEnterQueryResponse> queryEnterNo(@Param("page") Page<WhEnterQueryResponse> page,
                                             @Param("request") WhEnterRequest request,
                                             @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    WhEnterResultResponse queryResult(@Param("request") WhEnterRequest request, @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    Long queryEnterCount(@Param("request") WhEnterRequest whEnterRequest, @Param("queryRequest") OrgQueryConditionRequest orgQueryConditionRequest);

    List<DispatchExcelResponse> queryEnterExcel(@Param("request") WhEnterRequest whEnterRequest, @Param("queryRequest") OrgQueryConditionRequest orgQueryConditionRequest);

    List<DispatchItemExcelResponse> queryEnterItemExcel(@Param("request") WhEnterRequest whEnterRequest, @Param("queryRequest") OrgQueryConditionRequest orgQueryConditionRequest);

    Long queryEnterItemCount(@Param("request") WhEnterRequest whEnterRequest, @Param("queryRequest") OrgQueryConditionRequest orgQueryConditionRequest);

}
