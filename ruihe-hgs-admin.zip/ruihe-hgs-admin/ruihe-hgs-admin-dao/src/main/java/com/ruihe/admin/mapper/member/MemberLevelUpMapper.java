package com.ruihe.admin.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.member.MemberLevelUpPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-14 11:05
 */
@Mapper
public interface MemberLevelUpMapper extends BaseMapper<MemberLevelUpPo> {
    Integer batchInsert(@Param("list") List<MemberLevelUpPo> list);
}
