package com.ruihe.admin.po;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 计算导入成功数量,失败数量和处理数量
 *
 * @author:Fangtao
 * @Date:2019/11/11 10:25
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberImportQtyPo implements Serializable {
    @ApiModelProperty("成功数量")
    private Integer successQty;
    @ApiModelProperty("失败数量")
    private Integer failureQty;
    @ApiModelProperty("处理中数量")
    private Integer processingQty;
}
