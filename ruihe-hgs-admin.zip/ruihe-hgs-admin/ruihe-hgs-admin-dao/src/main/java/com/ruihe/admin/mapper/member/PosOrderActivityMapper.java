package com.ruihe.admin.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.order.PosOrderActivity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author LiangYuan
 * @Description
 * @create 2020-09-18 11:25
 */
@Mapper
public interface PosOrderActivityMapper extends BaseMapper<PosOrderActivity> {
}
