package com.ruihe.admin.mapper.bi;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.admin.response.bi.Report001Data;
import com.ruihe.common.constant.DBConst;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
@DS(DBConst.SLAVE)
public interface Report001Mapper {
    List<Report001Data> query();
}
