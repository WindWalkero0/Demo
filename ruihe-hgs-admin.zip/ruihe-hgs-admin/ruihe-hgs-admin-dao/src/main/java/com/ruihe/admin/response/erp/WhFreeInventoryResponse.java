package com.ruihe.admin.response.erp;

import com.ruihe.common.pojo.PageVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-22 9:51
 */
@ApiModel(value = "WhFreeInventoryResponse", description = "查询盘点单响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhFreeInventoryResponse implements Serializable {

    @ApiModelProperty(value = "自由盘点返回前端Vo")
    private PageVO pageVo;

    @ApiModelProperty(value = "自由盘点数据结果返回前端Vo")
    WhFreeInventoryResultResponse whFreeInventoryResultResponse;

    @ApiModelProperty(value = "传给前端key")
    private String key;
}
