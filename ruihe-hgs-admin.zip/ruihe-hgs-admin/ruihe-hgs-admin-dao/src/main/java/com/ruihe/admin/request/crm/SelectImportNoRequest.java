package com.ruihe.admin.request.crm;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author:Fangtao
 * @Date:2019/11/8 16:16
 */
@ApiModel(value = "SelectImportNoRequest", description = "会员档案excel导入->按条件查询请求实体")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SelectImportNoRequest implements Serializable {

    @ApiModelProperty(value = "导入模式(0,新增模式 1,更新模式)")
    private Integer importMode;

    @ApiModelProperty(value = "导入名称")
    private String importName;

    @ApiModelProperty(value = "开始时间")
    private LocalDate startTime;

    @ApiModelProperty(value = "结束时间")
    private LocalDate endTime;

    private Integer pageSize;
    private Integer pageNumber;
}
