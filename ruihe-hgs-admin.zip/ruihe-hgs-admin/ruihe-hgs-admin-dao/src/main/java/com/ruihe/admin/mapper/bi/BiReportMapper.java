package com.ruihe.admin.mapper.bi;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.po.BiReportPo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BiReportMapper extends BaseMapper<BiReportPo> {
}
