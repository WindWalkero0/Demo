package com.ruihe.admin.request.basic;

import lombok.Data;

/**
 * @Description
 * @author 梁远
 * @create 2019-06-19 10:42
 */
@Data
public class AgentRequest {
    //所属品牌
    public String brandId;

    //代理商代码
    public String agentId;

    //代理商名称
    public String agentName;

    //代理商等级
    public Integer agentLevel;

    //所属省份ID
    public Integer provinceId;

    //所属城市ID
    public Integer cityId;

    //代理商类别
    public Integer agentType;

    //有效区分
    public Integer status;
}
