package com.ruihe.admin.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author:Fangtao
 * @Date:2019/11/15 20:22
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_msg_record")
public class MsgRecordPo implements Serializable {
    private Long id;
    /*** 区号 **/
    private String regionCode;
    /*** 联系方式 */
    private String contact;
    /*** 模板代码 */
    private String templateCode;
    /*** 语言_国家,zh_CN */
    private String locale;
    /*** 供应商代码 */
    private String supplier;
    /*** 标题 */
    private String subject;
    /*** 消息内容 */
    private String content;
    /*** 响应内容,json */
    private String responseText;
    /*** 我方生产的请求id */
    private String reqId;
    /*** 供应商返回的id */
    private String resId;
    /*** 模板代码 */
    private String remark;
    /**
     * 基础运营商确认时间(成功/失败)
     */
    private LocalDateTime ackTime;
    /*** 客户ip */
    private String ip;
    /*** 状态,0未发送,1已发送,2发送成功,3发送失败,4其他 */
    private Integer status;
    /*** 备注 */
    private LocalDateTime createTime;
    /*** 创建时间 */
    private LocalDateTime updateTime;
}
