package com.ruihe.admin.po;

import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ruihe.common.ArrayJsonHandler;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 消息
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName(value = "t_pos_message", autoResultMap = true)
public class PosMessagePo implements Serializable {
    /**
     * 主键id
     **/
    @TableId(type = IdType.AUTO)
    private Integer msgId;
    /**
     * 消息标题
     **/
    private String title;
    /**
     * 正文
     **/
    private String content;
    /**
     * 定时发送时间
     **/
    private LocalDateTime sendTime;
    /**
     * 结束时间
     */
    private LocalDateTime endTime;
    /**
     * 发送状态,0待发送/1已取消/2已发送/3已删除
     **/
    private Integer status;

    /**
     * 最后修改用户ID
     */
    private String lastModifyUserId;

    /**
     * 最后修改用户Name
     */
    private String lastModifyUserName;
    /**
     * 创建时间
     **/
    private LocalDateTime createTime;
    /**
     * 最近更新时间
     **/
    private LocalDateTime updateTime;
    /**
     * 消息排序
     */
    private Integer seq;

    /**
     * 可以查看的柜台
     */
    @TableField(typeHandler = ArrayJsonHandler.class)
    private JSONArray placeInfo;

    /**
     * 消息编辑回显字段
     */
    private String showDescription;
}
