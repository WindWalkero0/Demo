package com.ruihe.admin.response.erp;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-22 11:03
 */
@ApiModel(value = "TransferMasterExcelResponse", description = "调拨单主表excel导出")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class TransferMasterExcelResponse implements Serializable {

    @ExcelProperty(value = "调拨申请单号", index = 0)
    private String transferOrderNo;

    @ExcelProperty(value = "调入部门编号", index = 1)
    private String inCounterId;

    @ExcelProperty(value = "调入部门名称", index = 2)
    private String inCounterName;

    @ExcelProperty(value = "调出部门编号", index = 3)
    private String outCounterId;

    @ExcelProperty(value = "调出部门名称", index = 4)
    private String outCounterName;

    @ExcelProperty(value = "调拨数量", index = 5)
    private Integer inGoodsQty;

    @ExcelProperty(value = "调拨申请日期", index = 6)
    private String createTime;

    @ExcelProperty(value = "调出日期", index = 7)
    private String ackOutTime;

    @ExcelProperty(value = "调拨金额", index = 8)
    private BigDecimal inAmt;

    @ExcelProperty(value = "处理状态", index = 9)
    private String status;

    @ExcelProperty(value = "操作员（调出方）", index = 10)
    private String outBaName;
}
