package com.ruihe.admin.mapper.erp.report;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.warehouse.WhStockPo;
import com.ruihe.admin.request.erp.RealtimeStockRequest;
import com.ruihe.admin.response.erp.WhProductStockDetailVo;
import com.ruihe.admin.response.erp.WhProductStockVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface WhStockMapper extends BaseMapper<WhStockPo> {
    int updateCategoryInfo(@Param("product") Product product);

    /**
     * 进销存管理->报表查询->产品实时库存查询
     */
    IPage<WhProductStockVo> queryRealtimeStock(
            Page<WhProductStockVo> page,
            @Param("request") RealtimeStockRequest request);

    /**
     * 产品实时库存查询excel导出
     *
     * @param request
     * @return
     */
    List<WhProductStockVo> queryRealtimeStockExcel(@Param("request") RealtimeStockRequest request);

    /**
     * 查询详情与导出查询
     *
     * @param request
     * @return
     */
    List<WhProductStockDetailVo> queryRealtimeStockDetail(
            @Param("request") RealtimeStockRequest request);

    /**
     * 导出数据之前查询数据量
     *
     * @param request
     * @return
     */
    Long exportDetailCount(@Param("request") RealtimeStockRequest request);

    /**
     * 导出数据之前查询数据量
     *
     * @param request
     * @return
     */
    Long exportTableCount(@Param("request") RealtimeStockRequest request);
}
