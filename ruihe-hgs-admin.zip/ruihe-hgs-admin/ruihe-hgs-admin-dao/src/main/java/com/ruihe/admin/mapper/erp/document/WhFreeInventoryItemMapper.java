package com.ruihe.admin.mapper.erp.document;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhFreeInventoryItemPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-22 15:48
 */
@Mapper
public interface WhFreeInventoryItemMapper extends BaseMapper<WhFreeInventoryItemPo> {
}
