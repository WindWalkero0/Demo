package com.ruihe.admin.request.basic;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@ApiModel("柜台操作接收类")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CounterRequest {

    @ApiModelProperty("柜台名称")
    public String counterName;

    @ApiModelProperty("柜台编号")
    public String counterId;

    @ApiModelProperty("柜台地址")
    public String counterAddress;

    @ApiModelProperty("柜台主管")
    public String orgMasterName;

    @ApiModelProperty("所属省份code")
    public String provinceCode;

    @ApiModelProperty("所属于城市code")
    public String cityCode;

    @ApiModelProperty("所属渠道code")
    public String channelCode;

    @ApiModelProperty("柜台状态")
    public Integer counterStatus;

    @ApiModelProperty("停用启用   0启用  1停用")
    public Integer isDel;

    @ApiModelProperty("柜台id列表")
    private List<String> counterIds;

    @ApiModelProperty("分页大小")
    private Integer pageSize;

    @ApiModelProperty("当前页数")
    private Integer pageNumber;

    @ApiModelProperty("查询截图地址")
    private String picUrl;

    @ApiModelProperty("备注")
    private String remark;
}
