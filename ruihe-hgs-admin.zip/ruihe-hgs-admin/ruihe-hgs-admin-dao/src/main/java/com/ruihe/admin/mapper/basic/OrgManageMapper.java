package com.ruihe.admin.mapper.basic;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OrgManageMapper {
}
