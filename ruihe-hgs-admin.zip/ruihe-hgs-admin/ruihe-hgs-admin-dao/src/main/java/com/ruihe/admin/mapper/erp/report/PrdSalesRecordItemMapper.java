package com.ruihe.admin.mapper.erp.report;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Anthor:Fangtao
 * @Date:2019/11/28 16:19
 */
@Mapper
public interface PrdSalesRecordItemMapper extends BaseMapper<PosOrderItemPo> {

}
