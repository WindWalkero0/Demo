package com.ruihe.admin.mapper.bi;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.common.constant.DBConst;
import com.ruihe.admin.request.bi.MemberPurchaseTraceReportRequest;
import com.ruihe.admin.request.bi.MemberSalesFactorReportRequest;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.response.bi.MemberPurchaseResponse;
import com.ruihe.admin.response.bi.MemberSalesResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Author: ly
 * @Date: 2020-02-05 14:46
 * @Description 1.0
 */
@Mapper
@DS(DBConst.SLAVE)
public interface MemberReportMapper {
    /**
     * 会员购买跟踪报表查询
     *
     * @param request
     * @param
     * @return
     */
    List<MemberPurchaseResponse> memberPurchaseTrace(@Param("page") Page page,
                                                     @Param("request") MemberPurchaseTraceReportRequest request,
                                                     @Param("org") OrgQueryConditionRequest org,
                                                     @Param("scols") String scols,
                                                     @Param("gcols") String gcols,
                                                     @Param("empId") String empId,
                                                     @Param("flag") boolean flag);


    /**
     * 会员销售要素统计报表--基础数据
     *
     * @param request
     * @param
     * @return
     */
    List<MemberSalesResponse> memberSalesFactor4BaseData(@Param("page") Page page,
                                                         @Param("request") MemberSalesFactorReportRequest request,
                                                         @Param("org") OrgQueryConditionRequest org,
                                                         @Param("scols") String outScols,
                                                         @Param("gcols") String outGcols,
                                                         @Param("empId") String empId,
                                                         @Param("flag") boolean flag);

    /**
     * 会员销售要素统计报表-销售天数
     *
     * @param request
     * @param
     * @return
     */
    List<MemberSalesResponse> memberSalesFactor4SaleDays(@Param("page") Page page,
                                                         @Param("request") MemberSalesFactorReportRequest request,
                                                         @Param("org") OrgQueryConditionRequest org,
                                                         @Param("inScols") String inScols,
                                                         @Param("inGcols") String inGcols,
                                                         @Param("outScols") String outScols,
                                                         @Param("outGcols") String outGcols,
                                                         @Param("empId") String empId,
                                                         @Param("flag") boolean flag);

    /**
     * 会员销售要素统计报表-经营新会员数据
     *
     * @param request
     * @param
     * @return
     */
    List<MemberSalesResponse> memberSalesFactor4OptNew(@Param("page") Page page,
                                                        @Param("request") MemberSalesFactorReportRequest request,
                                                        @Param("org") OrgQueryConditionRequest org,
                                                        @Param("scols") String scols,
                                                        @Param("gcols") String gcols,
                                                        @Param("empId") String empId,
                                                        @Param("flag") boolean flag);

    /**
     * 会员销售要素统计报表-会员入会数量
     *
     * @param request
     * @param
     * @return
     */
    List<MemberSalesResponse> memberSalesFactor4Mj(@Param("page") Page page,
                                                   @Param("request") MemberSalesFactorReportRequest request,
                                                   @Param("org") OrgQueryConditionRequest org,
                                                   @Param("scols") String scols,
                                                   @Param("gcols") String gcols,
                                                   @Param("empId") String empId,
                                                   @Param("flag") boolean flag);
}
