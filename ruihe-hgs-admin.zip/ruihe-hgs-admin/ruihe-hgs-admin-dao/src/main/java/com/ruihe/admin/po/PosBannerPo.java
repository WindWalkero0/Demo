package com.ruihe.admin.po;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 轮播图管理
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_pos_banner")
public class PosBannerPo implements Serializable {
    /**
     * 主键id
     **/
    @TableId(type = IdType.AUTO)
    private Integer bannerId;

    /**
     * banner标题
     */
    private String title;

    /**
     * APP:移动端  WEB:WEB端
     */
    private String osType;

    /**
     * 所属模块
     */
    private String bannerType;

    /**
     * 链接url
     */
    private String linkUrl;

    /**
     * 图片跳转href
     */
    private String imgUrl;

    /**
     * banner描述/广告描述
     */
    private String description;

    /**
     *排序序号
     */
    private Integer sortNum;

    /**
     * 状态：0有效,1无效
     */
    private Integer status;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 修改时间
     */
    private LocalDateTime updateTime;

}
