package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author 梁远
 * @Description
 * @create 2020-02-27 10:07
 */
@ApiModel(value = "PaymentReportResponse", description = "支付方式报表返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PaymentReportResponse implements Serializable {

    @ApiModelProperty(value = "订单号")
    private String orderNo;

    @ApiModelProperty(value = "前置单据号")
    private String preOrderNo;

    @ApiModelProperty(value = "柜台id")
    private String counterId;

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "柜员代码")
    private String baCode;

    @ApiModelProperty(value = "柜员姓名")
    private String baName;

    @ApiModelProperty(value = "订单渠道名称")
    private String orderChanName;

    @ApiModelProperty(value = "订单金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal realAmt;

    @ApiModelProperty(value = "支付金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal payAmt;

    @ApiModelProperty(value = "会员姓名")
    private String memberName;

    @ApiModelProperty(value = "会员手机号码/卡号")
    private String memberPhone;

    @ApiModelProperty(value = "小票号码")
    private String receiptNo;

    @ApiModelProperty(value = "交易类型")
    private Integer transType;

    @ApiModelProperty(value = "订单类型：1实体店销售,2预定单")
    private Integer orderType;

    @ApiModelProperty(value = "支付渠道:10现金,20银行卡,30微信,40支付宝,50银联二维码,60其他")
    private String payChannel;

    @ApiModelProperty(value = "业务发生时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime bizTime;
}
