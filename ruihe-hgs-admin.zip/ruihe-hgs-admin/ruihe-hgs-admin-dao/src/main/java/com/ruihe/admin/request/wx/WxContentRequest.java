package com.ruihe.admin.request.wx;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author fly
 * @date 2020年10月28日10:39:16
 */
@ApiModel(value = "WxContentRequest", description = "会员购买跟踪报表请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WxContentRequest implements Serializable {

    @ApiModelProperty("id")
    public Integer id;

    @ApiModelProperty("所属微信号")
    public String belong;

    @ApiModelProperty("回复类型文本类型  图文类型")
    @Size(max = 30,message = "回复内容最大长度为30个字符")
    public String type;

    @ApiModelProperty("展示回复内容")
    @Size(max = 999,message = "展示回复内容最大长度为999个字符")
    public String showContent;

    @ApiModelProperty("回复内容")
    @Size(max = 999,message = "回复内容最大长度为999个字符")
    public String content;

    @ApiModelProperty("超链接")
    @Builder.Default
    private List<WxContentHyperLinksRequest> hyperlinks = new ArrayList<WxContentHyperLinksRequest>();

}
