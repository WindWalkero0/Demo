package com.ruihe.admin.mapper.erp.document;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhTransferItemPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * 通过申请单号查看详情
 *
 * @Anthor:Fangtao
 * @Date:2019/11/22 11:27
 */
@Mapper
public interface WhTransferItemMapper extends BaseMapper<WhTransferItemPo> {
}
