package com.ruihe.admin.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 员工柜台批量导入
 *
 * @author huangjie
 * @since 2021-06-29
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_employee_counter")
public class EmployeeCounterImportPo implements Serializable {

    /**
     * emp_id员工id
     */
    private String empId;

    /**
     * 姓名
     */
    private String name;

    /**
     * 手机号码
     */
    private String phoneNo;


    /**
     * 部门代码
     */
    private String counterCode;

    /**
     * 部门名称
     */
    private String counterName;

    /**
     * 是否是店长:0否1是
     */
    private Integer isMaster;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
}
