package com.ruihe.admin.request.wx;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author fly
 * @date 2020年10月28日10:39:16
 */
@ApiModel(value = "WxContentHyperLinksRequest", description = "超链接")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WxContentHyperLinksRequest implements Serializable {

    @ApiModelProperty("占位符")
    public String placeholder;

    @ApiModelProperty("所属微信号")
    public String linkWord;

    @ApiModelProperty("超链接地址")
    public String url;

}
