package com.ruihe.admin.response.bi;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Anthor: William
 * @Date:2020/2/6 22:17
 */
@ApiModel(value = "BaSalesDailyReportPo", description = "销售业绩报表-ba销售日报")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BaSalesTimeReportPo implements Serializable {

    @ApiModelProperty(value = "年月/日期")
    private String time;

    @ApiModelProperty("大区代码")
    private String orgAreaCode;

    @ApiModelProperty("大区名称")
    private String orgAreaName;

    @ApiModelProperty("办事处代码")
    private String orgOfficeCode;

    @ApiModelProperty("办事处名称")
    private String orgOfficeName;

    @ApiModelProperty("柜台主管代码")
    private String orgPrincipalCode;

    @ApiModelProperty("柜台主管姓名")
    private String orgPrincipalName;

    @ApiModelProperty("柜台id")
    private String counterId;

    @ApiModelProperty("柜台")
    private String counterName;

    @ApiModelProperty("ba编号")
    private String baCode;

    @ApiModelProperty("ba姓名")
    private String baName;

    @ApiModelProperty("销售总金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal realAmt;

    @ApiModelProperty("实物销售总支数")
    private Integer goodsQty;

    @ApiModelProperty("护肤品类销售总支数")
    private Integer skQty;

    @ApiModelProperty("销售总单数")
    private Integer orderQty;

    @ApiModelProperty("净销售总单数,排除实付/退款金额等于0的订单")
    private Integer netOrderQty;

    @ApiModelProperty("经营新会员人数")
    private Integer optNewMem;

    @ApiModelProperty("销售天数")
    private Integer salesDays;

    @ApiModelProperty("客单价")
    private BigDecimal pct;

    @ApiModelProperty("连带率")
    private BigDecimal jr;

    @ApiModelProperty("老会员购买人数")
    private Integer vetPur;

    @ApiModelProperty("老客单（老会员购买金额/老会员购买单数）")
    private BigDecimal vetPct;
    @ApiModelProperty("老会员购买金额")
    private BigDecimal vetAmt;
    @ApiModelProperty("老会员购买单数")
    private Integer vetOrder;

    @ApiModelProperty("经营新客单\n（经营新会员购买金额/经营新会员购买单数）")
    private BigDecimal optNewPct;
    @ApiModelProperty("经营新会员购买金额")
    private BigDecimal optNewAmt;
    @ApiModelProperty("经营新会员购买单数")
    private Integer optNewOrder;

    @ApiModelProperty("会员入会数量")
    private Integer mj;
    @ApiModelProperty("新会员购买单数")
    private Integer newOrder;
    @ApiModelProperty("新会员重复购买率（新会员购买单数/会员入会数量）")
    private BigDecimal newRepurRate;
    @ApiModelProperty("老会员重复购买率（老会员购买单数/老会员购买人数）,老会员复购率")
    private BigDecimal vetRepurRate;
}
