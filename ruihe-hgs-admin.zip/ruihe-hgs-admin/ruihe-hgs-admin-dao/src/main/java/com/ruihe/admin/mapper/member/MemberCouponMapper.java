package com.ruihe.admin.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.member.MemberCoupon;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MemberCouponMapper extends BaseMapper<MemberCoupon> {

    Integer stopMemberCoupon(List<String> memberCoupons);
}