package com.ruihe.admin.mapper.erp.document;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhReturnItemLogPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-23 18:04
 */
@Mapper
public interface WhReturnItemLogMapepr extends BaseMapper<WhReturnItemLogPo> {
}
