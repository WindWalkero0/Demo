package com.ruihe.admin.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.member.MemberFileImportItem;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @Anthor:Fangtao
 * @Date:2019/11/21 11:16
 */
@Mapper
public interface MemberFileImportItemMapper extends BaseMapper<MemberFileImportItem> {
    /**
     * 设置页码
     */
    Long queryTotal(@Param("importSerialNo") String importSerialNo);
}
