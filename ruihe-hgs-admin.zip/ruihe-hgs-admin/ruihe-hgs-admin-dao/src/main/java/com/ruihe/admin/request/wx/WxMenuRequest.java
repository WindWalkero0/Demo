package com.ruihe.admin.request.wx;

import com.ruihe.common.annotation.Create;
import com.ruihe.common.annotation.Update;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * @author fly
 * @date 2020年10月28日10:39:16
 */
@Data
@ApiModel("微信菜单接收类")
public class WxMenuRequest implements Serializable {

    @ApiModelProperty("id")
    @NotNull(message = "id", groups = {Update.class})
    public Integer id;

    @ApiModelProperty("归属微信公众号")
    @NotBlank(message = "类型不能为空", groups = {Create.class, Update.class})
    public String belong;

    @ApiModelProperty("菜单等级")
    @NotNull(message = "类型不能为空", groups = {Create.class})
    public Integer menuLevel;

    @ApiModelProperty("上级菜单id")
    @NotNull(message = "类型不能为空", groups = {Create.class})
    public Integer parentMenu;

    @ApiModelProperty("菜单类型view表示网页类型，click表示点击类型，miniprogram表示小程序类型")
    @NotBlank(message = "类型不能为空", groups = {Create.class})
    public String type;

    @ApiModelProperty("菜单名称")
    @NotBlank(message = "菜单名称不能为空", groups = {Create.class})
    @Size(max =30,message = "菜单名称最大长度为30个字符")
    public String name;

    @ApiModelProperty("小程序的页面路径")
    public String pagePath;

    @ApiModelProperty("key")
    public String appKey;

    @ApiModelProperty("appId")
    public String appId;

    @ApiModelProperty("链接")
    public String url;


}
