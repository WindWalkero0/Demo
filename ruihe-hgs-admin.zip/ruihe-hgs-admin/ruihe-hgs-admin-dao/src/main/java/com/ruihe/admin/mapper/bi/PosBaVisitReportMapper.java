package com.ruihe.admin.mapper.bi;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.common.constant.DBConst;
import com.ruihe.admin.request.bi.PosBaVisitReportRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

/**
 * @Author: fly
 * @Date: 2020年10月20日12:20:03
 * @Description 1.0
 */
@Mapper
@DS(DBConst.SLAVE)
public interface PosBaVisitReportMapper {

    /**
     * 服务记录bi报表导出
     *
     * @param request
     * @param outScols
     * @param outGcols
     * @param sumDcols
     * @param flag
     * @return
     */
    List<HashMap> posBaVisitReport(@Param("request") PosBaVisitReportRequest request,
                                   @Param("scols") String outScols,
                                   @Param("dcols") String sumDcols,
                                   @Param("gcols") String outGcols,
                                   @Param("flag") boolean flag);
}
