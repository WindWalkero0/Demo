package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author:fly
 * @Date:2020年7月10日09:15:13
 */
@ApiModel(value = "PosLaingitemExtractListResponse", description = "预订单提货单详情返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class PosLaingitemExtractListResponse implements Serializable {
    @ApiModelProperty(value = "产品条码(对外标准条码)")
    private String prdBarCode;
    @ApiModelProperty(value = "产品名称")
    private String prdName;
    @ApiModelProperty(value = "商品条码")
    private String goodsBarCode;
    @ApiModelProperty("已提金额")
    private BigDecimal amt;
    @ApiModelProperty(value = "已提数量")
    private Integer extractQty;
    @ApiModelProperty(value = "提货时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime extractTime;
    @ApiModelProperty(value = "提货单号")
    private String ladingOrderNo;
    @ApiModelProperty(value = "柜台编码")
    private String counterId;
    @ApiModelProperty(value = "柜台名称")
    private String counterName;
    @ApiModelProperty(value = "ba编码")
    private String baCode;
    @ApiModelProperty(value = "ba名称")
    private String baName;
}
