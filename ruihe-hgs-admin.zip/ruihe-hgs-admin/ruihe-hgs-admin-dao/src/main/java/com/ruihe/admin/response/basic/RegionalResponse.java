package com.ruihe.admin.response.basic;

import com.ruihe.common.dao.bean.base.Region;
import lombok.Data;

import java.util.List;

@Data
public class RegionalResponse {
    public String name;
    public Integer id;
    public List<Region> list;
}
