package com.ruihe.admin.mapper.promotional;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.activity.ActivityPlace;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ActivityPlaceMapper extends BaseMapper<ActivityPlace> {
}

