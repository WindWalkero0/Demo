package com.ruihe.admin.request.basic;

import lombok.Data;

/**
 * @Description
 * @author 梁远
 * @create 2019-06-17 16:16
 */
@Data
public class ProductRequest {
    public String brandName;
    //厂商编码
    public String manufacturerCode;
    //产品类型
    public Integer productType1;
    public Integer productType2;
    //产品条码
    public String barCode;
    //中文名
    public String chName;
    //产品状态
    public Integer productStatus;
    //有效区分
    public Integer status;
    //可否用于积分兑换
    public Integer isExchange;
    //大分类
    public String big;

    //中分类
    public String mid;

    //小分类
    public String small;


    //商品品牌和有效状态
}
