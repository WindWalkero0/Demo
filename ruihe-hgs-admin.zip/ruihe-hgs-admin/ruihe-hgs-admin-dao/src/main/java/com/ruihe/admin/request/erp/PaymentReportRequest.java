package com.ruihe.admin.request.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author 梁远
 * @Description
 * @create 2020-02-27 10:00
 */
@ApiModel(value = "PaymentReportRequest", description = "支付方式报表请求实体")
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentReportRequest extends PageForm implements Serializable {

    @ApiModelProperty(value = "开始时间")
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate startTime;

    @ApiModelProperty(value = "结束时间")
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate endTime;

    @ApiModelProperty(value = "订单号")
    private String orderNo;

    @ApiModelProperty(value = "支付方式:10现金,20银行卡,30微信,40支付宝,50银联二维码,60其他")
    private Integer payChannel;

    @ApiModelProperty(value = "组织模式查询条件")
    private OrgQueryConditionRequest orgQueryConditionRequest;
}
