package com.ruihe.admin.response.bi;


import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 会员销售要素统计报表
 *
 * @Author: fangtao
 * @Date: 2020-02-13 14:51
 * @Description 1.0
 */
@ApiModel(value = "MemberSalesResponse", description = "会员销售要素统计报表vo")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberSalesResponse implements Serializable {
    /**
     * ------------组织结构------------
     **/
    @ApiModelProperty("大区代码")
    private String orgAreaCode;

    @ApiModelProperty("大区名称")
    private String orgAreaName;

    @ApiModelProperty("办事处代码")
    private String orgOfficeCode;

    @ApiModelProperty("办事处名称")
    private String orgOfficeName;

    @ApiModelProperty("柜台主管代码")
    private String orgPrincipalCode;

    @ApiModelProperty("柜台主管姓名")
    private String orgPrincipalName;

    @ApiModelProperty("柜台id")
    private String counterId;

    @ApiModelProperty("柜台")
    private String counterName;

    @ApiModelProperty("Ba编号")
    private String baCode;

    @ApiModelProperty("Ba姓名")
    private String baName;

    /**
     * ------------核心数据------------
     **/
    @ApiModelProperty("销售天数")
    private Integer saleDays;

    @ApiModelProperty("销售总金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal salesAmt;

    @ApiModelProperty("销售总单数")
    private Integer salesOrderQty;

    @ApiModelProperty("销售总支数")
    private Integer salesGoodsQty;

    @ApiModelProperty("会员购买人数")
    private Integer memPur;

    @ApiModelProperty("会员购买金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal memAmt;

    @ApiModelProperty("会员购买单数")
    private Integer memOrder;

    @ApiModelProperty("会员入会数量")
    private Integer mj;

    @ApiModelProperty("新会员购买人数")
    private Integer newPur;

    @ApiModelProperty("新会员购买金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal newAmt;

    @ApiModelProperty("新会员购买单数")
    private Integer newOrder;

    @ApiModelProperty("新客单（新会员购买金额/新会员购买单数）")
    private BigDecimal newPct;

    @ApiModelProperty("老会员购买人数")
    private Integer vetPur;

    @ApiModelProperty("老会员购买金额")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private BigDecimal vetAmt;

    @ApiModelProperty("老会员购买单数")
    private Integer vetOrder;

    @ApiModelProperty("老客单（老会员购买金额/老会员购买单数）")
    private BigDecimal vetPct;

    /**
     * 在查询时间段内入会且单次消费大于等于200元的非体验会员
     **/
    @ApiModelProperty("经营新会员人数")
    private Integer optNew;

    @ApiModelProperty("经营新会员购买金额")
    private BigDecimal optNewAmt;

    @ApiModelProperty("经营新会员购买单数")
    private Integer optNewOrder;

    @ApiModelProperty("会员购买金额占比(会员购买金额/销售总金额)")
    private BigDecimal memAmtPp;

    @ApiModelProperty("会员购买单数占比(会员购买单数/销售总单数)")
    private BigDecimal memOrderPp;

    @ApiModelProperty("平均客单价(销售总金额/销售总单数)")
    private BigDecimal pct;

    @ApiModelProperty("连带率(销售总支数/销售总单数)")
    private BigDecimal jr;

    @ApiModelProperty("新会员购买金额占比(新会员购买金额/会员购买金额)")
    private BigDecimal newAmtPp;

    @ApiModelProperty("新会员购买单数占比(新会员购买单数/会员购买单数)")
    private BigDecimal newOrderPp;

    @ApiModelProperty("新会员重复购买率（新会员购买单数/会员入会数量）")
    private BigDecimal newRepurRate;

    @ApiModelProperty("非会员购买人数-即非注册会员购买订单数")
    private Integer nonMemOrder;

    @ApiModelProperty("老会员购买金额占比(老会员购买金额/会员购买金额)")
    private BigDecimal vetAmtPp;

    @ApiModelProperty("老会员购买单数占比(老会员购买单数/会员购买单数)")
    private BigDecimal vetOrderPp;

    @ApiModelProperty("老会员重复购买率（老会员购买单数/老会员购买人数）,老会员复购率")
    private BigDecimal vetRepurRate;

    @ApiModelProperty("经营新会员重复购买率")
    private BigDecimal optNewRepurRate;

    @ApiModelProperty("经营新客单（经营新会员购买金额/经营新会员购买单数）")
    private BigDecimal optNewPct;

}
