package com.ruihe.admin.mapper.employee;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.admin.po.EmployeeImportPo;
import com.ruihe.admin.po.EmployeesPo;
import com.ruihe.common.dao.bean.employee.EmployeeFileImportItem;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description
 * @author huangjei
 * @create 2021-06-23
 */
@Mapper
public interface EmployeeFileImportItemMapper extends BaseMapper<EmployeeFileImportItem> {
    Integer batchInsert(@Param("list") List<EmployeeFileImportItem> list);

    /**
     * 点击导入流水号查看详情->条件查询
     */
    List<EmployeesPo> queryImportDetail(@Param("importSerialNo") String importSerialNo,
                                        @Param("idCard") String idCard,
                                        @Param("name") String name);

    /**
     * 设置页码
     */
    Long queryTotal(@Param("importSerialNo") String importSerialNo,
                    @Param("idCard") String idCard,
                    @Param("name") String name);
}
