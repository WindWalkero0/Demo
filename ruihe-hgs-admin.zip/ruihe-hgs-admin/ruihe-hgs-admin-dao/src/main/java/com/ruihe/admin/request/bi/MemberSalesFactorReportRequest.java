package com.ruihe.admin.request.bi;

import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author 方涛
 * @Description
 * @create 2020-02-05 09:50
 */
@ApiModel(value = "MemberSalesFactorReportRequest", description = "会员销售要素统计报表请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberSalesFactorReportRequest implements Serializable {
    @ApiModelProperty(value = "输出项")
    @NotNull(message = "输出项不能为空")
    private MemberSalesFactorSelectRequest selectRequest;

    @ApiModelProperty(value = "渠道")
    private String channelCode;

    @ApiModelProperty(value = "开始时间")
    @NotNull(message = "开始时间不能为空")
    private LocalDate startTime;

    @ApiModelProperty(value = "结束时间")
    @NotNull(message = "结束时间不能为空")
    private LocalDate endTime;

    @ApiModelProperty("标签")
    @NotBlank(message = "标签不能为空")
    @Size(max= 30,message = "标签最大长度为30个字符")
    private String tag;

    @ApiModelProperty("查询图片地址")
    private String picUrl;

    @ApiModelProperty("组织模式查询条件")
    @Builder.Default
    private OrgQueryConditionRequest orgQueryConditionRequest = new OrgQueryConditionRequest();
}
