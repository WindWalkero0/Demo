package com.ruihe.admin.mapper.erp.document;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.common.dao.bean.warehouse.WhTransferPo;
import com.ruihe.admin.request.erp.OrgQueryConditionRequest;
import com.ruihe.admin.request.erp.TransferRequest;
import com.ruihe.admin.response.erp.TransferItemExcelResponse;
import com.ruihe.admin.response.erp.TransferMasterExcelResponse;
import com.ruihe.admin.response.erp.WhTransferQueryResponse;
import com.ruihe.admin.response.erp.WhTransferResultResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 查询主表方法
 */
@Mapper
public interface WhTransferMapper extends BaseMapper<WhTransferPo> {
    /**
     * 根据条件查询盘点单处理
     *
     * @param request
     * @return
     */
    IPage<WhTransferQueryResponse> queryWhTransfer(@Param("page") Page<WhTransferQueryResponse> page, @Param("request") TransferRequest request, @Param("queryRequest") OrgQueryConditionRequest queryRequest);


    /**
     * 获取总数
     *
     * @param request
     * @param queryRequest
     * @return
     */
    Long queryWhTransferCount(@Param("request") TransferRequest request, @Param("queryRequest") OrgQueryConditionRequest queryRequest);


    /**
     * 查询出结果数据
     *
     * @param request
     * @return
     */
    WhTransferResultResponse queryResult(@Param("request") TransferRequest request, @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 调拨单主表导出总数量查询
     *
     * @param request
     * @param queryRequest
     * @return
     */
    Long queryListCount(@Param("request") TransferRequest request,
                        @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 调拨单主表导出查询
     *
     * @param request
     * @param queryRequest
     * @return
     */
    List<TransferMasterExcelResponse> masterListExcel(@Param("request") TransferRequest request,
                                                      @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 调拨单子表导出总数量查询
     *
     * @param request
     * @param queryRequest
     * @return
     */
    Long queryItemListCount(@Param("request") TransferRequest request,
                            @Param("queryRequest") OrgQueryConditionRequest queryRequest);

    /**
     * 调拨单子表导出查询
     *
     * @param request
     * @param queryRequest
     * @return
     */
    List<TransferItemExcelResponse> itemListExcel(@Param("request") TransferRequest request,
                                                  @Param("queryRequest") OrgQueryConditionRequest queryRequest);
}
