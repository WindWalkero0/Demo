package com.ruihe.admin.response.erp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @Anthor:Fangtao
 * @Date:2020/3/10 14:14
 */
@ApiModel(value = "WhEnterQueryResponse", description = "发货单处理返回前端Vo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class WhEnterQueryResponse implements Serializable {
    @ApiModelProperty(value = "发货单号")
    private String deliveryNo;

    @ApiModelProperty(value = "收货部门id")
    private String counterId;

    @ApiModelProperty(value = "收货部门名称")
    private String counterName;

    @ApiModelProperty(value = "发货数量")
    private Integer deliveryQty;

    @ApiModelProperty(value = "入库单")
    private String enterNo;

    @ApiModelProperty(value = "状态 (1,待确认;2,已确认)")
    private Integer status;

    @ApiModelProperty(value = "时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
}
