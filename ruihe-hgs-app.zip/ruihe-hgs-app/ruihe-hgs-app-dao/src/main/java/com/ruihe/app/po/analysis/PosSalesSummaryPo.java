package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 销售小结
 *
 * @author:Fangtao
 * @Date:2019/10/30 14:37
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosSalesSummaryPo implements Serializable {
    /**
     * ba代码
     */
    private String baCode;
    /**
     * ba姓名
     */
    private String baName;
    /**
     * 订单数(查询时间段内正常销售单+预订单数)
     */
    private Integer orderQty;

    private Integer returnOrderQty;
    /**
     * 销售数量
     */
    private Integer salesQty;
    /**
     * 销售额
     */
    private BigDecimal salesAmt;
    /**
     * 退货数
     */
    private Integer returnQty;
    /**
     * 退货金额
     */
    private BigDecimal returnAmt;
    /**
     * 预定数
     */
    private Integer bookQty;
    /**
     * 预定金额
     */
    private BigDecimal bookAmt;
    /**
     * 提货数量
     */
    private Integer takeGoodsQty;
    /**
     * 提货退货数量
     */
    private Integer takeReturnQty;
    /**
     * 预订单退货数
     */
    private Integer orderFormReturnQty;
    /**
     * 护肤品销售数量
     */
    private Integer skSalesQty;
    /**
     * 护肤品退货数量
     */
    private Integer skReturnQty;
    /**
     * 预订单退货金额
     */
    private BigDecimal orderFormReturnAmt;
}
