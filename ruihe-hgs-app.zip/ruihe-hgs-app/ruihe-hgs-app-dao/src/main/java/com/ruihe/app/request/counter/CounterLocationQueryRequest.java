package com.ruihe.app.request.counter;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author qubin
 * @date 2021/4/23 15:00
 */
@ApiModel(value = "CounterLocationQueryRequest", description = "查询柜台位置")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CounterLocationQueryRequest implements Serializable {

    @ApiModelProperty("柜台名称")
    private String counterName;

    @ApiModelProperty("省编码")
    private String provinceCode;

    @ApiModelProperty("市编码")
    private String cityCode;

    @ApiModelProperty("区编码")
    private String countyCode;

    @ApiModelProperty("定位经纬度")
    private String location;
}
