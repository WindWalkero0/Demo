package com.ruihe.app.po.material;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author qubin
 * @date 2021年07月05日 10:39
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_material")
public class MaterialPo implements Serializable {

    /**
     * 主键
     */
    @TableId
    private Integer id;

    /**
     * 模块id
     */
    private Integer moduleId;

    /**
     * 模块名称
     */
    private String moduleName;

    /**
     * 项目id
     */
    private Integer projectId;

    /**
     * 项目名称
     */
    private String projectName;

    /**
     * 分类id
     */
    private Integer categoryId;

    /**
     * 分类名称
     */
    private String categoryName;

    /**
     * 图片描述
     */
    private String picMemo;

    /**
     * 标签
     */
    private String tag;

    /**
     * 封面图片地址
     */
    private String coverUrl;

    /**
     * 图片地址
     */
    private String picUrls;

    /**
     * 连接地址
     */
    private String linkUrl;

    /**
     * 状态，0表示无效|1表示有效
     */
    private Integer status;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 修改时间
     */
    private LocalDateTime updateTime;
}
