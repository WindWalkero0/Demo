package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.ProductSortItemPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Anthor:Fangtao
 * @Date:2019/11/25 15:38
 */
@Mapper
public interface WhProductSortMapper extends BaseMapper<ProductSortItemPo> {
}
