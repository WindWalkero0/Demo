package com.ruihe.app.request.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AddMoneyProducts implements Serializable {

    @ApiModelProperty("对应的数量")
    private Integer count;

    @ApiModelProperty("商品条码")
    private String proId;

    @ApiModelProperty("产品编码")
    private String proCode;

    @ApiModelProperty("产品名称")
    private String name;

    @ApiModelProperty("商品单价")
    private BigDecimal proPrice;

    @ApiModelProperty("商品会员价")
    private BigDecimal memberPrice;
}
