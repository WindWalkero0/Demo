package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 销售月报表->销售明细报表->条件搜索
 *
 * @author:Fangtao
 * @Date:2019/11/5 16:52
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosDetailReportConditionPo implements Serializable {
    /**
     * 总汇中的单数
     */
    private Integer orders;
    /**
     * 总汇中的数量
     */
    private Integer number;
    /**
     * 总汇中的业绩
     */
    private BigDecimal performance;
    /**
     * 会员姓名
     */
    private String memberName;
    /**
     * 时间
     */
    private LocalDateTime createTime;
    /**
     * 时间
     */
    private LocalDateTime bizTime;
    /**
     * 数量
     */
    private Integer qty;
    /**
     * 小票号
     */
    private String receiptNo;
    /**
     * 金额
     */
    private BigDecimal amt;
    /**
     * 订单号
     */
    private String orderNo;

    private Integer transType;

    private Integer activityType;

    private String memberPhone;

    private String baName;

    private Integer goodsQty;
}
