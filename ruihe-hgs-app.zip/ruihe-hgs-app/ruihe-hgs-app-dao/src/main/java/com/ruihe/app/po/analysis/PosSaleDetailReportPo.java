package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 销售明细报表->销售小结->按条件计算数量与销售额
 *
 * @author:Fangtao
 * @Date:2019/10/31 14:45
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosSaleDetailReportPo implements Serializable {
    /**
     * 销售总数量
     */
    private Integer saleQty;
    /**
     * 销售总金额
     */
    private BigDecimal saleAmt;
    /**
     * 退货数量
     */
    private Integer returnQty;
    /**
     * 退货金额
     */
    private BigDecimal returnAmt;
}
