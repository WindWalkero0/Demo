package com.ruihe.app.po.crm;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/11 19:17
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberInfoMessagePo implements Serializable {
    private String memberName;

    //积分
    public Integer integral;

    //积分时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime integralTime;

    private String birthday;

    @ApiModelProperty("入会时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    private String memberLevelName;

    @ApiModelProperty(value = "累计消费金额")
    private BigDecimal buyAmt;

    @ApiModelProperty(value = "上次消费金额")
    private BigDecimal lastTimeAmt;

    private Integer transType;
}
