package com.ruihe.app.po.basic;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author:Fangtao
 * @Date:2019/11/6 16:23
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosCounterPo implements Serializable {
    @ApiModelProperty("柜台编号")
    private String counterId;
    @ApiModelProperty("柜台名称")
    public String counterName;
}
