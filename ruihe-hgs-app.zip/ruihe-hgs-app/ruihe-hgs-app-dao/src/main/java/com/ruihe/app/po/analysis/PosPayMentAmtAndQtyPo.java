package com.ruihe.app.po.analysis;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 商品销售排行榜中的净销售数量和金额
 *
 * @Anthor:Fangtao
 * @Date:2020/3/10 17:32
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosPayMentAmtAndQtyPo implements Serializable {
    @ApiModelProperty(value = "总销售数量")
    private Integer qty;

    @ApiModelProperty(value = "总购买金额")
    private BigDecimal amt;
}
