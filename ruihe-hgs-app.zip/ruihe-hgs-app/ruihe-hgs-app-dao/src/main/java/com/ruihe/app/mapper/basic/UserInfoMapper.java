package com.ruihe.app.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.UserInformation;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Anthor:Fangtao
 * @Date:2020/3/12 19:29
 */
@Mapper
public interface UserInfoMapper extends BaseMapper<UserInformation> {
}
