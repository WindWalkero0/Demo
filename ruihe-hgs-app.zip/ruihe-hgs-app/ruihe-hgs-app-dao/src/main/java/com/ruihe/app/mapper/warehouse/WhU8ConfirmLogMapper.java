package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhU8ConfirmLogPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * u8返回确认 Mapper 接口
 * </p>
 *
 * @author William
 * @since 2020-03-10
 */
@Mapper
public interface WhU8ConfirmLogMapper extends BaseMapper<WhU8ConfirmLogPo> {

}
