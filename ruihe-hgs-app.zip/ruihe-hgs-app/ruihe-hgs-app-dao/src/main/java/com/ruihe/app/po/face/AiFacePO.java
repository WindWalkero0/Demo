package com.ruihe.app.po.face;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_ai_face_info")
public class AiFacePO {

    /**
     * id
     */
    @TableId(value = "id", type = IdType.NONE)
    private String id;
    /**
     * 测肤记录ID
     */
    private String photographId;
    /**
     * 黑头
     */
    private String blackHead;
    /**
     * 痘痘
     */
    private String acnes;
    /**
     * 痘痘图层图片
     */
    private String acneLayer;
    /**
     * 黑眼圈
     */
    private String darkCircle;
    /**
     * 黑眼圈图层图片
     */
    private String darkCircleMaskPath;
    /**
     * 眉形
     */
    private String eyebrow;
    /**
     * 眼型
     */
    private String eyeshape;
    /**
     * 人脸姿态估计
     */
    private String facePose;
    /**
     * 遮挡物
     */
    private String faceShelter;
    /**
     * 肤色
     */
    private String facecolor;
    /**
     * 脸型
     */
    private String faceshape;
    /**
     * 脂肪粒
     */
    private String fatGranule;
    /**
     * 卧蚕
     */
    private Integer furrows;
    /**
     * 图片质量
     */
    private String imageQuality;
    /**
     * 是否是人脸
     */
    private Integer isface;
    /**
     * 水分
     */
    private String moisture;
    /**
     * 水分图层图片
     */
    private String moistureMaskPath;
    /**
     * 水分整脸的情况
     */
    private String moistureOverall;
    /**
     * 油分
     */
    private String oil;
    /**
     * 油分整脸的情况
     */
    private String oilOverall;
    /**
     * 油分图层图片
     */
    private String oilMaskPath;
    /**
     * 色素斑
     */
    private String pigmentations;
    /**
     * 色斑图层图片
     */
    private String pigmentationLayer;
    /**
     * 毛孔
     */
    private String pore;
    /**
     * 眼袋
     */
    private String pouch;
    /**
     * 敏感度
     */
    private String sensitivity;
    /**
     * 性别
     */
    private Integer sex;
    /**
     * 肌肤年龄
     */
    private Integer skinAge;
    /**
     * 肤质类型
     */
    private Integer skinType;
    /**
     * 相似明星脸
     */
    private String starResult;
    /**
     * 细纹
     */
    private String wrinkles;
    /**
     * 细纹图层图片
     */
    private String wrinkleLayer;
    /**
     * 鱼尾纹图层图片
     */
    private String crowfeetMaskPath;
    /**
     * 原图人脸坐标
     */
    private String orgimageFaceLocation;
    /**
     * 会员ID
     */
    private String memberId;
    /**
     * 面部原始图片
     */
    private String faceOriginImage;
    /**
     * 底图
     */
    private String basemapPaths;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;


}
