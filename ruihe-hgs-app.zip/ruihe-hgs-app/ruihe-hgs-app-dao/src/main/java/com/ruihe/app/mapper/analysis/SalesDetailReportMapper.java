package com.ruihe.app.mapper.analysis;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.analysis.PosReturnOrderDetailsPo;
import com.ruihe.app.po.analysis.PosSaleDetailPayMentPo;
import com.ruihe.app.po.analysis.PosSaleDetailPo;
import com.ruihe.app.po.analysis.PosSaleDetailReturnPo;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 销售明细单--销售类型
 *
 * @author:Fangtao
 * @Date:2019/10/31 16:21
 */
@Mapper
public interface SalesDetailReportMapper extends BaseMapper<PosOrderItemPo> {
    /**
     * 销售明细单--销售类型
     *
     * @param orderNo
     * @return
     */
    List<PosSaleDetailPo> queryDetail(@Param("orderNo") String orderNo);

    /**
     * 销售明细单--销售类型--统计总金额
     *
     * @param orderNo
     * @return
     */
    PosSaleDetailPo queryAmt(@Param("orderNo") String orderNo);

    /**
     * 销售明细单--销售类型--支付方式
     *
     * @param orderNo
     * @return
     */
    List<PosSaleDetailPayMentPo> queryPayType(@Param("orderNo") String orderNo);

    /**
     * 销售明细单--销售类型--关联退货单
     *
     * @param orderNo
     * @return
     */
    PosSaleDetailPo queryReturnNo(@Param("orderNo") String orderNo);

    /**
     * 销售明细单--退货类型
     *
     * @param orderNo
     * @return
     */
    List<PosSaleDetailReturnPo> queryReturnType(@Param("orderNo") String orderNo);

    /**
     * 销售明细单--退货类型--统计总金额
     *
     * @param transType
     * @param preOrderNo
     * @return
     */
    PosSaleDetailReturnPo queryTotalAmt(@Param("transType") Integer transType, @Param("preOrderNo") String preOrderNo);

    /**
     * 销售明细单--退货类型--支付方式
     *
     * @param orderNo
     * @return
     */
    List<PosSaleDetailReturnPo> queryPay(@Param("orderNo") String orderNo);

    /**
     * 销售明细单--退货类型--退货单号
     *
     * @param transType
     * @param preOrderNo
     * @return
     */
    PosSaleDetailReturnPo returnNo(@Param("transType") Integer transType, @Param("preOrderNo") String preOrderNo);

    /**
     * 销售明细单--退货类型--退货单明细
     *
     * @param orderNo
     * @return
     */
    List<PosReturnOrderDetailsPo> queryReturnOrderDetails(@Param("orderNo") String orderNo);

    List<PosReturnOrderDetailsPo> queryPayWays(@Param("orderNo") String orderNo);
}
