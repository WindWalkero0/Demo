package com.ruihe.app.mapper.order;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.app.request.order.OrderHistoryRequest;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * pos销售订单子表 Mapper 接口
 * </p>
 *
 * @author William
 * @since 2019-10-18
 */
@Mapper
public interface PosOrderItemMapper extends BaseMapper<PosOrderItemPo> {

    /**
     * 批量插入订单明细
     *
     * @param list
     * @return
     */
    public Integer batchInsert(@Param("list") List<PosOrderItemPo> list);

    /**
     * 批量更新
     *
     * @param posOrderItemPoList
     * @return
     */
    Integer batchUpdate(@Param("list") List<PosOrderItemPo> posOrderItemPoList);

    /**
     * 查询销售记录
     *
     * @param page
     * @return
     */
    IPage<PosOrderItemPo> selectOrderItemPage(Page<PosOrderItemPo> page,
                                              @Param("request") OrderHistoryRequest request);

}
