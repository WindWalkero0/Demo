package com.ruihe.app.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.Region;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description 区域Mapper
 * @author 梁远
 * @create 2019-10-18 10:33
 */
@Mapper
public interface RegionalManageMapper extends BaseMapper<Region> {
}
