package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.warehouse.*;
import com.ruihe.common.pojo.response.basic.CounterSortVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * 门店库存表 Mapper 接口
 * </p>
 *
 * @author William
 * @since 2019-10-24
 */
@Mapper
public interface WhStockMapper extends BaseMapper<WhStockPo> {

    Integer batchUpdate(@Param("list") List<WhStockPo> list);

    Integer batchInsert(@Param("list") List<WhStockPo> list);

    /**
     * 库存报表->按产品分类统计
     *
     * @param
     * @return
     */
    List<WhStockPrdCatReportPo> prdCatReport(@Param("counterId") String counterId,
                                             @Param("bigCatCode") String bigCatCode,
                                             @Param("mediumCatCode") String mediumCatCode,
                                             @Param("smallCatCode") String smallCatCode);

    /**
     * 库存报表打印，根据分类、柜台查询条件
     *
     * @param counterId     柜台ID
     * @param bigCatCode    大类编号
     * @param mediumCatCode 中类编号
     * @param smallCatCode  小类编号
     * @return
     */
    List<WhStockPo> listStockOfCategory(@Param("counterId") String counterId,
                                        @Param("bigCatCode") String bigCatCode,
                                        @Param("mediumCatCode") String mediumCatCode,
                                        @Param("smallCatCode") String smallCatCode);

    /**
     * 库存报表打印，根据系列、柜台查询条件
     *
     * @param counterId 柜台编号
     * @param seriesCode 系列编号
     * @return
     */
    List<WhStockPo> listStockOfSeries(@Param("counterId") String counterId, 
                                      @Param("seriesCode") String seriesCode);
    
    /**
     * 库存报表->按产品系列详情
     *
     * @param counterId
     * @param seriesCode
     * @return java.util.List<com.ruihe.common.dao.bean.warehouse.WhStockPo>
     * @author qubin
     * @date 2021/5/15 17:53
     */
    List<WhStockPo> selectPrdSeriesList(@Param("counterId") String counterId,
                                        @Param("seriesCode") String seriesCode);

    /**
     * 库存报表->按产品系列统计
     *
     * @param
     * @return
     */
    List<WhStockPrdSeriesReportPo> prdSeriesReport(@Param("counterId") String counterId,
                                                   @Param("seriesCode") String seriesCode);

    /**
     * 查询库存分类总览
     *
     * @param counterId
     * @param bigCatCode
     * @return
     */
    List<WhStockPrdCatReportPo> prdCatReport1(@Param("counterId") String counterId,
                                              @Param("bigCatCode") String bigCatCode);

    /**
     * 所有商品库存报表统计数量(合计)
     */
    WhStockSubtotalPo sumCounterAllStock(@Param("counterId") String counterId);

    /**
     * 商品小类库存报表统计数量(合计)
     */
    WhStockSubtotalPo sumCounterSmallCatStock(@Param("counterId") String counterId,
                                              @Param("bigCatCode") String bigCatCode,
                                              @Param("mediumCatCode") String mediumCatCode,
                                              @Param("smallCatCode") String smallCatCode);


    /**
     * 根据产品价格查询商品
     */
    List<WhStockPo> selectMoney(@Param("money") BigDecimal money, @Param("counterId") String counterId,
                                @Param("includeDisabledProduct") boolean includeDisabledProduct);

    /**
     * 2020年5月4日11:27:15
     * 根据商品修改更改库存的对应商品
     */
    Integer updateProduct(@Param("product") Product product);

    /**
     * 根据商品条码查询商品信息
     *
     * @param barCode
     * @param counterId
     * @return
     */
    List<WhStockPo> selectStockProduct(@Param("barCode") String barCode, @Param("counterId") String counterId,
                                       @Param("bigCatCode") String bigCatCode,
                                       @Param("mediumCatCode") String mediumCatCode,
                                       @Param("smallCatCode") String smallCatCode,
                                       @Param("includeDisabledProduct") boolean includeDisabledProduct,
                                       @Param("seriesCode") String seriesCode);

    @Ella(Describe = "根据价格查询商品信息", Author = "K")
    List<Product> selectMoneyProduct(@Param("money") BigDecimal money,
                                     @Param("includeDisabledProduct") boolean includeDisabledProduct);

    @Ella(Describe = "根据条码查询商品信息", Author = "K")
    List<Product> selectBarProduct(@Param("barCode") String barCode,
                                   @Param("includeDisabledProduct") boolean includeDisabledProduct,
                                   @Param("bigCatCode") String bigCatCode,
                                   @Param("mediumCatCode") String mediumCatCode,
                                   @Param("smallCatCode") String smallCatCode,
                                   @Param("seriesCode") String seriesCode);

    /**
     * 根据柜台查询分类及分类下产品数量
     *
     * @param counterId
     * @return
     */
    List<CounterSortVo> selectCounterSort(@Param("counterId") String counterId);

    /**
     * 根据柜台查询其库存信息并按照 大中小条码排序
     *
     * @param counterId
     * @return
     */
    List<WhStockPo> selectDownStock(@Param("counterId") String counterId);

    /**
     * 查询柜台库存，根据库存排倒叙
     *
     * @param goodsBarCode
     * @param orgOfficeId
     * @return java.util.List<com.ruihe.common.dao.bean.warehouse.WhCounterStockPo>
     * @author qubin
     * @date 2021/5/31 10:10
     */
    List<WhCounterStockPo> selectCountStock(@Param("goodsBarCode") String goodsBarCode,
                                            @Param("orgOfficeId") String orgOfficeId,
                                            @Param("counterId") String counterId);
}
