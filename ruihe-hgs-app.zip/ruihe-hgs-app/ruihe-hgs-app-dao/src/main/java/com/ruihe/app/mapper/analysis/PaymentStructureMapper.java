package com.ruihe.app.mapper.analysis;

import com.ruihe.app.po.analysis.PosPaymentStructurePo;
import com.ruihe.common.pojo.request.order.PaymentStructureRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 支付构成报表 -->支付方式与销售额
 *
 * @author:Fangtao
 * @Date:2019/10/30 19:17
 */
@Mapper
public interface PaymentStructureMapper {
    /**
     * 支付方式与销售额
     *
     * @param request
     * @return
     */
    List<PosPaymentStructurePo> queryAmtAndPayChannel(@Param("request") PaymentStructureRequest request);

}
