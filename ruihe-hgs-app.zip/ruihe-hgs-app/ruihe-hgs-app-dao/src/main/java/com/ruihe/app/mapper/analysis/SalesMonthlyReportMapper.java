package com.ruihe.app.mapper.analysis;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.analysis.*;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.pojo.request.analysis.MonthlyReportRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 销售月报表
 *
 * @author:Fangtao
 * @Date:2019/11/4 17:48
 */
@Mapper
public interface SalesMonthlyReportMapper extends BaseMapper<PosOrderPo> {
    /**
     * 销售月报表
     */
    List<PosSalesMonthlyReportPo> queryMonthReport(@Param("counterId") String counterId, @Param("startTime") LocalDate startTime, @Param("endTime") LocalDate endTime);

    /**
     * 计算销售明细报表
     */
    List<PosSalesMonthlyPo> querySummary(@Param("counterId") String counterId,
                                         @Param("createTime") LocalDateTime createTime);

    /**
     * 销售月报表->销售明细报表->条件搜索汇总
     */
    PosMonthlyReportConditionPo queryDetails(@Param("request") MonthlyReportRequest request, @Param("endTime") LocalDate endTime);

    /**
     * 销售月报表->销售明细报表->条件搜索下半部分
     */
    List<PosDetailReportConditionPo> queryDetailsReport(@Param("request") MonthlyReportRequest request, @Param("endTime") LocalDate endTime);

    /**
     * 销售月报表->销售明细报表->销售明细
     */
    List<PosSalesDetailsPo> querySaleDetail(@Param("orderNo") String orderNo);

    List<PosDetailReportConditionPo> queryType(@Param("request") MonthlyReportRequest request, @Param("endTime") LocalDate endTime);
}


