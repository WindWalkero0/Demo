package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhFreeInventoryPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-22 15:18
 */
@Mapper
public interface WhFreeInventoryMapper extends BaseMapper<WhFreeInventoryPo> {
}
