package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/26 13:57
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosMemberSaleDetailPo implements Serializable {
    /**
     * 12个月内购买总数
     */
    private Integer qty;
    /**
     * 12个月内购买金额
     */
    private BigDecimal amt;
}
