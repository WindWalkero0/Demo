package com.ruihe.app.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PromotionCouponVo {

    /**
     * 发券活动id
     */
    private String proCouponId;

    /**
     * 活动名称
     */
    private String couponName;

    /**
     * 活动开始日期
     */
    private LocalDateTime startTime;

    /**
     * 活动结束日期
     */
    private LocalDateTime stopTime;

    /**
     * 检验方式  0无校验  1coupon校验
     */
    private Integer checkType;

    /**
     * 优惠券有效类型  0指定时间  1相对时间
     */
    private Integer useType;

    /**
     * 相对时间--第多少天开始
     */
    private Long startDay;

    /**
     * 相对时间--多少天内有效
     */
    private Long effectiveDay;

    /**
     * 优惠券有效期开始时间
     */
    private LocalDateTime couponStartTime;

    /**
     * 优惠券有效期结束时间
     */
    private LocalDateTime couponStopTime;

    /**
     * 优惠券发放方式  0事件触发 1其他
     */
    private Integer sendMethod;

    /**
     * 优惠券发放类型  0购买 1其他
     */
    private Integer sendType;

    /**
     * 最大匹配次数数量
     */
    public Integer couponCount;

    /**
     * 活动描述
     */
    private String couponDescribe;

    /**
     * 活动地点类型
     */
    public Integer activityPlaceType;

    /**
     * 活动对象类型
     */
    public Integer activityObjectType;

    /**
     * 购买条件类型
     */
    public Integer buyConditionType;

    /**
     * 已参加优惠的订单不在发券?  0否  1是
     */
    private Integer checkDiscount;

    /**
     * 奖励方式 0礼品抵用券  1金额抵用券
     */
    private Integer rewardType;

    /**
     * 抵扣金额
     */
    private BigDecimal deductionMoney;

    /**
     * 领用需要金额
     */
    private BigDecimal needMoney;

    /**
     * 产品使用范围 0无限制  1限定产品
     */
    private Integer proRange;

    /**
     * 状态 0已审核  1新建(默认)  2停用(手动停用或者到期失效)
     */
    private Integer status;

    /**
     * 是否生效 0不生效(默认不生效)  1生效(审核过后为生效)
     */
    private Integer effective;

    /**
     * 是否生效 0已删除  1未删除
     */
    private Integer isDel;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 修改时间
     */
    private LocalDateTime updateTime;

    /**
     * 创建人名称
     */
    private String createAuthor;

    /**
     * 创建人账号
     */
    private String account;

    /**
     * 排序
     */
    private Integer sort;

    /**
     * 回显字段
     */
    private String memberSelectString;

    private String memberSelectOrigin;

    /**
     * 匹配到了几次
     */
    private Integer count;
}
