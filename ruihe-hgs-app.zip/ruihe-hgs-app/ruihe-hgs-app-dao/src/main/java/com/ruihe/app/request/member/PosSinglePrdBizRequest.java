package com.ruihe.app.request.member;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author Fangtao
 * @date 2020/1/20 9:23
 */
@ApiModel(description = "接收类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosSinglePrdBizRequest implements Serializable {

    @NotBlank(message = "柜台编码不能为空")
    private String counterId;

    @NotBlank(message = "商品编码不能为空")
    private String prdBarCode;

    private LocalDate startTime;

    private LocalDate endTime;

    @NotNull(message = "页码不能为空")
    private Integer pageNumber;

    @NotNull(message = "页数不能为空")
    private Integer pageSize;
}
