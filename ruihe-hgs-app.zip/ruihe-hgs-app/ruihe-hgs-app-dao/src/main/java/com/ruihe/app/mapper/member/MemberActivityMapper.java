package com.ruihe.app.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.crm.MemberInfoMessagePo;
import com.ruihe.app.request.member.MemberActivityCouponRequest;
import com.ruihe.app.request.member.MemberActivityRedeemRequest;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.member.MemberActivity;
import com.ruihe.common.dao.bean.member.MemberCoupon;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Ella(Describe = "会员活动", Author = "K")
@Mapper
public interface MemberActivityMapper extends BaseMapper<MemberActivity> {

    List<MemberCoupon> selectMemberCoupons(@Param("request") MemberActivityRedeemRequest request);

    @Ella(Describe = "查询正在进行中且有效的活动")
    List<MemberActivity> selectMemberActivityByTime(@Param("request") MemberActivityCouponRequest request);

    Long countActivityByTime(@Param("request") MemberActivityCouponRequest request);

    /**
     * 查询会员信息
     */
    MemberInfoMessagePo queryMemberMessage(@Param("memberId") String memberId);

    /**
     * 计算累计消费金额
     */
    MemberInfoMessagePo queryAmt(@Param("memberId") String memberId);


    MemberInfoMessagePo queryLastAmt(@Param("memberId") String memberId);

    /**
     * 获取新老积分规则
     *
     * @param orderNo
     * @return
     */
    Integer queryIntegralType(@Param("orderNo") String orderNo);

    /**
     * 获取新老积分规则
     *
     * @param activityIds
     * @return
     */
    Integer getActivityTypeRule(@Param("activityIds") List<String> activityIds);
}
