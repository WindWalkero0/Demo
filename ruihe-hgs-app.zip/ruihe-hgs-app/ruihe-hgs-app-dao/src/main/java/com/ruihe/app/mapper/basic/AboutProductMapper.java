package com.ruihe.app.mapper.basic;

import com.ruihe.common.dao.bean.base.Product;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AboutProductMapper {


    List<Product> selectProductItem(@Param("prdBarCode") String prdBarCode);
}
