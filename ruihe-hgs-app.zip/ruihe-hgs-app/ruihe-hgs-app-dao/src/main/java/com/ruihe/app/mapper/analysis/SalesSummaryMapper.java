package com.ruihe.app.mapper.analysis;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.analysis.PosSaleDetailReportPo;
import com.ruihe.app.po.analysis.PosSalesSummaryPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.pojo.request.analysis.SaleDetailRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.util.List;

/**
 * @author:Fangtao
 * @Date:2019/10/30 14:29
 */
@Mapper
public interface SalesSummaryMapper extends BaseMapper<PosOrderPo> {
    /**
     * 查询柜台下的所有柜员/销售单数或者是退货单数/总销售额
     *
     * @param counterId
     * @param startTime
     * @param endTime
     * @return
     */
    List<PosSalesSummaryPo> querySaleSummary(@Param("counterId") String counterId,
                                             @Param("startTime") LocalDate startTime,
                                             @Param("endTime") LocalDate endTime,
                                             @Param("baCode") String baCode);


    /**
     * 计算提货退货数量
     *
     * @param counterId
     * @param startTime
     * @param endTime
     * @return
     */
    PosSalesSummaryPo queryTakeReturnGoodsQty(@Param("counterId") String counterId,
                                              @Param("startTime") LocalDate startTime,
                                              @Param("endTime") LocalDate endTime,
                                              @Param("baCode") String baCode);

    /**
     * 计算提货退货数量
     *
     * @param counterId
     * @param startTime
     * @param endTime
     * @return
     */
    List<PosSalesSummaryPo> queryTakeReturnGoodsQtyByFly(@Param("counterId") String counterId,
                                              @Param("startTime") LocalDate startTime,
                                              @Param("endTime") LocalDate endTime,
                                              @Param("baCode") String baCode);
    /**
     * 统计门店一段时间内的销售订单数
     *
     * @param counterId
     * @param startTime
     * @param endTime
     * @return
     */
    Integer salesOrderCount(@Param("counterId") String counterId,
                            @Param("startTime") LocalDate startTime,
                            @Param("endTime") LocalDate endTime,
                            @Param("baCode") String baCode);

    /**
     * 统计门店一段时间内所有Ba的销售订单数
     *
     * @param counterId
     * @param startTime
     * @param endTime
     * @return
     */
    Integer calculationSalesOrderCount(@Param("counterId") String counterId,
                                       @Param("startTime") LocalDate startTime,
                                       @Param("endTime") LocalDate endTime);

    /**
     * 统计门店一段时间内的退货订单数
     *
     * @param counterId
     * @param startTime
     * @param endTime
     * @return
     */
    Integer returnOrderCount(@Param("counterId") String counterId,
                             @Param("startTime") LocalDate startTime,
                             @Param("endTime") LocalDate endTime,
                             @Param("baCode") String baCode);

    /**
     * 统计门店一段时间内所有Ba的退货订单数
     *
     * @param counterId
     * @param startTime
     * @param endTime
     * @return
     */
    Integer calculationReturnOrderCount(@Param("counterId") String counterId,
                                        @Param("startTime") LocalDate startTime,
                                        @Param("endTime") LocalDate endTime);

    /**
     * 累计“护肤品”大类销售产品数量
     *
     * @param counterId
     * @param startTime
     * @param endTime
     * @param baCode
     * @return
     */
    Integer querySalesPrdQty(@Param("counterId") String counterId,
                             @Param("startTime") LocalDate startTime,
                             @Param("endTime") LocalDate endTime,
                             @Param("baCode") String baCode);

    /**
     * 总的累计“护肤品”大类销售产品数量
     *
     * @param counterId
     * @param startTime
     * @param endTime
     * @return
     */
    Integer calculationSalesPrdQty(@Param("counterId") String counterId,
                                   @Param("startTime") LocalDate startTime,
                                   @Param("endTime") LocalDate endTime);

    /**
     * 累计“护肤品”大类实物退货产品数量
     */
    Integer queryReturnPrdQty(@Param("counterId") String counterId,
                              @Param("startTime") LocalDate startTime,
                              @Param("endTime") LocalDate endTime,
                              @Param("baCode") String baCode);

    /**
     * 总的累计“护肤品”大类实物退货产品数量
     */
    Integer calculationReturnPrdQty(@Param("counterId") String counterId,
                                    @Param("startTime") LocalDate startTime,
                                    @Param("endTime") LocalDate endTime);


    /**
     * 销售明细报表->销售小结->按条件计算数量与销售额
     */
    PosSaleDetailReportPo sumCounterAllStock(@Param("request") SaleDetailRequest request);

    /**
     * 计算预订单退货数和预订单退货金额
     *
     * @return
     */
    PosSalesSummaryPo calculationReturnQtyAndAmt(@Param("counterId") String counterId,
                                                 @Param("startTime") LocalDate startTime,
                                                 @Param("endTime") LocalDate endTime,
                                                 @Param("baCode") String baCode);

    Long count(@Param("counterId") String counterId,
               @Param("startTime") LocalDate startTime,
               @Param("endTime") LocalDate endTime,
               @Param("baCode") String baCode);
}
