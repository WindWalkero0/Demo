package com.ruihe.app.mapper.promotion;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.promotion.PromotionActivity;
import com.ruihe.common.dao.bean.promotion.PromotionCoupon;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PromotionMapper extends BaseMapper<PromotionActivity> {

    /**
     * 查询生效的发券活动
     *
     * @return
     */
    List<PromotionCoupon> selectPromotions();
}
