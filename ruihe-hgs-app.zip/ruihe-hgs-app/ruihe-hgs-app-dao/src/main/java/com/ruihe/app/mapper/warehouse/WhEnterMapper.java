package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.app.po.warehouse.WhEnterQueryPo;
import com.ruihe.common.dao.bean.warehouse.WhEnterPo;
import com.ruihe.common.pojo.request.warehouse.WhEnterQueryRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 入库单主表方法
 *
 * @author:Fangtao
 * @Date:2019/10/24 11:11
 */
@Mapper
public interface WhEnterMapper extends BaseMapper<WhEnterPo> {
    /**
     * 入库单列表查询
     */
    List<WhEnterQueryPo> queryWhEnter(@Param("page") Page page, @Param("request") WhEnterQueryRequest request);

    /**
     * 查看入库单明细
     */
    WhEnterQueryPo queryWhEnterItem(@Param("enterNo") String enterNo);

    /**
     * 计算入库总金额
     */
    WhEnterQueryPo queryWhEnterAmt(@Param("enterNo") String enterNo);
}
