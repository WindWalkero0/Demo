package com.ruihe.app.request.member;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDate;

/**
 * @author luojie
 * @program ruihe-top
 * @description ba回访批量请求体
 * @create: 2021/7/15 15:54
 */
@ApiModel(value = "ba回访批量插入实体类", description = "ba回访批量插入实体类")
@Data
public class BaVisitBatchRequest {

    @ApiModelProperty("柜台编码")
    @NotBlank(message = "柜台编码不能为空")
    private String counterId;

    @ApiModelProperty("柜台名称")
    @NotBlank(message = "柜台名称不能为空")
    private String counterName;

    @ApiModelProperty("ba编码")
    @NotBlank(message = "ba编码不能为空")
    private String baCode;

    @ApiModelProperty("ba名称")
    @NotBlank(message = "ba名称不能为空")
    private String baName;

    @ApiModelProperty("顾客姓名")
    @Size(max = 20, message = "顾客姓名最长不可超过20")
    private String customerName;

    @ApiModelProperty("顾客手机号")
    @Size(max = 11, message = "手机号不可超过11位")
    private String customerPhone;

    @ApiModelProperty("操作类型id")
    @NotNull(message = "操作类型id不能为空")
    private Integer typeId;

    @ApiModelProperty("操作类型")
    @NotBlank(message = "操作类型不能为空")
    private String operationType;

    @ApiModelProperty("数量")
    @NotNull(message = "数量不能为空")
    private Integer operationQty;
    
    @ApiModelProperty("服务时间")
    @NotNull(message = "服务时间不可为空")
    private LocalDate serviceTime;
}
