package com.ruihe.app.mapper.plan;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.plan.SalesPlanPo;
import com.ruihe.common.pojo.response.plan.SalesPlanInfoSimpleResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author qubin
 * @date 2021/4/2 16:01
 */
@Mapper
public interface SalesPlanMapper extends BaseMapper<SalesPlanPo> {

    /**
     * 根据规划对象类型查询
     * @param bizIdList
     * @return
     */
    List<SalesPlanInfoSimpleResponse> selectByBizIdListAndPlanMemberType(@Param("list") List<String> bizIdList
            ,@Param("planMemberType") String planMemberType);

    /**
     * 根据业务唯一id查询
     *
     * @param bizId
     * @return
     */
    SalesPlanPo selectByBizId(@Param("bizId") String bizId);

    /**
     * 根据bizId获取规划记录
     *
     * @param ids
     * @return
     */
    List<SalesPlanPo> selectPlanRecord(List<String> ids);
}
