package com.ruihe.app.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.member.MemberLevelUpPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-14 11:05
 */
@Mapper
public interface MemberLevelUpMapper extends BaseMapper<MemberLevelUpPo> {
}
