package com.ruihe.app.po.analysis;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/26 14:15
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosMemberDataPo implements Serializable {
    @ApiModelProperty(value = "会员卡号")
    private String memberCardNumber;
    @ApiModelProperty(value = "会员姓名")
    private String memberName;
    @ApiModelProperty(value = "会员手机号")
    private String mobilePhone;
    @ApiModelProperty(value = "生日")
    private String birthday;
    @ApiModelProperty(value = "回访方式")
    private String returnWay;
    @ApiModelProperty(value = "当前等级")
    private String memberLevelName;
    @ApiModelProperty(value = "推荐会员id")
    private String rcmdMemberId;
    @ApiModelProperty(value = "推荐会员姓名")
    private String rcmdMemberName;
    @ApiModelProperty(value = "电话")
    private String telephone;
    @ApiModelProperty(value = "性别")
    private String sex;
    @ApiModelProperty(value = "省份")
    private String province;
    @ApiModelProperty(value = "邮箱")
    private String email;
    @ApiModelProperty(value = "地址")
    private String address;
    @ApiModelProperty(value = "职业")
    private String career;
    @ApiModelProperty(value = "注册时间")
    private String joinDate;
    @ApiModelProperty(value = "城市")
    private String city;
    @ApiModelProperty(value = "发卡柜台")
    private String counterName;
    @ApiModelProperty(value = "肤质")
    private String skinType;
    @ApiModelProperty(value = "收入")
    private String income;
    @ApiModelProperty(value = "可用积分")
    private Integer totalQty;
    @ApiModelProperty(value = "有效积分")
    private Integer avlQty;
    @ApiModelProperty(value = "即将失效积分")
    private Integer expiringQty;
    @ApiModelProperty(value = "累计失效积分")
    private Integer expiredQty;
    @ApiModelProperty(value = "累计兑换积分")
    private Integer exchQty;
    @ApiModelProperty(value = "即将过期时间")
    private LocalDateTime nextExpireTime;
}
