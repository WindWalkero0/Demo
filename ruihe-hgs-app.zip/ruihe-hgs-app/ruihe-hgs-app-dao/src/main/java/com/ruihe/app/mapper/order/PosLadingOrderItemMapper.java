package com.ruihe.app.mapper.order;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.order.PosLadingOrderItemPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ly
 * @since 2019-10-19
 */
@Mapper
public interface PosLadingOrderItemMapper extends BaseMapper<PosLadingOrderItemPo> {

    Integer batchInsert(@Param("list") List<PosLadingOrderItemPo> list);
}
