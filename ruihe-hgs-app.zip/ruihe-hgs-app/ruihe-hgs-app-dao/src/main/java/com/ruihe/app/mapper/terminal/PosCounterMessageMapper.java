package com.ruihe.app.mapper.terminal;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.fa.PosCounterMessagePo;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 柜台已读消息 Mapper 接口
 * </p>
 *
 * @author William
 * @since 2020-01-17
 */
@Mapper
public interface PosCounterMessageMapper extends BaseMapper<PosCounterMessagePo> {

}
