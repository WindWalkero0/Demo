package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 会员销售统计
 *
 * @author:Fangtao
 * @Date:2019/11/2 13:45
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosMemberSaleStatisticPo implements Serializable {
    /**
     * 会员号
     */
    private String memberPhone;
    /**
     * 会员姓名
     */
    private String memberName;
    /**
     * 商品数量
     */
    private Integer goodsQty;
    /**
     * 购买金额
     */
    private BigDecimal realAmt;

    private String memberId;

}
