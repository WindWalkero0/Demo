package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 会员详情页中的消费计算
 *
 * @author:Fangtao
 * @Date:2019/11/11 15:46
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosMemberDetailPo implements Serializable {

    /**
     * 订单数(查询时间段内正常销售单+预订单数)
     */
    private Integer orderQty;
    /**
     * 销售数量
     */
    private Integer salesQty;
    /**
     * 销售额
     */
    private BigDecimal salesAmt;
    /**
     * 退货数
     */
    private Integer returnQty;
    /**
     * 退货金额
     */
    private BigDecimal returnAmt;
}
