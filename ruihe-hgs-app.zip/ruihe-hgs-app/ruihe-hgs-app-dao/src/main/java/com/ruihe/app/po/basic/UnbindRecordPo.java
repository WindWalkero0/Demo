package com.ruihe.app.po.basic;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author huangjie
 * @date 2021年07月06日 16:12
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_unbind_record")
public class UnbindRecordPo implements Serializable {

    @ApiModelProperty("主键")
    @TableId(value = "Id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty("字符串柜台id")
    private String counterId;

    @ApiModelProperty("柜台名称")
    private String counterName;

    @ApiModelProperty("操作美导id")
    private String opeEmpId;

    @ApiModelProperty("操作美导姓名")
    private String opeEmpName;

    @ApiModelProperty("被解绑美导id")
    private String pasEmpId;

    @ApiModelProperty("被解绑美导姓名")
    private String pasEmpName;

    @ApiModelProperty("创建时间")
    private LocalDateTime createTime;
}
