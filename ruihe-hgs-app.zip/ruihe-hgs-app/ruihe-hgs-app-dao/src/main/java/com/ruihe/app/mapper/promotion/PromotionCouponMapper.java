package com.ruihe.app.mapper.promotion;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.promotion.PromotionCoupon;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PromotionCouponMapper extends BaseMapper<PromotionCoupon> {
}
