package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhU8StockOptItemPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * U8系统库存变动操作明细表 Mapper 接口
 * </p>
 *
 * @author William
 * @since 2019-10-24
 */
@Mapper
public interface WhU8StockOptItemMapper extends BaseMapper<WhU8StockOptItemPo> {

    Integer batchInsert(@Param("list") List<WhU8StockOptItemPo> list);
}
