package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 计算销售明细报表
 *
 * @author:Fangtao
 * @Date:2019/11/5 15:42
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosSalesMonthlyPo implements Serializable {
    /**
     * 商品数量
     */
    private Integer goodsQty;
    /**
     * 实付金额
     */
    private BigDecimal realAmt;
    /**
     * 业务类型
     */
    private Integer transType;
    /**
     * 时间
     */
    private LocalDateTime createTime;
    /**
     * 会员名称
     */
    private String memberName;
    /**
     * 小票号
     */
    private String receiptNo;
}
