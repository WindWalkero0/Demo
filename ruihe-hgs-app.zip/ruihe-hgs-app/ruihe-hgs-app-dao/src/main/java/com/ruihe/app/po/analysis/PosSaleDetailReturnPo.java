package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 销售明细单--退货类型
 *
 * @author:Fangtao
 * @Date:2019/11/1 17:35
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosSaleDetailReturnPo implements Serializable {
    /**
     * 产品条码
     */
    private String prdBarCode;
    /**
     * 促销活动分摊金额
     */
    private BigDecimal shareAmt;
    /**
     * 商品名称
     */
    private String prdName;
    /**
     * 付款方式
     */
    private String payChannel;
    /**
     * 退货人名称
     */
    private String memberName;
    /**
     * 关联退货单号
     */
    private String preOrderNo;

    private String orderNo;
    /**
     * 每件商品件数
     */
    private Integer purQty;
    /**
     * 每件商品售价
     */
    private BigDecimal salePrice;
    /**
     * 订单中商品总件数
     */
    private Integer qty;
    /**
     * 订单中商品相加的总金额
     */
    private BigDecimal amt;

    /*****************************关联单号*******************************/
    /**
     * 时间
     */
    private LocalDateTime createTime;
    /**
     * 数量
     */
    private Integer goodsQty;
    /**
     * 金额
     */
    private BigDecimal realAmt;

    private BigDecimal payAmt;

}
