package com.ruihe.app.mapper.order;


import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.promotion.PromotionActivity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface SalesOrderMapper {

    @Ella(Describe = "补录查询活动信息", Author = "K")
    List<PromotionActivity> selectPromotions(@Param("time") String time);
}
