package com.ruihe.app.po.fa;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 柜台已读消息
 * </p>
 *
 * @author William
 * @since 2020-01-17
 */
@Data
@Builder
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("t_pos_counter_message")
public class PosCounterMessagePo implements Serializable {

    /**
     * 柜台id
     */
    private String counterId;

    /**
     * 消息id
     */
    private Integer posMsgId;

    /**
     * 已读时间
     */
    private LocalDateTime createTime;

    /**
     * 已读时间
     */
    private LocalDateTime msgCreateTime;
}
