package com.ruihe.app.mapper.order;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.order.PosLadingOrderPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  提货单Mapper 接口
 * </p>
 *
 * @author ly
 * @since 2019-10-19
 */
@Mapper
public interface PosLadingOrderMapper extends BaseMapper<PosLadingOrderPo> {
}
