package com.ruihe.app.request.member;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@ApiModel(value = "MemberVisitReq", description = "会员回访请求实体类")
public class MemberVisitReq implements Serializable {

    public final static List<String> dateRangesList = new ArrayList<>(
            Arrays.asList(
                    "Customize",
                    "Today",
                    "ThisWeek",
                    "ThisMonth",
                    "Recent3Week",
                    "Recent3Month",
                    "Recent3Day",
                    "Recent7Day",
                    "Recent28Day",
                    "Recent56Day"));

    @ApiModelProperty(value = "请求时间范围")
    @NotBlank(message = "请求时间范围不能为空")
    public String dateRange;

    @ApiModelProperty(value = "自定义开始时间")
    public LocalDate beginDate;

    @ApiModelProperty(value = "自定义结束时间")
    public LocalDate endDate;

    @ApiModelProperty(value = "当前页码")
    @Min(value = 1, message = "当前页码不能小于1")
    public Integer pageNumber = 1;

    @ApiModelProperty(value = "每页记录数")
    public Integer pageSize = 20;

    public DateRanges dateRanges;


}

@ApiModel(description = "请求时间范围枚举,不需要传该值,dateRange值要在该集合中存在")
class DateRanges {
    @ApiModelProperty(value = "自定义时间")
    public String Customize;
    @ApiModelProperty(value = "今天")
    public String Today;
    @ApiModelProperty(value = "这个星期")
    public String ThisWeek;
    @ApiModelProperty(value = "这个月")
    public String ThisMonth;
    @ApiModelProperty(value = "最近7天")
    public String Recent7Day;
    @ApiModelProperty(value = "最近28天")
    public String Recent28Day;
    @ApiModelProperty(value = "最近56天")
    public String Recent56Day;
    @ApiModelProperty(value = "最近3天")
    public String Recent3Day;
    @ApiModelProperty(value = "最近3周")
    public String Recent3Week;
    @ApiModelProperty(value = "最近3月")
    public String Recent3Month;
}