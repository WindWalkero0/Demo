package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhEnterItemPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 入库单子表方法
 * @author:Fangtao
 * @Date:2019/10/24 11:09
 */
@Mapper
public interface WhEnterItemMapper extends BaseMapper<WhEnterItemPo> {

    /**
     * 批量插入订单明细
     *
     * @param list
     * @return
     */
    Integer batchInsert(@Param("list") List<WhEnterItemPo> list);

    /**
     * 批量修改订单明细
     */
    Integer batchUpdate(@Param("list") List<WhEnterItemPo> list);

}
