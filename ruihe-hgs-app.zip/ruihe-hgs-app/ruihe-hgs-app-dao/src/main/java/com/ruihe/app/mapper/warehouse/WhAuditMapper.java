package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhAuditPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 梁远
 * @Description
 * @create 2020-03-02 16:35
 */
@Mapper
public interface WhAuditMapper extends BaseMapper<WhAuditPo> {
}
