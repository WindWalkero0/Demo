package com.ruihe.app.request.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author 梁远
 * @Description
 * @create 2019-12-04 9:27
 */
@ApiModel(value = "BuyHistoryRequest", description = "查询会员历史购买记录，以订单维度展示请求实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BuyHistoryRequest implements Serializable {

    @NotBlank(message = "会员id不能为空")
    @ApiModelProperty(value = "会员id----必填")
    private String memberId;

    @ApiModelProperty(value = "开始时间")
    private LocalDate startTime;

    @ApiModelProperty(value = "结束时间")
    private LocalDate endTime;

    @ApiModelProperty(value = "BA代码---删除")
    private String baCode;

    @ApiModelProperty(value = "柜台id----删除")
    private String counterId;

    @ApiModelProperty(value = "小票号码")
    private String receiptNo;

    @ApiModelProperty(value = "交易类型，1销售,-1退货")
    private Integer transType;

    @ApiModelProperty(value = "活动类型 0兑换活动  1优惠券  2促销活动  3 不参加活动")
    private Integer activityType;

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;

}
