package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 支付构成报表 -->支付方式与销售额
 * @author:Fangtao
 * @Date:2019/10/30 19:18
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosPaymentStructurePo implements Serializable {
    /**
     * 支付方式
     */
    private String payChannel;
    /**
     * 每种支付方式对应的销售额
     */
    private BigDecimal salesVolume;
    /**
     * 交易笔数
     */
    private Integer transactionNo;
    /**
     * 实收总金额
     */
    private BigDecimal transactionAmt;
    /**
     * 销售笔数
     */
    private Integer saleNo;
    /**
     * 退货笔数
     */
    private Integer returnNo;
    /**
     * 每种支付方式对应的退货金额额
     */
    private BigDecimal returnVolume;
}
