package com.ruihe.app.po.fa;

import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 消息
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_pos_message")
public class PosMessagePo implements Serializable {
    /**
     * 主键id
     **/
    @TableId(type = IdType.AUTO)
    private Integer msgId;
    /**
     * 消息标题
     **/
    private String title;
    /**
     * 正文
     **/
    private String content;
    /**
     * 定时发送时间
     **/
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime sendTime;

    /**
     * 结束时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endTime;

    /**
     * 发送状态,0待发送/1已取消/2已发送/3已删除
     **/
    private Integer status;

    /**
     * 最后修改用户ID
     */
    private String lastModifyUserId;

    /**
     * 最后修改用户Name
     */
    private String lastModifyUserName;

    /**
     * 消息排序
     */
    private Integer seq;

    /**
     * 可以查看的柜台
     */
    private JSONArray placeInfo;

    /**
     * 创建时间
     **/
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
    /**
     * 最近更新时间
     **/
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;
}
