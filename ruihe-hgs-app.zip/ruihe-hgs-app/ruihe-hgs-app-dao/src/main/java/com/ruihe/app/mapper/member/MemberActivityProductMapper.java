package com.ruihe.app.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.member.MemberActivityProduct;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author fly
 * 2021年3月11日14:52:55
 */
@Mapper
public interface MemberActivityProductMapper extends BaseMapper<MemberActivityProduct> {

    /**
     * 获取包含列表
     *
     * @param activityIds
     * @return
     */
    List<MemberActivityProduct> selectMemberActivityRestrictsInProducts(@Param("activityIds") List<String> activityIds);

    /**
     * 获取排除列表
     *
     * @param activityIds
     * @return
     */
    List<MemberActivityProduct> selectMemberActivityRestrictsOutProducts(@Param("activityIds") List<String> activityIds);
}
