package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.analysis.WhTransferStockPo;
import com.ruihe.common.dao.bean.warehouse.WhTransferItemPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 查询子表方法
 */
@Mapper
public interface WhTransferItemMapper extends BaseMapper<WhTransferItemPo> {

    /**
     * 批量插入订单明细
     *
     * @param list
     * @return
     */
    Integer batchInsert(@Param("list") List<WhTransferItemPo> list);

    List<WhTransferStockPo> query(@Param("counterId") String counterId,
                                  @Param("prdBarCode") String prdBarCode,
                                  @Param("transferOrderNo") String transferOrderNo);

}
