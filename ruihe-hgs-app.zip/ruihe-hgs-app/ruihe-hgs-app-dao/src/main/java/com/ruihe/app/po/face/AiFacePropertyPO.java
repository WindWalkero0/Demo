package com.ruihe.app.po.face;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_ai_face_Property")
public class AiFacePropertyPO {

    @TableId(value = "id", type = IdType.NONE)
    private String id;
    /**
     * 属性名
     */
    private String property;
    /**
     * 属性中文名
     */
    private String propertyChinese;
    /**
     * 属性层级
     */
    private Integer propertyLevel;
    /**
     * 属性编码
     */
    private BigDecimal propertyCode;
    /**
     * 值枚举
     */
    private String propertyValueEnum;
}
