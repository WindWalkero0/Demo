package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 客单价,退货订单数
 * @Anthor:Fangtao
 * @Date:2020/3/2 10:05
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosReturnOrderCountPo implements Serializable {
    /**
     * 退货订单数
     */
    private Integer returnOrderQty;
}
