package com.ruihe.app.mapper.ding;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.bean.ding.DingConfig;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DingConfigMapper extends BaseMapper<DingConfig> {
    default DingConfig findByCropId(String cropId) {
        return selectOne(Wrappers.lambdaQuery(DingConfig.class).eq(DingConfig::getCorpId, cropId));
    }

    default DingConfig first() {
        var list = selectList(null);
        if (list.isEmpty()) return null;
        return list.get(0);
    }
}
