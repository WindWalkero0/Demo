package com.ruihe.app.po.analysis;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;


/**
 * 销售月报表->销售明细报表->汇总
 *
 * @Anthor:Fangtao
 * @Date:2020/1/10 11:01
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosMonthlyReportConditionPo implements Serializable {
    /**
     * 销售单数
     */
    private Integer saleOrderQty;
    /**
     *退货单数
     */
    private Integer returnOrderQty;
    /**
     * 积分兑换单数
     */
    private Integer integralExchangeOrderQty;
    /**
     *销售商品数量
     */
    private Integer salesQty;
    /**
     * 退货商品数量
     */
    private Integer returnQty;
    /**
     * 积分兑换商品数量
     */
    private Integer integralExchangeQty;
    /**
     * 销售业绩
     */
    private BigDecimal saleAmt;
    /**
     * 退货业绩
     */
    private BigDecimal returnAmt;
    /**
     * 积分兑换业绩
     */
    private BigDecimal integralExchangeAmt;
    /**
     *汇总数量
     */
    private Integer number;
    /**
     * 汇总业绩
     */
    private BigDecimal performance;
}
