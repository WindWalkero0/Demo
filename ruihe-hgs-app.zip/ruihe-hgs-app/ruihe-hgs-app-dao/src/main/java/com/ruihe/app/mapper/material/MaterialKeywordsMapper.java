package com.ruihe.app.mapper.material;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.material.MaterialKeywordsPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * 导购助手-资料关键词
 * @author qubin
 * @date 2021年07月05日 10:35
 */
@Mapper
public interface MaterialKeywordsMapper extends BaseMapper<MaterialKeywordsPo> {
}
