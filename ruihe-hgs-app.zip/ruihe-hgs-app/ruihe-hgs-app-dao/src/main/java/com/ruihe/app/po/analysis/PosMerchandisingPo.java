package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 分析->商品销售排行
 *
 * @author:Fangtao
 * @Date:2019/11/4 16:10
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosMerchandisingPo implements Serializable {
    /**
     * 商品条码
     */
    private String prdBarCode;
    /**
     * 商品条码
     */
    private String goodsBarCode;
    /**
     * 商品名称
     */
    private String prdName;
    /**
     * 商品数量
     */
    private Integer purQty;
    /**
     * 销售数量
     */
    private Integer salesQty;
    /**
     * 购买金额
     */
    private BigDecimal purchasingAmt;
    /**
     * 总销售数量
     */
    private Integer qty;
    /**
     * 总购买金额
     */
    private BigDecimal amt;

}
