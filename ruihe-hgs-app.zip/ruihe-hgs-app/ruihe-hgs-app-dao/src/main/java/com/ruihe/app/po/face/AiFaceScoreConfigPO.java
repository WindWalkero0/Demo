package com.ruihe.app.po.face;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_ai_face_score_config")
public class AiFaceScoreConfigPO {

    @TableId(value = "id", type = IdType.NONE)
    private String id;

    /**
     * 标签
     */
    private String label;
    /**
     * 联合属性名
     */
    private String property;
    /**
     * 联合属性值
     */
    private String propertyValue;
    /**
     * 联合属性值对应分数(分值扩大10倍)
     */
    private Integer propertyScore;
}
