package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhReturnLogPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-23 18:03
 */
@Mapper
public interface WhReturnLogMapper extends BaseMapper<WhReturnLogPo> {
}
