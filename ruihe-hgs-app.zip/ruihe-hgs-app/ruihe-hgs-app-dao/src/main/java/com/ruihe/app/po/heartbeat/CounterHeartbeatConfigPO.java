package com.ruihe.app.po.heartbeat;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 柜台心跳配置po
 * @author qubin
 * @date 2021/4/17 16:03
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_counter_heartbeat_config")
public class CounterHeartbeatConfigPO implements Serializable {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 柜台id
     */
    private String counterId;

    /**
     * 柜台名称
     */
    private String counterName;

    /**
     * 类型(common:通用|special:个性化)
     */
    private String type;

    /**
     * 开始时间，小时(按照hh:mm的格式)
     */
    private String startClock;

    /**
     * 结束时间，小时(按照hh:mm的格式)
     */
    private String finishClock;

    /**
     * 间隔秒数
     */
    private Integer intervalSeconds;

    /**
     * 超时次数
     */
    private Integer overtimeCount;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 修改时间
     */
    private LocalDateTime updateTime;
}
