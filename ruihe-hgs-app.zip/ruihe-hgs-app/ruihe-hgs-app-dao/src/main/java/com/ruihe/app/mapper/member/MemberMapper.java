package com.ruihe.app.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.member.MemberInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-14 11:31
 */
@Mapper
public interface MemberMapper extends BaseMapper<MemberInfo> {
    /**
     * 销售小结查询页面
     * 统计每个柜员招收新会员数量
     */
    List<Map<String, Object>> baNewMemberQty(@Param("counterId") String counterId,
                                             @Param("startTime") LocalDate startTime,
                                             @Param("endTime") LocalDate endTime);

    /**
     * POS首页查询新增会员数量
     *
     * @param counterId
     * @param startTime
     * @return
     */
    Integer newMemberQty(@Param("counterId") String counterId,
                         @Param("startTime") LocalDate startTime);

    /**
     * 获取会员等级到期的会员的id的list
     *
     * @param endTime
     * @return
     */
    List<String> selectMemberIdList(@Param("endTime") LocalDateTime endTime);

    /**
     * 微信入会更新会员信息（指定字段）
     *
     * @param memberInfo
     * @return
     */
    Integer updateMemberInfo(@Param("memberInfo") MemberInfo memberInfo);

    /**
     * 微信线上入会信息修改再次激活
     *
     * @param memberId
     * @return
     */
    Integer updateForMemberCard(@Param("memberId") String memberId);

    /**
     * 判断该会员是否是员工
     *
     * @param memberId
     * @return
     */
    boolean isEmp(@Param("memberId") String memberId);

    /**
     * 通过手机号码或姓名模糊查询会员
     *
     * @param phone,memberName
     * @return
     */
    List<MemberInfo> memberList(@Param("phone") String phone,
                                @Param("memberName") String memberName,
                                @Param("counterId") String counterId);
}
