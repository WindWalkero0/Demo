package com.ruihe.app.request.member;



import io.swagger.annotations.ApiModel;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@ApiModel(value = "优惠券查询接收类")
@Data
public class MemberActivityRedeemRequest {

    @NotNull(message = "会员id不能为空")
    public String memberId;

    @NotBlank(message = "柜台id不能为空")
    public String counterId;


    @NotBlank(message = "当前时间不能为空")
    public String nowTime;

    @NotNull(message = "当前页不能为空")
    public Integer pageNumber;

    @NotNull(message = "页码不能为空")
    public Integer pageSize;
}
