package com.ruihe.app.mapper.order;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.order.PosPaymentOrderPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 支付订单表 Mapper 接口
 * </p>
 *
 * @author William
 * @since 2019-10-19
 */
@Mapper
public interface PosPaymentOrderMapper extends BaseMapper<PosPaymentOrderPo> {

    /**
     * 批量插入支付订单
     *
     * @param list
     * @return
     */
    public Integer batchInsert(@Param("list") List<PosPaymentOrderPo> list);
}
