package com.ruihe.app.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.UserCounter;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @Anthor:Fangtao
 * @Date:2020/3/17 14:44
 */
@Mapper
public interface UserCounterMapper extends BaseMapper<UserCounter> {

    /**
     * pos端登录修改最近一次修改时间
     *
     * @param
     * @return
     */
    Integer updateLoginTime(@Param("userCounter") UserCounter userCounter);
}
