package com.ruihe.app.mapper.face;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.face.AiFaceScoreConfigPO;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AiFaceScoreConfigMapper extends BaseMapper<AiFaceScoreConfigPO> {
}
