package com.ruihe.app.request.member;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.List;

@ApiModel(value = "优惠券查询接收类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberCheckCouponRequest implements Serializable {

    @ApiModelProperty(value = "优惠券id")
    @NotBlank(message = "优惠券id未传递")
    public String couponId;

    @ApiModelProperty(value = "子活动id")
    public String activityId;

    @ApiModelProperty(value = "主活动id")
    public String subActivityId;

    @ApiModelProperty(value = "会员id")
    public String memberId;

    @ApiModelProperty(value = "柜台id")
    public String counterId;

    @ApiModelProperty("【交易类型是销售必填】所购商品列表")
    private List<OrderItemRequest> orderItemList;

    /**
     * 购买商品信息
     */
    @ApiModel(value = "OrderItemRequest", description = "销售-商品信息实体")
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OrderItemRequest implements Serializable {
        @ApiModelProperty("产品条码-对外标准")
        private String prdBarCode;

        @ApiModelProperty("商品条码-私有编码")
        private String goodsBarCode;

        @ApiModelProperty("购买数量")
        private Integer purQty;
    }


}
