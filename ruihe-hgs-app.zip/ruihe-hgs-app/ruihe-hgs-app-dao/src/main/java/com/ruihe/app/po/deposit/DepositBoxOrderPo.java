package com.ruihe.app.po.deposit;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * <p>
 * 寄存箱存取记录主表
 * </p>
 *
 * @author ly
 * @since 2019-10-12
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_deposit_box_order")
public class DepositBoxOrderPo implements Serializable {

    /**
     * 寄存箱存取记录id
     */
    @TableId(value = "order_id", type = IdType.NONE)
    private String orderId;

    /**
     * 寄存箱id
     */
    private Integer boxId;

    /**
     * 寄存箱编号
     */
    private String boxNo;

    /**
     * 柜台编号
     */
    private String counterId;

    /**
     * 柜台名称
     */
    private String counterName;

    /**
     * 会员id
     */
    private String memberId;

    /**
     * 会员手机号
     */
    private String memberPhone;

    /**
     * 会员名称
     */
    private String memberName;

    /**
     * 存/取数量
     */
    private Integer prdCount;

    /**
     * 存/取金额
     */
    private BigDecimal amount;

    /**
     * 操作用户的id
     */
    private String userId;

    /**
     * 操作员工
     */
    private String userName;

    /**
     * 0存1取
     */
    private Integer optType;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 修改时间
     */
    private LocalDateTime updateTime;

}
