package com.ruihe.app.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
/**
 * @author huangjie
 * @Description
 * @create 2021-05-13
 */
@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class MemberConsumeVo {
    /**
     * 会员ID
     */
    private String memberId;

    /**
     * 会员手机号
     */
    private String mobile;

    /**
     * 会员姓名
     */
    private String name;

    /**
     * 会员等级
     */
    private int memberLevel;

    /**
     * 上次消费时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime lastBuyTime;

    /**
     * 上次护理时间
     */
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime lastNursingTime;

    /**
     * 美导名称
     */
    private String baName;
}
