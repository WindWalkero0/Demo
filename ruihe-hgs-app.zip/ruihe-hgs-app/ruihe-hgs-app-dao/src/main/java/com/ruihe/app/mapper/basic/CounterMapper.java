package com.ruihe.app.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.basic.PosCounterPo;
import com.ruihe.app.request.counter.CounterLocationQueryRequest;
import com.ruihe.app.response.CounterLocationInfoVo;
import com.ruihe.common.dao.bean.base.CounterInformation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 柜台信息mapper
 *
 * @author William
 */
@Mapper
public interface CounterMapper extends BaseMapper<CounterInformation> {
    /**
     * 根据柜台名称模糊查询柜台
     */
    List<PosCounterPo> queryAll(@Param("counterName") String counterName);

    /**
     * 根据柜台名称、地址和省市区进行查询
     *
     * @param request
     * @return
     */
    List<CounterLocationInfoVo> queryCounterLocation(@Param("request") CounterLocationQueryRequest request);
}
