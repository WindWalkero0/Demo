package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * 销售月报表
 *
 * @author:Fangtao
 * @Date:2019/11/4 17:52
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosSalesMonthlyReportPo implements Serializable {
    /**
     * 销售数量
     */
    private Integer goodsQty;
    /**
     * 销售金额
     */
    private BigDecimal realAmt;
    /**
     * 日期
     */
    private LocalDate date;

    /**
     * 销售数量
     */
    private Integer salesQty;
    /**
     * 销售额
     */
    private BigDecimal salesAmt;
    /**
     * 退货数
     */
    private Integer returnQty;
    /**
     * 退货金额
     */
    private BigDecimal returnAmt;

}
