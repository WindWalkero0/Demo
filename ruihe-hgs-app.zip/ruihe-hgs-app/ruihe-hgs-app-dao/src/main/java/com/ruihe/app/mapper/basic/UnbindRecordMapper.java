package com.ruihe.app.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.basic.UnbindRecordPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Anthor:huangjie
 * @Date:2021/07/06
 */
@Mapper
public interface UnbindRecordMapper extends BaseMapper<UnbindRecordPo> {
}
