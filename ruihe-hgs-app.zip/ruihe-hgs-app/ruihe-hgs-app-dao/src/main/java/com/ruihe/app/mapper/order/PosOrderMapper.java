package com.ruihe.app.mapper.order;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.app.po.analysis.PosPaymentStructurePo;
import com.ruihe.app.request.order.BuyHistoryRequest;
import com.ruihe.app.request.order.OrderHistoryRequest;
import com.ruihe.app.request.order.PosRsvOrderQueryRequest;
import com.ruihe.common.dao.bean.member.MemberLevelLog;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.pojo.request.order.PaymentStructureRequest;
import com.ruihe.common.pojo.response.homepage.AmtAndQty;
import com.ruihe.common.pojo.response.homepage.MemberIdAndTotalAmt;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * pos终端销售订单表 Mapper 接口
 * </p>
 *
 * @author William
 * @since 2019-10-18
 */
@Mapper
public interface PosOrderMapper extends BaseMapper<PosOrderPo> {
    List<String> selectOrderHistory(@Param("request") OrderHistoryRequest request);

    List<Map<Integer, Object>> sales(@Param("counterId") String counterId, @Param("startTime") LocalDate startTime, @Param("endTime") LocalDate plusDays);

    /**
     * 支付报表->统计销售笔数
     */
    PosPaymentStructurePo saleTotal(@Param("request") PaymentStructureRequest request);

    /**
     * 支付报表->统计退货笔数
     */
    PosPaymentStructurePo returnTotal(@Param("request") PaymentStructureRequest request);

    /**
     * 根据条件查询预订单
     *
     * @param page
     * @return
     */
    IPage<PosOrderPo> selectPosOrderPoList(@Param("page") Page<PosOrderPo> page,
                                           @Param("request") PosRsvOrderQueryRequest request);

    /**
     * 根据条件查询订单销售
     *
     * @param page
     * @param request
     * @return
     */
    IPage<PosOrderPo> selectBuyHistory(@Param("page") Page<PosOrderPo> page,
                                       @Param("request") BuyHistoryRequest request);


    /**
     * 查询销售数量和金额
     *
     * @param request
     * @return
     */
    AmtAndQty selectAmtAndQty(@Param("request") BuyHistoryRequest request);

    /**
     * 根据条件查询订单信息列表(状态为1，不包含退货相关的订单)
     *
     * @param memberId
     * @param startTime
     * @param endTime
     * @return
     */
    List<PosOrderPo> selectOrderList(@Param("memberId") String memberId,
                                     @Param("startTime") LocalDateTime startTime,
                                     @Param("endTime") LocalDateTime endTime);

    /**
     * 查询当月或者当日首单
     *
     * @param memberId
     * @param beginDate
     * @param endDate
     * @return
     */
    Integer selectFirstOrder(@Param("memberId") String memberId,
                             @Param("beginDate") LocalDate beginDate,
                             @Param("endDate") LocalDate endDate);

    /**
     * 查询最近一次的保级记录
     *
     * @param memberId
     * @return
     */
    MemberLevelLog selectRegulation(@Param("memberId") String memberId);

    /**
     * 获取时间段内累计消费金额
     *
     * @param memberId
     * @param startTime
     * @param endTime
     * @return
     */
    BigDecimal sumPayAmt(@Param("memberId") String memberId,
                         @Param("startTime") LocalDateTime startTime,
                         @Param("endTime") LocalDateTime endTime);

    /**
     * 获取时间段内累计消费金额，根据会员id分组
     *
     * @param memberIdList
     * @param startTime
     * @param endTime
     * @return
     */
    List<MemberIdAndTotalAmt> sumPayAmtGroupByMemberId(@Param("list") List<String> memberIdList,
                                                       @Param("startTime") LocalDateTime startTime,
                                                       @Param("endTime") LocalDateTime endTime);

    /**
     * 判断保级之后，有没有有效订单(需要排除退货相关的订单,在订单时间范围内，去掉销售关联的退货（两单都去掉），如果只有退货没有销售，则保留)
     *
     * @param memberId
     * @param startTime
     * @param endTime
     * @return
     */
    List<PosOrderPo> selectAllOrderList(@Param("memberId") String memberId,
                                        @Param("startTime") LocalDateTime startTime,
                                        @Param("endTime") LocalDateTime endTime);

    /**
     * 定时任务---计算退货后保级中的金额总数
     *
     * @param memberId
     * @param startTime
     * @param endTime
     * @return
     */
    BigDecimal sumTaskPayAmt(@Param("memberId") String memberId,
                             @Param("startTime") LocalDateTime startTime,
                             @Param("endTime") LocalDateTime endTime);

    /**
     * 定时任务---计算退货后保级中的金额总数
     *
     * @param amendmentTime
     * @param memberId
     * @return
     */
    List<PosOrderPo> selectOrderListByMember(@Param("amendmentTime") String amendmentTime,
                                             @Param("memberId") String memberId);
}
