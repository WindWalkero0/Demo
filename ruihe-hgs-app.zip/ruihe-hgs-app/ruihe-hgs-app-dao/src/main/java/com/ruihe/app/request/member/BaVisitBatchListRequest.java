package com.ruihe.app.request.member;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.Valid;
import java.util.List;

/**
 * @author luojie
 * @program ruihe-top
 * @description ba回访批量请求体对象
 * @create: 2021/7/15 16:35
 */
@Data
@ApiModel(value = "ba回访批量请求体对象", description = "ba回访批量请求体对象")
public class BaVisitBatchListRequest {
    @Valid
    @ApiModelProperty("ba回访批量对象")
    private List<BaVisitBatchRequest> batchRequestList;
}
