package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhFreeInventoryItemPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-22 15:48
 */
@Mapper
public interface WhFreeInventoryItemMapper extends BaseMapper<WhFreeInventoryItemPo> {
    Integer batchInsert(@Param("itemPoList") List<WhFreeInventoryItemPo> itemPoList);
}
