package com.ruihe.app.request.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-19 15:28
 */
@ApiModel(value = "PosRsvOrderQueryRequest", description = "预订单查询条件")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosRsvOrderQueryRequest implements Serializable {

    @ApiModelProperty(value = "会员id")
    private String memberId;

    @NotBlank(message = "柜台id不能为空")
    @ApiModelProperty(value = "柜台id----必填")
    private String counterId;

    @ApiModelProperty(value = "手机号")
    private String memberPhone;

    @ApiModelProperty(value = "开始时间")
    private LocalDate startTime;

    @ApiModelProperty(value = "结束时间")
    private LocalDate endTime;

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
