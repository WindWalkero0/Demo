package com.ruihe.app.mapper.member;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.app.request.member.MemberVisitReq;
import com.ruihe.app.response.MemberVisitVO;
import com.ruihe.common.dao.bean.member.MemberInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;


@Mapper
public interface MemberVisitMapper {

    /*IPage<MemberVisitVO> selectBirthdayVisit(Page<MemberVisitVO> page,
                                             String counterId,
                                             String beginDate,
                                             String endDate,
                                             boolean isCrossYear);*/

    IPage<MemberVisitVO> selectBirthdayVisit(@Param("page") Page<MemberVisitVO> page,
                                             @Param(Constants.WRAPPER) Wrapper<MemberInfo> wrapper);

    IPage<MemberVisitVO> selectJoinDateVisit(Page<MemberVisitVO> page,
                                             @Param("counterId") String counterId,
                                             @Param("beginDate") String beginDate,
                                             @Param("endDate") String endDate);

    IPage<MemberVisitVO> selectByOrderTime(Page<MemberVisitVO> page,
                                           @Param("counterId") String counterId,
                                           @Param("request") MemberVisitReq request);

}
