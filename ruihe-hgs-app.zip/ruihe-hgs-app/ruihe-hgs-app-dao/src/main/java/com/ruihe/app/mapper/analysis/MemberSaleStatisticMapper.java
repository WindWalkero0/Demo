package com.ruihe.app.mapper.analysis;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.analysis.*;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.pojo.request.analysis.MemberSaleRequest;
import com.ruihe.common.pojo.request.analysis.SaleRankingRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员销售统计
 *
 * @author:Fangtao
 * @Date:2019/11/2 13:43
 */
@Mapper
public interface MemberSaleStatisticMapper extends BaseMapper<MemberInfo> {
    /**
     * 会员销售统计
     *
     * @param request
     * @return
     */
    List<PosMemberSaleStatisticPo> queryMemberSale(@Param("request") MemberSaleRequest request);

    /**
     * 会员销售统计总金额与总数量
     *
     * @param request
     * @return
     */
    PosMemberSaleTotalAmtQtyPo queryQtyAndAmt(@Param("request") MemberSaleRequest request);

    /**
     * 统计门店一段时间内的购买人数
     *
     * @param memberId
     * @return
     */
    Integer counterConsumer(@Param("memberId") String memberId);

    /**
     * 商品销售排行
     *
     * @param request
     * @return
     */
    List<PosMerchandisingPo> queryMerchandising(@Param("request") SaleRankingRequest request);

    /**
     * 会员详情页中的消费计算->十二个月内购买总数与购买金额
     *
     * @param memberId
     * @param counterId
     * @return
     */
    PosMemberSaleDetailPo queryDetailOfQtyAndAmt(@Param("memberId") String memberId,
                                                 @Param("counterId") String counterId);

    /**
     * 会员详情页中的消费计算->连带率和客单价
     *
     * @param memberId
     * @param counterId
     * @return
     */
    PosMemberDetailPo queryDetailOfRateAndPrice(@Param("memberId") String memberId,
                                                @Param("counterId") String counterId);

    /**
     * 销售订单数(销售总单数M=累计实付金额大于0的订单数+累计退货金额大于0的订单数)
     *
     * @param memberId
     * @param counterId
     * @return
     */
    PosSalesOrderCountPo queryOrderCount(@Param("memberId") String memberId,
                                         @Param("counterId") String counterId);

    /**
     * 退货订单数(销售总单数M=累计实付金额大于0的订单数+累计退货金额大于0的订单数)
     *
     * @param memberId
     * @param counterId
     * @return
     */
    PosReturnOrderCountPo queryReturnCount(@Param("memberId") String memberId,
                                           @Param("counterId") String counterId);

    /**
     * 销售总数量M=累计“护肤品”大类销售产品数量-累计“护肤品”大类实物退货产品数量
     * 累计“护肤品”大类销售产品数量
     *
     * @param memberId
     * @param counterId
     * @return
     */
    PosSalesTotalCountPo querySalesPrdQty(@Param("memberId") String memberId,
                                          @Param("counterId") String counterId);

    /**
     * 销售总数量M=累计“护肤品”大类销售产品数量-累计“护肤品”大类实物退货产品数量
     * 累计“护肤品”大类实物退货产品数量
     *
     * @param memberId
     * @param counterId
     * @return
     */
    PosReturnTotalCountPo queryReturnPrdQty(@Param("memberId") String memberId,
                                            @Param("counterId") String counterId);

    /**
     * 会员详情页中的消费计算->最近购买的时间
     *
     * @param memberId
     * @param counterId
     * @return
     */
    PosMemberDiffTimePo queryLatelyTime(@Param("memberId") String memberId,
                                        @Param("counterId") String counterId);

    /**
     * 会员详情
     *
     * @param memberId
     * @param counterId
     * @return
     */
    PosMemberDataPo queryMemberDataList(@Param("memberId") String memberId,
                                        @Param("counterId") String counterId);

    /**
     * 商品销售排行榜中的净销售数量和金额
     *
     * @param request
     * @return
     */
    PosPayMentAmtAndQtyPo querySaleQtyAndAmt(@Param("request") SaleRankingRequest request);
}
