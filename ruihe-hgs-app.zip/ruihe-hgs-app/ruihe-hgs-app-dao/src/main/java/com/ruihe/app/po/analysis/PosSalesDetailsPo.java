package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 销售月报表->销售明细报表->销售明细
 *
 * @author:Fangtao
 * @Date:2019/11/5 18:01
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosSalesDetailsPo implements Serializable {
    /**
     * 商品总金额
     */
    private BigDecimal amt;
    /**
     * 商品总数量
     */
    private Integer qty;
    /**
     * 支付方式
     */
    private String payChannel;
    /**
     * 商品条码
     */
    private String prdBarCode;
    /**
     * 商品名称
     */
    private String prdName;
    /**
     * 分摊金额
     */
    private BigDecimal shareAmt;
}
