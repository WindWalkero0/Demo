package com.ruihe.app.response;

import com.ruihe.common.dao.bean.base.PosBaVisit;
import com.ruihe.common.pojo.response.member.BaVisitTypeResponse;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author luojie
 * @program ruihe-top
 * @description 服务记录返回实体类
 * @create: 2021/7/15 14:58
 */
@ApiModel(value = "服务记录返回体", description = "服务记录返回体")
@Data
public class BaVisitResponse {
    @ApiModelProperty("回访类型统计数据")
    List<BaVisitTypeResponse> typeResponseList;
    
    @ApiModelProperty("回访记录")
    List<PosBaVisit> visitList;
}
