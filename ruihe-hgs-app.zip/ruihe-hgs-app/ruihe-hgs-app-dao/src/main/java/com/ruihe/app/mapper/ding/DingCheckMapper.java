package com.ruihe.app.mapper.ding;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.bean.ding.DingCheck;
import org.apache.ibatis.annotations.Mapper;

import java.time.LocalDateTime;

@Mapper
public interface DingCheckMapper extends BaseMapper<DingCheck> {
    /**
     * 查询美导当前工作柜台
     * 按打卡时所在的柜台判断
     * 返回最近的打卡记录
     */
    default DingCheck getDingCheck(String baCode) {
        var list = selectList(Wrappers.lambdaQuery(DingCheck.class)
                .eq(DingCheck::getBaCode, baCode)
                .ge(DingCheck::getCheckTime, LocalDateTime.now())
        );
        if (list.isEmpty()) return null;
        return list.get(list.size() - 1);
    }
}
