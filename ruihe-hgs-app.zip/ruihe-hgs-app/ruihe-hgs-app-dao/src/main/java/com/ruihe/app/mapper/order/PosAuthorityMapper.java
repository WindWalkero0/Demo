package com.ruihe.app.mapper.order;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.order.PosAuthorityPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2019-12-10 9:59
 */
@Mapper
public interface PosAuthorityMapper extends BaseMapper<PosAuthorityPo> {
    List<PosAuthorityPo> queryAuthority(@Param("counter") CounterInformation counter);

    /**
     * 查询指定权限判断
     *
     * @param counter
     * @param type
     * @return
     */
    Integer countSpecifiedAuthority(@Param("counter") CounterInformation counter, @Param("type") String type);
}
