package com.ruihe.app.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author luojie
 * @program ruihe-top
 * @description 财务月开始日期及当前日期实体类
 * @create: 2021/7/20 15:32
 */
@ApiModel(value = "财务月开始日期及当前日期", description = "财务月开始日期及当前日期")
@Data
public class FinancialMonthResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @ApiModelProperty("财务月开始日期")
    private LocalDate startFinancialDate;
    
    @ApiModelProperty("财务月当前日期")
    private LocalDate currentFinancialDate;
}
