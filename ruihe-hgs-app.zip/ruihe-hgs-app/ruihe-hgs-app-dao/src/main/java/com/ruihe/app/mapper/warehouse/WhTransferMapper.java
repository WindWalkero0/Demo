package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhTransferPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * 查询主表方法
 */
@Mapper
public interface WhTransferMapper extends BaseMapper<WhTransferPo> {
}
