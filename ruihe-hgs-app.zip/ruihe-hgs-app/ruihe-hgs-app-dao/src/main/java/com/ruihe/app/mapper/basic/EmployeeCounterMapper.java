package com.ruihe.app.mapper.basic;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.UserCounter;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Anthor:huangjie
 * @Date:2021/07/16
 */
@Mapper
public interface EmployeeCounterMapper extends BaseMapper<UserCounter> {
}
