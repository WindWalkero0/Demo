package com.ruihe.app.request.member;

import com.ruihe.common.annotation.EnumValidation;
import com.ruihe.common.enums.member.MemberActivityEnum;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@ApiModel(value = "优惠券查询接收类")
@Data
public class MemberActivityCouponRequest {

    @NotBlank(message = "会员id不能为空")
    public String memberId;

    @NotBlank(message = "柜台id不能为空")
    public String counterId;

    /**
     * 积分兑礼:2024;商品兑换:2033
     */
    @NotNull(message = "积分兑换类型为空")
    @EnumValidation(clazz = MemberActivityEnum.class, method = "getKey", message = "积分兑换类型错误")
    private Integer type;

    @NotBlank(message = "当前时间不能为空")
    public String nowTime;

    @NotNull(message = "当前页不能为空")
    public Integer pageNumber;

    @NotNull(message = "页码不能为空")
    public Integer pageSize;


}




