package com.ruihe.app.request.member;

import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author luojie
 * @program ruihe-top
 * @description ba回访查询请求实体类
 * @create: 2021/7/15 17:39
 */
@ApiModel(value = "服务记录查询请求体", description = "服务记录查询请求体")
@Data
public class BaVisitQueryRequest extends PageForm implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @ApiModelProperty("服务操作类型id")
    private Integer typeId;
    
    @ApiModelProperty(value = "美导编号", required = true)
    @NotBlank(message = "美导编号不能为空")
    private String baCode;
    
    @ApiModelProperty(value = "开始时间(格式：yyyy-MM-dd)", required = true)
    @NotBlank(message = "开始时间不能为空")
    private String startTime;
    
    @ApiModelProperty(value = "结束时间(格式：yyyy-MM-dd)", required = true)
    @NotBlank(message = "结束时间不能为空")
    private String endTime;
}
