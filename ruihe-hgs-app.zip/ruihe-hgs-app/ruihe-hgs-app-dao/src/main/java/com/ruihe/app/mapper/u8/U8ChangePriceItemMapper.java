package com.ruihe.app.mapper.u8;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.u8.U8ChangePriceItemPo;
import com.ruihe.common.dao.bean.u8.U8ChangePriceItemSimplePo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * u8返回确认 Mapper 接口
 * </p>
 *
 * @author qubin
 * @since 2021-04-16
 */
@Mapper
public interface U8ChangePriceItemMapper extends BaseMapper<U8ChangePriceItemPo> {
    /**
     * 批量插入
     *
     * @param list
     * @return
     */
    Integer batchInsert(@Param("list") List<U8ChangePriceItemPo> list);

    /**
     * 查询产品最大生效时间
     *
     * @param prdBarCodeList
     * @return
     */
    List<U8ChangePriceItemSimplePo> selectMaxPrdEffectiveTime(@Param("list") List<String> prdBarCodeList);

}
