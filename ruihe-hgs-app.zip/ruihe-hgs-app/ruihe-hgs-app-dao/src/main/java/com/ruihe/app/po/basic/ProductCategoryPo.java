package com.ruihe.app.po.basic;/**
 * @author qubin
 * @date 2021/5/15 16:00
 */

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author qubin
 * @date 2021年05月15日 16:00
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductCategoryPo implements Serializable {

    @ApiModelProperty("主键")
    private Integer id;

    @ApiModelProperty("名称")
    private String name;
}
