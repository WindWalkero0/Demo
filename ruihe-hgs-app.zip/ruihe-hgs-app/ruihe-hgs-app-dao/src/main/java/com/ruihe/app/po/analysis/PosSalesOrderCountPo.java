package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 客单价,销售订单数
 * @Anthor:Fangtao
 * @Date:2020/3/2 9:52
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosSalesOrderCountPo implements Serializable {
    /**
     * 销售订单数
     */
    private Integer saleOrderQty;
}
