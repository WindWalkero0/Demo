package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.warehouse.WhReturnItemLogPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-23 18:04
 */
@Mapper
public interface WhReturnItemLogMapepr extends BaseMapper<WhReturnItemLogPo> {
    Integer batchInsert(@Param("itemPoList") List<WhReturnItemLogPo> itemPoList);
}
