package com.ruihe.app.mapper.terminal;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.fa.PosBannerPo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/9 14:12
 */
@Mapper
public interface PosBannerMapper extends BaseMapper<PosBannerPo> {
    /**
     * 根据时间查询最近的5张图片
     */
    List<PosBannerPo> selectBanner();
}
