package com.ruihe.app.po.fa;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 终端管理升级管理实体
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_fa_upgrade")
public class PosUpgradePo implements Serializable {
    /**
     * 主键id
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 平台  0安卓,1ios
     */
    private Integer platform;

    /**
     * app更新url
     */
    private String upgradeUrl;

    /**
     * 强制升级标识  1强制,2提示更新
     */
    private Integer forceUpgrade;

    /**
     * 提示更新频率   0每天第一次打开提示,1每次打开提示
     */
    private Integer tipsFreq;

    /**
     * 更新说明
     */
    private String tips;

    /**
     * 最新版本号
     */
    private String appVersion;
}
