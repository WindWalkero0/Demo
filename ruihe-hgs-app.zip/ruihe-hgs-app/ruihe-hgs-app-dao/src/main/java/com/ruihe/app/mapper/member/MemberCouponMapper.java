package com.ruihe.app.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.member.MemberCoupon;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 梁远
 * @Description
 * @create 2019-12-27 14:15
 */
@Mapper
public interface MemberCouponMapper extends BaseMapper<MemberCoupon> {
}
