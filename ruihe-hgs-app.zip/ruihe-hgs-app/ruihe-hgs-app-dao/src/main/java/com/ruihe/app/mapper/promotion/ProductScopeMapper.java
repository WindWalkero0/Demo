package com.ruihe.app.mapper.promotion;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.promotion.ProductScope;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductScopeMapper extends BaseMapper<ProductScope> {
}
