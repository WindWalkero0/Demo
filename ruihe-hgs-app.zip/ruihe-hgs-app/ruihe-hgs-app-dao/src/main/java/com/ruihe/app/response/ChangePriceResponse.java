package com.ruihe.app.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class ChangePriceResponse {
    /**
     * 活动名称
     */
    private String activityName;

    /**
     * 活动uid
     */
    private String uid;

    /**
     * 活动改价最小值
     */
    private BigDecimal priceChangeMin;

    /**
     * 整单改价最大值
     */
    public BigDecimal priceChangeMax;
}
