package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 销售明细单--销售类型
 *
 * @author:Fangtao
 * @Date:2019/10/31 16:58
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosSaleDetailPo implements Serializable {
    /**
     * 产品条码
     */
    private String prdBarCode;
    /**
     * 促销活动分摊金额
     */
    private BigDecimal shareAmt;
    /**
     * 商品名称
     */
    private String prdName;
    /**
     * 购买数量
     */
    private Integer purQty;
    /**
     * 每种商品总金额
     */
    private BigDecimal amt;

    /**
     *金额
     */
    private BigDecimal orderAmt;
    /**
     * 关联退货单号
     */
    private String preOrderNo;

    private String orderNo;





    /*****************************关联单号*******************************/
    /**
     * 时间
     */
    private LocalDateTime createTime;
    /**
     * 数量
     */
    private Integer goodsQty;
    /**
     * 金额
     */
    private BigDecimal realAmt;
    /**
     * 名字
     */
    private String memberName;
}
