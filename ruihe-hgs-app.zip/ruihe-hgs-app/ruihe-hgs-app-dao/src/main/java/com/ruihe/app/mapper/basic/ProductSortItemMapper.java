package com.ruihe.app.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.ProductSortItem;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author William
 * @since 2020-01-07
 */
@Mapper
public interface ProductSortItemMapper extends BaseMapper<ProductSortItem> {

}
