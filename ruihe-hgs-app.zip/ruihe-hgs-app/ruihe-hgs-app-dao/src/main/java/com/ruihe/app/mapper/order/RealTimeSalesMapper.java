package com.ruihe.app.mapper.order;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.home.RealTimeSalesPo;
import com.ruihe.common.pojo.response.socket.SalesVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author cxt
 * @since 2019-11-27
 */
@Mapper
public interface RealTimeSalesMapper extends BaseMapper<RealTimeSalesPo> {

    List<Map<String, Object>> queryAmt(@Param("time") LocalDate time);

    List<Map<String, Object>> queryQty(@Param("time") LocalDate time);

    SalesVo getSalesVo(@Param("time") LocalDate time);
}
