package com.ruihe.app.mapper.deposit;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.deposit.DepositBoxOrderPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-19 9:09
 */
@Mapper
public interface DepositBoxOrderMapper extends BaseMapper<DepositBoxOrderPo> {
}
