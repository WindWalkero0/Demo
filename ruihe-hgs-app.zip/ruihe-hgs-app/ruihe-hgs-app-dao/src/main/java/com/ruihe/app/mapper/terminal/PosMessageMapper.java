package com.ruihe.app.mapper.terminal;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.common.dao.bean.terminal.PosMessagePo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * pos消息
 */
@Mapper
public interface PosMessageMapper extends BaseMapper<PosMessagePo> {

    /**
     * @return
     */
    List<String> selectMessageCount(@Param("counterId") String counterId);


    Page<PosMessagePo> findNeedShowMessageForCurrentCounter(String counterId, Page<PosMessagePo> tPage);
}
