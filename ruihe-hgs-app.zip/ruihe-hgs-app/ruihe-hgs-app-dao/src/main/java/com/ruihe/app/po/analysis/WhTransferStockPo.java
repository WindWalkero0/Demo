package com.ruihe.app.po.analysis;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @Anthor:Fangtao
 * @Date:2020/2/28 15:30
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhTransferStockPo implements Serializable {
    @ApiModelProperty(value = "产品条码(对外标准条码)")
    private String prdBarCode;

    @ApiModelProperty(value = "产品名称")
    private String prdName;

    @ApiModelProperty(value = "商品条码")
    private String goodsBarCode;

    @ApiModelProperty(value = "申请调入数")
    private Integer inQty;

    @ApiModelProperty(value = "调出确认数")
    private Integer ackOutQty;

    @ApiModelProperty(value = "调入确认数")
    private Integer ackInQty;

    @ApiModelProperty(value = "单价")
    private BigDecimal memberPrice;

    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createTime;

    @ApiModelProperty(value = "修改时间")
    private LocalDateTime updateTime;

    @ApiModelProperty(value = "调出商品金额")
    private BigDecimal outProAmt;

    @ApiModelProperty(value = "库存")
    private Integer stock;
}
