package com.ruihe.app.request.member;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author Fangtao
 * @date 2019/11/26 19:32
 */
@ApiModel(description = "接收类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosWhInventoryRequest implements Serializable {
    @NotBlank(message = "柜台编码不能为空")
    private String counterId;

    @NotBlank(message = "商品编码不能为空")
    private String prdBarCode;

    private LocalDate startTime;

    private LocalDate endTime;
}
