package com.ruihe.app.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author qubin
 * @Description
 * @create 2021-04-23
 */
@ApiModel(value = "CounterLocationInfoVo", description = "门店地理位置VO")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CounterLocationInfoVo implements Serializable {

    @ApiModelProperty("门店id")
    private String counterId;

    @ApiModelProperty("门店名称")
    private String counterName;

    @ApiModelProperty("门店地址")
    private String counterAddress;

    @ApiModelProperty("距离，以米为单位返回，未定位时不返回")
    private Integer distance;

    @ApiModelProperty("定位经纬度")
    private String location;
}
