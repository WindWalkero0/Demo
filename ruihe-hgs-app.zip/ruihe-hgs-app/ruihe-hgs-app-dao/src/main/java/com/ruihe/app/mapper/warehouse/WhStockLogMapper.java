package com.ruihe.app.mapper.warehouse;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.app.po.analysis.PosStockLogSubtotalPo;
import com.ruihe.common.dao.bean.warehouse.WhSinglePrdStockPo;
import com.ruihe.common.dao.bean.warehouse.WhStockLogPo;
import com.ruihe.app.request.member.PosSinglePrdBizRequest;
import com.ruihe.app.request.member.PosWhInventoryRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 门店库存流水表 Mapper 接口
 * </p>
 *
 * @author William
 * @since 2019-10-24
 */
@Mapper
public interface WhStockLogMapper extends BaseMapper<WhStockLogPo> {

    Integer batchInsert(List<WhStockLogPo> list);

    List<WhSinglePrdStockPo> singlePrdBizReport(@Param("request") PosWhInventoryRequest request);

    List<WhStockLogPo> queryItem(@Param("page") Page page,
                                 @Param("request") PosSinglePrdBizRequest request);

    PosStockLogSubtotalPo queryTotal(@Param("counterId") String counterId, @Param("prdBarCode") String prdBarCode);
}
