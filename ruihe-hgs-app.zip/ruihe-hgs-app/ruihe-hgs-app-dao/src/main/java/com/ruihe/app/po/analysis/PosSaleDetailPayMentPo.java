package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/31 11:26
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosSaleDetailPayMentPo implements Serializable {

    private BigDecimal payChannelAmt;

    /**
     * 付款方式
     */
    private String payChannel;
}
