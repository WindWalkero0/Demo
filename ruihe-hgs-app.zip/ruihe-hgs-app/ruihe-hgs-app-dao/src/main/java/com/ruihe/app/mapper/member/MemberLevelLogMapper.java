package com.ruihe.app.mapper.member;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.member.MemberLevelLog;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description
 * @author 梁远
 * @create 2019-11-13 15:24
 */
@Mapper
public interface MemberLevelLogMapper extends BaseMapper<MemberLevelLog> {
}
