package com.ruihe.app.po.analysis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 销售总数量M=累计“护肤品”大类销售产品数量-累计“护肤品”大类实物退货产品数量
 * @Anthor:Fangtao
 * @Date:2020/3/2 10:44
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosSalesTotalCountPo implements Serializable {
    /**
     * “护肤品”大类销售产品数量
     */
    private Integer salesPrdQty;
}
