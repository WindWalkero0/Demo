package com.ruihe.app.po.heartbeat;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 柜台心跳po
 * @author qubin
 * @date 2021/4/17 16:03
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_counter_heartbeat")
public class CounterHeartbeatPO implements Serializable {

    /**
     * 柜台id
     */
    @TableId
    private String counterId;

    /**
     * 柜台名称
     */
    private String counterName;

    /**
     * 是否存活(0:死亡|1:存活)
     */
    private Integer isLive;

    /**
     * 心跳时间
     */
    private LocalDateTime heartbeatTime;

    /**
     * 上次心跳时间
     */
    private LocalDateTime lastHeartbeatTime;

    /**
     * 预计下次心跳时间
     */
    private LocalDateTime preNextTime;

    /**
     * 实际超时次数
     */
    private Integer actOvertimeCount;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 修改时间
     */
    private LocalDateTime updateTime;
}
