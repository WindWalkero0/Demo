package com.ruihe.app.mapper.heartbeat;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.app.po.heartbeat.CounterHeartbeatConfigPO;
import org.apache.ibatis.annotations.Mapper;

/**
 * 柜台心跳配置mapper
 *
 * @author qubin
 * @Date 2021-04-17
 */
@Mapper
public interface CounterHeartbeatConfigMapper extends BaseMapper<CounterHeartbeatConfigPO> {
}
