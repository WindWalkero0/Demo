package com.ruihe.app.request.member;

import com.ruihe.common.annotation.FieldName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author fly
 */
@ApiModel(value = "ba回访")
@Data
public class BaVisitRequest {

    @ApiModelProperty(value = "柜台编码")
    @FieldName(name = "柜台编码")
    @NotBlank(message = "柜台编码不能为空")
    public String counterId;

    @ApiModelProperty(value = "柜台名称")
    @FieldName(name = "柜台名称")
    @NotBlank(message = "柜台名称不能为空")
    public String counterName;

    @ApiModelProperty(value = "ba编码")
    @FieldName(name = "ba编码")
    @NotBlank(message = "ba编码不能为空")
    public String baCode;

    @ApiModelProperty(value = "ba名称")
    @FieldName(name = "ba名称")
    @NotBlank(message = "ba名称不能为空")
    public String baName;

    @ApiModelProperty(value = "操作类型")
    @FieldName(name = "操作类型")
    @NotBlank(message = "操作类型不能为空")
    public String operationType;

    @ApiModelProperty(value = "数量")
    @FieldName(name = "数量")
    @NotNull(message = "数量不能为空")
    public Integer operationQty;
}
