package com.ruihe.app.po.warehouse;

import lombok.*;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author:Fangtao
 * @Date:2019/11/14 18:25
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhEnterQueryPo implements Serializable {
    /**
     * 入库单号(可作唯一键)
     */
    private String enterNo;
    /**
     * 状态(1,待确认;2,已确认)
     */
    private Integer status;
    /**
     * 柜台id
     */
    private String counterId;
    /**
     * 柜台名称
     */
    private String counterName;
    /**
     * 实际入库数量
     */
    private Integer realQty;
    /**
     * 实际入库金额
     */
    private BigDecimal realAmt;
    /**
     * 操作人id
     */
    private String baCode;
    /**
     * 操作人姓名
     */
    private String baName;
    /**
     * 发货单号
     */
    private String deliveryNo;
    /**
     * 发货数量
     */
    private Integer deliveryQty;
    /**
     * 入库单号创建时间
     */
    private LocalDateTime createTime;
    /**
     * 入库总金额
     */
    private BigDecimal enterAmt;

}
