package com.ruihe.app.mapper.basic;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.warehouse.WhStockPo;
import com.ruihe.common.dao.bean.warehouse.WhStockPrdCatReportPo;
import com.ruihe.common.dao.bean.warehouse.WhStockPrdSeriesReportPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ProductMapper extends BaseMapper<Product> {
    /**
     * 库存报表->按产品分类统计
     *
     * @param
     * @return
     */
    List<WhStockPrdCatReportPo> prdCatReport(@Param("bigCatCode") String bigCatCode,
                                             @Param("mediumCatCode") String mediumCatCode,
                                             @Param("smallCatCode") String smallCatCode);

    /**
     * 库存报表->按产品系列统计
     *
     * @param
     * @return
     */
    List<WhStockPrdSeriesReportPo> prdSeriesReport(@Param("counterId") String counterId, @Param("seriesCode") String seriesCode);

    /**
     * 类似于扫码本
     *
     * @param
     * @return
     */
    List<Product> selectProduct(@Param("condition") String condition, @Param("price") String price);


    /**
     * 库存报表打印，根据分类查询条件
     *
     * @param bigCatCode
     * @param mediumCatCode
     * @param smallCatCode
     * @return
     */
    List<WhStockPo> listAllStockOfCategory(@Param("bigCatCode") String bigCatCode,
                                           @Param("mediumCatCode") String mediumCatCode,
                                           @Param("smallCatCode") String smallCatCode);
    
    /**
     * 库存报表打印，根据系列查询条件
     *
     * @param seriesCode
     * @return
     */
    List<WhStockPo> listAllStockOfSeries(@Param("seriesCode") String seriesCode);
}
