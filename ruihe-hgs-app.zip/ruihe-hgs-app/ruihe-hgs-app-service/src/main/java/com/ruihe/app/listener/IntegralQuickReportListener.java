package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.bean.integral.IntegralOrderPo;
import com.ruihe.common.pojo.dto.WsIntegralQuickReportDto;
import com.ruihe.common.pojo.dto.WsIntegralQuickReportItemDto;
import com.ruihe.common.enums.integral.IntegralBizTypeEnum;
import com.ruihe.common.constant.RabbitMQConst;
import com.ruihe.app.enums.WebSocketUriEnum;
import com.ruihe.app.event.IntegralQuickReportEvent;
import com.ruihe.common.dao.mapper.integral.IntegralOrderMapper;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.ws.client.WsClient;
import com.ruihe.ws.dto.Request;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


/**
 * 积分速报
 *
 * @author fly
 * @Description 积分速报
 * @create 2019年11月28日15:50:15
 */
@Slf4j
@Component
public class IntegralQuickReportListener {
    @Autowired
    private IntegralOrderMapper integralOrderMapper;

    @Autowired
    private WsClient wsClient;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(IntegralQuickReportEvent event) {
        try {
            //根据积分订单号获取积分订单记录
            IntegralOrderPo integralOrderPo = integralOrderMapper.selectById(event.getIntegralOrderNo());
            //后期可能延时接受的话  回一次返回多个
            List<WsIntegralQuickReportItemDto> integralList = new ArrayList<>();
            WsIntegralQuickReportItemDto wsIntegralQuickReportItemDto = new WsIntegralQuickReportItemDto();
            BeanUtils.copyProperties(integralOrderPo, wsIntegralQuickReportItemDto);
            //2020年3月30日16:41:47  新增需求 积分速报  如果是积分兑换的就只展示兑换的积分  返回的积分就不管了 比如我用了1000积分 买的东西又得到了100积分 就展示我兑换了1000积分
            if (integralOrderPo.getBizType().equals(IntegralBizTypeEnum.INTEGRAL_EXCH.getCode())) {
                wsIntegralQuickReportItemDto.setIntegralQty(integralOrderPo.getPaidQty());
            }
            integralList.add(wsIntegralQuickReportItemDto);
            //速报上金额、数量为正数 积分兑换很可能是负数
            integralList.parallelStream().forEach(e -> {
                e.setBizAmt(e.getBizAmt());
                e.setBizQty(Math.abs(e.getBizQty()));
                e.setIntegralQty(Math.abs(e.getIntegralQty()));
            });
            //获取今日积分订单总数
            LambdaQueryWrapper<IntegralOrderPo> queryWrapper = Wrappers.lambdaQuery();
            //业务类型(10正常销售,20销售退货,30积分兑换,40积分兑换退货,50积分维护,60积分清零)
            queryWrapper.in(IntegralOrderPo::getBizType, IntegralBizTypeEnum.INTEGRAL_EXCH.getCode(), IntegralBizTypeEnum.SALE.getCode())
                    .gt(IntegralOrderPo::getBizTime, LocalDate.now());

            Integer total = integralOrderMapper.selectCount(queryWrapper);
            //返回数据
            WsIntegralQuickReportDto quickReport = WsIntegralQuickReportDto.builder()
                    .total(total)
                    .integralList(integralList)
                    .build();
            //设置返回前端数据
        /*Request<WsIntegralQuickReportDto> request = new Request<>();
        request.setUri(WebSocketUriEnum.INTEGRAL.getCode());
        request.setData(quickReport);
        wsClient.upTopic(request);*/
            Request<WsIntegralQuickReportDto> request = new Request<>();
            request.setUri(WebSocketUriEnum.INTEGRAL.getCode());
            //request.setData(JSON.toJSONString(quickReport));
            request.setData(quickReport);
            rabbitTemplate.convertAndSend(RabbitMQConst.WEBSOCKET_FANOUT_EXCHANGE, "", request);
        } catch (Exception e) {
            log.error("积分速报异常，event{}", JSON.toJSONString(event), e);
        }
    }
}
