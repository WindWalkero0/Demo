package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.ruihe.app.event.IntegralExpireEvent;
import com.ruihe.app.service.task.AppTaskService;
import com.ruihe.common.constant.CommonConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;


/**
 * 积分过期监听
 *
 * @author Administrator
 */
@Slf4j
@Component
public class IntegralExpireListener {

    @Autowired
    private AppTaskService appTaskService;

    @EventListener
    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    public void onApplicationEvent(IntegralExpireEvent event) {
        try {
            appTaskService.newExpire();
        } catch (Exception e) {
            log.error("积分过期事件错误，event{}", JSON.toJSONString(event), e);
        }
    }
}
