package com.ruihe.app.dto.face;



import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;


@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class LabelProblemInfo {
    /**
     * 大类(标签)
     */
    private String label;
    /**
     * 大类中文名
     */
    private String labelChinese;
    /**
     * 严重等级
     */
    private String level;
    /**
     * 修正过的等级(因为每个等级的具体枚举值不是统一的但是前端需要统一展示)
     */
    private Integer fixLevel;
    /**
     * 问题类型
     */
    private String type;
    /**
     * 问题数量
     */
    private Integer number;
    /**
     * 面部位置
     */
    private String facePart;
    /**
     * 问题描述
     */
    private String description;
    /**
     * 问题占比
     */
    private String areaRatio;
    /**
     * 问题图层
     */
    private String layer;
    /**
     * 原始图像
     */
    private String image;
    /**
     * 问题详情
     */
    private List<LabelProblemInfo> detailInfo;
}
