package com.ruihe.app.service.basic.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.basic.AboutProductMapper;
import com.ruihe.app.mapper.basic.ProductCategoryMapper;
import com.ruihe.app.mapper.basic.ProductMapper;
import com.ruihe.app.mapper.basic.ProductSeriesMapper;
import com.ruihe.app.mapper.warehouse.WhStockMapper;
import com.ruihe.app.po.basic.ProductCategoryPo;
import com.ruihe.app.po.basic.ProductSeriesPo;
import com.ruihe.app.service.basic.QueryProductService;
import com.ruihe.app.vo.ProductItemVo;
import com.ruihe.app.vo.ProductSimpleVo;
import com.ruihe.app.vo.WhStockVo;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.base.ProductCategory;
import com.ruihe.common.dao.bean.base.ProductSeries;
import com.ruihe.common.dao.bean.warehouse.WhStockPo;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-24 10:36
 */
@Slf4j
@DS(DBConst.SLAVE)
@Service
public class QueryProductServiceImpl implements QueryProductService {

    @Autowired
    private AboutProductMapper aboutProductMapper;

    @Autowired
    private WhStockMapper whStockMapper;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private ProductSeriesMapper productSeriesMapper;

    @Autowired
    private  ProductCategoryMapper productCategoryMapper;

    /**
     * 根据商品条码查询商品信息，同时展示库存数量
     *
     * @param counterId
     * @param barCode
     * @return
     */
    @Override
    public Response selectProductStock(String counterId, String barCode) {
        //查询库存信息
        LambdaQueryWrapper<WhStockPo> queryWrapper = Wrappers.<WhStockPo>lambdaQuery()
                .eq(WhStockPo::getCounterId, counterId)
                .like(WhStockPo::getPrdBarCode, barCode)
                .orderByAsc(WhStockPo::getBigCatCode)
                .orderByAsc(WhStockPo::getMediumCatCode)
                .orderByAsc(WhStockPo::getSmallCatCode)
                .orderByAsc(WhStockPo::getPrdBarCode);
        List<WhStockPo> stockPoList = whStockMapper.selectList(queryWrapper);
        return Response.success(ObjectUtils.toList(stockPoList, WhStockVo.class));
    }

    /**
     * 根据商品条码查询商品信息
     *
     * @param prdBarCode
     * @return
     */
    @Override
    public Response selectProduct(String prdBarCode) {
        List<Product> products = aboutProductMapper.selectProductItem(prdBarCode);
        return Response.success(ObjectUtils.toList(products, ProductItemVo.class));
    }

    @Override
    public Response selectProductStockByAPP(String counterId, List<String> prdBraCodeList) {
        LambdaQueryWrapper<WhStockPo> queryWrapper = Wrappers.<WhStockPo>lambdaQuery();
        LambdaQueryWrapper<Product> queryWrapperForProduct = Wrappers.<Product>lambdaQuery();
        if (prdBraCodeList == null || prdBraCodeList.size() == 0) {
            queryWrapper.eq(WhStockPo::getCounterId, counterId);
        } else {
            queryWrapper.eq(WhStockPo::getCounterId, counterId)
                    .in(WhStockPo::getPrdBarCode, prdBraCodeList);
            queryWrapperForProduct.in(Product::getPrdBarCode, prdBraCodeList);
        }
        //查询库存信息
        List<WhStockPo> stockPoList = whStockMapper.selectList(queryWrapper);
        List<Product> products = productMapper.selectList(queryWrapperForProduct);
        List<WhStockVo> WhStockVoList = ObjectUtils.toList(stockPoList, WhStockVo.class);
        Map<String, Product> productMap = products.stream().collect(Collectors.toMap(Product::getPrdBarCode, Function.identity()));
        Map<String, WhStockVo> whStockMap = WhStockVoList.stream().collect(Collectors.toMap(WhStockVo::getPrdBarCode, Function.identity()));
        List<WhStockVo> returnList = new ArrayList<>();
        String counter = WhStockVoList.get(0).getCounterId();
        String counterName = WhStockVoList.get(0).getCounterName();
        productMap.forEach((key, value) -> {
            WhStockVo whStockVo = new WhStockVo();
            WhStockVo whStockVo1 = whStockMap.get(key);
            if (whStockVo1 == null) {
                BeanUtils.copyProperties(value, whStockVo);
                whStockVo.setCounterId(counter);
                whStockVo.setCounterName(counterName);
                whStockVo.setPrdPrice(value.getSalePrice());
                whStockVo.setStock(0);
                returnList.add(whStockVo);
            } else {
                returnList.add(whStockVo1);
            }
        });

        return Response.success(returnList);
    }

    /**
     * 查询商品做条码展示
     *
     * @param condition
     * @return
     */
    @Override
    public Response selectProductBarCode(String condition, String price) {
        List<Product> products = productMapper.selectProduct(condition, price);
        return Response.success(products);
    }

    @Ella(Describe = "查询商品大分类", Author = "qubin")
    @DS(DBConst.SLAVE)
    public Response selectBigCat() {
        List<ProductCategory> productCategoryList = productCategoryMapper.selectList(Wrappers.<ProductCategory>lambdaQuery()
                .eq(ProductCategory::getDeleted, 0)
                .eq(ProductCategory::getLevel, 1));
        return  Response.success(ObjectUtils.toList(productCategoryList, ProductCategoryPo.class));
    }

    @Ella(Describe = "查询分类children", Author = "qubin")
    @DS(DBConst.SLAVE)
    public Response selectChildrenCat(Integer parentId) {
        List<ProductCategory> list = getChildren(parentId);
        return  Response.success(ObjectUtils.toList(list, ProductCategoryPo.class));
    }

    private List<ProductCategory> getChildren(Integer parentId) {
        return productCategoryMapper.selectList(Wrappers.lambdaQuery(ProductCategory.class)
                .eq(ProductCategory::getParentId, parentId)
                .eq(ProductCategory::getDeleted, 0)
                .orderByAsc(ProductCategory::getSort)
        );
    }
    @Ella(Describe = "查询系列", Author = "qubin")
    @DS(DBConst.SLAVE)
    public Response selectSeries() {
        List<ProductSeries> productSeriesList = productSeriesMapper.selectList(Wrappers.<ProductSeries>lambdaQuery()
                .eq(ProductSeries::getDeleted,0)
                .orderByDesc(ProductSeries::getSort).orderByAsc(ProductSeries::getId));
        return  Response.success(ObjectUtils.toList(productSeriesList, ProductSeriesPo.class));
    }

    /**
     * 根据商品条码查询
     *
     * @param goodsBarCode
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response searchProductByGoodsBarCode(String goodsBarCode) {
        if(StringUtils.isBlank(goodsBarCode)){
            return Response.errorMsg("商品条码不能为空");
        }
        List<Product> productList = productMapper.selectList(Wrappers.<Product>lambdaQuery()
                .like(Product::getGoodsBarCode, goodsBarCode)
                .orderByDesc(Product::getMemberPrice));
        return Response.success(ObjectUtils.toList(productList, ProductSimpleVo.class));
    }
}
