package com.ruihe.app.service.order;

import com.ruihe.common.pojo.request.promotion.SalesProductRequest;
import com.ruihe.common.utils.FullCombinationUtil;
import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;

import static java.util.Comparator.comparing;
import static java.util.Comparator.comparingInt;
import static java.util.stream.Collectors.*;

@Data
class MatchInfo {
    private Boolean finishMatch; //是否结束匹配
    private Integer matchCount; //最大匹配次数
    private Integer activityTotalAmt;//限定金额
    private Map<String, Long> excludeProducts;//排除掉的商品及数量
    private List<SalesProductRequest> flatProducts;//购物车里平铺后的商品

    public MatchInfo(int activityTotalAmt, List<SalesProductRequest> flatProducts) {
        this.activityTotalAmt = activityTotalAmt;
        this.flatProducts = flatProducts;
        this.finishMatch = false;
        this.matchCount = 0;
        this.excludeProducts = Collections.emptyMap();
    }

    /**
     * 到达最大匹配次数临界条件
     */
    public static boolean arriveMaxMathCondition(MatchInfo matchInfo) {
        return matchInfo.getFinishMatch();
    }

    /**
     * 排除购买商品逻辑
     */
    public static MatchInfo excludeProductLogic(MatchInfo matchInfo) {

        //本次筛选将要排除的商品
        var excludeProductsThisTime = (matchInfo.getFlatProducts().size() <= 20)
                ? getWillExcludeProducts(matchInfo)
                : getWillExcludeProductsExtra(matchInfo);

        if (CollectionUtils.isEmpty(excludeProductsThisTime)) {
            matchInfo.setFinishMatch(true);
        } else {
            //更新平铺产品
            matchInfo.setFlatProducts(getFlatProducts(matchInfo, excludeProductsThisTime));
            //累计排除商品
            matchInfo.setExcludeProducts(getExcludeProducts(matchInfo, excludeProductsThisTime));
            //更新最大匹配次数
            matchInfo.setMatchCount(matchInfo.getMatchCount() + 1);
        }
        return matchInfo;
    }

    /**
     * 获取最新的购物车
     *
     * @param matchInfo               匹配信息
     * @param excludeProductsThisTime 本次被排除的商品
     * @return 最新的购物车商品
     */
    private static List<SalesProductRequest> getFlatProducts(MatchInfo matchInfo, Map<String, Long> excludeProductsThisTime) {

        //上一次匹配完后购物车剩余的商品
        var flatProductsMap = matchInfo.getFlatProducts()
                .stream().collect(groupingBy(SalesProductRequest::getProId, LinkedHashMap::new, toList()));

        //本次需要匹配了排除商品后的购物车
        return flatProductsMap.entrySet().stream().flatMap(e -> {
            var proId = e.getKey();
            var productsList = e.getValue();
            Long skipNum = excludeProductsThisTime.get(proId);
            if (skipNum == null) {
                return productsList.stream();
            } else {
                return productsList.stream().skip(skipNum);
            }
        }).collect(toList());
    }

    /**
     * 累计被排除商品
     *
     * @param matchInfo               匹配信息
     * @param excludeProductsThisTime 本次被排除的商品
     * @return 累计被排除商品
     */
    private static Map<String, Long> getExcludeProducts(MatchInfo matchInfo, Map<String, Long> excludeProductsThisTime) {

        //之前已经排除的商品
        var excludeProductsAlready = matchInfo.getExcludeProducts();

        //首次
        if (CollectionUtils.isEmpty(excludeProductsAlready)) {
            excludeProductsAlready = excludeProductsThisTime;
        } else {
            //非首次
            for (Map.Entry<String, Long> entry : excludeProductsThisTime.entrySet()) {
                String key = entry.getKey();
                Long value = entry.getValue();
                excludeProductsAlready.merge(key, value, Long::sum);
            }
        }
        return excludeProductsAlready;
    }


    /**
     * 产品不大于20个时的排除逻辑
     *
     * @param matchInfo matchInfo
     * @return excludeProducts
     */
    private static Map<String, Long> getWillExcludeProducts(MatchInfo matchInfo) {

        var flatProductPrices = matchInfo.flatProducts.stream().map(SalesProductRequest::confirmProductPrice).collect(toList());
        int activityTotalAmt = matchInfo.activityTotalAmt;
        var flatProducts = matchInfo.flatProducts;

        //全组合后所有的情形
        var allConditionList = FullCombinationUtil.arrangeSelect(flatProductPrices);
        //每种组合加起来的组合总金额
        Function<List<Integer>, Integer> sumAmt = (e) -> e.stream().reduce(Integer::sum).orElse(0);

        //key：价格差 value：包含的商品价格
        var finalSortedPriceCombine = allConditionList.parallelStream()
                .filter(e -> sumAmt.apply(e) >= activityTotalAmt)//取出组合中总金额大于活动金额的组合
                .map(e -> e.stream().sorted(comparing(Integer::intValue).reversed()).collect(toList()))//对每种组合内部的产品按价格从高到低进行排序
                .sorted(comparingInt(List::size))//对每种组合之间再进行排序,组合内包含产品单价越高的产品越多的排前面
                .distinct()//对每种组合内部产品相同的组合去重只保留一个
                .collect(groupingBy(e -> Math.abs(sumAmt.apply(e) - activityTotalAmt), TreeMap::new, toList()));//按每种组合内部产品价格之和与总金额的差值的绝对值进行分组,对分组的结果用TreeMap进行排序,排序的结果用List进行收集起来

        //购物车里里已经没有满足大于购买金额条件的商品集合了
        boolean empty = CollectionUtils.isEmpty(finalSortedPriceCombine);
        if (empty) {
            return Collections.emptyMap();
        }

        //最终确定下来满足条件(最接近活动总金额)的价格集合 取第一值就好了!!!!
        //因为按组合与活动总金额的差值的绝对值进行分组,那么Map里排在前面的的key值就比后面的小,取差值最小的组合(产品集合里金额累加起来最接近活动金额)
        // 然后从差值最小的组合集合中取第一个组合[因为在分组之前就已经排好序了上面sorted()方法]就是满足需求条件的最终组合
        var finalKey = finalSortedPriceCombine.keySet().iterator().next();
        var finalPriceComb = finalSortedPriceCombine.get(finalKey).get(0);
        //每种金额对应的数量
        var priceAndCountMap = finalPriceComb.stream().collect(groupingBy(Function.identity(), counting()));
        //根据最终金额从购物车里确定产品以及产品的数量
        return priceAndCountMap.entrySet().stream().flatMap(entry -> {
            Integer price = entry.getKey();
            Long priceCount = entry.getValue();
            //拿金额去购物车里找出产品,再找出满足该金额产品数量
            return flatProducts.stream().filter(e -> e.confirmProductPrice() == price).limit(priceCount);
        }).collect(groupingBy(SalesProductRequest::getProId, counting()));

    }

    /**
     * 产品大于20个时的排除逻辑
     * 因为如果产品数量大于20个时,转换下找出商品策略(20个以上元素全组合筛选排序操作将会非常耗时)
     *
     * @param matchInfo matchInfo
     * @return excludeProducts
     */
    private static Map<String, Long> getWillExcludeProductsExtra(MatchInfo matchInfo) {

        int activityTotalAmt = matchInfo.activityTotalAmt;
        var flatProducts = matchInfo.flatProducts;
        var flatProductPrices = matchInfo.flatProducts.stream().map(SalesProductRequest::confirmProductPrice).collect(toList());

        //case1 单品价格直接大于或等于总金额,找一个元素就行
        boolean existPriceMoreThan = flatProductPrices.stream().anyMatch(e -> e >= activityTotalAmt);
        if (existPriceMoreThan) {
            //存在单品价格大于总金额的情形,找等于或最接近总金额的单品就行
            return flatProducts.stream()
                    .filter(e -> e.confirmProductPrice() >= activityTotalAmt)//找出单价大于总金额的产品
                    .sorted(comparing(SalesProductRequest::confirmProductPrice))//按产品零售价排序
                    .limit(1).collect(groupingBy(SalesProductRequest::getProId, counting()));
        }

        //case2 限定金额大于任意产品金额-->产品排序然后产品金额累加,当累加金额小于等于限定金额时,停止累加并返回累加过的产品
        AtomicInteger sumAmt = new AtomicInteger(0);
        var lessThenProducts = flatProducts.stream()
                .peek(e -> sumAmt.set(sumAmt.get() + e.confirmProductPrice()))
                .takeWhile(e -> sumAmt.get() <= activityTotalAmt)
                .collect(toList());
        int calculateAmt = lessThenProducts.stream().mapToInt(SalesProductRequest::confirmProductPrice).sum();

        //如果商品按顺序相加小于总金额的逻辑,还得再选一个商品(相加刚刚好的直接就不用再选一个了)
        if (calculateAmt < activityTotalAmt) {
            var lastProduct = flatProducts.stream()
                    .skip(lessThenProducts.size())//从后面开始找
                    .sorted(comparing(SalesProductRequest::confirmProductPrice))//按差额正序排
                    .takeWhile(e -> e.confirmProductPrice() > (activityTotalAmt - calculateAmt))//找大于金额差的所有
                    .collect(toList()).get(0);
            lessThenProducts.add(lastProduct);
        }
        return lessThenProducts.stream().collect(groupingBy(SalesProductRequest::getProId, counting()));
    }

}
