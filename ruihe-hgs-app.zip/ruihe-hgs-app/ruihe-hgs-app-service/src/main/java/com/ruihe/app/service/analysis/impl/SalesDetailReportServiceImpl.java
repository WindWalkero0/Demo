package com.ruihe.app.service.analysis.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.app.service.analysis.SalesDetailReportService;
import com.ruihe.app.vo.*;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.dao.bean.order.PosPaymentOrderPo;
import com.ruihe.common.enums.activity.ActivityTypeEnum;
import com.ruihe.common.pojo.request.analysis.SaleDetailRequest;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.mapper.analysis.SalesDetailReportMapper;
import com.ruihe.app.mapper.analysis.SalesSummaryMapper;
import com.ruihe.app.mapper.order.PosOrderItemMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.mapper.order.PosPaymentOrderMapper;
import com.ruihe.app.po.analysis.PosSaleDetailReportPo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.common.pojo.PageVO;
;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 销售明细报表->销售小结
 *
 * @author:Fangtao
 * @Date:2019/10/31 11:03
 */
@Slf4j
@DS(DBConst.SLAVE)
@Service
public class SalesDetailReportServiceImpl implements SalesDetailReportService {
    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private PosOrderItemMapper posOrderItemMapper;

    @Autowired
    private SalesSummaryMapper salesSummaryMapper;

    @Autowired
    private SalesDetailReportMapper salesDetailReportMapper;

    @Autowired
    private PosPaymentOrderMapper posPaymentOrderMapper;

    /**
     * 按条件查询销售小结首页
     */
    @Override
    public Response selectReport(SaleDetailRequest request) {
        //判断页数和页面
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            return Response.errorMsg("页数、页码不能为空!");
        }
        if (StringUtils.isBlank(request.getCounterId())) {
            return Response.errorMsg("柜台编码不能为空!");
        }
        //分页
        Page<PosOrderPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询条件
        LambdaQueryWrapper<PosOrderPo> queryWrapper = Wrappers.<PosOrderPo>lambdaQuery()
                .eq(PosOrderPo::getCounterId, request.getCounterId())
                .orderByDesc(PosOrderPo::getBizTime);
        if (StringUtils.isNotBlank(request.getBaCode())) {
            queryWrapper.eq(PosOrderPo::getBaCode, request.getBaCode());
        }
        if (StringUtils.isNotBlank(request.getMemberPhone())) {
            queryWrapper.eq(PosOrderPo::getMemberPhone, request.getMemberPhone());
        }
        if (request.getActivityType() != null) {
            //2020年5月8日18:26:47 activityType 1 和 4都是优惠券 你查1的时候就 in(1,4)
            if (request.getActivityType().equals(ActivityTypeEnum.USING_CONPON_4MEMBER.getCode())){
                queryWrapper.in(PosOrderPo::getActivityType, ActivityTypeEnum.USING_CONPON_4MEMBER.getCode(), ActivityTypeEnum.USING_CONPON_4ISSUE.getCode());
            }else {
                queryWrapper.eq(PosOrderPo::getActivityType, request.getActivityType());
            }
        }
        if (request.getTransType() != null) {
            queryWrapper.eq(PosOrderPo::getTransType, request.getTransType());
        }
        if (StringUtils.isNotBlank(request.getReceiptNo())) {
            queryWrapper.like(PosOrderPo::getReceiptNo, request.getReceiptNo());
        }
        if (request.getEndTime() != null && request.getStartTime() != null) {
            queryWrapper.between(PosOrderPo::getBizTime, request.getStartTime(), request.getEndTime().plusDays(1));
        }
        //分页查询
        IPage<PosOrderPo> posOrderPoIPage = posOrderMapper.selectPage(page, queryWrapper);
        //转换数据
        List<PosOrderPo> orderPoList = posOrderPoIPage.getRecords();
        if (!orderPoList.isEmpty()) {
            orderPoList.forEach(e -> {
                if (e.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                    e.setGoodsQty(Math.negateExact(Math.abs(e.getGoodsQty())));
                    e.setRealAmt(e.getRealAmt().abs().negate());
                }
            });
        }
        //转换page对象
        PageVO pageVO = PageVO.<PosSaleOrderVo>builder()
                .list(ObjectUtils.toList(orderPoList, PosSaleOrderVo.class))
                .pageNum(posOrderPoIPage.getCurrent())
                .pageSize(posOrderPoIPage.getSize())
                .pages(posOrderPoIPage.getPages())
                .total(posOrderPoIPage.getTotal())
                .build();
        return Response.success(pageVO);
    }


    /**
     * 销售明细报表->销售小结->按条件计算数量与销售额
     */
    @Override
    public Response sumCounterAllStock(SaleDetailRequest request) {
        if (StringUtils.isBlank(request.getCounterId())) {
            return Response.errorMsg("柜台编码不能为空!");
        }
        PosSaleDetailReportVo posSaleDetailReportVo = new PosSaleDetailReportVo();
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        PosSaleDetailReportPo posSaleDetailReportPo = salesSummaryMapper.sumCounterAllStock(request);
        if (posSaleDetailReportPo != null) {
            posSaleDetailReportVo.setQty(posSaleDetailReportPo.getSaleQty());
            posSaleDetailReportVo.setAmt(posSaleDetailReportPo.getSaleAmt());
        }
        return Response.success(posSaleDetailReportVo);
    }


    /**
     * 销售明细单--查看详情
     */
    @Override
    public Response typeOfReturn(String orderNo, Integer transType) {
        //根据订单号查询详情
        List<PosOrderItemPo> posOrderItemPoList = posOrderItemMapper.selectList(Wrappers.<PosOrderItemPo>lambdaQuery()
                .eq(PosOrderItemPo::getOrderNo, orderNo));
        if (posOrderItemPoList.isEmpty()) {
            //页面有数据，查看详情无数据
            return Response.errorMsg("查询出错，请刷新重试!");
        }
        List<PosOrderItemVo> posOrderItemVoList = ObjectUtils.toList(posOrderItemPoList, PosOrderItemVo.class);
        //查询支付方式
        List<PosPaymentOrderPo> paymentOrderPoList = posPaymentOrderMapper.selectList(Wrappers.<PosPaymentOrderPo>lambdaQuery()
                .eq(PosPaymentOrderPo::getOrderNo, orderNo));
        if (paymentOrderPoList.isEmpty()) {
            //没有查询到支付信息
            return Response.errorMsg("查询出错，请刷新重试!");
        }
        List<PosPayMentItemVo> posPaymentItemVoList = ObjectUtils.toList(paymentOrderPoList, PosPayMentItemVo.class);
        //返回前端的前置数据
        BuyHistoryVo buyHistoryVo = new BuyHistoryVo();
        //如果交易类型是销售，则查询是否有关联的退货单
        if (transType.equals(OrderTransTypeEnum.GOODS_OUT.getCode())) {
            PosOrderPo po = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                    .eq(PosOrderPo::getPreOrderNo, orderNo));
            if (po != null) {
                BeanUtils.copyProperties(po, buyHistoryVo);
                buyHistoryVo.setGoodsQty(Math.negateExact(Math.abs(po.getGoodsQty())));
                buyHistoryVo.setRealAmt(po.getRealAmt().abs().negate());
            }
        } else {
            //退货数据设置成负数
            posOrderItemVoList.forEach(e -> {
                e.setPurQty(Math.negateExact(Math.abs(e.getPurQty())));
                e.setAmount(e.getAmount().abs().negate());
            });
            //支付信息设置成负数
            posPaymentItemVoList.forEach(e -> e.setPayAmt(e.getPayAmt().abs().negate()));
            //查询关联的销售单
            PosOrderPo po = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                    .eq(PosOrderPo::getOrderNo, orderNo));
            //查询到前置单据不为空
            if (StringUtils.isNotBlank(po.getPreOrderNo())) {
                PosOrderPo posOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                        .eq(PosOrderPo::getOrderNo, po.getPreOrderNo()));
                if (posOrderPo != null) {
                    //返回的销售单数据都是正数
                    BeanUtils.copyProperties(posOrderPo, buyHistoryVo);
                    buyHistoryVo.setGoodsQty(Math.abs(posOrderPo.getGoodsQty()));
                    buyHistoryVo.setRealAmt(posOrderPo.getRealAmt().abs());
                }
            }
        }
        //返回
        Map<String, Object> resultMap = Map.ofEntries(
                Map.entry("buyHistoryVo", buyHistoryVo),
                Map.entry("posOrderItemVoList", posOrderItemVoList),
                Map.entry("posPaymentItemVoList", posPaymentItemVoList)
        );
        return Response.success(resultMap);
    }

    /**
     * 销售明细报表->销售明细->积分兑换类型
     *
     * @param orderNo
     * @return
     */
    @Override
    public Response pointExchangeType(String orderNo, Integer activityType, Integer transType) {
        //销售明细报表->销售明细->积分兑换类型->order子表查询
        LambdaQueryWrapper<PosOrderItemPo> wrapper = Wrappers.<PosOrderItemPo>lambdaQuery()
                .eq(PosOrderItemPo::getOrderNo, orderNo);
        List<PosOrderItemPo> itemPoList = salesDetailReportMapper.selectList(wrapper);
        //判断
        if (itemPoList.isEmpty()) {
            return Response.successMsg("暂无数据");
        }
        List<PosIntegralExchangeItemVo> toList = ObjectUtils.toList(itemPoList, PosIntegralExchangeItemVo.class);

        //去pos_payment中查询支付方式
        List<PosPaymentOrderPo> list = posPaymentOrderMapper.selectList(Wrappers.<PosPaymentOrderPo>lambdaQuery()
                .eq(PosPaymentOrderPo::getOrderNo, orderNo));
        if (list.isEmpty()) {
            return Response.successMsg("暂无数据");
        }
        List<PosPayMentItemVo> toList1 = ObjectUtils.toList(list, PosPayMentItemVo.class);

        //返回前端的前置数据
        BuyHistoryVo buyHistoryVo = new BuyHistoryVo();
        //如果交易类型是销售且是积分兑换，则查询是否有关联的退货单
        if (transType.equals(OrderTransTypeEnum.GOODS_OUT.getCode()) && activityType == 0) {
            PosOrderPo po = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                    .eq(PosOrderPo::getPreOrderNo, orderNo));
            if (po != null) {
                BeanUtils.copyProperties(po, buyHistoryVo);
                buyHistoryVo.setGoodsQty(Math.negateExact(Math.abs(po.getGoodsQty())));
                buyHistoryVo.setRealAmt(po.getRealAmt().abs().negate());
            }
        } else {
            //退货数据设置成负数
            toList.forEach(e -> {
                e.setPurQty(Math.negateExact(Math.abs(e.getPurQty())));
                e.setAmount(e.getAmount().abs().negate());
            });
            //支付信息设置成负数
            toList1.forEach(e -> e.setPayAmt(e.getPayAmt().abs().negate()));
            //查询关联的销售单
            PosOrderPo po = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                    .select(PosOrderPo::getPreOrderNo)
                    .eq(PosOrderPo::getOrderNo, orderNo));
            //查询到前置单据不为空
            if (StringUtils.isNotBlank(po.getPreOrderNo())) {
                PosOrderPo posOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                        .eq(PosOrderPo::getOrderNo, po.getPreOrderNo()));
                if (posOrderPo != null) {
                    //返回的销售单数据都是正数
                    BeanUtils.copyProperties(posOrderPo, buyHistoryVo);
                    buyHistoryVo.setGoodsQty(Math.abs(posOrderPo.getGoodsQty()));
                    buyHistoryVo.setRealAmt(posOrderPo.getRealAmt().abs());
                }
            }
        }
        //返回
        Map<String, Object> resultMap = Map.ofEntries(
                Map.entry("buyHistoryVo", buyHistoryVo),
                Map.entry("posOrderItemVoList", toList),
                Map.entry("posPaymentItemVoList", toList1)
        );
        return Response.success(resultMap);
    }
}
