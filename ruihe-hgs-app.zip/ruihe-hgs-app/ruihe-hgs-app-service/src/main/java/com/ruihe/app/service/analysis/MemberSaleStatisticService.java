package com.ruihe.app.service.analysis;

import com.ruihe.common.pojo.request.analysis.MemberSaleRequest;
import com.ruihe.common.pojo.request.analysis.SaleRankingRequest;
import com.ruihe.common.response.Response;

/**
 * 分析/会员销售统计
 *
 * @author:Fangtao
 * @Date:2019/11/2 10:52
 */
public interface MemberSaleStatisticService {
    /**
     * 会员销售统计
     */
    Response selectMemberSale(MemberSaleRequest request);

    /**
     * 会员详情页
     */
    Response memberDetail(String memberId,String counterId);


    /**
     * 会员详情页中的消费计算
     */
    Response consumptionCalculation(String memberId,String counterId);

    /**
     * 商品销售排行
     */
    Response saleRanking(SaleRankingRequest request);

}
