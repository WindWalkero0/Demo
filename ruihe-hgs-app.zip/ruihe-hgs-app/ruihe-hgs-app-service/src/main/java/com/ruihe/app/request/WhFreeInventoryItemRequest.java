package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-22 16:13
 */
@ApiModel(value = "WhFreeInventoryItemRequest", description = "新增盘点单详情请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhFreeInventoryItemRequest implements Serializable {

    @ApiModelProperty(value = "盘点单号,新增的时候可以为空")
    private String invNo;

    @NotNull(message = "产品条码不能为空")
    @ApiModelProperty(value = "产品条码", required = true)
    private String prdBarCode;

    @NotNull(message = "厂商编码不能为空")
    @ApiModelProperty(value = "厂商编码", required = true)
    private String goodsBarCode;

    @NotNull(message = "产品名称不能为空")
    @ApiModelProperty(value = "产品名称", required = true)
    private String prdName;

    @NotNull(message = "产品单价不能为空")
    @ApiModelProperty(value = "产品单价", required = true)
    private BigDecimal memberPrice;

    @NotNull(message = "实盘数不能为空")
    @ApiModelProperty(value = "实盘数", required = true)
    @Max(value = 5000, message = "数量超过限制,请核实!")
    //2021年1月19日15:57:36 新增权限来控制
//    @Min(value = 0, message = "实盘数不可为负数,请修改后重新提交!")
    private Integer realQty;
}
