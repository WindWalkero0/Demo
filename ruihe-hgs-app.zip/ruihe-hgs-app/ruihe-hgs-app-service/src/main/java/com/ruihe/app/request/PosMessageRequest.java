package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

@ApiModel(value = "PosMessageRequest", description = "消息新增/修改实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosMessageRequest implements Serializable {
    @ApiModelProperty(value = "消息id")
    private Integer msgId;
    @ApiModelProperty(value = "消息标题")
    private String title;
    @ApiModelProperty(value = "正文")
    private String content;
    @ApiModelProperty(value = "定时发送时间")
    private LocalDateTime sendTime;
}
