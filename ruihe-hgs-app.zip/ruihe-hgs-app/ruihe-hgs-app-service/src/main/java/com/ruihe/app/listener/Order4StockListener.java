package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.request.WhU8StockOptRequest;
import com.ruihe.app.vo.u8.U8GoodsReturnItemVo;
import com.ruihe.app.vo.u8.U8GoodsReturnVo;
import com.ruihe.app.vo.u8.U8ShipmentsItemVo;
import com.ruihe.app.vo.u8.U8ShipmentsVo;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.dao.bean.warehouse.WhStockLogPo;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.stock.WhStockBizTypeEnum;
import com.ruihe.app.constant.U8DocumentTypeConfig;
import com.ruihe.app.constant.U8WareHouseConfig;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.enums.OrderTypeEnum;
import com.ruihe.app.event.Order4StockEvent;
import com.ruihe.app.mapper.basic.CounterMapper;
import com.ruihe.app.mapper.basic.ProductMapper;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.app.mapper.order.PosOrderItemMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.request.WhU8StockOptItemRequest;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.app.service.u8.U8MQProducer;
import com.ruihe.app.service.warehouse.StoreInventoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 销售订单事件-库存处理
 *
 * @author William
 */
@Slf4j
@Component
public class Order4StockListener {

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private PosOrderItemMapper posOrderItemMapper;

    @Autowired
    private StoreInventoryService storeInventoryService;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private U8MQProducer u8MQProducer;

    @Autowired
    private MemberMapper memberMapper;

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(Order4StockEvent event) {
        try {
            PosOrderPo orderPo = posOrderMapper.selectById(event.getOrderNo());
            LambdaQueryWrapper<PosOrderItemPo> queryWrapper = Wrappers.<PosOrderItemPo>lambdaQuery()
                    .eq(PosOrderItemPo::getOrderNo, event.getOrderNo());
            List<PosOrderItemPo> posOrderItemList = posOrderItemMapper.selectList(queryWrapper);
            List<WhStockLogPo> whStockLogList = this.extractStockLogList(orderPo, posOrderItemList);
            //事务处理
            storeInventoryService.changeStock(orderPo.getCounterId(), whStockLogList);
            //通知U8
            WhU8StockOptRequest request = this.extractWhU8StockRequest(orderPo, whStockLogList);
            storeInventoryService.syncStockWithU8(request);

            CounterInformation counterInformation = counterMapper.selectById(orderPo.getCounterId());
            String operationalModel = counterInformation.getOperationalModel();
            Integer counterType = counterInformation.getCounterType();
            if (operationalModel.equals(CounterEnum.AGENT_COUNTER.getKey().toString())) {
                //代理商就不同步
                return;
            }
            if (counterType.equals(CounterEnum.TEST_COUNTER.getKey())) {
                //测试柜台不同步
                return;
            }
            //u8不同步测试会员的订单
            //2020年6月17日17:47:53  存在测试会员去正式店买东西的情况去掉这个判断
            if (OrderTypeEnum.BOOK.getCode().equals(orderPo.getOrderType())) {
                //预订单不同步
                return;
            }
            Integer transType = orderPo.getTransType();
            if (transType.equals(OrderTransTypeEnum.GOODS_OUT.getCode())) {
                U8ShipmentsVo u8ShipmentsVo = this.buildSaleOrder(orderPo, posOrderItemList);
                u8MQProducer.saveLog(u8ShipmentsVo.getPoscode());
                u8MQProducer.sendMessageToU8(u8ShipmentsVo, U8DocumentTypeConfig.SASEND_ADD);
            } else if (transType.equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                U8GoodsReturnVo u8GoodsReturnVo = this.buildReturnOrder(orderPo, posOrderItemList);
                u8MQProducer.saveLog(u8GoodsReturnVo.getPoscode());
                u8MQProducer.sendMessageToU8(u8GoodsReturnVo, U8DocumentTypeConfig.RO_ADD);
            }
        } catch (Exception e) {
            log.error("库存处理异常，event{}", JSON.toJSONString(event), e);
        }

    }

    /**
     * 抽取门店扣减库存对象
     *
     * @param orderPo
     * @param posOrderItemList
     * @return
     */
    private List<WhStockLogPo> extractStockLogList(PosOrderPo orderPo, List<PosOrderItemPo> posOrderItemList) {
        //找出非虚拟商品的产品代码
        Set<String> prdBarCodeSet = posOrderItemList.parallelStream()
                .filter(e -> e.getIsVirtual().equals(BigInteger.ZERO.intValue()))
                .map(PosOrderItemPo::getPrdBarCode)
                .collect(Collectors.toSet());
        List<Product> products = productMapper.selectList(Wrappers.<Product>lambdaQuery().in(Product::getPrdBarCode, prdBarCodeSet));
        //排除虚拟商品，重复商品累加数量
        Map<String, Integer> prdCodeQtyMap = posOrderItemList.parallelStream()
                .filter(e -> e.getIsVirtual().equals(BigInteger.ZERO.intValue()))
                .collect(Collectors.groupingBy(PosOrderItemPo::getPrdBarCode, Collectors.summingInt(PosOrderItemPo::getPurQty)));
        return products.parallelStream()
                .map(e -> {
                    Integer qty = prdCodeQtyMap.containsKey(e.getPrdBarCode()) ? prdCodeQtyMap.get(e.getPrdBarCode()) : BigInteger.ZERO.intValue();
                    Integer stock = OrderTransTypeEnum.GOODS_OUT.getCode().equals(orderPo.getTransType()) ? Math.negateExact(Math.abs(qty)) : Math.abs(qty);
                    return WhStockLogPo.builder()
                            .counterId(orderPo.getCounterId())
                            .counterName(orderPo.getCounterName())
                            .baCode(orderPo.getBaCode())
                            .baName(orderPo.getBaName())
                            .bizType(extractBizType(orderPo))
                            .bizNo(orderPo.getOrderNo())
                            .bizTime(orderPo.getBizTime())
                            .prdBarCode(e.getPrdBarCode())
                            .prdName(e.getPrdName())
                            .goodsBarCode(e.getGoodsBarCode())
                            .qty(stock)
                            .prdPrice(e.getSalePrice())
                            .memberPrice(e.getMemberPrice())
                            .bigCatCode(e.getBigCatCode())
                            .bigCatName(e.getBigCatName())
                            .mediumCatCode(e.getMediumCatCode())
                            .mediumCatName(e.getMediumCatName())
                            .smallCatCode(e.getSmallCatCode())
                            .smallCatName(e.getSmallCatName())
                            .build();
                }).collect(Collectors.toList());
    }

    private String extractBizType(PosOrderPo orderPo) {
        if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(orderPo.getTransType())) {
            return WhStockBizTypeEnum.SALES.getCode();
        }
        if (OrderTransTypeEnum.GOODS_RETURN.getCode().equals(orderPo.getTransType())) {
            return WhStockBizTypeEnum.SALES_RETURN.getCode();
        }
        return null;
    }

    /**
     * 抽取U8库存接口操作
     *
     * @param orderPo
     * @param stockLogList
     * @return
     */
    private WhU8StockOptRequest extractWhU8StockRequest(PosOrderPo orderPo, List<WhStockLogPo> stockLogList) {
        WhU8StockOptRequest request = WhU8StockOptRequest.builder()
                .bizType(WhStockBizTypeEnum.SALES.getCode())
                .bizNo(orderPo.getOrderNo())
                .bizTime(orderPo.getBizTime())
                .counterId(orderPo.getCounterId())
                .counterName(orderPo.getCounterName())
                .build();
        List<WhU8StockOptItemRequest> itemList = stockLogList.parallelStream().map(e ->
                WhU8StockOptItemRequest.builder()
                        .bizType(e.getBizType())
                        .bizNo(e.getBizNo())
                        .bizTime(e.getBizTime())
                        .counterId(e.getCounterId())
                        .counterName(e.getCounterName())
                        .prdBarCode(e.getPrdBarCode())
                        .prdName(e.getPrdName())
                        .goodsBarCode(e.getGoodsBarCode())
                        .qty(e.getQty())
                        .build()
        ).collect(Collectors.toList());
        request.setItemRequestList(itemList);
        return request;
    }

    /**
     * 同步到u8的发货单
     */
    private U8ShipmentsVo buildSaleOrder(PosOrderPo orderPo, List<PosOrderItemPo> posOrderItemList) {
        Integer i = 0;
        List<U8ShipmentsItemVo> u8ShipmentsItemVoList = new ArrayList<>();
        for (PosOrderItemPo e : posOrderItemList) {
            i++;
            U8ShipmentsItemVo test = U8ShipmentsItemVo
                    .builder()
                    .inventory_code(e.getIsVirtual() == 0 ? e.getPrdBarCode() : U8WareHouseConfig.Virtual)
                    .warehouse_code(e.getCounterId())
                    .quantity(e.getPurQty())
                    .taxrate(BigDecimal.ZERO)
                    .price(e.getSalePrice())
                    .taxpricel(e.getSalePrice())
                    .money(e.getAmount())
                    .tax(BigDecimal.ZERO)
                    .sum(e.getAmount())
                    .poslineid(i)
                    .memo("")
                    .build();
            u8ShipmentsItemVoList.add(test);
        }
        //U8那边要的发货单数据类型和字段（表头）
        U8ShipmentsVo build = U8ShipmentsVo.builder()
                .poscode(orderPo.getOrderNo())
                .operation_type("普通销售")
                .saletype("自营销售(02)")
                .custcode(orderPo.getCounterId())
                .deptcode(U8WareHouseConfig.DirectManagementDepartment)
                .cPersonCode(U8WareHouseConfig.HandledBy)
                .dDate(orderPo.getBizTime())
                .memo("商品销售")
                .Body(u8ShipmentsItemVoList).build();
        //把对象推送到MQ
        return build;
    }

    /**
     * 同步到u8的退货单
     */
    private U8GoodsReturnVo buildReturnOrder(PosOrderPo orderPo, List<PosOrderItemPo> posOrderItemList) {
        //U8那边要的退货单数据类型和字段（表体）
        Integer i = 0;
        List<U8GoodsReturnItemVo> u8GoodsReturnItemVoList = new ArrayList<>();
        for (PosOrderItemPo e : posOrderItemList) {
            i++;
            U8GoodsReturnItemVo test = U8GoodsReturnItemVo
                    .builder()
                    .inventory_code(e.getIsVirtual() == 0 ? e.getPrdBarCode() : U8WareHouseConfig.Virtual)
                    .u8sendlineid(null)
                    .warehouse_code(e.getCounterId())
                    .quantity(e.getPurQty())
                    .taxrate(BigDecimal.ZERO)
                    .price(e.getSalePrice())
                    .taxpricel(e.getSalePrice())
                    .money(e.getAmount())
                    .tax(BigDecimal.ZERO)
                    .sum(e.getAmount())
                    .poslineid(i)
                    .memo("")
                    .build();
            u8GoodsReturnItemVoList.add(test);
        }
        //U8那边要的发货单数据类型和字段（表头）
        U8GoodsReturnVo build = U8GoodsReturnVo.builder()
                .poscode(orderPo.getOrderNo())
                .operation_type("普通销售")
                .saletype("自营销售(02)")
                .custcode(orderPo.getCounterId())
                .deptcode(U8WareHouseConfig.DirectManagementDepartment)
                .u8sendcode("")
                .cPersonCode(U8WareHouseConfig.HandledBy)
                .dDate(orderPo.getBizTime())
                .memo("商品退货")
                .Body(u8GoodsReturnItemVoList).build();
        //把对象推送到MQ
        return build;
    }
}
