package com.ruihe.app.response;

import com.alibaba.fastjson.JSONArray;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.poi.hpsf.Decimal;

import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author huangjie
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NurInvandSalesPlanResponse {

    private String inviteId;

    private String phone;

    private String memberId;

    private String memberName;

    private String baCode;

    private String baName;

    private String counterId;

    private String counterName;

    /**
     * 护理项目ID
     */
    private JSONArray nursingId;

    /**
     * 护理项目名称
     */
    private JSONArray nursingItem;

    /**
     * 护理数量
     */
    private Integer inviteQty;

    /**
     * 预约途径不能为空
     */
    private Integer inviteType;

    /**
     * 状态 0已预约 1已完成 2已取消
     */
    private Integer nursingStatus;

    /**
     * 预约时间
     */
    private LocalDateTime inviteTime;

    /**
     * 备注
     */
    @Size(max = 50, message = "备注最大长度为50个字符")
    private String remark;

    /**
     * 规划金额
     */
    private BigDecimal planAmt;

    /**
     * 规划护理id
     */
    private JSONArray planNursingId;

    /**
     * 规划护理项
     */
    private JSONArray planNursingItem;

}