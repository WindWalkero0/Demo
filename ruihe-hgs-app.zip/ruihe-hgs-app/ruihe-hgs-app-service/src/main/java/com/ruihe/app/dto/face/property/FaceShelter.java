package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class FaceShelter {
    private Integer exist;
    private Types types;
}
