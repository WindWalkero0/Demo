package com.ruihe.app.service.face;

import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.dto.face.property.*;
import com.ruihe.app.request.AIOverviewRequest;
import com.ruihe.app.response.AIComprehensive.*;
import com.ruihe.app.response.AIOverviewResponse;
import com.ruihe.common.dao.bean.wx.WxCardInfoPo;
import com.ruihe.common.enums.wx.WxCardStatusEnum;
import com.ruihe.common.dao.mapper.WxCardInfoPoMapper;
import com.ruihe.app.dto.face.AiFaceDTO;
import com.ruihe.app.dto.face.LabelOverviewInfo;
import com.ruihe.app.dto.face.LabelProblemInfo;
import com.ruihe.app.mapper.face.AiFaceMapper;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.app.po.face.AiFacePO;
import com.ruihe.app.response.AIComprehensiveResponse;
import com.ruihe.app.response.AIOverviewCheckResponse;
import com.ruihe.common.constant.AiFaceConstant;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.dao.mapper.fa.ParameterConfigMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.ruihe.common.constant.AiFaceConstant.whitelistCode;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toMap;

/**
 * 小程序里Ai面部检测的service
 */
@Service
@Slf4j
public class AIFaceService {
    @Value("${wechat.cardId}")
    private String cardId;
    @Value("${file-upload.static-root-url}")
    private String staticRootUrl;

    @Resource
    private AiFaceMapper aiFaceMapper;

    @Resource
    private ParameterConfigMapper parameterConfigMapper;

    @Resource
    private MemberMapper memberMapper;

    @Resource
    private WxCardInfoPoMapper wxCardInfoPoMapper;

    private final AIFaceBaseService aiFaceBaseService;

    public AIFaceService(AIFaceBaseService aiFaceBaseService) {
        this.aiFaceBaseService = aiFaceBaseService;
    }

    /**
     * 检查是否能够进行AI肤质检测,如果从未检测过neverTest为false,后续可以调用CLife测肤结果;如果已经进行过肤质测试,将返回肤质检测结果概览信息.
     *
     * @param unionId unionId
     * @return 检测结果
     */
    public AIOverviewCheckResponse checkIsCanDoAIFaceTest(String unionId) {

        //检查是否有会员
        var wxCardWhere = Wrappers.<WxCardInfoPo>lambdaQuery()
                .eq(WxCardInfoPo::getUnionId, unionId)
                .eq(WxCardInfoPo::getCardId, cardId);
        var wxCardInfoPo = wxCardInfoPoMapper.selectOne(wxCardWhere);
        if (ObjectUtils.isEmpty(wxCardInfoPo)) {
            //未查询到会员领卡信息
            return AIOverviewCheckResponse.builder().neverTest(true).build();
        }

        //如果卡券是非激活状态,需要返回从未测试过(前端后续会去调用是否需要激活接口去激活)
        if (!wxCardInfoPo.getStatus().equals(WxCardStatusEnum.EFFECTIVE.getCode())) {
            return AIOverviewCheckResponse.builder().neverTest(true).build();
        }

        //查看白名单中是否有该会员,有的话可以多次测肤
        boolean existThisMember = this.checkCurrentMemberIsInWhiteList(wxCardInfoPo.getMemberId());
        if (existThisMember) {
            return AIOverviewCheckResponse.builder().neverTest(true).build();
        }

        //检查之前是否检测过肤质
        var aiFaceWhere = Wrappers.<AiFacePO>lambdaQuery()
                .eq(AiFacePO::getMemberId, wxCardInfoPo.getMemberId())
                .orderByDesc(AiFacePO::getCreateTime);
        var aiFaceList = aiFaceMapper.selectList(aiFaceWhere);
        if (CollectionUtils.isEmpty(aiFaceList)) {
            return AIOverviewCheckResponse.builder().neverTest(true).build();
        }

        final AiFacePO aiFacePOLatest = aiFaceList.get(0);
        var aiFaceDTO = aiFaceBaseService.convert2DTO(aiFacePOLatest);
        return AIOverviewCheckResponse.builder()
                .neverTest(false)
                .aiOverviewResponse(this.getAiOverviewResponse(aiFaceDTO, aiFacePOLatest.getCreateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))))
                .build();
    }

    /**
     * 保存AI肤质检测结果并返回检测结果概览信息
     *
     * @param request 肤质检测详情数据
     * @return 检测结果概览信息
     */
    public AIOverviewResponse saveAiFaceTestResultAndProviderOverviewInfo(AIOverviewRequest request) {
        //检查是否有会员
        var wxCardWhere = Wrappers.<WxCardInfoPo>lambdaQuery()
                .eq(WxCardInfoPo::getUnionId, request.getUnionId())
                .eq(WxCardInfoPo::getCardId, cardId);
        var wxCardInfoPo = wxCardInfoPoMapper.selectOne(wxCardWhere);
        if (ObjectUtils.isEmpty(wxCardInfoPo)) {
            log.error("未查询到会员领卡信息,unionId={},cardId={}", request.getUnionId(), cardId);
            throw new BizException("未查询到会员领卡信息");
        }

        boolean existThisMember = this.checkCurrentMemberIsInWhiteList(wxCardInfoPo.getMemberId());
        if (!existThisMember) {
            //没在白名单内的只能测肤一次,否则就要报错了
            var aiFaceWhere = Wrappers.<AiFacePO>lambdaQuery().eq(AiFacePO::getMemberId, wxCardInfoPo.getMemberId());
            if (aiFaceMapper.selectCount(aiFaceWhere) > 1) {
                log.error("已经存在肤质检测记录,请检查调用接口是否正确!,memberId={}", wxCardInfoPo.getMemberId());
                throw new BizException("已经存在肤质检测记录,请检查调用接口是否正确!");
            }
        }

        //保存检测结果到数据库
        var facePo = request.convert2PO();
        facePo.setMemberId(wxCardInfoPo.getMemberId());
        facePo.setCreateTime(LocalDateTime.now());
        facePo.setFaceOriginImage(facePo.getFaceOriginImage().replace(staticRootUrl, ""));
        aiFaceMapper.insert(facePo);
        var aiFaceDTO = request.getAiFaceDTO();
        aiFaceDTO.setId(facePo.getId());
        return this.getAiOverviewResponse(request.getAiFaceDTO(), facePo.getCreateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    }

    /**
     * 获取AI肤质检测报告的各项描述
     *
     * @param id AI检测结果ID
     * @return response
     */
    public AIComprehensiveResponse getComprehensiveInfo(String id) {

        var aiFacePO = aiFaceMapper.selectById(id);

        //将PO对象转换为DTO
        var aiFaceDTO = aiFaceBaseService.convert2DTO(aiFacePO);
        aiFaceDTO.setFaceOriginImage(String.format("%s%s", staticRootUrl, aiFacePO.getFaceOriginImage()));

        var labelInfoSortedMap = this.setLabelOverviewInfo(aiFaceDTO);//报告简述2

        //综合评分
        var deductScore = labelInfoSortedMap.values().stream().mapToInt(LabelOverviewInfo::getDeduct).sum();
        var finalScore = BigDecimal.valueOf(1000 + deductScore).divide(BigDecimal.valueOf(10), 0, RoundingMode.HALF_EVEN);

        //肤质信息
        var skinTypeLevelDegree = labelInfoSortedMap.get(AiFaceConstant.skinType).getMaxLevelName();
        var sensitivityLevelDegree = labelInfoSortedMap.get(AiFaceConstant.sensitivity).getMaxLevelName();
        var faceColorLevelDegree = labelInfoSortedMap.get(AiFaceConstant.facecolor).getMaxLevelName();
        final SkinInfo skinInfo = new SkinInfo();
        skinInfo.setSkinType(skinTypeLevelDegree);
        skinInfo.setSensitivity(sensitivityLevelDegree);
        skinInfo.setFacecolor(faceColorLevelDegree);
        skinInfo.setSkinAge(aiFaceDTO.getSkinAge());

        //实时水油
        var moistureName = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.moisture, "level", labelInfoSortedMap.get(AiFaceConstant.moisture).getMaxLevel());
        var oilName = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.oil, "level", labelInfoSortedMap.get(AiFaceConstant.oil).getMaxLevel());
        var waterOilInfo = new WaterOil();
        waterOilInfo.setWater(moistureName);
        waterOilInfo.setOil(oilName);

        //肤质
        var skinTypeDescriptionEnum = aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.skintype);
        var skinTypeDescription = skinTypeDescriptionEnum.get(String.valueOf(aiFaceDTO.getSkinType()));
        var skinTypeInfo = new SkinType();
        skinTypeInfo.setProperty(skinTypeLevelDegree);
        skinTypeInfo.setDescription(skinTypeDescription);

        //肤色
        var faceColorDescriptionEnum = aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.facecolor);
        var faceColorDescription = faceColorDescriptionEnum.get(aiFaceDTO.getFacecolor());
        var faceColorInfo = new Facecolor();
        faceColorInfo.setPropertyChinese(faceColorLevelDegree);
        faceColorInfo.setDescription(faceColorDescription);

        var scoreDetail = labelInfoSortedMap.values().stream()
                .filter(e -> !e.getDeduct().equals(0))
                .peek(e -> {
                    if (e.getLabel().equals(AiFaceConstant.moisture)) {
                        e.setLabelName("");
                    }
                })
                .map(e -> String.format("%s%s %s分",
                        e.getMaxLevelName(),
                        e.getLabelName(),
                        BigDecimal.valueOf(e.getDeduct()).divide(BigDecimal.valueOf(10), 0, RoundingMode.HALF_EVEN).toString()))
                .collect(Collectors.toList());
        //健康指标
        var healthInfo = this.getHealthInfo(labelInfoSortedMap);
        var response = new AIComprehensiveResponse();
        response.setTotalScore(finalScore.compareTo(BigDecimal.valueOf(42)) < 0 ? "42" : finalScore.toString());
        response.setScoreDetail(scoreDetail);
        response.setImage(aiFaceDTO.getFaceOriginImage());
        response.setSkinInfo(skinInfo);
        response.setWaterOil(waterOilInfo);
        response.setSkinType(skinTypeInfo);
        response.setFacecolor(faceColorInfo);
        response.setHealth(healthInfo);

        return response;
    }

    /**
     * 获取AI肤质检测报告问题详情
     *
     * @param id AI检测结果ID
     * @return response
     */
    public List<HashMap<String, Object>> getLabelProblemResults(String id) {

        var aiFacePO = aiFaceMapper.selectById(id);
        if (ObjectUtils.isEmpty(aiFacePO)) {
            log.error("未查询到测肤记录,id={}", id);
            throw new BizException("未查询到测肤记录");
        }

        //将PO对象转换为DTO
        var aiFaceDTO = aiFaceBaseService.convert2DTO(aiFacePO);
        aiFaceDTO.setFaceOriginImage(String.format("%s%s", staticRootUrl, aiFacePO.getFaceOriginImage()));

        var result = this.getLabelProblemDetail(aiFaceDTO);
        return result.stream().sorted(Comparator.comparing(LabelProblemInfo::getFixLevel).reversed()).filter(e -> e.getFixLevel() > 1)
                .collect(groupingBy(LabelProblemInfo::getFixLevel))
                .entrySet().stream().map(e -> {
                    var res = new HashMap<String, Object>();
                    res.put("level", e.getKey());
                    res.put("data", e.getValue());
                    return res;
                }).collect(Collectors.toList());
    }

    /**
     * 将等级为轻微、中度、重度的问题指标的详细数据整理出来
     *
     * @param aiFaceDTO aiFaceDTO
     * @return 指标的问题详情
     */
    private List<LabelProblemInfo> getLabelProblemDetail(AiFaceDTO aiFaceDTO) {

        /*  oil        严重等级（1-无，2-轻微，3-严重） <br>
         * moisture   严重等级（1-滋润，2-轻度缺水，3-重度缺水）<br>
         * pore       严重等级（1-紧致，2-轻度，3-中度，4-重度）<br>
         * wrinkles   严重等级（1-无，2-轻度，3-中度，4-重度）<br>
         * sensitivity严重等级（1-无，2-轻度，3-中度, 4-重度）<br>
         * acnes      严重等级（1-无，2-轻度，3-中度，4-重度）<br>
         * pigmentations严重等级（1-无，2-轻度，3-中度，4-重度）<br>
         * blackhead   严重等级（1-无，2-极少，3-轻度，4-中度，5-重度）<br>
         * darkCircle  严重等级（1-无，2-轻微，3-严重）<br>
         * fatGranule  严重等级（1-无，2-轻，3-重）<br>*/
        //---------------------------水油平衡------------------------------------
        var moistureMax = aiFaceDTO.getMoisture().stream().max(Comparator.comparing(Moisture::getLevel)).orElseThrow(() -> {
            log.error("AI检测过结果返回水分数据有问题,moisture={}", aiFaceDTO.getMoisture());
            return new BizException("系统繁忙请稍后再试");
        });
        var oilMax = aiFaceDTO.getOil().stream().max(Comparator.comparing(Oil::getLevel)).orElseThrow(() -> {
            log.error("AI检测过结果返回油分数据有问题,oil={}", aiFaceDTO.getOil());
            return new BizException("系统繁忙请稍后再试");
        });
        //取"水分"和"油分"中等级最严重的的显示
        String moistureOilMaxLevel;
        String moistureOilMaxAreaRatio;
        String moistureOilMaxLayer;
        if (moistureMax.getLevel() > oilMax.getLevel()) {
            moistureOilMaxLevel = (moistureMax.getLevel() > 2) ? "重度" : "轻度";
            moistureOilMaxAreaRatio = aiFaceDTO.getMoistureOverall().getAreaRatio();
            moistureOilMaxLayer = aiFaceDTO.getMoistureMaskPath();
        } else {
            moistureOilMaxLevel = oilMax.getLevel() > 2 ? "重度" : "轻度";
            moistureOilMaxAreaRatio = aiFaceDTO.getOilOverall().getAreaRatio();
            moistureOilMaxLayer = aiFaceDTO.getOilMaskPath();
        }
        var moistureMetaInfo = LabelProblemInfo.builder()
                .label(AiFaceConstant.moisture)
                .areaRatio(aiFaceDTO.getMoistureOverall().getAreaRatio())
                .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.moisture))
                .type(aiFaceBaseService.getLabelChinese(AiFaceConstant.moisture))
                .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.moisture, "level", moistureMax.getLevel()))
                .description(aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.moisture).get(String.format("%s:%s", moistureMax.getLevel(), moistureMax.getFacePart())))
                .layer(aiFaceDTO.getMoistureMaskPath())
                .image(aiFaceDTO.getFaceOriginImage())
                .fixLevel(this.fixDegreeWhenLevelIs3(moistureMax.getLevel()))
                .build();
        var oilMetaInfo = LabelProblemInfo.builder()
                .label(AiFaceConstant.oil)
                .type(aiFaceBaseService.getLabelChinese(AiFaceConstant.oil))
                .areaRatio(aiFaceDTO.getOilOverall().getAreaRatio())
                .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.oil))
                .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.oil, "level", oilMax.getLevel()))
                .description(aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.oil).get(String.format("%s:%s", oilMax.getLevel(), oilMax.getFacePart())))
                .layer(aiFaceDTO.getOilMaskPath())
                .image(aiFaceDTO.getFaceOriginImage())
                .fixLevel(this.fixDegreeWhenLevelIs3(oilMax.getLevel()))
                .build();
        var waterOilInfo = LabelProblemInfo.builder()
                .label("waterOil")
                .labelChinese("水油失衡")
                .type("水油失衡")
                .level(moistureOilMaxLevel)
                .areaRatio(moistureOilMaxAreaRatio)
                .layer(moistureOilMaxLayer)
                .image(aiFaceDTO.getFaceOriginImage())
                .detailInfo(List.of(moistureMetaInfo, oilMetaInfo))
                .fixLevel(this.fixDegreeWhenLevelIs3(oilMax.getLevel()))
                .build();//水油
        //---------------------------毛孔------------------------------------
        var poreInfo = LabelProblemInfo.builder()
                .label(AiFaceConstant.pore)
                .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.pore))
                .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.pore, "level", aiFaceDTO.getPore().getLevel()))
                .number(aiFaceDTO.getPore().getNumber())
                .description(aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.pore).get(String.format("%s", aiFaceDTO.getPore().getLevel())))
                .layer(aiFaceDTO.getMoistureMaskPath())
                .image(aiFaceDTO.getFaceOriginImage())
                .fixLevel(aiFaceDTO.getPore().getLevel())
                .build();
        //---------------------------细纹------------------------------------
        var wrinkle = aiFaceDTO.getWrinkles();
        var wrinklesMaxLevel = wrinkle.stream().max(Comparator.comparing(Wrinkles::getLevel)).orElseThrow(() -> {
            log.error("AI检测过结果返回毛孔数据有问题,wrinkle={}", wrinkle);
            return new BizException("系统繁忙请稍后再试");
        });
        var wrinklesDetail = wrinkle.stream().filter(Wrinkles::getProblemData).map(e -> LabelProblemInfo.builder()
                .label(AiFaceConstant.wrinkles)
                .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.wrinkles))
                .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.wrinkles, "level", e.getLevel()))
                .type(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.wrinkles, "wrinkleTypeId", e.getWrinkleTypeId()))
                .description(aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.wrinkles).get(String.format("%s:%s", e.getWrinkleTypeId(), e.getLevel())))
                .areaRatio(this.calWrinklesAreaRatio(wrinkle))
                .fixLevel(e.getLevel())
                .build()).collect(Collectors.toList());
        var wrinklesInfo = LabelProblemInfo.builder()
                .label(AiFaceConstant.wrinkles)
                .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.wrinkles))
                .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.wrinkles, "level", wrinklesMaxLevel.getLevel()))
                .layer(aiFaceDTO.getWrinkleLayer())
                .image(aiFaceDTO.getFaceOriginImage())
                .areaRatio(this.calWrinklesAreaRatio(wrinkle))
                .detailInfo(wrinklesDetail)
                .fixLevel(wrinklesMaxLevel.getLevel())
                .build();
        //---------------------------敏感------------------------------------
        var maxSensitivity = aiFaceDTO.getSensitivity().getSensitivityCategory().stream().max(Comparator.comparing(SensitivityCategory::getLevel)).orElseThrow(() -> {
            log.error("AI检测过结果返回敏感肌数据有问题,sensitivity={}", aiFaceDTO.getSensitivity().getSensitivityCategory());
            return new BizException("系统繁忙请稍后再试");
        });
        var sensitivityInfo = LabelProblemInfo.builder()
                .label(AiFaceConstant.sensitivity)
                .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.sensitivity))
                .areaRatio(aiFaceDTO.getSensitivity().getSensitivityOverall().getAreaRatio())
                .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.sensitivity, "level", maxSensitivity.getLevel()))
                .facePart(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.sensitivity, "facePart", maxSensitivity.getFacePart()))
                .layer(aiFaceDTO.getSensitivity().getSensitivityMaskPath())
                .image(aiFaceDTO.getFaceOriginImage())
                .fixLevel(maxSensitivity.getLevel())
                .description(aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.sensitivity).get(String.format("%s", aiFaceDTO.getPore().getLevel())))
                .build();
        //---------------------------痘痘------------------------------------
        var acnes = aiFaceDTO.getAcnes();
        var acnesMaxLevel = acnes.stream().max(Comparator.comparing(Acnes::getLevel)).orElseThrow(() -> {
            log.error("AI检测过结果返回痘痘数据有问题,acnes={}", acnes);
            return new BizException("系统繁忙请稍后再试");
        });
        //按类型分类,因为问题展示是按类型来区分的
        var acesInfo = acnes.stream().filter(Acnes::getProblemData).collect(groupingBy(Acnes::getAcneTypeId)).values().stream().map(typesLevelAndPart -> {
            //按类型分类痘痘的等级和数量
            //每个类型中最严重的等级
            var maxLevel = typesLevelAndPart.stream().max(Comparator.comparing(Acnes::getLevel)).orElseThrow(() -> {
                log.error("AI检测过结果返回痘痘数据有问题,acnes={}", acnes);
                return new BizException("系统繁忙请稍后再试");
            });
            return LabelProblemInfo.builder()
                    .label(AiFaceConstant.wrinkles)
                    .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.acnes))
                    .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.acnes, "level", maxLevel.getLevel()))
                    .type(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.acnes, "acneTypeId", maxLevel.getAcneTypeId()))
                    .facePart(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.acnes, "facePart", maxLevel.getFacePart()))
                    .description(aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.acnes).get(String.format("%s:%s:%s", maxLevel.getAcneTypeId(), maxLevel.getLevel(), maxLevel.getFacePart())))
                    .number(maxLevel.getNumber())
                    .fixLevel(maxLevel.getLevel())
                    .build();
        }).collect(Collectors.toList());
        var acnesInfo = LabelProblemInfo.builder()
                .label(AiFaceConstant.acnes)
                .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.acnes))
                .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.acnes, "level", acnesMaxLevel.getLevel()))
                .layer(aiFaceDTO.getAcneLayer())
                .image(aiFaceDTO.getFaceOriginImage())
                .number(acnesMaxLevel.getNumber())
                .detailInfo(acesInfo)
                .fixLevel(acnesMaxLevel.getLevel())
                .build();
        //---------------------------色斑------------------------------------
        var pigmentations = aiFaceDTO.getPigmentations();
        var pigmentationsMaxLevel = pigmentations.stream().max(Comparator.comparing(Pigmentations::getLevel)).orElseThrow(() -> {
            log.error("AI检测过结果返回色斑数据有问题,pigmentations={}", pigmentations);
            return new BizException("系统繁忙请稍后再试");
        });
        //按类型分类,因为问题展示是按类型来区分的
        var pigmentationsDetail = pigmentations.stream().filter(Pigmentations::getProblemData)
                .collect(groupingBy(Pigmentations::getPigmentationTypeId))
                .values().stream().map(typesLevelAndPart -> {
                    //按类型分类色斑的等级和数量
                    //每个类型中最严重的等级
                    var maxLevel = typesLevelAndPart.stream().max(Comparator.comparing(Pigmentations::getLevel)).orElseThrow(() -> {
                        log.error("AI检测过结果返回色斑数据有问题,pigmentations={}", pigmentations);
                        return new BizException("系统繁忙请稍后再试");
                    });
                    return LabelProblemInfo.builder()
                            .label(AiFaceConstant.pigmentations)
                            .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.pigmentations))
                            .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.pigmentations, "level", maxLevel.getLevel()))
                            .type(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.pigmentations, "pigmentationTypeId", maxLevel.getPigmentationTypeId()))
                            .facePart(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.pigmentations, "facePart", maxLevel.getFacePart()))
                            .description(aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.pigmentations).get(String.format("%s:%s:%s", maxLevel.getPigmentationTypeId(), maxLevel.getLevel(), maxLevel.getFacePart())))
                            .areaRatio(maxLevel.getAreaRatio())
                            .fixLevel(maxLevel.getLevel())
                            .build();
                }).collect(Collectors.toList());
        var pigmentationsInfo = LabelProblemInfo.builder()
                .label(AiFaceConstant.pigmentations)
                .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.pigmentations))
                .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.pigmentations, "level", pigmentationsMaxLevel.getLevel()))
                .layer(aiFaceDTO.getAcneLayer())
                .image(aiFaceDTO.getFaceOriginImage())
                .detailInfo(pigmentationsDetail)
                .areaRatio(pigmentationsMaxLevel.getAreaRatio())
                .fixLevel(pigmentationsMaxLevel.getLevel())
                .build();
        //---------------------------黑头------------------------------------
        var blackHeadInfo = LabelProblemInfo.builder()
                .label(AiFaceConstant.blackhead)
                .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.blackhead))
                .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.blackhead, "level", aiFaceDTO.getBlackHead().getLevel()))
                .number(aiFaceDTO.getBlackHead().getNumber())
                .description(aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.blackhead).get(String.format("%s", aiFaceDTO.getBlackHead().getLevel())))
                .layer(aiFaceDTO.getBlackHead().getMaskPath())
                .image(aiFaceDTO.getFaceOriginImage())
                .fixLevel(this.fixDegreeWhenLevelIs5(aiFaceDTO.getBlackHead().getLevel()))//黑头
                .build();
        //---------------------------黑眼圈------------------------------------
        var darkCircle = aiFaceDTO.getDarkCircle();
        var maxDarkCircle = darkCircle.stream().max(Comparator.comparing(DarkCircle::getLevel)).orElseThrow(() -> {
            log.error("AI检测过结果返回黑眼圈数据有问题,pigmentations={}", pigmentations);
            return new BizException("系统繁忙请稍后再试");
        });
        var darkCircleDetail = darkCircle.stream().filter(DarkCircle::getProblemData).collect(groupingBy(DarkCircle::getType)).values().stream().map(e -> {
            var maxType = e.stream().max(Comparator.comparing(DarkCircle::getLevel)).orElseThrow(() -> {
                log.error("AI检测过结果返回黑眼圈数据有问题,e={}", e);
                return new BizException("系统繁忙请稍后再试");
            });
            return LabelProblemInfo.builder()
                    .label(AiFaceConstant.darkcircle)
                    .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.fatgranule))
                    .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.darkcircle, "level", maxType.getLevel()))
                    .type(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.darkcircle, "type", maxType.getType()))
                    .description(aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.darkcircle).get(String.format("%s:%s", maxType.getType(), maxType.getLevel())))
                    .fixLevel(this.fixDegreeWhenLevelIs3(maxType.getLevel()))
                    .build();
        }).collect(Collectors.toList());
        var darkcircleInfo = LabelProblemInfo.builder()
                .label(AiFaceConstant.darkcircle)
                .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.darkcircle))
                .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.darkcircle, "level", maxDarkCircle.getLevel()))
                .type(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.darkcircle, "type", maxDarkCircle.getType()))
                .description(aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.darkcircle).get(String.format("%s:%s", maxDarkCircle.getType(), maxDarkCircle.getLevel())))
                .layer(aiFaceDTO.getDarkCircleMaskPath())
                .image(aiFaceDTO.getFaceOriginImage())
                .detailInfo(darkCircleDetail)
                .fixLevel(this.fixDegreeWhenLevelIs3(maxDarkCircle.getLevel()))//黑眼圈
                .build();
        //---------------------------脂肪粒------------------------------------
        var fatGranule = aiFaceDTO.getFatGranule();
        var fatGranuleLevel = fatGranule.stream().max(Comparator.comparing(FatGranule::getLevel)).orElseThrow(() -> {
            log.error("AI检测过结果返回脂肪粒数据有问题,fatGranule={}", fatGranule);
            return new BizException("系统繁忙请稍后再试");
        });
        var fatGranuleDetail = fatGranule.stream().filter(FatGranule::getProblemData).map(e -> LabelProblemInfo.builder()
                .label(AiFaceConstant.fatgranule)
                .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.fatgranule))
                .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.fatgranule, "level", e.getLevel()))
                .type(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.fatgranule, "fatGranuleTypeId", e.getFatGranuleTypeId()))
                .description(aiFaceBaseService.getDescriptionConfigFromRedis(AiFaceConstant.fatgranule).get(String.format("%s:%s", e.getFatGranuleTypeId(), e.getLevel())))
                .number(e.getNumber())
                .fixLevel(this.fixDegreeWhenLevelIs3(e.getLevel()))
                .build())
                .collect(Collectors.toList());
        var fatGranuleInfo = LabelProblemInfo.builder()
                .label(AiFaceConstant.fatgranule)
                .labelChinese(aiFaceBaseService.getLabelChinese(AiFaceConstant.fatgranule))
                .level(aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.fatgranule, "level", fatGranuleLevel.getLevel()))
                .layer(fatGranuleLevel.getMaskPath())
                .image(aiFaceDTO.getFaceOriginImage())
                .detailInfo(fatGranuleDetail)
                .number(fatGranuleLevel.getNumber())
                .fixLevel(this.fixDegreeWhenLevelIs3(fatGranuleLevel.getLevel()))//脂肪粒
                .build();

        return List.of(waterOilInfo, poreInfo, wrinklesInfo, sensitivityInfo, acnesInfo, pigmentationsInfo, blackHeadInfo, darkcircleInfo, fatGranuleInfo);
    }

    /**
     * @param aiFaceDTO  测肤结果DTO
     * @param createTime 创建时间
     * @return 结果预览
     */
    private AIOverviewResponse getAiOverviewResponse(AiFaceDTO aiFaceDTO, String createTime) {

        //获取每个指标整理后的值
        var labelInfoSortedMap = this.setLabelOverviewInfo(aiFaceDTO);//结果预览1
        //计算最后的得分
        var deductScore = labelInfoSortedMap.values().stream().mapToInt(LabelOverviewInfo::getDeduct).sum();
        var finalScore = BigDecimal.valueOf(1000 + deductScore).divide(BigDecimal.valueOf(10), 0, RoundingMode.HALF_EVEN);


        final AIOverviewResponse aiOverviewResponse = new AIOverviewResponse();
        //总分
        aiOverviewResponse.setTotalScore(finalScore.compareTo(BigDecimal.valueOf(42)) < 0 ? "42" : finalScore.toString());
        //测肤时间
        aiOverviewResponse.setTestTime(createTime);
        //肤质文字描述
        aiOverviewResponse.setSkin(String.format("%s，%s", labelInfoSortedMap.get(AiFaceConstant.skinType).getMaxLevelName(), labelInfoSortedMap.get(AiFaceConstant.sensitivity).getMaxLevelName()));
        //肤色文字描述
        aiOverviewResponse.setFacecolor(labelInfoSortedMap.get(AiFaceConstant.facecolor).getMaxLevelName());
        //问题文字描述
        aiOverviewResponse.setProblem(this.getProblemDescription(labelInfoSortedMap));
        aiOverviewResponse.setId(aiFaceDTO.getId());
        return aiOverviewResponse;
    }

    /**
     * 获取到每个标签整理合成后的数据
     *
     * @param aiFaceDTO AI肤质检测结果
     * @return 每个指标整理后的数据
     */
    private Map<String, LabelOverviewInfo> setLabelOverviewInfo(AiFaceDTO aiFaceDTO) {

        //减分指标  肤色,痘痘...->黑眼圈
        //描述指标  肤色,痘痘...->黑眼圈+脂肪粒+肤质

        //肤色 肤色分数配置取值有点特殊,因为对应值实在太多了(单独需要配置取值需要新增66条数),现在配置为相同肤色的取值只配一条数据,通过判断是否包含该值来取对应的文字 详情请看t_ai_face_score_config
        int faceColorScore = aiFaceBaseService.getScoreConfigFromRedis(AiFaceConstant.facecolor)
                .entrySet().stream().filter(e -> e.getKey().contains(aiFaceDTO.getFacecolor()))
                .map(Map.Entry::getValue).findFirst().orElse(0);
        var faceColorLevelChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.facecolor, "facecolor", aiFaceDTO.getFacecolor());
        var faceColorLabelChinese = aiFaceBaseService.getLabelChinese(AiFaceConstant.facecolor);
        var faceColorInfo = LabelOverviewInfo.builder()
                .label(AiFaceConstant.facecolor)
                .labelName(faceColorLabelChinese)
                .maxLevelName(faceColorLevelChinese)
                .deduct(faceColorScore)
                .build();

        //痘痘
        int acnesScore = aiFaceDTO.getAcnes().stream().mapToInt(e -> {
            final String propertyValue = String.format("%s:%s", e.getAcneTypeId(), e.getLevel());
            return aiFaceBaseService.getScoreConfigFromRedis(AiFaceConstant.acnes).get(propertyValue);
        }).sum();
        var acnesMax = aiFaceDTO.getAcnes().stream().max(Comparator.comparing(Acnes::getLevel)).orElseThrow(() -> new BizException("检测结果中痘痘标签返回数据有问题"));
        var acnesLabelChines = aiFaceBaseService.getLabelChinese(AiFaceConstant.acnes);
        var acnesLevelChines = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.acnes, "level", acnesMax.getLevel());
        var acnesTypeChines = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.acnes, "acneTypeId", acnesMax.getAcneTypeId());
        var acnesInfo = LabelOverviewInfo.builder()
                .label(AiFaceConstant.acnes)
                .labelName(acnesLabelChines)
                .maxLevel(acnesMax.getLevel())
                .fixLevel(acnesMax.getLevel())
                .maxLevelName(acnesLevelChines)
                .maxType(acnesMax.getAcneTypeId())
                .maxTypeName(acnesTypeChines)
                .deduct(acnesScore)
                .build();

        //色斑
        int pigmentationsScore = aiFaceDTO.getPigmentations().stream().mapToInt(e -> {
            final String propertyValue = String.format("%s:%s", e.getPigmentationTypeId(), e.getLevel());
            return aiFaceBaseService.getScoreConfigFromRedis(AiFaceConstant.pigmentations).get(propertyValue);
        }).sum();
        var maxPigmentations = aiFaceDTO.getPigmentations().stream().max(Comparator.comparing(Pigmentations::getLevel)).orElseThrow(() -> new BizException("检测结果中色斑标签返回数据有问题"));
        var pigmentationsLabelChinese = aiFaceBaseService.getLabelChinese(AiFaceConstant.pigmentations);
        var pigmentationsTypeChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.pigmentations, "pigmentationTypeId", maxPigmentations.getPigmentationTypeId());
        var pigmentationsLevelChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.pigmentations, "level", maxPigmentations.getLevel());

        var pigmentationsInfo = LabelOverviewInfo.builder()
                .label(AiFaceConstant.pigmentations)
                .labelName(pigmentationsLabelChinese)
                .deduct(pigmentationsScore)
                .maxType(maxPigmentations.getPigmentationTypeId())
                .maxTypeName(pigmentationsTypeChinese)
                .maxLevel(maxPigmentations.getLevel())
                .fixLevel(maxPigmentations.getLevel())
                .maxLevelName(pigmentationsLevelChinese)
                .build();

        //细纹
        int wrinklesScore = aiFaceDTO.getWrinkles().stream().mapToInt(e -> {
            final String propertyValue = String.format("%s:%s", e.getWrinkleTypeId(), e.getLevel());
            return aiFaceBaseService.getScoreConfigFromRedis(AiFaceConstant.wrinkles).get(propertyValue);
        }).sum();
        var maxWrinkles = aiFaceDTO.getWrinkles().stream().max(Comparator.comparing(Wrinkles::getLevel)).orElseThrow(() -> new BizException("检测结果中细纹标签返回数据有问题"));
        var wrinklesLabelChinese = aiFaceBaseService.getLabelChinese(AiFaceConstant.wrinkles);
        var wrinklesTypeChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.wrinkles, "wrinkleTypeId", maxWrinkles.getWrinkleTypeId());
        var wrinklesLevelChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.wrinkles, "level", maxWrinkles.getLevel());
        var wrinklesInfo = LabelOverviewInfo.builder()
                .label(AiFaceConstant.wrinkles)
                .labelName(wrinklesLabelChinese)
                .deduct(wrinklesScore)
                .maxType(maxWrinkles.getWrinkleTypeId())
                .maxTypeName(wrinklesTypeChinese)
                .maxLevel(maxWrinkles.getLevel())
                .fixLevel(maxWrinkles.getLevel())
                .maxLevelName(wrinklesLevelChinese)
                .build();

        //眼袋
        int pouchLevel = aiFaceDTO.getPouch().getLevel();
        int pouchScore = aiFaceBaseService.getScoreConfigFromRedis(AiFaceConstant.pouch).get(String.valueOf(pouchLevel));
        var pouchLabelChinese = aiFaceBaseService.getLabelChinese(AiFaceConstant.pouch);
        var pouchLevelChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.pouch, "level", pouchLevel);

        var pouchInfo = LabelOverviewInfo.builder()
                .label(AiFaceConstant.pouch)
                .labelName(pouchLabelChinese)
                .maxLevel(pouchLevel)
                .fixLevel(pouchLevel)
                .maxLevelName(pouchLevelChinese)
                .deduct(pouchScore)
                .build();

        //黑头
        int blackHeadLevel = aiFaceDTO.getBlackHead().getLevel();
        int blackHeadScore = aiFaceBaseService.getScoreConfigFromRedis(AiFaceConstant.blackhead).get(String.valueOf(blackHeadLevel));
        var blackHeadLabelChinese = aiFaceBaseService.getLabelChinese(AiFaceConstant.blackhead);
        var blackHeadLevelChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.blackhead, "level", blackHeadLevel);

        var blackHeadInfo = LabelOverviewInfo.builder()
                .label(AiFaceConstant.blackhead)
                .labelName(blackHeadLabelChinese)
                .deduct(blackHeadScore)
                .maxLevel(blackHeadLevel)
                .fixLevel(this.fixDegreeWhenLevelIs5(blackHeadLevel))
                .maxLevelName(blackHeadLevelChinese)
                .maxNumber(aiFaceDTO.getBlackHead().getNumber())
                .build();

        //毛孔
        final Integer pornLevel = aiFaceDTO.getPore().getLevel();
        int poreScore = aiFaceBaseService.getScoreConfigFromRedis(AiFaceConstant.pore).get(String.valueOf(pornLevel));
        var poreHeadLabelChinese = aiFaceBaseService.getLabelChinese(AiFaceConstant.pore);
        var poreHeadLevelChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.pore, "level", pornLevel);
        var poreInfo = LabelOverviewInfo.builder()
                .label(AiFaceConstant.pore)
                .labelName(poreHeadLabelChinese)
                .deduct(poreScore)
                .maxLevel(pornLevel)
                .fixLevel(pornLevel)
                .maxLevelName(poreHeadLevelChinese)
                .maxNumber(aiFaceDTO.getPore().getNumber())
                .build();

        //敏感
        int sensitivityMaxLevel = aiFaceDTO.getSensitivity().getSensitivityCategory().stream().mapToInt(SensitivityCategory::getLevel).max()
                .orElseThrow(() -> new BizException("分数配置表中敏感度严重等级配置错误"));
        int sensitivityScore = aiFaceBaseService.getScoreConfigFromRedis(AiFaceConstant.sensitivity).get(String.valueOf(sensitivityMaxLevel));
        var sensitivityLabelChinese = aiFaceBaseService.getLabelChinese(AiFaceConstant.sensitivity);
        var sensitivityLevelChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.sensitivity, "level", sensitivityMaxLevel);
        var sensitivitySorted = LabelOverviewInfo.builder()
                .label(AiFaceConstant.sensitivity)
                .labelName(sensitivityLabelChinese)
                .deduct(sensitivityScore)
                .maxLevel(sensitivityMaxLevel)
                .fixLevel(sensitivityMaxLevel)
                .maxLevelName(sensitivityLevelChinese)
                .build();

        //水分
        int moistureMaxLevel = aiFaceDTO.getMoisture().stream().mapToInt(Moisture::getLevel).max()
                .orElseThrow(() -> new BizException("分数配置表中水分严重等级配置错误"));
        int moistureScore = aiFaceBaseService.getScoreConfigFromRedis(AiFaceConstant.moisture).get(String.valueOf(moistureMaxLevel));
        var moistureLabelChinese = aiFaceBaseService.getLabelChinese(AiFaceConstant.moisture);
        var moistureLevelChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.moisture, "level", moistureMaxLevel);
        var moistureInfo = LabelOverviewInfo.builder()
                .label(AiFaceConstant.moisture)
                .labelName(moistureLabelChinese)
                .deduct(moistureScore)
                .maxLevel(moistureMaxLevel)
                .fixLevel(this.fixDegreeWhenLevelIs3(moistureMaxLevel))//水分
                .maxLevelName(moistureLevelChinese)
                .build();

        //油分
        int oilMaxLevel = aiFaceDTO.getOil().stream().mapToInt(Oil::getLevel).max()
                .orElseThrow(() -> new BizException("分数配置表中油分程度配置错误"));
        int oilScore = aiFaceBaseService.getScoreConfigFromRedis(AiFaceConstant.oil).get(String.valueOf(oilMaxLevel));
        var oilLabelChinese = aiFaceBaseService.getLabelChinese(AiFaceConstant.oil);
        var oilLevelChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.oil, "level", oilMaxLevel);

        var oilInfo = LabelOverviewInfo.builder()
                .label(AiFaceConstant.oil)
                .labelName(oilLabelChinese)
                .deduct(oilScore)
                .maxLevel(oilMaxLevel)
                .fixLevel(this.fixDegreeWhenLevelIs3(oilMaxLevel))//油分
                .maxLevelName(oilLevelChinese)
                .build();

        //黑眼圈
        final Map<Integer, Integer> positionAndMaxLevel = aiFaceDTO.getDarkCircle().stream()
                .collect(toMap(DarkCircle::getPosition, DarkCircle::getLevel, (d1, d2) -> d1 > d2 ? d1 : d2));
        final int darkCircleScore = positionAndMaxLevel.entrySet().stream().mapToInt(e -> {
            final Integer position = e.getKey();
            final Integer maxLevel = e.getValue();
            final String propertyValue = String.format("%s:%s", position, maxLevel);
            return aiFaceBaseService.getScoreConfigFromRedis(AiFaceConstant.darkcircle).get(propertyValue);
        }).sum();
        var maxDarkCircle = aiFaceDTO.getDarkCircle().stream().max(Comparator.comparing(DarkCircle::getLevel)).orElseThrow(() -> new BizException("检测结果中黑眼圈标签返回数据有问题"));
        var darkCircleLabelChinese = aiFaceBaseService.getLabelChinese(AiFaceConstant.darkcircle);
        var darkCircleTypeChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.darkcircle, "type", maxDarkCircle.getType());
        var darkCircleLevelChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.darkcircle, "level", maxDarkCircle.getLevel());

        var darkCircleInfo = LabelOverviewInfo.builder()
                .label(AiFaceConstant.darkcircle)
                .labelName(darkCircleLabelChinese)
                .deduct(darkCircleScore)
                .maxType(maxDarkCircle.getType())
                .maxTypeName(darkCircleTypeChinese)
                .maxLevel(maxDarkCircle.getLevel())
                .fixLevel(this.fixDegreeWhenLevelIs3(maxDarkCircle.getLevel()))//黑眼圈
                .maxLevelName(darkCircleLevelChinese)
                .build();

        //脂肪粒
        final FatGranule maxGranule = aiFaceDTO.getFatGranule().stream().max(Comparator.comparing(FatGranule::getLevel)).orElseThrow(() -> new BizException("检测结果中脂肪粒返回数据有问题"));
        var fatGranuleLabelChinese = aiFaceBaseService.getLabelChinese(AiFaceConstant.fatgranule);
        var fatGranuleTypeChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.fatgranule, "fatGranuleTypeId", maxGranule.getFatGranuleTypeId());
        var fatGranuleLevelChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.fatgranule, "level", maxGranule.getLevel());
        var granuleInfo = LabelOverviewInfo.builder()
                .label(AiFaceConstant.fatgranule)
                .labelName(fatGranuleLabelChinese)
                .deduct(0)
                .maxNumber(maxGranule.getNumber())
                .maxLevel(maxGranule.getLevel())
                .fixLevel(this.fixDegreeWhenLevelIs3(maxGranule.getLevel()))//脂肪粒
                .maxLevelName(fatGranuleLevelChinese)
                .maxTypeName(fatGranuleTypeChinese)
                .build();

        //肤质
        var skinLabelChinese = aiFaceBaseService.getLabelChinese(AiFaceConstant.skintype);
        var skinTypeChinese = aiFaceBaseService.getLabelPropertyValueChinese(AiFaceConstant.skintype, "skinType", aiFaceDTO.getSkinType());
        var skinTypeInfo = LabelOverviewInfo.builder()
                .label(AiFaceConstant.skintype)
                .labelName(skinLabelChinese)
                .deduct(0)
                .maxLevel(aiFaceDTO.getSkinType())
                .fixLevel(aiFaceDTO.getSkinType())
                .maxLevelName(skinTypeChinese)
                .build();

        return List.of(faceColorInfo,
                acnesInfo,
                pigmentationsInfo,
                wrinklesInfo,
                pouchInfo,
                blackHeadInfo,
                poreInfo,
                sensitivitySorted,
                moistureInfo,
                oilInfo,
                darkCircleInfo,
                granuleInfo,
                skinTypeInfo).stream().collect(toMap(LabelOverviewInfo::getLabel, Function.identity()));

    }

    /**
     * 从很多的大类的属性中拼接出前端需要的文字
     *
     * @param labelInfoSortedMap 每个大类重新整理分类完之后的属性值（因为有的属性是返回的列表集合，需要找出最严重的属性做展示）
     * @return 文字描述
     */
    private String getProblemDescription(Map<String, LabelOverviewInfo> labelInfoSortedMap) {

        List<String> description = new ArrayList<>();

        //脂肪粒：类型和数量（无则不显示）
        //level 严重等级（1-无，2-轻，3-重）
        final LabelOverviewInfo fatgranule = labelInfoSortedMap.get(AiFaceConstant.fatgranule);
        if (fatgranule.thisLabelIsProblemData()) {
            final String descri = fatgranule.getMaxTypeName() + fatgranule.getMaxNumber() + "粒";
            description.add(descri);
        }

        //斑：等级（仅展示最严重一种类型）
        //level 严重等级（1-无，2-轻度，3-中度，4-重度）
        //pigmentationTypeId 色素斑类型（1-黑痣，2-黄褐斑，3-雀斑，4-隐藏斑）
        final LabelOverviewInfo pigmentations = labelInfoSortedMap.get(AiFaceConstant.pigmentations);
        if (pigmentations.thisLabelIsProblemData()) {
            final String descri = pigmentations.getMaxLevelName() + pigmentations.getMaxTypeName();
            description.add(descri);
        }

        //皱纹：等级（仅展示最严重一种类型）
        //type  细纹类型（1-抬头纹，2-法令纹，3-泪沟，4-笑肌断层,5-鱼尾纹,6-眉间纹）
        //level 严重等级（1-无，2-轻度，3-中度，4-重度）
        final LabelOverviewInfo wrinkles = labelInfoSortedMap.get(AiFaceConstant.wrinkles);
        if (wrinkles.thisLabelIsProblemData()) {
            final String descri = wrinkles.getMaxLevelName() + wrinkles.getMaxTypeName();
            description.add(descri);
        }

        //黑头：数量（无则不展示）
        //level  严重等级（1-无，2-极少，3-轻度，4-中度，5-重度）
        //number  黑头数量
        final LabelOverviewInfo blackHead = labelInfoSortedMap.get(AiFaceConstant.blackhead);
        if (blackHead.thisLabelIsProblemData()) {
            final String descri = String.format("黑头%s颗", blackHead.getMaxNumber());
            description.add(descri);
        }

        //毛孔：等级（无则不展示）
        //level  严重等级（1-紧致，2-轻度，3-中度，4-重度）
        //number 毛孔数量
        final LabelOverviewInfo pore = labelInfoSortedMap.get(AiFaceConstant.pore);
        if (pore.thisLabelIsProblemData()) {
            final String descri = pore.getMaxLevelName() + "毛孔";
            description.add(descri);
        }

        //黑眼圈：等级（无则不展示）
        //level number 严重等级（1-无，2-轻微，3-严重）
        final LabelOverviewInfo darkCircle = labelInfoSortedMap.get(AiFaceConstant.darkcircle);
        if (darkCircle.thisLabelIsProblemData()) {
            final String descri = darkCircle.getMaxLevelName() + "黑眼圈";
            description.add(descri);
        }
        return String.join("、", description);
    }

    private List<Health> getHealthInfo(Map<String, LabelOverviewInfo> labelInfoSortedMap) {

        var healthLabel = List.of(
                AiFaceConstant.pouch,
                AiFaceConstant.pore,
                AiFaceConstant.pigmentations,
                AiFaceConstant.wrinkles,
                AiFaceConstant.sensitivity,
                AiFaceConstant.acnes,
                AiFaceConstant.blackhead,
                AiFaceConstant.darkcircle,
                AiFaceConstant.fatgranule);

        var healthInfo = labelInfoSortedMap.values().stream().filter(e -> healthLabel.contains(e.getLabel())).map(e -> {
            var _health = new Health();
            _health.setLabel(e.getLabelName());
            _health.setLevel(e.getFixLevel());
            _health.setLevelName(e.getMaxLevelName());
            return _health;
        }).collect(Collectors.toList());

        //水油失衡
        var moistureSorted = labelInfoSortedMap.get(AiFaceConstant.moisture);
        var oilSorted = labelInfoSortedMap.get(AiFaceConstant.oil);
        var waterOil = new Health();
        waterOil.setLabel("水油失衡");
        if (moistureSorted.getMaxLevel() > oilSorted.getMaxLevel()) {
            waterOil.setLevel(moistureSorted.getFixLevel());
            waterOil.setLevelName(moistureSorted.getMaxLevelName());
        } else {
            waterOil.setLevel(oilSorted.getFixLevel());
            waterOil.setLevelName(oilSorted.getMaxLevelName());
        }
        healthInfo.add(waterOil);
        return healthInfo;
    }

    /**
     * （1-无，2-轻微，3-严重）转换为
     * （1-紧致，2-轻度，3-中度，4-重度）
     */
    private Integer fixDegreeWhenLevelIs3(Integer level) {
        switch (level) {
            case 2:
                return 2;
            case 3:
                return 4;
            case 1:
            default:
                return 1;
        }
    }

    /**
     * （1-无，2-极少，3-轻度，4-中度，5-重度）转换为
     * （1-紧致，2-轻度，3-中度，4-重度）
     */
    private Integer fixDegreeWhenLevelIs5(Integer level) {
        switch (level) {
            case 3:
                return 2;
            case 4:
                return 3;
            case 5:
                return 4;
            case 2:
            default:
                return 1;
        }
    }

    /**
     * 计算面积占比公式 累加各维度面积值，有左右的，左右都要加起来，一起求和。然后这个（整体面积*100）/3000000
     *
     * @param wrinkles wrinkles
     * @return 计算结果
     */
    private String calWrinklesAreaRatio(List<Wrinkles> wrinkles) {
        /*
        面积占比=（整体面积*100）/3,000,000
        整体面积=泪沟面积+法令纹面积+鱼尾纹面积+抬头纹面积+笑肌断层面积+眉间纹面积
        单类细纹面积=left+right，如果某类细纹left和right没有值那么，该单类细纹面积=area
        */
        var areaRatioSum = wrinkles.stream().mapToInt(e -> {
            int areaRatio = 0;
            if (ObjectUtils.isNotEmpty(e.getLeft()) || ObjectUtils.isNotEmpty(e.getRight())) {
                if (ObjectUtils.isNotEmpty(e.getLeft())) {
                    areaRatio += e.getLeft();
                }
                if (ObjectUtils.isNotEmpty(e.getRight())) {
                    areaRatio += e.getRight();
                }
                if (ObjectUtils.isNotEmpty(e.getOverallArea())) {
                    areaRatio += e.getOverallArea().getLeft() + e.getOverallArea().getRight();
                }
            } else {
                areaRatio += StringUtils.isNotBlank(e.getArea()) ? Integer.parseInt(e.getArea()) : 0;
            }
            return areaRatio;
        }).sum();
        return String.valueOf(BigDecimal.valueOf(areaRatioSum * 100).divide(BigDecimal.valueOf(3000000), 2, RoundingMode.HALF_UP));
    }


    /**
     * 检查当前会员是否在会员白名单内,之内的话可以多次测肤
     *
     * @param memberId memberId
     * @return 结果
     */
    private boolean checkCurrentMemberIsInWhiteList(String memberId) {
        var memberInfo = memberMapper.selectById(memberId);
        var parameterConfigPo = parameterConfigMapper.selectById(whitelistCode);
        return JSONArray.parseArray(parameterConfigPo.getValue(), String.class).stream().anyMatch(e -> e.equals(memberInfo.getMobilePhone()));
    }

}
