package com.ruihe.app.enums;

/**
 * 验证码
 * @author
 */
public enum WXEnum {
    /**
     * 限定每天获取短信验证码次数
     **/
    FREQUENCY(5, "五次");

    private Integer code;
    private String msg;


    WXEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
