package com.ruihe.app.service.integral;

import com.alibaba.fastjson.JSONObject;

/**
 * 规则接口定义,适用于准入规则和奖励规则
 *
 * @author William
 */
public interface IntegralRule {
    public MatchResult match(JSONObject conf, RuleContext rc);
}
