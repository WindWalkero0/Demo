package com.ruihe.app.response.material;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**

/**
 * @author qubin
 * @date 2021年07月06日 13:03
 */
@ApiModel(value = "MaterialPicDetailResponse", description = "导购助手-资料级别响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MaterialPicDetailResponse implements Serializable {

    @ApiModelProperty("项目集合")
    private List<MaterialProjectResponse> projectResponseList;

    @ApiModelProperty("图片对象集合")
    private List<MaterialLevelResponse> picList;
}
