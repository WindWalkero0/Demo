package com.ruihe.app.service.member;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.event.CancelAndAddCouponEvent;
import com.ruihe.app.event.MsgEvent;
import com.ruihe.app.mapper.basic.CounterInfoMapper;
import com.ruihe.app.mapper.deposit.DepositBoxOrderMapper;
import com.ruihe.app.mapper.member.*;
import com.ruihe.app.mapper.order.PosAuthorityMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.po.crm.MemberInfoMessagePo;
import com.ruihe.app.po.deposit.DepositBoxOrderPo;
import com.ruihe.app.request.MemberPurchaseRequest;
import com.ruihe.app.response.MemberConsumeVo;
import com.ruihe.app.service.basic.AboutCounterService;
import com.ruihe.app.service.integral.IntegralService;
import com.ruihe.app.vo.MemberVo;
import com.ruihe.app.vo.PurchaseVo;
import com.ruihe.app.vo.member.MemberInfoVo;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.annotation.FieldName;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.constant.MsgerTplConstant;
import com.ruihe.common.constant.RedisPrefixKeyConst;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.dao.bean.member.*;
import com.ruihe.common.dao.bean.nursing.NursingRecordPO;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.dao.bean.rgebox.DepositBoxPo;
import com.ruihe.common.dao.bean.rgebox.DepositBoxStockPo;
import com.ruihe.common.dao.bean.system.SystemConfigPo;
import com.ruihe.common.dao.bean.wx.WxCardInfoPo;
import com.ruihe.common.dao.mapper.*;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.member.MemberInfoEnum;
import com.ruihe.common.enums.member.MemberLevelEnum;
import com.ruihe.common.enums.member.MemberLevelLogBizTypeEnum;
import com.ruihe.common.enums.member.MemberLevelRuleTypeEnum;
import com.ruihe.common.enums.order.ProgramTypeEnum;
import com.ruihe.common.enums.prefix.PrefixEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.enums.system.SystemConfigEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.pojo.context.holder.PosUserContextHolder;
import com.ruihe.common.pojo.request.member.MemberOperationRequest;
import com.ruihe.common.response.Response;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.service.*;
import com.ruihe.common.service.event.NewMemberCacheEvent;
import com.ruihe.common.service.event.OnlyAddCouponEvent;
import com.ruihe.common.utils.IPUtils;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.RegularUtil;
import com.ruihe.common.utils.TimeUtils;
import com.ruihe.msger.dto.MsgerRequestDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
public class MemberService implements ApplicationContextAware {

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private MemberLevelLogMapper memberLevelLogMapper;

    @Autowired
    private MemberLevelMapper memberLevelMapper;

    @Autowired
    private MemberLevelRuleMapper memberLevelRuleMapper;

    @Autowired
    private MemberActivityMapper memberActivityMapper;

    @Autowired
    private CustomService customService;

    @Autowired
    private AboutCounterService aboutCounterService;

    @Autowired
    private IntegralService integralService;

    @Autowired
    private CommonService commonService;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private DepositBoxMemberStockMapper depositBoxMemberStockMapper;

    @Autowired
    private DepositBoxMapper depositBoxMapper;

    @Autowired
    private MemberCouponSingleOperation memberCouponSingleOperation;

    @Autowired
    private DepositBoxOrderMapper depositBoxOrderMapper;

    @Autowired
    private WxCardInfoPoMapper wxCardInfoPoMapper;

    @Autowired
    private PosAuthorityMapper posAuthorityMapper;

    @Autowired
    private SystemConfigMapper systemConfigMapper;

    @Autowired
    private RedisCacheService redisService;

    @Autowired
    private CounterInfoMapper counterInfoMapper;

    @Autowired
    private MemberInvcodeService memberInvcodeService;

    private ApplicationContext applicationContext;

    @Autowired
    private MemberOrderSearchMapper memberOrderSearchMapper;

    @Autowired
    private NursingRecordMapper nursingRecordMapper;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Ella(Describe = "填充默认等级")
    public void fillLevel(MemberInfo memberInfo) {
        memberInfo.setMemberLevelCode("WMLC006");
        memberInfo.setMemberLevel(MemberLevelEnum.EXPERIENCED_MEMBER.getKey());
        memberInfo.setMemberLevelName(MemberLevelEnum.EXPERIENCED_MEMBER.getValue());
    }

    /**
     * pos端新增会员</br>
     * 2021-03-19 口碑礼（邀请有礼）活动拿掉推荐人手机号</br>
     *
     * @param memberOperationRequest
     * @return
     * @throws Exception
     */
    @Ella(Describe = "添加会员", Author = "K")
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addMember(MemberOperationRequest memberOperationRequest) throws Exception {
        MemberInfo memberInfo = new MemberInfo();
        BeanUtils.copyProperties(memberOperationRequest.getMemberInfo(), memberInfo);
        //会员等级信息默认填充
        fillLevel(memberInfo);
        //2020-05-16 上午处理会员姓名为空格/回车的情况--BUG单号1742
        if (org.apache.commons.lang3.StringUtils.isBlank(memberInfo.getMemberName().replaceAll("\\s*", ""))) {
            return Response.errorMsg("请输入会员姓名!");
        }
        memberInfo.setMemberName(memberInfo.getMemberName().replaceAll("\\s*", ""));
        //判断手机号规则
        if (org.apache.commons.lang3.StringUtils.isBlank(memberInfo.getMobilePhone())) {
            return Response.errorMsg("手机号不能为空!");
        }
        if (!memberInfo.getMobilePhone().matches(RegularUtil.REGEX_MOBILE)) {
            return Response.errorMsg("手机号不合法!");
        }
        MemberInfo memberInfo2 = customService.select(MemberInfo.builder().mobilePhone(memberInfo.getMobilePhone()).build());
        if (memberInfo2 != null) {
            return Response.errorMsg(MemberInfoEnum.MEMBER_NAME_EXIT.getValue());
        }
        MemberInfo select = customService.select(MemberInfo.builder().memberCardNumber(memberInfo.getMobilePhone()).build());
        if (select != null) {
            return Response.errorMsg("会员卡号已经存在");
        }
        //检测推荐会员是否存在，口碑礼（邀请有礼）活动拿掉推荐人手机号,2021-03-19
        /**
         if (!StringUtils.isEmpty(memberInfo.getRcmdMemberPhone())) {
         Integer status = checkMember(memberInfo.getRcmdMemberPhone());
         if (!status.equals(StatusEnum.SUCCESS.getKey())) {
         return Response.errorMsg(MemberInfoEnum.instance(status).getValue());
         }
         MemberInfo memberInfo1 = selectMemberInfo(MemberInfo.builder().mobilePhone(memberInfo.getRcmdMemberPhone()).build());
         memberInfo.setRcmdMemberId(memberInfo1.getMemberId());
         memberInfo.setRcmdMemberPhone(memberInfo1.getMobilePhone());
         memberInfo.setRcmdMemberName(memberInfo1.getMemberName());
         }*/
        //获取邀请码
        String invCode = memberInvcodeService.retrieve();
        memberInfo.setInvCode(invCode);
        //填充数据
        memberInfo.setMemberId(IdGenerator.getShorterSerialNo(PrefixEnum.MR.getCode()));
        memberInfo.setStatus(CommonStatusEnum.EFFECTIVE.getCode());
        memberInfo.setCreateTime(LocalDateTime.now());
        memberInfo.setCardIssuingTime(TimeUtils.longFormatString(System.currentTimeMillis()));//发卡时间
        memberInfo.setUpdateTime(LocalDateTime.now());
        memberOperationRequest.setMemberInfo(memberInfo.convert2DTO());
        //会员类型判断
        memberTypeJudge(memberInfo);
        //填充履历信息并保存
        fillOperation(memberOperationRequest);
        //生成积分信息
        saveIntegralAccount(IntegralAccountPo
                .builder()
                .avlQty(0)
                .expiringQty(0)
                .memberId(memberInfo.getMemberId())
                .memberName(memberInfo.getMemberName())
                .memberPhone(memberInfo.getMobilePhone())
                .counterId(memberInfo.getCounterId())
                .counterName(memberInfo.getCounterName())
                .totalQty(0)
                .newQty(0)
                .oldQty(0)
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build());
        //判断会员等级信息
        if (StringUtils.isEmpty(memberInfo.getMemberLevelName())) {
            memberInfo.setMemberLevelName(MemberLevelEnum.EXPERIENCED_MEMBER.getValue());
            memberInfo.setMemberLevel(MemberLevelEnum.EXPERIENCED_MEMBER.getKey());
        }
        //设置会员等级的有效时间
        memberInfo.setLevelStartTime(LocalDateTime.now());
        memberInfo.setLevelEndTime(getEndTime(memberInfo.getMemberLevel()));
        //会员等级修改履历
        MemberLevelLog memberLevelLog = fillMemberLevelLog(memberInfo);
        Integer rows = memberLevelLogMapper.insert(memberLevelLog);
        if (rows == 0) {
            log.error("会员等级履历修改失败,memberLevelLog={}", memberLevelLog);
            throw new BizException("会员等级履历修改失败");
        }
        //新会员发送营销短信--added by William
        MsgerRequestDto smsRequest = MsgerRequestDto.builder()
                .contact(memberInfo.getMobilePhone())
                .template(MsgerTplConstant.SMS_MKT_MEMBER_ENTRANCE)
                .ip(IPUtils.getLocalIP())
                .build();
        applicationContext.publishEvent(new MsgEvent(this, smsRequest));
        Integer save = customService.save(memberInfo);
        if (save.equals(0)) {
            log.error("添加会员失败,memberInfo={}", memberInfo);
            throw new BizException("添加会员失败");
        }
        //判断寄存箱中是否存在信息
        doDeposit(memberInfo);
        //新增会员之后需要执行的事件
        NewMemberCacheEvent newMemberCacheEvent = new NewMemberCacheEvent(memberInfo);
        this.applicationContext.publishEvent(newMemberCacheEvent);
        OnlyAddCouponEvent onlyAddCouponEvent = new OnlyAddCouponEvent(memberInfo.getMemberId());
        this.applicationContext.publishEvent(onlyAddCouponEvent);
        return Response.success(StatusEnum.SUCCESS.getValue());
    }

    private void doDeposit(MemberInfo memberInfo) {
        //根据手机号查询过往数据(如果更换了手机号，此处处理的数据可能不全)
        List<DepositBoxPo> depositBoxPos = depositBoxMapper.selectList(Wrappers.<DepositBoxPo>lambdaQuery()
                .eq(DepositBoxPo::getMemberPhone, memberInfo.getMobilePhone())
                .and(e ->
                        e.eq(DepositBoxPo::getMemberId, org.apache.commons.lang3.StringUtils.EMPTY).or().isNull(DepositBoxPo::getMemberId)
                ));
        if (!depositBoxPos.isEmpty()) {
            //如果不为空，说明这个会员之前存在非会员寄存的情况，需要进行更新寄存箱
            List<Integer> boxIdList = depositBoxPos.stream().map(DepositBoxPo::getBoxId).collect(Collectors.toList());
            //更新寄存箱
            Integer rows = depositBoxMapper.update(DepositBoxPo.builder()
                    .memberId(memberInfo.getMemberId())
                    .memberName(memberInfo.getMemberName())
                    .build(), Wrappers.<DepositBoxPo>lambdaUpdate()
                    .in(DepositBoxPo::getBoxId, boxIdList));
            if (rows == 0) {
                throw new BizException("更新寄存箱信息失败!");
            }
        }
        //根据手机号查询存取记录
        List<DepositBoxOrderPo> depositBoxOrderPoList = depositBoxOrderMapper.selectList(Wrappers.<DepositBoxOrderPo>lambdaQuery()
                .eq(DepositBoxOrderPo::getMemberPhone, memberInfo.getMobilePhone())
                .isNull(DepositBoxOrderPo::getMemberId));
        if (!depositBoxOrderPoList.isEmpty()) {
            List<String> orderList = depositBoxOrderPoList.stream().map(DepositBoxOrderPo::getOrderId).collect(Collectors.toList());
            Integer rows = depositBoxOrderMapper.update(DepositBoxOrderPo.builder()
                    .memberId(memberInfo.getMemberId())
                    .memberName(memberInfo.getMemberName())
                    .build(), Wrappers.<DepositBoxOrderPo>lambdaUpdate()
                    .in(DepositBoxOrderPo::getOrderId, orderList));
            if (rows == 0) {
                throw new BizException("更新寄存箱存取记录信息失败!");
            }
        }
        //根据手机号查询库存信息
        List<DepositBoxStockPo> depositBoxStockPos = depositBoxMemberStockMapper.selectList(Wrappers.<DepositBoxStockPo>lambdaQuery()
                .eq(DepositBoxStockPo::getMemberPhone, memberInfo.getMobilePhone())
                .isNull(DepositBoxStockPo::getMemberId));
        if (!depositBoxStockPos.isEmpty()) {
            List<Integer> stockList = depositBoxStockPos.stream().map(DepositBoxStockPo::getStockId).collect(Collectors.toList());
            Integer rows = depositBoxMemberStockMapper.update(DepositBoxStockPo.builder()
                    .memberId(memberInfo.getMemberId())
                    .memberName(memberInfo.getMemberName())
                    .build(), Wrappers.<DepositBoxStockPo>lambdaUpdate()
                    .in(DepositBoxStockPo::getStockId, stockList));
            if (rows == 0) {
                throw new BizException("更新寄存箱库存信息失败!");
            }
        }
    }

    /**
     * 填充会员等级修改履历
     *
     * @param memberInfo
     * @return
     */
    private MemberLevelLog fillMemberLevelLog(MemberInfo memberInfo) {
        return MemberLevelLog.builder()
                .memberId(memberInfo.getMemberId())
                .status(CommonStatusEnum.EFFECTIVE.getCode())
                .levelStartTime(memberInfo.getLevelStartTime())
                .levelEndTime(memberInfo.getLevelEndTime())
                .levelCodeAfter(memberInfo.getMemberLevelCode())
                .levelNameAfter(memberInfo.getMemberLevelName())
                .changeType(MemberLevelRuleTypeEnum.UPGRADE.getKey())
                .businessType(MemberLevelLogBizTypeEnum.MEMBER_INFORMATION.getKey())
                .changeReason("会员资料上传")
                .levelAfter(memberInfo.getMemberLevel())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
    }

    @Ella(Describe = "会员类型判断", Author = "K")
    @DS(DBConst.SLAVE)
    public void memberTypeJudge(MemberInfo memberInfo) {
        //判断是否是测试会员
        CounterInformation counterInformation = aboutCounterService.selectCounterAll(memberInfo.getCounterId());
        Integer counterType = counterInformation.getCounterType();
        if (counterType.equals(CounterEnum.TEST_COUNTER.getKey())) {//测试柜台
            memberInfo.setMemberType(0);
        } else if (counterType.equals(CounterEnum.FORMAL_COUNTER.getKey())) {//正式柜台
            memberInfo.setMemberType(1);
        } else {
            log.error("不存在的柜台类型{}", counterInformation);
            throw new BizException("柜台:" + counterInformation.getCounterName() + "的柜台类型为" + counterInformation.getCounterType() + "属于未知类型");
        }
    }

    /**
     * pos端新增会员</br>
     * 2021-03-19 口碑礼（邀请有礼）活动拿掉推荐人手机号</br>
     *
     * @param memberOperationRequest
     * @return
     * @throws Exception
     */
    @Ella(Describe = "修改会员", Author = "K")
    @DS(DBConst.MASTER)
    public Response editMember(MemberOperationRequest memberOperationRequest) throws Exception {
        MemberInfo memberInfo = new MemberInfo();
        BeanUtils.copyProperties(memberOperationRequest.getMemberInfo(), memberInfo);
        memberInfo.setMemberType(null);
        memberInfo.setMemberLevel(null);
        memberInfo.setMemberLevelCode(null);
        memberInfo.setMemberLevelName(null);
        memberInfo.setBaName(null);
        memberInfo.setBaId(null);
        memberInfo.setCounterId(null);
        memberInfo.setCounterName(null);
        //检测会员信息是否重复
        Integer code = checkMember(memberInfo, 1);
        if (!code.equals(StatusEnum.SUCCESS.getKey())) {
            return Response.error(code, MemberInfoEnum.instance(code).getValue());
        }
        //检测推荐会员是否存在，口碑礼（邀请有礼）活动拿掉推荐人手机号,2021-03-19
        /**
         if (!StringUtils.isEmpty(memberInfo.getRcmdMemberPhone())) {
         Integer status = checkMember(memberInfo.getRcmdMemberPhone());
         if (!status.equals(StatusEnum.SUCCESS.getKey())) {
         return Response.errorMsg("推荐会员手机号不存在,请核对后重试");
         }
         MemberInfo memberInfoOther = customService.select(MemberInfo.builder().mobilePhone(memberInfo.getRcmdMemberPhone()).build());
         memberInfo.setRcmdMemberId(memberInfoOther.getMemberId());
         }*/
        //生成修改履历并保存
        fillOperation(memberOperationRequest);
        //记录保修改时间
        memberInfo.setUpdateTime(LocalDateTime.now());
        //进行保存
        updateMember(memberInfo, MemberInfo.builder().memberId(memberInfo.getMemberId()).build());
        return Response.success(StatusEnum.SUCCESS.getValue());
    }

    /**
     * 首单销售，判定会员等级之后，对会员信息进行更新
     *
     * @param memberRule
     * @param orderNo
     * @param memberInfo
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void updateMemberLevel(MemberRule memberRule, String orderNo, MemberInfo memberInfo) throws BizException {
        //更新会员等级履历表
        MemberLevelLog beforeLog = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        Integer rows = memberLevelLogMapper.update(MemberLevelLog.builder()
                        .status(CommonStatusEnum.INVALID.getCode())
                        .realEndTime(memberInfo.getLevelStartTime()).build(),
                Wrappers.<MemberLevelLog>lambdaUpdate()
                        .eq(MemberLevelLog::getMemberId, beforeLog.getMemberId())
                        .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                        .eq(MemberLevelLog::getLevelAfter, beforeLog.getLevelAfter()));
        if (rows == 0) {
            log.error("更新会员等级履历表保存失败！会员ID为：{};关联订单号是：{}", memberInfo.getMemberId(), orderNo);
            throw new BizException("更新会员等级履历表保存失败");
        }
        //保存等级变化履历
        MemberLevelLog levelLog = this.extractMemberLevelLog(memberRule, orderNo, memberInfo, beforeLog);
        rows = memberLevelLogMapper.insert(levelLog);
        if (rows == 0) {
            log.error("根据首单判定会员等级保存修改履历！会员ID为：{};关联订单号是：{}", memberInfo.getMemberId(), orderNo);
            throw new BizException("根据首单判定会员等级保存修改履历");
        }
        //最后进行会员信息更新--触发优惠券，这个比较耗时，所以放在等级履历变化之后
        updateMemberInfo(memberInfo, orderNo);
    }

    /**
     * 根据销售进行等级更新,如果等级发生改变,则取消当前等级的券
     *
     * @param memberLevelRulePo
     * @param memberInfo
     * @param orderNo
     * @param description
     * @param memberLevelCode
     * @throws BizException
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void upMemberLevel(MemberLevelRulePo memberLevelRulePo, MemberInfo memberInfo, String orderNo, String description, String memberLevelCode) throws BizException {
        //为了避免修改履历中没有该会员的修改履历信息，需要在会员信息更新之前查询该会员的信息
        MemberInfo memberInfoBefore = memberMapper.selectOne(Wrappers.<MemberInfo>lambdaQuery()
                .eq(MemberInfo::getMemberId, memberInfo.getMemberId()));
        //更新会员等级履历表
        updateSaleMemberLevelLog(memberInfo, memberLevelRulePo, memberInfoBefore, orderNo, description);
        //会员更新
        if (memberInfo.getMemberLevelCode().equals(memberLevelCode)) {
            updateMemberInfoNoCoupon(memberInfo, orderNo);
        } else {
            updateMemberInfo(memberInfo, orderNo);
        }
    }


    /**
     * 根据销售进行会员等级履历更新
     *
     * @param memberInfo
     * @param memberLevelRulePo
     * @param memberInfoBefore
     * @param orderNo
     * @throws BizException
     */
    private void updateSaleMemberLevelLog(MemberInfo memberInfo, MemberLevelRulePo memberLevelRulePo, MemberInfo memberInfoBefore, String orderNo, String description) throws BizException {
        //更新等级履历信息
        updateBeforeLevelLog(memberInfo);
        //保存等级变化履历
        MemberLevelLog levelLog = this.extract4MemberLevelLog(memberLevelRulePo, memberInfo, memberInfoBefore);
        levelLog.setOddNumbers(orderNo);
        //0表示销售，1表示降级处理
        levelLog.setBusinessType(MemberLevelLogBizTypeEnum.SALE.getKey());
        //0 升级  1 降级
        levelLog.setChangeType(MemberLevelRuleTypeEnum.UPGRADE.getKey());
        //变化原因
        levelLog.setChangeReason(description);
        Integer rows = memberLevelLogMapper.insert(levelLog);
        if (rows == 0) {
            log.error("保存等级变化履历失败！会员ID为：{};关联订单号是：{}", memberInfo.getMemberId(), orderNo);
            throw new BizException("保存等级变化履历失败！");
        }
    }

    /**
     * 等级到期之后对会员等级进行降级处理
     *
     * @param memberInfo
     * @param memberLevelRulePo
     */
    private void updateMemberLevelLog(MemberInfo memberInfo, MemberLevelRulePo memberLevelRulePo, MemberInfo memberInfoBefore, String description) throws BizException {
        //更新等级履历信息
        updateBeforeLevelLog(memberInfo);
        //保存等级变化履历
        MemberLevelLog levelLog = this.extract4MemberLevelLog(memberLevelRulePo, memberInfo, memberInfoBefore);
        //0表示销售，1表示降级处理
        levelLog.setBusinessType(MemberLevelLogBizTypeEnum.DOWNGRADE.getKey());
        //0 升级  1 降级
        levelLog.setChangeType(MemberLevelRuleTypeEnum.DOWNGRADE.getKey());
        //变化原因
        levelLog.setChangeReason(description);
        Integer rows = memberLevelLogMapper.insert(levelLog);
        if (rows == 0) {
            log.error("保存等级变化履历失败！levelLog={}", levelLog);
            throw new BizException("保存等级变化履历失败！");
        }
    }

    /**
     * 更新等级履历信息
     *
     * @param memberInfo
     * @throws BizException
     */
    private void updateBeforeLevelLog(MemberInfo memberInfo) throws BizException {
        //获取修改履历信息
        MemberLevelLog beforeLog = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        if (beforeLog != null) {
            //对获取的履历信息进行更新
            Integer rows = memberLevelLogMapper.update(MemberLevelLog.builder()
                            .status(CommonStatusEnum.INVALID.getCode())
                            .realEndTime(LocalDateTime.now())
                            .updateTime(LocalDateTime.now()).build(),
                    Wrappers.<MemberLevelLog>lambdaUpdate()
                            .eq(MemberLevelLog::getMemberId, beforeLog.getMemberId())
                            .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
            if (rows == 0) {
                log.error("更新会员等级履历表保存失败！memberId={}", memberInfo.getMemberId());
                throw new BizException("更新会员等级履历表保存失败！");
            }
        }
    }

    /**
     * 保存会员信息修改，等级发生改变，触发优惠券操作
     *
     * @param memberInfo
     * @throws BizException
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void updateMemberInfo(MemberInfo memberInfo, String orderNo) throws BizException {
        Integer rows = memberMapper.update(memberInfo, Wrappers.<MemberInfo>lambdaUpdate()
                .eq(MemberInfo::getMemberId, memberInfo.getMemberId()));
        if (rows == 0) {
            log.error("根据销售判定会员等级更新会员信息失败！会员ID为：{};关联订单号是：{}", memberInfo.getMemberId(), orderNo);
            throw new BizException("根据销售判定会员等级更新会员信息失败!");
        }
        memberCouponSingleOperation.cancelMemberCoupon(memberInfo.getMemberId());
    }

    /**
     * 保存会员信息修改，等级发生改变，触发优惠券操作
     *
     * @param memberInfo
     * @throws BizException
     */
    private void updateMemberInfoCoupon(MemberInfo memberInfo, String orderNo) throws BizException {
        Integer rows = memberMapper.update(memberInfo, Wrappers.<MemberInfo>lambdaUpdate()
                .eq(MemberInfo::getMemberId, memberInfo.getMemberId()));
        if (rows == 0) {
            log.error("根据销售判定会员等级更新会员信息失败！会员ID为：{};关联订单号是：{}", memberInfo.getMemberId(), orderNo);
            throw new BizException("根据销售判定会员等级更新会员信息失败!");
        }
        //等级变化触发优惠券变化
        CancelAndAddCouponEvent dealMemberLevelEvent = new CancelAndAddCouponEvent(this, memberInfo.getMemberId());
        applicationContext.publishEvent(dealMemberLevelEvent);
    }

    /**
     * 保存会员信息修改，不触发优惠券变化操作
     *
     * @param memberInfo
     * @throws BizException
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void updateMemberInfoNoCoupon(MemberInfo memberInfo, String orderNo) throws BizException {
        Integer rows = memberMapper.update(memberInfo, Wrappers.<MemberInfo>lambdaUpdate()
                .eq(MemberInfo::getMemberId, memberInfo.getMemberId()));
        if (rows == 0) {
            log.error("根据销售判定会员等级更新会员信息失败！会员ID为：{};关联订单号是：{}", memberInfo.getMemberId(), orderNo);
            throw new BizException("根据销售判定会员等级更新会员信息失败!");
        }
    }

    /**
     * 定时任务----保存会员信息修改，不触发优惠券变化操作
     *
     * @param memberInfo
     * @throws BizException
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void updateTaskMemberInfo(MemberInfo memberInfo, String orderNo) throws BizException {
        Integer rows = memberMapper.update(memberInfo, Wrappers.<MemberInfo>lambdaUpdate()
                .eq(MemberInfo::getMemberId, memberInfo.getMemberId()));
        if (rows == 0) {
            log.error("根据销售判定会员等级更新会员信息失败！会员ID为：{};关联订单号是：{}", memberInfo.getMemberId(), orderNo);
            throw new BizException("根据销售判定会员等级更新会员信息失败!");
        }
    }

    /**
     * 会员等级到期之后，对等级升降进行判断
     *
     * @param memberLevelRulePo
     * @param memberInfo
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void changeMemberLevel(MemberLevelRulePo memberLevelRulePo, MemberInfo memberInfo, String description) throws BizException {
        //为了避免修改履历中没有该会员的修改履历信息，需要在会员信息更新之前查询该会员的信息
        MemberInfo memberInfoBefore = memberMapper.selectOne(Wrappers.<MemberInfo>lambdaQuery()
                .eq(MemberInfo::getMemberId, memberInfo.getMemberId()));
        //更新会员等级履历表
        updateMemberLevelLog(memberInfo, memberLevelRulePo, memberInfoBefore, description);
        //会员更新
        updateMemberInfoCoupon(memberInfo, "无，此处是会员到期之后的降级处理");
    }

    @Ella(Describe = "查询会员信息", Author = "K")
    public MemberInfo selectMemberInfoQuery(MemberInfo memberInfo) {
        return customService.select(memberInfo);
    }


    /**
     * 构建会员等级变化履历
     *
     * @param memberLevelRulePo
     * @param memberInfo
     * @param memberInfoBefore
     * @return
     */
    private MemberLevelLog extract4MemberLevelLog(MemberLevelRulePo memberLevelRulePo, MemberInfo memberInfo, MemberInfo memberInfoBefore) {
        return MemberLevelLog.builder()
                .ruleId(memberLevelRulePo.getRuleId())
                .ruleName(memberLevelRulePo.getRuleName())
                .memberId(memberInfo.getMemberId())
                .levelAfter(memberInfo.getMemberLevel())
                .levelCodeAfter(memberInfo.getMemberLevelCode())
                .levelNameAfter(memberInfo.getMemberLevelName())
                .levelStartTime(memberInfo.getLevelStartTime())
                .levelEndTime(memberInfo.getLevelEndTime())
                .levelBefore(memberInfoBefore.getMemberLevel())
                .levelCodeBefore(memberInfoBefore.getMemberLevelCode())
                .levelNameBefore(memberInfoBefore.getMemberLevelName())
                .status(CommonStatusEnum.EFFECTIVE.getCode())
                .createTime(LocalDateTime.now()).build();
    }

    /**
     * 计算等级结束时间
     *
     * @param level
     * @return
     */
    private LocalDateTime getEndTime(Integer level) {
        MemberLevel memberLevel = memberLevelMapper.selectOne(Wrappers.<MemberLevel>lambdaQuery()
                .eq(MemberLevel::getLevel, level)
                .eq(MemberLevel::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        if (memberLevel.getDuration().equals(0)) {
            return LocalDateTime.parse("9999-12-31 00:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        } else {
            return LocalDateTime.now().plusMonths(memberLevel.getDuration());
        }
    }

    /**
     * 首单消费之后，构建会员等级变化履历
     *
     * @param memberRule
     * @param orderNo
     * @param memberInfo
     * @param beforeLog
     * @return
     */
    private MemberLevelLog extractMemberLevelLog(MemberRule memberRule, String orderNo, MemberInfo memberInfo, MemberLevelLog beforeLog) {
        return MemberLevelLog.builder()
                .changeType(MemberLevelRuleTypeEnum.UPGRADE.getKey())
                .oddNumbers(orderNo)
                .businessType(MemberLevelLogBizTypeEnum.SALE.getKey())
                .ruleId(memberRule.getRuleId().toString())
                .ruleName(memberRule.getRuleName())
                .memberId(memberInfo.getMemberId())
                .changeReason(memberRule.getDescription())
                .levelAfter(memberRule.getLevel())
                .levelCodeAfter(memberRule.getLevelCode())
                .levelNameAfter(memberRule.getLevelName())
                .levelStartTime(memberInfo.getLevelStartTime())
                .levelEndTime(memberInfo.getLevelEndTime())
                .levelBefore(beforeLog.getLevelAfter())
                .levelCodeBefore(beforeLog.getLevelCodeAfter())
                .levelNameBefore(beforeLog.getLevelNameAfter())
                .status(CommonStatusEnum.EFFECTIVE.getCode())
                .createTime(LocalDateTime.now()).build();
    }


    @Ella(Describe = "记录修改履历", Author = "K")
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void fillOperation(MemberOperationRequest memberOperationRequestRequest) throws Exception {
        MemberOperation memberOperation = new MemberOperation();
        BeanUtils.copyProperties(memberOperationRequestRequest.getMemberOperation(), memberOperation);
        memberOperation.setOperationId(IdGenerator.getSerialNo(PrefixEnum.OP.getCode()));
        memberOperation.setCreateTime(LocalDateTime.now());
        MemberInfo memberInfo = new MemberInfo();
        BeanUtils.copyProperties(memberOperationRequestRequest.getMemberInfo(), memberInfo);
        memberOperation.setMemberId(memberInfo.getMemberId());
        memberOperation.setMemberName(memberInfo.getMemberName());
        memberOperation.setMemberPhone(memberInfo.getMobilePhone());
        //检测修改的字段信息,并进行日志记录
        MemberInfo memberInfoTemp = new MemberInfo();
        BeanUtils.copyProperties(memberOperationRequestRequest.getMemberInfo(), memberInfoTemp);
        Integer integer = checkFieldEdit(memberInfoTemp, memberOperation);
        if (!integer.equals(0)) {
            //进行保存操作信息
            saveMemberOperation(memberOperation);
        }
    }

    @Ella(Describe = "检测修改的字段信息", Author = "K")
    public Integer checkFieldEdit(MemberInfo memberInfo, MemberOperation memberOperation) throws Exception {
        Integer count = 0;
        //查询修改之前的会员信息
        MemberInfo memberOther = selectMemberInfo(MemberInfo.builder().memberId(memberInfo.getMemberId()).build());
        Field[] declaredFields = memberInfo.getClass().getDeclaredFields();
        for (Field field : declaredFields) {
            field.setAccessible(true);
            if (field.getAnnotation(FieldName.class) != null) {//判断字段是否发生了变化
                Object after = field.get(memberInfo);//现在的值
                if (StringUtils.isEmpty(after)) {//为空直接跳过
                    continue;
                }
                if (memberOperation.getType().equals(MemberInfoEnum.OPERATION_ADD.getKey())) {//如果是新增
                    String name = field.getName();
                    if (name.equals("nickName")
                            || name.equals("status")
                            || name.equals("memberLevelName")
                            || name.equals("provinceName")
                            || name.equals("cityName")
                            || name.equals("countyName")
                            || name.equals("address")
                            || name.equals("cardIssuingTime")
                            || name.equals("identityCard")
                            || name.equals("career")
                            || name.equals("income")
                            || name.equals("telephone")
                            || name.equals("isMarried")
                            || name.equals("remark")
                            || name.equals("skinType")
                            || name.equals("memberType")) {//新增的时候这些字段不需要
                        continue;
                    }
                    saveOperationFields(MemberOperationFields
                            .builder()
                            .operationId(memberOperation.getOperationId())
                            .field(field.getAnnotation(FieldName.class).name())
                            .fieldBefore(null)
                            .memberId(memberInfo.getMemberId())
                            .fieldAfter(after.toString())
                            .build());
                    count++;
                } else {
                    Object before = field.get(memberOther);
                    //进行比较是否发生了变化
                    if ((StringUtils.isEmpty(after) && !StringUtils.isEmpty(before)) || (!StringUtils.isEmpty(after) && StringUtils.isEmpty(before)) || (!before.equals(after))) {
                        if (field.getName().equals("status")) {
                            saveOperationFields(MemberOperationFields
                                    .builder()
                                    .operationId(memberOperation.getOperationId())
                                    .field(field.getAnnotation(FieldName.class).name())
                                    .fieldBefore(CommonStatusEnum.instance((Integer) before).getMsg())
                                    .fieldAfter(CommonStatusEnum.instance((Integer) after).getMsg())
                                    .memberId(memberInfo.getMemberId())
                                    .build());
                        } else {
                            saveOperationFields(MemberOperationFields
                                    .builder()
                                    .operationId(memberOperation.getOperationId())
                                    .field(field.getAnnotation(FieldName.class).name())
                                    .fieldBefore(before == null ? null : before.toString())
                                    .fieldAfter(after == null ? null : after.toString())
                                    .memberId(memberInfo.getMemberId())
                                    .build());
                        }
                        count++;
                    }
                }
            }
        }
        return count;
    }

    @Ella(Describe = "查询会员信息", Author = "K")
    @DS(DBConst.SLAVE)
    public Response selectMember(String phone) {
        //根据手机号查询会员信息
        MemberInfo memberInfo = memberMapper.selectOne(Wrappers.<MemberInfo>lambdaQuery()
                .eq(MemberInfo::getMobilePhone, phone)
                .or().eq(MemberInfo::getMemberCardNumber, phone));
        if (memberInfo == null) {
            return Response.errorMsg("未查询到该用户信息,请核对重试!");
        }
        if (memberInfo.getStatus().equals(CommonStatusEnum.INVALID.getCode())) {
            return Response.errorMsg("此会员无效!");
        }
        MemberInfoVo memberInfoVo = new MemberInfoVo();
        BeanUtils.copyProperties(memberInfo, memberInfoVo);
        //查询积分
        IntegralAccountPo integralAccountPo = integralService.selectIntegralAccount(memberInfo.getMemberId());
        if (integralAccountPo == null) {
            memberInfoVo.setIntegral(BigInteger.ZERO.intValue());
            memberInfoVo.setOldQty(BigInteger.ZERO.intValue());
            memberInfoVo.setNewQty(BigInteger.ZERO.intValue());
        } else {
            memberInfoVo.setIntegral(integralAccountPo.getAvlQty());
            memberInfoVo.setOldQty(integralAccountPo.getOldQty());
            memberInfoVo.setNewQty(integralAccountPo.getNewQty());
        }
        //积分时间
        MemberInfoMessagePo memberInfoMessagePo = memberActivityMapper.queryMemberMessage(memberInfo.getMemberId());
        if (memberInfoMessagePo != null) {
            memberInfoVo.setIntegralTime(memberInfoMessagePo.getIntegralTime());
        }
        //购买金额
        MemberInfoMessagePo memberInfoMessagePo1 = memberActivityMapper.queryAmt(memberInfo.getMemberId());
        if (memberInfoMessagePo1 == null) {
            memberInfoVo.setBuyAmt(BigDecimal.valueOf(0, 2));
        } else {
            memberInfoVo.setBuyAmt(memberInfoMessagePo1.getBuyAmt());
        }
        //上次购买金额
        MemberInfoMessagePo memberInfoMessagePo2 = memberActivityMapper.queryLastAmt(memberInfo.getMemberId());
        if (memberInfoMessagePo2 == null) {
            //如果未查询到数据，设置为0.00
            memberInfoVo.setLastTimeAmt(BigDecimal.valueOf(0, 2));
        } else {
            //如果交易类型是退货，则取负数
            if (memberInfoMessagePo2.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                //查询的数据已经取了绝对值，此处直接取负数即可
                memberInfoVo.setLastTimeAmt(memberInfoMessagePo2.getLastTimeAmt().negate());
            } else {
                memberInfoVo.setLastTimeAmt(memberInfoMessagePo2.getLastTimeAmt());
            }
        }
        //临时需求 新增展示微信绑定与否  配合权限一起
        List<WxCardInfoPo> wxCardInfoPos = wxCardInfoPoMapper.selectList(Wrappers.<WxCardInfoPo>lambdaQuery()
                .eq(WxCardInfoPo::getMemberId, memberInfoVo.getMemberId()));
        if (wxCardInfoPos != null && wxCardInfoPos.size() > 0) {
            memberInfoVo.setWxBind(true);
        } else {
            memberInfoVo.setWxBind(false);
            //2021-01-11新需求，每月微信未激活可销售人数，每个门店每个财务月有指定的名额
            String counterId = PosUserContextHolder.get().getCounter().getCounterId();
            this.fillSaleQty(counterId, memberInfoVo);
        }
        return Response.success(memberInfoVo);
    }

    @Ella(Describe = "空退页面查询会员信息", Author = "K")
    @DS(DBConst.SLAVE)
    public Response selectMemberByPhone(String phone) {
        //根据手机号查询会员信息
        MemberInfo memberInfo = memberMapper.selectOne(Wrappers.<MemberInfo>lambdaQuery()
                .eq(MemberInfo::getMobilePhone, phone)
                .or().eq(MemberInfo::getMemberCardNumber, phone));
        if (memberInfo == null) {
            return Response.errorMsg("未查询到该用户信息,请核对重试!");
        }
        if (memberInfo.getStatus().equals(CommonStatusEnum.INVALID.getCode())) {
            return Response.errorMsg("此会员无效!");
        }
        MemberInfoVo memberInfoVo = new MemberInfoVo();
        BeanUtils.copyProperties(memberInfo, memberInfoVo);
        //查询积分
        IntegralAccountPo integralAccountPo = integralService.selectIntegralAccount(memberInfo.getMemberId());
        if (integralAccountPo == null) {
            memberInfoVo.setIntegral(BigInteger.ZERO.intValue());
            memberInfoVo.setOldQty(BigInteger.ZERO.intValue());
            memberInfoVo.setNewQty(BigInteger.ZERO.intValue());
        } else {
            memberInfoVo.setIntegral(integralAccountPo.getAvlQty());
            memberInfoVo.setOldQty(integralAccountPo.getOldQty());
            memberInfoVo.setNewQty(integralAccountPo.getNewQty());
        }
        //积分时间
        MemberInfoMessagePo memberInfoMessagePo = memberActivityMapper.queryMemberMessage(memberInfo.getMemberId());
        if (memberInfoMessagePo != null) {
            memberInfoVo.setIntegralTime(memberInfoMessagePo.getIntegralTime());
        }
        //购买金额
        MemberInfoMessagePo memberInfoMessagePo1 = memberActivityMapper.queryAmt(memberInfo.getMemberId());
        if (memberInfoMessagePo1 == null) {
            memberInfoVo.setBuyAmt(BigDecimal.valueOf(0, 2));
        } else {
            memberInfoVo.setBuyAmt(memberInfoMessagePo1.getBuyAmt());
        }
        //上次购买金额
        MemberInfoMessagePo memberInfoMessagePo2 = memberActivityMapper.queryLastAmt(memberInfo.getMemberId());
        if (memberInfoMessagePo2 == null) {
            //如果未查询到数据，设置为0.00
            memberInfoVo.setLastTimeAmt(BigDecimal.valueOf(0, 2));
        } else {
            //如果交易类型是退货，则取负数
            if (memberInfoMessagePo2.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                //查询的数据已经取了绝对值，此处直接取负数即可
                memberInfoVo.setLastTimeAmt(memberInfoMessagePo2.getLastTimeAmt().negate());
            } else {
                memberInfoVo.setLastTimeAmt(memberInfoMessagePo2.getLastTimeAmt());
            }
        }


            memberInfoVo.setWxBind(true);
        return Response.success(memberInfoVo);
    }
    @Ella(Describe = "根据手机号或会员姓名模糊查询会员信息", Author = "H")
    @DS(DBConst.SLAVE)
    public Response selectMemberList(String phone, String memberName, String counterId) {
        List<MemberConsumeVo> memberConsumeVoList = new ArrayList<>();
        if (phone.isEmpty() && memberName.isEmpty()) {
            return Response.errorMsg("查询条件不能为空");
        }
        if (!phone.isEmpty() && phone.length() < 4) {
            return Response.success(memberConsumeVoList);
        }
        //根据手机号或会员姓名模糊查询会员信息
        List<MemberInfo> memberInfoList = memberMapper.memberList(phone, memberName, counterId);
        if (memberInfoList.isEmpty()) {
            return Response.success(memberConsumeVoList);
        }
        List<String> memberIdList = memberInfoList.stream().map(MemberInfo::getMemberId).collect(Collectors.toList());
        List<MemberOrderSearchPo> memberOrderSearchPos = memberOrderSearchMapper.selectLastBuyRecord(memberIdList);
        List<NursingRecordPO> nursingRecordPOList = nursingRecordMapper.selectLastNursingRecord(memberIdList);
        Map<String,MemberOrderSearchPo> memberOrderSearchMap = memberOrderSearchPos.stream().collect(Collectors.toMap(MemberOrderSearchPo::getMemberId,e->e));
        Map<String,NursingRecordPO> nursingRecordPOMap = nursingRecordPOList.stream().collect(Collectors.toMap(NursingRecordPO::getMemberId,e->e));
        for (MemberInfo memberInfo : memberInfoList) {
            MemberConsumeVo memberConsumeVo = new MemberConsumeVo();
            memberConsumeVo.setMemberId(memberInfo.getMemberId());
            memberConsumeVo.setMobile(memberInfo.getMobilePhone());
            memberConsumeVo.setName(memberInfo.getMemberName());
            memberConsumeVo.setMemberLevel(memberInfo.getMemberLevel());
            String memberId = memberInfo.getMemberId();
            MemberOrderSearchPo memberOrderSearchPo = memberOrderSearchMap.get(memberId);
            if (memberOrderSearchPo != null) {
                memberConsumeVo.setLastBuyTime(memberOrderSearchPo.getRecentTime());
            }
            NursingRecordPO nursingRecordPO = nursingRecordPOMap.get(memberId);
            if(nursingRecordPO != null){
                memberConsumeVo.setLastNursingTime(nursingRecordPO.getCreateTime());
                memberConsumeVo.setBaName(nursingRecordPO.getBaName());
            }
            memberConsumeVoList.add(memberConsumeVo);
        }
        return Response.success(memberConsumeVoList);
    }


    /**
     * 2021-01-11新需求，未激活会员销售，每个门店每个财务月有指定的名额(同一会员只算一个)
     *
     * @param counterId
     * @param memberInfoVo
     */
    private void fillSaleQty(String counterId, MemberInfoVo memberInfoVo) {
        CounterInformation counter = counterInfoMapper.selectById(counterId);
        //查询是否开启了限制
        Integer count = posAuthorityMapper.countSpecifiedAuthority(counter, ProgramTypeEnum.WX_BIND.getCode());
        if (count == 0) {
            return;
        }
        //系统配置里面是否有限制次数
        SystemConfigPo systemConfigPo = systemConfigMapper.selectOne(Wrappers.<SystemConfigPo>lambdaQuery()
                .eq(SystemConfigPo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                .eq(SystemConfigPo::getParamKey, SystemConfigEnum.MONTH_WX_UNACTIVE_SALE.getCode()));
        if (systemConfigPo == null) {
            return;
        }
        //总计可销售未激活会员个数
        memberInfoVo.setTotalSaleQty(Integer.valueOf(systemConfigPo.getParamValue()));
        //查询redis中是否存在该柜台的会员
        Set<String> memberList = redisService.getObject(String.format(RedisPrefixKeyConst.WX_MONTH_UNACTIVE_MEMBER_ID, counterId));
        if (ObjectUtils.isEmpty(memberList)) {
            memberInfoVo.setSaleQty(Integer.valueOf(systemConfigPo.getParamValue()));
        } else {
            //如果当前会员已存在redis中，直接返回
            if (memberList.contains(memberInfoVo.getMemberId())) {
                return;
            }
            //不在redis中，则返回还剩余的数量(这里可能会存在负数的情况，比如说配置的减少了)
            memberInfoVo.setSaleQty(Integer.valueOf(systemConfigPo.getParamValue()) - memberList.size());
        }
    }

    @Ella(Describe = "查询会员", Author = "K")
    @DS(DBConst.SLAVE)
    public MemberInfo selectMemberInfo(MemberInfo memberInfo) {
        return customService.select(memberInfo);
    }

    @Ella(Describe = "查询会员集合信息", Author = "K")
    @DS(DBConst.SLAVE)
    public List<MemberInfo> selectMembers(MemberInfo memberInfo) {
        return customService.selectListByTime(memberInfo);
    }

    @Ella(Describe = "保存会员", Author = "K")
    @DS(DBConst.MASTER)
    public void saveMember(MemberInfo memberInfo) {
        Integer save = customService.save(memberInfo);
        if (save.equals(0)) {
            log.error("保存会员失败,memberInfo={}", memberInfo);
            throw new BizException("保存会员失败!");
        }
    }

    @Ella(Describe = "更新会员信息", Author = "K")
    @DS(DBConst.MASTER)
    public void updateMember(MemberInfo memberInfo, MemberInfo memberInfoOther) {
        Integer update = customService.update(memberInfo, memberInfoOther);
        if (update.equals(0)) {
            log.error("更新会员信息失败,memberInfo={},memberInfoOther={}", memberInfo, memberInfoOther);
            throw new BizException("更新会员信息失败!");
        }
    }

    @Ella(Describe = "检测会员信息是否重复,编辑的时候type为1", Author = "K")
    public Integer checkMember(MemberInfo memberInfo, Integer type) {
        MemberInfo memberInformation = selectMemberInfo(MemberInfo.builder().mobilePhone(memberInfo.getMobilePhone()).build());
        return type == null ?
                (memberInformation != null) ? MemberInfoEnum.MEMBER_NAME_EXIT.getKey() : StatusEnum.SUCCESS.getKey() :
                !memberInformation.getMobilePhone().equals(memberInfo.getMobilePhone()) ? MemberInfoEnum.MEMBER_NAME_EXIT.getKey() : StatusEnum.SUCCESS.getKey();
    }

    @Ella(Describe = "检测推荐会员是否存在", Author = "K")
    public Integer checkMember(String rPhone) {
        MemberInfo memberInformation = selectMemberInfo(MemberInfo
                .builder()
                .mobilePhone(rPhone)
                .status(CommonStatusEnum.EFFECTIVE.getCode())
                .build());
        return memberInformation == null ? MemberInfoEnum.MEMBER_IS_NULL.getKey() : StatusEnum.SUCCESS.getKey();
    }

    @Ella(Describe = "保存字段信息", Author = "K")
    @DS(DBConst.MASTER)
    public void saveOperationFields(MemberOperationFields operationFields) throws Exception {
        Integer save = customService.save(operationFields);
        if (save.equals(0)) {
            log.error("保存字段信息失败!operationFields={}", operationFields);
            throw new BizException("保存字段信息失败!");
        }
    }

    @Ella(Describe = "保存修改信息", Author = "K")
    @DS(DBConst.MASTER)
    public void saveMemberOperation(MemberOperation memberOperation) throws Exception {
        Integer save = customService.save(memberOperation);
        if (save.equals(0)) {
            log.error("保存修改信息失败,memberOperation={}", memberOperation);
            throw new BizException("保存修改信息失败");
        }
    }

    @Ella(Describe = "生成会员积分关联信息", Author = "K")
    @DS(DBConst.MASTER)
    public void saveIntegralAccount(IntegralAccountPo integralAccountPo) throws Exception {
        Integer save = customService.save(integralAccountPo);
        if (save.equals(StatusEnum.UN_DELETED.getKey())) {
            log.error("生成会员积分账户信息失败,integralAccountPo={}", integralAccountPo);
            throw new BizException("生成会员积分账户信息失败");
        }
    }

    /**
     * 根据手机号查询会员信息和购买记录
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response memberPurchase(MemberPurchaseRequest request) {
        //判断页数和页面
        if (request.getPageNumber() == null || request.getPageSize() == null) {
            return Response.errorMsg("页数、页码不能为空!");
        }
        //查会员信息
        MemberInfo memberInfo = memberMapper.selectOne(Wrappers.<MemberInfo>lambdaQuery()
                .eq(MemberInfo::getMobilePhone, request.getMobilePhone()));
        if (memberInfo == null) {
            return Response.successMsg("未查询到该会员!");
        }
        //返回前端实体类
        MemberVo memberVo = new MemberVo();
        BeanUtils.copyProperties(memberInfo, memberVo);
        //查询积分
        IntegralAccountPo integral = integralService.selectIntegralAccount(memberInfo.getMemberId());
        if (integral == null) {
            memberVo.setIntegral(BigInteger.ZERO.intValue());
        } else {
            memberVo.setIntegral(integral.getAvlQty());
        }
        //查询购买记录
        Page<PosOrderPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        IPage<PosOrderPo> posOrderPoIPage = posOrderMapper.selectPage(page, Wrappers.<PosOrderPo>lambdaQuery()
                .eq(PosOrderPo::getMemberId, memberInfo.getMemberId())
                .orderByDesc(PosOrderPo::getBizTime));
        List<PosOrderPo> records = posOrderPoIPage.getRecords();
        if (records.isEmpty()) {
            memberVo.setPageVo(new PageVO());
        } else {
            List<PurchaseVo> purchaseVoList = records.stream().map(e -> {
                PurchaseVo purchaseVo = new PurchaseVo();
                BeanUtils.copyProperties(e, purchaseVo);
                //设置交易类型返回
                purchaseVo.setTransTypeDesc(getDesc(e.getTransType(), e.getOrderType()));
                //获取该笔订单的积分
                purchaseVo.setIntegral(e.getInteQty());
                return purchaseVo;
            }).collect(Collectors.toList());
            //设置返回前端的分页Vo
            PageVO pageVO = PageVO.<PurchaseVo>builder()
                    .list(purchaseVoList)
                    .pageNum(posOrderPoIPage.getCurrent())
                    .pageSize(posOrderPoIPage.getSize())
                    .pages(posOrderPoIPage.getPages())
                    .total(posOrderPoIPage.getTotal())
                    .build();
            //获取返回前端的vo
            memberVo.setPageVo(pageVO);
        }
        return Response.success(memberVo);
    }

    /**
     * 获取到类型
     *
     * @param transType
     * @param orderType
     * @return
     */
    private String getDesc(Integer transType, Integer orderType) {
        if (!transType.equals(OrderTransTypeEnum.GOODS_OUT.getCode()) && !transType.equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
            return null;
        }
        String desc = null;
        if (transType.equals(OrderTransTypeEnum.GOODS_OUT.getCode())) {
            switch (orderType) {
                case 1:
                    desc = "销售";
                    break;
                case 2:
                    desc = "预订单销售";
                    break;
                case 3:
                    desc = "积分兑换";
                    break;
                default:
                    break;
            }
        } else {
            switch (orderType) {
                case 1:
                    desc = "销售退货";
                    break;
                case 2:
                    desc = "预订单退货";
                    break;
                case 3:
                    desc = "积分兑换退货";
                    break;
                default:
                    break;
            }
        }
        return desc;
    }

    /**
     * 会员等级降级履历
     *
     * @param memberLevelLog
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void downMemberLevelLog(MemberLevelLog memberLevelLog, String orderNo, MemberInfo memberInfo) throws BizException {
        //查询该会员目前的等级履历信息
        MemberLevelLog currentLevelLog = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaUpdate()
                .eq(MemberLevelLog::getMemberId, memberLevelLog.getMemberId())
                .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        //更新现有的会员等级履历表
        MemberLevelLog build = MemberLevelLog.builder()
                .realEndTime(LocalDateTime.now())
                .status(CommonStatusEnum.INVALID.getCode())
                .updateTime(LocalDateTime.now())
                .build();
        Integer rows = memberLevelLogMapper.update(build, Wrappers.<MemberLevelLog>lambdaUpdate()
                .eq(MemberLevelLog::getMemberId, memberLevelLog.getMemberId())
                .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        if (rows == 0) {
            log.error("降级处理失败!会员ID为：{};关联订单号是：{}", memberLevelLog.getMemberId(), orderNo);
            throw new BizException("降级处理失败!");
        }
        //新增一条履历信息
        MemberLevelLog levelLog = MemberLevelLog.builder()
                .memberId(memberInfo.getMemberId())
                .levelAfter(memberInfo.getMemberLevel())
                .levelNameAfter(memberInfo.getMemberLevelName())
                .levelCodeAfter(memberInfo.getMemberLevelCode())
                .levelBefore(currentLevelLog.getLevelAfter())
                .levelNameBefore(currentLevelLog.getLevelNameAfter())
                .levelCodeBefore(currentLevelLog.getLevelCodeAfter())
                .levelStartTime(memberInfo.getLevelStartTime())
                .levelEndTime(memberInfo.getLevelEndTime())
                .changeReason("用户查单退货，系统自动降级")
                .changeType(MemberLevelRuleTypeEnum.DOWNGRADE.getKey())
                .businessType(MemberLevelLogBizTypeEnum.DOWNGRADE.getKey())
                .oddNumbers(orderNo)
                .status(CommonStatusEnum.EFFECTIVE.getCode())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
        rows = memberLevelLogMapper.insert(levelLog);
        if (rows == 0) {
            log.error("降级处理失败!会员ID为：{};关联订单号是：{}", memberLevelLog.getMemberId(), orderNo);
            throw new BizException("降级处理失败!");
        }
    }

    /**
     * 插入修改履历
     *
     * @throws BizException
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void insertMemberLog(MemberInfo memberInfo, String orderNo, MemberLevelUpPo levelUpPo) throws BizException {
        //查询现有的有效修改履历信息
        MemberLevelLog memberLevelLog = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaUpdate()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        //更新现有的会员等级履历表
        MemberLevelLog build = MemberLevelLog.builder()
                .realEndTime(LocalDateTime.now())
                .status(CommonStatusEnum.INVALID.getCode())
                .updateTime(LocalDateTime.now())
                .build();
        Integer rows = memberLevelLogMapper.update(build, Wrappers.<MemberLevelLog>lambdaUpdate()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        if (rows == 0) {
            log.error("降级处理失败!会员ID为：{};关联订单号是：{}", memberLevelLog.getMemberId(), orderNo);
            throw new BizException("降级处理失败!");
        }
        //查询等级信息
        MemberLevelRulePo memberLevelRulePo = memberLevelRuleMapper.selectOne(Wrappers.<MemberLevelRulePo>lambdaQuery()
                .eq(MemberLevelRulePo::getRuleId, levelUpPo.getRuleId()));
        //新增一条履历信息
        MemberLevelLog levelLog = MemberLevelLog.builder()
                .memberId(memberInfo.getMemberId())
                .levelAfter(memberInfo.getMemberLevel())
                .levelNameAfter(memberInfo.getMemberLevelName())
                .levelCodeAfter(memberInfo.getMemberLevelCode())
                .levelBefore(memberLevelLog.getLevelAfter())
                .levelNameBefore(memberLevelLog.getLevelNameAfter())
                .levelCodeBefore(memberLevelLog.getLevelCodeAfter())
                .levelStartTime(memberInfo.getLevelStartTime())
                .levelEndTime(memberInfo.getLevelEndTime())
                .ruleId(memberLevelRulePo.getRuleId())
                .ruleName(memberLevelRulePo.getRuleName())
                .changeReason(levelUpPo.getDescription())
                .changeType(MemberLevelRuleTypeEnum.UPGRADE.getKey())
                .businessType(MemberLevelLogBizTypeEnum.SALE.getKey())
                .oddNumbers(orderNo)
                .status(CommonStatusEnum.EFFECTIVE.getCode())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
        rows = memberLevelLogMapper.insert(levelLog);
        if (rows == 0) {
            log.error("降级处理失败!会员ID为：" + memberLevelLog.getMemberId() + ";关联订单号是：" + orderNo);
            throw new BizException("降级处理失败!");
        }
    }

    /**
     * 会员信息保级处理
     *
     * @param memberInfo
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void updateRelegationMemberInfo(MemberInfo memberInfo) {
        //更新会员信息
        Integer rows = memberMapper.updateById(memberInfo);
        if (rows == 0) {
            log.error("会员等级更新会员信息失败!会员ID为：{}", memberInfo.getMemberId());
            throw new BizException("会员等级更新会员信息失败!");
        }
        //查询履历表中信息
        MemberLevelLog memberLevelLog = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        //修改履历表中信息
        MemberLevelLog build = MemberLevelLog.builder()
                .realEndTime(LocalDateTime.now())
                .status(CommonStatusEnum.INVALID.getCode())
                .updateTime(LocalDateTime.now())
                .build();
        rows = memberLevelLogMapper.update(build, Wrappers.<MemberLevelLog>lambdaUpdate()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        if (rows == 0) {
            log.error("会员等级更新等级履历信息失败!会员ID为：{}", memberLevelLog.getMemberId());
            throw new BizException("会员等级更新等级履历信息失败!");
        }
        //插入一条履历信息
        MemberLevelLog levelLog = MemberLevelLog.builder()
                .memberId(memberInfo.getMemberId())
                .levelAfter(memberInfo.getMemberLevel())
                .levelNameAfter(memberInfo.getMemberLevelName())
                .levelCodeAfter(memberInfo.getMemberLevelCode())
                .levelBefore(memberLevelLog.getLevelAfter())
                .levelNameBefore(memberLevelLog.getLevelNameAfter())
                .levelCodeBefore(memberLevelLog.getLevelCodeAfter())
                .levelStartTime(memberInfo.getLevelStartTime())
                .levelEndTime(memberInfo.getLevelEndTime())
                .changeReason("会员等级有效期到期")
                .changeType(MemberLevelRuleTypeEnum.RELEGATION.getKey())
                .businessType(MemberLevelLogBizTypeEnum.LEVEL_MAINTENANCE.getKey())
                .status(CommonStatusEnum.EFFECTIVE.getCode())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
        rows = memberLevelLogMapper.insert(levelLog);
        if (rows == 0) {
            log.error("会员等级插入等级履历信息失败!会员ID为：{}", memberLevelLog.getMemberId());
            throw new BizException("会员等级插入等级履历信息失败!");
        }
    }

    /**
     * 会员保级之后退货导致的等级变化
     *
     * @param memberInfo
     * @param memberLevelDownPo
     * @param posOrderPo
     */
    public void regulationMemberLevelLog(MemberInfo memberInfo, MemberLevelDownPo memberLevelDownPo, PosOrderPo posOrderPo) {
        //查询升降级主表信息
        MemberLevelRulePo memberLevelRulePo = memberLevelRuleMapper.selectOne(Wrappers.<MemberLevelRulePo>lambdaQuery()
                .eq(MemberLevelRulePo::getRuleId, memberLevelDownPo.getRuleId()));
        //将当前有效的会员履历设置为无效
        MemberLevelLog levelLogBefore = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        Integer rows = memberLevelLogMapper.update(MemberLevelLog.builder()
                .realEndTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .status(CommonStatusEnum.INVALID.getCode())
                .build(), Wrappers.<MemberLevelLog>lambdaUpdate()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        if (rows == 0) {
            log.error("退货之后，将保级降级时修改会员等级履历失败！会员ID为：{};关联订单号是：{}", memberInfo.getMemberId(), posOrderPo.getOrderNo());
            throw new BizException("退货之后，将保级降级时修改会员等级履历失败！");
        }
        //构建新的会员等级履历信息
        //保存等级变化履历
        MemberLevelLog levelLog = MemberLevelLog.builder()
                .changeType(MemberLevelRuleTypeEnum.DOWNGRADE.getKey())
                .oddNumbers(posOrderPo.getOrderNo())
                .businessType(MemberLevelLogBizTypeEnum.SALE.getKey())
                .ruleId(memberLevelDownPo.getRuleId())
                .ruleName(memberLevelRulePo.getRuleName())
                .memberId(memberInfo.getMemberId())
                .changeReason(memberLevelDownPo.getDescription())
                .levelAfter(memberLevelDownPo.getAfterLevel())
                .levelCodeAfter(memberLevelDownPo.getAfterLevelCode())
                .levelNameAfter(memberLevelDownPo.getAfterLevelName())
                .levelStartTime(memberInfo.getLevelStartTime())
                .levelEndTime(memberInfo.getLevelEndTime())
                .levelBefore(levelLogBefore.getLevelAfter())
                .levelCodeBefore(levelLogBefore.getLevelCodeAfter())
                .levelNameBefore(levelLogBefore.getLevelNameAfter())
                .status(CommonStatusEnum.EFFECTIVE.getCode())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now()).build();
        rows = memberLevelLogMapper.insert(levelLog);
        if (rows == 0) {
            log.error("退货之后，将保级降级时会员等级保存修改履历！会员ID为：{};关联订单号是：{}", memberInfo.getMemberId(), posOrderPo.getOrderNo());
            throw new BizException("退货之后，将保级降级时修改会员等级履历失败！");
        }
    }

    /**
     * 根据销售进行等级更新
     *
     * @param memberLevelRulePo
     * @param memberInfo
     * @throws BizException
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void upSalesMemberLevel(MemberLevelRulePo memberLevelRulePo, MemberInfo memberInfo, String orderNo, String description) throws BizException {
        //将当前有效的会员履历设置为无效
        MemberLevelLog levelLogBefore = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        Integer rows = memberLevelLogMapper.update(MemberLevelLog.builder()
                .realEndTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .status(CommonStatusEnum.INVALID.getCode())
                .build(), Wrappers.<MemberLevelLog>lambdaUpdate()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
        if (rows == 0) {
            log.error("退货之后，修改会员等级履历失败！会员ID为：{};关联订单号是：{}", memberInfo.getMemberId(), orderNo);
            throw new BizException("退货之后，修改会员等级履历失败！");
        }
        MemberLevelLog levelLog = MemberLevelLog.builder()
                .changeType(MemberLevelRuleTypeEnum.UPGRADE.getKey())
                .oddNumbers(orderNo)
                .businessType(MemberLevelLogBizTypeEnum.SALE.getKey())
                .ruleId(memberLevelRulePo.getRuleId())
                .ruleName(memberLevelRulePo.getRuleName())
                .memberId(memberInfo.getMemberId())
                .changeReason(description)
                .levelAfter(memberInfo.getMemberLevel())
                .levelCodeAfter(memberInfo.getMemberLevelCode())
                .levelNameAfter(memberInfo.getMemberLevelName())
                .levelStartTime(memberInfo.getLevelStartTime())
                .levelEndTime(memberInfo.getLevelEndTime())
                .levelBefore(levelLogBefore.getLevelAfter())
                .levelCodeBefore(levelLogBefore.getLevelCodeAfter())
                .levelNameBefore(levelLogBefore.getLevelNameAfter())
                .status(CommonStatusEnum.EFFECTIVE.getCode())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now()).build();
        rows = memberLevelLogMapper.insert(levelLog);
        if (rows == 0) {
            log.error("退货之后，新增会员等级保存修改履历！会员ID为：{};关联订单号是：{}", memberInfo.getMemberId(), orderNo);
            throw new BizException("退货之后，新增修改会员等级履历失败！");
        }
    }
}
