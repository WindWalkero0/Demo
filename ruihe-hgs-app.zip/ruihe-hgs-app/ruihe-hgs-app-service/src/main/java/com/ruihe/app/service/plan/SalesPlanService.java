package com.ruihe.app.service.plan;

import com.ruihe.app.request.plan.SalesPlanOperateRequest;
import com.ruihe.common.enums.plan.PlanObjectTypeEnum;
import com.ruihe.common.response.Response;
import com.ruihe.app.request.plan.SalesPlanInfoQueryRequest;

/**
 * 销售规划服务
 * @author qubin
 * @date 2021/4/2 13:13
 */
public interface SalesPlanService {

    /**
     * 新增销售规划
     * @param request 操作请求
     */
     Response operateSalesPlan(SalesPlanOperateRequest request);

    /**
     *  查询销售计划信息详情
     * @param planObjectType 规划对象类型
     * @param planObjectId 规划对象id
     * @param bizId 业务id
     * @return
     */
     Response selectSalesPlanInfoDetail(String planObjectType, String planObjectId, String bizId);

    /**
     * 查询柜台销售计划
     * @param request 查询请求
     * @return
     */
     Response selectSalesPlanInfo(SalesPlanInfoQueryRequest request);

     /**
      * 查询月度销售规划统计信息
      * @author qubin
      * @date 2021/7/19 10:05
      * @param planTime 规划时间，格式为YYYYMM形式
      * @param counterId 柜台编号
      * @return com.ruihe.common.response.Response
      */
     Response selectTotalMonthSalesPlanInfo(String counterId, String planTime);
}
