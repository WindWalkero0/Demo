package com.ruihe.app.service.app.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.app.constant.ParameterConfigConst;
import com.ruihe.app.dto.PosUpgradeDto;
import com.ruihe.app.response.BootInitResponse;
import com.ruihe.app.service.app.BootInitService;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.service.ParameterConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author William
 * @create 2019-10-12 19:44
 */
@DS(DBConst.SLAVE)
@Service
public class BootInitServiceImpl implements BootInitService {

    @Autowired
    private ParameterConfigService parameterConfigService;


    /**
     * 启动初始化
     *
     * @return
     */
    @Override
    public Response init() {
        /**
         * 终端管理升级逻辑,
         * versionCode:
         * 1、门店app > 服务器端app  --》强制更新降级处理；
         * 2、门店app = 服务器端app  --》不更新也不提示；
         * 3、门店app < 服务器端app  --》根据forceUpgrade配置相应处理更新
         */
        String value = parameterConfigService.getValue(ParameterConfigConst.APP_UPGRADE_CONF);
        PosUpgradeDto posUpgradeDto = JSON.parseObject(value, PosUpgradeDto.class);
        BootInitResponse response = BootInitResponse.builder()
                .upgrade(posUpgradeDto)
                .build();
        return Response.success(response);
    }

}
