package com.ruihe.app.service.analysis;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.common.pojo.request.order.PaymentStructureRequest;
import com.ruihe.app.mapper.analysis.PaymentStructureMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.po.analysis.PosPaymentStructurePo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

/**
 * 支付构成报表
 *
 * @author:Fangtao
 * @Date:2019/10/30 18:09
 */
@Slf4j
@DS(DBConst.SLAVE)
@Service
public class PaymentStructureService {

    @Autowired
    private PaymentStructureMapper paymentStructureMapper;

    @Autowired
    private PosOrderMapper posOrderMapper;

    /**
     * 支付构成报表 -->支付方式与销售额
     */
    public Response payReport(PaymentStructureRequest request) {
        if (StringUtils.isBlank(request.getCounterId())) {
            return Response.errorMsg("柜台编码不能为空");
        }
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        //实收金额
        PosPaymentStructurePo noAndAmt = new PosPaymentStructurePo();
        //支付方式与销售额
        List<PosPaymentStructurePo> paymentStructurePosList = paymentStructureMapper.queryAmtAndPayChannel(request);
        if (paymentStructurePosList != null && !paymentStructurePosList.isEmpty()) {
            //计算每个渠道的净销售额
            paymentStructurePosList.forEach(e ->
                    e.setSalesVolume((e.getSalesVolume().subtract(e.getReturnVolume())))
            );
            //计算总净销售额
            noAndAmt.setTransactionAmt(paymentStructurePosList.stream().map(PosPaymentStructurePo::getSalesVolume).reduce(BigDecimal::add).orElse(BigDecimal.ZERO));
        }
        //销售笔数
        PosPaymentStructurePo saleTotal = posOrderMapper.saleTotal(request);
        //退货笔数
        PosPaymentStructurePo returnTotal = posOrderMapper.returnTotal(request);
        //交易笔数
        noAndAmt.setTransactionNo(returnTotal.getReturnNo() + saleTotal.getSaleNo());
        //设置返回前端
        HashMap<String, Object> map = new HashMap<>();
        map.put("list", paymentStructurePosList);
        map.put("saleTotal", saleTotal);
        map.put("noAndAmt", noAndAmt);
        map.put("returnTotal", returnTotal);
        return Response.success(map);
    }
}
