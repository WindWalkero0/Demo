package com.ruihe.app.service.plan.handler.impl;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.toolkit.ObjectUtils;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.request.plan.SalesPlanInfoQueryRequest;
import com.ruihe.app.request.plan.SalesPlanOperateRequest;
import com.ruihe.app.response.plan.SalesPlanCommonResponse;
import com.ruihe.app.service.plan.handler.SalesPlanHandler;
import com.ruihe.common.dao.bean.nursing.NursingInvitePO;
import com.ruihe.common.dao.bean.nursing.NursingRecordPO;
import com.ruihe.common.dao.bean.plan.SalesPlanPo;
import com.ruihe.common.dao.mapper.NursingInviteMapper;
import com.ruihe.common.dao.mapper.NursingRecordChildMapper;
import com.ruihe.common.dao.mapper.NursingRecordMapper;
import com.ruihe.common.enums.nursing.NursingInviteStatusEnum;
import com.ruihe.common.enums.plan.PlanObjectTypeEnum;
import com.ruihe.common.pojo.response.homepage.MemberIdAndTotalAmt;
import com.ruihe.common.pojo.response.plan.SalesPlanDetailResponse;
import com.ruihe.common.pojo.response.plan.SalesPlanInfoSimpleResponse;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.TimeUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 预约登记-单日销售规划处理器
 * @author qubin
 * @date 2021年07月15日 17:38
 */
@Service(value = "APPOINTMENT")
@Slf4j
public class AppointmentSalesPlanHandler implements SalesPlanHandler {

    @Autowired
    private NursingInviteMapper nursingInviteMapper;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private NursingRecordMapper nursingRecordMapper;

    @Autowired
    private NursingRecordChildMapper nursingRecordChildMapper;

    /**
     * 获取业务id
     *
     * @param request
     * @return java.lang.String
     * @author qubin
     * @date 2021/7/15 17:36
     */
    @Override
    public Response prepare(SalesPlanOperateRequest request) {
        NursingInvitePO nursingInvitePO = nursingInviteMapper.selectById(request.getPlanObjectId());
        if (ObjectUtils.isEmpty(nursingInvitePO)) {
            return Response.errorMsg("预约记录不存在");
        }
        LocalDateTime planTime = nursingInvitePO.getInviteTime();
        //当前时间在规划时间之后，或者在同一天，则不允许编辑
        if (LocalDateTime.now().isAfter(planTime) || LocalDate.now().equals(planTime.toLocalDate())) {
            return Response.errorMsg("不允许进行销售规划");
        }
        //预约单日规划bizId为playObject_规划
        String bizId = PlanObjectTypeEnum.parse(request.getPlanObjectType()) + "_" + request.getPlanObjectId();
        return Response.success(SalesPlanCommonResponse.builder()
                .bizId(bizId)
                .planTime(planTime).build());
    }

    /**
     * @param planObjectId
     * @param bizId
     * @return com.ruihe.common.response.Response
     * @author qubin
     * @date 2021/7/16 10:52
     */
    @Override
    public Response getBaseDetail(String planObjectId, String bizId) {
        NursingInvitePO nursingInvitePO = nursingInviteMapper.selectById(planObjectId);
        if (ObjectUtils.isEmpty(nursingInvitePO)) {
            return Response.errorMsg("预约记录不存在");
        }
        bizId = PlanObjectTypeEnum.APPOINTMENT.name() + "_" + planObjectId;
        return Response.success(SalesPlanDetailResponse.builder()
                .counterId(nursingInvitePO.getCounterId())
                .planTime(nursingInvitePO.getInviteTime())
                .inviteNursingItem(nursingInvitePO.getNursingItem())
                .inviteQty(nursingInvitePO.getInviteQty())
                .memberId(nursingInvitePO.getMemberId())
                .memberPhone(nursingInvitePO.getPhone())
                .bizId(bizId).build());
    }

    /**
     * @param salesPlanDetailResponse
     * @param exitSalesPlanPo
     * @return com.ruihe.common.response.Response
     * @author qubin
     * @date 2021/7/16 11:02
     */
    @Override
    public void getActAmtAndNursingItem(SalesPlanDetailResponse salesPlanDetailResponse, SalesPlanPo exitSalesPlanPo) {
        if (exitSalesPlanPo != null) {
            // 查询实际销售额
            String memberId = salesPlanDetailResponse.getMemberId();
            LocalDateTime planTime = salesPlanDetailResponse.getPlanTime();
            BigDecimal actAmt = posOrderMapper.sumPayAmt(memberId, LocalDateTime.of(planTime.toLocalDate(), LocalTime.MIN),
                    LocalDateTime.of(planTime.toLocalDate().plusDays(1), LocalTime.MIN));
            salesPlanDetailResponse.setActAmt(actAmt);
            //查询实际护理项目
            List<String> recordIdList = nursingRecordMapper.selectNursingRecordByMemberId(memberId, LocalDateTime.of(planTime.toLocalDate(), LocalTime.MIN),
                    LocalDateTime.of(planTime.toLocalDate().plusDays(1), LocalTime.MIN));
            if (recordIdList.size() > 0) {
                List<String> nursingItemList = nursingRecordChildMapper.selectNursingItemByRecordIdList(recordIdList);
                salesPlanDetailResponse.setActNursingItem(JSONArray.parseArray(JSON.toJSONString(nursingItemList)));
            }
        }
    }

    /**
     * @param memberIdList
     * @param bizIdList
     * @param salesPlanList
     * @param request
     * @return com.ruihe.common.response.Response
     * @author qubin
     * @date 2021/7/16 13:08
     */
    @Override
    public void getBaseInfo(List<String> memberIdList, List<String> bizIdList, List<SalesPlanInfoSimpleResponse> salesPlanList, SalesPlanInfoQueryRequest request) {
        List<NursingInvitePO> nursingInvitePOList = nursingInviteMapper.selectCounterSalesPlanInfo(request.getPlanTime()
                , request.getCounterId());
        if (nursingInvitePOList == null || nursingInvitePOList.size() == 0) {
            return;
        }
        //过滤状态是取消的，且如果美导code不为空，则筛选美导code一致
        List<NursingInvitePO> nursingInvitePOs = nursingInvitePOList.stream().filter(nursingInvitePO ->
                nursingInvitePO.getNursingStatus() != (NursingInviteStatusEnum.CANCEL.getCode())
                        && StringUtils.isNotBlank(request.getBaCode()) ? request.getBaCode().equals(nursingInvitePO.getBaCode()) : true)
                .collect(Collectors.toList());
        if (nursingInvitePOs.isEmpty()) {
            return;
        }
        nursingInvitePOs.forEach(nursingInvitePO -> {
            //会员id集合
            memberIdList.add(nursingInvitePO.getMemberId());
            //规划对象id集合
            bizIdList.add(PlanObjectTypeEnum.APPOINTMENT.name() + "_" + nursingInvitePO.getInviteId());
            //初始化集合
            SalesPlanInfoSimpleResponse invite = SalesPlanInfoSimpleResponse.builder()
                    .memberId(nursingInvitePO.getMemberId())
                    .memberName(nursingInvitePO.getMemberName())
                    .memberPhone(nursingInvitePO.getPhone())
                    .baName(nursingInvitePO.getBaName())
                    .baCode(nursingInvitePO.getBaCode())
                    .planObjectId(nursingInvitePO.getInviteId())
                    .buttonStatus((LocalDate.now().isAfter(TimeUtils.getLocalDate(request.getPlanTime()))
                            || LocalDate.now().equals(nursingInvitePO.getInviteTime().toLocalDate())) ? 1 : 0)
                    .planObjectType(PlanObjectTypeEnum.APPOINTMENT.getCode())
                    .inviteTime(nursingInvitePO.getInviteTime())
                    .bizId(PlanObjectTypeEnum.APPOINTMENT.name() + "_" + nursingInvitePO.getInviteId())
                    .build();
            salesPlanList.add(invite);
        });
    }

    /**
     * @param memberIdList
     * @param request
     * @author qubin
     * @date 2021/7/16 13:20
     */
    @Override
    public Response getBatchActAmtAndNursingItem(List<String> memberIdList, SalesPlanInfoQueryRequest request, Map<String, BigDecimal> memberIdAndActAmtMap) {

        //批量查询实际销售金额
        List<MemberIdAndTotalAmt> memberIdAndTotalAmts = posOrderMapper.sumPayAmtGroupByMemberId(memberIdList,
                LocalDateTime.of(TimeUtils.getLocalDate(request.getPlanTime()), LocalTime.MIN),
                LocalDateTime.of(TimeUtils.getLocalDate(request.getPlanTime()).plusDays(1), LocalTime.MIN));
        for (MemberIdAndTotalAmt memberIdAndTotalAmt : memberIdAndTotalAmts) {
            memberIdAndActAmtMap.put(memberIdAndTotalAmt.getMemberId(), memberIdAndTotalAmt.getTotalAmt());
        }
        //查询实际护理项目
        List<NursingRecordPO> nursingRecordList = nursingRecordMapper.selectNursingRecordByMemberIdList(memberIdList,
                LocalDateTime.of(TimeUtils.getLocalDate(request.getPlanTime()), LocalTime.MIN),
                LocalDateTime.of(TimeUtils.getLocalDate(request.getPlanTime()).plusDays(1), LocalTime.MIN));
        return Response.success(nursingRecordList);
    }
}
