package com.ruihe.app.enums;

import org.springframework.util.StringUtils;

/**
 * @author huangjie
 * @description
 * @date 2021-04-30 13:29
 */

public enum WxBaWorkTypeEnum {
    /**
     * 美导排班(0:早班 1:中班 2:晚班)
     */
    MORNSHIFT(0, "早班"),
    MIDDLESHIFT(1, "中班"),
    NIGHTSHIFT(2, "晚班");
    private Integer code;
    private String msg;


    WxBaWorkTypeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static WxBaWorkTypeEnum instance(Integer key) {
        if (key == null) {
            return null;
        }
        for (WxBaWorkTypeEnum e : values()) {
            if (e.getCode().equals(key)) {
                return e;
            }
        }
        return null;
    }

    public static WxBaWorkTypeEnum getString(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (WxBaWorkTypeEnum e : values()) {
            if (e.getMsg().equals(value)) {
                return e;
            }
        }
        return null;
    }
}
