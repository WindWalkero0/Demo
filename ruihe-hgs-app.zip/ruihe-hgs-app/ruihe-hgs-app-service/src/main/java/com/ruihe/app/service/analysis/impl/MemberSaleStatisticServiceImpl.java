package com.ruihe.app.service.analysis.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.app.po.analysis.*;
import com.ruihe.app.service.analysis.MemberSaleStatisticService;
import com.ruihe.app.vo.PosMemberConsumeAnalysisVo;
import com.ruihe.app.vo.PosMemberInfoVo;
import com.ruihe.app.vo.PosMerchandisingVo;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.pojo.request.analysis.MemberSaleRequest;
import com.ruihe.common.pojo.request.analysis.SaleRankingRequest;
import com.ruihe.app.mapper.analysis.MemberSaleStatisticMapper;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 分析/会员销售统计
 *
 * @author:Fangtao
 * @Date:2019/11/2 11:03
 */
@Slf4j
@DS(DBConst.SLAVE)
@Service
public class MemberSaleStatisticServiceImpl implements MemberSaleStatisticService {
    @Autowired
    private MemberSaleStatisticMapper memberSaleStatisticMapper;

    @Ella(Describe = "会员销售统计", Author = "T")
    @Override
    public Response selectMemberSale(MemberSaleRequest request) {
        //此处可能需要加分页
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        //数据查询
        List<PosMemberSaleStatisticPo> posMemberSaleStatisticPosList = memberSaleStatisticMapper.queryMemberSale(request);
        //会员销售统计总金额与总数量
        PosMemberSaleTotalAmtQtyPo posSaleDetailReportPo = memberSaleStatisticMapper.queryQtyAndAmt(request);
        Map<String, Object> map = new HashMap<>();
        map.put("posSaleDetailReportPo", posSaleDetailReportPo);
        map.put("posMemberSaleStatisticPosList", posMemberSaleStatisticPosList);
        return Response.success(map);
    }

    @Ella(Describe = "会员详情页", Author = "T")
    @Override
    public Response memberDetail(String memberId, String counterId) {
        PosMemberDataPo posMemberDataPo = memberSaleStatisticMapper.queryMemberDataList(memberId, counterId);
        if (posMemberDataPo == null) {
            return Response.successMsg("暂无信息");
        }
        return Response.success(ObjectUtils.toObject(posMemberDataPo, PosMemberInfoVo.class));
    }

    @Ella(Describe = "会员详情页中的消费计算", Author = "T")
    @Override
    public Response consumptionCalculation(String memberId, String counterId) {
        //十二个月内购买总数与购买金额
        //2020年5月26日04:32:06 跟江欣确认过 用的是全柜台的消费记录不要counterId了
        counterId = null;
        PosMemberConsumeAnalysisVo posMemberConsumeAnalysisVo = new PosMemberConsumeAnalysisVo();
        PosMemberSaleDetailPo posMemberDetailPo = memberSaleStatisticMapper.queryDetailOfQtyAndAmt(memberId, counterId);
        if (posMemberDetailPo == null) {
            return Response.errorMsg("暂无信息");
        }
        if (posMemberDetailPo.getQty() == null) {
            posMemberConsumeAnalysisVo.setQty(0);
        } else {
            posMemberConsumeAnalysisVo.setQty(posMemberDetailPo.getQty());
        }
        if (posMemberDetailPo.getAmt() == null) {
            posMemberConsumeAnalysisVo.setAmt(BigDecimal.ZERO);
        } else {
            posMemberConsumeAnalysisVo.setAmt(posMemberDetailPo.getAmt());
        }
        //客单价
        PosMemberDetailPo posMemberDetailPo1 = memberSaleStatisticMapper.queryDetailOfRateAndPrice(memberId, counterId);
        //销售单数
        PosSalesOrderCountPo salesOrderCountPo = memberSaleStatisticMapper.queryOrderCount(memberId, counterId);
        //退货单数
        PosReturnOrderCountPo returnOrderCountPo = memberSaleStatisticMapper.queryReturnCount(memberId, counterId);
        //累计“护肤品”大类销售产品数量
        PosSalesTotalCountPo salesPrdQty = memberSaleStatisticMapper.querySalesPrdQty(memberId, counterId);
        //累计“护肤品”大类实物退货产品数量
        PosReturnTotalCountPo returnPrdQty = memberSaleStatisticMapper.queryReturnPrdQty(memberId, counterId);
        //如果销售总单数M为0
        if (salesOrderCountPo.getSaleOrderQty() + returnOrderCountPo.getReturnOrderQty() == 0) {
            posMemberConsumeAnalysisVo.setAvgPrice(BigDecimal.ZERO);
        } else {
            //客单价：查询时间段内 净销售额/ 销售总单数M(销售总单数M=累计实付金额大于0的订单数+累计退货金额大于0的订单数)
            BigDecimal avgPrice = posMemberDetailPo1.getSalesAmt().subtract(posMemberDetailPo1.getReturnAmt())
                    .divide(BigDecimal.valueOf(salesOrderCountPo.getSaleOrderQty() + returnOrderCountPo.getReturnOrderQty()), 2, RoundingMode.HALF_UP);
            posMemberConsumeAnalysisVo.setAvgPrice(avgPrice);
        }
        //连带率
        if (salesPrdQty.getSalesPrdQty() - returnPrdQty.getReturnPrdQty() != 0) {
            if ((salesOrderCountPo.getSaleOrderQty() + returnOrderCountPo.getReturnOrderQty()) == 0){
                posMemberConsumeAnalysisVo.setRelatedRate(BigDecimal.ZERO);
            }else {
                BigDecimal relatedRate =
                        BigDecimal.valueOf((salesPrdQty.getSalesPrdQty() - returnPrdQty.getReturnPrdQty()) / (salesOrderCountPo.getSaleOrderQty() + returnOrderCountPo.getReturnOrderQty()));
                posMemberConsumeAnalysisVo.setRelatedRate(relatedRate);
            }
        }
        //十二个月内最近购买时间
        PosMemberDiffTimePo posMemberDetailPo2 = memberSaleStatisticMapper.queryLatelyTime(memberId, counterId);
        if (posMemberDetailPo2 != null) {
            posMemberConsumeAnalysisVo.setDiffTime(posMemberDetailPo2.getDiffTime());
        }
        return Response.success(posMemberConsumeAnalysisVo);
    }

    @Ella(Describe = "商品销售排行", Author = "T")
    @Override
    public Response saleRanking(SaleRankingRequest request) {
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        //数据查询
        List<PosMerchandisingPo> posMerchandisingPosList = memberSaleStatisticMapper.queryMerchandising(request);
        for (int i = 0; i < posMerchandisingPosList.size(); i++) {
            PosMerchandisingPo posMerchandisingPo = posMerchandisingPosList.get(i);
            if (posMerchandisingPo.getSalesQty() == 0) {
                posMerchandisingPosList.remove(i);
                //2020年3月31日09:47:55
                i--;
            }
        }
        //取总金额和总数量的值并且设置
        //2020年4月23日19:44:57 刚刚找江欣确认过 只有这地方是用的数量乘以金额 其余的都是用的卖的钱 减去退的钱
        int qty = 0;
        BigDecimal amt = BigDecimal.ZERO;
        if (posMerchandisingPosList.size() == 0) {

        } else {
            for (PosMerchandisingPo posMerchandisingPo : posMerchandisingPosList) {
                qty += posMerchandisingPo.getSalesQty();
                amt = amt.add(posMerchandisingPo.getPurchasingAmt());
            }
        }
        PosMerchandisingVo posMerchandisingVo = new PosMerchandisingVo();
        posMerchandisingVo.setAmt(amt);
        posMerchandisingVo.setQty(qty);
        HashMap<Object, Object> map = new HashMap<>();
        map.put("amtAndQty", posMerchandisingVo);
        map.put("list", posMerchandisingPosList);
        return Response.success(map);
    }
}
