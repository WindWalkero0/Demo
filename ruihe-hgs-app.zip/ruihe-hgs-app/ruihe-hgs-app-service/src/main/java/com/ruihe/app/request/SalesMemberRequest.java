package com.ruihe.app.request;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Api(description = "销售录入匹配促销活动会员信息接收类")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SalesMemberRequest {

    @ApiModelProperty("会员唯一标识")
    private String memberId;

}
