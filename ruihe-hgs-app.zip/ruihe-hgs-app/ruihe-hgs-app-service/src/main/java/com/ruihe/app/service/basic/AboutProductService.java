package com.ruihe.app.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.constant.DBConst;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@DS(DBConst.SLAVE)
@Service
public class AboutProductService {


    @Autowired
    private CustomService customService;


    @Ella(Describe = "查询商品信息", Author = "K")
    public Product selectProduct(Product product) {
        return customService.select(product);
    }

    @Ella(Describe = "查询商品信息集合", Author = "K")
    public List<Product> selectProducts(Product product) {
        return customService.selectList(product);
    }
}
