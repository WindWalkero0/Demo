package com.ruihe.app.service.order;

import com.ruihe.app.request.member.BaVisitBatchListRequest;
import com.ruihe.app.request.member.BaVisitBatchRequest;
import com.ruihe.app.request.member.BaVisitQueryRequest;
import com.ruihe.app.request.member.BaVisitRequest;
import com.ruihe.common.pojo.ResultVO;
import com.ruihe.common.response.Response;

import java.util.List;

/**
 * ba回访记录
 *
 * @author fly
 * @since 2020年10月14日15:20:53
 */
public interface PosBaVisitService {
    /**
     * 添加回访记录
     *
     * @param baVisitRequest
     * @return
     */
    Response addVisit(BaVisitRequest baVisitRequest);

    /**
     * 批量添加回访记录
     * 
     * @param request
     * @return
     */
    Response addBatchVisit(BaVisitBatchListRequest request);

    /**
     * 查询添加回访记录的分类
     * @return
     */
    Response selectType();

    /**
     * 服务记录查询-分页
     * 
     * @param request
     * @return
     */
    Response list(BaVisitQueryRequest request);

    /**
     * 计算当前日期所属财务月的开始日期
     * 
     * @return
     */
    Response getFinancialInfo();
}
