package com.ruihe.app.enums;

/**
 * 0未完成（没有达到奖励条件） 1未发放（没有达到发放条件） 2已发放 3已回收
 *
 * @author fly
 */
public enum InvitingStatusEnum {

    UN_COMMIT(0, "未完成（没有达到奖励条件）"),
    UN_AWARD(1, "未发放（没有达到发放条件）"),
    AWARDED(2, "已发放"),
    RECYCLE(3, "已回收"),
    ;


    private Integer code;
    private String msg;


    InvitingStatusEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
