package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-24 10:19
 */
@ApiModel(value = "WhReturnItemRequest", description = "退库申请详情请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhReturnItemRequest implements Serializable {


    @ApiModelProperty(value = "申请编号,新增的时候可以为空")
    private String returnNo;

    @NotNull(message = "产品条码不能为空")
    @ApiModelProperty(value = "产品条码", required = true)
    private String prdBarCode;

    @NotNull(message = "厂商编码不能为空")
    @ApiModelProperty(value = "厂商编码", required = true)
    private String goodsBarCode;

    @NotNull(message = "产品名称不能为空")
    @ApiModelProperty(value = "产品名称", required = true)
    private String prdName;

    @NotNull(message = "销售价格不能为空")
    @ApiModelProperty(value = "销售价格", required = true)
    private BigDecimal memberPrice;

    @ApiModelProperty(value = "申请数量", required = true)
    @Min(value = 1, message = "数量不能小于1")
    private Integer applyQty;
}
