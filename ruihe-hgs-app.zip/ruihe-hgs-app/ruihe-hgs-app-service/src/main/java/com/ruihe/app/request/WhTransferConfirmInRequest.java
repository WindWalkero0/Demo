package com.ruihe.app.request;

import com.ruihe.app.vo.WhTransferConfirmItemVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author:Fangtao
 * @Date:2019/11/7 10:49
 */
@ApiModel(value = "WhTransferConfirmInRequest", description = "新建调拨单实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhTransferConfirmInRequest implements Serializable {
    @ApiModelProperty(value = "调拨单号(也做唯一键),确认调入时必传")
    private String transferOrderNo;
    @ApiModelProperty(value = "调入申请ba代码")
    private String inBaCode;
    @ApiModelProperty(value = "调入申请ba姓名")
    private String inBaName;
    @ApiModelProperty(value = "申请调入柜台号")
    private String inCounterId;
    @ApiModelProperty(value = "申请调入柜台名称")
    private String inCounterName;
    @ApiModelProperty(value = "调出柜台id")
    private String outCounterId;
    @ApiModelProperty(value = "调出柜台名称")
    private String outCounterName;
    @ApiModelProperty(value = "申请调入商品总数量")
    private Integer inGoodsQty;
    @ApiModelProperty(value = "确认调入商品总数量")
    private Integer ackInQty;
    @ApiModelProperty(value = "1编辑中(A)->2待调出(A)->3确认调出(B)/4拒绝(B)->5确认-成功(A)/6拒收(A)")
    private Integer status;
    @ApiModelProperty(value = "调出ba代码")
    private String outBaCode;
    @ApiModelProperty(value = "调出ba姓名")
    private String outBaName;
    @ApiModelProperty(value = "确认金额")
    private BigDecimal ackAmt;

    @ApiModelProperty(value = "入库明细")
    List<WhTransferConfirmItemVo> transferItemList;
}
