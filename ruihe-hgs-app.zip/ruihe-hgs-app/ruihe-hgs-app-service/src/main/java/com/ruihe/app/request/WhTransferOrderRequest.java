package com.ruihe.app.request;

import com.ruihe.app.vo.WhTransferItemVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

@ApiModel(value = "WhTransferOrderRequest", description = "调入单实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhTransferOrderRequest implements Serializable {
    @ApiModelProperty(value = "调拨单号(也做唯一键)")
    private String transferOrderNo;
    @ApiModelProperty(value = "申请调入柜台号")
    private String inCounterId;
    @ApiModelProperty(value = "申请调入柜台名称")
    private String inCounterName;
    @ApiModelProperty(value = "调出柜台id")
    private String outCounterId;
    @ApiModelProperty(value = "调出柜台名称")
    private String outCounterName;
    @ApiModelProperty(value = "申请调入商品总数量")
    private Integer inGoodsQty;
   /* @ApiModelProperty(value = "产品条码(对外标准条码)")
    private String prdBarCode;
    @ApiModelProperty(value = "产品名称")
    private String prdName;
    @ApiModelProperty(value = "商品条码")
    private String goodsBarCode;
    @ApiModelProperty(value = "申请调入数")
    private Integer inQty;
    @ApiModelProperty(value = "单价")
    private BigDecimal price;*/
    @ApiModelProperty(value = "调入申请ba代码")
    private String inBaCode;
    @ApiModelProperty(value = "调入申请ba姓名")
    private String inBaName;
    @ApiModelProperty(value = "调入申请金额")
    private BigDecimal inAmt;
    @ApiModelProperty(value = "判断是暂存还是确认")
    private Integer choose;

    List<WhTransferItemVo> transferItemList;
}
