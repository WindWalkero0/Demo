package com.ruihe.app.service.basic.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.member.RegionalManageMapper;
import com.ruihe.app.service.basic.QueryRegionalService;
import com.ruihe.app.vo.RegionVo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.Region;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.Collator;
import java.util.List;
import java.util.Locale;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-24 10:36
 */
@Slf4j
@DS(DBConst.SLAVE)
@Service
public class QueryRegionalServiceImpl implements QueryRegionalService {

    @Autowired
    private RegionalManageMapper regionalManageMapper;

    private Collator collator = Collator.getInstance(Locale.CHINA);

    /**
     * 查询省份信息
     *
     * @return
     */
    @Override
    public Response queryProvince() {
        LambdaQueryWrapper<Region> queryWrapper = Wrappers.<Region>lambdaQuery().eq(Region::getLevel, 1).eq(Region::getIsDel, 0);
        List<Region> regionList = regionalManageMapper.selectList(queryWrapper);
        if (regionList.isEmpty()) {
            return Response.successMsg("无");
        }
        /**
         * modify by qubin 2021-05-12
         * 根据欧阳需求对省做首字母排序
         */
        //暂时对多音字重庆做个性化处理
        regionList.sort((o1, o2) -> collator.compare(o1.getRegionName().equals("重庆市")? "chongqing" : o1.getRegionName(), o2.getRegionName()));
        return Response.success(ObjectUtils.toList(regionList, RegionVo.class));
    }

    /**
     * 根据省份的code值查询关联的城市
     *
     * @param regionalCode
     * @return
     */
    @Override
    public Response queryCity(String regionalCode) {
        LambdaQueryWrapper<Region> queryWrapper = Wrappers.<Region>lambdaQuery().eq(Region::getParentCode, regionalCode).eq(Region::getIsDel, 0);
        List<Region> regionList = regionalManageMapper.selectList(queryWrapper);
        if (regionList.isEmpty()) {
            return Response.success();
        }
        return Response.success(ObjectUtils.toList(regionList, RegionVo.class));
    }
}
