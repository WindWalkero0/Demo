package com.ruihe.app.event;

/**
 * 退货订单事件-积分处理
 *
 * @author William
 */
public class ReturnOrder4IntegralEvent extends OrderEvent {
    public ReturnOrder4IntegralEvent(Object source, String orderNo) {
        super(source, orderNo);
    }
}
