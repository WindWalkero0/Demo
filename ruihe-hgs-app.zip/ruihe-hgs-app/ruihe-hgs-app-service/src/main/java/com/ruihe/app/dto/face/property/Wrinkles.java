package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class Wrinkles {

    private String area;

    private Integer wrinkleTypeId;

    private Integer level;

    /**
     * 左边面积值(只有法令纹和鱼尾纹有左右面积)
     */
    private Integer left;
    /**
     * 右边面积值(只有法令纹和鱼尾纹有左右面积)
     */
    private Integer right;

    private OverallArea overallArea;

    public static boolean getProblemData(Wrinkles wrinkles) {
        return wrinkles.getLevel() > 1;
    }
}
