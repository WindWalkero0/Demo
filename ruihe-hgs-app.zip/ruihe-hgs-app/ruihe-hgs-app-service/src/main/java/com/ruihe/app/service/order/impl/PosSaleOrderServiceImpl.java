package com.ruihe.app.service.order.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ruihe.app.constant.BizConst;
import com.ruihe.app.enums.OrderChannelEnum;
import com.ruihe.app.enums.OrderNoPrefixEnum;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.enums.OrderTypeEnum;
import com.ruihe.app.event.*;
import com.ruihe.app.mapper.member.MemberCouponMapper;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.app.mapper.order.PosOrderItemMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.mapper.order.PosPaymentOrderMapper;
import com.ruihe.app.request.PosSaleOrderRequest;
import com.ruihe.app.service.basic.AboutCounterService;
import com.ruihe.app.service.member.AboutMemberActivityService;
import com.ruihe.app.service.member.MemberService;
import com.ruihe.app.service.order.*;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderPo;
import com.ruihe.common.dao.bean.member.*;
import com.ruihe.common.dao.bean.order.PosOrderActivity;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.dao.bean.order.PosPaymentOrderPo;
import com.ruihe.common.dao.bean.promotion.PromotionActivity;
import com.ruihe.common.dao.bean.promotion.PromotionCoupon;
import com.ruihe.common.dao.bean.system.SystemConfigPo;
import com.ruihe.common.dao.mapper.MemberKbActivityMapper;
import com.ruihe.common.dao.mapper.SystemConfigMapper;
import com.ruihe.common.dao.mapper.integral.IntegralAccountMapper;
import com.ruihe.common.dao.mapper.integral.IntegralOrderMapper;
import com.ruihe.common.enums.activity.ActivityTypeEnum;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.member.MemberActivityEnum;
import com.ruihe.common.enums.member.MemberInfoEnum;
import com.ruihe.common.enums.member.MemberOperationSourceEnum;
import com.ruihe.common.enums.order.OrderItemProductTypeEnum;
import com.ruihe.common.enums.promotion.PromotionalEnum;
import com.ruihe.common.enums.sat.SatTypeEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.enums.system.SystemPosConfigEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.request.member.MemberOperationRequest;
import com.ruihe.common.profile.BufferedProfile;
import com.ruihe.common.response.Response;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.util.ProductUtil;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.LinkedValidator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.tuple.MutableTriple;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.http.HttpStatus;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.ruihe.common.utils.StrategyCommon.BK_CUXIAO;
import static com.ruihe.common.utils.StrategyCommon.CUXIAO;


/**
 * POS销售
 *
 * @author William
 */
@Service
@Slf4j
public class PosSaleOrderServiceImpl implements PosSaleOrderService, ApplicationContextAware {

    private final PosOrderMapper posOrderMapper;
    private final CustomService customService;
    private final PosOrderItemMapper posOrderItemMapper;
    private final MemberMapper memberMapper;
    private final PosPaymentOrderMapper posPaymentOrderMapper;
    private final AboutMemberActivityService memberActivityService;
    private final MemberService memberService;
    private final AboutCounterService aboutCounterService;
    private final ActivityOrderService activityOrderService;
    private final IntegralAccountMapper integralAccountMapper;
    private ApplicationContext applicationContext;
    private final MemberCouponMapper memberCouponMapper;
    private final SystemConfigMapper systemConfigMapper;
    private final IntegralOrderMapper integralOrderMapper;
    private final MemberKbActivityMapper memberKbActivityMapper;

    public PosSaleOrderServiceImpl(PosOrderMapper posOrderMapper, CustomService customService,
                                   PosOrderItemMapper posOrderItemMapper, MemberMapper memberMapper,
                                   PosPaymentOrderMapper posPaymentOrderMapper,
                                   AboutMemberActivityService memberActivityService, MemberService memberService,
                                   AboutCounterService aboutCounterService, ActivityOrderService activityOrderService
            , IntegralAccountMapper integralAccountMapper, MemberCouponMapper memberCouponMapper, SystemConfigMapper systemConfigMapper, IntegralOrderMapper integralOrderMapper, MemberKbActivityMapper memberKbActivityMapper) {
        this.posOrderMapper = posOrderMapper;
        this.customService = customService;
        this.posOrderItemMapper = posOrderItemMapper;
        this.memberMapper = memberMapper;
        this.posPaymentOrderMapper = posPaymentOrderMapper;
        this.memberActivityService = memberActivityService;
        this.memberService = memberService;
        this.aboutCounterService = aboutCounterService;
        this.activityOrderService = activityOrderService;
        this.integralAccountMapper = integralAccountMapper;
        this.memberCouponMapper = memberCouponMapper;
        this.systemConfigMapper = systemConfigMapper;
        this.integralOrderMapper = integralOrderMapper;
        this.memberKbActivityMapper = memberKbActivityMapper;
    }

    @Autowired
    private OrderRefundService orderRefundService;

    @Override
    public void setApplicationContext(@NonNull ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }


    /**
     * 销售下单【正常销售（附加促销活动）、预订单、积分兑换】
     * 退货下单【正常销售（附加促销活动）、预订单、积分兑换】、以及空退
     *
     * @param request
     * @return Response
     */
    @Override
    @BufferedProfile(minTime = 200)
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response placeOrder(PosSaleOrderRequest request) throws Exception {
        //首先校验参数合法性
        LinkedValidator validator = this.validate(request);
        if (validator.isInvalid()) {
            return Response.errorMsg(validator.getErrorMsg());
        }
        //正常销售价格填充
        Integer activityType = operationRequestItem(request);
        //临时需求限定外购品商品 2021年3月20日13:55:42 取消掉放到前一个接口校验
        if (request.getTransType().equals(OrderTransTypeEnum.GOODS_OUT.getCode())) {
            temporaryDemand(request);
        }
        CounterInformation counter = aboutCounterService.selectCounterInfo(CounterInformation.builder().counterId(request.getCounterId()).isDel(StatusEnum.UN_DELETED.getKey()).build());
        if (counter == null) {
            return Response.errorMsg("柜台不存在");
        }
        //生成订单号
        String orderNo = IdGenerator.getShorterSerialNo(OrderTransTypeEnum.GOODS_RETURN.getCode().equals(request.getTransType()) ? OrderNoPrefixEnum.SRMP.getCode() : OrderNoPrefixEnum.NSMP.getCode());
        if (activityType.equals(ActivityTypeEnum.INTEGRAL_EXCH.getCode())) {
            orderNo = IdGenerator.getShorterSerialNo(OrderNoPrefixEnum.PXMP.getCode());
        }
        //会员销售memberId必传,手机号码预订单必传
        MemberInfo memberInfo = StringUtils.isBlank(request.getMemberId()) ? null : memberMapper.selectById(request.getMemberId().trim());
        if (memberInfo != null) {
            CounterInformation counterInformation = customService.select(CounterInformation.builder().counterId(memberInfo.getCounterId()).build());
            if (counterInformation == null) {
                return Response.errorMsg("该会员发卡柜台不存在");
            }
            if (counterInformation.getCounterType().equals(CounterEnum.TEST_COUNTER.getKey())) {
                memberInfo.setMemberType(0);
            }
            //当微信注册用户首次在某个柜台消费后，其发卡柜台，发卡BA自动更新为购买柜台，首单的BA
            this.dealMemberInfo(memberInfo, request, counter.getCounterName());
        }
        //处理订单明细计算时需要排除虚拟商品，二期需求app传了虚拟商品
        List<PosOrderItemPo> posOrderItemList = this.extractOrderItemList(memberInfo, counter, request, orderNo);
        //全部退还----优惠券处理逻辑
        orderRefundService.operationReturnGoods(request.getOriginalOrderNo(), request.getTransType(), request.getMemberId());
        //活动监测并处理
        final AcitivityMatchContext activityCtx = AcitivityMatchContext.builder().discountAmt(BigDecimal.ZERO).build();
        //生成虚拟商品并关联活动订单信息
        List<PosOrderActivity> posOrderActivities = activityOrderService.operationOrderItems(activityCtx, memberInfo, counter, posOrderItemList, request, orderNo);
        //处理分摊后金额//需要重新计算??能否放在处理优惠券信息后面
        this.calcOrderItemShareAmt(request, activityCtx, posOrderActivities, posOrderItemList);
        //校验下单积分是否充足
        checkIntegral(activityCtx, memberInfo, posOrderItemList);
        //构造订单
        PosOrderPo posOrderPo = this.extractOrder(activityCtx, counter, memberInfo, request, orderNo, posOrderItemList, activityType);
        //处理优惠券信息并赋予订单类型
        activityOrderService.saveActivityLog(posOrderActivities, posOrderPo);
        //1、订单-落地订单
        int rows = posOrderMapper.insert(posOrderPo);
        if (rows != 1) {
            throw new BizException("销售录入失败！");
        }
        //2、订单-落地订单明细
        rows = posOrderItemMapper.batchInsert(posOrderItemList);
        if (rows != posOrderItemList.size()) {
            log.error("销售录入失败！posOrderItemList={}", posOrderItemList);
            throw new BizException("销售录入失败！");
        }
        //3、支付订单【销售、查单退货、空退需要构造组合支付信息】
        List<PosPaymentOrderPo> paymentOrderList = this.extractPaymentOrder(posOrderPo, request, orderNo);
        rows = posPaymentOrderMapper.batchInsert(paymentOrderList);
        if (rows != paymentOrderList.size()) {
            log.error("销售录入失败！paymentOrderList={}", paymentOrderList);
            throw new BizException("销售录入失败！");
        }
        //4、会员入会&升降级-->积分逻辑处理
        if (memberInfo != null) {
            //2021年1月25日13:39:25 积分控制在等级变化前后等级去计算的
            SystemConfigPo systemConfigPoList = systemConfigMapper.selectOne(Wrappers.<SystemConfigPo>lambdaQuery()
                    .eq(SystemConfigPo::getParamKey, SystemPosConfigEnum.UPGRADE_LEVEL_INTEGRAL.getMsg()));
            if (systemConfigPoList == null || systemConfigPoList.getStatus().equals(CommonStatusEnum.INVALID.getCode())) {
                throw new BizException("缺少积分配置！");
            }
            //0：升级前；1：升级后
            if (systemConfigPoList.getParamValue().equals(BigInteger.ZERO.toString())) {
                Order4IntegralBeforeLevelEvent order4IntegralBeforeLevelEvent = new Order4IntegralBeforeLevelEvent(this, memberInfo.getMemberId(), orderNo);
                this.applicationContext.publishEvent(order4IntegralBeforeLevelEvent);
            } else if (systemConfigPoList.getParamValue().equals(BigInteger.ONE.toString())) {
                //先等级后积分
                Order4MemberEntranceEvent order4MemberEntranceEvent = new Order4MemberEntranceEvent(this, memberInfo.getMemberId(), orderNo);
                this.applicationContext.publishEvent(order4MemberEntranceEvent);
            } else {
                throw new BizException("错误的积分配置！");
            }
        }
        /*5、库存处理,预订单没有真正出入库操作*/
        if (!OrderTypeEnum.BOOK.getCode().equals(request.getOrderType())) {
            Order4StockEvent order4StockEvent = new Order4StockEvent(this, orderNo);
            this.applicationContext.publishEvent(order4StockEvent);
        }
        //6、处理销售速报，测试柜台数据不统计（同时将数据发送到前端）
        if (counter.getCounterType().equals(CounterEnum.FORMAL_COUNTER.getKey())) {
            SalesEvent salesEvent = new SalesEvent(this, orderNo);
            this.applicationContext.publishEvent(salesEvent);
        }
//        7、查看是否发券活动要求
        if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(request.getTransType()) && memberInfo != null) {
            //购买并且未使用优惠
            PromotionCouponEvent promotionCouponEvent = new PromotionCouponEvent(this, memberInfo, activityType, orderNo, request.getProducts(), request.getCounterId());
            this.applicationContext.publishEvent(promotionCouponEvent);
        }
        //8、处理每月微信未激活可销售人数(暂时不在订单中进行逻辑判断，因为每个门店只有一台POS机，不会出现并行的问题)
        if (memberInfo != null) {
            Order4WxUnActiveSaleEvent order4WxUnActiveSaleEvent = new Order4WxUnActiveSaleEvent(this, memberInfo.getMemberId(), counter.getCounterId());
            this.applicationContext.publishEvent(order4WxUnActiveSaleEvent);
        }
        //9、会员满意度销售问卷
        if (StringUtils.isNotBlank(posOrderPo.getMemberId())) {
            SatEvalAppEvent satEvalAppEvent = new SatEvalAppEvent(this, orderNo, SatTypeEnum.SALES_EVALUATION.getKey());
            this.applicationContext.publishEvent(satEvalAppEvent);
        }
        //返回订单号
        Map<String, String> map = Maps.newHashMap();
        map.put("orderNo", posOrderPo.getOrderNo());
        map.put("receiptNo", posOrderPo.getReceiptNo());
        return Response.successDataMsg(map, "操作成功");
    }

    /**
     * 校验积分
     *
     * @param acitivityCtx
     * @param memberInfo
     * @param orderItemList
     */
    private void checkIntegral(AcitivityMatchContext acitivityCtx, MemberInfo memberInfo,
                               List<PosOrderItemPo> orderItemList) {
        //2021年4月6日11:21:42 看看积分是否充足
        if (acitivityCtx.getIntePayable() != null && acitivityCtx.getIntePayable() != 0) {
            //购买订单花费了积分  肯定是会员销售
            if (memberInfo != null) {
                //非空退判断积分是否充足
                IntegralAccountPo integralAccountPo = integralAccountMapper.selectById(memberInfo.getMemberId());
                if (integralAccountPo == null) {
                    throw new BizException("不存在账户信息！");
                }
                List<String> collect = orderItemList.stream()
                        .filter(e -> e.getIsVirtual().intValue() == BigInteger.ONE.intValue())
                        .filter(e -> e.getActivityId() != null)
                        .map(PosOrderItemPo::getActivityId)
                        .collect(Collectors.toList());
                Integer activityTypeRule = activityOrderService.getActivityTypeRule(collect);
                if (activityTypeRule.equals(0)) {
                    //老积分
                    if (integralAccountPo.getOldQty() < Math.abs(acitivityCtx.getIntePayable())) {
                        throw new BizException("可用积分不足,无法积分兑换！");
                    }
                } else if (activityTypeRule.equals(1)) {
                    //新积分
                    if (integralAccountPo.getNewQty() < Math.abs(acitivityCtx.getIntePayable())) {
                        throw new BizException("可用积分不足,无法积分兑换！");
                    }
                }
            }
        }
    }

    /**
     * 临时需求限定外购品商品
     */
    private void temporaryDemand(PosSaleOrderRequest request) {
        List<PosSaleOrderRequest.OrderItemRequest> collect = request.getOrderItemList().stream().filter(orderItemRequest -> orderItemRequest.getIsVirtual().equals(0)).collect(Collectors.toList());
        request.getOrderItemList().stream().filter(orderItemRequest -> orderItemRequest.getIsVirtual().equals(1) && orderItemRequest.getProType().equals(0)).forEach(orderItemRequest -> {
            MemberActivitySon memberActivitySon = customService.select(MemberActivitySon.builder().activityId(orderItemRequest.getActivityId()).build());
            if (memberActivitySon == null) {
                log.error("活动:{},不存在", orderItemRequest.getActivityId());
                throw new BizException("活动不存在");
            }
            //外购品只能选一个活动进行使用,且只针对于老积分活动不针对于新积分活动
            MemberActivity memberActivity = customService.select(MemberActivity
                    .builder()
                    .subjectType(MemberActivityEnum.EXCHANGE_ACTIVITY.getKey())
                    .activityType(MemberActivityEnum.PRODUCT_TYPE.getKey())
                    .typeRule(0)
                    .activityId(memberActivitySon.getSubjectId())
                    .build());
            if (memberActivity != null) {//进行限制
                if (collect.size() > 1) {
                    log.error("外购品活动只能选择对应活动的一种商品");
                    throw new BizException("积分兑换档次内容与实际产品不一致，请返回后重新调整产品再试");
                }
                if (collect.size() == 1) {
                    PosSaleOrderRequest.OrderItemRequest product = collect.get(0);
                    if (product.getPurQty() > 1) {
                        log.error("外购品数量不能超过1个，请返回修改数量重试");
                        throw new BizException("外购品数量不能超过1个，请返回修改数量重试");
                    }
                    if (!memberActivitySon.getName().contains(product.getPrdName())) {
                        log.error("积分兑换档次:{},内容与实际产品:{},不一致", memberActivitySon.getName() + "(" + memberActivitySon.getActivityId() + ")", product.getPrdName() + "(" + product.getGoodsBarCode() + ")");
                        throw new BizException("积分兑换档次内容与实际产品不一致，请返回后重新调整产品再试");
                    }
                }
            }
        });
    }


    /**
     * 检查优惠券有没有被使用
     *
     * @param request request
     */
    private void checkCouponIsAvailable(PosSaleOrderRequest request) {
        request.getOrderItemList().stream()
                .filter(it -> StringUtils.isNotBlank(it.getCouponId()))
                .forEach(it -> {
                    final var couponId = it.getCouponId();
                    final var whereCondition = Wrappers.<MemberCoupon>lambdaQuery()
                            .eq(MemberCoupon::getCouponId, couponId)
                            .eq(MemberCoupon::getMemberId, request.getMemberId())
                            .eq(MemberCoupon::getStatus, 0);
                    var unUsedCoupon = memberCouponMapper.selectOne(whereCondition);
                    if (ObjectUtils.isEmpty(unUsedCoupon)) {
                        log.warn("下单失败，优惠券已使用request={}", JSONObject.toJSONString(request));
                        throw new BizException("优惠券已使用，请到查单退货界面确认");
                    }
                });
    }


    @Ella(Describe = "销售最终价格填充")
    private Integer operationRequestItem(PosSaleOrderRequest request) {
        //正常销售
        if (request.getTransType().equals(OrderTransTypeEnum.GOODS_OUT.getCode())) {
            request.getOrderItemList().stream().forEach(orderItemRequest -> {
                if (orderItemRequest.getDiscernType() == null) {
                    log.warn("是否是购物车商品类型未传递discernType={},request={}", orderItemRequest, JSONObject.toJSONString(request));
                    throw new BizException("是否是购物车商品类型未传递");
                } else if (orderItemRequest.getDiscernType().equals(2)) {//2是为了兼容之前的值 传递的值只有两种情况 0购物车1奖励商品
                    log.warn("错误的商品类型discernType={},request={}", orderItemRequest.getDiscernType(), JSONObject.toJSONString(request));
                    throw new BizException("商品是否是购物车商品类型传递错误");
                }
                if (orderItemRequest.getResultPrice() == null) {
                    throw new BizException(orderItemRequest.getPrdBarCode() + "商品最终价格没有传递");
                }
            });
            List<PosSaleOrderRequest.OrderItemRequest> collect =
                    request.getOrderItemList().stream().filter(orderItemRequest -> orderItemRequest.getIsVirtual().equals(1)).collect(Collectors.toList());
            if (!collect.isEmpty()) {
                if (collect.size() > 1) {
                    return ActivityTypeEnum.MULTIPLE.getCode();
                }
                return collect.get(0).getProType();
            }
            return ActivityTypeEnum.NONE.getCode();
        } else if (request.isKt()) {
            //空退业务所有商品全是实物商品
            request.getOrderItemList().parallelStream().forEach(e -> e.setIsVirtual(0));
        }
        return ActivityTypeEnum.NONE.getCode();
    }

    /**
     * 当微信注册用户首次在某个柜台消费后，其发卡柜台，发卡BA自动更新为购买柜台，首单的BA
     *
     * @param memberInfo
     * @param request
     * @param counterName
     */
    private void dealMemberInfo(MemberInfo memberInfo, PosSaleOrderRequest request, String counterName) throws Exception {
        //此处直接从数据库拿来写死的，如果有变动，需要批量进行修改
        if (memberInfo.getBaId().equals(CommonConstant.WX_BA_CODE) || memberInfo.getCounterId().equals(CommonConstant.WX_COUNTER_CODE)) {
            memberInfo.setBaId(request.getBaCode());
            memberInfo.setBaName(request.getBaName());
            memberInfo.setCounterId(request.getCounterId());
            memberInfo.setCounterName(counterName);
            memberInfo.setUpdateTime(LocalDateTime.now());
            int rows = memberMapper.update(memberInfo, Wrappers.<MemberInfo>lambdaUpdate().eq(MemberInfo::getMemberId
                    , memberInfo.getMemberId()));
            if (rows != 1) {
                log.error("销售录入失败！memberInfo={}", memberInfo);
                throw new BizException("销售录入失败！");
            }
            //生成修改履历
            MemberOperation memberOperation = MemberOperation
                    .builder()
                    .counterId(memberInfo.getCounterId())
                    .counterName(memberInfo.getCounterName())
                    .empId(memberInfo.getBaId())
                    .empName(memberInfo.getBaName())
                    .remark("微信用户首次购买")
                    .source(MemberOperationSourceEnum.POS.getValue())
                    .type(MemberInfoEnum.OPERATION_UPDATE.getKey())
                    .build();
            MemberOperationRequest memberOperationRequest = MemberOperationRequest
                    .builder()
                    .memberInfo(memberInfo.convert2DTO())
                    .memberOperation(memberOperation.convert2DTO())
                    .build();
            memberService.fillOperation(memberOperationRequest);
        }
    }

    /**
     * 基本校验
     *
     * @param request
     * @return
     */
    private LinkedValidator validate(PosSaleOrderRequest request) {
        LinkedValidator validator = LinkedValidator.newInstance();
        validator.checkStringNotBlank(request.getBaCode(), "请填写BA代码！");
        validator.checkStringNotBlank(request.getBaName(), "请填写BA姓名！");
        validator.checkStringNotBlank(request.getCounterId(), "请填写柜台id！");
        validator.checkObjectNotNull(request.getOrderType(), "请填写订单类型！");
        validator.checkObjectNotNull(request.getTransType(), "请填写交易类型！");
        validator.checkObjectNotEmpty(request.getPaymentOrderList(), "请填写收/退款信息！");
        if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(request.getTransType())) {
            validator.checkObjectNotEmpty(request.getOrderItemList(), "未选择商品！");
            if (request.getOrderItemList() != null) {
                List<PosSaleOrderRequest.OrderItemRequest> orderItemList = request.getOrderItemList();
                orderItemList.parallelStream().forEach(orderItemRequest -> {
                    validator.checkStringNotBlank(orderItemRequest.getPrdBarCode(), "商品编码未传递");
                    validator.checkStringNotBlank(orderItemRequest.getGoodsBarCode(), "商品条码未传递");
                    validator.checkStringNotBlank(orderItemRequest.getPrdName(), "商品名称未传递");
                    validator.checkObjectNotNull(orderItemRequest.getProType(), "商品类型未传递");
                });
            }
        } else if (OrderTransTypeEnum.GOODS_RETURN.getCode().equals(request.getTransType())
                && StringUtils.isNotBlank(request.getOriginalOrderNo())) {
            //非空退必须校验订单是否存在
            Integer count =
                    posOrderMapper.selectCount(Wrappers.<PosOrderPo>lambdaQuery().eq(PosOrderPo::getPreOrderNo,
                            request.getOriginalOrderNo()));
            validator.checkTrue(count == BigInteger.ZERO.intValue(), "该订单已退货，请选择其他订单！");
        } else if (request.isKt()) {
            //空退校验
            validator.checkObjectNotEmpty(request.getPaymentOrderList(), "请填写退款信息！");
        }
        if (OrderTypeEnum.BOOK.getCode().equals(request.getOrderType())
                && OrderTransTypeEnum.GOODS_OUT.getCode().equals(request.getTransType())) {
            validator.checkObjectNotNull(request.getRsvPickUpTime(), "请填写预计提货日期！");
            validator.checkTrue(request.getRsvPickUpTime().isAfter(LocalDate.now().plusDays(-1)), "预计提货日期不能早于今天！");
            validator.checkObjectNotEmpty(request.getMemberPhone(), "请填写手机号码！");
        }
        if (request.getBizTime() != null) {
            validator.checkTrue(request.getBizTime().isBefore(LocalDateTime.now()), "补录时间不能晚于现在");
        }
        //下单验证优惠券
        if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(request.getTransType())) {
            this.checkCouponIsAvailable(request);
        }
        // 判断的退单ba是不是当前订单所属ba
        if (OrderTransTypeEnum.GOODS_RETURN.getCode().equals(request.getTransType())
                && StringUtils.isNotBlank(request.getOriginalOrderNo())) {
            PosOrderPo orderPo = posOrderMapper.selectById(request.getOriginalOrderNo());
            validator.checkTrue(orderPo != null && orderPo.getBaCode().equals(request.getBaCode()), "不能退货到其他BA");
        }
        //2021年3月29日11:07:30 如果最后一笔的订单没有积分生成记录就报个警
        if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(request.getTransType()) && !StringUtils.isBlank(request.getMemberId())) {
            PosOrderPo posOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery().eq(PosOrderPo::getMemberId, request.getMemberId()).orderByDesc(PosOrderPo::getCreateTime).last("LIMIT 0,1"));
            if (posOrderPo == null) {
                //第一次下单
            } else {
                IntegralOrderPo integralOrderPo = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery().eq(IntegralOrderPo::getBizNo, posOrderPo.getOrderNo()));
                if (integralOrderPo == null) {
                    log.error("用户{}的最后一笔订单{}还没有处理完积分", request.getMemberId(), posOrderPo.getOrderNo());
                }
            }
        }
        return validator;
    }

    /**
     * 构造订单明细
     *
     * @param memberInfo
     * @param request
     * @param newOrderNo
     * @return
     */
    private List<PosOrderItemPo> extractOrderItemList(MemberInfo memberInfo, CounterInformation counter, PosSaleOrderRequest request, String newOrderNo) {
        //如果是退货则查询db
        if (OrderTransTypeEnum.GOODS_RETURN.getCode().equals(request.getTransType()) && StringUtils.isNotBlank(request.getOriginalOrderNo())) {
            LambdaQueryWrapper<PosOrderItemPo> queryWrapper =
                    Wrappers.<PosOrderItemPo>lambdaQuery().eq(PosOrderItemPo::getOrderNo, request.getOriginalOrderNo());
            List<PosOrderItemPo> posOrderItemList = posOrderItemMapper.selectList(queryWrapper);
            if (posOrderItemList.isEmpty()) {
                //解决数据迁移原销售订单还未同步过来的问题
                log.error("该销售订单暂未同步至新系统，10分钟后再试！memberInfo={},counter={},request={},newOrderNo={}", memberInfo, counter, request, newOrderNo);
                throw new BizException("该销售订单暂未同步至新系统，10分钟后再试！");
            }
            posOrderItemList.parallelStream().forEach(e -> {
                e.setOrderNo(newOrderNo);
                e.setPurQty(e.getPurQty());
                e.setAmount(e.getAmount());
                e.setShareAmt(e.getShareAmt());
                e.setSurplusQty(BigInteger.ZERO.intValue());
                e.setCreateTime(LocalDateTime.now());
                e.setUpdateTime(LocalDateTime.now());
            });
            //更新原始订单的剩余提货数量
            PosOrderItemPo updateOrderItem = PosOrderItemPo.builder()
                    .surplusQty(BigInteger.ZERO.intValue())
                    .updateTime(LocalDateTime.now())
                    .build();
            posOrderItemMapper.update(updateOrderItem, queryWrapper);
            return posOrderItemList;
        }

        List<PosOrderItemPo> orderItemList =
                request.getOrderItemList().stream()
                        .filter(activityOrderService::isNotFictitious)
                        .map(e -> {//排除虚拟商品
                            Product product = customService.select(Product.builder().prdBarCode(e.getPrdBarCode()).build());
                            ProductUtil prd = ProductUtil.builder().build();
                            BeanUtils.copyProperties(product, prd);
                            prd.setResultPrice(e.getResultPrice());
                            //非活动商品价格为0说明商品价格维护错误
                            if (OrderItemProductTypeEnum.NORMAL.getCode().equals(e.getProType())) {
                                //如果是非会员销售，则零售价不为0
                                if (memberInfo == null && prd.getSalePrice().compareTo(BigDecimal.ZERO) == BigInteger.ZERO.intValue()) {
                                    log.warn("商品零售价为0，请检查产品表价格维护,商品:{}", ToStringBuilder.reflectionToString(prd));
                                }
                                //如果是会员购买，则判断会员价是否为0
                                if (memberInfo != null && prd.getMemberPrice().compareTo(BigDecimal.ZERO) == BigInteger.ZERO.intValue()) {
                                    log.warn("商品会员价为0，请检查产品表价格维护,商品:{}", ToStringBuilder.reflectionToString(prd));
                                }
                            }
                            BigDecimal itemAmount = BigDecimal.valueOf(e.getPurQty()).multiply(e.getResultPrice()).setScale(2, RoundingMode.HALF_UP);
                            return PosOrderItemPo.builder()
                                    .activityDesc(StringUtils.isBlank(e.getActivityName()) ? "0" : e.getActivityName())
                                    .activityId(StringUtils.isBlank(e.getActivityId()) ? "0" : e.getActivityId())
                                    .orderNo(newOrderNo)
                                    .counterId(counter.getCounterId())
                                    .counterName(counter.getCounterName())
                                    .memberId(memberInfo == null ? null : memberInfo.getMemberId())
                                    .memberName(memberInfo == null ? null : memberInfo.getMemberName())
                                    //预订单必须留手机号
                                    .memberPhone(memberInfo == null ? StringUtils.trim(request.getMemberPhone()) : memberInfo.getMobilePhone())
                                    .goodsBarCode(prd.getGoodsBarCode())
                                    .prdBarCode(prd.getPrdBarCode())
                                    .prdName(prd.getPrdName())
                                    .unitName(prd.getUnitName())
                                    .prdPrice(prd.getSalePrice())
                                    .memberPrice(prd.getMemberPrice())
                                    .bigCatCode(prd.getBigCatCode())
                                    .bigCatName(prd.getBigCatName())
                                    .mediumCatCode(prd.getMediumCatCode())
                                    .mediumCatName(prd.getMediumCatName())
                                    .smallCatCode(prd.getSmallCatCode())
                                    .smallCatName(prd.getSmallCatName())
                                    .discernType(e.getDiscernType())//商品类型
                                    //实际销售价格
                                    .salePrice(prd.getResultPrice())
                                    .purQty(e.getPurQty())
                                    .amount(itemAmount)
                                    .shareAmt(itemAmount)
                                    //预订单才展示剩余提取数量
                                    .surplusQty(OrderTypeEnum.BOOK.getCode().equals(request.getOrderType()) ?
                                            e.getPurQty() :
                                            BigInteger.ZERO.intValue())
                                    //填充商品类型,方便数据查询
                                    .proType(e.getProType())
                                    //非虚拟商品
                                    .isVirtual(BigInteger.ZERO.intValue())
                                    .createTime(LocalDateTime.now())
                                    .updateTime(LocalDateTime.now())
                                    .build();
                        }).collect(Collectors.toList());
        //空退业务
        Boolean isKt = request.isKt();
        if (isKt) {
            //空退商品总额
            BigDecimal totalAmt =
                    orderItemList.parallelStream().map(e -> e.getAmount().abs()).reduce(BigDecimal::add).get();
            //退款金额
            BigDecimal totalKtAmt =
                    request.getPaymentOrderList().parallelStream().map(e -> e.getPayAmt().abs()).reduce(BigDecimal::add).get();
            if (totalKtAmt.compareTo(totalAmt) > BigInteger.ZERO.intValue()) {
                log.error("空退退款金额大于商品总额，请检查！totalKtAmt={},totalAmt={}", totalKtAmt, totalAmt);
                throw new BizException("空退退款金额大于商品总额，请检查！");
            }
            //价格调整处理
            if (totalKtAmt.compareTo(totalAmt) != BigInteger.ZERO.intValue()) {
                //价格调整
                String prdName = String.format(BizConst.KT_GOODS_NAME, counter.getCounterName());
                //如果退款金额<商品总额则说明存在价格调整
                BigDecimal discountAmt = totalKtAmt.abs().subtract(totalAmt.abs());
                PosOrderItemPo ktItem = PosOrderItemPo
                        .builder()
                        .activityDesc(prdName)
                        .orderNo(newOrderNo)
                        .counterId(counter.getCounterId())
                        .counterName(counter.getCounterName())
                        .memberId(memberInfo == null ? null : memberInfo.getMemberId())
                        .memberName(memberInfo == null ? null : memberInfo.getMemberName())
                        //预订单必须留手机号
                        .memberPhone(memberInfo == null ? StringUtils.trim(request.getMemberPhone()) :
                                memberInfo.getMobilePhone())
                        .goodsBarCode(BizConst.KT_GOODS_BAR_CODE)
                        .prdName(prdName)
                        .prdBarCode(BizConst.KT_GOODS_BAR_CODE)
                        .surplusQty(BigInteger.ZERO.intValue())
                        //默认为1
                        .purQty(BigInteger.ONE.intValue())
                        //空退促销
                        .proType(OrderItemProductTypeEnum.KT_PROMOTION.getCode())
                        .prdPrice(BigDecimal.ZERO)
                        .salePrice(discountAmt)
                        .amount(discountAmt)
                        .shareAmt(BigDecimal.ZERO)
                        .bigCatName("套装折扣")
                        .bigCatCode(-1)
                        .mediumCatName("套装折扣")
                        .mediumCatCode(-1)
                        .smallCatName("套装折扣")
                        .smallCatCode(-1)
                        .activityId("0")//?空退的报错;是因为修改了测试数据的数据结构;如果不给activityId填充默认值就会报错?空退是谁的为什么没处理?
                        //虚拟商品
                        .isVirtual(BigInteger.ONE.intValue())
                        .discernType(0)
                        .build();
                orderItemList.add(ktItem);
            }
        }
        //重复商品校验,存在相同的商品和类型，但价格不一样
        Set<String> repeatParCodeSet = orderItemList.stream().map(e -> String.join("-", e.getOrderNo(),
                e.getPrdBarCode(), StringUtils.defaultIfBlank(e.getActivityId(), "0"),
                StringUtils.defaultIfBlank(e.getDiscernType().toString(), "2"))).collect(Collectors.toSet());
        if (repeatParCodeSet.size() != orderItemList.size()) {
            log.error("销售录入失败，有重复商品！repeatParCodeSet={},OrderItemList={}", repeatParCodeSet, orderItemList);
            throw new BizException("销售录入失败，有重复商品！");
        }
        return orderItemList;
    }

    /**
     * orderItemList传入此方法前shareAmt默认是amount
     * 计算分摊后金额
     * 积分兑换-》所有商品参与分摊
     * 金额抵用券-》所有商品参与分摊
     * 整单优惠-》所有商品参与分摊
     * -------
     * 其他活动-》商品类型是1、2、4且是非虚拟商品才进行分摊金额
     *
     * @param activityCtx   activityCtx
     * @param orderItemList orderItemList
     */
    private void calcOrderItemShareAmt(PosSaleOrderRequest request, AcitivityMatchContext activityCtx,
                                       List<PosOrderActivity> posOrderActivities, List<PosOrderItemPo> orderItemList) {
        //退货或者无活动销售则不需要计算分摊金额
        boolean isGoodsOut = OrderTransTypeEnum.GOODS_OUT.getCode().equals(request.getTransType());
        if (isGoodsOut && ObjectUtils.isEmpty(posOrderActivities)) {
            //无活动销售订单,设置分摊后金额为商品金额
            return;
        }
        //是否是空退业务
        Boolean isKt = request.isKt();
        //空退业务需要计算分摊后金额
        boolean beValid = isGoodsOut || isKt;
        if (!beValid) {
            return;
        }
        //单品不允许参与多个活动
        //按虚拟商品id分组要计算分摊金额的实物商品<活动id,<优惠金额,是否全部商品,实物item列表>>
        Map<String, MutableTriple<BigDecimal, Boolean, List<PosOrderItemPo>>> group = Maps.newHashMap();
        orderItemList.stream()
                .filter(e -> e.getIsVirtual() == BigInteger.ONE.intValue())
                .forEach(e -> {
                    if (!group.containsKey(e.getPrdBarCode())) {
                        //初始化,"是否全部商品"默认必须为null
                        group.put(e.getPrdBarCode(), MutableTriple.of(e.getAmount(), Boolean.FALSE,
                                Lists.newArrayList()));
                    } else {
                        //虚拟商品把优惠金额相加
                        BigDecimal add = group.get(e.getPrdBarCode()).getLeft().add(e.getAmount());
                        group.get(e.getPrdBarCode()).setLeft(add);
                    }
                    //积分兑换、金额优惠券、整单改价、空退等活动是所有商品分摊优惠金额
                    final String activityId = e.getPrdBarCode();
                    Integer proType = e.getProType();
                    if (proType.equals(OrderItemProductTypeEnum.PROMOTION.getCode())) {
                        //促销活动
                        PromotionActivity promotionActivity =
                                OrderItemProductTypeEnum.PROMOTION.getCode().equals(e.getProType()) && StringUtils.isNotBlank(activityId) ?
                                        customService.select(PromotionActivity.builder().uid(activityId).build()) :
                                        null;
                        //如果是整单改价则优惠金额分摊至所有实物商品
                        if (promotionActivity != null) {
                            //整单改价
                            if (PromotionalEnum.JIANGLI8.getKey().equals(promotionActivity.getRewardType())) {
                                group.get(activityId).setMiddle(Boolean.TRUE);
                            }
                        }
                    } else if (proType.equals(OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode())) {
                        //会员活动-积分兑换,所有商品分摊
                        group.get(activityId).setMiddle(Boolean.TRUE);
                    } else if (proType.equals(OrderItemProductTypeEnum.COUPON.getCode())) {
                        //会员活动-优惠券
                        MemberActivitySon memberActivitySon =
                                OrderItemProductTypeEnum.COUPON.getCode().equals(e.getProType()) && StringUtils.isNotBlank(e.getActivityId()) ?
                                        memberActivityService.selectMemberActivitySon(MemberActivitySon.builder().activityId(e.getActivityId()).build()) : null;
                        if (memberActivitySon != null) {
                            if (BigInteger.ONE.intValue() == memberActivitySon.getRewardType()) {
                                //1金额抵用券-所有商品分摊金额
                                group.get(activityId).setMiddle(Boolean.TRUE);
                            }
                        }
                    } else if (proType.equals(OrderItemProductTypeEnum.PROMOTION_COUPON.getCode())) {
                        PromotionCoupon promotionCoupon =
                                OrderItemProductTypeEnum.PROMOTION_COUPON.getCode().equals(e.getProType()) && StringUtils.isNotBlank(e.getActivityId()) ?
                                        customService.select(PromotionCoupon.builder().proCouponId(e.getActivityId()).build()) : null;
                        if (promotionCoupon != null) {
                            if (BigInteger.ONE.intValue() == promotionCoupon.getRewardType()) {
                                //1金额抵用券-所有商品分摊金额
                                group.get(activityId).setMiddle(Boolean.TRUE);
                            }
                        }
                    } else if (proType.equals(OrderItemProductTypeEnum.KT_PROMOTION.getCode())) {
                        //所有商品分摊
                        group.get(activityId).setMiddle(Boolean.TRUE);
                    }
                });
        /*订单金额小于优惠金额的处理[积分兑换、金额优惠券]---begin*/
        BigDecimal orderAmt =
                orderItemList.parallelStream().filter(e -> e.getIsVirtual() == BigInteger.ZERO.intValue()).map(PosOrderItemPo::getAmount).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        //非整单部分商品优惠金额
        BigDecimal nonHolisticAmt =
                group.values().stream().filter(bigDecimalBooleanListMutableTriple -> !bigDecimalBooleanListMutableTriple.getMiddle()).map(MutableTriple::getLeft).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        BigDecimal originalDiscountAmt =
                orderItemList.parallelStream().filter(e -> e.getIsVirtual() == BigInteger.ONE.intValue()).map(PosOrderItemPo::getAmount).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        if (orderAmt.add(originalDiscountAmt).compareTo(BigDecimal.ZERO) < BigInteger.ONE.intValue()) {
            Map<String, BigDecimal> virtualItemAmt = group.entrySet()
                    .parallelStream()
                    .filter(e -> e.getValue().getMiddle())
                    .collect(Collectors.toMap(Map.Entry::getKey, v -> v.getValue().getLeft()));
            List<PosOrderItemPo> newItemList = orderItemList.stream()
                    .filter(e -> virtualItemAmt.containsKey(e.getPrdBarCode()))
                    .sorted(Comparator.comparing(PosOrderItemPo::getAmount)).collect(Collectors.toList());
            //整单优惠item累计差额
            BigDecimal diff = originalDiscountAmt.add(orderAmt.add(nonHolisticAmt));
            int d = diff.multiply(new BigDecimal(100)).intValue();
            for (PosOrderItemPo e : newItemList) {
                if (d == 0) {
                    continue;
                }
                int t = e.getAmount().multiply(new BigDecimal(100)).intValue();
                if (t > d) {
                    e.setAmount(BigDecimal.ZERO);
                    e.setSalePrice(BigDecimal.ZERO);
                    d = d - t;
                } else {
                    BigDecimal left = new BigDecimal(t - d).divide(new BigDecimal(100));
                    e.setAmount(left);
                    e.setSalePrice(left);
                    d = 0;
                }
            }
            //重新计算该订单优惠金额
            BigDecimal newDiscountAmt =
                    orderItemList.parallelStream().filter(e -> e.getIsVirtual() == BigInteger.ONE.intValue()).map(PosOrderItemPo::getAmount).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
            activityCtx.setDiscountAmt(newDiscountAmt.setScale(2, RoundingMode.HALF_UP));
            group.entrySet()
                    .stream()
                    .filter(e -> virtualItemAmt.containsKey(e.getKey()))
                    .forEach(e -> {
                        BigDecimal realDiscountAmt =
                                orderItemList.stream().filter(i -> i.getPrdBarCode().equals(e.getKey())).map(PosOrderItemPo::getAmount).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
                        e.getValue().setLeft(realDiscountAmt.setScale(2, RoundingMode.HALF_UP));
                    });
        }
        /*订单金额小于优惠金额的处理---end*/
        //礼品赠送or加价购产品代码集合
        //填充group里的非整单折扣的Item
        group.forEach((key, value) -> orderItemList.stream()
                .filter(e -> e.getIsVirtual() == 0)//过滤掉虚拟商品
                .peek(this::setRewardType)//为每个实物商品赋活动奖励值
                .forEach(e -> {

                    final String activityId = e.getActivityId();
                    if (!key.equals(activityId)) {
                        return;
                    }

                    //排除掉积分兑换、金额优惠券、空退等活动，因为它们是所有商品分摊优惠金额
                    Integer proType = e.getProType();
                    Integer discernType = e.getDiscernType();

                    if (discernType == 0
                            && proType.equals(OrderItemProductTypeEnum.NORMAL.getCode())
                            && PromotionalEnum.JIANGLI7.getKey().equals(e.getRewardType())) {
                        //整单优惠 分摊的商品在条件里
                        value.getRight().add(e);
                        value.setMiddle(value.getMiddle() != null ? value.getMiddle() : Boolean.FALSE);

                    } else if (discernType == 0
                            && proType.equals(OrderItemProductTypeEnum.NORMAL.getCode())
                            && PromotionalEnum.JIANGLI5.getKey().equals(e.getRewardType())) {
                        //套装特价(促销非整单) 分摊的商品在条件里
                        value.getRight().add(e);
                        value.setMiddle(value.getMiddle() != null ? value.getMiddle() : Boolean.FALSE);

                    } else if ((discernType == 0 || discernType == 1)
                            && (proType.equals(OrderItemProductTypeEnum.NORMAL.getCode()) || proType.equals(OrderItemProductTypeEnum.PROMOTION.getCode()))
                            && PromotionalEnum.JIANGLI6.getKey().equals(e.getRewardType())) {
                        //第N件折扣 分摊的商品条件和奖励里都有
                        value.getRight().add(e);
                        value.setMiddle(value.getMiddle() != null ? value.getMiddle() : Boolean.FALSE);

                    } else if (proType.equals(OrderItemProductTypeEnum.PROMOTION.getCode())) {

                        //赠送礼品、加价购、整单买送 分摊的商品在奖励里
                        if (discernType == 1
                                && (PromotionalEnum.JIANGLI2.getKey().equals(e.getRewardType()) ||
                                PromotionalEnum.JIANGLI4.getKey().equals(e.getRewardType()) ||
                                PromotionalEnum.JIANGLI9.getKey().equals(e.getRewardType()))) {

                            value.getRight().add(e);
                            value.setMiddle(value.getMiddle() != null ? value.getMiddle() : Boolean.FALSE);

                        } else if (PromotionalEnum.JIANGLI8.getKey().equals(e.getRewardType())) {
                            //整单优惠 整单改价不会走此流程
                            log.error("{}不会走此流程", PromotionalEnum.instance(e.getRewardType()).getValue());
                            throw new BizException(PromotionalEnum.instance(e.getRewardType()).getValue() + "不会走此流程");
                        }

                    } else if (proType.equals(OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode())) {
                        //会员活动-积分兑换,所有商品分摊
                        log.error("{}会员活动-积分兑换不会走此流程", PromotionalEnum.instance(e.getRewardType()).getValue());
                        throw new BizException("会员活动-积分兑换不会走此流程");

                    } else if (proType.equals(OrderItemProductTypeEnum.COUPON.getCode())) {

                        //会员活动-优惠券
                        if (BigInteger.ZERO.intValue() == e.getRewardType()) {
                            //0礼品抵用券--奖励商品分摊金额
                            value.getRight().add(e);
                            value.setMiddle(Boolean.FALSE);
                        } else if (value.getMiddle() == null && BigInteger.ONE.intValue() == e.getRewardType()) {
                            //1金额抵用券-所有商品分摊金额
                            log.error("{}会员活动-金额抵用券不会走此流程", PromotionalEnum.instance(e.getRewardType()).getValue());
                            throw new BizException("会员活动-金额抵用券不会走此流程");
                        }

                    } else if (proType.equals(OrderItemProductTypeEnum.PROMOTION_COUPON.getCode())) {

                        if (BigInteger.ZERO.intValue() == e.getRewardType()) {
                            //0礼品抵用券--奖励商品分摊金额
                            value.getRight().add(e);
                            value.setMiddle(Boolean.FALSE);

                        } else if (value.getMiddle() == null && BigInteger.ONE.intValue() == e.getRewardType()) {
                            //1金额抵用券-所有商品分摊金额
                            throw new BizException("促销活动-金额抵用券不会走此流程");
                        }

                    } else if (proType.equals(OrderItemProductTypeEnum.KT_PROMOTION.getCode())) {
                        //所有商品分摊
                        throw new BizException("空退优惠不会走此流程");
                    }
                }));
        //虚拟商品累加的优惠金额
        BigDecimal _discountAmt =
                group.values().stream().map(MutableTriple::getLeft).reduce(BigDecimal::add).orElse(BigDecimal.ZERO).setScale(2, RoundingMode.FLOOR);
        if (!activityCtx.getDiscountAmt().setScale(2, RoundingMode.FLOOR).equals(_discountAmt)) {
            throw new BizException("匹配活动优惠金额与虚拟商品累加优惠金额不一致");
        }
        //分组处理多活动分摊金额
        group.entrySet().
                stream()
                //部分优惠在前处理,整单折扣后处理
                .sorted((a, b) -> {
                    if (a.getValue().getMiddle().equals(b.getValue().getMiddle())) {
                        return BigInteger.ZERO.intValue();
                    } else if (a.getValue().getMiddle() && !b.getValue().getMiddle()) {
                        return 1;
                    } else {
                        return -1;
                    }
                }).forEach(e -> {
            //如果是整单商品都分摊，则添加所有实物商品,复制一个list副本出来Pair<主本，副本>
            List<Pair<PosOrderItemPo, PosOrderItemPo>> pairList = Lists.newArrayList();
            if (e.getValue().getMiddle()) {
                e.getValue().getRight().clear();
                //过滤掉虚拟商品
                List<Pair<PosOrderItemPo, PosOrderItemPo>> list = orderItemList.stream()
                        .filter(oi -> oi.getIsVirtual() == BigInteger.ZERO.intValue())
                        .map(oi -> {
                            PosOrderItemPo item = PosOrderItemPo.builder().build();
                            BeanUtils.copyProperties(oi, item);
                            //item.setShareAmt(BigDecimal.ZERO);
                            return Pair.of(oi, item);
                        }).collect(Collectors.toList());
                pairList.addAll(list);
            } else {
                //过滤掉虚拟商品
                List<Pair<PosOrderItemPo, PosOrderItemPo>> list = e.getValue().getRight().stream()
                        .filter(oi -> oi.getIsVirtual() == BigInteger.ZERO.intValue())
                        .map(oi -> {
                            PosOrderItemPo item = PosOrderItemPo.builder().build();
                            BeanUtils.copyProperties(oi, item);
                            //item.setShareAmt(BigDecimal.ZERO);
                            return Pair.of(oi, item);
                        })
                        .collect(Collectors.toList());
                pairList.addAll(list);
            }
            List<PosOrderItemPo> newOrderItemList =
                    pairList.parallelStream().map(Pair::getRight).collect(Collectors.toList());
            //分摊商品应付总金额
            BigDecimal totalAmount = pairList.parallelStream()
                    //.filter(i -> i.getLeft().getShareAmt().compareTo(BigDecimal.ZERO) != BigInteger.ZERO.intValue())
                    .map(i -> i.getRight().getAmount())
                    .reduce(BigDecimal::add)
                    .orElse(BigDecimal.ZERO);
            BigDecimal leftTotalShareAmt =
                    pairList.parallelStream().map(i -> i.getLeft().getShareAmt()).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
            //解决倒找客户钱的问题,比如积分兑换100块钱,但是客户买了88的商品,实际优惠金额就是88
            final BigDecimal discountAmt =
                    e.getValue().getLeft().compareTo(BigDecimal.ZERO) == BigInteger.ONE.intValue() ?
                            e.getValue().getLeft() :
                            e.getValue().getLeft().abs().compareTo(leftTotalShareAmt.abs()) == BigInteger.ONE.intValue() ?
                                    leftTotalShareAmt.abs().negate() : e.getValue().getLeft();
            //如果订单总金额是0，则兼容处理，实际上绝不可能，除非产品表商品价格维护错误
            if (totalAmount.compareTo(BigDecimal.ZERO) == BigInteger.ZERO.intValue()) {
                log.warn("订单金额为0，请检查产品表价格维护,商品列表:{}", ToStringBuilder.reflectionToString(newOrderItemList));
                //throw new BizException("订单总金额为0，请检查商品价格维护是否正确");
                //订单金额为0（包括proType=3的正常商品）设置分摊后金额为0，正常商品价格为0无法理解，实在无法理解？？？？？？？？？？？？？？？？？？？？？？？？？？？
                //第一条商品金额为0的明细分摊金额
                BigDecimal _leftTotalShareAmt = discountAmt.compareTo(BigDecimal.ZERO) == BigInteger.ZERO.intValue()
                        ? e.getValue().getLeft() : discountAmt;
                //totalAmount = leftTotalShareAmt;
                newOrderItemList.get(0).setShareAmt(_leftTotalShareAmt);
            } else {
                //裁剪掉一个分摊后金额不为0的元素
                PosOrderItemPo lastItem = null;
                Optional<PosOrderItemPo> orderItemPo = newOrderItemList.stream().filter(i -> i.getShareAmt().compareTo(BigDecimal.ZERO) != BigInteger.ZERO.intValue()).sorted(Comparator.comparing(PosOrderItemPo::getShareAmt)).findFirst();
                if (orderItemPo.isPresent()) {
                    lastItem = orderItemPo.get();
                }
                //.get();
                newOrderItemList.remove(lastItem);
                //PosOrderItemPo lastItem = newOrderItemList.remove(0);
                newOrderItemList.parallelStream().forEach(i -> {
                    BigDecimal itemDiscountAmt =
                            i.getShareAmt().divide(leftTotalShareAmt, 8, RoundingMode.FLOOR).multiply(discountAmt).setScale(2, RoundingMode.HALF_UP);
                    //BigDecimal itemDiscountAmt = i.getAmount().divide(totalAmount, 8, RoundingMode.FLOOR).multiply
                    // (discountAmt).setScale(2, RoundingMode.HALF_UP);
                    BigDecimal shareAmt = i.getAmount().add(itemDiscountAmt);
                    if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(request.getTransType())) {
                        //优惠金额可能比商品金额大，比如积分兑换、优惠券优惠金额大于订单金额,此时计算的分摊后金额是负数
                        i.setShareAmt(shareAmt.compareTo(BigDecimal.ZERO) >= BigInteger.ZERO.intValue() ? shareAmt :
                                BigDecimal.ZERO);
                    } else {
                        i.setShareAmt(shareAmt);
                    }
                });
                //计算最后一笔分摊后金额，解决除不尽的情况
                BigDecimal totalShareAmtExceptLast =
                        newOrderItemList.parallelStream().map(PosOrderItemPo::getShareAmt).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
                //BigDecimal lastShareAmt = totalAmount.compareTo(discountAmt.abs()) >= BigInteger.ZERO.intValue() ?
                // totalAmount.add(discountAmt).subtract(totalShareAmtExceptLast) : BigDecimal.ZERO.subtract
                // (totalShareAmtExceptLast);
                BigDecimal lastShareAmt = totalAmount.add(discountAmt).subtract(totalShareAmtExceptLast);
                if (lastItem != null) {
                    lastItem.setShareAmt(lastShareAmt);
                    newOrderItemList.add(lastItem);
                }
            }
            ///处理主本分摊金额，累加过程
            pairList.parallelStream().forEach(oi -> {
                //算出副本的优惠金额
                BigDecimal itemDiscountAmt = oi.getRight().getAmount().subtract(oi.getRight().getShareAmt());
                //主本当前分摊后金额减去本次活动本商品优惠金额
                BigDecimal shareAmt = oi.getLeft().getShareAmt().subtract(itemDiscountAmt);
                if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(request.getTransType())) {
                    //优惠金额可能比商品金额大，比如积分兑换、优惠券优惠金额大于订单金额,此时计算的分摊后金额是负数
                    oi.getLeft().setShareAmt(shareAmt.compareTo(BigDecimal.ZERO) >= BigInteger.ZERO.intValue() ?
                            shareAmt : BigDecimal.ZERO);
                } else {
                    //空退处理
                    oi.getLeft().setShareAmt(shareAmt);
                }
            });
        });
    }


    private void setRewardType(PosOrderItemPo e) {
        //整单优惠
        boolean isPromotionWholeDiscount = OrderItemProductTypeEnum.NORMAL.getCode().equals(e.getProType())
                && e.getDiscernType() == 0 && (e.getActivityId().contains(CUXIAO) || e.getActivityId().contains(BK_CUXIAO));

        //奖励商品是促销活动的 则给rewordType设值
        boolean isPromotion = OrderItemProductTypeEnum.PROMOTION.getCode().equals(e.getProType())
                && StringUtils.isNotBlank(e.getActivityId());
        if (isPromotion || isPromotionWholeDiscount) {
            PromotionActivity promotionActivity =
                    customService.select(PromotionActivity.builder().uid(e.getActivityId()).build());
            e.setRewardType(promotionActivity.rewardType);
        }
        //奖励商品是会员活动的 则给rewordType设值
        boolean isMemberCoupon = OrderItemProductTypeEnum.COUPON.getCode().equals(e.getProType())
                && StringUtils.isNotBlank(e.getActivityId());
        if (isMemberCoupon) {
            MemberActivitySon memberActivitySon =
                    memberActivityService.selectMemberActivitySon(MemberActivitySon.builder().activityId(e.getActivityId()).build());
            e.setRewardType(memberActivitySon.rewardType);
        }
        //奖励商品是发券活动的 则给rewordType设值
        boolean isCoupon = OrderItemProductTypeEnum.PROMOTION_COUPON.getCode().equals(e.getProType())
                && StringUtils.isNotBlank(e.getActivityId());
        if (isCoupon) {
            PromotionCoupon promotionCoupon =
                    customService.select(PromotionCoupon.builder().proCouponId(e.getActivityId()).build());
            //如果查不到 那可能是口碑礼的 口碑礼就沿用了4状态
            if (promotionCoupon == null) {
                KbActivity kbActivity = memberKbActivityMapper.selectById(e.getActivityId());
                e.setRewardType(kbActivity.getAwardConf().getAwardType());
            } else {
                e.setRewardType(promotionCoupon.getRewardType());
            }
        }
    }

    /**
     * 构造订单信息
     *
     * @param counter
     * @param memberInfo
     * @param request
     * @param orderNo
     * @param orderItemList
     * @return
     */
    private PosOrderPo extractOrder(AcitivityMatchContext acitivityCtx,
                                    CounterInformation counter,
                                    MemberInfo memberInfo,
                                    PosSaleOrderRequest request,
                                    String orderNo,
                                    List<PosOrderItemPo> orderItemList, Integer activityType) {
        //解决及时业务bizTime跟createTime不一致的情况
        LocalDateTime now = LocalDateTime.now();
        //如果是退货则查询db
        if (OrderTransTypeEnum.GOODS_RETURN.getCode().equals(request.getTransType())
                && StringUtils.isNotBlank(request.getOriginalOrderNo())) {
            PosOrderPo orderPo = posOrderMapper.selectById(request.getOriginalOrderNo());
            if (orderPo == null) {
                log.error("原始订单不存在,originalOrderNo={}", request.getOriginalOrderNo());
                throw new BizException("原始订单不存在!");
            }
            //会员销售才能判断积分是否充足
            if (memberInfo != null) {
                //非空退判断积分是否充足
                IntegralAccountPo integralAccountPo = integralAccountMapper.selectById(memberInfo.getMemberId());
                //退货的时候需要扣的积分  正数
                Integer integerQty = orderPo.getInteQty();
                //空退的时候是没有积分填充的  但是扣的积分是按价格1比1来的
                //2020年7月22日10:25:13 确认空退的时候不校验了
                //2021年2月22日15:35:08 新老积分区分后 看业务时间 老订单就看老积分  新订单就看新积分
                IntegralOrderPo integralOrderPo = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery()
                        .eq(IntegralOrderPo::getBizNo, request.getOriginalOrderNo()));
                if (integralOrderPo == null) {
                    log.error("原始订单不存在,originalOrderNo={}", request.getOriginalOrderNo());
                    throw new BizException("原始订单不存在!");
                }
                if (integralOrderPo.getInteType() == 0) {
                    if (integerQty != null && integerQty > 0 && integerQty > integralAccountPo.getOldQty()) {
                        throw new BizException(HttpStatus.GONE.value(), "可用积分不足,无法退货！");
                    }
                } else {
                    if (integerQty != null && integerQty > 0 && integerQty > integralAccountPo.getNewQty()) {
                        throw new BizException(HttpStatus.GONE.value(), "可用积分不足,无法退货！");
                    }
                }
            }
            //更新原订单信息
            PosOrderPo originalOrder = PosOrderPo.builder()
                    .orderNo(request.getOriginalOrderNo())
                    .surplusQty(BigInteger.ZERO.intValue())
                    .updateTime(LocalDateTime.now())
                    .build();
            posOrderMapper.updateById(originalOrder);
            orderPo.setOrderNo(orderNo);
            orderPo.setPreOrderNo(request.getOriginalOrderNo());
            //退货后小票号重新生成
            //2020年4月16日15:59:53 小票号格式优化
            orderPo.setReceiptNo(IdGenerator.genReceiptNo(OrderNoPrefixEnum.LS.getCode()));
            //积分
            orderPo.setIntePayable(orderPo.getIntePayable());
            orderPo.setInteGained(orderPo.getInteGained());
            orderPo.setInteQty(orderPo.getInteQty());
            orderPo.setBaCode(request.getBaCode());
            orderPo.setBaName(request.getBaName());
            //2020年4月9日10:00:10添加字段 添加各种类型
            orderPo.setCounterType(orderPo.getCounterType());
            orderPo.setCounterOptMode(orderPo.getCounterOptMode());
            orderPo.setCounterName(counter.getCounterName());
            orderPo.setTransType(request.getTransType());
            orderPo.setOrderType(request.getOrderType());
            //金额、数量取反
            orderPo.setOrderAmt(orderPo.getOrderAmt());
            orderPo.setDiscountAmt(orderPo.getDiscountAmt());
            orderPo.setRealAmt(orderPo.getRealAmt());
            orderPo.setGoodsQty(orderPo.getGoodsQty());
            orderPo.setSkQty(orderPo.getSkQty());
            orderPo.setSurplusQty(BigInteger.ZERO.intValue());
            //补录业务取参数时间否则取当前时间
            orderPo.setBizTime(request.getBizTime() != null ? request.getBizTime() : now);
            orderPo.setCreateTime(now);
            orderPo.setUpdateTime(now);
            return orderPo;
        }
        //map-reduce求和,实付
        //商品总件数(实物商品)：包含正常购买商品+赠送商品
        PosOrderItemAssit accRealAmt = orderItemList.stream()
                .map(e ->
                        PosOrderItemAssit.builder()
                                .purQty(e.getPurQty())
                                .skQty(CommonConstant.SKIN_CARE_LIST.contains(e.getBigCatName()) ? e.getPurQty() : 0)
                                .payableAmt(e.getAmount())
                                .build()
                ).reduce((acc, item) -> {
                    acc.setPurQty(acc.getPurQty() + item.getPurQty());
                    acc.setSkQty(acc.getSkQty() + item.getSkQty());
                    acc.setPayableAmt(acc.getPayableAmt().add(item.getPayableAmt()));
                    return acc;
                }).get();
        //应付金额(订单金额)
        PosOrderItemAssit accOrderAmt = orderItemList.stream()
                .filter(e -> e.getIsVirtual().intValue() == BigInteger.ZERO.intValue())
                .map(e ->
                        PosOrderItemAssit.builder()
                                .purQty(e.getPurQty())
                                .skQty(CommonConstant.SKIN_CARE_LIST.contains(e.getBigCatName()) ? e.getPurQty() : 0)
                                .payableAmt(e.getAmount())
                                .build()
                ).reduce((acc, item) -> {
                    acc.setPurQty(acc.getPurQty() + item.getPurQty());
                    acc.setSkQty(acc.getSkQty() + item.getSkQty());
                    acc.setPayableAmt(acc.getPayableAmt().add(item.getPayableAmt()));
                    return acc;
                }).get();

        //订单金额，订单金额是优惠前金额
//        BigDecimal orderAmt =
//                orderItemList.parallelStream().map(PosOrderItemPo::getAmount).reduce(BigDecimal::add).get();
        //实付金额
        BigDecimal realAmt = accRealAmt.getPayableAmt().compareTo(BigDecimal.ZERO) < 1 ? BigDecimal.ZERO : accRealAmt.getPayableAmt();
        BigDecimal discountAmt = acitivityCtx.getDiscountAmt() == null ? BigDecimal.ZERO :
                acitivityCtx.getDiscountAmt();
        if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(request.getTransType()) && discountAmt.compareTo(BigDecimal.ZERO) > BigInteger.ZERO.intValue()) {
            log.warn("【活动】订单优惠计算要让客户多掏钱，商品价格为零就会出现，请检查活动配置或者修改产品价格，参与活动后实付金额大于原订单总额！");
        }
        //计算总折扣率
        BigDecimal discountRate = accOrderAmt.getPayableAmt().compareTo(BigDecimal.ZERO) == 0 ? BigDecimal.ONE : realAmt.divide(accOrderAmt.getPayableAmt(), 2, RoundingMode.HALF_UP);
        return PosOrderPo.builder()
                .orderNo(orderNo)
                //2020年4月9日10:00:10添加字段 添加各种类型
                //2020年4月21日14:15:21 改回来成对应counter的字段
                .counterType(counter.getCounterType())
                .counterOptMode(counter.getOperationalModel())
                .memberId(memberInfo == null ? null : memberInfo.getMemberId())
                .memberName(memberInfo == null ? null : memberInfo.getMemberName())
                .memberPhone(memberInfo == null ? StringUtils.trim(request.getMemberPhone()) :
                        memberInfo.getMobilePhone())
                //填充活动
                .activityType(activityType)
                //填充结束
                .baCode(request.getBaCode())
                .baName(request.getBaName())
                .counterId(counter.getCounterId())
                .counterName(counter.getCounterName())
                .counterAddr(counter.getCounterAddress())
                .counterChanCode(counter.getChannelCode())
                .counterChanName(counter.getChannelName())
                .areaCode(counter.getLargeAreaCode())
                .areaName(counter.getLargeAreaName())
                .provinceCode(counter.getProvinceCode())
                .provinceName(counter.getProvinceName())
                .cityCode(counter.getCityCode())
                .cityName(counter.getCityName())
                .countyCode(counter.getCountyCode())
                .countyName(counter.getCountyName())
                .orgAreaCode(counter.getOrgAreaId())
                .orgAreaName(counter.getOrgAreaName())
                .orgOfficeCode(counter.getOrgOfficeId())
                .orgOfficeName(counter.getOrgOfficeName())
                .orgPrincipalCode(counter.getOrgMasterId())
                .orgPrincipalName(counter.getOrgMasterName())
                .orderChanCode(OrderChannelEnum.SHOP.getCode())
                .orderChanName(OrderChannelEnum.SHOP.getMsg())
                .orderType(request.getOrderType())
                .transType(request.getTransType())
                .orderAmt(accOrderAmt.getPayableAmt())
                //.orderAmt(orderAmt)
                //优惠金额
                .discountAmt(discountAmt)
                //实付金额=订单金额-优惠金额
                .realAmt(realAmt)
                //总折扣率
                .discountRate(discountRate)
                //花费的积分
                .intePayable(Math.abs(acitivityCtx.getIntePayable()))
                .receiptNo(IdGenerator.genReceiptNo(OrderNoPrefixEnum.LS.getCode()))
                .goodsQty(accOrderAmt.getPurQty())
                .skQty(accOrderAmt.getSkQty())
                //预定单-剩余未提数量
                .surplusQty(OrderTypeEnum.BOOK.getCode().equals(request.getOrderType()) ? accOrderAmt.getPurQty() :
                        BigInteger.ZERO.intValue())
                //预定单-预约提货时间
                .rsvPickUpTime(OrderTypeEnum.BOOK.getCode().equals(request.getOrderType()) ?
                        request.getRsvPickUpTime().atStartOfDay() : null)
                .memberType(memberInfo == null ? null : memberInfo.getMemberType())
                //补录业务取参数时间否则取当前时间
                .bizTime(request.getBizTime() != null ? request.getBizTime() : now)
                .createTime(now)
                .updateTime(now)
                .build();
    }

    /**
     * 构造组合支付信息【销售、空退】
     *
     * @return
     */
    private List<PosPaymentOrderPo> extractPaymentOrder(PosOrderPo posOrderPo, PosSaleOrderRequest request,
                                                        String orderNo) {
        //批量生成订单号
        List<String> paymentOrderNoList = IdGenerator.batchGenIdWithPrefix(OrderNoPrefixEnum.PMT.getCode(),
                request.getPaymentOrderList().size());
        //校验实付金额是否与系统运算应付金额一致
        if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(request.getTransType())) {
            BigDecimal realAmt =
                    request.getPaymentOrderList().parallelStream().map(PosSaleOrderRequest.PaymentOrderRequest::getPayAmt).reduce(BigDecimal::add).get();
            BigDecimal appRealAmt = posOrderPo.getRealAmt();
            if (appRealAmt.compareTo(realAmt) != 0) {
                log.error(String.format("POS端计算¬实付金额（%s与后端计算实付金额(%s)不一致，请检查", realAmt.toString(),
                        posOrderPo.getRealAmt().toString()));
                throw new BizException("金额计算错误！");
            }
        }
        return IntStream.range(0, request.getPaymentOrderList().size())
                .boxed()
                .map(index -> {
                    PosSaleOrderRequest.PaymentOrderRequest e = request.getPaymentOrderList().get(index);
                    return PosPaymentOrderPo.builder()
                            .paymentOrderNo(paymentOrderNoList.get(index.intValue()))
                            .orderNo(orderNo)
                            .counterId(posOrderPo.getCounterId())
                            .counterName(posOrderPo.getCounterName())
                            .memberId(posOrderPo.getMemberId())
                            .memberName(posOrderPo.getMemberName())
                            .memberPhone(posOrderPo.getMemberPhone())
                            .payChannel(e.getPayChannel())
                            .payAmt(e.getPayAmt())
                            .createTime(LocalDateTime.now())
                            .bizTime(posOrderPo.getBizTime())
                            .build();
                }).collect(Collectors.toList());
    }
}
