package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.event.Order4WxUnActiveSaleEvent;
import com.ruihe.app.mapper.basic.CounterInfoMapper;
import com.ruihe.app.mapper.order.PosAuthorityMapper;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.constant.RedisPrefixKeyConst;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.system.SystemConfigPo;
import com.ruihe.common.dao.bean.wx.WxCardInfoPo;
import com.ruihe.common.dao.mapper.SystemConfigMapper;
import com.ruihe.common.dao.mapper.WxCardInfoPoMapper;
import com.ruihe.common.enums.order.ProgramTypeEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.enums.system.SystemConfigEnum;
import com.ruihe.common.service.RedisCacheService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

/**
 * @author LiangYuan
 * @description 每月微信未激活可销售人数
 * @date 2021-01-12 9:19
 */
@Slf4j
@Component
public class Order4WxUnActiveSaleListener {

    @Autowired
    private WxCardInfoPoMapper wxCardInfoPoMapper;

    @Autowired
    private PosAuthorityMapper posAuthorityMapper;

    @Autowired
    private SystemConfigMapper systemConfigMapper;

    @Autowired
    private CounterInfoMapper counterInfoMapper;

    @Autowired
    private RedisCacheService redisService;


    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(Order4WxUnActiveSaleEvent event) {
        try {
            CounterInformation counterInformation = counterInfoMapper.selectById(event.getCounterId());
            //查询会员卡信息
            WxCardInfoPo wxCardInfoPo = wxCardInfoPoMapper.selectOne(Wrappers.<WxCardInfoPo>lambdaQuery()
                    .eq(WxCardInfoPo::getMemberId, event.getMemberId()));
            if (wxCardInfoPo != null) {
                return;
            }
            //查询是否开启了限制
            Integer count = posAuthorityMapper.countSpecifiedAuthority(counterInformation, ProgramTypeEnum.WX_BIND.getCode());
            if (count == 0) {
                return;
            }
            //系统配置里面是否有限制次数
            SystemConfigPo systemConfigPo = systemConfigMapper.selectOne(Wrappers.<SystemConfigPo>lambdaQuery()
                    .eq(SystemConfigPo::getParamKey, SystemConfigEnum.MONTH_WX_UNACTIVE_SALE.getCode())
                    .eq(SystemConfigPo::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
            if (systemConfigPo == null) {
                return;
            }
            //查询数据
            String key = String.format(RedisPrefixKeyConst.WX_MONTH_UNACTIVE_MEMBER_ID, event.getCounterId());
            Set<String> memberList = redisService.getObject(key);
            //是否已有数据
            if (!ObjectUtils.isEmpty(memberList)) {
                //是否包含
                if (memberList.contains(event.getMemberId())) {
                    return;
                }
                //redisService.delete(key);
                memberList.add(event.getMemberId());
                //缓存新的key-value值
                this.setRedis(memberList, key);
            } else {
                Set<String> list = new HashSet<>();
                list.add(event.getMemberId());
                //缓存新的key-value值
                this.setRedis(list, key);
            }
        } catch (Exception e) {
            log.error("门店微信未激活会员销售数量处理异常，event{}", JSON.toJSONString(event), e);
        }
    }

    /**
     * 设置redis缓存与失效时间
     *
     * @param memberList
     * @param key
     */
    private void setRedis(Set<String> memberList, String key) {
        //失效时间
        LocalDate now = LocalDate.now();
        LocalDate endTime = LocalDate.of(now.getYear(), now.getMonthValue(), 25);
        if (now.getDayOfMonth() > 25) {
            endTime = endTime.plusMonths(1);
        }
        long timeout = Duration.between(LocalDateTime.now(), LocalDateTime.of(endTime, LocalTime.of(23, 59, 59))).toSeconds();
        //缓存新的key-value值
        redisService.setex(key, memberList, timeout);
    }
}
