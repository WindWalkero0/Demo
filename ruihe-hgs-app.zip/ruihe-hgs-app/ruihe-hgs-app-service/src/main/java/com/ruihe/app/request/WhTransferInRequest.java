package com.ruihe.app.request;


import com.ruihe.app.vo.WhTransferItemVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

@ApiModel(value = "WhTransferInRequest", description = "新建调拨单实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhTransferInRequest implements Serializable {

    @ApiModelProperty(value = "调拨单号")
    private String transferOrderNo;

    @NotBlank(message = "申请调入柜台号不能为空")
    @ApiModelProperty(value = "申请调入柜台号")
    private String inCounterId;

    @NotBlank(message = "申请调入柜台名称不能为空")
    @ApiModelProperty(value = "申请调入柜台名称")
    private String inCounterName;

    @NotBlank(message = "调出柜台id不能为空")
    @ApiModelProperty(value = "调出柜台id")
    private String outCounterId;

    @NotBlank(message = "调出柜台名称不能为空")
    @ApiModelProperty(value = "调出柜台名称")
    private String outCounterName;

    @NotNull(message = "申请调入商品总数量不能为空")
    @ApiModelProperty(value = "申请调入商品总数量")
    private Integer inGoodsQty;

    @NotNull(message = "调入确认数不能为空")
    @ApiModelProperty(value = "调入确认数")
    private Integer ackInQty;

/*    @ApiModelProperty(value = "确认调入商品总数量")
    private Integer inQty;*/

    @NotBlank(message = "调入申请ba代码不能为空")
    @ApiModelProperty(value = "调入申请ba代码")
    private String inBaCode;

    @NotBlank(message = "调入申请ba姓名不能为空")
    @ApiModelProperty(value = "调入申请ba姓名")
    private String inBaName;

    @NotNull(message = "申请金额不能为空")
    @ApiModelProperty(value = "申请金额")
    private BigDecimal inAmt;

    @NotNull(message = "调拨单状态不能为空")
    @ApiModelProperty(value = "调拨单状态")
    private Integer status;

    @NotEmpty(message = "入库明细不能为空")
    @ApiModelProperty(value = "入库明细")
    @Valid
    List<WhTransferItemVo> transferItemList;
}
