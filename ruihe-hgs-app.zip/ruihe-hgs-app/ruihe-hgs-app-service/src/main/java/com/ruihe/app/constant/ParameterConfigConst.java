package com.ruihe.app.constant;

/**
 * fa配置参数表key的常量
 *
 * @author William
 */
public class ParameterConfigConst {
    /**
     * app版本升级配置
     **/
    public static final String APP_UPGRADE_CONF = "APP_UPGRADE_CONF";

    /**
     * 这次上线的12家柜台
     **/
    public static final String ONLINE_COUNTER_LIST = "ONLINE_COUNTER_LIST";

    /**
     * ba回访的类型
     **/
    public static final String BA_VISIT_TYPE = "BA_VISIT_TYPE";
}
