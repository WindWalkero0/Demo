package com.ruihe.app.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@ApiModel(value = "EditMemberRequest", description = "会员修改实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EditMemberRequest implements Serializable {
    @ApiModelProperty(value = "会员主键id")
    private String memberId;
    @ApiModelProperty(value = "会员姓名")
    private String memberName;
    @ApiModelProperty(value = "手机号")
    private String mobilePhone;
    @ApiModelProperty(value = "性别")
    private String gender;
    @ApiModelProperty(value = "生日")
    private String birthday;
    @ApiModelProperty(value = "省份")
    private String province;
    @ApiModelProperty(value = "省份id")
    private String provinceId;
    @ApiModelProperty(value = "城市")
    private String city;
    @ApiModelProperty(value = "城市id")
    private String cityId;
    @ApiModelProperty(value = "详细地址")
    private String address;
    @ApiModelProperty(value = "推荐会员")
    private String recommendMemberId;
    @ApiModelProperty(value = "肤质")
    private String skinType;
    @ApiModelProperty(value = "职业")
    private String career;
    @ApiModelProperty(value = "收入")
    private String income;
    @ApiModelProperty(value = "联系电话")
    private String telephone;
    @ApiModelProperty(value = "备注")
    private String remarkOne;
}
