package com.ruihe.app.service.basic;

import com.ruihe.common.response.Response;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-24 10:35
 */
public interface QueryRegionalService {
    /**
     * 查询省份
     *
     * @return
     */
    Response queryProvince();

    /**
     * 查询某一省份下所有的城市
     *
     * @return
     */
    Response queryCity(String regionalCode);

}
