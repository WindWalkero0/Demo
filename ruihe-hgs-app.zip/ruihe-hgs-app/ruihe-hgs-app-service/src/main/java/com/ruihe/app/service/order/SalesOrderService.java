package com.ruihe.app.service.order;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Maps;
import com.ruihe.app.mapper.basic.CounterInfoMapper;
import com.ruihe.app.request.SalesRequest;
import com.ruihe.app.service.activity.AbstractActivityService;
import com.ruihe.common.dao.bean.activity.ActivityPlace;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.member.MemberSelect;
import com.ruihe.common.dao.bean.promotion.ProductScope;
import com.ruihe.common.dao.bean.promotion.PromotionActivity;
import com.ruihe.common.dao.bean.promotion.PromotionProduct;
import com.ruihe.common.dao.bean.promotion.RewardCloud;
import com.ruihe.common.constant.AppointType;
import com.ruihe.common.util.LambdaUtil;
import com.ruihe.common.dao.bean.warehouse.WhStockPo;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.pojo.dto.PromotionActivityDTO;
import com.ruihe.common.enums.activity.ActivityEnum;
import com.ruihe.common.enums.promotion.PromotionalEnum;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.pojo.request.member.MemberInfoRequest;
import com.ruihe.common.pojo.request.promotion.SalesProductRequest;
import com.ruihe.common.service.ActivityService;
import com.ruihe.common.service.CommonService;
import com.ruihe.common.service.CustomService;
import com.ruihe.app.mapper.order.SalesOrderMapper;
import com.ruihe.app.mapper.promotion.ActivityPlaceMapper;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.StringUti;
import com.ruihe.common.utils.TimeUtils;
import com.ruihe.app.service.activity.ActivityMatchLogic;
import com.ruihe.app.service.activity.PromotionActivityService;
import com.ruihe.app.service.basic.AboutProductService;
import com.ruihe.app.service.warehouse.WhStockService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

/**
 * 销售录入之前的操作
 *
 * @Author 胡坤
 * @Date 2019年10月24日18:21:38
 */
@Slf4j
@DS(DBConst.SLAVE)
@Service
public class SalesOrderService {

    @Autowired
    private CustomService customService;

    @Autowired
    private CommonService commonService;

    @Autowired
    private ScatteredService scatteredService;

    @Autowired
    private UnifiedService unifiedService;

    @Autowired
    private ActivityService activityService;

    @Autowired
    private AboutProductService productService;

    @Autowired
    private WhStockService whStockService;

    @Autowired
    private SalesOrderMapper salesOrderMapper;


    @Autowired
    private ActivityPlaceMapper activityPlaceMapper;

    @Autowired
    private CounterInfoMapper counterInfoMapper;

    @Autowired
    private AbstractActivityService abstractActivityService;

    @Autowired
    private PromotionActivityService promotionActivityService;

    @Autowired
    private ActivityMatchLogic activityMatchLogic;


    @Ella(Describe = "销售录入-匹配促销活动")
    public Response matchActivity(SalesRequest salesRequest) throws Exception {
        commonService.judgeField(salesRequest);//字段检测
        judgeMember(salesRequest);//会员判断
        HashMap<String, PromotionActivity> promotionActivityMap = fillMap(salesRequest.getIds());
        fillPrice(salesRequest);//重新填充商品价格
        List<PromotionActivity> promotionActivityList = new ArrayList<>();
        List<PromotionActivity> promotionalActivities;
        if (StringUtils.isEmpty(salesRequest.getBizTime())) {//正常销售
            promotionalActivities = selectPromotional();//查询所有有效并且正在进行中的促销活动
        } else {//补录订单
            promotionalActivities = salesOrderMapper.selectPromotions(salesRequest.getBizTime());
        }
        List<PromotionActivity> collect = promotionalActivities.stream()
                .filter(promotionActivity -> !promotionActivity.getRewardType().equals(PromotionalEnum.JIANGLI8.getKey()) && operation(promotionActivity, promotionActivityMap))
                .peek(promotionActivity -> {
                    checkJudge(promotionActivity, promotionActivityMap);
                }).collect(Collectors.toList());
        if (collect.isEmpty()) {
            return Response.success(collect);
        }
        for (PromotionActivity promotionActivity : collect) {
            matchRule(salesRequest, promotionActivity, promotionActivityList); //获取到进行中的活动,进行匹配
        }
        operationData(promotionActivityList, salesRequest);//匹配完的活动进行数据重新装载
        return Response.success(promotionActivityList);
    }

    @Ella(Describe = "互斥说明")
    private void checkJudge(PromotionActivity promotionActivity, Map<String, PromotionActivity> promotionActivityMap) {
        promotionActivity.setCheckJudge(1);
//        List<PromotionProduct> promotionProducts = customService.selectList(PromotionProduct.builder()
//        .promotionalUid(promotionActivity.getUid()).methodType(0).promotionType(0).build());
//        promotionActivity.setPromotionProducts(promotionProducts);
//        promotionActivityMap.forEach((k, activity) -> {
//            if (activity.getBuyConditionType().equals(PromotionalEnum.TIAOJIAN2.getKey()) && (activity
//            .getPromotionProducts() == null || activity.getPromotionProducts().isEmpty())) {//已选的是整单无限定的
//                if (!promotionActivity.getBuyConditionType().equals(PromotionalEnum.TIAOJIAN1.getKey())) {//排除无条件
//                    promotionActivity.setCheckJudge(0);
//                }
//            } else if ((activity.getBuyConditionType().equals(PromotionalEnum.TIAOJIAN2.getKey()) && (activity
//            .getPromotionProducts() != null && !activity.getPromotionProducts().isEmpty()))//整单有限定
//                    || (activity.getBuyConditionType().equals(PromotionalEnum.TIAOJIAN3.getKey()))) {//非整单
//                if (promotionActivity.getBuyConditionType().equals(PromotionalEnum.TIAOJIAN2.getKey()) &&
//                (promotionActivity.getPromotionProducts() == null || promotionActivity.getPromotionProducts()
//                .isEmpty())) {//整单无限定
//                    promotionActivity.setCheckJudge(0);
//                }
//            }
//        });
    }

    @Ella(Describe = "已选活动互斥判断")
    public HashMap<String, PromotionActivity> fillMap(List<String> ids) {
        HashMap<String, PromotionActivity> promotionActivityMap = Maps.newHashMap();
        if (ids != null && !ids.isEmpty()) {
            ids.forEach(id -> {
                PromotionActivity activity = customService.select(PromotionActivity.builder().uid(id).build());
                List<PromotionProduct> list =
                        customService.selectList(PromotionProduct.builder().promotionalUid(activity.getUid()).methodType(0).promotionType(0).build());
                if (list != null && !list.isEmpty()) {
                    activity.setPromotionProducts(list);
                }
                promotionActivityMap.put(id, activity);
            });
        }
        return promotionActivityMap;
    }

    @Ella(Describe = "晒选已选的活动")
    public Boolean operation(PromotionActivity promotionActivity, Map<String, PromotionActivity> promotionActivityMap) {
        LambdaUtil build = LambdaUtil.builder().flag(true).build();
        //消除重复的活动
        promotionActivityMap.forEach((id, activity) -> {
            if (id.equals(promotionActivity.getUid())) {//已选择的活动进行排除
                build.setFlag(false);
            }
        });
        return build.getFlag();
    }

    private Response matchActivity2(SalesRequest salesRequest) throws Exception {

        commonService.judgeField(salesRequest);//字段检测
        judgeMember(salesRequest);//会员判断
        fillPrice(salesRequest);//重新填充商品价格
        List<PromotionActivity> promotionActivityList = new ArrayList<>();
        List<PromotionActivity> promotionalActivities;
        if (StringUtils.isEmpty(salesRequest.getBizTime())) {//正常销售
            promotionalActivities = selectPromotional();//查询所有有效并且正在进行中的促销活动
        } else {//补录订单
            promotionalActivities = salesOrderMapper.selectPromotions(salesRequest.getBizTime());
        }
        List<PromotionActivityDTO> promotionActivities = promotionalActivities.stream()
                .filter(promotionActivity -> !promotionActivity.getRewardType().equals(PromotionalEnum.JIANGLI8.getKey()))
                .map(PromotionActivity::convert2DTO)
                .collect(Collectors.toList());
        if (ObjectUtils.isEmpty(promotionActivities)) {
            return Response.success(promotionActivities);
        }

        var promotionIds = promotionActivities.stream().map(PromotionActivityDTO::getUid).collect(toList());

        var placeWhereCondition = Wrappers.<ActivityPlace>lambdaQuery()
                .in(ActivityPlace::getActivityUid, promotionIds);
        var activityPlaces = activityPlaceMapper.selectList(placeWhereCondition);
        if (ObjectUtils.isEmpty(activityPlaces)) {
            log.error("促销活动匹配失败，活动地点不存在！promotionIds={},", promotionIds);
            throw new BizException("促销活动匹配失败，柜台信息不存在！");
        }

        String counterId = salesRequest.counterId;
        var countWhere = Wrappers.<CounterInformation>lambdaQuery()
                .eq(CounterInformation::getCounterId, counterId);
        var counterInformation = Optional.of(counterInfoMapper.selectOne(countWhere)).orElseThrow(() -> {
            log.error("促销活动匹配失败，柜台信息不存在！counterId={},", counterId);
            throw new BizException("促销活动匹配失败，柜台信息不存在！");
        });


        //查询会员搜索条件
        var searchTypeActivityIds = promotionActivities
                .stream()
                .filter(e -> e.activityObjectType.equals(ActivityEnum.ACTITY_OBJECT2.getKey()))
                .map(PromotionActivityDTO::getUid).collect(toList());

        var searchMemberRes =
                CompletableFuture.supplyAsync(() -> abstractActivityService.getSearchMemberRes(searchTypeActivityIds));

        //查询Excel导入
        var excelTypeActivityIds = promotionActivities.stream()
                .filter(e -> e.activityObjectType.equals(ActivityEnum.ACTITY_OBJECT3.getKey()))
                .map(PromotionActivityDTO::getUid).collect(toList());

        var excelImportMemberRes =
                CompletableFuture.supplyAsync(() -> abstractActivityService.getExcelImportMemberRes(excelTypeActivityIds));

        var searchMember = searchMemberRes.get();
        var excelImport = excelImportMemberRes.get();

        //整单条件的限定产品
        var wholeActivityProductMap = promotionActivityService.queryWholeBuyConditionProduct(promotionActivities);

        //非整单购买条件分组后的产品
        var noneWholeActivityProductMap = promotionActivityService.queryNoneWholeBuyConditionProduct(promotionIds);


        var existMember = salesRequest.getFlag();
        String memberId = existMember ? salesRequest.getMemberRequest().getMemberId() : null;

        //购物车产品
        var shoppingCarProducts = salesRequest.getProducts();
        //购物车产品详情信息
        List<String> productCodes = shoppingCarProducts.stream().map(SalesProductRequest::getProId).collect(toList());


        //List<Product> allProducts = simpleProductService.findAllProducts(productCodes);

        var matchedProduct = promotionActivities.stream()
                .filter(e -> ActivityMatchLogic.checkActivityPlace(e.activityPlaceType, activityPlaces, counterInformation))
                .filter(e -> ActivityMatchLogic.checkActivityObject(e.uid, e.activityObjectType, memberId, searchMember, excelImport))
                .filter(e -> activityMatchLogic.checkActivityBuyCondition(e, shoppingCarProducts, existMember, wholeActivityProductMap, noneWholeActivityProductMap))
                .peek(e -> {
                    var matchMax = activityMatchLogic.maxMatchCount(e, shoppingCarProducts, existMember, wholeActivityProductMap, noneWholeActivityProductMap);
                    e.matchingCount = matchMax > e.matchingCount ? e.matchingCount : matchMax;
                })
                .collect(Collectors.toList());

        System.out.println(matchedProduct);
        /*for (PromotionActivity promotionActivity : promotionActivityDTOS) {
            matchRule(salesRequest, promotionActivity, promotionActivityList); //获取到进行中的活动,进行匹配
        }
        operationData(promotionActivityList, salesRequest);//匹配完的活动进行数据重新装载
        return Response.success(promotionActivityList);*/

        return null;
    }


    @Ella(Describe = "匹配完的活动进行数据重新装载")
    public void operationData(List<PromotionActivity> promotionActivityList, SalesRequest salesRequest) {
        Integer zero = BigInteger.ZERO.intValue();
        //填充信息
        if (!promotionActivityList.isEmpty()) {
            promotionActivityList.stream().forEach(promotionActivity -> {
                promotionActivity.setIsMember(salesRequest.getFlag());//如果是会员就为true
                operationReward(salesRequest, promotionActivity, zero);//奖励信息处理
                selectPlace(promotionActivity); //活动地点查询
                selectMember(promotionActivity);//会员查询
                selectLimitPro(promotionActivity); //查询产品
                selectCloud(promotionActivity, salesRequest.getCounterId());//查询组合并填充
                if (promotionActivity.getBuyConditionType().equals(PromotionalEnum.TIAOJIAN1.getKey())) {//如果是无条件
                    promotionActivity.setCount(promotionActivity.getMatchingCount());
                }
            });
            sortActivity(promotionActivityList);//活动排序
        }
    }

    @Ella(Describe = "奖励信息处理")
    public void operationReward(SalesRequest salesRequest, PromotionActivity promotionActivity, Integer zero) {
        List<SalesProductRequest> salesProductRequests = new ArrayList<>();
        //参加活动商品处理
        Map<String, SalesProductRequest> activitiesMap = promotionActivity.getActivitiesMap();
        if (activitiesMap != null && !activitiesMap.isEmpty()) {
            List<SalesProductRequest> abatementList = new ArrayList<>();
            activitiesMap.forEach((k, v) -> {
                WhStockPo whStockPo =
                        customService.select(WhStockPo.builder().counterId(salesRequest.getCounterId()).prdBarCode(k).build());
                Product product = customService.select(Product.builder().prdBarCode(k).build());
                v.setProPrice(product.getSalePrice().toString());
                v.setMemberPrice(product.getMemberPrice());
                v.setProCode(product.getGoodsBarCode());
                v.setName(product.getPrdName());
                v.setStock(whStockPo == null ? zero : whStockPo.getStock());
                salesProductRequests.add(v);
            });
            //价格从高到低排序
            scatteredService.sortDesc(salesProductRequests, salesRequest.getFlag());
            promotionActivity.setDiscountActivities(salesProductRequests);
            promotionActivity.setActivitiesMap(null);//暂存商品置空
            //查询购买条件数量
            List<RewardCloud> rewardClouds = customService.selectList(RewardCloud.builder()
                    .promotionalUid(promotionActivity.getUid())
                    .cloudMethod(0)
                    .isDel(CommonStatusEnum.EFFECTIVE.getCode())
                    .build()
            );
            if (rewardClouds.size() > 1) {
                log.error("第N件折扣只能选择一种奖励{}", rewardClouds.size());
                log.error("第N件折扣只能选择一种奖励{}", rewardClouds.size());
                log.error("第N件折扣只能选择一种奖励{}", rewardClouds.size());
                throw new BizException("第N件折扣只能选择一种奖励");
            }
            RewardCloud rewardCloud = rewardClouds.get(0);
            int count = Integer.parseInt(rewardCloud.getInputValues());
            /**
             * 设置优惠商品
             */
            List<SalesProductRequest> salesProductRequests1 = new ArrayList<>();
            salesProductRequests.stream().forEach(salesProductRequest -> {
                int i = Integer.parseInt(salesProductRequest.getProCount());
                for (int j = 0; j < i; j++) {
                    SalesProductRequest build = SalesProductRequest
                            .builder()
                            .proId(salesProductRequest.getProId())
                            .proCode(salesProductRequest.getProCode())
                            .memberPrice(salesProductRequest.getMemberPrice())
                            .name(salesProductRequest.getName())
                            .proPrice(salesProductRequest.getProPrice())
                            .proCount("1")
                            .build();
                    salesProductRequests1.add(build);
                }
            });
            int a = salesProductRequests1.size() / count;
            LambdaUtil build = LambdaUtil.builder().count(0).build();
            for (int i = 0; i < a; i++) {
                List<SalesProductRequest> salesProductRequests2 = salesProductRequests1.subList(build.getCount(),
                        build.getCount() + count);
                //价格由低到高
                scatteredService.sortAsc(salesProductRequests2, salesRequest.getFlag());
                SalesProductRequest salesProductRequest = salesProductRequests2.get(0);
                abatementList.add(salesProductRequest);
                build.setCount(build.getCount() + count);
            }
            promotionActivity.setAbatementList(abatementList);
        }
    }

    @Ella(Describe = "活动排序")
    public void sortActivity(List<PromotionActivity> promotionActivityList) {
        if (promotionActivityList.size() > 1) {
            //进行柜台和购买条件
            sortByCounter(promotionActivityList);
            List<PromotionActivity> promotionActivityCounters = new ArrayList<>();//指定柜台
            List<PromotionActivity> promotionActivityOtherCounters = new ArrayList<>();//全部柜台
            promotionActivityList.stream().forEach(promotionActivity -> {
                if (promotionActivity.getSortCounter() == 1) {
                    promotionActivityCounters.add(promotionActivity);
                } else {
                    promotionActivityOtherCounters.add(promotionActivity);
                }
            });
            //购买条件进行排序
            sortByCondition(promotionActivityCounters);
            sortByCondition(promotionActivityOtherCounters);
            //进行活动重新排序
            promotionActivityList.clear();
            promotionActivityList.addAll(promotionActivityCounters);
            promotionActivityList.addAll(promotionActivityOtherCounters);
        }
    }

    @Ella(Describe = "会员判断")
    public void judgeMember(SalesRequest salesRequest) {
        if (salesRequest.getMemberRequest() != null && !StringUtils.isEmpty(salesRequest.getMemberRequest().getMemberId())) {
            MemberInfo memberInfo =
                    customService.selectAppoint(MemberInfo.builder().memberId(AppointType.appointString).build(),
                            MemberInfo.builder().memberId(salesRequest.getMemberRequest().getMemberId()).build());
            if (memberInfo != null) {
                salesRequest.setFlag(true);
                var newProducts = salesRequest.getProducts().stream().peek(e -> e.setIsMember(true)).collect(toList());
                salesRequest.setProducts(newProducts);
            } else {
                salesRequest.setFlag(false);
            }
        } else {
            salesRequest.setFlag(false);
        }
    }

    /**
     * 系统内置规则：
     * 1)活动柜台：特定柜台活动优先级高于全部柜台；
     * 2)购买条件：非整单>整单>无条件
     * 3)活动开始时间降序
     *
     * @param
     */
    @Ella(Describe = "活动柜台排序", Author = "K")
    public void sortByCounter(List<PromotionActivity> promotionActivityList) {
        promotionActivityList.stream().forEach(promotionActivity -> {
            if (!promotionActivity.getActivityPlaceType().equals(ActivityEnum.ACTITY_PLACE_TYPE1.getKey())) {//不是全部柜台
                promotionActivity.setSortCounter(1);
            } else {
                promotionActivity.setSortCounter(2);
            }
            if (promotionActivity.getBuyConditionType().equals(PromotionalEnum.TIAOJIAN3.getKey())) {//非整单
                promotionActivity.setSortType(1);
            } else if (promotionActivity.getBuyConditionType().equals(PromotionalEnum.TIAOJIAN2.getKey())) {//整单
                promotionActivity.setSortType(2);
            } else if (promotionActivity.getBuyConditionType().equals(PromotionalEnum.TIAOJIAN1.getKey())) {//无条件
                promotionActivity.setSortType(3);
            } else {
                log.error("未知购买类型type={}", promotionActivity.getActivityPlaceType());
                throw new BizException("未知购买类型");
            }
        });
    }

    @Ella(Describe = "购买条件排序", Author = "K")
    public void sortByCondition(List<PromotionActivity> promotionActivityCounters) {
        List<PromotionActivity> noWholeSheet = new ArrayList<>();//非整单
        List<PromotionActivity> wholeSheet = new ArrayList<>();//整单
        List<PromotionActivity> noCondition = new ArrayList<>();//无条件
        promotionActivityCounters.stream().forEach(promotionActivity -> {
            if (promotionActivity.getSortType() == 1) {
                noWholeSheet.add(promotionActivity);
            } else if (promotionActivity.getSortType() == 2) {
                wholeSheet.add(promotionActivity);
            } else {
                noCondition.add(promotionActivity);
            }
        });
        //进行排序
        sortByTime(noWholeSheet);
        sortByTime(wholeSheet);
        sortByTime(noCondition);
        //进行添加到新的集合
        promotionActivityCounters.clear();
        promotionActivityCounters.addAll(noWholeSheet);
        promotionActivityCounters.addAll(wholeSheet);
        promotionActivityCounters.addAll(noCondition);
    }

    @Ella(Describe = "活动开始时间", Author = "K")
    public void sortByTime(List<PromotionActivity> promotionActivities) {
        if (promotionActivities.size() > 1) {
            Collections.sort(promotionActivities, new Comparator<PromotionActivity>() {
                @Override
                public int compare(PromotionActivity promotionActivity, PromotionActivity promotionActivityOther) {
                    return new BigDecimal(TimeUtils.dateToStamp(promotionActivityOther.getStartTime())).compareTo(new BigDecimal(TimeUtils.dateToStamp(promotionActivity.getStartTime())));
                }
            });
        }
    }

    /**
     * 活动地点查询并填充
     *
     * @param promotionActivity
     * @throws Exception
     */
    private void selectPlace(PromotionActivity promotionActivity) {
        if (!(promotionActivity.getActivityPlaceType().equals(ActivityEnum.ACTITY_PLACE_TYPE1.getKey()))) {
            //不是全部柜台,进行查询
            List<ActivityPlace> activityPlaces = activityService.selectActivityPlaces(ActivityPlace
                    .builder()
                    .activityType(1)
                    .isDel(CommonStatusEnum.EFFECTIVE.getCode())
                    .activityUid(promotionActivity.getUid())
                    .build());
            promotionActivity.setActivityPlaceList(activityPlaces);
        }
    }

    /**
     * 会员查询并填充
     *
     * @param promotionActivity
     * @throws Exception
     */
    private void selectMember(PromotionActivity promotionActivity) {
        if (promotionActivity.getActivityObjectType().equals(PromotionalEnum.ACTITY_OBJECT2.getKey())) {
            MemberSelect memberSelect = activityService.selectMemberSelect(MemberSelect
                    .builder()
                    .activityType(1)
                    .isDel(CommonStatusEnum.EFFECTIVE.getCode())
                    .activityId(promotionActivity.getUid())
                    .build());
            promotionActivity.setMemberSelect(memberSelect);
        }
    }


    /**
     * 查询并填充限定产品
     *
     * @param promotionActivity
     */
    private void selectLimitPro(PromotionActivity promotionActivity) {
        List<PromotionProduct> promotionProducts = selectlimitProByUid(promotionActivity.getUid());
        promotionActivity.setPromotionProducts(promotionProducts);
    }

    /**
     * 根据uid查询限定产品
     */
    public List<PromotionProduct> selectlimitProByUid(String uid) {
        return customService.selectList(PromotionProduct.builder()
                .promotionalUid(uid)
                .isDel(CommonStatusEnum.EFFECTIVE.getCode())
                .build());
    }

    /**
     * 查询组合并填充
     *
     * @param promotionActivity
     */
    private void selectCloud(PromotionActivity promotionActivity, String counterId) {
        promotionActivity.setRewardCloudList(selectCloudProByUid(promotionActivity.getUid(), counterId));
    }

    /**
     * 根据uid查询组合并填充产品范围数据
     */
    public List<RewardCloud> selectCloudProByUid(String uid, String counterId) {
        List<RewardCloud> rewardClouds = customService.selectList(RewardCloud.builder()
                .promotionalUid(uid)
                .cloudMethod(1)
                .isDel(CommonStatusEnum.EFFECTIVE.getCode())
                .build());
        if (!rewardClouds.isEmpty()) {
            rewardClouds.stream().forEach(rewardCloud -> {
                if (rewardCloud.getProRange().equals(PromotionalEnum.PRO2.getKey())) {//只有指定商品能添加库存
                    WhStockPo whStockPo =
                            whStockService.searchStockProduct(WhStockPo.builder().prdBarCode(rewardCloud.getSpecificProductId()).counterId(counterId).build());
                    if (rewardCloud.getProRange().equals(PromotionalEnum.PRO2.getKey())) {
                        if (whStockPo == null) {
                            Product product =
                                    productService.selectProduct(Product.builder().prdBarCode(rewardCloud.getSpecificProductId()).build());
                            rewardCloud.setGoodsBarCode(product.getGoodsBarCode());
                            rewardCloud.setMemberPrice(product.getMemberPrice().toString());
                            rewardCloud.setNormalPrice(product.getSalePrice().toString());
                            rewardCloud.setStock("0");
                        } else {
                            rewardCloud.setGoodsBarCode(whStockPo.getGoodsBarCode());
                            rewardCloud.setMemberPrice(whStockPo.getMemberPrice().toString());
                            rewardCloud.setNormalPrice(whStockPo.getPrdPrice().toString());
                            rewardCloud.setStock(whStockPo.getStock().toString());
                        }
                    }
                } else if (rewardCloud.getProRange().equals(PromotionalEnum.PRO1.getKey())) {
                    List<ProductScope> productScopeList =
                            customService.selectList(ProductScope.builder().cloudMethod(rewardCloud.getCloudMethod()).activityUid(rewardCloud.getPromotionalUid()).isDel(CommonStatusEnum.EFFECTIVE.getCode()).build());//填充产品范围
                    productScopeList.stream().forEach(productScope -> {
                        if (productScope.getProRange().equals(PromotionalEnum.PRO2.getKey())) {//对有特定的商品进行价格填充
                            WhStockPo whStockPo =
                                    whStockService.searchStockProduct(WhStockPo.builder().prdBarCode(productScope.getSpecificProductId()).counterId(counterId).build());
                            if (whStockPo == null) {
                                Product product =
                                        productService.selectProduct(Product.builder().prdBarCode(productScope.getSpecificProductId()).build());
                                productScope.setNormalPrice(product.getSalePrice().toString());
                                productScope.setGoodsBarCode(product.getGoodsBarCode());
                                productScope.setStock("0");
                                productScope.setMemberPrice(product.getMemberPrice().toString());
                            } else {
                                productScope.setNormalPrice(whStockPo.getPrdPrice().toString());
                                productScope.setGoodsBarCode(whStockPo.getGoodsBarCode());
                                productScope.setStock(whStockPo.getStock().toString());
                                productScope.setMemberPrice(whStockPo.getMemberPrice().toString());
                            }
                        }
                    });
                    rewardCloud.setProductScopes(productScopeList);
                }
            });
        }
        return rewardClouds;
    }

    /**
     * 根据商品id查询商品价格
     */
    public void fillPrice(SalesRequest salesRequest) {
        if (!StringUti.isNull(salesRequest, "products") && !salesRequest.getProducts().isEmpty()) {
            //会员存在查询的是会员价格
            List<SalesProductRequest> products = salesRequest.getProducts();
            for (SalesProductRequest request : products) {
                LambdaUtil lambdaUtil = LambdaUtil.builder().flag(false).build();
                WhStockPo stock =
                        customService.select(WhStockPo.builder().counterId(salesRequest.getCounterId()).prdBarCode(request.getProId()).build());
                Product product = customService.select(Product.builder().prdBarCode(request.getProId()).build());
                lambdaUtil.setFlag(!StringUti.isNull(salesRequest, "memberRequest") && !StringUtils.isEmpty(salesRequest.getMemberRequest().getMemberId()));//如果是会员就为true

                if (ObjectUtils.isEmpty(stock)) {
                    request.setProPrice(product.getSalePrice().toString());
                    request.setMemberPrice(product.getMemberPrice());
                    request.setProCode(product.getGoodsBarCode());
                } else {
                    request.setProPrice(stock.getPrdPrice().toString());
                    request.setMemberPrice(stock.getMemberPrice());
                    request.setProCode(stock.getGoodsBarCode());
                }
            }
            salesRequest.setProducts(products);
        }
    }

    /**
     * 根据销售数据,和促销活动进行匹配
     *
     * @param salesRequest
     * @param promotionalActivities
     * @return
     */
    public List<PromotionActivity> matchOperation(SalesRequest salesRequest,
                                                  List<PromotionActivity> promotionalActivities) throws Exception {
        List<PromotionActivity> promotionActivityList = new ArrayList<>();
        //遍历促销活动
        for (PromotionActivity promotionActivity : promotionalActivities) {
            matchRule(salesRequest, promotionActivity, promotionActivityList);
        }
        return promotionActivityList;
    }

    /**
     * 根据规则进行判断是否满足活动需求
     */
    private void matchRule(SalesRequest salesRequest, PromotionActivity promotionActivity,
                           List<PromotionActivity> promotionActivityList) {
        //进行地点,活动对象,购买条件筛选
        if (checkActivityPlace(promotionActivity.getActivityPlaceType(),promotionActivity.getUid(), salesRequest) &&
                checkActivityObject(promotionActivity.getActivityObjectType(), promotionActivity.getUid(), salesRequest.getFlag(), salesRequest.getMemberRequest().getMemberId()) &&
                checkMoneyAndCount(promotionActivity, salesRequest)) {//活动匹配
            promotionActivityList.add(promotionActivity);
        }
    }

    /**
     * 判断是否满足活动地点 (满足  返回true  不满足 返回false)
     */
    public Boolean checkActivityPlace(Integer activityPlaceType, String activityId, SalesRequest salesRequest) {
        if (activityPlaceType.equals(ActivityEnum.ACTITY_PLACE_TYPE1.getKey())) {
            return true;
        }
        //查询柜台
        CounterInformation counterInformation = counterInfoMapper.selectOne(Wrappers.<CounterInformation>lambdaQuery()
                .eq(CounterInformation::getCounterId, salesRequest.getCounterId()));
        List<ActivityPlace> activityPlaces = selectActivityPlace(activityId);
        for (ActivityPlace activityPlace : activityPlaces) {
            //如果是按组织架构的
            if (activityPlaceType.equals(ActivityEnum.ACTITY_PLACE_TYPE3.getKey())) {
                if(counterInformation == null){
                    return false;
                }
                if(activityPlace.getDepartmentId()!=null && activityPlace.getDepartmentId().equals(counterInformation.getOrgMasterId())){
                    return true;
                }
            }
            if (activityPlace.getCounterId() == null) {//如果柜台为空说明是为了回显的数据直接忽略
                continue;
            }
            if (activityPlace.getCounterId().equals(salesRequest.getCounterId())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判断活动对象是否满足
     *
     * @param activityObjectType 活动对象类型
     * @param activityId         活动id
     * @param isMember           是否是会员 true是 false不是
     * @param memberId           会员id
     * @return
     */
    public Boolean checkActivityObject(Integer activityObjectType, String activityId, Boolean isMember, String memberId) {
        if (activityObjectType.equals(PromotionalEnum.ACTITY_OBJECT4.getKey())) { //不限制对象
            return true;
        } else {
            if (activityObjectType.equals(PromotionalEnum.ACTITY_OBJECT1.getKey())) {
                return isMember;
            } else if (activityObjectType.equals(PromotionalEnum.ACTITY_OBJECT2.getKey())) {//搜索条件 查询搜索条件
                if (!isMember) {
                    return false;
                }
                MemberSelect memberSelect = activityService.selectMemberSelect(MemberSelect
                        .builder()
                        .isDel(CommonStatusEnum.EFFECTIVE.getCode())
                        .activityId(activityId)
                        .build());
                //数据库搜索出来的条件填充到搜索信息
                commonService.fillMemberSelect(memberSelect);
                memberSelect.setMemberId(memberId);
                List<MemberInfoRequest> memberInfoRequests = commonService.selectMemberByQuery(memberSelect);
                if (!memberInfoRequests.isEmpty()) {
                    return true;
                }
                return false;
            } else {
                log.error("未知对象类型,type={}", activityObjectType);
                throw new BizException("未知对象类型");
            }
        }
    }

    /**
     * 将排除商品除掉
     */
    private void operationExclude(PromotionActivity promotionActivity, SalesRequest salesRequest) {
        //根据活动查询排除商品
        List<PromotionProduct> promotionProducts = selectProduct(promotionActivity.getUid(),
                PromotionalEnum.PRO2.getKey(), 1, 0);
        if (!promotionProducts.isEmpty()) {
            //开始清除
            if (!StringUti.isNull(salesRequest, "products") && !(salesRequest.getProducts().isEmpty())) {
                List<SalesProductRequest> productList = salesRequest.getProducts();
                for (PromotionProduct promotionProduct : promotionProducts) {
                    //活动特定产品==商品集合的某一个商品 那么将商品集合中的该商品去掉
                    productList.removeIf(productRequest -> promotionProduct.getSpecificProductId().equals(productRequest.getProId()));
                }
            }
        }
    }

    /**
     * 判断购买条件是否满足(满足  返回true  不满足 返回false)
     */
    public Boolean checkMoneyAndCount(PromotionActivity promotionActivity, SalesRequest salesRequest) {
        //购买条件类型
        Integer buyConditionType = promotionActivity.getBuyConditionType();
        if (buyConditionType.equals(PromotionalEnum.TIAOJIAN1.getKey())) { //无条件
            return true;
        } else {
            if ((StringUti.isNull(salesRequest, "products")) || (salesRequest.getProducts().isEmpty())) {
                //如果购买的商品信息为空直接返回false q:为什么商品集合会为空?
                return false;
            }
            //先将排除商品除掉 为什么要排除传参中的特定商品? 现在活动有排除限定商品的需求吗? 看新建活动时没有提供排除限定商品的操作!!!!!
            operationExclude(promotionActivity, salesRequest);
            if (promotionActivity.getBuyConditionType().equals(PromotionalEnum.TIAOJIAN2.getKey())) {
                return unifiedService.checkSheet(promotionActivity, salesRequest);//整单条件
            } else if (promotionActivity.getBuyConditionType().equals(PromotionalEnum.TIAOJIAN3.getKey())) {//非整单条件
                //又重新copy了一次前端请求参数
                SalesRequest salesRequestOther = SalesRequest.builder().build();
                BeanUtils.copyProperties(salesRequest, salesRequestOther);
                List<SalesProductRequest> collect =
                        salesRequestOther.getProducts().stream().map(salesProductRequest -> {
                            SalesProductRequest build = SalesProductRequest.builder().build();
                            BeanUtils.copyProperties(salesProductRequest, build);
                            return build;
                        }).collect(Collectors.toList());
                salesRequestOther.setProducts(collect);
                return scatteredService.checkSheet(promotionActivity, salesRequestOther);
            } else {
                log.error("未知条件类型,type={}", buyConditionType);
                throw new BizException("未知条件类型");
            }
        }
    }

    /**
     * 根据商品信息查询商品分类信息
     */
    private Integer selectProductItem(String id, String counterId) {
        WhStockPo whStockPo = customService.select(WhStockPo.builder()
                .counterId(counterId)
                .prdBarCode(id)
                .build());
        if (!StringUti.isNull(whStockPo, "smallCatCode")) {
            return whStockPo.getSmallCatCode();
        }
        return null;
    }

    /**
     * 根据活动查询商品(购买)
     */
    public List<PromotionProduct> selectProduct(String uid, Integer proRange, Integer promotionType,
                                                Integer methodType) {
        return customService.selectList(PromotionProduct.builder()
                .promotionalUid(uid)
                .isDel(CommonStatusEnum.EFFECTIVE.getCode())
                .methodType(methodType)
                .promotionType(promotionType)
                .proRange(proRange)
                .build());
    }


    /**
     * 根据活动uid 查询活动对象
     */
    private List<ActivityPlace> selectActivityPlace(String uid) {
        return customService.selectList(ActivityPlace
                .builder()
                .isDel(CommonStatusEnum.EFFECTIVE.getCode())
                .activityUid(uid)
                .build());
    }

    /**
     * 查询所有有效并且正在进行中的促销活动
     */
    private List<PromotionActivity> selectPromotional() {
        return customService.selectList(PromotionActivity.builder()
                .templateType(0)
                .isDel(StatusEnum.UN_DELETED.getKey())
                .status(0)
                .activityStatus(0)
                .build());
    }

    /**
     * 填充购买商品
     */
    public Map<Serializable, SalesProductRequest> fillData(SalesRequest salesRequest) {
        Map<Serializable, SalesProductRequest> data = new HashMap<>();
        List<SalesProductRequest> products = salesRequest.getProducts();
        for (SalesProductRequest product : products) {
            data.put(product.getProId(), product);
        }
        return data;
    }

    /**
     * 填充购买商品分类
     */
    public Map<Serializable, SalesProductRequest> fillClassData(SalesRequest salesRequest) {
        Map<Serializable, SalesProductRequest> data = new HashMap<>();
        List<SalesProductRequest> products = salesRequest.getProducts();
        for (SalesProductRequest product : products) {
            Integer proId = selectProductItem(product.getProId(), salesRequest.getCounterId());
            if (proId != null) {
                data.put(proId, product);
            }
        }
        return data;
    }

    @Ella(Describe = "匹配次数", Author = "K")
    public void count(PromotionActivity promotionActivity, SalesRequest salesRequest) {
        Integer matchingCount = promotionActivity.getMatchingCount();//获取到最大匹配次数
        Integer buyConditionType = promotionActivity.getBuyConditionType();//购买条件类型
        if (buyConditionType.equals(PromotionalEnum.TIAOJIAN2.getKey())) {//整单条件
            //获取金额/数量---条件
            String inputValues = promotionActivity.getInputValues();
            List<SalesProductRequest> products = salesRequest.getProducts();
            if (promotionActivity.getTotal().equals(0)) {//总金额
                BigDecimal memberMoney = new BigDecimal("0");
                BigDecimal normalMoney = new BigDecimal("0");
                for (SalesProductRequest product : products) {
                    WhStockPo whStockPo =
                            whStockService.searchStockProduct(WhStockPo.builder().prdBarCode(product.getProId()).build());
                    //会员价格
                    memberMoney =
                            memberMoney.add(whStockPo.getMemberPrice().multiply(new BigDecimal(product.getProCount())));
                    //普通价格
                    normalMoney =
                            normalMoney.add(whStockPo.getPrdPrice().multiply(new BigDecimal(product.getProCount())));
                }
                String memberId = salesRequest.getMemberRequest().getMemberId();
                if (memberId == null) {
                    //如果不是会员
                    BigDecimal divide = normalMoney.divide(new BigDecimal(inputValues), 0, RoundingMode.HALF_UP);
                    Integer count = Integer.parseInt(divide.toString());
                    promotionActivity.setCount(matchingCount >= count ? count : matchingCount);
                } else {
                    BigDecimal divide = memberMoney.divide(new BigDecimal(inputValues), 0, RoundingMode.HALF_UP);
                    Integer count = Integer.parseInt(divide.toString());
                    promotionActivity.setCount(matchingCount >= count ? count : matchingCount);
                }
            } else {//总数量
                Integer buyCount = 0;
                for (SalesProductRequest product : products) {
                    buyCount = buyCount + Integer.parseInt(product.getProCount());
                }
                Integer total = buyCount / Integer.parseInt(inputValues);
                promotionActivity.setCount(total > matchingCount ? matchingCount : total);
            }
        }
    }


}

