package com.ruihe.app.service.order.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.app.request.PosOrderPageQueryRequest;
import com.ruihe.app.vo.PosOrder4ReturnVo;
import com.ruihe.app.vo.PosOrderItemVo;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.dao.bean.order.PosPaymentOrderPo;
import com.ruihe.common.pojo.context.holder.PosUserContextHolder;
import com.ruihe.common.enums.activity.ActivityTypeEnum;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.enums.OrderTypeEnum;
import com.ruihe.app.mapper.order.PosOrderItemMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.mapper.order.PosPaymentOrderMapper;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.app.service.order.PosOrderQueryService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 订单查询服务
 *
 * @author William
 */
@Slf4j
@DS(DBConst.SLAVE)
@Service
public class PosOrderQueryServiceImpl implements PosOrderQueryService {

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private PosOrderItemMapper posOrderItemMapper;

    @Autowired
    private PosPaymentOrderMapper posPaymentOrderMapper;

    /**
     * 查单退货-订单分页查询
     * 只查询订单类型是正常销售、预订，交易类型是卖出去的订单
     *
     * @param request
     * @return
     */
    @Override
    public Response pageOrderList4Return(PosOrderPageQueryRequest request) {
        var userContextVo = PosUserContextHolder.get();
        IPage<PosOrderPo> pageQuery = new Page<>(request.getPageNumber(), request.getPageSize());
        LambdaQueryWrapper<PosOrderPo> queryWrapper = Wrappers.lambdaQuery();
        queryWrapper.eq(PosOrderPo::getCounterId, userContextVo.getCounter().getCounterId());
        if (request.getStartTime() != null) {
            queryWrapper.ge(PosOrderPo::getBizTime, request.getStartTime());
        }
        if (request.getEndTime() != null) {
            queryWrapper.le(PosOrderPo::getBizTime, request.getEndTime().plusDays(1));
        }
        if (StringUtils.isNotBlank(request.getMemberPhone())) {
            queryWrapper.eq(PosOrderPo::getMemberPhone, request.getMemberPhone().trim());
        }
        if (request.getOrderType() != null) {
            queryWrapper.eq(PosOrderPo::getOrderType, request.getOrderType());
        }

        //只查询卖出去的订单
        queryWrapper.eq(PosOrderPo::getTransType, OrderTransTypeEnum.GOODS_OUT.getCode());
        queryWrapper.in(PosOrderPo::getOrderType, OrderTypeEnum.SHOP_SALE.getCode(), OrderTypeEnum.BOOK.getCode());
        //查单退货排除掉积分兑换，公司实际业务不存在积分兑换退货--update by William 2020-02-27
        //两个积分的也属于多活动 这个也要排除2020年7月8日17:17:36
        queryWrapper.ne(PosOrderPo::getActivityType, ActivityTypeEnum.INTEGRAL_EXCH.getCode());
        queryWrapper.notExists("select order_no from t_pos_order_item oi where oi.order_no = t_pos_order.order_no and oi.pro_type = 0 ");
        queryWrapper.orderByDesc(PosOrderPo::getBizTime);
        IPage<PosOrderPo> posOrderPoPage = posOrderMapper.selectPage(pageQuery, queryWrapper);
        List<PosOrder4ReturnVo> list = ObjectUtils.toList(posOrderPoPage.getRecords(), PosOrder4ReturnVo.class);
        //检查订单有无退货
        List<String> orderNoList = list.parallelStream().map(PosOrder4ReturnVo::getOrderNo).collect(Collectors.toList());
        if (!orderNoList.isEmpty()) {
            //查询退货记录
            List<PosOrderPo> returnOrderList = posOrderMapper.selectList(Wrappers.<PosOrderPo>lambdaQuery().in(PosOrderPo::getPreOrderNo, orderNoList));
            Map<String, PosOrderPo> returnOrderMap = returnOrderList.parallelStream().collect(Collectors.toMap(PosOrderPo::getPreOrderNo, Function.identity(), (o, n) -> n));
            list.parallelStream().forEach(e -> {
                //目前有前置订单号的订单说明订单已全退
                if (returnOrderMap.containsKey(e.getOrderNo())) {
                    e.setGoodsQty(BigInteger.ZERO.intValue());
                    e.setRealAmt(BigDecimal.ZERO);
                    e.setCanViewDetail(Boolean.TRUE);
                    e.setCanRefund(Boolean.FALSE);
                    e.setTip("可退数量为0！");
                } else if (OrderTypeEnum.BOOK.getCode().equals(e.getOrderType()) && e.getGoodsQty() > e.getSurplusQty()) {
                    //在查单退货中，如果当前该预订单提货数量大于0，则不可进行退货；否则可以全退，在退货后生成相应的退货订单记录
                    e.setGoodsQty(BigInteger.ZERO.intValue());
                    e.setRealAmt(BigDecimal.ZERO);
                    e.setCanViewDetail(Boolean.FALSE);
                    e.setCanRefund(Boolean.FALSE);
                    e.setTip("该预订单已经部分提货，不可进行退单！");
                }
            });
        }
        //转换page对象
        PageVO pageVO = PageVO.<PosOrder4ReturnVo>builder()
                .list(list)
                .pageNum(posOrderPoPage.getCurrent())
                .pageSize(posOrderPoPage.getSize())
                .pages(posOrderPoPage.getPages())
                .total(posOrderPoPage.getTotal())
                .build();
        return Response.success(pageVO);
    }

    /***
     * 查单退货-订单明细
     * @param orderNo 订单号
     * @return
     */
    @Override
    public Response orderItem4Return(final String orderNo) {
        LambdaQueryWrapper<PosOrderItemPo> queryWrapper = Wrappers.<PosOrderItemPo>lambdaQuery()
                .eq(PosOrderItemPo::getOrderNo, orderNo)
                .orderByDesc(PosOrderItemPo::getProType, PosOrderItemPo::getPrdBarCode);
        List<PosOrderItemPo> orderItemList = posOrderItemMapper.selectList(queryWrapper);
        return Response.success(ObjectUtils.toList(orderItemList, PosOrder4ReturnVo.PosOrder4ReturnItemVo.class));
    }

    /***
     * 查单退货-订单明细-支付详情
     * @param orderNo 订单号
     * @return
     */
    @Override
    public Response paymentList4Return(final String orderNo) {
        LambdaQueryWrapper<PosPaymentOrderPo> queryWrapper = Wrappers.<PosPaymentOrderPo>lambdaQuery()
                .eq(PosPaymentOrderPo::getOrderNo, orderNo);
        List<PosPaymentOrderPo> orderItemList = posPaymentOrderMapper.selectList(queryWrapper);
        return Response.success(ObjectUtils.toList(orderItemList, PosOrder4ReturnVo.PaymentOrderVo.class));
    }

    /**
     * 会话接口-》根据订单号查询订单详情
     *
     * @param orderNo
     * @return
     */
    @Override
    public Response item(String orderNo) {
        List<PosOrderItemPo> posOrderItemPoList = posOrderItemMapper.selectList(Wrappers.<PosOrderItemPo>lambdaQuery()
                .eq(PosOrderItemPo::getOrderNo, orderNo));
        if (posOrderItemPoList.isEmpty()) {
            return Response.errorMsg("查询失败，请刷新重试!");
        }
        return Response.success(ObjectUtils.toList(posOrderItemPoList, PosOrderItemVo.class));
    }

}
