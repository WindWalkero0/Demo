package com.ruihe.app.service.face;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.face.AiFaceDescriptionConfigMapper;
import com.ruihe.app.mapper.face.AiFacePropertyMapper;
import com.ruihe.app.mapper.face.AiFaceScoreConfigMapper;
import com.ruihe.app.po.face.AiFaceDescriptionConfigPO;
import com.ruihe.app.po.face.AiFacePropertyPO;
import com.ruihe.app.po.face.AiFaceScoreConfigPO;
import com.ruihe.common.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.RoundingMode;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import static com.ruihe.common.constant.AiFaceConstant.*;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toMap;

@Slf4j
@Component
public class InitAiFaceProperty implements InitializingBean {

    @Resource
    private AiFaceScoreConfigMapper aiFaceScoreConfigMapper;
    @Resource
    private AiFaceDescriptionConfigMapper aiFaceDescriptionConfigMapper;
    @Resource
    private AiFacePropertyMapper aiFacePropertyMapper;

    private final RedisTemplate<Object, Object> redisTemplate;

    public InitAiFaceProperty(RedisTemplate<Object, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    @Override
    public void afterPropertiesSet() {

        final Map<String, Map<String, Integer>> scoreConfig = this.getScoreConfig();
        final Map<String, Map<String, String>> descriptionConfig = this.getDescriptionConfig();
        final Map<String, Map<String, String>> propertyNameMap = this.getPropertyNameMap();

        redisTemplate.opsForHash().getOperations().delete(scoreConfigRedis);
        redisTemplate.opsForHash().getOperations().delete(descriptionConfigRedis);
        redisTemplate.opsForHash().getOperations().delete(propertyNameConfigRedis);
        redisTemplate.opsForHash().putAll(scoreConfigRedis, scoreConfig);
        redisTemplate.opsForHash().putAll(descriptionConfigRedis, descriptionConfig);
        redisTemplate.opsForHash().putAll(propertyNameConfigRedis, propertyNameMap);
    }

    /**
     * 获取标签的所有分值
     *
     * @return Map<标签, Map < 联合主键值, 联合主键值对应的分值>>
     */
    public Map<String, Map<String, Integer>> getScoreConfig() {

        var wrapper = Wrappers.<AiFaceScoreConfigPO>lambdaQuery();
        var scoreConfigs = aiFaceScoreConfigMapper.selectList(wrapper);
        return scoreConfigs.stream()
                .collect(groupingBy(AiFaceScoreConfigPO::getLabel))
                .entrySet().stream().collect(toMap(Map.Entry::getKey,
                        e -> e.getValue().stream().collect(toMap(AiFaceScoreConfigPO::getPropertyValue, AiFaceScoreConfigPO::getPropertyScore))));
    }

    /**
     * 获取标签的所有的描述
     *
     * @return Map<标签, Map < 联合主键值, 联合主键值对应的描述>>
     */
    public Map<String, Map<String, String>> getDescriptionConfig() {

        var wrapper = Wrappers.<AiFaceDescriptionConfigPO>lambdaQuery();
        var descriptionConfigs = aiFaceDescriptionConfigMapper.selectList(wrapper);

        return descriptionConfigs.stream()
                .collect(groupingBy(AiFaceDescriptionConfigPO::getLabel))
                .entrySet().stream().collect(toMap(Map.Entry::getKey,
                        e -> e.getValue().stream().collect(toMap(AiFaceDescriptionConfigPO::getPropertyValue, AiFaceDescriptionConfigPO::getPropertyDescription))));
    }

    /**
     * 获取AI检测返回每个属性的中文名称
     *
     * @return Map<标签, < 属性名, 属性值>>
     */
    public Map<String, Map<String, String>> getPropertyNameMap() {

        var wrapper = Wrappers.<AiFacePropertyPO>lambdaQuery();
        var aiFaceProperties = aiFacePropertyMapper.selectList(wrapper);

        //每个标签的属性分组
        final Map<Integer, List<AiFacePropertyPO>> labelPropertyGroup =
                aiFaceProperties.stream()
                        .collect(groupingBy(e -> e.getPropertyCode().setScale(0, RoundingMode.DOWN).intValue()));

        return labelPropertyGroup.values().stream()
                .collect(toMap(
                        key -> key.stream().min(Comparator.comparing(AiFacePropertyPO::getPropertyLevel)).map(AiFacePropertyPO::getProperty).orElseThrow(() -> new BizException("配置表里未正确配置标签的层级代码")),
                        value -> {
                            //当前标签的所有属性值对应中文的映射
                            final Map<String, String> propertyNameMap = value.stream().collect(toMap(AiFacePropertyPO::getProperty, AiFacePropertyPO::getPropertyChinese, (e1, e2) -> e1));
                            //有些属性还具有枚举值的描述映射
                            final Map<String, String> propertyEnumMap = value.stream().filter(f -> ObjectUtils.isNotEmpty(f.getPropertyValueEnum()))
                                    .collect(toMap(k -> k.getProperty() + "_enum", AiFacePropertyPO::getPropertyValueEnum, (e1, e2) -> e1));
                            propertyNameMap.putAll(propertyEnumMap);
                            return propertyNameMap;
                        }
                ));
    }
}
