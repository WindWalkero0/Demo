package com.ruihe.app.service.activity;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.bean.activity.ActivityPlace;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.promotion.ProductScope;
import com.ruihe.common.dao.bean.promotion.PromotionProduct;
import com.ruihe.common.enums.activity.ActivityEnum;
import com.ruihe.common.enums.promotion.PromotionalEnum;
import com.ruihe.common.pojo.dto.*;
import com.ruihe.common.pojo.request.promotion.SalesProductRequest;
import com.ruihe.app.mapper.promotion.ProductScopeMapper;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.utils.TailRecursionWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


import static com.ruihe.common.pojo.dto.ConditionMatchDetail.getCombineConditionKey;
import static java.util.stream.Collectors.*;


@Slf4j
@Service
public class ActivityMatchLogic {


    final String fixedAndPRO1 = String.format("%s-%s", "0", PromotionalEnum.PRO1.getKey());//固定+产品范围
    final String fixedAndPRO2 = String.format("%s-%s", "0", PromotionalEnum.PRO2.getKey());//固定+指定产品
    final String fixedAndPRO6 = String.format("%s-%s", "0", PromotionalEnum.PRO6.getKey());//固定+产品小类
    final String selectedAndPRO1 = String.format("%s-%s", "1", PromotionalEnum.PRO1.getKey());//选择+产品范围
    final String selectedAndPRO2 = String.format("%s-%s", "1", PromotionalEnum.PRO2.getKey());//选择+指定产品
    final String selectedAndPRO6 = String.format("%s-%s", "1", PromotionalEnum.PRO6.getKey());//选择+产品小类


    private final SimpleProductService simpleProductService;
    private final ProductScopeMapper productScopeMapper;

    public ActivityMatchLogic(SimpleProductService simpleProductService, ProductScopeMapper productScopeMapper) {
        this.simpleProductService = simpleProductService;
        this.productScopeMapper = productScopeMapper;
    }

    /**
     * 活动地点匹配逻辑：当前柜台是否在该活动配置的地点内
     *
     * @param placeType   该活动的地址类型 {@link ActivityEnum}
     * @param places      该活动的活动地点数据
     * @param counterInfo 当前柜台信息
     * @return 该活动的匹配结果
     */
    public static boolean checkActivityPlace(Integer placeType, List<ActivityPlace> places, CounterInformation counterInfo) {
        boolean matchCounter = places.stream().map(ActivityPlace::getCounterId).filter(Objects::nonNull).anyMatch(e -> e.equals(counterInfo.counterId));
        Map<ActivityEnum, Supplier<Boolean>> matchRuler = new HashMap<>();
        matchRuler.put(ActivityEnum.ACTITY_PLACE_TYPE1, () -> true);//全部柜台
        matchRuler.put(ActivityEnum.ACTITY_PLACE_TYPE3, () -> places.stream().map(ActivityPlace::getDepartmentId).anyMatch(e -> e.equals(counterInfo.orgMasterId)));//按组织结构
        matchRuler.put(ActivityEnum.ACTITY_PLACE_TYPE4, () -> matchCounter);//按组织结构指定柜台
        matchRuler.put(ActivityEnum.ACTITY_PLACE_TYPE5, () -> places.stream().map(ActivityPlace::getChannelCode).anyMatch(e -> e.equals(counterInfo.channelCode)));//按渠道
        matchRuler.put(ActivityEnum.ACTITY_PLACE_TYPE6, () -> matchCounter);//按渠道指定柜台
        matchRuler.put(ActivityEnum.ACTITY_PLACE_TYPE7, () -> places.stream().map(ActivityPlace::getRegionCode).anyMatch(e -> e.equals(counterInfo.countyCode)));//按区域
        matchRuler.put(ActivityEnum.ACTITY_PLACE_TYPE8, () -> matchCounter);//按区域指定柜台
        ActivityEnum activityEnum = ActivityEnum.valueOf(String.valueOf(placeType));
        return matchRuler.getOrDefault(activityEnum, () -> false).get();
    }

    /**
     * 活动对象匹配逻辑：当前会员对象是否在该活动配置的对象内
     *
     * @param activityId   活动Id
     * @param objectType   活动的对象类型{@link ActivityEnum}
     * @param memberId     当前会员Id
     * @param searchMember Map<activityId,List<MemberDTO>> 活动的搜索会员集合 {@link MemberDTO}
     * @param excelImport  Map<activityId,List<MemberDTO>> 活动的Excel导入会员集合 {@link MemberDTO}
     * @return 该活动的匹配结果
     */

    public static boolean checkActivityObject(String activityId,
                                              Integer objectType,
                                              String memberId,
                                              Map<String, List<MemberDTO>> searchMember,
                                              Map<String, List<MemberDTO>> excelImport) {

        var members = objectType.equals(ActivityEnum.ACTITY_OBJECT2.getKey()) ? searchMember : excelImport;

        Map<ActivityEnum, Supplier<Boolean>> matchRuler = new HashMap<>();
        matchRuler.put(ActivityEnum.ACTITY_OBJECT1, () -> memberId != null);//全部会员
        matchRuler.put(ActivityEnum.ACTITY_OBJECT2, () -> CollectionUtils.isNotEmpty(members.get(activityId)));//搜索条件
        matchRuler.put(ActivityEnum.ACTITY_OBJECT3, () -> members.getOrDefault(memberId, Collections.emptyList()).stream().anyMatch(e -> e.memberId.equals(memberId)));//Excel导入
        matchRuler.put(ActivityEnum.ACTITY_OBJECT4, () -> true);//不限对象

        ActivityEnum activityEnum = ActivityEnum.valueOf(String.valueOf(objectType));
        return matchRuler.getOrDefault(activityEnum, () -> false).get();
    }

    /**
     * 促销活动非整单购买条件匹配逻辑：当前购物车的商品是否满足非整单条件设置
     *
     * @param activity                促销活动
     * @param shoppingCarProducts     购物车商品集合
     * @param wholeActivityConfig     一对整单活动的数据(是否有会员 + 整单活动限定商品映射)
     * @param noneWholeActivityConfig 非整单活动映射 详情结构清查看 该方法的{@link PromotionActivityService#queryNoneWholeBuyConditionProduct(List) 返回结果说明 }
     * @return 该活动的匹配结果
     */
    public boolean checkActivityBuyCondition(PromotionActivityDTO activity,
                                             List<SalesProductRequest> shoppingCarProducts,
                                             Boolean isMember,
                                             Map<String, List<PromotionProduct>> wholeActivityConfig,
                                             Map<String, Map<String, List<RewardCloudDTO>>> noneWholeActivityConfig) {

        Map<PromotionalEnum, Supplier<Boolean>> matchRuler = new HashMap<>();
        matchRuler.put(PromotionalEnum.TIAOJIAN1, () -> true);//无条件
        matchRuler.put(PromotionalEnum.TIAOJIAN2, () -> {//整单条件

            var productFilterLogic = getFilterLogicOfLimited(activity.uid, wholeActivityConfig);//检查购买条件时调用
            int inputValues = getWholeOrderShoppingCarValue(activity.total, isMember, shoppingCarProducts, productFilterLogic);//检查购买条件时调用
            return inputValues >= Integer.parseInt(activity.inputValues);

        });
        matchRuler.put(PromotionalEnum.TIAOJIAN3, () -> {//非整单条件

            var currentActivityConfigMap = noneWholeActivityConfig.get(activity.uid);//获取活动非整单的所有配置条件 如果获取不到数据那就证明是数据有问题!!!

            var activityMatchRes = currentActivityConfigMap.entrySet().stream().collect(toMap(
                    Map.Entry::getKey,
                    map -> {
                        var conditionKey = getCombineConditionKey(map.getKey());
                        var buyConditionProducts = map.getValue();//非整单的一个限定模式(不管是组合模式还是选择模式)下配置的具体产品集合(产品集合不管它是产品范围还是限定产品还是产品小类)
                        return checkNonWholeOrderShoppingCarProductsMatchLogic(conditionKey, buyConditionProducts, shoppingCarProducts);//非整单情形下的所有组合情况的匹配逻辑
                    }
            ));
            return activityMatchRes.entrySet().stream().allMatch(Map.Entry::getValue);

        });//非整单条件

        PromotionalEnum activityEnum = PromotionalEnum.valueOf(String.valueOf(activity.buyConditionType));
        return matchRuler.getOrDefault(activityEnum, () -> false).get();
    }

    /**
     * 购物车里筛选出整单条件里限定商品逻辑（如果有限定商品的话）
     *
     * @param activityId           活动ID
     * @param buyConditionProducts 整单活动限定商品配置
     * @return 过滤逻辑
     */
    private static Predicate<SalesProductRequest> getFilterLogicOfLimited(String activityId,
                                                                          Map<String, List<PromotionProduct>> buyConditionProducts) {
        var limitedProducts = buyConditionProducts.get(activityId);//限定产品
        var limitedProductsCount = limitedProducts.stream().filter(Objects::nonNull).count();//限定产品的数量
        //购物车里找出有效商品的逻辑  如果没有限定产品 用购物车里的所有商品，否者要排除购物车里非限定产品
        return e -> limitedProductsCount == 0 || limitedProducts.stream().anyMatch(limitProduct -> limitProduct.specificProductId.equals(e.getProId()));
    }


    public int maxMatchCount(PromotionActivityDTO activity,
                             List<SalesProductRequest> shoppingCarProducts,
                             Boolean existMember, Map<String, List<PromotionProduct>> wholeActivityProductMap,
                             Map<String, Map<String, List<RewardCloudDTO>>> noneWholeActivityProductMap) {


        final Supplier<Integer> integerSupplier = () -> {//整单条件
            var productFilterLogic = getFilterLogicOfLimited(activity.uid, wholeActivityProductMap);//检查最大匹配次数时调用
            int inputValues = getWholeOrderShoppingCarValue(activity.total, existMember, shoppingCarProducts, productFilterLogic);//检查购买条件时调用
            //具体逻辑参考产品文档
            return inputValues / Integer.parseInt(activity.inputValues);

        };

        final Supplier<Integer> integerSupplier1 = () -> {//非整单条件
            var currentActivityConfigMap = noneWholeActivityProductMap.get(activity.uid);
            //非整单活动的DTO
            var nonWholeDTO = new NonWholeActivityDTO();
            nonWholeDTO.activity = activity;
            nonWholeDTO.shoppingCarProducts = shoppingCarProducts;
            nonWholeDTO.initMatchDetail(currentActivityConfigMap);

            return TailRecursionWrapper
                    .<NonWholeActivityDTO, Integer>init(nonWholeDTO)
                    .loop(this::matchManyCountRuler) //循环匹配次数
                    .when(NonWholeActivityDTO::shoppingCarIsEmpty) //循环结束条件
                    .done(NonWholeActivityDTO::getMatchCount)//最终返回结果
                    .exec().orElse(0);
        };

        Map<PromotionalEnum, Supplier<Integer>> matchRuler = new HashMap<>();
        matchRuler.put(PromotionalEnum.TIAOJIAN2, integerSupplier);
        matchRuler.put(PromotionalEnum.TIAOJIAN3, integerSupplier1);

        PromotionalEnum activityEnum = PromotionalEnum.valueOf(String.valueOf(activity.buyConditionType));
        return matchRuler.getOrDefault(activityEnum, () -> 0).get();

    }

    private NonWholeActivityDTO matchManyCountRuler(NonWholeActivityDTO dto) {

        var newDTO = new NonWholeActivityDTO(dto.activity);

        dto.matchDetail.forEach((oldDetailKey, oldDetailValue) -> {

            var combineConditionKey = oldDetailValue.combineConditionKey;
            var conditionProducts = oldDetailValue.conditionProducts;
            var shoppingCarProducts = dto.shoppingCarProducts;

            List<SalesProductRequest> matchProducts;
            List<SalesProductRequest> newShoppingCarProducts;

            //匹配逻辑匹配结果
            var matchRes = this.conditionMatchLogic(combineConditionKey, conditionProducts, shoppingCarProducts);
            if (matchRes) {
                //如果这次匹配成功，那么就要从购物车筛选出匹配条件商品
                matchProducts = this.findAllMatchProductsLogic(combineConditionKey, conditionProducts, shoppingCarProducts);
                //如果这次匹配成功，将筛选出的商品从购物车里的剔除掉
                newShoppingCarProducts = this.refreshShoppingCarProductsLogic(combineConditionKey, conditionProducts, shoppingCarProducts);
            } else {
                //如果这次匹配失败,那么就要清空购物车;后面就要进行终止匹配了
                matchProducts = Collections.emptyList();
                newShoppingCarProducts = Collections.emptyList();
            }

            //单个组合模式每匹配一次都要重新更新匹配结果
            var newDetail = new ConditionMatchDetail(oldDetailValue.combineConditionKey);
            newDetail.isMatchSuccess = matchRes;
            newDetail.matchProducts = matchProducts;
            newDTO.updateMatchDetail(Pair.of(oldDetailKey, newDetail));
            newDTO.shoppingCarProducts = newShoppingCarProducts;

        });

        //完整的一次匹配次数最终结果
        boolean finalMatchResult = dto.matchDetail.values().stream().allMatch(e -> e.isMatchSuccess);
        if (finalMatchResult) newDTO.matchCount += 1; //这次匹配成功的话就对匹配结果加1呀~!
        return newDTO;
    }

    private List<SalesProductRequest> refreshShoppingCarProductsLogic(String combineConditionKey, List<RewardCloudDTO> conditionProducts, List<SalesProductRequest> shoppingCarProducts) {
        return Collections.emptyList();
    }


    private boolean conditionMatchLogic(String conditionKey,
                                        List<RewardCloudDTO> buyConditionProducts,
                                        List<SalesProductRequest> shoppingCarProducts) {

        Map<String, Supplier<Boolean>> matchLogic = new HashMap<>();
        //固定+指定产品
        matchLogic.put(fixedAndPRO2, () -> buyConditionProducts.stream().allMatch(this.forProductMatch(shoppingCarProducts)));
        //固定+产品小类
        matchLogic.put(fixedAndPRO6, () -> buyConditionProducts.stream().anyMatch(this.forProductCategory(shoppingCarProducts)));
        //固定+产品范围
        matchLogic.put(fixedAndPRO1, this.forProductRange2(buyConditionProducts, shoppingCarProducts));
        //选择+指定产品
        matchLogic.put(selectedAndPRO2, () -> buyConditionProducts.stream().anyMatch(this.forProductMatch(shoppingCarProducts)));
        //选择+产品小类
        matchLogic.put(selectedAndPRO6, () -> buyConditionProducts.stream().anyMatch(this.forProductCategory(shoppingCarProducts)));
        //选择+产品范围
        matchLogic.put(selectedAndPRO1, this.forProductRange2(buyConditionProducts, shoppingCarProducts));

        return matchLogic.getOrDefault(conditionKey, () -> false).get();//一次任意组合的匹配结果
    }

    /**
     * 从购物车里进行一次剔除符合非整单条件限定商品的操作
     *
     * @param conditionKey         限定条件的key
     * @param buyConditionProducts 单个购买条件的奖励集合
     * @param shoppingCarProducts  购物车里的商品
     * @return 当前购买条件能够匹配上的商品集合
     */
    private List<SalesProductRequest> findAllMatchProductsLogic(String conditionKey,
                                                                List<RewardCloudDTO> buyConditionProducts,
                                                                List<SalesProductRequest> shoppingCarProducts) {
        //购物车商品按价格倒序排列
        var shoppingCarProductsSorted = shoppingCarProducts.stream()
                .sorted(Comparator.comparing(SalesProductRequest::confirmProductPrice).reversed())
                .collect(Collectors.toList());

        Map<String, Supplier<List<SalesProductRequest>>> matchLogic = new HashMap<>();

        //固定+指定产品
        matchLogic.put(fixedAndPRO2, () -> {

            var proCodeAndCount = buyConditionProducts.stream().collect(toMap(RewardCloudDTO::getSpecificProductId, RewardCloudDTO::getInputValues));

            return shoppingCarProductsSorted.stream().map(e -> {
                //key 产品code 数量
                var products = new SalesProductRequest();
                BeanUtils.copyProperties(e, products);
                products.setProCount(proCodeAndCount.get(e.getProId()));//这次要从购物车里排除产品数量
                return products;
            }).collect(toList());
        });

        //固定+产品小类
        matchLogic.put(fixedAndPRO6, () -> {

            //购买条件产品小类数量
            var smallCategoryAndCount = buyConditionProducts.stream().collect(toMap(RewardCloudDTO::getProductClassId, e -> Integer.valueOf(e.inputValues)));
            //根据产品条码获取产品详情
            var productCodes = shoppingCarProducts.stream().map(SalesProductRequest::getProId).collect(toList());//产品id
            var allProducts = simpleProductService.findAllProducts(productCodes);//获取产品详情
            var barCodeAndSmallCodeMap = allProducts.stream().collect(toMap(Product::getPrdBarCode, Product::getSmallCatCode));//产品ID和产品小类的map

            //对购物车里的产品按产品小类分组
            var shoppingCarSmallCategoryGroup = shoppingCarProducts.stream()
                    .collect(groupingBy(f -> barCodeAndSmallCodeMap.get(f.getProId()), LinkedHashMap::new, toList()));

            return shoppingCarSmallCategoryGroup.entrySet().stream().flatMap(entry -> {

                var smallCategory = entry.getKey();
                var smallCategoryProducts = entry.getValue();

                //将购物车里带有多个数量的产品集合平铺成只带有一个数量的产品集合:->为的是方便按顺序从购物车里挑出可以满足产品小类个数的产品
                var productFlat = smallCategoryProducts.stream()
                        .flatMap(e -> IntStream.rangeClosed(1, Integer.parseInt(e.getProCount())).mapToObj(f -> {
                            var product = new SalesProductRequest();
                            BeanUtils.copyProperties(e, f);
                            product.setProCount("1");
                            return product;
                        }).collect(toList()).stream()).collect(toList());

                int needSmallCount = smallCategoryAndCount.get(smallCategory);//购买条件里需要的产品小类商品数量
                //取出符合产品小类的购物车商品
                return productFlat.stream().limit(needSmallCount);

            }).collect(groupingBy(SalesProductRequest::getProId))//从购物车收集完符合产品小类的产品后再把平铺的产品再还原回去
                    .values()
                    .stream()
                    .map(products -> {
                        var product = products.get(0);
                        product.setProCount(String.valueOf(products.size()));
                        return product;
                    }).collect(toList());
        });
        //固定+产品范围
        matchLogic.put(fixedAndPRO1, Collections::emptyList);//todo('选择+产品小类确定产品')
        //选择+指定产品
        matchLogic.put(selectedAndPRO2, () -> {

            Map<String, String> proCodeAndCount = buyConditionProducts.stream().collect(toMap(RewardCloudDTO::getSpecificProductId, RewardCloudDTO::getInputValues));
            //当满足选择条件下取零售价最大的那笔组合
            var matchedProducts = shoppingCarProductsSorted.stream().filter(e -> {
                String count = proCodeAndCount.get(e.getProId());//配置里需要的产品数量
                return Integer.parseInt(count) >= Integer.parseInt(e.getProCount());
            }).findFirst().orElseThrow(() -> {
                log.error("非整单条件最大匹配次数代码逻辑处理有问题,在满足(选择+指定产品)匹配条件后获取匹配的商品时居然为空了,matchedProducts={},buyConditionProducts={}"
                        , shoppingCarProductsSorted, buyConditionProducts);
                throw new BizException("网络异常,请一段时间后再重试!");
            });

            matchedProducts.setProCount(proCodeAndCount.get(matchedProducts.getProId()));//设置产品数量
            return List.of(matchedProducts);
        });
        //选择+产品小类
        matchLogic.put(selectedAndPRO6, Collections::emptyList);//todo('选择+产品小类确定产品')
        //选择+产品范围
        matchLogic.put(selectedAndPRO1, Collections::emptyList);//todo('选择+产品范围确定产品')

        matchLogic.getOrDefault(conditionKey, Collections::emptyList).get();//一次任意组合的匹配结果
        return Collections.emptyList();
    }

    /**
     * 获取购物车里计算出来的(总金额/总数量)
     *
     * @param total               类型(0:总金额，1:总数量)
     * @param isMember            是否是会员
     * @param shoppingCarProducts 购物车商品
     * @param filterLogic         限定产品过滤过滤
     * @return 是否能匹配上
     */
    private static int getWholeOrderShoppingCarValue(Integer total,
                                                     Boolean isMember,
                                                     List<SalesProductRequest> shoppingCarProducts,
                                                     Predicate<SalesProductRequest> filterLogic) {

        Map<Integer, Supplier<Integer>> wholeLogic = new HashMap<>();
        wholeLogic.put(0, () -> {//总金额
            return shoppingCarProducts.stream().filter(filterLogic).mapToInt(e -> {
                //单价 * 数量
                var price = isMember ? e.getMemberPrice().intValue() : Integer.parseInt(e.getProPrice());
                var num = Integer.parseInt(e.getProCount());
                return price * num;
            }).sum();
        });

        wholeLogic.put(1, () -> {//总数量
            return shoppingCarProducts.stream().filter(filterLogic).mapToInt(e -> Integer.parseInt(e.getProCount())).sum();
        });

        return wholeLogic.getOrDefault(total, () -> 0).get();
    }


    /**
     * 促销活动非整单的购物车产品匹配逻辑
     *
     * @param buyConditionProducts 非整单里配置的当前条件类型的一组产品
     * @param shoppingCarProducts  购物车里的产品集合
     */
    private Boolean checkNonWholeOrderShoppingCarProductsMatchLogic(String conditionKey,
                                                                    List<RewardCloudDTO> buyConditionProducts,
                                                                    List<SalesProductRequest> shoppingCarProducts) {


        Map<String, Supplier<Boolean>> matchLogic = new HashMap<>();
        //固定+指定产品
        matchLogic.put(fixedAndPRO2, () -> buyConditionProducts.stream().allMatch(this.forProductMatch(shoppingCarProducts)));
        //固定+产品小类
        matchLogic.put(fixedAndPRO6, () -> buyConditionProducts.stream().allMatch(this.forProductCategory(shoppingCarProducts)));
        //固定+产品范围
        matchLogic.put(fixedAndPRO1, this.forProductRange(buyConditionProducts, shoppingCarProducts));
        //选择+指定产品
        matchLogic.put(selectedAndPRO2, () -> buyConditionProducts.stream().anyMatch(this.forProductMatch(shoppingCarProducts)));
        //选择+产品小类
        matchLogic.put(selectedAndPRO6, () -> buyConditionProducts.stream().anyMatch(this.forProductCategory(shoppingCarProducts)));
        //选择+产品范围
        matchLogic.put(selectedAndPRO1, this.forProductRange(buyConditionProducts, shoppingCarProducts));

        return matchLogic.getOrDefault(conditionKey, () -> false).get();//一次任意组合的匹配结果
    }


    /**
     * 购物车里产品与单个活动的单个组合的单个条件(限定特定产品)匹配的逻辑
     *
     * @param shoppingCarProducts 购物车里的产品
     * @return 购物车的产品
     */
    private Predicate<RewardCloudDTO> forProductMatch(List<SalesProductRequest> shoppingCarProducts) {
        return e -> {
            var productQuantityMap = shoppingCarProducts.stream().collect(toMap(SalesProductRequest::getProId, SalesProductRequest::getProCount));
            var productQt = productQuantityMap.get(e.getSpecificProductId());
            if (StringUtils.isEmpty(productQt)) {
                return false;
            } else {
                //购物车里该产品数据>=当前活动里配置的产品数量
                return Integer.parseInt(productQt) >= Integer.parseInt(e.getInputValues());
            }
        };
    }

    /**
     * 购物车里产品与单个活动的单个组合的单个条件(限定产品小类)匹配的逻辑
     *
     * @param shoppingCarProducts 购物车里的产品
     * @return 匹配结果
     */
    private Predicate<RewardCloudDTO> forProductCategory(List<SalesProductRequest> shoppingCarProducts) {
        return e -> {

            //根据产品条码获取产品详情
            var productCodes = shoppingCarProducts.stream().map(SalesProductRequest::getProId).collect(toList());
            var allProducts = simpleProductService.findAllProducts(productCodes);

            //产品对应的小类Map
            var barCodeAndSmallCodeMap = allProducts.stream().collect(toMap(Product::getPrdBarCode, Product::getSmallCatCode));
            //购物车里每种产品小类对应的产品数量
            var smallCodeQuantityMap = shoppingCarProducts.stream().collect(groupingBy(f -> barCodeAndSmallCodeMap.get(f.getProId()), counting()));

            var smallCodeQt = smallCodeQuantityMap.get(e.getProductClassId());
            if (smallCodeQt == null) {
                return false;
            } else {
                //购物车里该产品小类数量>=当前活动里配置的小类数量
                return smallCodeQt >= Long.parseLong(e.getInputValues());
            }
        };
    }

    /**
     * 购物车里产品与单个活动的单个组合的单个条件(限定产品范围)匹配的逻辑
     *
     * @param configProducts      非整单里配置的当前条件类型的一组产品
     * @param shoppingCarProducts 购物车产品
     * @return 匹配结果
     */
    private Supplier<Boolean> forProductRange(List<RewardCloudDTO> configProducts, List<SalesProductRequest> shoppingCarProducts) {
        return () -> {
            //因为产品范围条件时t_promotion_reward_cloud表里储存时就一条数据,它的详情数据在t_promotion_product_scope里 这个设计不明白!!!!!
            //查询配置里产品范围的商品详情
            RewardCloudDTO rewardCloud = configProducts.get(1);
            var condition = Wrappers.<ProductScope>lambdaQuery().eq(ProductScope::getRewardUid, rewardCloud.rewardUid);
            var productScopes = productScopeMapper.selectList(condition);

            //产品范围 特定产品和产品小类只能存在一种
            long proRangeCount = productScopes.stream().map(ProductScope::getProRange).distinct().count();
            if (proRangeCount != 1L) {
                log.error("非整单条件产品范围配置产品中存储的proRange数据有误,出现了多个proRange或者没有proRange,productScopes={}", productScopes);
                throw new BizException("非整单条件产品范围配置的产品范围类型值错误");
            }

            Map<PromotionalEnum, Supplier<Boolean>> matchRuler = new HashMap<>();
            matchRuler.put(PromotionalEnum.PRO2, () -> {
                var productQuantityMap = shoppingCarProducts.stream().collect(toMap(SalesProductRequest::getProId, SalesProductRequest::getProCount));
                //购物车里每个产品的数量
                int productQt = productScopes.stream().mapToInt(e -> {

                    //从购物车里获取活动特定产品的数量
                    var _productQt = productQuantityMap.get(e.getSpecificProductId());
                    if (StringUtils.isEmpty(_productQt)) {
                        return 0;
                    } else {
                        return Integer.parseInt(_productQt);
                    }
                }).sum();
                //购物车里该产品数据>=当前活动里配置的产品数量
                return productQt >= Integer.parseInt(rewardCloud.inputValues);
            });
            matchRuler.put(PromotionalEnum.PRO6, () -> {

                //根据产品条码获取产品详情
                var productCodes = shoppingCarProducts.stream().map(SalesProductRequest::getProId).collect(toList());
                var productsDetail = simpleProductService.findAllProducts(productCodes);

                //产品对应的小类
                var barCodeAndSmallCodeMap = productsDetail.stream().collect(toMap(Product::getPrdBarCode, Product::getSmallCatCode));
                //购物车里每种产品小类对应的数量
                var smallCodeQuantityMap = shoppingCarProducts.stream().collect(groupingBy(f -> barCodeAndSmallCodeMap.get(f.getProId()), counting()));

                int smallCodeQt = productScopes.stream().mapToInt(e -> {
                    //从购物车里获取活动配置小类的数量
                    var _smallCodeQt = smallCodeQuantityMap.get(e.getProductClassId());
                    if (_smallCodeQt == null) {
                        return 0;
                    } else {
                        return _smallCodeQt.intValue();
                    }
                }).sum();
                //购物车里该产品小类数量>=当前活动里配置的小类数量
                return smallCodeQt >= Integer.parseInt(rewardCloud.inputValues);

            });

            int proRange = productScopes.get(0).proRange;
            PromotionalEnum activityEnum = PromotionalEnum.valueOf(String.valueOf(proRange));
            return matchRuler.getOrDefault(activityEnum, () -> false).get();
        };
    }


    private Supplier<Boolean> forProductRange2(List<RewardCloudDTO> configProducts, List<SalesProductRequest> shoppingCarProducts) {
        return () -> {
            //因为产品范围条件时t_promotion_reward_cloud表里储存时就一条数据,它的详情数据在t_promotion_product_scope里 这个设计不明白!!!!!
            //查询配置里产品范围的商品详情
            RewardCloudDTO rewardCloud = configProducts.get(1);
            var condition = Wrappers.<ProductScope>lambdaQuery().eq(ProductScope::getRewardUid, rewardCloud.rewardUid);
            var productScopes = productScopeMapper.selectList(condition);

            //产品范围 特定产品和产品小类只能存在一种
            long proRangeCount = productScopes.stream().map(ProductScope::getProRange).distinct().count();
            if (proRangeCount != 1L) {
                log.error("非整单条件产品范围配置产品中存储的proRange数据有误,出现了多个proRange或者没有proRange,productScopes={}", productScopes);
                throw new BizException("非整单条件产品范围配置的产品范围类型值错误");
            }

            Map<PromotionalEnum, Supplier<Boolean>> matchRuler = new HashMap<>();
            matchRuler.put(PromotionalEnum.PRO2, () -> {
                var productQuantityMap = shoppingCarProducts.stream().collect(toMap(SalesProductRequest::getProId, SalesProductRequest::getProCount));
                //购物车里每个产品的数量
                int productQt = productScopes.stream().mapToInt(e -> {

                    //从购物车里获取活动特定产品的数量
                    var _productQt = productQuantityMap.get(e.getSpecificProductId());
                    if (StringUtils.isEmpty(_productQt)) {
                        return 0;
                    } else {
                        return Integer.parseInt(_productQt);
                    }
                }).sum();
                //购物车里该产品数据>=当前活动里配置的产品数量
                return productQt >= Integer.parseInt(rewardCloud.inputValues);
            });
            matchRuler.put(PromotionalEnum.PRO6, () -> {

                //根据产品条码获取产品详情
                var productCodes = shoppingCarProducts.stream().map(SalesProductRequest::getProId).collect(toList());
                var productsDetail = simpleProductService.findAllProducts(productCodes);

                //产品对应的小类
                var barCodeAndSmallCodeMap = productsDetail.stream().collect(toMap(Product::getPrdBarCode, Product::getSmallCatCode));
                //购物车里每种产品小类对应的数量
                var smallCodeQuantityMap = shoppingCarProducts.stream().collect(groupingBy(f -> barCodeAndSmallCodeMap.get(f.getProId()), counting()));

                int smallCodeQt = productScopes.stream().mapToInt(e -> {
                    //从购物车里获取活动配置小类的数量
                    var _smallCodeQt = smallCodeQuantityMap.get(e.getProductClassId());
                    if (_smallCodeQt == null) {
                        return 0;
                    } else {
                        return _smallCodeQt.intValue();
                    }
                }).sum();
                //购物车里该产品小类数量>=当前活动里配置的小类数量
                return smallCodeQt >= Integer.parseInt(rewardCloud.inputValues);

            });

            int proRange = productScopes.get(0).proRange;
            PromotionalEnum activityEnum = PromotionalEnum.valueOf(String.valueOf(proRange));
            return matchRuler.getOrDefault(activityEnum, () -> false).get();
        };
    }

}
