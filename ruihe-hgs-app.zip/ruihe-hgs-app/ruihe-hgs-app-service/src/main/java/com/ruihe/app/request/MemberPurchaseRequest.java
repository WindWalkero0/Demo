package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-12-19 15:22
 */
@ApiModel(value = "MemberPurchaseRequest", description = "寄存箱查询历史销售记录请求实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberPurchaseRequest implements Serializable {

    @ApiModelProperty(value = "会员手机号")
    private String mobilePhone;

    @ApiModelProperty(value = "每页显示数量")
    @NotNull(message = "当前页不能为空")
    private Integer pageSize;

    @ApiModelProperty(value = "页码")
    @NotNull(message = "页码不能为空")
    private Integer pageNumber;
}
