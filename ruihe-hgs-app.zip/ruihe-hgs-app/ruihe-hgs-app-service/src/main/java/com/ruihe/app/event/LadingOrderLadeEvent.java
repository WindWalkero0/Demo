package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 预订单提货事件
 *
 * @author William
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class LadingOrderLadeEvent extends ApplicationEvent {
    /**
     * 单号
     */
    private String orderNo;

    public LadingOrderLadeEvent(Object source, String orderNo) {
        super(source);
        this.orderNo = orderNo;
    }
}
