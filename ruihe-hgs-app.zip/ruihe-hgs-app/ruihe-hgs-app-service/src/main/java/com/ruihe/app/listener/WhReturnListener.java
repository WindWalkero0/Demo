package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.service.warehouse.StoreInventoryService;
import com.ruihe.common.dao.bean.warehouse.WhReturnItemLogPo;
import com.ruihe.common.dao.bean.warehouse.WhReturnPo;
import com.ruihe.common.dao.bean.warehouse.WhStockLogPo;
import com.ruihe.common.enums.stock.WhStockBizTypeEnum;
import com.ruihe.app.event.WhReturnEvent;
import com.ruihe.app.mapper.warehouse.WhReturnItemLogMapepr;
import com.ruihe.app.mapper.warehouse.WhReturnMapper;
import com.ruihe.common.constant.CommonConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 退库审核通过事件处理
 *
 * @author William
 */
@Slf4j
@Component
public class WhReturnListener {

    @Autowired
    private WhReturnMapper whReturnMapper;

    @Autowired
    private WhReturnItemLogMapepr whReturnItemLogMapepr;

    @Autowired
    private StoreInventoryService storeInventoryService;


    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(WhReturnEvent event) {
        try {
            //查询退库申请单主表
            WhReturnPo orderPo = whReturnMapper.selectById(event.getOrderNo());
            //查询退库log明细
            List<WhReturnItemLogPo> itemList = whReturnItemLogMapepr.selectList(Wrappers.<WhReturnItemLogPo>lambdaQuery()
                    .eq(WhReturnItemLogPo::getReturnNo, orderPo.getU8OrderNo()));
            //根据U8返回的log子表构建库存log表
            List<WhStockLogPo> whStockLogList = this.extractStockLogList(orderPo, itemList);
            //按返回的单据处理库存
            storeInventoryService.changeStock(orderPo.getCounterId(), whStockLogList);
        } catch (Exception e) {
            log.error("退库处理异常，event{}", JSON.toJSONString(event), e);
        }
    }

    /**
     * 抽取门店盘点对象
     *
     * @param orderPo
     * @param itemList
     * @return
     */
    private List<WhStockLogPo> extractStockLogList(WhReturnPo orderPo, List<WhReturnItemLogPo> itemList) {
        return itemList.stream()
                .map(e ->
                        WhStockLogPo.builder()
                                .counterId(orderPo.getCounterId())
                                .counterName(orderPo.getCounterName())
                                .baCode(orderPo.getBaCode())
                                .baName(orderPo.getBaName())
                                .bizType(WhStockBizTypeEnum.RETURN.getCode())
                                .bizNo(orderPo.getReturnNo())
                                .bizTime(orderPo.getCreateTime())
                                .prdBarCode(e.getPrdBarCode())
                                .prdName(e.getPrdName())
                                .goodsBarCode(e.getGoodsBarCode())
                                .qty(Math.negateExact(Math.abs(e.getRealQty())))
                                .prdPrice(e.getPrdPrice())
                                .memberPrice(e.getMemberPrice())
                                .bigCatCode(e.getBigCatCode())
                                .bigCatName(e.getBigCatName())
                                .mediumCatCode(e.getMediumCatCode())
                                .mediumCatName(e.getMediumCatName())
                                .smallCatCode(e.getSmallCatCode())
                                .smallCatName(e.getSmallCatName())
                                .build()
                ).collect(Collectors.toList());
    }
}
