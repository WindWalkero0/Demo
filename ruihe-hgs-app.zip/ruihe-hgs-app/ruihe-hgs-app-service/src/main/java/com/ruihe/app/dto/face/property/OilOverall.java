package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class OilOverall {
    private String area;
    private String areaRatio;
    private Integer level;
}
