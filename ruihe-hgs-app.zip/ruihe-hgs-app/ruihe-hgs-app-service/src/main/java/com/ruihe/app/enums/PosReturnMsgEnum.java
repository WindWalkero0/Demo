package com.ruihe.app.enums;

/**
 * @author 梁远
 * @Description 退库单审核操作信息
 * @create 2019-10-17 15:14
 */
public enum PosReturnMsgEnum {

    //申请单作成
    APPLY(1, "退库申请单作成"),
    //SAP确认
    SAP(2, "SAP确认"),
    //已确认
    CONFIRM(3, "已确认"),
    //已废弃
    REJECTED(4, "已废弃");
    private Integer code;
    private String msg;


    PosReturnMsgEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
