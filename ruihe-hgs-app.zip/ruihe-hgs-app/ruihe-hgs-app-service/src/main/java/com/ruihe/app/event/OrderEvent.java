package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 销售订单事件
 *
 * @author William
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class OrderEvent extends ApplicationEvent {

    /**
     * 订单号
     */
    private String orderNo;

    /**
     * Create a new ApplicationEvent.
     *
     * @param source the object on which the event initially occurred (never {@code null})
     */
    public OrderEvent(Object source, String orderNo) {
        super(source);
        this.orderNo = orderNo;
    }

}
