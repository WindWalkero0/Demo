package com.ruihe.app.service.order;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ruihe.app.request.PosCheckOrderRequest;
import com.ruihe.app.request.PosSaleOrderRequest;
import com.ruihe.app.request.SalesRequest;
import com.ruihe.app.service.member.AboutMemberActivityService;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.member.MemberActivityProduct;
import com.ruihe.common.dao.bean.member.MemberActivitySon;
import com.ruihe.common.dao.bean.promotion.PromotionActivity;
import com.ruihe.common.dao.bean.system.SystemConfigPo;
import com.ruihe.common.enums.activity.MemberActivityRestrictEnum;
import com.ruihe.common.util.LambdaUtil;
import com.ruihe.common.dao.bean.warehouse.WhStockPo;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.enums.order.OrderItemProductTypeEnum;
import com.ruihe.common.enums.promotion.PromotionalEnum;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.enums.system.SystemConfigEnum;
import com.ruihe.common.pojo.request.OrderActivityRequest;
import com.ruihe.common.pojo.request.order.MatchRequest;
import com.ruihe.common.pojo.request.order.OrderProductRequest;
import com.ruihe.common.pojo.response.order.OrderProductResponse;
import com.ruihe.common.pojo.response.order.ProductResponse;
import com.ruihe.common.pojo.response.order.PromotionOrderResponse;
import com.ruihe.common.service.CustomService;
import com.ruihe.app.response.ChangePriceResponse;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@DS(DBConst.SLAVE)
@Service
public class OrderShowService {

    @Autowired
    private CustomService customService;

    @Autowired
    private SalesOrderService salesOrderService;

    @Autowired
    private AboutMemberActivityService memberActivityService;

    @Ella(Describe = "查询是否有整单改价权限")
    public Response matchChangePrice(String counterId) {
        List<PromotionActivity> promotionActivities = customService.selectListByTime(PromotionActivity
                .builder()//按时间排序查询所有有效且正在进行中的整单改价活动
                .templateType(0)//不是模板
                .isDel(StatusEnum.UN_DELETED.getKey())//未被删除
                .status(0)//已经生效
                .rewardType(PromotionalEnum.JIANGLI8.getKey())//整单改价
                .activityStatus(0)//正在进行中
                .build());
        List<PromotionActivity> collect = promotionActivities.stream().filter(promotionActivity -> judgeCounter(promotionActivity, counterId)).collect(Collectors.toList());//去除掉不满足的活动
        ChangePriceResponse build = ChangePriceResponse.builder().build();
        LambdaUtil lambdaUtil = LambdaUtil.builder().flag(true).build();
        collect.stream().forEach(promotionActivity -> {//只取最新的一个
            if (lambdaUtil.getFlag()) {
                build.setActivityName(promotionActivity.getName());
                build.setPriceChangeMax(promotionActivity.getPriceChangeMax());
                build.setPriceChangeMin(promotionActivity.getPriceChangeMin());
                build.setUid(promotionActivity.getUid());
                lambdaUtil.setFlag(false);
            }
        });
        return Response.success(build);
    }

    /**
     * 校验兑换活动
     * 兑换活动只有积分兑换
     * 只有兑换
     */
    public Response checkProduct(PosCheckOrderRequest request) {
        //获取到了 兑换活动列表
        List<String> collect = request.getOrderItemList().stream()
                .filter(orderItemRequest -> orderItemRequest.getIsVirtual().equals(1) && orderItemRequest.getProType().equals(0))
                .map(PosCheckOrderRequest.OrderItemRequest::getActivityId)
                .collect(Collectors.toList());
        //获取到了 兑换活动列表
        if (collect.size() == 0) {
            return Response.success();
        }
        List<MemberActivitySon> memberActivitySons = memberActivityService.selectMemberActivitySonList(collect);
        if (memberActivitySons == null || memberActivitySons.size() == 0) {
            return Response.success();
        }
        List<String> restrictsIn = memberActivitySons.stream()
                .filter(activitySon -> activitySon.getRestrictType().equals(MemberActivityRestrictEnum.IN_RESTRICT.getCode()))
                .map(MemberActivitySon::getActivityId)
                .collect(Collectors.toList());
        List<String> restrictsOut = memberActivitySons.stream()
                .filter(activitySon -> activitySon.getRestrictType().equals(MemberActivityRestrictEnum.OUT_RESTRICT.getCode()))
                .map(MemberActivitySon::getActivityId)
                .collect(Collectors.toList());
        //获取排除或者包含的产品总量
        List<MemberActivityProduct> memberActivityProductsIn = memberActivityService.selectMemberActivityRestrictsInProducts(restrictsIn);
        List<MemberActivityProduct> memberActivityProductsOut = memberActivityService.selectMemberActivityRestrictsOutProducts(restrictsOut);
        List<PosCheckOrderRequest.OrderItemRequest> products = request.getOrderItemList().stream().filter(orderItemRequest -> orderItemRequest.getIsVirtual().equals(0)).collect(Collectors.toList());
        StringBuffer sb = new StringBuffer();
        StringBuffer sbb = new StringBuffer();
        if (memberActivityProductsIn != null && memberActivityProductsIn.size() > 0) {
            Map<String, Integer> inMap = memberActivityProductsIn.stream().collect(Collectors.toMap(MemberActivityProduct::getPrdBarCode, MemberActivityProduct::getCount));
            products.forEach(e -> {
                boolean flag = inMap.containsKey(e.getPrdBarCode());
                if (!flag) {
                    //不包含的话就是有问题
                    sb.append(e.getPrdName());
                    sb.append(",");
                }
                if (flag && inMap.get(e.getPrdBarCode()) < e.getPurQty()) {
                    sbb.append(e.getPrdName());
                    sbb.append(",");
                }
            });
            if (sb.length() > 1) {
                return Response.errorMsg(sb.append("产品不可兑换，请核对后重试!").toString());
            }
            if (sbb.length() > 1) {
                return Response.errorMsg(sbb.append("产品超出兑换数量限制，请核对后重试!").toString());
            }
        }
        if (memberActivityProductsOut != null && memberActivityProductsOut.size() > 0) {
            Map<String, Integer> outMap = memberActivityProductsOut.stream().collect(Collectors.toMap(MemberActivityProduct::getPrdBarCode, MemberActivityProduct::getCount));
            products.forEach(e -> {
                boolean flag = outMap.containsKey(e.getPrdBarCode());
                if (flag) {
                    //包含的话就是有问题
                    sb.append(e.getPrdName());
                    sb.append(",");
                }
            });
            if (sb.length() > 1) {
                return Response.errorMsg(sb.append("产品不可兑换，请核对后重试").toString());
            }
        }
        return Response.success();
    }

    @Ella(Describe = "判断是否满足柜台限制:满足true;不满足false;")
    private boolean judgeCounter(PromotionActivity promotionActivity, String counterId) {
        SalesRequest salesRequest = SalesRequest.builder().counterId(counterId).build();
        return salesOrderService.checkActivityPlace(promotionActivity.getActivityPlaceType(), promotionActivity.getUid(), salesRequest);
    }

    @Ella(Describe = "将pos端销售页面所需要展示的数据返回给pos端")
    public Response orderShow(MatchRequest matchRequest) {
        String pro_price_modelCode = SystemConfigEnum.PRO_PRICE_MODEL.getCode();
        SystemConfigPo systemConfig = customService.select(SystemConfigPo.builder().paramKey(pro_price_modelCode).status(CommonStatusEnum.EFFECTIVE.getCode()).build());
        LambdaUtil system = LambdaUtil.builder().type(systemConfig != null ? Integer.parseInt(systemConfig.getParamValue()) : 1).build();
        //正常区域列表
        ArrayList<OrderProductResponse> orderProductResponses = Lists.newArrayList();
        //活动区域对象
        HashMap<String, List<OrderProductResponse>> orderProductResponseMap = Maps.newHashMap();
        //获取到剩余购物车商品(完全未参与到活动的商品)
        List<OrderProductRequest> orderProductRequests = matchRequest.getOrderProductRequests();
        //获取到活动信息以及所队以的匹配商品和奖励商品
        List<OrderActivityRequest> orderActivityRequests = matchRequest.getOrderActivityRequests();
        //检查参数
        checkParams(matchRequest.getIsMember(), matchRequest.getCounterId());
        //一次性加载商品信息
        Map<String, ProductResponse> productMap = operationProduct(orderProductRequests, orderActivityRequests, matchRequest.getCounterId());
        orderProductRequests.forEach(orderProductRequest -> {
            ProductResponse productResponse = productMap.get(orderProductRequest.getGoodsBarCode());
            OrderProductResponse build = OrderProductResponse
                    .builder()
                    .discernType(0)//购物车商品
                    .goodsBarCode(orderProductRequest.getGoodsBarCode())
                    .prdBarCode(orderProductRequest.getPrdBarCode())
                    .isVirtual(0)//是否是虚拟商品
                    .salePrice(matchRequest.getIsMember() ? productResponse.getMemberPrice() : productResponse.getSalePrice())//销售价格
                    .proCount(orderProductRequest.getProCount())//商品数量
                    .productAllMoney(BigDecimal.valueOf(orderProductRequest.getProCount()).multiply(matchRequest.getIsMember() ? productResponse.getMemberPrice() : productResponse.getSalePrice()))//总价格
                    .prdName(productResponse.getPrdName())//商品名称
                    .proType(OrderItemProductTypeEnum.NORMAL.getCode())//商品类型
                    .stock(productResponse.getStock())
                    .build();
            orderProductResponses.add(build);
        });
        orderActivityRequests.stream().forEach(orderActivityRequest -> {
            moneySelect(matchRequest.getIsMember(), orderActivityRequest, orderProductResponses, orderProductResponseMap, productMap, system.getType());
        });
        //组装返回参数
        LambdaUtil lambdaUtil = LambdaUtil.builder().totalMoney(BigDecimal.ZERO).discountMoney(BigDecimal.ZERO).actualMoney(BigDecimal.ZERO).count(BigInteger.ZERO.bitCount()).build();
        orderProductResponseMap.forEach((k, v) -> {
            v.forEach(orderProductResponse -> {
                if (orderProductResponse.getIsVirtual().equals(1)) {//虚拟商品计入优惠金额
                    lambdaUtil.setDiscountMoney(lambdaUtil.getDiscountMoney().add(orderProductResponse.getProductAllMoney()).setScale(2, RoundingMode.HALF_UP));
                } else {//非虚拟商品计入总价
                    lambdaUtil.setCount(lambdaUtil.getCount() + orderProductResponse.getProCount());
                    lambdaUtil.setTotalMoney(lambdaUtil.getTotalMoney().add(orderProductResponse.getProductAllMoney()).setScale(2, RoundingMode.HALF_UP));
                }
            });
        });
        orderProductResponses.forEach(orderProductResponse -> {
            lambdaUtil.setTotalMoney(lambdaUtil.getTotalMoney().add(orderProductResponse.getProductAllMoney()).setScale(2, RoundingMode.HALF_UP));
            lambdaUtil.setCount(lambdaUtil.getCount() + orderProductResponse.getProCount());
        });
        //装载返回参数
        PromotionOrderResponse promotionOrderResponse = PromotionOrderResponse
                .builder()
                .versionNumber("GTM" + System.currentTimeMillis())
                .count(lambdaUtil.getCount())
                .orderProductResponses(orderProductResponses)
                .orderProductResponseMap(orderProductResponseMap)
                .discountMoney(lambdaUtil.getDiscountMoney())
                .totalMoney(lambdaUtil.getTotalMoney())
                .actualMoney(lambdaUtil.getTotalMoney().add(lambdaUtil.getDiscountMoney()))//总金额加上优惠金额得到的是实际金额
                // (一般优惠金额为负数,如果优惠金额为正数说明追加的钱大于实际所得到的商品这种情况是存在的)
                .build();
        if (promotionOrderResponse.getActualMoney().compareTo(BigDecimal.ZERO) == -1) {
            promotionOrderResponse.setActualMoney(BigDecimal.ZERO);
            log.info("返回给pos端金额为0的参数{}", promotionOrderResponse);
        }
        return Response.success(promotionOrderResponse);
    }

    @Ella(Describe = "合并相同的商品")
    private void mergeProducts(OrderActivityRequest orderActivityRequest) {
        List<OrderProductRequest> shoppingCardProducts = orderActivityRequest.getShoppingCardProducts();
        List<OrderProductRequest> rewardProducts = orderActivityRequest.getRewardProducts();
        mergeProducts(shoppingCardProducts);
        mergeProducts(rewardProducts);
        orderActivityRequest.setShoppingCardProducts(null);
        orderActivityRequest.setRewardProducts(null);
        orderActivityRequest.setRewardProducts(rewardProducts);
        orderActivityRequest.setShoppingCardProducts(shoppingCardProducts);
    }

    @Ella(Describe = "合并相同的商品")
    private void mergeProducts(List<OrderProductRequest> orderProductRequests) {
        if (orderProductRequests != null && !orderProductRequests.isEmpty()) {
            HashMap<String, OrderProductRequest> map = Maps.newHashMap();
            orderProductRequests.forEach(orderProductRequest -> {
                OrderProductRequest build = map.get(orderProductRequest.getPrdBarCode());
                if (build != null) {
                    orderProductRequest.setProCount(orderProductRequest.getProCount() + build.getProCount());
                }
                map.put(orderProductRequest.getPrdBarCode(), orderProductRequest);
            });
            orderProductRequests.clear();
            map.forEach((k, v) -> {
                orderProductRequests.add(v);
            });
        }
    }

    @Ella(Describe = "参数判断")
    private void checkParams(Boolean isMember, String counterId) {
        if (isMember == null) {
            log.error("返回展示数据时,isMember参数为空");
            throw new BizException("isMember参数为空");
        }
        if (StringUtils.isEmpty(counterId)) {
            log.error("pos端柜台参数没有传递");
            throw new BizException("pos端柜台参数没有传递");
        }
    }

    @Ella(Describe = "将用到的商品全部一次性查完")
    private Map<String, ProductResponse> operationProduct(List<OrderProductRequest> orderProductRequests, List<OrderActivityRequest> orderActivityRequests, String counterId) {
        HashMap<String, ProductResponse> productHashMap = Maps.newHashMap();
        if (orderActivityRequests != null || !orderActivityRequests.isEmpty()) {
            orderActivityRequests.forEach(orderActivityRequest -> {
                List<OrderProductRequest> shoppingCardProducts = orderActivityRequest.getShoppingCardProducts();
                List<OrderProductRequest> rewardProducts = orderActivityRequest.getRewardProducts();
                fillPrice(shoppingCardProducts, productHashMap, counterId);
                fillPrice(rewardProducts, productHashMap, counterId);
            });
        }
        fillPrice(orderProductRequests, productHashMap, counterId);
        return productHashMap;
    }

    @Ella(Describe = "商品价格填充")
    public void fillPrice(List<OrderProductRequest> orderProductRequests,
                          HashMap<String, ProductResponse> productHashMap, String counterId) {
        if (orderProductRequests != null || !orderProductRequests.isEmpty()) {
            orderProductRequests.forEach(orderProductRequest -> {
                if (StringUtils.isEmpty(orderProductRequest.getGoodsBarCode()) || StringUtils.isEmpty(orderProductRequest.getPrdBarCode())) {
                    log.error("商品的编码或者条码参数没有传递");
                    throw new BizException("商品的编码或者条码参数没有传递");
                }
                WhStockPo whStockPo = customService.select(WhStockPo.builder().prdBarCode(orderProductRequest.getPrdBarCode()).counterId(counterId).goodsBarCode(orderProductRequest.getGoodsBarCode()).build());
                Product product = customService.select(Product.builder().goodsBarCode(orderProductRequest.getGoodsBarCode()).prdBarCode(orderProductRequest.getPrdBarCode()).build());
                ProductResponse productResponse = new ProductResponse();
                BeanUtils.copyProperties(product, productResponse);
                productResponse.setStock(whStockPo == null ? 0 : whStockPo.getStock());
                productHashMap.put(product.getGoodsBarCode(), productResponse);
            });
        }
    }

    @Ella(Describe = "取价选择")
    private void moneySelect(Boolean isMember, OrderActivityRequest orderActivityRequest, ArrayList<OrderProductResponse> orderProductResponses, HashMap<String, List<OrderProductResponse>> orderProductResponseMap, Map<String, ProductResponse> productMap, Integer type) {
        String activityId = orderActivityRequest.getActivityId();
        checkActivityId(activityId);
        //合并相同商品
        mergeProducts(orderActivityRequest);
        //购物车商品
        List<OrderProductRequest> shoppingCardProducts = orderActivityRequest.getShoppingCardProducts();
        //奖励商品
        List<OrderProductRequest> rewardProducts = orderActivityRequest.getRewardProducts();
        //活动信息
        PromotionActivity promotionActivity = customService.select(PromotionActivity.builder().uid(activityId).build());
        //奖励商品数量=活动设置的数量*匹配次数(第N件折扣和整单买送的除外)
        rewardProducts.stream().filter(rewardProduct -> !promotionActivity.getRewardType().equals(PromotionalEnum.JIANGLI6.getKey()) && !promotionActivity.getRewardType().equals(PromotionalEnum.JIANGLI9.getKey())).forEach(rewardProduct -> {
            rewardProduct.setProCount(rewardProduct.getProCount() * orderActivityRequest.getCount());
        });
        List<OrderProductResponse> list = new ArrayList<>();
        LambdaUtil lambdaUtil = LambdaUtil.builder().totalMoney(BigDecimal.ZERO).build();
        //获取条件类型
        Integer buyConditionType = promotionActivity.getBuyConditionType();
        //获取奖励类型
        Integer rewardType = promotionActivity.getRewardType();
        /**
         * 整单的:加价购和赠送礼品中的奖励商品处理--同非整单的:加价购和赠送礼品中的奖励商品处理一致
         * 整单的:整单买送中的奖励商品处理--同非整单的:套装特价和第N件折扣中的奖励商品处理一致
         */
        if ((buyConditionType.equals(PromotionalEnum.TIAOJIAN3.getKey()) || buyConditionType.equals(PromotionalEnum.TIAOJIAN2.getKey()))) {//整单非整单
            if (rewardType.equals(PromotionalEnum.JIANGLI4.getKey()) || rewardType.equals(PromotionalEnum.JIANGLI2.getKey())) {//加价购和赠送礼品
                //奖励商品--活动区域--零售价
                List<OrderProductResponse> collectRewards = fillResponse(rewardProducts, promotionActivity, productMap, BigInteger.ONE.intValue(), type, OrderItemProductTypeEnum.PROMOTION.getCode(), isMember);
                list.addAll(collectRewards);
            } else if ((rewardType.equals(PromotionalEnum.JIANGLI6.getKey()) || rewardType.equals(PromotionalEnum.JIANGLI5.getKey())) || rewardType.equals(PromotionalEnum.JIANGLI9.getKey())) {//整单买送和套装特价和第N件折扣
                //奖励商品--正常取价--活动区域
                List<OrderProductResponse> collectRewards = fillResponse(rewardProducts, promotionActivity, productMap, BigInteger.ONE.intValue(), BigInteger.ZERO.intValue(), OrderItemProductTypeEnum.PROMOTION.getCode(), isMember);
                list.addAll(collectRewards);
            }
            if (buyConditionType.equals(PromotionalEnum.TIAOJIAN2.getKey())) {//整单条件
                wholeOrder(orderProductResponses, shoppingCardProducts, isMember, promotionActivity, productMap);
            } else {//非整单条件
                incompleteOrder(list, shoppingCardProducts, isMember, promotionActivity, productMap);
            }
        } else if (buyConditionType.equals(PromotionalEnum.TIAOJIAN1.getKey())) {//无条件
            unconditional(list, orderProductResponses, rewardProducts, shoppingCardProducts, isMember, promotionActivity, productMap, type);
        } else {
            throw new BizException("未知活动类型");
        }
        if (promotionActivity.getBuyConditionType().equals(PromotionalEnum.TIAOJIAN3.getKey()) && promotionActivity.getRewardType().equals(PromotionalEnum.JIANGLI5.getKey())) {
            list.stream().filter(orderProductResponse -> orderProductResponse.getIsVirtual().equals(0) && orderProductResponse.getDiscernType().equals(0)).forEach(orderProductResponse -> {
                lambdaUtil.setTotalMoney(lambdaUtil.getTotalMoney().add(orderProductResponse.getProductAllMoney()));
            });
        } else {
            list.stream().filter(orderProductResponse -> orderProductResponse.getIsVirtual().equals(0) && orderProductResponse.getDiscernType().equals(1)).forEach(orderProductResponse -> {
                lambdaUtil.setTotalMoney(lambdaUtil.getTotalMoney().add(orderProductResponse.getProductAllMoney()));
            });
        }
        //生成对应的虚拟商品
        OrderProductResponse fictitious = createFictitious(promotionActivity, lambdaUtil, orderActivityRequest.getCount());
        list.add(fictitious);
        orderProductResponseMap.put(promotionActivity.getUid(), list);
    }

    /**
     * 未参加活动的产品:正常取价
     * 奖励产品:零售价
     * 添加的购物商品:在正常销售区域
     * 奖励的商品:在活动区域
     */
    @Ella(Describe = "无条件取价")
    private void unconditional(List<OrderProductResponse> list, ArrayList<OrderProductResponse> orderProductResponses, List<OrderProductRequest> rewardProducts, List<OrderProductRequest> shoppingCardProducts, Boolean isMember, PromotionActivity promotionActivity, Map<String, ProductResponse> productMap, Integer type) {
        Integer rewardType = promotionActivity.getRewardType();
        if (rewardType.equals(PromotionalEnum.JIANGLI4.getKey())) {//加价购
            //零售价--在活动区域
            List<OrderProductResponse> collectRewards = fillResponse(rewardProducts, promotionActivity, productMap, BigInteger.ONE.intValue(), type, OrderItemProductTypeEnum.PROMOTION.getCode(), isMember);
            list.addAll(collectRewards);
            //正常取价--在正常区域
            List<OrderProductResponse> collectCards = fillResponse(shoppingCardProducts, promotionActivity, productMap, BigInteger.ZERO.intValue(), BigInteger.ZERO.intValue(), OrderItemProductTypeEnum.NORMAL.getCode(), isMember);
            orderProductResponses.addAll(collectCards);
        }
    }

    /**
     * 一:加价购和赠送礼品:1限定产品会员价;2奖励商品零售价
     * 二:整单优惠:购买的产品:正常取价
     * 三:整单买送:正常取价
     * 限定以及非限定产品在正常销售区域
     * 奖励产品在正常活动区域中
     */

    @Ella(Describe = "整单取价")
    private void wholeOrder(ArrayList<OrderProductResponse> orderProductResponses, List<OrderProductRequest> shoppingCardProducts, Boolean isMember, PromotionActivity promotionActivity, Map<String, ProductResponse> productMap) {
        Integer rewardType = promotionActivity.getRewardType();
        if (rewardType.equals(PromotionalEnum.JIANGLI4.getKey()) || rewardType.equals(PromotionalEnum.JIANGLI2.getKey())) {//加价购和赠送礼品
            //购物车商品--正常取价--正常区域
            List<OrderProductResponse> collectCards = fillResponse(shoppingCardProducts, promotionActivity, productMap, BigInteger.ZERO.intValue(), BigInteger.ZERO.intValue(), OrderItemProductTypeEnum.NORMAL.getCode(), isMember);
            orderProductResponses.addAll(collectCards);
        } else if (rewardType.equals(PromotionalEnum.JIANGLI9.getKey())) {//整单买送
            //购物车商品--正常取价--正常区域
            List<OrderProductResponse> collectCards = fillResponse(shoppingCardProducts, promotionActivity, productMap, BigInteger.ZERO.intValue(), BigInteger.ZERO.intValue(), OrderItemProductTypeEnum.NORMAL.getCode(), isMember);
            orderProductResponses.addAll(collectCards);
        } else if (rewardType.equals(PromotionalEnum.JIANGLI7.getKey())) {//整单优惠
            //购物车产品--正常取价--正常区域
            List<OrderProductResponse> collectCards = fillResponse(shoppingCardProducts, promotionActivity, productMap, BigInteger.ZERO.intValue(), BigInteger.ZERO.intValue(), OrderItemProductTypeEnum.NORMAL.getCode(), isMember);
            orderProductResponses.addAll(collectCards);
        }
    }

    /**
     * 一:套装特价和第N件折扣:正常取价
     * 二:加价购和赠送礼品:1购买条件产品:会员价;2奖励产品:零售价
     * 非购买条件中商品或者购买条件中商品为成功匹配的商品再正常销售区域
     * 活动匹配成功的商品和奖励的商品在活动区域
     */
    @Ella(Describe = "非整单取价")
    private void incompleteOrder(List<OrderProductResponse> list, List<OrderProductRequest> shoppingCardProducts, Boolean isMember, PromotionActivity promotionActivity, Map<String, ProductResponse> productMap) {
        Integer rewardType = promotionActivity.getRewardType();
        if (rewardType.equals(PromotionalEnum.JIANGLI4.getKey()) || rewardType.equals(PromotionalEnum.JIANGLI2.getKey())) {//加价购和赠送礼品
            //购物车商品--正常取价--活动区域
            List<OrderProductResponse> collectCards = fillResponse(shoppingCardProducts, promotionActivity, productMap, BigInteger.ZERO.intValue(), BigInteger.ZERO.intValue(), OrderItemProductTypeEnum.NORMAL.getCode(), isMember);
            list.addAll(collectCards);
        } else if (rewardType.equals(PromotionalEnum.JIANGLI6.getKey()) || rewardType.equals(PromotionalEnum.JIANGLI5.getKey())) {//第N件折扣和套装特价
            //购物车商品--正常取价--活动区域
            List<OrderProductResponse> collectCards = fillResponse(shoppingCardProducts, promotionActivity, productMap, BigInteger.ZERO.intValue(), BigInteger.ZERO.intValue(), OrderItemProductTypeEnum.NORMAL.getCode(), isMember);
            list.addAll(collectCards);
        }
    }

    @Ella(Describe = "生成虚拟商品信息")
    private OrderProductResponse createFictitious(PromotionActivity promotionActivity, LambdaUtil lambdaUtil, Integer count) {
        //创建虚拟商品信息
        OrderProductResponse build = OrderProductResponse
                .builder()
                .count(count)//匹配次数
                .stock(BigInteger.ZERO.intValue())
                .discernType(1)
                .prdName(promotionActivity.getName())//活动名称
                .goodsBarCode(promotionActivity.getUid())//活动id
                .prdBarCode(promotionActivity.getUid())//活动id
                .activityId(promotionActivity.getUid())
                .activityName(promotionActivity.getName())
                .isVirtual(1)//虚拟商品
                .proCount(count)//数量
                .proType(OrderItemProductTypeEnum.PROMOTION.getCode())//促销类型
                .build();
        Integer rewardType = promotionActivity.getRewardType();
        BigDecimal totalMoney = lambdaUtil.getTotalMoney();
        if (rewardType.equals(PromotionalEnum.JIANGLI4.getKey())) {//加价购
            BigDecimal markupMoney = promotionActivity.getMarkupMoney();
            build.setSalePrice(markupMoney.multiply(BigDecimal.valueOf(build.getCount())).subtract(totalMoney).setScale(2, RoundingMode.HALF_UP));
        } else if (rewardType.equals(PromotionalEnum.JIANGLI7.getKey())) {//整单优惠
            BigDecimal preferentialAmount = promotionActivity.getPreferentialAmount();
            build.setSalePrice(BigDecimal.ZERO.subtract(preferentialAmount).multiply(BigDecimal.valueOf(build.getCount())).setScale(2, RoundingMode.HALF_UP));
        } else if (rewardType.equals(PromotionalEnum.JIANGLI2.getKey())) {//赠送礼品
            build.setSalePrice(BigDecimal.ZERO.subtract(totalMoney));
        } else if (rewardType.equals(PromotionalEnum.JIANGLI6.getKey())) {//第N件折扣
            //获取到折扣条件
            BigDecimal discount = promotionActivity.getDiscount();
            if (discount.compareTo(BigDecimal.valueOf(10)) == 1) {//折扣大于10
                log.error("非正常的折扣条件{}", promotionActivity);
                throw new BizException("存在非正常的折扣活动");
            }
            BigDecimal divide = discount.divide(BigDecimal.valueOf(10));
            BigDecimal subtract = BigDecimal.ONE.subtract(divide);
            build.setSalePrice(BigDecimal.ZERO.subtract(totalMoney.multiply(subtract)).setScale(2,
                    RoundingMode.HALF_UP));
        } else if (rewardType.equals(PromotionalEnum.JIANGLI5.getKey())) {//套装特价
            BigDecimal setPrice =
                    promotionActivity.getSetPrice().multiply(BigDecimal.valueOf(build.getCount())).setScale(2,
                            RoundingMode.HALF_UP);
            build.setSalePrice(setPrice.subtract(totalMoney));
        } else if (rewardType.equals(PromotionalEnum.JIANGLI9.getKey())) {//整单买送
            BigDecimal moreMoney =
                    promotionActivity.getMoreMoney().multiply(BigDecimal.valueOf(build.getCount())).setScale(2,
                            RoundingMode.HALF_UP);
            if (moreMoney.compareTo(totalMoney) > -1) {//设置的买送的价格大于等于实际奖励商品的价格
                build.setSalePrice(BigDecimal.ZERO.subtract(totalMoney));
            } else if (moreMoney.compareTo(totalMoney) == -1) {//设置的买送的价格小于实际奖励商品的价格
                build.setSalePrice(BigDecimal.ZERO.subtract(moreMoney));
            }
        } else {
            log.error("未知活动奖励类型");
            throw new BizException("未知促销活动类型");
        }
        build.setProductAllMoney(build.getSalePrice());
        return build;
    }


    /**
     * @param orderProductRequests 奖励商品集合
     * @param promotionActivity    活动信息
     * @param productMap           活动区域商品
     * @param type                 0购物车1奖励商品
     * @param moneyType            0正常取价;1零售价
     * @param productType          商品类型
     * @param isMember             是否是会员标识
     * @return
     */
    @Ella(Describe = "进行取价:type 0购物车商品;1奖励商品 moneyType:0正常取价;1零售价 productType商品类型")
    private List<OrderProductResponse> fillResponse(List<OrderProductRequest> orderProductRequests, PromotionActivity promotionActivity, Map<String, ProductResponse> productMap, Integer type, Integer moneyType, Integer productType, Boolean isMember) {
        List<OrderProductResponse> collect = orderProductRequests.stream().map(orderProductRequest -> {
            String goodsBarCode = orderProductRequest.getGoodsBarCode();
            ProductResponse productResponse = productMap.get(goodsBarCode);
            OrderProductResponse build = OrderProductResponse
                    .builder()
                    .stock(productResponse.getStock())//设置库存
                    .prdName(productResponse.getPrdName())//商品名称
                    .proCount(orderProductRequest.getProCount())//商品数量
                    .prdBarCode(productResponse.getPrdBarCode())//条码
                    .goodsBarCode(productResponse.getGoodsBarCode())//编码
                    .activityId(promotionActivity.getUid())//参与活动id
                    .activityName(promotionActivity.getName())//参与活动名称
                    .isVirtual(BigInteger.ZERO.intValue())//是否是虚拟商品
                    .discernType(type)//购物车或者奖励商品类型
                    .proType(productType)//商品类型
                    .build();
            if (isMember) {//会员
                if (moneyType.equals(0)) {//正常取价
                    build.setSalePrice(productResponse.getMemberPrice());
                    build.setProductAllMoney(new BigDecimal(build.getProCount()).multiply(build.getSalePrice()));
                } else if (moneyType.equals(1)) {//取零售价
                    build.setSalePrice(productResponse.getSalePrice());
                    build.setProductAllMoney(BigDecimal.valueOf(orderProductRequest.getProCount()).multiply(build.getSalePrice()));
                } else {
                    log.error("未知取价类型");
                    throw new BizException("未知取价类型");
                }
            } else {//非会员
                build.setSalePrice(productResponse.getSalePrice());
                build.setProductAllMoney(BigDecimal.valueOf(orderProductRequest.getProCount()).multiply(build.getSalePrice()));
            }
            return build;
        }).collect(Collectors.toList());
        return collect;
    }

    private void checkActivityId(String activityId) {
        if (StringUtils.isEmpty(activityId)) {
            log.error("活动id没有传递");
            throw new BizException("活动id没有传递活动id没有传递");
        }
    }
}
