package com.ruihe.app.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.basic.CounterMapper;
import com.ruihe.app.mapper.order.PosAuthorityMapper;
import com.ruihe.app.po.basic.PosCounterPo;
import com.ruihe.app.response.PosMenuResponse;
import com.ruihe.app.service.terminal.PosMenuService;
import com.ruihe.app.vo.PosCounterVo;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.order.PosAuthorityPo;
import com.ruihe.common.dao.bean.system.SystemConfigPo;
import com.ruihe.common.dao.mapper.SystemConfigMapper;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.order.ProgramTypeEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.enums.system.SystemPosConfigEnum;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author:Fangtao
 * @Date:2019/11/6 16:17
 */
@Slf4j
@DS(DBConst.SLAVE)
@Service
@Ella(Describe = "查询柜台操作service", Author = "T")
public class QueryCounterService {
    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private PosMenuService posMenuService;

    @Autowired
    private PosAuthorityMapper posAuthorityMapper;

    @Autowired
    private SystemConfigMapper systemConfigMapper;

    public Response queryCounter(String counterName) {
        List<PosCounterPo> posCounterPosList = counterMapper.queryAll(counterName);
        if (posCounterPosList.isEmpty()) {
            return Response.errorMsg("暂无数据");
        }
        return Response.success(ObjectUtils.toList(posCounterPosList, PosCounterVo.class));
    }

    /**
     * 查询柜台的菜单控制以及补录、空退按钮控制
     *
     * @param counterId
     * @return
     */
    public Response queryCounterAuth(String counterId) {
        if(StringUtils.isBlank(counterId)){
            return Response.errorMsg("柜台id不能为空");
        }
        CounterInformation counter = counterMapper.selectById(counterId);
        List<PosMenuResponse> posMenuResponses = posMenuService.allPosMenuConf();
        Map<String, Boolean> authMap = posMenuResponses.parallelStream()
                .collect(Collectors.toMap(PosMenuResponse::getFuncCode, e -> {
                    //如果是自营
                    if (CounterEnum.SELF_SUPPORT.getKey().toString().equals(counter.getOperationalModel())) {
                        return e.getEnable() && e.getSelfOperateEnable();
                    }
                    //如果是加盟商
                    if (CounterEnum.AGENT_COUNTER.getKey().toString().equals(counter.getOperationalModel())) {
                        return e.getEnable() && e.getFranchiseEnable();
                    }
                    //其他
                    return Boolean.FALSE;
                }));
        //查询柜台补录、空退权限，不区分加盟还是直营店
        List<PosAuthorityPo> authorityList = posAuthorityMapper.queryAuthority(counter);
        Map<String, Boolean> tempAuthorityMap = authorityList.parallelStream().collect(Collectors.toMap(PosAuthorityPo::getType, e -> Boolean.TRUE, (n, o) -> o));
        //遍历枚举防止authorityList缺少元素
        Map<String, Boolean> authorityMap = Arrays.stream(ProgramTypeEnum.values())
                .collect(Collectors.toMap(ProgramTypeEnum::getCode, e -> {
                    //加盟店需要开启负库存，此处对自营门店设置为始终允许负库存
//                    if (e.getCode().equals(ProgramTypeEnum.NEGATIVE_INVENTORY.getCode()) && CounterEnum.SELF_SUPPORT.getKey().toString().equals(counter.getOperationalModel())) {
//                        return Boolean.TRUE;
//                    } else {
                       //2021-06-11 0630版本，根据产品需求，直营允许负库存也走配置，不写死
                        return tempAuthorityMap.containsKey(e.getCode());
//                    }
                }));
        //合并加盟商
        authorityMap.putAll(authMap);
        //查询权限
        List<String> msgList = Arrays.stream(SystemPosConfigEnum.values()).map(SystemPosConfigEnum::getMsg).collect(Collectors.toList());
        List<SystemConfigPo> systemConfigPoList = systemConfigMapper.selectList(Wrappers.<SystemConfigPo>lambdaQuery()
                //状态
                .eq(SystemConfigPo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                //允许状态（参数值只有0和1的情况）
                .eq(SystemConfigPo::getParamValue, CommonStatusEnum.EFFECTIVE.getCode())
                .in(SystemConfigPo::getParamKey, msgList));
        //获取权限map集合
        Map<String, Boolean> configMap = systemConfigPoList.stream().collect(Collectors.toMap(SystemConfigPo::getParamKey, e -> Boolean.TRUE, (n, o) -> o));
        //处理返回
        Map<String, Boolean> resultMap = Arrays.stream(SystemPosConfigEnum.values()).collect(Collectors.toMap(SystemPosConfigEnum::getCode, e -> configMap.containsKey(e.getMsg())));
        authorityMap.putAll(resultMap);
        return Response.success(authorityMap);
    }

    /**
     * 验证权限
     *
     * @param counterId
     * @return
     */
    public Boolean checkPermission(String counterId, ProgramTypeEnum authorityEnum) {
        CounterInformation counterInformation = counterMapper.selectById(counterId);
        Integer validAuthorityCount = posAuthorityMapper.countSpecifiedAuthority(counterInformation, authorityEnum.getCode());
        return validAuthorityCount != null && validAuthorityCount > 0;
    }
}
