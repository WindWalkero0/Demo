package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author LiangYuan
 * @date 2021-03-31 14:29
 */
@ApiModel(value = "ScheduleEmpRequest", description = "排班管理美导信息请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScheduleEmpRequest implements Serializable {

    @NotNull(message = "排班类型不能为空")
    @ApiModelProperty(value = "排班类型:0早班，1中班，2晚班")
    private Integer type;

    @NotBlank(message = "美导编号不能为空")
    @ApiModelProperty(value = "美导编号")
    private String baCode;

    @NotBlank(message = "美导姓名不能为空")
    @ApiModelProperty(value = "美导姓名")
    private String baName;
}
