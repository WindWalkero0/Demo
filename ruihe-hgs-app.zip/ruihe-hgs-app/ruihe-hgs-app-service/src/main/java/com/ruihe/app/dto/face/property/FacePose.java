package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class FacePose {

    private String pitch;
    private String roll;
    private String yam;
}
