package com.ruihe.app.response.AIProblem;

import lombok.Data;

@Data
public class MoistureOil {
    private String level;
    private String facePart;
    private String layer;
    private String image;
    private String areaRatio;//缺水面积占比
    private String description;
}
