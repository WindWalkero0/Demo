package com.ruihe.app.service.member;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.pagehelper.PageInfo;
import com.ruihe.app.event.SatEvalAppEvent;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.nursing.NursingMemberPO;
import com.ruihe.common.dao.bean.nursing.NursingRecordChildPo;
import com.ruihe.common.dao.bean.nursing.NursingRecordPO;
import com.ruihe.common.dao.mapper.NursingMemberMapper;
import com.ruihe.common.dao.mapper.NursingRecordChildMapper;
import com.ruihe.common.dao.mapper.NursingRecordMapper;
import com.ruihe.common.enums.sat.SatTypeEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.context.PosCounter;
import com.ruihe.common.pojo.context.holder.PosUserContextHolder;
import com.ruihe.common.pojo.request.member.MemberAddNursingLogRequest;
import com.ruihe.common.pojo.request.member.MemberAddNursingRequest;
import com.ruihe.common.pojo.request.member.MemberSearchNursingLogRequest;
import com.ruihe.common.pojo.request.member.NursingProductRequest;
import com.ruihe.common.pojo.response.member.MemberNursingChildResponse;
import com.ruihe.common.pojo.response.member.MemberNursingLogResponse;
import com.ruihe.common.response.Response;
import com.ruihe.common.service.ChangeService;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.TimeUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@Slf4j
public class MemberNursingLogService implements ApplicationContextAware {

    @Autowired
    private NursingRecordMapper nursingRecordMapper;

    @Autowired
    private MemberNursingService nursingService;

    @Autowired
    private NursingMemberMapper nursingMemberMapper;

    @Autowired
    private NursingRecordChildMapper nursingRecordChildMapper;

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private ChangeService changeService;

    private ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    /**
     * 新增护理记录
     *
     * @param request
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public Response addNursingLog(MemberAddNursingLogRequest request) {
        NursingMemberPO nursingMemberPO = nursingMemberMapper.selectOne(Wrappers.lambdaQuery(NursingMemberPO.class)
                .eq(NursingMemberPO::getCounterId, request.getCounterId())
                .eq(NursingMemberPO::getMemberId, request.getMemberId()));
        List<NursingProductRequest> list = request.getList();
        List<Integer> nursing = list.stream().map(NursingProductRequest::getNursingId).collect(Collectors.toList());
        JSONArray nursingArray = JSONArray.parseArray(JSON.toJSONString(nursing));
        if (nursingMemberPO == null && request.getType().equals("normal")) {
            //新增护理包会员
            List<String> nursingItem = list.stream().map(NursingProductRequest::getNursingItem).collect(Collectors.toList());
            JSONArray itemArray = JSONArray.parseArray(JSON.toJSONString(nursingItem));
            MemberAddNursingRequest build = MemberAddNursingRequest
                    .builder()
                    .baCode(request.getBaCode())
                    .baName(request.getBaName())
                    .counterId(request.getCounterId())
                    .counterName(request.getCounterName())
                    .memberId(request.getMemberId())
                    .memberName(request.getMemberName())
                    .nursingId(nursingArray)
                    .nursingItem(itemArray)
                    .phone(request.getPhone())
                    .build();
            nursingService.operationNursing(build);
            nursingMemberPO = nursingMemberMapper.selectOne(Wrappers.lambdaQuery(NursingMemberPO.class)
                    .eq(NursingMemberPO::getCounterId, request.getCounterId())
                    .eq(NursingMemberPO::getMemberId, request.getMemberId()));
        }
        //判断护理服务
        if(nursingMemberPO!=null &&  request.getType().equals("normal")){
            if (!nursingMemberPO.getNursingId().containsAll(nursingArray)) {
                throw new BizException("不允许新增护理服务");
            }
        }

        //添加护理记录
        NursingRecordPO build = NursingRecordPO
                .builder()
                .id(IdGenerator.getShorterSerialNo("NUR"))
                .baCode(request.getBaCode())
                .baName(request.getBaName())
                .counterId(request.getCounterId())
                .counterName(request.getCounterName())
                .createTime(LocalDateTime.now())
                .memberId(request.getMemberId())
                .memberName(request.getMemberName())
                .mobile(request.getPhone())
                .nursingMemberId(Objects.isNull(nursingMemberPO) ? 0 : nursingMemberPO.getId())
                .type(request.getType())
                .build();
        Integer insert = nursingRecordMapper.insert(build);
        if (insert.equals(0)) {
            throw new BizException("添加护理记录失败");
        }
        list.forEach(nursingProductRequest -> {
            //组装护理记录数据
            NursingRecordChildPo nursingRecordChildPo = NursingRecordChildPo.builder()
                    .recordId(build.getId())
                    .count(nursingProductRequest.getCount())
                    .createTime(build.getCreateTime())
                    .nursingId(nursingProductRequest.getNursingId())
                    .nursingItem(nursingProductRequest.getNursingItem())
                    .build();
            Integer insertRecordChild = nursingRecordChildMapper.insert(nursingRecordChildPo);
            if (insertRecordChild.equals(0)) {
                throw new BizException("添加记录失败");
            }
        });
        //会员满意度护理评价
        SatEvalAppEvent satEvalAppEvent = new SatEvalAppEvent(this, build.getId(), SatTypeEnum.NURSING_EVALUATION.getKey());
        applicationContext.publishEvent(satEvalAppEvent);
        return Response.successMsg("操作成功");
    }

    /**
     * 查询护理记录信息
     *
     * @param request
     * @return
     */
    public Response selectNursingLog(MemberSearchNursingLogRequest request) {
        //先查询会员
        LambdaQueryWrapper<NursingRecordPO> lambdaQueryWrapper = Wrappers.lambdaQuery(NursingRecordPO.class).orderByDesc(NursingRecordPO::getCreateTime);
        if (!StringUtils.isEmpty(request.getPhone())) {
            MemberInfo one = memberMapper.selectOne(Wrappers.lambdaQuery(MemberInfo.class).eq(MemberInfo::getMobilePhone, request.getPhone()).eq(MemberInfo::getStatus, 1));
            request.setMemberId(one == null ? null : one.getMemberId());
            lambdaQueryWrapper.eq(NursingRecordPO::getMemberId, request.getMemberId());
        }
        //护理类型
        if(!StringUtils.isEmpty(request.getType())){
            lambdaQueryWrapper.eq(NursingRecordPO::getType, request.getType());
        }
        //ba编码
        if((!StringUtils.isEmpty(request.getBaCode()))){
            lambdaQueryWrapper.eq(NursingRecordPO::getBaCode, request.getBaCode());
        }
        PosCounter counter = PosUserContextHolder.get().getCounter();
        lambdaQueryWrapper.eq(!StringUtils.isEmpty(counter) && !StringUtils.isEmpty(counter.getCounterId()), NursingRecordPO::getCounterId, counter.getCounterId());
        //时间处理
        String startTime = TimeUtils.getStartTime(request.getStartTime(), 0);
        LocalDateTime localDateStartTime = TimeUtils.getLocalDateTime(startTime);
        String endTime = TimeUtils.getEndTime(request.getEndTime(), 0);
        LocalDateTime localDateEndTime = TimeUtils.getLocalDateTime(endTime);
        if (TimeUtils.dateToStamp(startTime) > TimeUtils.dateToStamp(endTime)) {
            return Response.errorMsg("开始时间不得大于与结束时间");
        }
        if (TimeUtils.dateToStamp(endTime) > TimeUtils.dateToStamp(TimeUtils.getEndTime(TimeUtils.longFormatString(System.currentTimeMillis()), 0))) {
            return Response.errorMsg("护理结束时间不可选择大于当前日期");
        }
        lambdaQueryWrapper.ge(NursingRecordPO::getCreateTime, localDateStartTime).le(NursingRecordPO::getCreateTime, localDateEndTime);
        Page<NursingRecordPO> page = new Page<>(request.getPageNumber(), request.getPageSize());
        IPage<NursingRecordPO> pageResult = nursingRecordMapper.selectPage(page, lambdaQueryWrapper);
        List<MemberNursingLogResponse> collect = pageResult.getRecords().stream().map(o -> {
            MemberInfo memberInfo = memberMapper.selectOne(Wrappers.lambdaQuery(MemberInfo.class).eq(MemberInfo::getMemberId, o.getMemberId()));
            MemberNursingLogResponse build = MemberNursingLogResponse
                    .builder()
                    .type(o.getType())
                    .baCode(o.getBaCode())
                    .baName(o.getBaName())
                    .createTime(o.getCreateTime())
                    .id(o.getId())
                    .memberLevel(memberInfo.getMemberLevelName())
                    .memberName(o.getMemberName())
                    .mobile(o.getMobile())
                    .build();
            //获取子类
            List<MemberNursingChildResponse> memberNursingChildResponses = nursingRecordChildMapper.selectList(Wrappers.lambdaQuery(NursingRecordChildPo.class).eq(NursingRecordChildPo::getRecordId, o.getId()))
                    .stream().map(nursingRecordChildPo -> MemberNursingChildResponse
                            .builder()
                            .count(nursingRecordChildPo.getCount())
                            .nursingId(nursingRecordChildPo.getNursingId())
                            .nursingItem(nursingRecordChildPo.getNursingItem())
                            .build()).collect(Collectors.toList());
            build.setChildResponses(memberNursingChildResponses);
            return build;
        }).collect(Collectors.toList());
        //转换page对象
        PageInfo<MemberNursingLogResponse> pageInfo = new PageInfo<>(collect);
        pageInfo.setPages((int) pageResult.getPages());
        pageInfo.setSize((int) pageResult.getSize());
        pageInfo.setTotal(pageResult.getTotal());
        pageInfo.setPageNum((int) pageResult.getCurrent());
        return Response.success(pageInfo);
    }


}
