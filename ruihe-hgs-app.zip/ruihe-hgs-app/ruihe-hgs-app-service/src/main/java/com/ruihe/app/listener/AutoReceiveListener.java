package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.ruihe.app.event.AutoReceiveEvent;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.app.service.task.AppTaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;


@Slf4j
@Component
public class AutoReceiveListener {

    @Autowired
    private AppTaskService appTaskService;


    @Async(CommonConstant.POS_COUPON_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(AutoReceiveEvent event) {
        try {
            appTaskService.autoReceive();
        } catch (Exception e) {
            log.error("自动入库失败，event{}", JSON.toJSONString(event), e);
        }
    }
}
