package com.ruihe.app.service.plan.handler.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.request.plan.SalesPlanInfoQueryRequest;
import com.ruihe.app.request.plan.SalesPlanOperateRequest;
import com.ruihe.app.response.plan.SalesPlanCommonResponse;
import com.ruihe.app.service.plan.handler.SalesPlanHandler;
import com.ruihe.common.dao.bean.nursing.NursingMemberPO;
import com.ruihe.common.dao.bean.nursing.NursingRecordPO;
import com.ruihe.common.dao.bean.plan.SalesPlanPo;
import com.ruihe.common.dao.mapper.NursingMemberMapper;
import com.ruihe.common.dao.mapper.NursingRecordChildMapper;
import com.ruihe.common.dao.mapper.NursingRecordMapper;
import com.ruihe.common.enums.nursing.NursingMemberStatusEnum;
import com.ruihe.common.enums.plan.PlanObjectTypeEnum;
import com.ruihe.common.pojo.response.homepage.MemberIdAndTotalAmt;
import com.ruihe.common.pojo.response.plan.SalesPlanDetailResponse;
import com.ruihe.common.pojo.response.plan.SalesPlanInfoSimpleResponse;
import com.ruihe.common.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;


/**
 * 护理包会员-月度销售规划
 *
 * @author qubin
 * @date 2021年07月16日 14:31
 */
@Service(value = "NURSING_MEMBER")
@Slf4j
public class NursingMemberSalesPlanHandler implements SalesPlanHandler {

    @Autowired
    private NursingMemberMapper nursingMemberMapper;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private NursingRecordMapper nursingRecordMapper;

    @Autowired
    private NursingRecordChildMapper nursingRecordChildMapper;

    public static int START_DAY = 26;
    /**
     * 计算财务月，现在只能规划下一个财务月，所以是根据当前时间返回下个财务月
     * 26~25
     * 2021-07-16->return 202108
     * 2021-07-26->return 202109
     * @return java.lang.String
     * @author qubin
     * @date 2021/7/16 14:59
     */
    public static String calculateNextFinanceMonth(LocalDateTime time) {
        if(time == null){
            time = LocalDateTime.now();
        }
        int day = time.getDayOfMonth();
        if (day >= START_DAY) {
            time = time.plusMonths(2);
        }else {
            time = time.plusMonths(1);
        }
        int year = time.getYear();
        int month = time.getMonthValue();
        return year + (Integer.toString(month).length() == 2 ? Integer.toString(month) : "0" + month);
    }

    /**
     * 计算当前时间所在的财务月
     * 26~25
     * 2021-07-16->return 202107
     * 2021-07-26->return 202108
     *
     * @return java.lang.String
     * @author qubin
     * @date 2021/7/16 14:59
     */
    public static String calculateCurrentFinanceMonth(LocalDateTime time ) {
        if(time == null){
            time = LocalDateTime.now();
        }
        int day = time.getDayOfMonth();
        if (day >= START_DAY) {
            time = time.plusMonths(2);
        }
        int year = time.getYear();
        int month = time.getMonthValue();
        return year + (Integer.toString(month).length() == 2 ? Integer.toString(month) : "0" + month);
    }

    /**
     * 获取规划时间
     * 月度规划默认选每个月自然月第一天
     *
     * @return java.time.LocalDateTime
     * @author qubin
     * @date 2021/7/16 15:32
     */
    public static LocalDateTime getPlanTime() {
        String planTimeString = calculateNextFinanceMonth(LocalDateTime.now());
        int year = Integer.parseInt(planTimeString.substring(0, 4));
        int month = Integer.parseInt(planTimeString.substring(4, 6));
        return LocalDateTime.of(year, month, 1, 10, 0);
    }


    @Override
    public Response prepare(SalesPlanOperateRequest request) {
        //查询柜台护理包会员
        NursingMemberPO nursingMemberPO = nursingMemberMapper.selectOne(Wrappers.<NursingMemberPO>lambdaQuery()
                .eq(NursingMemberPO::getCounterId, request.getCounterId())
                .eq(NursingMemberPO::getMemberId, request.getMemberId()));
        if (nursingMemberPO == null) {
            return Response.errorMsg("护理包会员不存在");
        }
        if (!nursingMemberPO.getStatus().equals(NursingMemberStatusEnum.YES.getCode())) {
            return Response.errorMsg("护理包会员状态错误");
        }
        //月度护理包会员规划bizId
        String bizId = PlanObjectTypeEnum.parse(request.getPlanObjectType()) + "_" + calculateNextFinanceMonth(LocalDateTime.now()) + "_" + request.getPlanObjectId();
        return Response.success(SalesPlanCommonResponse.builder()
                .bizId(bizId)
                .planTime(getPlanTime()).build());
    }

    @Override
    public Response getBaseDetail(String planObjectId, String bizId) {
        NursingMemberPO nursingMemberPO = nursingMemberMapper.selectOne(Wrappers.<NursingMemberPO>lambdaQuery().eq(NursingMemberPO::getId, planObjectId));
        if (nursingMemberPO == null) {
            return Response.errorMsg("护理包会员不存在");
        }
        if (bizId == null) {
            return Response.errorMsg("业务id不能为空");
        }
        return Response.success(SalesPlanDetailResponse.builder()
                .counterId(nursingMemberPO.getCounterId())
                //.planTime(nursingInvitePO.getInviteTime())
//                .inviteNursingItem(nursingMemberPO.getNursingItem())
//                .inviteQty(1)
                .memberId(nursingMemberPO.getMemberId())
                .memberPhone(nursingMemberPO.getMobile())
                .bizId(bizId).build());
    }

    @Override
    public void getActAmtAndNursingItem(SalesPlanDetailResponse salesPlanDetailResponse, SalesPlanPo exitSalesPlanPo) {
        if (exitSalesPlanPo != null) {
            // 查询实际销售额
            String memberId = salesPlanDetailResponse.getMemberId();
            LocalDateTime planTime = exitSalesPlanPo.getPlanTime();
            LocalDateTime endTime = LocalDateTime.of(planTime.getYear(), planTime.getMonthValue(), START_DAY, 0, 0, 0);
            LocalDateTime startTime = endTime.minusMonths(1);
            BigDecimal actAmt = posOrderMapper.sumPayAmt(memberId, startTime, endTime);
            salesPlanDetailResponse.setActAmt(actAmt);
            //查询实际护理项目
            List<String> recordIdList = nursingRecordMapper.selectNursingRecordByMemberId(memberId, startTime, endTime);
            if (recordIdList.size() > 0) {
                List<String> nursingItemList = nursingRecordChildMapper.selectNursingItemByRecordIdList(recordIdList);
                salesPlanDetailResponse.setActNursingItem(JSONArray.parseArray(JSON.toJSONString(nursingItemList)));
            }
        }

    }

    @Override
    public void getBaseInfo(List<String> memberIdList, List<String> bizIdList, List<SalesPlanInfoSimpleResponse> salesPlanList, SalesPlanInfoQueryRequest request) {
        /**
         * 获取该柜台下面状态为确认的护理包会员
         */
        LambdaQueryWrapper<NursingMemberPO> lambdaQueryWrapper = Wrappers.lambdaQuery(NursingMemberPO.class)
                .eq(NursingMemberPO::getCounterId, request.getCounterId())
                .eq(NursingMemberPO::getStatus, NursingMemberStatusEnum.YES.getCode())
                .orderByDesc(NursingMemberPO::getCreateTime);
        if (request.getBaCode() != null) {
            lambdaQueryWrapper.eq(NursingMemberPO::getBaCode, request.getBaCode());
        }
        List<NursingMemberPO> nursingMemberPOList = nursingMemberMapper.selectList(lambdaQueryWrapper);
        if (nursingMemberPOList == null || nursingMemberPOList.size() == 0) {
            return;
        }
        nursingMemberPOList.forEach(nursingMemberPO -> {
            //会员id集合
            memberIdList.add(nursingMemberPO.getMemberId());
            //规划对象id集合
            bizIdList.add(PlanObjectTypeEnum.NURSING_MEMBER.name() + "_" + request.getPlanTime() + "_" + nursingMemberPO.getId());
            //初始化集合
            SalesPlanInfoSimpleResponse invite = SalesPlanInfoSimpleResponse.builder()
                    .memberId(nursingMemberPO.getMemberId())
                    .memberName(nursingMemberPO.getMemberName())
                    .memberPhone(nursingMemberPO.getMobile())
                    .baName(nursingMemberPO.getBaName())
                    .baCode(nursingMemberPO.getBaCode())
                    .planObjectId(nursingMemberPO.getId().toString())
                    //如果当前时间所在的财务月小于request的财务月，则允许规划
                    .buttonStatus(Integer.parseInt(calculateCurrentFinanceMonth(LocalDateTime.now())) < Integer.parseInt(request.getPlanTime()) ? 0 : 1)
                    .planObjectType(PlanObjectTypeEnum.NURSING_MEMBER.getCode())
                    .bizId(PlanObjectTypeEnum.NURSING_MEMBER.name() + "_" + request.getPlanTime() + "_" + nursingMemberPO.getId())
                    .build();
            salesPlanList.add(invite);
        });
    }

    @Override
    public Response getBatchActAmtAndNursingItem(List<String> memberIdList, SalesPlanInfoQueryRequest request, Map<String, BigDecimal> memberIdAndActAmtMap) {
        int year = Integer.parseInt(request.getPlanTime().substring(0, 4));
        int month = Integer.parseInt(request.getPlanTime().substring(4, 6));
        LocalDateTime endTime = LocalDateTime.of(year, month, START_DAY, 0, 0, 0);
        LocalDateTime startTime = endTime.minusMonths(1);
        //批量查询实际销售金额
        List<MemberIdAndTotalAmt> memberIdAndTotalAmts = posOrderMapper.sumPayAmtGroupByMemberId(memberIdList, startTime, endTime);
        memberIdAndTotalAmts.forEach(memberIdAndTotalAmt -> {
            memberIdAndActAmtMap.put(memberIdAndTotalAmt.getMemberId(), memberIdAndTotalAmt.getTotalAmt());
        });
        //查询实际护理项目
        List<NursingRecordPO> nursingRecordList = nursingRecordMapper.selectNursingRecordByMemberIdList(memberIdList, startTime, endTime);
        return Response.success(nursingRecordList);
    }
}
