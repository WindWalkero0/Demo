package com.ruihe.app.enums;

/**
 * @author luojie
 * @program ruihe-top
 * @description 库存报表查询类型枚举
 * @create: 2021/7/6 13:39
 */
public enum StockQueryTypeEnum {
    STOCK_QUERY_CATEGORY(0, "按分类"),
    STOCK_QUERY_SERIES(1, "按系列");

    private Integer code;
    private String name;

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    StockQueryTypeEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public static String getName(int code) {
        for (StockQueryTypeEnum s : StockQueryTypeEnum.values()) {
            if (s.getCode() == code) {
                return s.name();
            }
        }
        return null;
    }

    public static Integer getCode(String name) {
        for (StockQueryTypeEnum s : StockQueryTypeEnum.values()) {
            if (s.getName().equals(name)) {
                return s.code;
            }
        }
        return -1;
    }

    public static StockQueryTypeEnum getByCode(Integer code) {
        for (StockQueryTypeEnum constants : values()) {
            if (constants.getCode().equals(code)) {
                return constants;
            }
        }
        return STOCK_QUERY_CATEGORY;
    }
}
