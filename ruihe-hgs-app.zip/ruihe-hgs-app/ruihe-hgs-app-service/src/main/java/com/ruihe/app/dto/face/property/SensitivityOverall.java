package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class SensitivityOverall {
    /**
     * 敏感度面积
     */
    private String area;
    /**
     * 敏感面积占比
     */
    private String areaRatio;

    private Integer level;

}
