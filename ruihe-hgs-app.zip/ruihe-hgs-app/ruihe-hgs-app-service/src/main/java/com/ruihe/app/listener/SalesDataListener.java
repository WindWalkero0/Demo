package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Maps;
import com.ruihe.common.dao.bean.base.ChannelInfo;
import com.ruihe.common.dao.bean.home.RealTimeAccPo;
import com.ruihe.common.dao.bean.home.RealTimeSalesPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.pojo.response.homepage.AmtAndQty;
import com.ruihe.common.pojo.response.homepage.TimeSharingResponse;
import com.ruihe.common.pojo.response.homepage.TimeSharingVo;
import com.ruihe.common.pojo.response.socket.QuickReportVo;
import com.ruihe.common.pojo.response.socket.SalesChannelVo;
import com.ruihe.common.pojo.response.socket.SalesResponse;
import com.ruihe.common.pojo.response.socket.SalesVo;
import com.ruihe.common.constant.RabbitMQConst;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.enums.WebSocketUriEnum;
import com.ruihe.app.event.SalesEvent;
import com.ruihe.app.mapper.basic.ChannelMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.mapper.order.RealTimeAccMapper;
import com.ruihe.app.mapper.order.RealTimeSalesMapper;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.ws.dto.Request;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * 销售速报
 *
 * @author 梁远
 * @Description 销售速报
 * @create 2019-11-26 15:14
 */
@Slf4j
@Component
public class SalesDataListener {
    @Autowired
    private RealTimeSalesMapper realTimeSalesMapper;

    @Autowired
    private RealTimeAccMapper realTimeAccMapper;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private ChannelMapper channelMapper;


    /**
     * 0-7点，8,9。。。24进行存储
     *
     * @param event
     */
    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(SalesEvent event) {
        try {

            //获取订单信息
            PosOrderPo posOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery().eq(PosOrderPo::getOrderNo, event.getOrderNo()));
       /*
       //2020-02-18 14:10，需求改变，要求全部显示
       //如果订单的biztime和建立时间不一致，说明是补录或者空退的，不进行记录
        if (!posOrderPo.getBizTime().isEqual(posOrderPo.getCreateTime())) {
            return;
        }*/
            //如果销售类型为退库，则将金额、数量转变为负数
            if (posOrderPo.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                posOrderPo.setRealAmt(posOrderPo.getRealAmt().abs().negate());
                posOrderPo.setGoodsQty(Math.negateExact(Math.abs(posOrderPo.getGoodsQty())));
            }
            //根据时间、渠道、柜台查询是否有数据
            LocalDateTime createTime = posOrderPo.getCreateTime();
            Integer hour = createTime.getHour();
            LocalDate date = createTime.toLocalDate();
            LambdaQueryWrapper<RealTimeSalesPo> queryWrapper = Wrappers.<RealTimeSalesPo>lambdaQuery()
                    .eq(RealTimeSalesPo::getCounterChanCode, posOrderPo.getCounterChanCode())
                    .eq(RealTimeSalesPo::getCounterId, posOrderPo.getCounterId())
                    .eq(RealTimeSalesPo::getCrtTime, date);
            //对时间进行判断
            if (hour < 7) {
                queryWrapper.eq(RealTimeSalesPo::getPointTime, 0);
            } else {
                queryWrapper.eq(RealTimeSalesPo::getPointTime, hour + 1);
            }
            RealTimeSalesPo realTimeSalesPo = realTimeSalesMapper.selectOne(queryWrapper);
            //如果查询结果为空，则进行插入操作，否则进行更新操作
            if (realTimeSalesPo == null) {
                RealTimeSalesPo po = this.extractRealTimeSalesPo(posOrderPo, createTime);
                Integer rows = realTimeSalesMapper.insert(po);
                if (rows == 0) {
                    throw new BizException("插入实时销售数据失败!");
                }
            } else {
                RealTimeSalesPo po = this.extractRealTimeSalesPoUpdate(posOrderPo, createTime, realTimeSalesPo);
            /* Wrappers.<RealTimeSalesPo>lambdaUpdate()
                    .eq(RealTimeSalesPo::getCounterChanCode, posOrderPo.getCounterChanCode())
                    .eq(RealTimeSalesPo::getCounterId, posOrderPo.getCounterId())
                    .eq(RealTimeSalesPo::getCrtTime, date);*/
                Integer rows = realTimeSalesMapper.update(po, Wrappers.<RealTimeSalesPo>lambdaUpdate()
                        .eq(RealTimeSalesPo::getId, realTimeSalesPo.getId()));
                if (rows == 0) {
                    throw new BizException("插入实时销售数据失败!");
                }
            }
            //处理累积数据
            //数据查询，查询当前时间之前数据
            List<RealTimeAccPo> realTimeAccPos = realTimeAccMapper.selectList(Wrappers.<RealTimeAccPo>lambdaQuery()
                    .eq(RealTimeAccPo::getCrtTime, date));
            //如果为空，说明没有数据，进行批量插入
            if (realTimeAccPos.isEmpty()) {
                List<RealTimeAccPo> realTimeAccPoList = new ArrayList<>();
                List<Integer> list = geTimeList();
                for (Integer integer : list) {
                    realTimeAccPoList.add(RealTimeAccPo.builder()
                            .crtTime(date)
                            .pointTime(integer)
                            .amt(BigDecimal.ZERO)
                            .qty(0).build());
                }
                Integer rows = realTimeAccMapper.batchInsert(realTimeAccPoList);
                if (rows != realTimeAccPoList.size()) {
                    throw new BizException("插入数据失败");
                }
                //删除一天之前的销售记录数据
                //realTimeSalesMapper.delete(Wrappers.<RealTimeSalesPo>lambdaQuery().lt(RealTimeSalesPo::getCrtTime, date));
                //删除一天之前的累积数据
                //realTimeSalesMapper.delete(Wrappers.<RealTimeSalesPo>lambdaQuery().lt(RealTimeSalesPo::getCrtTime, date));
            }
            //如果已存在数据，则进行累计数据更新
            List<RealTimeAccPo> realTimeAccPoList = realTimeAccMapper.selectList(Wrappers.<RealTimeAccPo>lambdaQuery()
                    .eq(RealTimeAccPo::getCrtTime, date)
                    .ge(RealTimeAccPo::getPointTime, hour + 1));
            List<RealTimeAccPo> collect = realTimeAccPoList.stream().map(e ->
                    RealTimeAccPo.builder()
                            .id(e.getId())
                            .amt(e.getAmt().add(posOrderPo.getRealAmt()))
                            .qty(e.getQty() + posOrderPo.getGoodsQty()).build()
            ).collect(Collectors.toList());
            Integer rows = realTimeAccMapper.batchUpdate(collect);
            //无论更新多少条数据，此处返回的都应该是1
            if (rows == 0) {
                throw new BizException("更新数据失败");
            }
            //将销售速报发送到前端
            sendQuickReport(posOrderPo);
            //将实时销售-累计数据发送到前端
            sendRealTimeAccSales();
        } catch (Exception e) {
            log.error("销售速报处理异常，event{}", JSON.toJSONString(event), e);
        }
    }

    /**
     * 将销售速报发送到前端
     *
     * @param posOrderPo
     */
    private void sendQuickReport(PosOrderPo posOrderPo) {
        //如果销售类型为退货，则将金额、数量转变为负数
        if (posOrderPo.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
            posOrderPo.setRealAmt(posOrderPo.getRealAmt().negate());
            posOrderPo.setGoodsQty(0 - posOrderPo.getGoodsQty());
        }
        //销售速报中订单信息
        QuickReportVo quickReportVo = new QuickReportVo();
        BeanUtils.copyProperties(posOrderPo, quickReportVo);
        quickReportVo.setTotalAmt(posOrderPo.getRealAmt());
        quickReportVo.setDesc(getDesc(posOrderPo.getTransType(), posOrderPo.getOrderType(), posOrderPo.getActivityType()));
        List<QuickReportVo> orderList = new ArrayList<>();
        orderList.add(quickReportVo);
        //返回数据
        SalesResponse response = this.extractSalesResponse(orderList);

        //设置返回前端数据
        /*Request<SalesResponse> request = new Request<>();
        request.setUri(WebSocketUriEnum.SALE_REPORT_ORDER.getCode());
        request.setData(response);
        ResultVo<?> resultVo = wsClient.upTopic(request);
        if (resultVo.getCode() != 0) {
            throw new BizException("发送销售速报失败!");
        }*/
        Request<SalesResponse> request = new Request<>();
        request.setUri(WebSocketUriEnum.SALE_REPORT_ORDER.getCode());
        //request.setData(JSON.toJSONString(response));
        request.setData(response);
        rabbitTemplate.convertAndSend(RabbitMQConst.WEBSOCKET_FANOUT_EXCHANGE, "", request);
    }

    /**
     * 将实时销售-累计数据发送到前端
     */
    private void sendRealTimeAccSales() {
        //分时数据查询
        List<RealTimeAccPo> realTimeAccList = realTimeAccMapper.selectList(Wrappers.<RealTimeAccPo>lambdaQuery()
                //当天
                .eq(RealTimeAccPo::getCrtTime, LocalDate.now())
                //排序
                .orderByAsc(RealTimeAccPo::getPointTime));
        //根据前端需求，对查询出来的数据进行处理
        List<TimeSharingResponse> timeSharingResponseList = ObjectUtils.toList(realTimeAccList, TimeSharingResponse.class);
        for (TimeSharingResponse timeSharingResponse : timeSharingResponseList) {
            //判断时间---小时+1
            if (timeSharingResponse.getPointTime() > LocalDateTime.now().getHour() + 1) {
                //将金额和数量设置为空
                timeSharingResponse.setAmt(null);
                timeSharingResponse.setQty(null);
            }
        }
        //数量金额
        RealTimeAccPo realTimeAccPo = realTimeAccMapper.selectOne(Wrappers.<RealTimeAccPo>lambdaQuery()
                .eq(RealTimeAccPo::getCrtTime, LocalDate.now())
                .orderByDesc(RealTimeAccPo::getPointTime)
                //此处的last表示sql语句的最后条件
                .last(" limit 1 "));
        AmtAndQty amtAndQty = AmtAndQty.builder()
                .totalAmt(realTimeAccPo.getAmt())
                .totalQty(realTimeAccPo.getQty())
                .build();
        TimeSharingVo timeSharingVo = TimeSharingVo.builder()
                .amtAndQty(amtAndQty)
                .list(timeSharingResponseList).build();
        //设置返回前端数据
        /*Request<TimeSharingVo> requestAcc = new Request<>();
        requestAcc.setUri(WebSocketUriEnum.SALE_REPORT_ACC.getCode());
        requestAcc.setData(timeSharingVo);
        ResultVo<?> vo = wsClient.upTopic(requestAcc);
        if (vo.getCode() != 0) {
            throw new BizException("发送实时销售-累计失败!");
        }*/
        Request<TimeSharingVo> requestAcc = new Request<>();
        requestAcc.setUri(WebSocketUriEnum.SALE_REPORT_ACC.getCode());
        //requestAcc.setData(JSON.toJSONString(timeSharingVo));
        requestAcc.setData(timeSharingVo);
        rabbitTemplate.convertAndSend(RabbitMQConst.WEBSOCKET_FANOUT_EXCHANGE, "", requestAcc);
    }

    /**
     * 获取时间列表
     *
     * @return
     */
    private List<Integer> geTimeList() {
        List<Integer> list = IntStream.rangeClosed(8, 24).boxed().collect(Collectors.toList());
        list.add(BigInteger.ZERO.intValue(), BigInteger.ZERO.intValue());
        return list;
        /*List<Integer> list = new ArrayList<>();
        list.add(0);
        for (int i = 8; i <= 24; i++) {
            list.add(i);
        }
        return list;*/
    }

    /**
     * 构建实时销售数据更新
     *
     * @param posOrderPo
     * @param createTime
     * @param realTimeSalesPo
     * @return
     */
    private RealTimeSalesPo extractRealTimeSalesPoUpdate(PosOrderPo posOrderPo, LocalDateTime createTime, RealTimeSalesPo realTimeSalesPo) {
        return RealTimeSalesPo.builder()
                .amt(posOrderPo.getRealAmt().add(realTimeSalesPo.getAmt()))
                .qty(posOrderPo.getGoodsQty() + realTimeSalesPo.getQty())
                .build();
    }

    /**
     * 构建新增的数据
     *
     * @param posOrderPo
     * @param createTime
     * @return
     */
    private RealTimeSalesPo extractRealTimeSalesPo(PosOrderPo posOrderPo, LocalDateTime createTime) {
        RealTimeSalesPo po = RealTimeSalesPo.builder()
                .counterChanCode(posOrderPo.getCounterChanCode())
                .counterChanName(posOrderPo.getCounterChanName())
                .counterId(posOrderPo.getCounterId())
                .counterName(posOrderPo.getCounterName())
                .amt(posOrderPo.getRealAmt())
                .qty(posOrderPo.getGoodsQty())
                .crtTime(createTime.toLocalDate())
                .build();
        //判断时间问题
        if (createTime.getHour() < 7) {
            po.setPointTime(0);
        } else {
            po.setPointTime(createTime.getHour() + 1);
        }
        return po;
    }

    /**
     * 构建返回前端的数据
     *
     * @param orderList
     * @return
     */
    private SalesResponse extractSalesResponse(List<QuickReportVo> orderList) {
        //查询当天所有的订单信息总金额和总数
        SalesVo salesVo = realTimeSalesMapper.getSalesVo(LocalDate.now());
        //渠道信息
        List<ChannelInfo> infoList = channelMapper.selectList(Wrappers.<ChannelInfo>lambdaQuery().eq(ChannelInfo::getIsDel, 0));
        //获取当天订单中各个渠道的总金额和总数
        List<Map<String, Object>> amtList = realTimeSalesMapper.queryAmt(LocalDate.now());
        List<Map<String, Object>> qtyList = realTimeSalesMapper.queryQty(LocalDate.now());
        //返回前端的渠道信息
        List<SalesChannelVo> voList = infoList.stream().map(e -> {
            SalesChannelVo vo = SalesChannelVo.builder()
                    .counterChanCode(e.getChannelCode())
                    .counterChanName(e.getChannelName())
                    .build();
            return vo;
        }).collect(Collectors.toList());
        //获取各个渠道总金额
        if (amtList != null && amtList.size() > 0) {
            Map<String, BigDecimal> amtMap = amtList.stream().map(e -> {
                HashMap<String, BigDecimal> map = Maps.newHashMap();
                map.put((String) e.get("counterChanCode"), (BigDecimal) e.get("amt"));
                return map;
            }).flatMap(e -> e.entrySet().stream()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
            voList.forEach(e -> {
                BigDecimal amt = amtMap.get(e.getCounterChanCode());
                if (amt != null) {
                    e.setAmt(amt);
                }
            });
        }
        //获取各个渠道总数量
        if (qtyList != null && qtyList.size() > 0) {
            Map<String, Integer> qtyMap = qtyList.stream().map(e -> {
                HashMap<String, Integer> map = Maps.newHashMap();
                map.put((String) e.get("counterChanCode"), ((BigDecimal) e.get("qty")).intValue());
                return map;
            }).flatMap(e -> e.entrySet().stream()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
            voList.forEach(e -> {
                Integer integer = qtyMap.get(e.getCounterChanCode());
                if (integer != null) {
                    e.setQty(integer);
                }
            });
        }
        SalesResponse salesResponse = SalesResponse.builder()
                .orderList(orderList)
                .channelList(voList)
                .build();
        if (salesVo == null) {
            salesResponse.setTotalAmt(BigDecimal.ZERO);
            salesResponse.setTotalQty(0);
        } else {
            salesResponse.setTotalQty(salesVo.getTotalQty());
            salesResponse.setTotalAmt(salesVo.getTotalAmt());
        }
        return salesResponse;
    }

    /**
     * 展示销售类型
     *
     * @param transType
     * @param orderType
     * @param activityType
     * @return
     */
    private String getDesc(Integer transType, Integer orderType, Integer activityType) {
        if (!transType.equals(OrderTransTypeEnum.GOODS_OUT.getCode()) && !transType.equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
            return null;
        }
        if (transType.equals(OrderTransTypeEnum.GOODS_OUT.getCode())) {
            if (activityType != null && activityType.equals(0)) {
                return "积分兑换";
            } else if (orderType != null && (orderType.equals(1) || orderType.equals(2))) {
                return "销售";
            }
        } else {
            if (activityType != null && activityType.equals(0)) {
                return "积分兑换退货";
            } else if (orderType != null && (orderType.equals(1) || orderType.equals(2))) {
                return "销售退货";
            }
        }
        return null;
    }
}
