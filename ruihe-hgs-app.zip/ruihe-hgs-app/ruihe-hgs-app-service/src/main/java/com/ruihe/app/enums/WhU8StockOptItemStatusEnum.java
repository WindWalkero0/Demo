package com.ruihe.app.enums;

/**
 * @Description U8系统库存变动操作
 * @author 梁远
 * @create 2019-10-17 15:14
 */
public enum WhU8StockOptItemStatusEnum {
    //同步U8状态,0初始化,1成功,2失败,3异常/超时
    //初始化
    INITIALIZE(0, "初始化"),
    //成功
    SUCCESS(1, "成功"),
    //失败
    FAIL(2, "失败"),
    //异常/超时
    OVERTIME(3, "异常/超时");
    private Integer code;
    private String msg;


    WhU8StockOptItemStatusEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
