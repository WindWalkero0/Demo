package com.ruihe.app.service.member;

import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.pagehelper.PageInfo;
import com.ruihe.app.mapper.plan.SalesPlanMapper;
import com.ruihe.app.response.NurInvandSalesPlanResponse;
import com.ruihe.app.service.wx.WxReserveRegisterService;
import com.ruihe.app.vo.WhStockDownVo;
import com.ruihe.common.dao.bean.nursing.NursingInvitePO;
import com.ruihe.common.dao.bean.plan.SalesPlanPo;
import com.ruihe.common.dao.bean.system.PosScheduleEmpPo;
import com.ruihe.common.dao.bean.system.PosSchedulePo;
import com.ruihe.common.dao.mapper.NursingInviteMapper;
import com.ruihe.common.dao.mapper.system.PosScheduleMapper;
import com.ruihe.common.enums.nursing.NursingInviteStatusEnum;
import com.ruihe.common.enums.plan.PlanObjectTypeEnum;
import com.ruihe.common.enums.rabbit.ListenerServiceEnum;
import com.ruihe.common.pojo.request.member.NursingInviteAddRequest;
import com.ruihe.common.pojo.request.member.NursingInviteQueryRequest;
import com.ruihe.common.pojo.response.member.NursingInviteResponse;
import com.ruihe.common.pojo.response.nursing.NursingInviteTimeRes;
import com.ruihe.common.response.Response;
import com.ruihe.common.service.rabbitmq.CustomMessage;
import com.ruihe.common.service.rabbitmq.RabbitmqClient;
import com.ruihe.common.utils.IdGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author fly
 */
@Service
@Slf4j
public class NursingInviteService {

    private final NursingInviteMapper nursingInviteMapper;

    private final PosScheduleMapper posScheduleMapper;

    private final WxReserveRegisterService wxReserveRegisterService;

    private final RabbitmqClient rabbitmqClient;

    private final SalesPlanMapper salesPlanMapper;


    public NursingInviteService(NursingInviteMapper nursingInviteMapper,
                                PosScheduleMapper posScheduleMapper,
                                WxReserveRegisterService wxReserveRegisterService,
                                RabbitmqClient rabbitmqClient,
                                SalesPlanMapper salesPlanMapper) {
        this.nursingInviteMapper = nursingInviteMapper;
        this.posScheduleMapper = posScheduleMapper;
        this.wxReserveRegisterService = wxReserveRegisterService;
        this.rabbitmqClient = rabbitmqClient;
        this.salesPlanMapper = salesPlanMapper;
    }

    /**
     * 新增护理邀约
     */
    @Transactional(rollbackFor = Exception.class)
    public Response addNursing(NursingInviteAddRequest request) {
        String invId = IdGenerator.getShorterSerialNo("INV");
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime parse = LocalDateTime.parse(request.getInviteTime(), dtf);
        if (parse.isBefore(LocalDateTime.now())) {
            return Response.errorMsg("预约时间不得晚于当前时间！");
        }
        //2021年4月8日14:32:23  当天同手机号只能一次
        List<NursingInvitePO> nursingInvitePOS = nursingInviteMapper.selectList(Wrappers.<NursingInvitePO>lambdaQuery()
                .gt(NursingInvitePO::getInviteTime, parse.toLocalDate())
                .lt(NursingInvitePO::getInviteTime, parse.toLocalDate().plusDays(1))
                .in(NursingInvitePO::getNursingStatus, NursingInviteStatusEnum.INVITED.getCode(), NursingInviteStatusEnum.COMPLETE.getCode())
                .eq(NursingInvitePO::getPhone, request.getPhone()));
        if (nursingInvitePOS != null && nursingInvitePOS.size() > 0) {
            return Response.errorMsg("一个手机号当天只能预约一次！");
        }
        NursingInvitePO build = NursingInvitePO.builder()
                .baCode(request.getBaCode())
                .baName(request.getBaName())
                .counterId(request.getCounterId())
                .counterName(request.getCounterName())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .inviteId(invId)
                .inviteQty(request.getNursingQty())
                .inviteTime(parse)
                .nursingId(request.getNursingId() == null ? JSONArray.parseArray("[]") : request.getNursingId())
                .nursingStatus(NursingInviteStatusEnum.INVITED.getCode())
                .nursingItem(request.getNursingItem() == null ? JSONArray.parseArray("[]") : request.getNursingItem())
                .phone(request.getPhone())
                .inviteType(request.getNursingType())
                .memberId(request.getMemberId())
                .memberName(request.getMemberName())
                .remark(request.getRemark())
                .build();
        int insert = nursingInviteMapper.insert(build);
        if (insert > 0) {
            Duration between = Duration.between(LocalDateTime.now(), build.getInviteTime().plusHours(1));
            CustomMessage cm = CustomMessage.builder()
                    .serviceName(ListenerServiceEnum.NURSING_INVITE.getName())
                    .bizNo(build.getInviteId())
                    .build();
            rabbitmqClient.produce(cm, (int) between.toMillis());
            return Response.successDataMsg(invId, "提交成功");
        }
        return Response.errorMsg("提交错误，请联系管理员");
    }

    /**
     * 编辑护理包邀约信息
     */
    @Transactional(rollbackFor = Exception.class)
    public Response editNursing(NursingInviteAddRequest request) {
        //判断是否已经存在
        NursingInvitePO nursingInvitePO = nursingInviteMapper.selectById(request.getInviteId());
        if (nursingInvitePO == null) {
            return Response.errorMsg("不存在的任务！");
        }
        //2021年4月15日09:05:15 已完成 已预约的都可以编辑  只有已取消的不能修改
        if (nursingInvitePO.getNursingStatus().equals(NursingInviteStatusEnum.CANCEL.getCode())) {
            return Response.errorMsg("完成任务无法操作！");
        }
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime parse = LocalDateTime.parse(request.getInviteTime(), dtf);
        if (parse.isBefore(LocalDateTime.now())) {
            return Response.errorMsg("预约时间不得晚于当前时间！");
        }
        NursingInvitePO build = NursingInvitePO.builder()
                .baCode(request.getBaCode())
                .baName(request.getBaName())
                .counterId(request.getCounterId())
                .counterName(request.getCounterName())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .inviteId(request.getInviteId())
                .inviteQty(request.getNursingQty())
                .inviteTime(parse)
                .nursingId(request.getNursingId())
                .nursingStatus(NursingInviteStatusEnum.INVITED.getCode())
                .nursingItem(request.getNursingItem())
                .phone(request.getPhone())
                .inviteType(request.getNursingType())
                .memberId(request.getMemberId())
                .memberName(request.getMemberName())
                .remark(request.getRemark())
                .build();
        int update = nursingInviteMapper.updateById(build);
        if (update > 0) {
            Duration between = Duration.between(LocalDateTime.now(), build.getInviteTime().plusHours(1));
            CustomMessage cm = CustomMessage.builder()
                    .serviceName(ListenerServiceEnum.NURSING_INVITE.getName())
                    .bizNo(build.getInviteId())
                    .build();
            rabbitmqClient.produce(cm, (int) between.toMillis());
            return Response.successMsg("更新成功");
        }
        return Response.errorMsg("更新失败，请联系管理员");
    }


    /**
     * 查询护理邀约记录
     *
     * @param request
     * @return
     */
    public Response queryNursingInv(NursingInviteQueryRequest request) {
        //判断是否展示这个参数存在
        if (request.getStatus() == null) {
            return Response.errorMsg("传参不能为空");
        }
        LambdaQueryWrapper<NursingInvitePO> lambdaQueryWrapper = Wrappers.lambdaQuery(NursingInvitePO.class).eq(NursingInvitePO::getCounterId, request.getCounterId());
        if ((!StringUtils.isEmpty(request.getBaCode()))) {
            lambdaQueryWrapper.eq(NursingInvitePO::getBaCode, request.getBaCode());
        }
        if ((!StringUtils.isEmpty(request.getInviteStatus()))) {
            lambdaQueryWrapper.eq(NursingInvitePO::getNursingStatus, request.getInviteStatus());
        }
        if ((!StringUtils.isEmpty(request.getPhone()))) {
            lambdaQueryWrapper.and(wrapper -> wrapper.like(NursingInvitePO::getPhone, request.getPhone()).or().like(NursingInvitePO::getPhone, request.getPhone()));
        }
        if ((!StringUtils.isEmpty(request.getInviteTime()))) {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime time = LocalDate.parse(request.getInviteTime(), dtf).atTime(0, 0, 0);
            lambdaQueryWrapper.ge(NursingInvitePO::getInviteTime, time);
            lambdaQueryWrapper.lt(NursingInvitePO::getInviteTime, time.plusDays(1));
        }
        lambdaQueryWrapper.orderByAsc(NursingInvitePO::getInviteTime);
        Page<NursingInvitePO> page = new Page<>(request.getPageNumber(), request.getPageSize());
        IPage<NursingInvitePO> pageResult = nursingInviteMapper.selectPage(page, lambdaQueryWrapper);
        List<NurInvandSalesPlanResponse> list = new ArrayList<>();
        //查询人数总数
        BigDecimal sum = nursingInviteMapper.selectSum(request);
        List<String> timesList = new ArrayList<>();
        //获取美导上班时间列表
        if (baTimeList(request.getInviteTime(), request.getCounterId(), request.getBaCode()).getData() == null) {
            return Response.successDataMsg(List.of(), baTimeList(request.getInviteTime(), request.getCounterId(), request.getBaCode()).getMsg());
        }
        List<String> baTimesList = (List<String>) baTimeList(request.getInviteTime(), request.getCounterId(), request.getBaCode()).getData();
        timesList = baTimesList.stream().map(e ->
                request.getInviteTime() + " " + e + ":00"
        ).collect(Collectors.toList());
        if (!pageResult.getRecords().isEmpty()) {
            List<String> inviteIdList = pageResult.getRecords().stream().map(NursingInvitePO::getInviteId).collect(Collectors.toList());
            List<SalesPlanPo> SalesPlanPos = salesPlanMapper.selectPlanRecord(inviteIdList);
            Map<String, SalesPlanPo> salesPlanMap = SalesPlanPos.stream().collect(Collectors.toMap(SalesPlanPo::getPlanObjectId, e -> e));
            list = pageResult.getRecords().stream().map(e -> {
                NurInvandSalesPlanResponse nurInvandSalesPlanResponse = new NurInvandSalesPlanResponse();
                BeanUtils.copyProperties(e, nurInvandSalesPlanResponse);
                if (salesPlanMap.get(e.getInviteId()) != null) {
                    nurInvandSalesPlanResponse.setPlanNursingId(salesPlanMap.get(e.getInviteId()).getPlanNursingId());
                    nurInvandSalesPlanResponse.setPlanNursingItem(salesPlanMap.get(e.getInviteId()).getPlanNursingItem());
                    nurInvandSalesPlanResponse.setPlanAmt(salesPlanMap.get(e.getInviteId()).getPlanAmt());
                }
                return nurInvandSalesPlanResponse;
            }).collect(Collectors.toList());
            if (request.getStatus()) {
                DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                List<String> lists = pageResult.getRecords().stream().map(e ->
                        df.format(e.getInviteTime())
                ).collect(Collectors.toList());
                for (int i = 0; i < timesList.size(); i++) {
                    NurInvandSalesPlanResponse nurInvandSalesPlanResponse = new NurInvandSalesPlanResponse();
                    if (!lists.contains(timesList.get(i))) {
                        nurInvandSalesPlanResponse.setInviteTime(LocalDateTime.parse(timesList.get(i), df));
                        list.add(nurInvandSalesPlanResponse);
                    }
                }
            }
        }
        if (pageResult.getRecords().isEmpty() && request.getStatus()) {
            for (int i = 0; i < timesList.size(); i++) {
                NurInvandSalesPlanResponse nurInvandSalesPlanResponse = new NurInvandSalesPlanResponse();
                DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                nurInvandSalesPlanResponse.setInviteTime(LocalDateTime.parse(timesList.get(i), df));
                list.add(nurInvandSalesPlanResponse);
            }
        }
        List<NurInvandSalesPlanResponse> collot = list.stream().sorted(Comparator.comparing(NurInvandSalesPlanResponse::getInviteTime)).collect(Collectors.toList());
        PageInfo<NurInvandSalesPlanResponse> pageInfo = new PageInfo<>(collot);
        pageInfo.setPages((int) pageResult.getPages());
        pageInfo.setSize((int) pageResult.getSize());
        pageInfo.setTotal(pageResult.getTotal());
        pageInfo.setPageNum((int) pageResult.getCurrent());
        Map<String, Object> map = new HashMap<>();
        map.put("pageInfo", pageInfo);
        map.put("sum", sum);
        map.put("count", pageInfo.getTotal());
        return Response.success(map);
    }

    /**
     * 更新邀约
     *
     * @param inviteId,status
     * @return
     */
    public Response updateNursingInv(String inviteId, Integer status) {
        NursingInvitePO nursingInvitePO = nursingInviteMapper.selectById(inviteId);
        if (nursingInvitePO == null) {
            return Response.errorMsg("不存在的任务！");
        }
        if (nursingInvitePO.getNursingStatus().equals(status)) {
            return Response.errorMsg("请勿重复操作！");
        }
        if (nursingInvitePO.getNursingStatus().equals(NursingInviteStatusEnum.COMPLETE.getCode())) {
            return Response.errorMsg("完成任务无法操作！");
        }
        if (!status.equals(NursingInviteStatusEnum.COMPLETE.getCode()) && !status.equals(NursingInviteStatusEnum.CANCEL.getCode())) {
            return Response.errorMsg("未知的状态！");
        }
        NursingInvitePO build = NursingInvitePO.builder().inviteId(inviteId).nursingStatus(status).updateTime(LocalDateTime.now()).build();
        int update = nursingInviteMapper.updateById(build);
        if (update > 0) {
            return Response.successMsg("操作成功！");
        }
        return Response.errorMsg("操作失败！请联系管理员");
    }

    /**
     * 按时间分组
     * 这边拼完给安卓
     *
     * @param inviteTime
     * @return
     */
    public Response queryGroup(String inviteTime, String counterId, String baCode) {
        List<NursingInviteTimeRes> nursingInviteTimeRes = nursingInviteMapper.queryGroup(inviteTime, counterId, baCode);
        Map<String, Integer> collect = nursingInviteTimeRes.stream().collect(Collectors.toMap(NursingInviteTimeRes::getInviteTime, NursingInviteTimeRes::getCount));
        if (baTimeList(inviteTime, counterId, baCode).getData() == null) {
            return Response.successDataMsg(List.of(), baTimeList(inviteTime, counterId, baCode).getMsg());
        }
        List<String> baTimesList = (List<String>) baTimeList(inviteTime, counterId, baCode).getData();

        if (baTimesList.isEmpty()) {
            return Response.successDataMsg(List.of(), baTimeList(inviteTime, counterId, baCode).getMsg());
        }
        List<NursingInviteTimeRes> list = new ArrayList<>();
        for (int i = 0; i < baTimesList.size(); i++) {
            NursingInviteTimeRes build0 = NursingInviteTimeRes.builder().inviteTime(baTimesList.get(i)).build();
            build0.setCount(collect.getOrDefault(baTimesList.get(i), 0));
            list.add(build0);
        }
        return Response.success(list);
    }

    /**
     * 带不进去当前时间的预约总人数
     *
     * @param inviteTime
     * @param baCode
     * @return
     */
    public Response querySum(String inviteTime, String baCode) {
        if (baCode.isEmpty()) {
            return Response.success(0);
        }
        int sum = nursingInviteMapper.querySum(inviteTime, baCode);
        return Response.success(sum);
    }

    public Response baTimeList(String inviteTime, String counterId, String baCode) {
        List<String> baTimesList;
        //判断该柜台是否排班计划
        PosSchedulePo posSchedulePo = posScheduleMapper.selectOne(Wrappers.<PosSchedulePo>lambdaQuery()
                .eq(PosSchedulePo::getCounterId, counterId)
                .eq(PosSchedulePo::getScheduleMonth, inviteTime.substring(0, 7)));
        if (posSchedulePo == null) {
            return Response.successDataMsg(List.of(), "该柜台没有排班");
        }
        String sid = posSchedulePo.getId();
        int scheduleDay = wxReserveRegisterService.getDay(inviteTime);
        List<PosScheduleEmpPo> posScheduleEmpPo = wxReserveRegisterService.getPosScheduleEmpList(sid, scheduleDay, baCode);
        if (posScheduleEmpPo.isEmpty()) {
            return Response.successDataMsg(List.of(), "该美导没有排班");
        } else {
            //获取美导开始上班时间和结束时间
            LocalDate resInviteTime = LocalDate.parse(inviteTime);
            String weekDay = wxReserveRegisterService.getWeekDay(resInviteTime);
            List<String> empTimes = wxReserveRegisterService.getDbTimes(posScheduleEmpPo, weekDay, counterId);
            if (empTimes.isEmpty()) {
                return Response.successDataMsg(List.of(), String.format("该柜台%s日没排班或未设置排班时间", resInviteTime.toString()));
            }
            //获取美导上班的所有时间列表
            baTimesList = getBaTimesList(empTimes);
        }
        return Response.success(baTimesList);
    }

    //获取美导上班的所有时间列表
    private List<String> getBaTimesList(List<String> list) {
        //初始预约列表
        List<String> timeList = List.of("6:00", "6:30", "7:00", "7:30", "8:00", "8:30", "9:00", "9:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30");
        int startTime = Integer.parseInt(list.get(0).replaceAll(":", ""));
        int endTime = Integer.parseInt(list.get(list.size() - 1).replaceAll(":", ""));
        List<String> baTimesList = new ArrayList<>();
        List<String> resBaTimesList = new ArrayList<>();
        int startMark = 0;
        int endMark = 32;
        if (startTime > 600) {
            startMark = timeList.indexOf(list.get(0));
        }
        if (endTime < 2130) {
            endMark = timeList.indexOf(list.get(list.size() - 1)) + 1;
        }
        baTimesList = timeList.subList(startMark, endMark);
        for (int i = 0; i < baTimesList.size(); i++) {
            if (baTimesList.get(i).length() == 4) {
                resBaTimesList.add("0" + baTimesList.get(i));
                continue;
            }
            resBaTimesList.add(baTimesList.get(i));
        }
        return resBaTimesList;
    }

}
