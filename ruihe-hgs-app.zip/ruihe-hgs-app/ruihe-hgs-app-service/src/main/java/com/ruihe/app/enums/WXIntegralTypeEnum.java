package com.ruihe.app.enums;

/**
 * @author LiangYuan
 * @Description
 * @create 2020-09-18 17:24
 */
public enum WXIntegralTypeEnum {
    /**
     * 获取：0，支出：1
     **/
    GAIN(0, "获取"),
    EXPENDITURE(1, "支出"),
    ;

    private Integer code;
    private String msg;


    WXIntegralTypeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
