package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.ruihe.app.event.CancelAndAddCouponEvent;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.service.MemberCouponSingleOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

/**
 * @author 梁远
 * @Description 会员根据订单记录进行会员优惠券处理
 * @create 2020-05-29 11:37
 */
@Slf4j
@Component
public class CancelAndAddCouponListener {

    @Autowired
    private CustomService customService;

    @Autowired
    private MemberCouponSingleOperation memberCouponSingleOperation;


    @Async(CommonConstant.POS_COUPON_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(CancelAndAddCouponEvent event) {
        try {
            log.info("========开始取消会员相关优惠券========");
            log.info("========开始取消会员相关优惠券========");
            log.info("========开始取消会员相关优惠券========");
            memberCouponSingleOperation.cancelMemberCoupon(event.getMemberId());
            log.info("========触发单个会员补发优惠券操作========");
            log.info("========触发单个会员补发优惠券操作========");
            log.info("========触发单个会员补发优惠券操作========");
            MemberInfo memberInfo = customService.select(MemberInfo.builder().memberId(event.getMemberId()).build());
            memberCouponSingleOperation.reprocessCoupon(memberInfo);
        } catch (Exception e) {
            log.error("处理会员优惠券异常，event{}", JSON.toJSONString(event), e);
        }
    }
}
