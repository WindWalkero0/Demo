package com.ruihe.app.service.integral;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderItemPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.enums.activity.ActivityTypeEnum;
import com.ruihe.common.enums.integral.IntegralBizTypeEnum;
import com.ruihe.common.enums.integral.IntegralTypeEnum;
import com.ruihe.app.enums.OrderNoPrefixEnum;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.event.Integral4OrderEvent;
import com.ruihe.app.event.IntegralQuickReportEvent;
import com.ruihe.common.dao.mapper.integral.IntegralAccountMapper;
import com.ruihe.common.dao.mapper.integral.IntegralOrderItemMapper;
import com.ruihe.common.dao.mapper.integral.IntegralOrderMapper;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.utils.IdGenerator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.MutableTriple;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 积分服务
 *
 * @author William
 */
@Service
@Slf4j
public class IntegralService implements ApplicationContextAware {
    @Autowired
    private IntegralOrderMapper integralOrderMapper;

    @Autowired
    private IntegralOrderItemMapper integralOrderItemMapper;

    @Autowired
    private IntegralAccountMapper integralAccountMapper;

    @Autowired
    private IntegralLogService integralLogService;

    private ApplicationContext applicationContext;

    public static final LocalDateTime expireTime = LocalDateTime.of(2022, 4, 1, 0, 0, 0);

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    /**
     * 会员积分操作，场景有【正常销售、预订单、积分兑换】交易类型是“出货”，空退业务
     *
     * @param triple
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void changeBalance(MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> triple) {
        int rows = integralOrderMapper.insert(triple.getLeft());
        if (rows == 0) {
            log.error("积分订单主表插入失败,data={}", triple.getLeft());
            throw new BizException("积分订单主表插入失败");
        }
        //设置子表的integralOrderId
        triple.getMiddle().forEach(e -> e.setIntegralOrderId(triple.getLeft().getIntegralOrderId()));
        rows = integralOrderItemMapper.batchInsert(triple.getMiddle());
        if (rows != triple.getMiddle().size()) {
            log.error("积分订单主表插入失败,data={}", triple.getMiddle());
            throw new BizException("积分订单主表插入失败");
        }
        IntegralAccountPo account = integralAccountMapper.selectById(triple.getLeft().getMemberId());
        if (account == null) {
            rows = integralAccountMapper.insert(triple.getRight());
        } else {
            Integer exchQty = Math.abs(triple.getLeft().getPaidQty());
            // 如果消费的积分大于老积分就是用的新积分 如果消费的积分小于老积分就是用的老积分
            // 2021年3月22日15:53:38  有问题   应该是用积分活动来判断使用的积分类型
//            Boolean flagUse = account.getOldQty() >= exchQty;
            Boolean flagUse = integralLogService.getUsingType(triple.getLeft().getBizNo());
            Boolean flag = integralLogService.getInteType(triple.getLeft().getBizTime()) == 0;
            rows = integralAccountMapper.changeBalance(triple.getLeft().getMemberId(), triple.getLeft().getGainQty(), exchQty, triple.getRight().getNextExpireTime(), flag, flagUse);
        }
        if (rows == 0) {
            log.error("【销售积分积累】积分订单主表插入失败or积分更新失败,data={}", triple.getMiddle());
            throw new BizException("【销售积分积累】积分订单主表插入失败or积分更新失败");
        }
        //发射积分事件
        this.publishEvent(triple.getLeft());
    }

    /**
     * 会员首页积分速报事件,只推送销售和积分兑换两种类型
     *
     * @param order
     */
    private void publishEvent(IntegralOrderPo order) {
        //回写pos_order积分数据
        applicationContext.publishEvent(new Integral4OrderEvent(this, order.getIntegralOrderId()));
        //推送websocket
        if (IntegralBizTypeEnum.SALE.getCode().equals(order.getBizType()) ||
                IntegralBizTypeEnum.INTEGRAL_EXCH.getCode().equals(order.getBizType())) {
            applicationContext.publishEvent(new IntegralQuickReportEvent(this, order.getIntegralOrderId()));
        }
    }

    /**
     * 退货退还积分,场景有【销售退货/预订单取消/积分兑换退货】
     * 空退还要走积分规则引擎
     *
     * @param orderPo
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void changeBalance(PosOrderPo orderPo) {
        //如果不是空退，整单退货
        if (StringUtils.isBlank(orderPo.getPreOrderNo())) {
            return;
        }
        //根据退货产品列表采出原订单的积分明细
        List<IntegralOrderItemPo> integralOrderItemList = integralOrderItemMapper.selectList(Wrappers.<IntegralOrderItemPo>lambdaQuery()
                .eq(IntegralOrderItemPo::getBizNo, orderPo.getPreOrderNo())
                .eq(IntegralOrderItemPo::getMemberId, orderPo.getMemberId()));
        IntegralOrderPo integralOrderPo = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery()
                .eq(IntegralOrderPo::getBizNo, orderPo.getPreOrderNo())
                .eq(IntegralOrderPo::getMemberId, orderPo.getMemberId()));
        //积分兑换应付积分,为正数
        Integer paidQty = Math.abs(integralOrderPo.getPaidQty());
        //返还总积分,为负
        Integer gainQty = -Math.abs(integralOrderPo.getGainQty());
        //总退货积分
        Integer totalQty = paidQty + gainQty;
        IntegralOrderPo order = IntegralOrderPo.builder()
                .memberId(orderPo.getMemberId())
                .memberName(orderPo.getMemberName())
                .memberPhone(orderPo.getMemberPhone())
                .counterId(orderPo.getCounterId())
                .counterName(orderPo.getCounterName())
                .bizType(this.extractBizType4Return(orderPo))
                .bizNo(orderPo.getOrderNo())
                .bizTime(orderPo.getBizTime())
                .bizRelationNo(orderPo.getPreOrderNo())
                .bizQty(orderPo.getGoodsQty())
                .bizAmt(orderPo.getRealAmt())
                .baCode(orderPo.getBaCode())
                .baName(orderPo.getBaName())
                .paidQty(paidQty)
                .gainQty(gainQty)
                .integralQty(totalQty)
                .inteType(integralOrderPo.getInteType())
                .surplusQty(0)
                .createTime(LocalDateTime.now())
                .build();
        int rows = integralOrderMapper.insert(order);
        if (rows == 0) {
            log.error("积分订单主表插入失败,order={}", order);
            throw new BizException("积分订单主表插入失败");
        }
        integralOrderItemList.forEach(e -> {
            e.setIntegralItemId(null);
            e.setIntegralOrderId(order.getIntegralOrderId());
            e.setBizType(this.extractBizType4Return(orderPo));
            e.setBizNo(orderPo.getOrderNo());
            e.setBizRelationNo(orderPo.getPreOrderNo());
            e.setIntegralType(this.extractIntegralType4Return(orderPo));
            e.setIntegralQty(Math.negateExact(e.getIntegralQty()));
            e.setBizItemQty(e.getBizItemQty());
            e.setBizItemAmt(e.getBizItemAmt());
            e.setDiscountAmt(e.getDiscountAmt());
            e.setActivityRuleDesc("关联退货对冲；" + e.getActivityRuleDesc());
            e.setCreateTime(LocalDateTime.now());
            e.setUpdateTime(LocalDateTime.now());
        });
        //批量插入退货积分订单明细
        rows = integralOrderItemMapper.batchInsert(integralOrderItemList);
        if (rows != integralOrderItemList.size()) {
            log.error("积分订单主表插入失败,size={},rows={}", integralOrderItemList, rows);
            throw new BizException("积分订单主表插入失败");
        }
        //退货积分不够时扣至为0,只有正向操作才进行续命，逆流程不算--updated by William 2020-01-09
        Integer exchQty = Math.negateExact(paidQty);
        //看是新老积分
        boolean flag = integralOrderPo.getInteType() == 0;
        //看用的是老积分还是新积分
        boolean flagUse = integralLogService.checkPaidQty(integralOrderPo);
        rows = integralAccountMapper.changeBalanceForReturn(order.getMemberId(), gainQty, exchQty, null, flag, flagUse);
        if (rows == 0) {
            String errorMsg = String.format("退货扣减积分失败,orderNo=%s,memberId=%s,totalQty=%s,paidQty=%s", order.getBizNo(), order.getMemberId(), totalQty * -1, paidQty);
            log.error(errorMsg);
            throw new BizException("退货扣减积分失败");
        }
        //发射积分事件
        //this.publishEvent(order);
    }

    private String extractBizType4Return(PosOrderPo orderPo) {
        Boolean beValid = OrderTransTypeEnum.GOODS_RETURN.getCode().equals(orderPo.getTransType());
        beValid = beValid && ActivityTypeEnum.INTEGRAL_EXCH.getCode().equals(orderPo.getActivityType());
        return beValid ? IntegralBizTypeEnum.INTEGRAL_EXCH_RETURN.getCode() : IntegralBizTypeEnum.SALE_RETURN.getCode();
    }

    private String extractIntegralType4Return(PosOrderPo orderPo) {
        Boolean beValid = OrderTransTypeEnum.GOODS_RETURN.getCode().equals(orderPo.getTransType());
        beValid = beValid && ActivityTypeEnum.INTEGRAL_EXCH.getCode().equals(orderPo.getActivityType());
        return beValid ? IntegralTypeEnum.INTEGRAL_EXCH.getCode() : IntegralTypeEnum.SALE.getCode();
    }

    /**
     * 积分失效处理，必须加事务
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void expire() {
        while (true) {
            LocalDateTime now = LocalDateTime.now();
            LambdaQueryWrapper<IntegralAccountPo> queryWrapper = Wrappers.<IntegralAccountPo>lambdaQuery()
                    .lt(IntegralAccountPo::getNextExpireTime, now)
                    .gt(IntegralAccountPo::getAvlQty, 0);
            queryWrapper.last("limit 1000");
            //查询有即将失效积分的账户,1000条处理一批
            List<IntegralAccountPo> integralAccountList = integralAccountMapper.selectList(queryWrapper);
            if (integralAccountList == null || integralAccountList.isEmpty()) {
                return;
            }
            for (IntegralAccountPo e : integralAccountList) {
                IntegralOrderPo order = IntegralOrderPo.builder()
                        .memberId(e.getMemberId())
                        .memberName(e.getMemberName())
                        .memberPhone(e.getMemberPhone())
                        .counterId(e.getCounterId())
                        .counterName(e.getCounterName())
                        .bizType(IntegralBizTypeEnum.INTEGRAL_CLEARING.getCode())
                        .bizNo(IdGenerator.getShorterSerialNo(OrderNoPrefixEnum.PC.getCode()))
                        .bizTime(e.getNextExpireTime())
                        .bizQty(BigInteger.ZERO.intValue())
                        .bizAmt(BigDecimal.ZERO)
                        .paidQty(BigInteger.ZERO.intValue())
                        .gainQty(Math.negateExact(Math.abs(e.getExpiringQty())))
                        .integralQty(Math.negateExact(Math.abs(e.getExpiringQty())))
                        .surplusQty(Math.negateExact(Math.abs(e.getExpiringQty())))
                        .inteType(0)
                        .baCode("系统任务")
                        .baName("系统任务")
                        .createTime(LocalDateTime.now())
                        .build();
                integralOrderMapper.insert(order);
                IntegralOrderItemPo item = IntegralOrderItemPo.builder()
                        .integralOrderId(order.getIntegralOrderId())
                        .discountAmt(BigDecimal.ZERO)
                        .integralQty(order.getIntegralQty())
                        .counterId(e.getCounterId())
                        .counterName(e.getCounterName())
                        .memberId(e.getMemberId())
                        .memberName(e.getMemberName())
                        .memberPhone(e.getMemberPhone())
                        .bizType(IntegralBizTypeEnum.INTEGRAL_CLEARING.getCode())
                        .bizNo(order.getBizNo())
                        .bizTime(e.getNextExpireTime())
                        .bizItemNo("")
                        .goodsBarCode("")
                        .bizItemDesc("")
                        .bizItemAmt(BigDecimal.ZERO)
                        .bizItemQty(BigInteger.ZERO.intValue())
                        .integralType(IntegralTypeEnum.INTEGRAL_CLEARING.getCode())
                        .multiple(BigDecimal.ZERO)
                        .createTime(LocalDateTime.now())
                        .updateTime(LocalDateTime.now())
                        .build();
                integralOrderItemMapper.insert(item);
                //只有老积分会置零
                int rows = integralAccountMapper.expire(e.getMemberId(), Math.abs(e.getExpiringQty()), now);
                if (rows == 0) {
                    String errorMsg = String.format("积分失效失败,memberId=%s,实际0", e.getMemberId());
                    log.error(errorMsg);
                    throw new BizException("积分失效失败");
                }
            }
        }
    }

    @Ella(Describe = "查询会员积分信息", Author = "K")
    public IntegralAccountPo selectIntegralAccount(String memberId) {
        return integralAccountMapper.selectById(memberId);
    }


    /**
     * 新积分失效处理，必须加事务
     */
    @DS(DBConst.MASTER)
    public void newExpire() {
        //执行的时候得是每个月月初的凌晨1点差不多
        if (LocalDateTime.now().getDayOfMonth() != 1) {
            //不是月初跳过
            return;
        }
        if (LocalDateTime.now().isBefore(expireTime)) {
            //2022年4月1号之前跳过
            return;
        }
        //直接获取全部要失效的会员  这个上面没有事物  多点就多点
        List<String> memberIds = integralAccountMapper.selectExpireMembers();
        //查询有即将失效积分的账户,1000条处理一批
        if (memberIds == null || memberIds.isEmpty()) {
            return;
        }
        for (String memberId : memberIds) {
            IntegralService integralService = (IntegralService) AopContext.currentProxy();
            integralService.saveNewExpire(memberId);
        }
    }


    @Transactional(rollbackFor = Exception.class)
    public void saveNewExpire(String memberId) {
        List<IntegralOrderPo> integralOrderNewPos = integralOrderMapper.selectList(Wrappers.<IntegralOrderPo>lambdaQuery()
                .eq(IntegralOrderPo::getMemberId, memberId)
                .gt(IntegralOrderPo::getSurplusQty, 0)
                .eq(IntegralOrderPo::getInteType, 1)
                .lt(IntegralOrderPo::getBizTime, LocalDateTime.now().plusYears(-1))
                .orderByAsc(IntegralOrderPo::getCreateTime));
        if (integralOrderNewPos == null || integralOrderNewPos.isEmpty()) {
            //可能已经被处理过了
            return;
        }
        IntegralAccountPo integralAccountPo = integralAccountMapper.selectById(memberId);
        IntegralOrderPo order = IntegralOrderPo.builder()
                .memberId(integralAccountPo.getMemberId())
                .memberName(integralAccountPo.getMemberName())
                .memberPhone(integralAccountPo.getMemberPhone())
                .counterId(integralAccountPo.getCounterId())
                .counterName(integralAccountPo.getCounterName())
                .bizType(IntegralBizTypeEnum.INTEGRAL_CLEARING.getCode())
                .bizNo(IdGenerator.getShorterSerialNo(OrderNoPrefixEnum.PC.getCode()))
                .bizTime(LocalDateTime.now())
                .bizQty(BigInteger.ZERO.intValue())
                .bizAmt(BigDecimal.ZERO)
                .paidQty(BigInteger.ZERO.intValue())
                .gainQty(0)
                .integralQty(0)
                .surplusQty(0)
                .inteType(1)
                .baCode("系统任务")
                .baName("系统任务")
                .createTime(LocalDateTime.now())
                .build();
        Integer qty = 0;
        for (IntegralOrderPo integralOrderNewPo : integralOrderNewPos) {
            integralLogService.save(order, integralOrderNewPo, 0, integralOrderNewPo.getSurplusQty(), IntegralBizTypeEnum.INTEGRAL_CLEARING.getCode());
            qty += integralOrderNewPo.getSurplusQty();
            integralLogService.updateOrderSurplus(integralOrderNewPo.getIntegralOrderId(), 0);
        }
        order.setGainQty(qty * -1);
        order.setIntegralQty(qty * -1);
        integralOrderMapper.insert(order);
        IntegralOrderItemPo item = IntegralOrderItemPo.builder()
                .integralOrderId(order.getIntegralOrderId())
                .discountAmt(BigDecimal.ZERO)
                .integralQty(order.getIntegralQty())
                .counterId(integralAccountPo.getCounterId())
                .counterName(integralAccountPo.getCounterName())
                .memberId(integralAccountPo.getMemberId())
                .memberName(integralAccountPo.getMemberName())
                .memberPhone(integralAccountPo.getMemberPhone())
                .bizType(IntegralBizTypeEnum.INTEGRAL_CLEARING.getCode())
                .bizNo(order.getBizNo())
                .bizTime(LocalDateTime.now())
                .bizItemNo("")
                .goodsBarCode("")
                .bizItemDesc("")
                .bizItemAmt(BigDecimal.ZERO)
                .bizItemQty(BigInteger.ZERO.intValue())
                .integralType(IntegralTypeEnum.INTEGRAL_CLEARING.getCode())
                .multiple(BigDecimal.ZERO)
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
        integralOrderItemMapper.insert(item);
        int rows = integralAccountMapper.newExpire(integralAccountPo.getMemberId(), qty, LocalDateTime.now());
        if (rows == 0) {
            String errorMsg = String.format("积分失效失败,memberId=%s,实际0", integralAccountPo.getMemberId());
            log.error(errorMsg);
            throw new BizException("积分失效失败");
        }
    }

}
