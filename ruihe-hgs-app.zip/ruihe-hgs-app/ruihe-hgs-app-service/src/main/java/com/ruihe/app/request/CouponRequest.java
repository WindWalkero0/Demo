package com.ruihe.app.request;

import com.ruihe.app.enums.WXCouponStatusEnum;
import com.ruihe.common.annotation.EnumValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-12-27 14:09
 */
@ApiModel(value = "CouponRequest", description = "微信获取个人优惠券实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CouponRequest implements Serializable {

    @NotNull(message = "会员id不能为空")
    @ApiModelProperty("会员id")
    private String memberId;

    @NotNull(message = "类型不能为空")
    @EnumValidation(clazz = WXCouponStatusEnum.class, method = "getCode", message = "类型错误")
    @ApiModelProperty("类型：未使用0，已使用1，已过期2，已取消3")
    private Integer status;

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
