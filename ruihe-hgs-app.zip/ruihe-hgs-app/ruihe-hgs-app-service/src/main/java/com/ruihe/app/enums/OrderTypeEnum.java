package com.ruihe.app.enums;

/**
 * 订单类型：1实体店普通销售/退货,2预定单
 *
 * @author fangtao
 */
public enum OrderTypeEnum {

    /**
     * 1，销售
     **/
    SHOP_SALE(1, "实体店普通销售"),
    /**
     * 2，预定单
     **/
    BOOK(2, "预定单"),
    ;


    private Integer code;
    private String msg;


    OrderTypeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static OrderTypeEnum parse(Integer key) {
        if (key == null) {
            return null;
        }
        for (OrderTypeEnum canalEnum : values()) {
            if (canalEnum.getCode().equals(key)) {
                return canalEnum;
            }
        }
        return null;
    }
}
