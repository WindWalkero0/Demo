package com.ruihe.app.request;

import com.ruihe.common.annotation.EnumValidation;
import com.ruihe.common.enums.status.CommonStatusEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * @author LiangYuan
 * @date 2021-03-11 16:19
 */
@ApiModel(value = "MemberSatEvalOptionRequest", description = "会员满意度评价题目选项请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberSatEvalOptionRequest implements Serializable {

    @ApiModelProperty(value = "ID，有就传")
    private Integer id;

    @NotNull(message = "问卷问题id不能为空")
    @ApiModelProperty(value = "问卷问题id")
    private String sesId;

    @ApiModelProperty(value = "选项排序")
    private String optionNo;

    @Size(max = 50, message = "答案最大长度为50个字符")
    @NotNull(message = "答案能为空")
    @ApiModelProperty(value = "选项答案/问卷答案")
    private String description;

    @NotNull(message = "选项状态能为空")
    @EnumValidation(clazz = CommonStatusEnum.class, method = "getCode", message = "选项状态错误")
    @ApiModelProperty(value = "选项状态：0未选择，1选择")
    private Integer status;
}
