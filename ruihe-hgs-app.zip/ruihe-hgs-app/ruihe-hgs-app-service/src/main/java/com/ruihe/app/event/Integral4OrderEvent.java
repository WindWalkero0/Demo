package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 积分订单事件，回写t_pos_order表inte_gained&inte_qty
 *
 * @author William
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Integral4OrderEvent extends ApplicationEvent {

    /**
     * 订单号
     */
    private Integer IntegralOrderNo;

    /**
     * Create a new ApplicationEvent.
     *
     * @param source the object on which the event initially occurred (never {@code null})
     */
    public Integral4OrderEvent(Object source, Integer IntegralOrderNo) {
        super(source);
        this.IntegralOrderNo = IntegralOrderNo;
    }

}
