package com.ruihe.app.service.order;

import com.ruihe.app.request.PosLadingOrderRequest;
import com.ruihe.app.request.PosLadingRefundRequest;
import com.ruihe.app.request.order.PosRsvOrderQueryRequest;
import com.ruihe.common.response.Response;

/**
 * <p>
 * 预订单-提货/退货服务
 * </p>
 *
 * @author ly
 * @since 2019-10-19
 */
public interface PosLadingOrderService {
    /**
     * 预订单提货操作
     *
     * @param request
     * @return
     */
    Response lade(PosLadingOrderRequest request);

    /**
     * 查询会员提货单列表
     *
     * @param request
     * @return
     */
    Response ladingList(PosRsvOrderQueryRequest request);

    /**
     * 查询提货/退货单明细
     *
     * @param ladingOrderNo
     * @return
     */
    Response ladingItem(String ladingOrderNo);

    /**
     * 提货单-退货操作
     *
     * @param request
     * @return
     */
    Response refund(PosLadingRefundRequest request);

    /**
     * 预定单补全
     *
     * @param orderNo
     * @return
     */
    Response fillAssociated(String orderNo);

    /**
     * u8失败重发
     *
     * @param orderNo
     * @return
     */
    Response u8FailResend(String orderNo,String type,boolean flag);

}
