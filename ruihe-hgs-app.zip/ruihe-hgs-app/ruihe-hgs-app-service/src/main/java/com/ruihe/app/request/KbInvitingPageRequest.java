package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author William
 * @Description
 * @create 2021-03-19 08:12
 */
@ApiModel(value = "KbInvitingPageRequest", description = "微信卡券-》邀请有礼-》我的邀请-》分页查询")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class KbInvitingPageRequest implements Serializable {

    @NotNull(message = "会员id不能为空")
    @ApiModelProperty("会员id")
    private String memberId;

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
