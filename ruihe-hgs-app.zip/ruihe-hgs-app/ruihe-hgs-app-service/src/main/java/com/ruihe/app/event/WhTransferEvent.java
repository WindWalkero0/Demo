package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 调拨确认事件
 *
 * @author William
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class WhTransferEvent extends ApplicationEvent {

    /**
     * 单号
     */
    private String orderNo;

    public WhTransferEvent(Object source, String orderNo) {
        super(source);
        this.orderNo = orderNo;
    }
}
