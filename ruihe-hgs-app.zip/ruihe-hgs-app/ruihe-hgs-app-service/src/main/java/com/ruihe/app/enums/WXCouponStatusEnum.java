package com.ruihe.app.enums;

/**
 * @author LiangYuan
 * @Description
 * @create 2020-09-18 17:24
 */
public enum WXCouponStatusEnum {
    /**
     * 未使用0，已使用1，已过期2，已取消3
     **/
    UNUSED(0, "未使用"),
    USED(1, "已使用"),
    EXPIRED(2, "已过期"),
    CANCELLED(3, "已取消"),
    ;

    private Integer code;
    private String msg;


    WXCouponStatusEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
