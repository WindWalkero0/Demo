package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * @author 梁远
 * @Description 每月微信未激活可销售人数
 * @date 2021-01-12 9:16
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Order4WxUnActiveSaleEvent extends ApplicationEvent {
    private String memberId;
    private String counterId;

    public Order4WxUnActiveSaleEvent(Object source, String memberId, String counterId) {
        super(source);
        this.memberId = memberId;
        this.counterId = counterId;
    }
}
