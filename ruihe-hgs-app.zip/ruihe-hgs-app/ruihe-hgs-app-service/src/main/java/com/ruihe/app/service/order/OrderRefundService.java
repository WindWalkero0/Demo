package com.ruihe.app.service.order;

import com.ruihe.common.dao.bean.member.MemberCoupon;
import com.ruihe.common.dao.bean.member.MemberCouponLog;
import com.ruihe.common.dao.bean.order.PosOrderActivity;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.enums.activity.ActivityTypeEnum;
import com.ruihe.common.enums.prefix.PrefixEnum;
import com.ruihe.common.service.CustomService;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.TimeUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
public class OrderRefundService {

    @Autowired
    private CustomService customService;

    /**
     * 秉坤的直接不退
     * 必须是会员
     * 查询是否满足退券要求  1:是退单在使用的优惠券有效期内  2:必须全退
     *
     * @param originalOrderNo 订单号
     * @param transType       订单类型
     * @param memberId        会员id
     */
    @Ella(Describe = "退货优惠券处理", Author = "K")
    @Transactional(rollbackFor = Exception.class)
    public void operationReturnGoods(String originalOrderNo, Integer transType, String memberId) {
        if (StringUtils.isBlank(originalOrderNo) ||
                originalOrderNo.length() > 25 ||
                OrderTransTypeEnum.GOODS_OUT.getCode().equals(transType) ||
                StringUtils.isBlank(memberId)) {
            return;
        }
        operationPromotion(originalOrderNo);
        //查询订单信息
        PosOrderPo posOrderPo = customService.select(PosOrderPo.builder().orderNo(originalOrderNo).build());
        Long timeMillis = System.currentTimeMillis();
        //当天退货
        //查询是否用了优惠券信息
        if (ActivityTypeEnum.USING_CONPON_4ISSUE.getCode().equals(posOrderPo.getActivityType()) || ActivityTypeEnum.USING_CONPON_4MEMBER.getCode().equals(posOrderPo.getActivityType())) {
            //会员优惠券活动和发券活动优惠券活动
            PosOrderActivity posOrderActivity = customService.select(PosOrderActivity.builder().orderNo(originalOrderNo).build());
            if (posOrderActivity == null) {
                //没有同步过来的订单关联活动信息,跳过
                return;
            }
            //进行重新发券来充当退券
            MemberCoupon memberCoupon = customService.select(MemberCoupon.builder().couponId(posOrderActivity.getCouponId()).build());
            //获取到优惠券的开始时和结束时间
            Long timeB = TimeUtils.timeChange(memberCoupon.getStartTime());
            Long timeE = TimeUtils.timeChange(memberCoupon.getStopTime());
            if (timeB <= timeMillis && timeMillis <= timeE) {
                if (ActivityTypeEnum.USING_CONPON_4ISSUE.getCode().equals(posOrderPo.getActivityType())) {
                    //生成一条优惠券信息
                    memberCoupon.setCouponId(IdGenerator.getSerialNo(PrefixEnum.ACTIVITY_COUPON.getCode()));
                    memberCoupon.setStatus(0);
                    memberCoupon.setCreateTime(LocalDateTime.now());
                    memberCoupon.setReceiveCounterId(null);
                    memberCoupon.setReceiveTime(null);
                    //生成优惠券记录
                    MemberCouponLog couponLog = MemberCouponLog
                            .builder()
                            .subActivityName(memberCoupon.getSubActivityName())
                            .subActivityId(memberCoupon.getSubActivityId())
                            .activityId(memberCoupon.getActivityId())
                            .activityName(memberCoupon.getActivityName())
                            .createTime(LocalDateTime.now())
                            .id(memberCoupon.getCouponId())
                            .memberId(memberCoupon.getMemberId())
                            .memberName(memberCoupon.getMemberName())
                            .memberPhone(memberCoupon.getMobilePhone())
                            .status(memberCoupon.getStatus())
                            .build();
                    //保存记录
                    Integer save = customService.save(couponLog);
                    if (save.equals(0)) {
                        log.error("保存优惠券记录信息失败,memberCouponLog={}", couponLog);
                        throw new BizException("保存优惠券记录信息失败");
                    }
                    //保存优惠券信息
                    Integer row = customService.save(memberCoupon);
                    if (row.equals(0)) {
                        log.error("保存优惠券信息失败!memberCoupon={}", memberCoupon);
                        throw new BizException("保存优惠券信息失败");
                    }
                } else if (ActivityTypeEnum.USING_CONPON_4MEMBER.getCode().equals(posOrderPo.getActivityType())) {
                    //将已经使用的优惠券设置为无效
                    Integer update = customService.update(MemberCoupon.builder().isDel(0).build(),
                            MemberCoupon.builder().couponId(memberCoupon.getCouponId()).build());
                    if (update.equals(0)) {
                        log.error("退货将已经使用的优惠券设置为无效失败");
                        throw new BizException();
                    }
                }
            }
        }
    }

    /**
     * 退单处理发券优惠券逻辑
     *
     * @param originalOrderNo
     */
    private void operationPromotion(String originalOrderNo) {
        List<MemberCoupon> memberCoupons =
                customService.selectList(MemberCoupon.builder().orderNo(originalOrderNo).status(0).couponType(1).build());
        memberCoupons.forEach(memberCoupon -> {
            Integer memberCouponUpdate = customService.update(MemberCoupon.builder().status(3).isDel(0).build(),
                    MemberCoupon.builder().couponId(memberCoupon.getCouponId()).build());
            if (memberCouponUpdate.equals(0)) {
                log.error("退单将发券的优惠券设置为无效失败,coupon_id={}", memberCoupon.getCouponId());
                throw new BizException("退单将发券的优惠券设置为无效失败");
            }
            Integer couponLog = customService.update(MemberCouponLog.builder().status(3).build(),
                    MemberCouponLog.builder().id(memberCoupon.getCouponId()).build());
            if (couponLog.equals(0)) {
                log.error("修改优惠券记录状态失败,coupon_id={}", memberCoupon.getCouponId());
                throw new BizException("修改优惠券记录状态失败");
            }
        });

    }
}
