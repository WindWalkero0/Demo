package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.event.Order4IntegralBeforeLevelEvent;
import com.ruihe.app.event.Order4OnlyMemberLevelEvent;
import com.ruihe.app.mapper.basic.CounterMapper;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.app.mapper.order.PosOrderItemMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.service.integral.IntegralLogService;
import com.ruihe.app.service.integral.IntegralRuleEngine;
import com.ruihe.app.service.integral.IntegralService;
import com.ruihe.app.service.integral.RuleContext;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderItemPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderPo;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.enums.integral.IntegralBizTypeEnum;
import com.ruihe.common.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.MutableTriple;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.List;

/**
 * 销售订单事件-积分业务处理
 * <p>
 * 销售+出-》增加积分
 * 销售+退-》扣减积分
 * 预订单+出-》增加积分
 * 预订单+退-》扣减积分
 * 积分兑换+出-》扣减积分
 * 积分兑换+退-》增加积分
 * </p>
 * 2021年1月25日14:17:25  积分之后在处理等级
 *
 * @author William
 */
@Slf4j
@Component
public class Order4IntegralBeforeLevelListener implements ApplicationContextAware {

    @Autowired
    private IntegralRuleEngine integralRuleEngine;

    @Autowired
    private IntegralService integralService;

    @Autowired
    private IntegralLogService integralLogService;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private PosOrderItemMapper posOrderItemMapper;

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private CounterMapper counterMapper;

    private ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(Order4IntegralBeforeLevelEvent event) {
        try {
            //构造rc
            RuleContext rc = this.extractRuleContext(event.getOrderNo());
            //记录积分处理
            if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(rc.getOrder().getTransType())) {
                //正常销售、预订单、积分兑换跑积分活动
                MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> result = integralRuleEngine.run(rc);
                //事务处理落地数据
                integralService.changeBalance(result);
                integralLogService.saveLog(rc);
            } else if (OrderTransTypeEnum.GOODS_RETURN.getCode().equals(rc.getOrder().getTransType()) && StringUtils.isNotBlank(rc.getOrder().getPreOrderNo())) {
                //正常销售退货、预订单退货、积分兑换退货【整单退】
                integralService.changeBalance(rc.getOrder());
                integralLogService.saveLog(rc);
            } else if (OrderTransTypeEnum.GOODS_RETURN.getCode().equals(rc.getOrder().getTransType()) && StringUtils.isBlank(rc.getOrder().getPreOrderNo())) {
                //空退货走默认积分规则进行扣减积分
                MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> result = integralRuleEngine.run4DirectGoodsReturn(rc);
                integralService.changeBalance(result);
                integralLogService.deductedNewForEmptyReturn(result.getLeft(), IntegralBizTypeEnum.SALE_RETURN.getCode());
            }

            Order4OnlyMemberLevelEvent order4OnlyMemberLevelEvent = new Order4OnlyMemberLevelEvent(this, event.getMemberId(), event.getOrderNo());
            this.applicationContext.publishEvent(order4OnlyMemberLevelEvent);
        } catch (BizException e) {
            //BizException日志降级，不钉钉报警
            log.warn("积分业务处理异常，event{}", JSON.toJSONString(event), e);
        } catch (Exception e) {
            log.error("积分业务处理异常，event{}", JSON.toJSONString(event), e);
        }

    }

    /**
     * 构造rc
     *
     * @param orderNo
     * @return
     */
    private RuleContext extractRuleContext(final String orderNo) {
        /*查询订单信息*/
        PosOrderPo orderPo = posOrderMapper.selectById(orderNo);
        List<PosOrderItemPo> posOrderItemPos = posOrderItemMapper.selectList(Wrappers.<PosOrderItemPo>lambdaQuery().eq(PosOrderItemPo::getOrderNo, orderNo));
        MemberInfo member = memberMapper.selectById(orderPo.getMemberId());
        CounterInformation counter = counterMapper.selectById(orderPo.getCounterId());
        IntegralAccountPo integralAccountPo = integralService.selectIntegralAccount(orderPo.getMemberId());
        return RuleContext.builder()
                .member(member)
                .counter(counter)
                .order(orderPo)
                .accountPo(integralAccountPo)
                .orderItemList(posOrderItemPos)
                .build();
    }
}
