package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.ruihe.app.event.Integral4OrderEvent;
import com.ruihe.common.dao.mapper.integral.IntegralOrderMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.common.dao.bean.integral.IntegralOrderPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.constant.CommonConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.time.LocalDateTime;

/**
 * 积分事件处理，回写t_pos_order表inte_gained&inte_qty
 *
 * @author William
 */
@Slf4j
@Component
public class Integral4OrderListener {
    @Autowired
    private IntegralOrderMapper integralOrderMapper;
    @Autowired
    private PosOrderMapper posOrderMapper;

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(Integral4OrderEvent event) {
        try {
            //根据积分订单号获取积分订单记录
            IntegralOrderPo integralOrder = integralOrderMapper.selectById(event.getIntegralOrderNo());
            PosOrderPo posOrder = PosOrderPo.builder()
                    .orderNo(integralOrder.getBizNo())
                    .inteGained(integralOrder.getGainQty())
                    .inteQty(integralOrder.getIntegralQty())
                    .updateTime(LocalDateTime.now())
                    .build();
            posOrderMapper.updateById(posOrder);
        } catch (Exception e) {
            log.error("积分事件处理异常，event{}", JSON.toJSONString(event), e);
        }
    }
}
