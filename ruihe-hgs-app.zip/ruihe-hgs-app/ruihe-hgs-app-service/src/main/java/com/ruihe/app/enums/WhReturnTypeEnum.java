package com.ruihe.app.enums;

/**
 * @author fly
 * @Description 退库类型
 * @create 2021年5月25日09:22:30
 */
public enum WhReturnTypeEnum {

    // 0可用试用装退回，1报废试用装退回，2转店退回，,质量问题退回，4过敏退回，5公司召回，6到货少货，7活动赠品退回，8其他 9无源退库
    RETURN_TYPE_ENUM_0(0, "可用试用装退回"),
    RETURN_TYPE_ENUM_1(1, "报废试用装退回"),
    RETURN_TYPE_ENUM_2(2, "转店退回"),
    RETURN_TYPE_ENUM_3(3, "质量问题退回"),
    RETURN_TYPE_ENUM_4(4, "过敏退回"),
    RETURN_TYPE_ENUM_5(5, "公司召回"),
    RETURN_TYPE_ENUM_6(6, "到货少货"),
    RETURN_TYPE_ENUM_7(7, "活动赠品退回"),
    RETURN_TYPE_ENUM_8(8, "其他"),
    RETURN_TYPE_ENUM_9(9, "无源退库");
    private Integer code;
    private String msg;


    WhReturnTypeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
