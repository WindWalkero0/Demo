package com.ruihe.app.response.AIComprehensive;

import lombok.Data;

@Data
public class WaterOil {
    private String water;
    private String oil;
}