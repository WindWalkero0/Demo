package com.ruihe.app.service.integral;

import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 积分规则上下文
 *
 * @author William
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RuleContext implements Serializable {
    /**
     * 会员
     */
    private MemberInfo member;
    /**
     * 柜台
     */
    private CounterInformation counter;
    /**
     * 用户
     */
    private IntegralAccountPo accountPo;
    /**
     * 销售订单
     */
    private PosOrderPo order;
    /**
     * 销售订单明细
     */
    private List<PosOrderItemPo> orderItemList;

}


