package com.ruihe.app.service.integral;

import com.ruihe.common.dao.bean.integral.IntegralActivityPo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 规则/活动执行结果
 *
 * @author William
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MatchResult implements Serializable {
    public static final Integer SKIP = 0;
    public static final Integer MISSMATCH = -1;
    public static final Integer MATCH = 1;
    private Integer code;
    private String msg;

    @Data
    @Builder
    public static class MatchResultItem implements Serializable {
        /**
         * 宿主规则
         **/
        private IntegralActivityPo mainActivity;
        /**
         * 附属规则
         **/
        private IntegralActivityPo subActivity;
        /**
         * 积分系数
         **/
        private BigDecimal multiple;
        /**
         * 积分奖励理由
         */
        private String reason;
    }

    public static MatchResult skip(String msg) {
        return MatchResult.builder().code(SKIP).msg(msg).build();
    }

    public static MatchResult match(String msg) {
        return MatchResult.builder().code(MATCH).msg(msg).build();
    }

    public static MatchResult missMatch(String msg) {
        return MatchResult.builder().code(MISSMATCH).msg(msg).build();
    }

    public boolean missMatch() {
        return MISSMATCH.equals(this.code);
    }

    public boolean match() {
        return MATCH.equals(this.code);
    }
}
