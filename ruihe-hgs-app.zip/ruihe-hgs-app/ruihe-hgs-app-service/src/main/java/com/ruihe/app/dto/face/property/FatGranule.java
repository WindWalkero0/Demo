package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class FatGranule {
    private Integer level;
    private Integer number;
    private Integer fatGranuleTypeId;
    private String maskPath;

    public static boolean getProblemData(FatGranule fatGranule) {
        return fatGranule.getLevel() > 1;
    }
}
