package com.ruihe.app.listener;


import com.alibaba.fastjson.JSON;
import com.ruihe.app.event.PromotionCouponEvent;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.app.service.promotion.AboutPromotionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

/**
 * 匹配发券活动进行发券
 */
@Slf4j
@Component
public class PromotionCouponListener {


    @Autowired
    private AboutPromotionService promotionService;

    @Async(CommonConstant.POS_COUPON_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(PromotionCouponEvent event) {
        try {
            promotionService.matchPromotion(event.getMemberInfo(), event.getActivityType(),event.getOrderNo(),
                    event.getProducts(),event.getCounterId());
        } catch (Exception e) {
            log.error("匹配发券活动进行发券异常，event{}", JSON.toJSONString(event), e);
        }
    }
}
