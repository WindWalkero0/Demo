package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 预订单提货退货事件
 *
 * @author William
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class LadingOrderLadeReturnEvent extends ApplicationEvent {

    /**
     * 单号
     */
    private String orderNo;

    public LadingOrderLadeReturnEvent(Object source, String orderNo) {
        super(source);
        this.orderNo = orderNo;
    }
}
