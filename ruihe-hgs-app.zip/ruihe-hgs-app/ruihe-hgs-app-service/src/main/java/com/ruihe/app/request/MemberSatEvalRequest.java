package com.ruihe.app.request;

import com.ruihe.common.annotation.EnumValidation;
import com.ruihe.common.enums.sat.SatChannelEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @author LiangYuan
 * @date 2021-03-11 16:19
 */
@ApiModel(value = "MemberSatEvalRequest", description = "会员满意度评价请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberSatEvalRequest implements Serializable {

    @NotBlank(message = "问卷ID不能为空")
    @ApiModelProperty(value = "问卷ID")
    private String id;

    @ApiModelProperty(value = "微信unionId，小程序中评价的时候需要填充")
    private String unionId;

    @ApiModelProperty(value = "会员id")
    private String memberId;

    @NotNull(message = "评价渠道不能为空")
    @EnumValidation(clazz = SatChannelEnum.class, method = "getKey", message = "评价渠道错误")
    @ApiModelProperty(value = "评价渠道：0微信模板消息，1短信消息")
    private Integer channel;

    @NotEmpty(message = "题目不能为空")
    @ApiModelProperty(value = "题目")
    @Valid
    private List<MemberSatEvalSubjectRequest> subjectRequestList;
}
