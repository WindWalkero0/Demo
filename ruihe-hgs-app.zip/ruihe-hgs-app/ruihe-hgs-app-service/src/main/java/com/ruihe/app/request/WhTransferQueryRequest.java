package com.ruihe.app.request;

import com.ruihe.common.annotation.FieldName;
import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;


/**
 * 调入/调出查询页请求实体
 *
 * @author Fangtao
 */
@ApiModel(value = "WhTransferQueryRequest", description = "调入/调出查询页请求实体")
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WhTransferQueryRequest extends PageForm implements Serializable {

    @NotBlank(message = "柜台id不能为空")
    @ApiModelProperty("柜台id")
    @FieldName(name = "柜台id")
    private String counterId;

    @NotNull(message = "开始时间不能为空")
    @ApiModelProperty("调拨单申请时间范围-[开始时间]")
    private LocalDate applyStartTime;

    @NotNull(message = "结束时间不能为空")
    @ApiModelProperty("调拨单申请时间范围-[结束时间]")
    private LocalDate applyEndTime;
}
