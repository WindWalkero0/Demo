package com.ruihe.app.service.heartbeat;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.enums.CountHeartbeatTypeEnum;
import com.ruihe.app.event.CounterHeartbeatEvent;
import com.ruihe.app.mapper.basic.CounterInfoMapper;
import com.ruihe.app.mapper.heartbeat.CounterHeartbeatConfigMapper;
import com.ruihe.app.mapper.heartbeat.CounterHeartbeatMapper;
import com.ruihe.app.po.heartbeat.CounterHeartbeatConfigPO;
import com.ruihe.app.po.heartbeat.CounterHeartbeatPO;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

/**
 * 柜台心跳服务
 * @author qubin
 * @date 2021/4/17 16:22
 */
@Slf4j
@Service
public class CounterHeartbeatService implements ApplicationContextAware {

    @Autowired
    private CounterHeartbeatConfigMapper counterHeartbeatConfigMapper;

    @Autowired
    private CounterHeartbeatMapper counterHeartbeatMapper;

    @Autowired
    private CounterInfoMapper counterInfoMapper;

    private ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    /**
     * 心跳预处理，发布事件，异步进行心跳处理
     * @param counterId
     * @return
     */
    public Response preHeartbeat(String counterId){
        //发布一个事件
        CounterHeartbeatEvent counterHeartbeatEvent = new CounterHeartbeatEvent(this,
                counterId);
        this.applicationContext.publishEvent(counterHeartbeatEvent);
        return Response.success();
    }

    /**
     * 心跳接口
     * @param counterId
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response heartbeat(String counterId){

        if(StringUtils.isBlank(counterId)){
            return Response.errorMsg("柜台id不能为空");
        }

        //查询柜台是否存在
        CounterInformation counterInformation = counterInfoMapper.selectById(counterId);
        if(counterInformation == null){
            return Response.errorMsg("柜台不存在");
        }
        //查询有无个性化配置
        CounterHeartbeatConfigPO counterHeartbeatConfigPO = counterHeartbeatConfigMapper.selectOne(Wrappers.<CounterHeartbeatConfigPO>lambdaQuery()
                .eq(CounterHeartbeatConfigPO::getCounterId, counterId));
        if(counterHeartbeatConfigPO == null){
            //查询通用化配置
            counterHeartbeatConfigPO = counterHeartbeatConfigMapper.selectOne(Wrappers.<CounterHeartbeatConfigPO>lambdaQuery()
                    .eq(CounterHeartbeatConfigPO::getType, CountHeartbeatTypeEnum.COMMON.getCode()));
        }

        if(counterHeartbeatConfigPO == null){
            return Response.errorMsg("柜台心跳配置不存在");
        }
        //查询心跳表有无该柜台记录
        CounterHeartbeatPO counterHeartbeatPO = counterHeartbeatMapper.selectOne(Wrappers.<CounterHeartbeatPO>lambdaQuery()
                .eq(CounterHeartbeatPO::getCounterId, counterId));
        try {
            if(counterHeartbeatPO == null){
                CounterHeartbeatPO build = CounterHeartbeatPO.builder()
                        .actOvertimeCount(0)
                        .counterId(counterId)
                        .counterName(counterInformation.getCounterName())
                        .createTime(LocalDateTime.now())
                        .heartbeatTime(LocalDateTime.now())
                        .isLive(1)
                        .preNextTime(LocalDateTime.now().plusSeconds(counterHeartbeatConfigPO.getIntervalSeconds()))
                        .updateTime(LocalDateTime.now())
                        .build();
                //不存在则新增
                int row =  counterHeartbeatMapper.insert(build);
                if(row != 1){
                    throw  new BizException("插入柜台心跳异常:" + build);
                }
                return Response.success();
            }
        } catch (DuplicateKeyException e) {
            //捕捉错误，当成功处理
            return Response.success();
        }

        //有记录则进行更新
        CounterHeartbeatPO build = CounterHeartbeatPO.builder()
                .updateTime(LocalDateTime.now())
                .preNextTime(LocalDateTime.now().plusSeconds(counterHeartbeatConfigPO.getIntervalSeconds()))
                .lastHeartbeatTime(counterHeartbeatPO.getHeartbeatTime())
                .heartbeatTime(LocalDateTime.now())
                .isLive(1)
                .actOvertimeCount(0)
//                .actOvertimeCount(Duration.between(LocalDateTime.now(),
//                        counterHeartbeatPO.getHeartbeatTime()).toSeconds() > counterHeartbeatConfigPO.getIntervalSeconds()?
//                        counterHeartbeatPO.getActOvertimeCount()+ 1 : counterHeartbeatPO.getActOvertimeCount())
                .counterId(counterId)
                .build();
        int row = counterHeartbeatMapper.updateById(build);
        if(row != 1){
            throw  new BizException("修改柜台心跳异常:" + build);
        }
        return Response.success();
    }

    /**
     * 检测心跳
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response checkHeartbeat(){
        //查询出预计下次心跳小于当前时间，并且心跳存活的数据
        List<CounterHeartbeatPO> counterHeartbeatPOList =  counterHeartbeatMapper.selectList(Wrappers.<CounterHeartbeatPO>lambdaQuery()
                .eq(CounterHeartbeatPO::getIsLive, 1)
                .lt(CounterHeartbeatPO::getPreNextTime, LocalDateTime.now()));
        if(counterHeartbeatPOList == null || counterHeartbeatPOList.isEmpty()){
            return Response.success();
        }
        //暂时先根据通用规则
       CounterHeartbeatConfigPO counterHeartbeatConfigPO = counterHeartbeatConfigMapper.selectOne(Wrappers.<CounterHeartbeatConfigPO>lambdaQuery()
                .eq(CounterHeartbeatConfigPO::getType, CountHeartbeatTypeEnum.COMMON.getCode()));
        if(counterHeartbeatConfigPO == null){
            return Response.errorMsg("柜台心跳规则不能为空");
        }
        for(CounterHeartbeatPO counterHeartbeatPO : counterHeartbeatPOList){
            //判断是否在工作时间范围内,超出直接清空
            if(LocalTime.now().compareTo(LocalTime.parse(counterHeartbeatConfigPO.getStartClock())) < 0
                 || LocalTime.now().compareTo(LocalTime.parse(counterHeartbeatConfigPO.getFinishClock())) > 0){
               CounterHeartbeatPO build = CounterHeartbeatPO.builder()
                       .counterId(counterHeartbeatPO.getCounterId())
                       .actOvertimeCount(0)
                       .isLive(0)
                       .updateTime(LocalDateTime.now())
                       .build();
               counterHeartbeatMapper.updateById(build);
               continue;
            }
            //如果超时次数大于规则的超时次数，则报警,
            if(counterHeartbeatPO.getActOvertimeCount() >= counterHeartbeatConfigPO.getOvertimeCount()){
                log.error("柜台网络异常：counterId= "+ counterHeartbeatPO.getCounterId());
                CounterHeartbeatPO build = CounterHeartbeatPO.builder()
                        .counterId(counterHeartbeatPO.getCounterId())
                        .isLive(0)
                        .updateTime(LocalDateTime.now())
                        .build();
                counterHeartbeatMapper.updateById(build);
                continue;
            }
            CounterHeartbeatPO build = CounterHeartbeatPO.builder()
                    .counterId(counterHeartbeatPO.getCounterId())
                    .actOvertimeCount(counterHeartbeatPO.getActOvertimeCount() + 1)
                    .updateTime(LocalDateTime.now())
                    .build();
            counterHeartbeatMapper.updateById(build);
        }
        return Response.success();
    }
}
