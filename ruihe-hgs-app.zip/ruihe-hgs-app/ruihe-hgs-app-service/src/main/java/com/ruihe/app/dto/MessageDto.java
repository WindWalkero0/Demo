package com.ruihe.app.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author LiangYuan
 * @description
 * @date 2020-10-16 11:18
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MessageDto implements Serializable {
    String sender;
    String reciver;
    String messgaeName;
    String messageContent;
}
