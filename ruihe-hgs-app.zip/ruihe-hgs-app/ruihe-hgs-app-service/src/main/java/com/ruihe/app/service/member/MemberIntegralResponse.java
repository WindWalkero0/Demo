package com.ruihe.app.service.member;

import com.ruihe.common.pojo.response.member.MemberActivityRedeemResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MemberIntegralResponse {

    private List<MemberActivityRedeemResponse> list;

    /**
     * 总积分
     */
    private Integer totalQty;

    /**
     * 新积分
     */
    private Integer newQty;

    /**
     * 老积分
     */
    private Integer oldQty;

    /**
     * 积分类型 0老积分 1新积分
     */
    private Integer ruleType;
}
