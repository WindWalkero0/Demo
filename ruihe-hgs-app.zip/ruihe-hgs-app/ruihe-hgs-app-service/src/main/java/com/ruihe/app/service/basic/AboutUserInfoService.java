package com.ruihe.app.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.common.dao.bean.base.UserInformation;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@Ella(Describe = "员工管理service", Author = "K")
public class AboutUserInfoService {

    @Autowired
    private CustomService customService;

    @Ella(Describe = "查询用户信息", Author = "K")
    @DS(DBConst.SLAVE)
    public UserInformation selectEmpDetail(UserInformation userInformation) {
        return customService.select(userInformation);
    }

    @Ella(Describe = "更新BA信息", Author = "K")
    @DS(DBConst.MASTER)
    public void updateEmp(UserInformation userInformation, UserInformation userInformationOhter) throws Exception {
        Integer update = customService.update(userInformation, userInformationOhter);
        if (update.equals(StatusEnum.UN_DELETED.getKey())) {
            throw new BizException("更新BA信息失败");
        }
    }
}
