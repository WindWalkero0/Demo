package com.ruihe.app.service.order;

import com.ruihe.app.mapper.member.MemberActivityMapper;
import com.ruihe.app.request.PosSaleOrderRequest;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.member.MemberActivitySon;
import com.ruihe.common.dao.bean.member.MemberCoupon;
import com.ruihe.common.dao.bean.member.MemberCouponLog;
import com.ruihe.common.dao.bean.member.MemberCouponResult;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.member.MemberIntegralResult;
import com.ruihe.common.dao.bean.order.PosOrderActivity;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.enums.order.OrderItemProductTypeEnum;
import com.ruihe.common.enums.prefix.PrefixEnum;
import com.ruihe.common.dao.mapper.TaskMapper;
import com.ruihe.common.service.CustomService;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.TimeUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Administrator
 */
@Service
@Slf4j
public class ActivityOrderService {

    @Autowired
    private TaskMapper taskMapper;

    @Autowired
    private CustomService customService;

    @Autowired
    private MemberActivityMapper memberActivityMapper;


    @Transactional(rollbackFor = Exception.class)
    @Ella(Describe = "活动相关虚拟订单处理")
    public List<PosOrderActivity> operationOrderItems(AcitivityMatchContext activityCtx, MemberInfo memberInfo, CounterInformation counter, List<PosOrderItemPo> posOrderItemList, PosSaleOrderRequest request, String orderNo) {
        if (request.isKt()) {
            //空退业务价格调整处理
            Optional<BigDecimal> priceAdjust = posOrderItemList.parallelStream()
                    .filter(e -> e.getSalePrice().compareTo(BigDecimal.ZERO) < BigInteger.ZERO.intValue())
                    .map(PosOrderItemPo::getSalePrice)
                    .reduce(BigDecimal::add);
            activityCtx.setDiscountAmt(priceAdjust.orElse(BigDecimal.ZERO));
        } else if (request.getTransType().equals(OrderTransTypeEnum.GOODS_OUT.getCode())) {
            List<PosOrderActivity> posOrderActivities = request.getOrderItemList().stream().filter(this::isFictitious)
                    .map(orderItemRequest -> {
                        if (orderItemRequest.getTotalMoney() == null) {
                            log.error("虚拟商品总价未传递{}", orderItemRequest);
                            throw new BizException("虚拟商品总价未传递");
                        }
                        PosOrderItemPo posOrderItemPo = PosOrderItemPo
                                .builder()
                                .discernType(orderItemRequest.getDiscernType())
                                .orderNo(orderNo)
                                .counterId(counter.getCounterId())
                                .counterName(counter.getCounterName())
                                .memberId(memberInfo == null ? null : memberInfo.getMemberId())
                                .memberName(memberInfo == null ? null : memberInfo.getMemberName())
                                .memberPhone(memberInfo == null ? StringUtils.trim(request.getMemberPhone()) : memberInfo.getMobilePhone()) //预订单必须留手机号
                                .surplusQty(BigInteger.ZERO.intValue())
                                .prdPrice(BigDecimal.ZERO)
                                .shareAmt(BigDecimal.ZERO)
                                .isVirtual(BigInteger.ONE.intValue())
                                .build();
                        Integer proType = orderItemRequest.getProType();
                        String prdBarCode = orderItemRequest.getPrdBarCode();//获取虚拟商品信息
                        posOrderItemPo.setProType(proType);//设置活动类型
                        posOrderItemPo.setActivityId(prdBarCode);//活动id
                        posOrderItemPo.setActivityDesc(orderItemRequest.getPrdName());//活动名称
                        posOrderItemPo.setGoodsBarCode(prdBarCode);//活动id
                        posOrderItemPo.setPrdBarCode(prdBarCode);//活动id
                        posOrderItemPo.setPrdName(orderItemRequest.getPrdName());//活动名称
                        posOrderItemPo.setBigCatCode(proType.equals(OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode()) ? -2 : -1);
                        posOrderItemPo.setBigCatName(proType.equals(OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode()) ? "积分兑礼" : "套装折扣");
                        posOrderItemPo.setMediumCatCode(proType.equals(OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode()) ? -2 : -1);
                        posOrderItemPo.setMediumCatName(proType.equals(OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode()) ? "积分兑礼" : "套装折扣");
                        posOrderItemPo.setSmallCatCode(proType.equals(OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode()) ? -2 : -1);
                        posOrderItemPo.setSmallCatName(proType.equals(OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode()) ? "积分兑礼" : "套装折扣");
                        posOrderItemPo.setPurQty(orderItemRequest.getPurQty());//虚拟数量
                        posOrderItemPo.setSalePrice(orderItemRequest.getTotalMoney());//虚拟商品价格
                        posOrderItemPo.setAmount(orderItemRequest.getTotalMoney());//虚拟商品应付价格
                        //计算优惠金额
                        activityCtx.setDiscountAmt(activityCtx.getDiscountAmt().add(posOrderItemPo.getAmount()));
                        if (proType.equals(OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode())) {
                            MemberActivitySon memberActivitySon = customService.select(MemberActivitySon.builder().activityId(prdBarCode).build());
                            activityCtx.setIntePayable(activityCtx.getIntePayable() + Integer.parseInt(memberActivitySon.getRequiredIntegral())); //计算花费积分
                        }
                        PosOrderActivity posOrderActivity = PosOrderActivity
                                .builder()
                                .createTime(LocalDateTime.now())
                                .couponId(orderItemRequest.getCouponId())
                                .activityType(proType)
                                .orderNo(orderNo)
                                .coupon(orderItemRequest.getCoupon())
                                .memberId(memberInfo != null ? memberInfo.getMemberId() : null)
                                .build(); //生成活动信息
                        if (proType.equals(OrderItemProductTypeEnum.PROMOTION.getCode()) || proType.equals(OrderItemProductTypeEnum.PROMOTION_COUPON.getCode())) {//促销活动
                            if (proType.equals(OrderItemProductTypeEnum.PROMOTION.getCode())) {
                                posOrderActivity.setPromotionId(prdBarCode);
                            } else {
                                posOrderActivity.setPromotionCouponId(prdBarCode);
                            }
                        } else if (proType.equals(OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode()) || proType.equals(OrderItemProductTypeEnum.COUPON.getCode())) {//会员活动
                            MemberActivitySon memberActivitySon = customService.select(MemberActivitySon.builder().activityId(prdBarCode).build());
                            posOrderActivity.setSubActivityId(memberActivitySon.getSubjectId());
                            posOrderActivity.setActivityId(memberActivitySon.getActivityId());
                            posOrderActivity.setCouponId(orderItemRequest.getCouponId());
                            posOrderActivity.setCoupon(orderItemRequest.getCoupon());
                        }
                        //添加到订单明细里面去
                        posOrderItemList.add(posOrderItemPo);
                        return posOrderActivity;
                    }).collect(Collectors.toList());
            //批量插入活动关联订单数据信息
            savePosActivity(posOrderActivities);
            return posOrderActivities;
        }
        return new ArrayList<>();
    }

    @Ella(Describe = "生成活动记录")
    public void saveActivityLog(List<PosOrderActivity> posOrderActivities, PosOrderPo posOrderPo) {
        if (!posOrderActivities.isEmpty()) {
            //设置订单类型
            posOrderPo.setActivityType(posOrderActivities.size() > 1 ? 6 : posOrderActivities.get(0).getActivityType());
            posOrderActivities.stream().forEach(posOrderActivity -> {
                Integer activityType = posOrderActivity.getActivityType();
                if (activityType.equals(OrderItemProductTypeEnum.COUPON.getCode()) || activityType.equals(OrderItemProductTypeEnum.PROMOTION_COUPON.getCode())) {//优惠券
                    operationCoupon(posOrderPo, posOrderActivity);
                } else if (activityType.equals(OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode())) {//积分兑换
                    createIntegralResult(posOrderActivity, posOrderPo);
                }
            });
        }
    }

    @Ella(Describe = "生成兑换活动信息", Author = "K")
    public void createIntegralResult(PosOrderActivity posOrderActivity, PosOrderPo posOrderPo) throws BizException {
        //查询会员类型
        MemberInfo memberInfo = customService.select(MemberInfo.builder().memberId(posOrderPo.getMemberId()).build());
        MemberIntegralResult integralResult = MemberIntegralResult
                .builder()
                .activityId(posOrderActivity.getActivityId())
                .convertId(IdGenerator.getSerialNo(PrefixEnum.ACTIVITY_INTEGRAL_CONVERT.getCode()))
                .counterId(posOrderPo.getCounterId())
                .createTime(LocalDateTime.now())
                .goodsQty(posOrderPo.getGoodsQty())
                .counterName(posOrderPo.getCounterName())
                .memberId(posOrderPo.getMemberId())
                .memberName(posOrderPo.getMemberName())
                .memberPhone(posOrderPo.getMemberPhone())
                .memberType(memberInfo.getMemberType())
                .operationId(posOrderPo.getBaCode())
                .operationName(posOrderPo.getBaName())
                .orderNo(posOrderPo.getOrderNo())
                .realAmt(posOrderPo.getRealAmt().toString())
                .subActivityId(posOrderActivity.getSubActivityId())
                .build();
        Integer save = customService.save(integralResult);
        if (save.equals(0)) {
            log.error("生成积分兑换记录失败");
            throw new BizException("生成积分兑换记录失败");
        }
    }

    @Ella(Describe = "获取新老积分规则", Author = "fly")
    public Integer getActivityTypeRule(List<String> activityIds) {
        if (activityIds == null || activityIds.size() == 0) {
            //现在基本用的都是新积分了
            return 1;
        }
        Integer activityTypeRule = memberActivityMapper.getActivityTypeRule(activityIds);
        return activityTypeRule == null ? 1 : activityTypeRule;
    }

    @Ella(Describe = "处理优惠券使用信息", Author = "K")
    public void operationCoupon(PosOrderPo posOrderPo, PosOrderActivity posOrderActivity) {
        //查询优惠券使用信息
        MemberCoupon memberCoupon = customService.select(MemberCoupon.builder().couponId(posOrderActivity.getCouponId()).build());
        memberCoupon.setStatus(1);
        MemberCouponResult build = MemberCouponResult
                .builder()
                .subActivityId(posOrderActivity.getSubActivityId())//会员活动填充主题活动id
                .subActivityName(memberCoupon.getSubActivityName())//会员活动填充主题活动名称
                .activityId(memberCoupon.getActivityId())//填充活动id
                .activityName(memberCoupon.getActivityName())//填充活动名称
                .counterId(posOrderPo.getCounterId())//填充柜台id
                .counterName(posOrderPo.getCounterName())//填充柜台名称
                .createTime(posOrderPo.getCreateTime())//填充创建时间
                .memberId(posOrderPo.getMemberId())//填充会员id
                .memberName(posOrderPo.getMemberName())//填充会员名称
                .memberPhone(posOrderPo.getMemberPhone())//填充会员手机号
                .memberType(memberCoupon.getMemberType())//填充会员类型
                .operationId(posOrderPo.getBaCode())//填充操作人员id
                .operationName(posOrderPo.getBaName())//填充操作人员名称
                .orderNo(posOrderPo.getOrderNo())//填充订单号
                .resultId(IdGenerator.getSerialNo(PrefixEnum.ACTIVITY_COUPON_RESULT.getCode()))//生成结果id
                .coupon(org.apache.commons.lang3.StringUtils.isBlank(memberCoupon.getCoupon()) ? null : memberCoupon.getCoupon())//填充coupon码
                .couponId(memberCoupon.getCouponId())//填充couponId
                .build();
        //进行保存
        Integer save = customService.save(build);
        if (save.equals(0)) {
            log.error("生成优惠券使用结果失败");
            throw new BizException("生成优惠券使用结果失败");
        }
        //生成日志记录
        operationCouponLog(memberCoupon, posOrderPo.getCounterId(), posOrderPo.getOrderNo());
        //修改优惠券使用状态
        Integer update = customService.update(MemberCoupon
                .builder()
                .receiveCounterId(posOrderPo.getCounterId())
                .receiveTime(TimeUtils.longFormatString(System.currentTimeMillis()))
                .status(1)
                .build(), MemberCoupon
                .builder()
                .couponId(memberCoupon.getCouponId())
                .build());
        if (update.equals(0)) {
            log.error("更新优惠券使用状态失败");
            throw new BizException("更新优惠券使用状态失败");
        }
    }

    @Ella(Describe = "生成优惠券日志信息", Author = "K")
    private void operationCouponLog(MemberCoupon memberCoupon, String counterId, String orderNo) throws BizException {
        MemberCouponLog couponLog = MemberCouponLog
                .builder()
                .subActivityId(memberCoupon.getSubActivityId())
                .subActivityName(memberCoupon.getSubActivityName())
                .activityId(memberCoupon.getActivityId())
                .activityName(memberCoupon.getActivityName())
                .counterId(counterId)
                .createTime(LocalDateTime.now())
                .id(memberCoupon.getCouponId())
                .memberId(memberCoupon.getMemberId())
                .memberName(memberCoupon.getMemberName())
                .memberPhone(memberCoupon.getMobilePhone())
                .status(memberCoupon.getStatus())
                .orderNo(orderNo)
                .build();
        Integer save = customService.save(couponLog);
        if (save.equals(0)) {
            log.error("生成优惠券使用记录失败");
            throw new BizException("生成优惠券使用记录失败");
        }
    }

    @Ella(Describe = "批量插入活动关联订单数据信息")
    private void savePosActivity(List<PosOrderActivity> posOrderActivities) {
        if (posOrderActivities != null && !posOrderActivities.isEmpty()) {
            Integer save = taskMapper.savePosActivity(posOrderActivities);
            if (!save.equals(posOrderActivities.size())) {
                log.error("插入活动关联信息表失败");
                throw new BizException("插入活动关联信息表失败");
            }
        }
    }

    @Ella(Describe = "是否是虚拟商品:是true;否false")
    public Boolean isFictitious(PosSaleOrderRequest.OrderItemRequest posOrderItemPo) {
        Integer isVirtual = posOrderItemPo.getIsVirtual();
        return isVirtual.equals(1);
    }

    @Ella(Describe = "是否是虚拟商品:是:false;否:true")
    public Boolean isNotFictitious(PosSaleOrderRequest.OrderItemRequest posOrderItemPo) {
        Integer isVirtual = posOrderItemPo.getIsVirtual();
        if (isVirtual == null) {
            log.error("商品类型没有被定义(是否是虚拟商品)");
            throw new BizException("商品类型没有被定义(是否是虚拟商品)");
        }
        return !isVirtual.equals(1);
    }
}
