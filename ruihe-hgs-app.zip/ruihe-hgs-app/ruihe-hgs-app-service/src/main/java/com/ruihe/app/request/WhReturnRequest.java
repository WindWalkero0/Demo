package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-24 10:19
 */
@ApiModel(value = "WhReturnRequest", description = "退库申请请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhReturnRequest implements Serializable {

    @ApiModelProperty(value = "申请编号,新增的时候可以为空")
    private String returnNo;

    @NotNull(message = "原因不能为空")
    @ApiModelProperty(value = "原因")
    private Integer reason;

    @NotBlank(message = "柜员编码不能为空")
    @ApiModelProperty(value = "柜员编码")
    private String baCode;

    @NotBlank(message = "柜员名称不能为空")
    @ApiModelProperty(value = "柜员名称")
    private String baName;

    @NotBlank(message = "柜台编码不能为空")
    @ApiModelProperty(value = "柜台编码")
    private String counterId;

    @NotBlank(message = "柜柜台名称不能为空")
    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "快递单号")
    private String trackingNo;

    @NotEmpty(message = "退库申请详情不能为空")
    @ApiModelProperty(value = "退库申请详情请求实体")
    @Valid
    List<WhReturnItemRequest> itemRequestList;
}
