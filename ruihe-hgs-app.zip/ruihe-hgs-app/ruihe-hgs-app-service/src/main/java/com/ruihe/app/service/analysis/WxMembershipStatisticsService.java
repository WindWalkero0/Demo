package com.ruihe.app.service.analysis;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.common.dao.mapper.WxCardInfoPoMapper;
import com.ruihe.common.enums.wx.WxSummaryEnum;
import com.ruihe.common.pojo.request.analysis.WxSummaryDetailRequest;
import com.ruihe.common.pojo.request.analysis.WxSummaryRequest;
import com.ruihe.common.pojo.response.analysis.WxSummaryDetailVo;
import com.ruihe.common.pojo.response.analysis.WxSummaryTotalVo;
import com.ruihe.common.pojo.response.analysis.WxSummaryVo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author LiangYuan
 * @descripstion 微信线上入会统计
 * @date 2020-11-10 9:13
 */
@Slf4j
@Service
public class WxMembershipStatisticsService {

    @Value("${wechat.cardId}")
    private String cardId;

    @Autowired
    private WxCardInfoPoMapper wxCardInfoPoMapper;

    /**
     * 微信线上入会小结查询页面
     *
     * @param request WxSummaryRequest
     * @return WxSummaryTotalVo
     */
    @DS(DBConst.SLAVE)
    public Response wxSummary(WxSummaryRequest request) {
        //判断时间问题
        if (request.getEndTime().isBefore(request.getStartTime())) {
            return Response.errorMsg("结束时间不能大于开始时间!");
        }
        if (request.getStartTime().plusDays(90).isBefore(request.getEndTime())) {
            return Response.errorMsg("查询区间超过90天!");
        }
        //设置参数
        request.setEndTime(request.getEndTime().plusDays(1));
        request.setCarId(cardId);
        //分页
        Page<WxSummaryVo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询
        IPage<WxSummaryVo> wxSummaryPageList = wxCardInfoPoMapper.wxSummaryList(page, request);
        List<WxSummaryVo> voList = wxSummaryPageList.getRecords();
        //查询总数
        WxSummaryTotalVo totalVo = wxCardInfoPoMapper.wxSummaryTotal(request);
        //设置返回参数
        totalVo.setVoList(voList);
        totalVo.setStartTime(request.getStartTime());
        totalVo.setEndTime(request.getEndTime());
        return Response.success(totalVo);
    }

    /**
     * 微信线上入会详情页面
     *
     * @param request WxSummaryDetailRequest
     * @return List<WxSummaryDetailVo>
     */
    @DS(DBConst.SLAVE)
    public Response wxSummaryDetail(WxSummaryDetailRequest request) {
        if (request.getType() != null && WxSummaryEnum.instance(request.getType()) == null) {
            return Response.errorMsg("类型错误!");
        }
        List<WxSummaryDetailVo> detailVoList;
        request.setCarId(cardId);
        //全部
        if (request.getType() == null) {
            List<WxSummaryDetailVo> voList = new ArrayList<>();
            Arrays.stream(WxSummaryEnum.values()).forEach(e -> {
                request.setType(e.getCode());
                List<WxSummaryDetailVo> summaryDetailVoList;
                //新会员领卡未激活
                if (e.getCode().equals(WxSummaryEnum.NEW_MEMBER_UNACTIVATED.getCode())) {
                    summaryDetailVoList = wxCardInfoPoMapper.wxNewMemberUnactivated(request);
                } else {
                    //其它情况
                    summaryDetailVoList = wxCardInfoPoMapper.wxSummaryDetail(request);
                }
                if (!summaryDetailVoList.isEmpty()) {
                    summaryDetailVoList.parallelStream().forEach(vo -> vo.setType(e.getMsg()));
                    voList.addAll(summaryDetailVoList);
                }
            });
            return Response.success(voList);
        } else if (request.getType().equals(WxSummaryEnum.NEW_MEMBER_UNACTIVATED.getCode())) {
            detailVoList = wxCardInfoPoMapper.wxNewMemberUnactivated(request);
        } else {
            detailVoList = wxCardInfoPoMapper.wxSummaryDetail(request);
        }
        return Response.success(detailVoList);
    }
}
