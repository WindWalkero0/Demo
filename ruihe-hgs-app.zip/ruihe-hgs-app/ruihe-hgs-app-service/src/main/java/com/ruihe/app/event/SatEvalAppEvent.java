package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 会员满意度评价事件
 *
 * @author LiangYuan
 * @date 2021-02-04 14:18
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SatEvalAppEvent extends ApplicationEvent {
    /**
     * 订单号、护理服务单号、月度评价单号--必填
     */
    private String orderNo;
    /**
     * 问卷类型：1销售，2服务--必填、与WxMsgTemplateEnum中的一致
     */
    private Integer satType;

    public SatEvalAppEvent(Object source, String orderNo, Integer satType) {
        super(source);
        this.orderNo = orderNo;
        this.satType = satType;
    }
}
