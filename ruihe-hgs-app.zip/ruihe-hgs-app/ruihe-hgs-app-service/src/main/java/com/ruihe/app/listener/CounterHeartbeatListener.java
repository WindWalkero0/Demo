package com.ruihe.app.listener;


import com.alibaba.fastjson.JSON;
import com.ruihe.app.event.CounterHeartbeatEvent;
import com.ruihe.app.service.heartbeat.CounterHeartbeatService;
import com.ruihe.common.constant.CommonConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * 柜台心跳事件监听
 * @author qubin
 * @date 2021/4/17
 */
@Slf4j
@Component
public class CounterHeartbeatListener {

    @Autowired
    private CounterHeartbeatService counterHeartbeatService;

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(CounterHeartbeatEvent event) {
        try{
            counterHeartbeatService.heartbeat(event.getCounterId());
        }catch (Exception e){
            log.error("柜台心跳事件监听异常", JSON.toJSONString(event), e);
        }
    }
}
