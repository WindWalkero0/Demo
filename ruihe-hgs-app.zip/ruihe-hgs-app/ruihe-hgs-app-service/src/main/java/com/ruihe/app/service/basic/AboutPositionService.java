package com.ruihe.app.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.common.dao.bean.base.Position;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.constant.DBConst;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@DS(DBConst.SLAVE)
@Service
@Ella(Describe = "岗位管理service", Author = "K")
public class AboutPositionService {

    @Autowired
    private CustomService customService;

    @Ella(Describe = "查询岗位为美导信息", Author = "K")
    public Position selectPosition() {
        return (Position) customService.select(Position
                .builder()
                .status(CommonStatusEnum.EFFECTIVE.getCode())
                .posLevel(5)
                .build());
    }
}
