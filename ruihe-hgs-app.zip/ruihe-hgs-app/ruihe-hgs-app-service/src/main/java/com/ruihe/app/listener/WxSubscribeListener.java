package com.ruihe.app.listener;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.event.WxSubscribeEvent;
import com.ruihe.app.service.wx.WxMpUserInfoService;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.dao.bean.wx.WxCardInfoPo;
import com.ruihe.common.dao.bean.wx.WxSubscribePo;
import com.ruihe.common.dao.mapper.WxCardInfoPoMapper;
import com.ruihe.common.dao.mapper.WxSubscribePoMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import me.chanjar.weixin.mp.bean.message.WxMpXmlMessage;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * 处理会员订阅
 *
 * @author LiangYuan
 * @date 2021-01-23 18:05
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class WxSubscribeListener {

    private final WxSubscribePoMapper wxSubscribePoMapper;
    private final WxCardInfoPoMapper wxCardInfoPoMapper;
    private final WxMpUserInfoService wxMpUserInfoService;

    @Value("${wechat.cardId}")
    private String cardId;

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(WxSubscribeEvent event) {
        WxMpXmlMessage msg = event.getMsg();
        WxSubscribePo subscribePo = wxSubscribePoMapper.selectOne(Wrappers.<WxSubscribePo>lambdaQuery()
                .eq(WxSubscribePo::getCardId, cardId)
                .eq(WxSubscribePo::getOpenId, msg.getFromUser()));
        WxSubscribePo wxSubscribePo = wxMpUserInfoService.extractWxSubscribePo(msg);
        //可能会出现先领卡激活再去关注的情况，所以需要对信息进行处理
        WxCardInfoPo wxCardInfoPo = wxCardInfoPoMapper.selectOne(Wrappers.<WxCardInfoPo>lambdaQuery()
                .eq(WxCardInfoPo::getCardId, cardId)
                .eq(WxCardInfoPo::getOpenId, wxSubscribePo.getOpenId()));
        if (subscribePo == null) {
            if (wxCardInfoPo != null && StringUtils.isNotBlank(wxCardInfoPo.getMemberId())) {
                this.doWxSubscribePo(wxSubscribePo, wxCardInfoPo);
            }
            wxSubscribePo.setCreateTime(LocalDateTime.now());
            try {
                wxSubscribePoMapper.insert(wxSubscribePo);
            } catch (Exception e) {
                log.error("信息处理慢,微信重发事件,重复新增数据导致唯一键冲突,wxSubscribePo={},e", wxSubscribePo, e);
            }
        } else {
            if (StringUtils.isBlank(subscribePo.getMemberId()) && wxCardInfoPo != null && StringUtils.isNotBlank(wxCardInfoPo.getMemberId())) {
                this.doWxSubscribePo(wxSubscribePo, wxCardInfoPo);
            }
            int rows = wxSubscribePoMapper.update(wxSubscribePo, Wrappers.<WxSubscribePo>lambdaUpdate()
                    .eq(WxSubscribePo::getCardId, cardId)
                    .eq(WxSubscribePo::getId, subscribePo.getId()));
            if (rows != 1) {
                log.error("获取微信用户关注公众号更新异常,subscribePo={},wxSubscribePo={}", subscribePo, wxSubscribePo);
            }
        }
    }

    /**
     * 处理信息
     *
     * @param wxSubscribePo
     * @param wxCardInfoPo
     */
    private void doWxSubscribePo(WxSubscribePo wxSubscribePo, WxCardInfoPo wxCardInfoPo) {
        wxSubscribePo.setMemberId(wxCardInfoPo.getMemberId());
        wxSubscribePo.setBindingTime(wxCardInfoPo.getActivationTime());
        if (StringUtils.isBlank(wxSubscribePo.getUnionId())) {
            wxSubscribePo.setUnionId(wxCardInfoPo.getUnionId());
        }
    }
}
