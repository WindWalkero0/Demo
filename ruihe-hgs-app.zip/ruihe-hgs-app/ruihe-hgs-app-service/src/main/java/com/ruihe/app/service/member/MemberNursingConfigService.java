package com.ruihe.app.service.member;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.common.constant.NursingConstant;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.nursing.NursingChildConfigPO;
import com.ruihe.common.dao.bean.nursing.NursingConfigPO;
import com.ruihe.common.dao.bean.nursing.NursingMemberPO;
import com.ruihe.common.dao.mapper.NursingChildConfigMapper;
import com.ruihe.common.dao.mapper.NursingConfigMapper;
import com.ruihe.common.dao.mapper.NursingMemberMapper;
import com.ruihe.common.enums.nursing.NursingMemberStatusEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.response.member.MemberNursingChildConfigResponse;
import com.ruihe.common.pojo.response.member.MemberNursingChildGroupResponse;
import com.ruihe.common.pojo.response.member.NursingMemberConfigResponse;
import com.ruihe.common.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Slf4j
@Service
public class MemberNursingConfigService {

    @Autowired
    private NursingChildConfigMapper nursingChildConfigMapper;

    @Autowired
    private NursingMemberMapper nursingMemberMapper;

    @Autowired
    private NursingConfigMapper nursingConfigMapper;

    @Autowired
    private MemberMapper memberMapper;

    public Response selectNursingConfig() {
        List<MemberNursingChildConfigResponse> collect = nursingChildConfigMapper.selectList(Wrappers.lambdaQuery(NursingChildConfigPO.class)
                .eq(NursingChildConfigPO::getStatus, NursingConstant.STATUS_EFFECTIVE)).stream()
                .map(nursingChildConfigPO -> {
                    MemberNursingChildConfigResponse build = MemberNursingChildConfigResponse.builder().build();
                    BeanUtils.copyProperties(nursingChildConfigPO, build);
                    return build;
                }).collect(Collectors.toList());
        return Response.success(collect);
    }

    /**
     * 查询列表带着大分组
     *
     * @return
     */
    public Response selectNursingConfigWithGroup() {
        List<NursingConfigPO> nursingConfigPOS = nursingConfigMapper.selectList(Wrappers.lambdaQuery(NursingConfigPO.class));
        List<NursingChildConfigPO> nursingChildConfigPOS = nursingChildConfigMapper.selectList(Wrappers.lambdaQuery(NursingChildConfigPO.class)
                .eq(NursingChildConfigPO::getStatus, NursingConstant.STATUS_EFFECTIVE));
        List<MemberNursingChildGroupResponse> collect = nursingConfigPOS.stream().map(e -> {
            MemberNursingChildGroupResponse build = MemberNursingChildGroupResponse.builder().build();
            build.setGroupName(e.getItem());
            build.setList(nursingChildConfigPOS.stream()
                    .filter(o -> o.getNursingId().equals(e.getId()))
                    .map(nursingChildConfigPO -> {
                        MemberNursingChildConfigResponse memberNursingChildConfigResponse = MemberNursingChildConfigResponse.builder().build();
                        BeanUtils.copyProperties(nursingChildConfigPO, memberNursingChildConfigResponse);
                        return memberNursingChildConfigResponse;
                    }).collect(Collectors.toList()));
            return build;
        }).collect(Collectors.toList());
        return Response.success(collect);
    }

    public Response selectNursingMemberConfig(String phone, String counterId) {

        //查询会员
        MemberInfo memberInfo = memberMapper.selectOne(Wrappers.lambdaQuery(MemberInfo.class)
                .eq(MemberInfo::getMobilePhone, phone)
                .eq(MemberInfo::getStatus, NursingConstant.STATUS_EFFECTIVE));
        if (memberInfo == null) {
            throw new BizException("会员不存在");
        }

        //查询护理会员
        NursingMemberPO nursingMemberPO = nursingMemberMapper.selectOne(Wrappers.lambdaQuery(NursingMemberPO.class)
                .eq(NursingMemberPO::getCounterId, counterId)
                .eq(NursingMemberPO::getMemberId, memberInfo.getMemberId()));
        if(nursingMemberPO == null){
            return Response.success();
        }
        if(nursingMemberPO != null && NursingMemberStatusEnum.YES.getCode().equals(nursingMemberPO.getStatus())) {
            NursingMemberConfigResponse build = NursingMemberConfigResponse.builder().status(NursingMemberStatusEnum.parse(Integer.parseInt(nursingMemberPO.getStatus())))
                    .nursingId(nursingMemberPO.getNursingId())
                    .nursingItem(nursingMemberPO.getNursingItem()).build();
            return Response.success(build);
        }
        NursingMemberConfigResponse build = NursingMemberConfigResponse.builder()
                .statusInfo("只能对已确认为“是”的护理包会员做护理服务，请核对该用户的护理包信息后重试")
                .build();
        return Response.success(build);
    }
}
