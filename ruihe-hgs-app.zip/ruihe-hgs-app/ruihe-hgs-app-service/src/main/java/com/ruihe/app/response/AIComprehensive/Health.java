package com.ruihe.app.response.AIComprehensive;

import lombok.Data;

@Data
public class Health {
    private String label;
    private Integer level;
    private String levelName;
}
