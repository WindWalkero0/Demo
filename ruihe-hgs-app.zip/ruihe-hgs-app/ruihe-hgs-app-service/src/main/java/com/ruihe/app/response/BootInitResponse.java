package com.ruihe.app.response;

import com.ruihe.app.dto.PosUpgradeDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@ApiModel(value = "BootInitResponse", description = "app启动初始化响应实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BootInitResponse implements Serializable {

    @ApiModelProperty(value = "升级配置")
    private PosUpgradeDto upgrade;
}
