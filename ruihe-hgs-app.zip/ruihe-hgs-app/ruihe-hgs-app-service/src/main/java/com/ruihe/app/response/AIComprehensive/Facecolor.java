package com.ruihe.app.response.AIComprehensive;

import lombok.Data;
@Data
public class Facecolor {
    private String propertyChinese;
    private String description;
}
