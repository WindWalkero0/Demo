package com.ruihe.app.enums;

import org.springframework.util.StringUtils;

/**
 * @author huangjie
 * @description
 * @date 2021-04-30 13:29
 */
public enum WxWeekDayEnum {
    /**
     * 获取周几
     */
    MONDAY(1, "周一"),
    TUESDAY(2, "周二"),
    WEDNESDAY(3, "周三"),
    THURSDAY(4, "周四"),
    FRIDAY(5, "周五"),
    SATURDAY(6, "周六"),
    SUNDAY(7, "周日");

    private Integer code;
    private String msg;


    WxWeekDayEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static WxWeekDayEnum instance(Integer key) {
        if (key == null) {
            return null;
        }
        for (WxWeekDayEnum e : values()) {
            if (e.getCode().equals(key)) {
                return e;
            }
        }
        return null;
    }

    public static WxWeekDayEnum getString(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (WxWeekDayEnum e : values()) {
            if (e.getMsg().equals(value)) {
                return e;
            }
        }
        return null;
    }
}
