package com.ruihe.app.response.AIComprehensive;

import lombok.Data;

@Data
public  class SkinInfo {
    private String skinType;
    private String sensitivity;
    private String facecolor;
    private Integer skinAge;
}
