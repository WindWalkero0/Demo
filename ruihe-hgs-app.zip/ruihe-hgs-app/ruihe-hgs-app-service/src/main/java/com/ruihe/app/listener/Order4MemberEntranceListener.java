package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.member.*;
import com.ruihe.app.service.member.MemberService;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.member.MemberLevel;
import com.ruihe.common.dao.bean.member.MemberLevelDownPo;
import com.ruihe.common.dao.bean.member.MemberLevelLog;
import com.ruihe.common.dao.bean.member.MemberLevelRulePo;
import com.ruihe.common.dao.bean.member.MemberLevelUpPo;
import com.ruihe.common.dao.bean.member.MemberRule;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.enums.member.MemberLevelEnum;
import com.ruihe.common.enums.member.MemberLevelRuleTypeEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.service.event.OnlyAddCouponEvent;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.event.Order4IntegralEvent;
import com.ruihe.app.event.Order4MemberEntranceEvent;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.common.constant.CommonConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * @author 梁远
 * @version 1.0.1
 * 1、2020-02-29 18:38 产品经理确认，补录的按照单据的时间（createTime）计算，所以，等级中所有时间业务以此为准
 * 2、2020-06-04 11:49 产品经理确认，退货影响等级的时候：等级开始时间为：时间查单退货的那笔订单购买时间；用户升级的订单购买时间
 * @Description 会员入会等级处理
 * @create 2019-11-14 15:09
 */
@Slf4j
@Component
public class Order4MemberEntranceListener implements ApplicationContextAware {


    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private MemberRuleMapper memberRuleMapper;

    @Autowired
    private MemberService memberService;

    @Autowired
    private MemberLevelRuleMapper memberLevelRuleMapper;

    @Autowired
    private MemberLevelUpMapper memberLevelUpMapper;

    @Autowired
    private MemberLevelDownMapper memberLevelDownMapper;

    @Autowired
    private MemberLevelLogMapper memberLevelLogMapper;

    @Autowired
    private MemberLevelMapper memberLevelMapper;

    @Autowired
    private MemberMapper memberMapper;

    private ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(Order4MemberEntranceEvent event) {
        try {
            //处理会员等级升降级//重新对活动进行匹配发券
            this.doChangeMemberLevel(event);
            var memberId = event.getMemberId();
            if (StringUtils.isNotBlank(memberId)) {
                //8、用户购买完以后判断是否有需要发下的优惠券并下发
                OnlyAddCouponEvent onlyAddCouponEvent = new OnlyAddCouponEvent(memberId);
                this.applicationContext.publishEvent(onlyAddCouponEvent);
                //会员销售处理积分
                Order4IntegralEvent order4IntegralEvent = new Order4IntegralEvent(this, event.getOrderNo());
                this.applicationContext.publishEvent(order4IntegralEvent);
            }
        } catch (Exception e) {
            log.error("会员销售处理等级业务处理异常，event{}", JSON.toJSONString(event), e);
        }
    }

    /**
     * 会员等级处理
     *
     * @param event
     */
    private void doChangeMemberLevel(Order4MemberEntranceEvent event) {
        //1、获取会员信息
        MemberInfo memberInfo = memberMapper.selectOne(Wrappers.<MemberInfo>lambdaQuery().eq(MemberInfo::getMemberId, event.getMemberId()));
        //2、根据单号查询订单信息
        PosOrderPo posOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                .eq(PosOrderPo::getOrderNo, event.getOrderNo()));
        //3、定义一个会员当前等级信息，用于判断该会员等级(不是时间)是否发生改变（是否需要走重新发券的接口）
        String memberLevelCode = memberInfo.getMemberLevelCode();
        //4、判断是否是退货
        if (posOrderPo.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
            //1）如果是空退，则不需要处理
            if (StringUtils.isBlank(posOrderPo.getPreOrderNo())) {
                return;
            }
            //2）如果是体验会员，则退货不影响等级
            if (memberInfo.getMemberLevel().equals(MemberLevelEnum.EXPERIENCED_MEMBER.getKey())) {
                return;
            }
            //3）根据前置单据号查询等级修改履历信息
            MemberLevelLog memberLevelLog = getMemberLevelLogByPreNo(memberInfo, posOrderPo.getPreOrderNo());
            if (memberLevelLog == null) {
                //如果根据订单号未查询到等级履历信息，则需要去判断是否影响保级
                dealRegulation(posOrderPo, memberInfo, memberLevelCode);
                return;
            }
            /**
             * 不满足，进行降级处理（到service中处理），生成一条降级记录
             * 2020-02-20 15:10 跟产品经理&&测试 确认:此处取该会员目前的等级，而非影响该订单的等级
             * 2020-06-01 14:45 与产品经理确认:会员首单买（升级）-退（降级)-再买（这一单不算首单）
             * 2020-06-01 14:49与产品经理确认:会员到期之前买了一笔达到保级条件，在保级之后退货，需要进行降级处理(放在上面代码中进行判断)
             */
            //4）以上条件都不满足的话，说明该订单退货影响到了会员等级
            dealLevelDownUp(memberInfo, memberLevelLog, posOrderPo);
            //5）最后，更新会员信息
            if (memberInfo.getMemberLevelCode().equals(memberLevelCode)) {
                //如果会员等级未发生改变，
                memberService.updateMemberInfoNoCoupon(memberInfo, posOrderPo.getOrderNo());
            } else {
                memberService.updateMemberInfo(memberInfo, posOrderPo.getOrderNo());
            }
            return;
        }
        //5、如果不是退货，则为正常销售，需要判断为首单入会规则，还是升降级规则
        Integer count = posOrderMapper.selectCount(Wrappers.<PosOrderPo>lambdaQuery()
                .eq(PosOrderPo::getMemberId, memberInfo.getMemberId())
                .ne(PosOrderPo::getOrderNo, event.getOrderNo()));
        //6、如果是大于0的话，则说明是升降级的规则
        if (count > 0) {
            //2)根据会员等级，查询升降级规则
            MemberLevelRulePo memberLevelRulePo = memberLevelRuleMapper.selectOne(Wrappers.<MemberLevelRulePo>lambdaQuery()
                    .eq(MemberLevelRulePo::getLevelCode, memberInfo.getMemberLevelCode())
                    .eq(MemberLevelRulePo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                    .ge(MemberLevelRulePo::getEndTime, LocalDateTime.now()).le(MemberLevelRulePo::getStartTime, LocalDateTime.now()));
            /**
             * 1)如果是最高级会员，则不进行等级升级判断
             * 2)如果没有适用的升级规则，直接返回
             * 3)如果该等级存在升级规则，则进行判断，否则直接返回
             */
            if (memberInfo.getMemberLevel().equals(MemberLevelEnum.PEONY_MEMBER.getKey()) || memberLevelRulePo == null) {
                return;
            }
            //3)根据主表查询升级规则，并按照升级后的等级降序排序
            List<MemberLevelUpPo> upPoList = memberLevelUpMapper.selectList(Wrappers.<MemberLevelUpPo>lambdaQuery()
                    .eq(MemberLevelUpPo::getRuleId, memberLevelRulePo.getRuleId())
                    .orderByDesc(MemberLevelUpPo::getAfterLevel));
            if (upPoList.isEmpty()) {
                return;
            }
            //5)对等级规则循环处理
            doMemberInfoAndLevel(memberInfo, memberLevelCode, memberLevelRulePo, upPoList, posOrderPo);
        } else {
            //根据条件查询会员入会规则，为了防止查出多条数据，此处按照等级级别倒序排序并取最后一个
            MemberRule memberRule = memberRuleMapper.selectOne(Wrappers.<MemberRule>lambdaQuery()
                    .eq(MemberRule::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                    .le(MemberRule::getFromAmt, posOrderPo.getRealAmt())
                    .gt(MemberRule::getToAmt, posOrderPo.getRealAmt())
                    .ge(MemberRule::getEndTime, LocalDateTime.now())
                    .le(MemberRule::getStartTime, LocalDateTime.now())
                    .orderByDesc(MemberRule::getLevel)
                    .last(" limit 1 "));
            if (memberRule == null) {
                return;
            }
            //判定查出的会员等级级别是否高于默认会员等级
            if (memberRule.getLevel() > memberInfo.getMemberLevel()) {
                MemberLevel memberLevel = memberLevelMapper.selectOne(Wrappers.<MemberLevel>lambdaQuery()
                        .eq(MemberLevel::getLevelCode, memberRule.getLevelCode()));
                //更新会员等级信息
                memberInfo.setMemberLevel(memberRule.getLevel());
                memberInfo.setMemberLevelCode(memberRule.getLevelCode());
                memberInfo.setMemberLevelName(memberRule.getLevelName());
                memberInfo.setLevelStartTime(posOrderPo.getCreateTime());
                memberInfo.setLevelEndTime(memberLevel.getDuration() == 0 ? parseTime() : posOrderPo.getCreateTime().plusMonths(memberLevel.getDuration()));
                memberInfo.setUpdateTime(LocalDateTime.now());
                memberService.updateMemberLevel(memberRule, event.getOrderNo(), memberInfo);
            }
        }
    }

    /**
     * 对等级规则循环处理，判断是否升级
     *
     * @param memberInfo
     * @param memberLevelCode
     * @param memberLevelRulePo
     * @param upPoList
     * @param posOrderPo
     */
    private void doMemberInfoAndLevel(MemberInfo memberInfo, String memberLevelCode, MemberLevelRulePo memberLevelRulePo, List<MemberLevelUpPo> upPoList, PosOrderPo posOrderPo) {
        //遍历循环，即使有多个满足条件，也只取第一个升级规则
        for (MemberLevelUpPo memberLevelUpPo : upPoList) {
            //判断单次购买:购买金额处于区间，而且当前等级小于升级后等级
            if (memberLevelUpPo.getSingle().equals(CommonStatusEnum.EFFECTIVE.getCode()) && memberLevelUpPo.getFromAmt().compareTo(posOrderPo.getRealAmt()) <= 0
                    && memberLevelUpPo.getToAmt().compareTo(posOrderPo.getRealAmt()) > 0 && memberInfo.getMemberLevel() < memberLevelUpPo.getAfterLevel()) {
                //填充会员信息
                fillMemberInfo(memberInfo, memberLevelUpPo, posOrderPo);
                //升级处理
                memberService.upMemberLevel(memberLevelRulePo, memberInfo, posOrderPo.getOrderNo(), memberLevelUpPo.getDescription(), memberLevelCode);
                //跳出循环
                break;
            } else if (memberLevelUpPo.getAcc() != null && memberLevelUpPo.getAcc().equals(CommonStatusEnum.EFFECTIVE.getCode())
                    && memberInfo.getMemberLevel() < memberLevelUpPo.getAfterLevel()) {
                //累计购买：当前等级小于升级后等级
                //1、获取当前等级履历信息
                MemberLevelLog memberLevelLog = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                        .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                        .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
                //2、查询订单：会员手机号、订单时间范围、是否包含首单（此处查询结果不会为空，因为执行此操作之前，支付已经完成了）
                LambdaQueryWrapper<PosOrderPo> queryWrapper = Wrappers.<PosOrderPo>lambdaQuery()
                        .eq(PosOrderPo::getMemberId, memberInfo.getMemberId())
                        .gt(PosOrderPo::getCreateTime, memberInfo.getLevelStartTime())
                        .lt(PosOrderPo::getCreateTime, LocalDateTime.now());
                if (memberLevelLog != null && StringUtils.isNotBlank(memberLevelLog.getOddNumbers()) && memberLevelUpPo.getIncludeFirst().equals(CommonStatusEnum.EFFECTIVE.getCode())) {
                    //不为空，才需要进行是否首单的判断
                    queryWrapper.or().eq(PosOrderPo::getOrderNo, memberLevelLog.getOddNumbers());
                }
                //3、获取订单的列表
                List<PosOrderPo> posOrderPoList = posOrderMapper.selectList(queryWrapper);
                //4、判断连续n月是否为空
                if (memberLevelUpPo.getDuration() == null || memberLevelUpPo.getDuration() == 0) {
                    //获取支付总金额
                    BigDecimal payTotalAmt = posOrderPoList.stream().map(e -> {
                        if (e.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                            return e.getRealAmt().abs().negate();
                        } else {
                            return e.getRealAmt().abs();
                        }
                    }).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
                    //如果支付金额大于设置累计金额
                    if (payTotalAmt.compareTo(memberLevelUpPo.getAccFromAmt()) >= 0) {
                        //填充会员信息
                        fillMemberInfo(memberInfo, memberLevelUpPo, posOrderPo);
                        //升级处理
                        memberService.upMemberLevel(memberLevelRulePo, memberInfo, posOrderPo.getOrderNo(), memberLevelUpPo.getDescription(), memberLevelCode);
                        //结束循环遍历
                        break;
                    }
                } else {
                    //获取支付总金额
                    BigDecimal payTotalAmt;
                    //升级的时间大于连续n月
                    if (memberInfo.getLevelStartTime().plusMonths(memberLevelUpPo.getDuration()).isBefore(posOrderPo.getCreateTime())) {
                        payTotalAmt = posOrderPoList.isEmpty() ? BigDecimal.ZERO : getTotalPay(posOrderPoList, memberLevelUpPo.getDuration());
                    } else {
                        //连续n月大于升级时间
                        payTotalAmt = posOrderPoList.stream().map(e -> {
                            if (e.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                                return e.getRealAmt().abs().negate();
                            } else {
                                return e.getRealAmt().abs();
                            }
                        }).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
                    }
                    //如果支付金额大于设置累计金额
                    if (payTotalAmt.compareTo(memberLevelUpPo.getAccFromAmt()) >= 0) {
                        //填充会员信息
                        fillMemberInfo(memberInfo, memberLevelUpPo, posOrderPo);
                        //升级处理
                        memberService.upMemberLevel(memberLevelRulePo, memberInfo, posOrderPo.getOrderNo(), memberLevelUpPo.getDescription(), memberLevelCode);
                        //结束循环遍历
                        break;
                    }
                }
            }
        }
    }

    /**
     * 由于销售退货对会员等级进行重新计算
     *
     * @param memberInfo     会员信息
     * @param memberLevelLog 根据前置订单查询到的等级履历信息
     * @param posOrderPo     当前的订单信息
     */
    private void dealLevelDownUp(MemberInfo memberInfo, MemberLevelLog memberLevelLog, PosOrderPo posOrderPo) {
        //1、根据等级履历信息查询到前一条等级履历信息
        MemberLevelLog preMemberLevelLog = getPreMemberLevelLog(memberLevelLog);
        //2、将会员等级降级
        memberInfo = downMemberInfo(memberInfo, preMemberLevelLog);
        //3、设置会员履历信息
        memberService.downMemberLevelLog(memberLevelLog, posOrderPo.getOrderNo(), memberInfo);
        //4、查询会员消费订单信息，排除退货相关
        List<PosOrderPo> orderList = posOrderMapper.selectOrderList(memberInfo.getMemberId(), memberLevelLog.getLevelStartTime(), posOrderPo.getCreateTime());
        //5、循环处理(2020-06-01 14:45 与产品经理确认，会员首单买（升级）-退（降级)-再买（这一单不算首单）)
        if (!orderList.isEmpty()) {
            for (PosOrderPo po : orderList) {
                //判断是否进行升降级
                MemberLevelUpPo levelUpPo = getMemberLevelUpPo(memberInfo, po);
                if (levelUpPo != null) {
                    //更改会员信息
                    memberInfo = editMemberInfo(levelUpPo, memberInfo, po);
                    //插入履历信息
                    memberService.insertMemberLog(memberInfo, po.getOrderNo(), levelUpPo);
                }
            }
        }
    }

    /**
     * 退货-会员等级降级为之前等级信息
     *
     * @param memberInfo
     * @param preMemberLevelLog
     * @return
     */
    private MemberInfo downMemberInfo(MemberInfo memberInfo, MemberLevelLog preMemberLevelLog) {
        LocalDateTime now = LocalDateTime.now();
        //填充会员信息
        memberInfo.setMemberLevel(preMemberLevelLog.getLevelAfter());
        memberInfo.setMemberLevelCode(preMemberLevelLog.getLevelCodeAfter());
        memberInfo.setMemberLevelName(preMemberLevelLog.getLevelNameAfter());
        memberInfo.setLevelStartTime(preMemberLevelLog.getLevelStartTime());
        memberInfo.setLevelEndTime(preMemberLevelLog.getLevelEndTime());
        memberInfo.setUpdateTime(now);
        return memberInfo;
    }

    /**
     * 根据指定的履历信息获取到前一条履历信息
     *
     * @param memberLevelLog
     * @return
     */
    private MemberLevelLog getPreMemberLevelLog(MemberLevelLog memberLevelLog) {
        return memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                .eq(MemberLevelLog::getMemberId, memberLevelLog.getMemberId())
                .lt(MemberLevelLog::getCreateTime, memberLevelLog.getCreateTime())
                .orderByDesc(MemberLevelLog::getCreateTime)
                .last(" limit 1"));
    }

    /**
     * 根据前置订单号查询会员等级履历信息
     *
     * @param memberInfo
     * @param preOrderNo
     * @return
     */
    private MemberLevelLog getMemberLevelLogByPreNo(MemberInfo memberInfo, String preOrderNo) {
        return memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getOddNumbers, preOrderNo)
                //为了防止出现两条一样的关联单号，需要取最新的一条
                .orderByDesc(MemberLevelLog::getCreateTime)
                .last(" limit 1"));
    }

    /**
     * 保级之后退货的判断
     * 2020-06-01 14:49与产品经理确认:会员等级到期之前买了一笔达到保级条件，在保级之后退货，需要进行降级处理
     * 2020-06-02 9:25 产品经理确认：会员等级到期之前买了一笔保级了，然后又买了一笔升级了，然后将保级的那笔订单退货，此时需要重新判断等级
     * 2020-06-02 9:35 与产品经理确认，会员到期之后只会降一级
     *
     * @param posOrderPo      当前订单信息
     * @param memberInfo      当前会员信息
     * @param memberLevelCode 当前会员等级
     */
    private void dealRegulation(PosOrderPo posOrderPo, MemberInfo memberInfo, String memberLevelCode) {
        //查询前置订单信息
        PosOrderPo preOrder = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                .eq(PosOrderPo::getOrderNo, posOrderPo.getPreOrderNo()));
        //1、查询最近的一次保级记录
        MemberLevelLog logRegulation = posOrderMapper.selectRegulation(memberInfo.getMemberId());
        if (logRegulation == null) {
            //没有保级记录说明退货不影响等级
            return;
        }
        //2、获取保级之前的等级记录(此记录是会员保级之前的判断)
        MemberLevelLog logBefore = getPreMemberLevelLog(logRegulation);
        //3、查询该订单是否落在了保级的时间段内
        if (preOrder.getCreateTime().isBefore(logBefore.getLevelStartTime()) || preOrder.getCreateTime().isAfter(logBefore.getLevelEndTime())) {
            return;
        }
        //4、根据规则的id和会员等级查询降级子表（2020-06-02 9:35 与产品经理确认，会员到期之后只会降一级）
        MemberLevelRulePo memberLevelRulePo = memberLevelRuleMapper.selectOne(Wrappers.<MemberLevelRulePo>lambdaQuery()
                .eq(MemberLevelRulePo::getLevelCode, logBefore.getLevelCodeAfter())
                .eq(MemberLevelRulePo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                .ge(MemberLevelRulePo::getEndTime, LocalDateTime.now())
                .le(MemberLevelRulePo::getStartTime, LocalDateTime.now()));
        //5、如果在该时间段内没有对应的升降级数据，则不处理，直接返回
        if (memberLevelRulePo == null) {
            return;
        }
        //6、根据主表查询降级规则
        MemberLevelDownPo memberLevelDownPo = memberLevelDownMapper.selectOne(Wrappers.<MemberLevelDownPo>lambdaQuery()
                .eq(MemberLevelDownPo::getRuleId, memberLevelRulePo.getRuleId()));
        if (memberLevelDownPo == null) {
            //如果该等级不存在降级规则，直接返回
            log.error("未查询到该会员的降级规则||降级规则子表信息不全，请检查!会员id：{}，降级规则id为：{}", memberInfo.getMemberId(), logBefore.getRuleId());
            return;
        }
        //7、判断是否已经进行过了保级的判断
        if (isRegulation(memberInfo, memberLevelDownPo, logRegulation, logBefore)) {
            return;
        }
        //8、如果在时间段内，重新进行保级的判断，获取在等级时间段内的累计支付金额
        BigDecimal totalAmt = posOrderMapper.sumPayAmt(memberInfo.getMemberId(), logBefore.getLevelStartTime(), logBefore.getLevelEndTime());
        if (totalAmt.compareTo(memberLevelDownPo.getAccAmt()) >= 0) {
            return;
        }
        //9、如果不能保级，则进行等级履历和会员信息的更新
        fillRegulationMemberInfo(memberInfo, memberLevelDownPo, logRegulation);
        memberService.regulationMemberLevelLog(memberInfo, memberLevelDownPo, posOrderPo);
        //10、判断保级之后，有没有有效订单(需要排除退货相关的订单,在订单时间范围内，去掉销售关联的退货（两单都去掉），如果只有退货没有销售，则保留)
        List<PosOrderPo> posOrderPoList = posOrderMapper.selectAllOrderList(memberInfo.getMemberId(), logRegulation.getLevelStartTime(), posOrderPo.getCreateTime());
        if (posOrderPoList.isEmpty()) {
            if (memberInfo.getMemberLevelCode().equals(memberLevelCode)) {
                memberService.updateMemberInfoNoCoupon(memberInfo, posOrderPo.getOrderNo());
            } else {
                memberService.updateMemberInfo(memberInfo, posOrderPo.getOrderNo());
            }
            return;
        }
        //11、循环处理
        for (PosOrderPo po : posOrderPoList) {
            //此处按照订单类型分开处理,如果是退货，则进行保级判断(排除已经判断的订单?--单据号+保级记录的下一条是不是降级)和升降级判断
            if (po.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode()) && StringUtils.isNotBlank(po.getPreOrderNo())) {
                //正常情况下不会存在在保级之后到该订单之间只存在关联退货，不存在销售的情况，此处如果有退货，应该是退保级时间内的订单
                doRegulationAndLevel(po, memberInfo);
            } else {
                //如果是销售，则进行升级判断（一定不是首单）
                doLevelUpdate(po, memberInfo);
            }
        }
        //最后更新会员等级信息
        if (memberInfo.getMemberLevelCode().equals(memberLevelCode)) {
            memberService.updateMemberInfoNoCoupon(memberInfo, posOrderPo.getOrderNo());
        } else {
            memberService.updateMemberInfo(memberInfo, posOrderPo.getOrderNo());
        }
    }

    /**
     * 判断是否已经进行过保级--降级操作了
     *
     * @param memberInfo
     * @param memberLevelDownPo
     * @param logRegulation
     * @param logBefore
     * @return
     */
    private boolean isRegulation(MemberInfo memberInfo, MemberLevelDownPo memberLevelDownPo, MemberLevelLog logRegulation, MemberLevelLog logBefore) {
        //获取到降级之后的等级是不满足保级的降级的所有信息
        List<MemberLevelLog> memberLevelLogList = memberLevelLogMapper.selectList(Wrappers.<MemberLevelLog>lambdaQuery()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getLevelCodeAfter, memberLevelDownPo.getAfterLevelCode())
                .eq(MemberLevelLog::getChangeType, MemberLevelRuleTypeEnum.DOWNGRADE.getKey())
                .gt(MemberLevelLog::getCreateTime, logRegulation.getCreateTime())
                .orderByAsc(MemberLevelLog::getCreateTime));
        if (memberLevelLogList.isEmpty()) {
            return false;
        }
        //循环处理
        for (MemberLevelLog memberLevelLog : memberLevelLogList) {
            if (StringUtils.isNotBlank(memberLevelLog.getOddNumbers())) {
                //根据关联单号查找订单
                PosOrderPo oddNo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                        .eq(PosOrderPo::getOrderNo, memberLevelLog.getOddNumbers()));
                if (oddNo.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode()) && StringUtils.isNotBlank(oddNo.getPreOrderNo())) {
                    PosOrderPo preOrder = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                            .eq(PosOrderPo::getOrderNo, oddNo.getPreOrderNo()));
                    if (preOrder.getCreateTime().isAfter(logBefore.getLevelStartTime()) && preOrder.getCreateTime().isBefore(logBefore.getLevelEndTime())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * 会员销售---升级判断
     *
     * @param po
     * @param memberInfo
     */
    private void doLevelUpdate(PosOrderPo po, MemberInfo memberInfo) {
        //如果是最高级会员，则不进行等级升级判断
        if (memberInfo.getMemberLevel().equals(MemberLevelEnum.PEONY_MEMBER.getKey())) {
            return;
        }
        //根据会员等级，查询升降级规则
        MemberLevelRulePo memberLevelRulePo = memberLevelRuleMapper.selectOne(Wrappers.<MemberLevelRulePo>lambdaQuery()
                .eq(MemberLevelRulePo::getLevelCode, memberInfo.getMemberLevelCode())
                .eq(MemberLevelRulePo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                .ge(MemberLevelRulePo::getEndTime, LocalDateTime.now())
                .le(MemberLevelRulePo::getStartTime, LocalDateTime.now()));
        if (memberLevelRulePo == null) {
            //如果没有适用的升级规则，直接返回
            return;
        }
        //根据主表查询升级规则，并按照升级后的等级降序排序
        List<MemberLevelUpPo> upPoList = memberLevelUpMapper.selectList(Wrappers.<MemberLevelUpPo>lambdaQuery()
                .eq(MemberLevelUpPo::getRuleId, memberLevelRulePo.getRuleId())
                .orderByDesc(MemberLevelUpPo::getAfterLevel));
        //如果该等级存在升级规则，则进行判断，否则直接返回
        if (upPoList.isEmpty()) {
            return;
        }
        //遍历循环，即使有多个满足条件，也只取第一个升级规则
        for (MemberLevelUpPo memberLevelUpPo : upPoList) {
            //判断单次购买:购买金额处于区间，而且当前等级小于升级后等级
            if (memberLevelUpPo.getSingle().equals(CommonStatusEnum.EFFECTIVE.getCode()) && memberLevelUpPo.getFromAmt().compareTo(po.getRealAmt()) <= 0
                    && memberLevelUpPo.getToAmt().compareTo(po.getRealAmt()) >= 0 && memberInfo.getMemberLevel() < memberLevelUpPo.getAfterLevel()) {
                //填充会员信息
                fillMemberInfo(memberInfo, memberLevelUpPo, po);
                //升级处理
                memberService.upSalesMemberLevel(memberLevelRulePo, memberInfo, po.getOrderNo(), memberLevelUpPo.getDescription());
                //跳出循环
                break;
            } else if (memberLevelUpPo.getAcc() != null && memberLevelUpPo.getAcc().equals(CommonStatusEnum.EFFECTIVE.getCode())
                    && memberInfo.getMemberLevel() < memberLevelUpPo.getAfterLevel()) {
                //累计购买：当前等级小于升级后等级
                //1、获取当前等级的时间，有可能查询出多个，需要取最近的一个
                MemberLevelLog memberLevelLog = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                        .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                        .eq(MemberLevelLog::getLevelAfter, memberLevelRulePo.getLevel())
                        .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
                //2、查询订单：会员手机号、订单时间范围、是否包含首单（此处查询结果不会为空，因为执行此操作之前，支付已经完成了）
                LambdaQueryWrapper<PosOrderPo> queryWrapper = Wrappers.<PosOrderPo>lambdaQuery()
                        .eq(PosOrderPo::getMemberId, memberInfo.getMemberId())
                        .gt(PosOrderPo::getCreateTime, memberInfo.getLevelStartTime())
                        .lt(PosOrderPo::getCreateTime, LocalDateTime.now());
                if (memberLevelLog != null && StringUtils.isNotBlank(memberLevelLog.getOddNumbers()) && memberLevelUpPo.getIncludeFirst().equals(CommonStatusEnum.EFFECTIVE.getCode())) {
                    //不为空，才需要进行是否首单的判断
                    queryWrapper.or().eq(PosOrderPo::getOrderNo, memberLevelLog.getOddNumbers());
                }
                //3、获取订单的列表
                List<PosOrderPo> posOrderPoList = posOrderMapper.selectList(queryWrapper);
                //4、判断连续n月是否为空
                if (memberLevelUpPo.getDuration() == null || memberLevelUpPo.getDuration() == 0) {
                    //获取支付总金额
                    BigDecimal payTotalAmt = posOrderPoList.stream().map(e -> {
                        if (e.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                            return e.getRealAmt().abs().negate();
                        } else {
                            return e.getRealAmt().abs();
                        }
                    }).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
                    //如果支付金额大于设置累计金额
                    if (payTotalAmt.compareTo(memberLevelUpPo.getAccFromAmt()) >= 0) {
                        //填充会员信息
                        fillMemberInfo(memberInfo, memberLevelUpPo, po);
                        //升级处理
                        memberService.upSalesMemberLevel(memberLevelRulePo, memberInfo, po.getOrderNo(), memberLevelUpPo.getDescription());
                        //结束循环遍历
                        break;
                    }
                } else {
                    //获取支付总金额
                    BigDecimal payTotalAmt;
                    //升级的时间大于连续n月
                    if (memberInfo.getLevelStartTime().plusMonths(memberLevelUpPo.getDuration()).isBefore(po.getCreateTime())) {
                        payTotalAmt = posOrderPoList.isEmpty() ? BigDecimal.ZERO : getTotalPay(posOrderPoList, memberLevelUpPo.getDuration());
                    } else {
                        //连续n月大于升级时间
                        payTotalAmt = posOrderPoList.stream().map(e -> {
                            if (e.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                                return e.getRealAmt().abs().negate();
                            } else {
                                return e.getRealAmt().abs();
                            }
                        }).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
                    }
                    //如果支付金额大于设置累计金额
                    if (payTotalAmt.compareTo(memberLevelUpPo.getAccFromAmt()) >= 0) {
                        //填充会员信息
                        fillMemberInfo(memberInfo, memberLevelUpPo, po);
                        //升级处理
                        memberService.upSalesMemberLevel(memberLevelRulePo, memberInfo, po.getOrderNo(), memberLevelUpPo.getDescription());
                        //结束循环遍历
                        break;
                    }
                }
            }
        }
    }

    /**
     * ,如果是退货，则进行保级判断(排除已经判断的订单?--单据号+保级记录的下一条是不是降级)和升降级判断
     *
     * @param posOrderPo
     * @param memberInfo
     */
    private void doRegulationAndLevel(PosOrderPo posOrderPo, MemberInfo memberInfo) {
        //1、如果此时已经是体验会员了，还是退货的话，不需要进行处理了
        if (memberInfo.getMemberLevel().equals(MemberLevelEnum.EXPERIENCED_MEMBER.getKey())) {
            return;
        }
        //2、查询前置订单
        PosOrderPo preOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                .eq(PosOrderPo::getOrderNo, posOrderPo.getPreOrderNo()));
        //3、查询最近的一次保级记录
        MemberLevelLog logRegulation = posOrderMapper.selectRegulation(memberInfo.getMemberId());
        //4、获取保级之前的等级记录(此记录是会员保级之前的判断)
        MemberLevelLog logBefore = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .lt(MemberLevelLog::getCreateTime, logRegulation.getCreateTime())
                .orderByDesc(MemberLevelLog::getCreateTime)
                .last(" limit 1 "));
        //5、查询该订单是否落在了保级的时间段内，不在则进行降级处理
        if (preOrderPo.getCreateTime().isBefore(logBefore.getLevelStartTime()) || preOrderPo.getCreateTime().isAfter(logBefore.getLevelEndTime())) {
            //正常情况下不会存在在保级之后到该订单之间只存在关联退货，不存在销售的情况，因为上面这个订单是查询保级之后的所有订单
            dealRegulationReturnDown(posOrderPo, memberInfo);
            return;
        }
        //6、根据规则的id和会员等级查询降级子表（2020-06-02 9:35 与产品经理确认，会员到期之后只会降一级）
        MemberLevelRulePo memberLevelRulePo = memberLevelRuleMapper.selectOne(Wrappers.<MemberLevelRulePo>lambdaQuery()
                .eq(MemberLevelRulePo::getLevelCode, memberInfo.getMemberLevelCode())
                .eq(MemberLevelRulePo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                .ge(MemberLevelRulePo::getEndTime, LocalDateTime.now())
                .le(MemberLevelRulePo::getStartTime, LocalDateTime.now()));
        //7、如果在该时间段内没有对应的升降级数据，则不处理，直接返回
        if (memberLevelRulePo == null) {
            return;
        }
        //8、根据主表查询降级规则
        MemberLevelDownPo memberLevelDownPo = memberLevelDownMapper.selectOne(Wrappers.<MemberLevelDownPo>lambdaQuery()
                .eq(MemberLevelDownPo::getRuleId, memberLevelRulePo.getRuleId()));
        if (memberLevelDownPo == null) {
            //如果该等级不存在降级规则，直接返回
            log.error("未查询到该会员的降级规则||降级规则子表信息不全，请检查!会员id：{}，降级规则id为：{}", memberInfo.getMemberId(), logBefore.getRuleId());
            return;
        }
        //9、判断是否已经进行过了保级的判断
        if (isRegulation(memberInfo, memberLevelDownPo, logRegulation, logBefore)) {
            return;
        }
        //10、如果在时间段内，重新进行保级的判断，获取在等级时间段内的累计支付金额
        BigDecimal totalAmt = posOrderMapper.sumPayAmt(memberInfo.getMemberId(), logBefore.getLevelStartTime(), logBefore.getLevelEndTime());
        if (totalAmt.compareTo(memberLevelDownPo.getAccAmt()) >= 0) {
            return;
        }
        //11、如果不能保级，则进行等级履历和会员信息的更新
        fillRegulationMemberInfo(memberInfo, memberLevelDownPo, logRegulation);
    }

    /**
     * 保级--降级之后，对退货单处理
     *
     * @param posOrderPo
     * @param memberInfo
     */
    private void dealRegulationReturnDown(PosOrderPo posOrderPo, MemberInfo memberInfo) {
        //1、根据前置单据号查询等级修改履历信息(正常情况下不会存在在保级之后到该订单之间只存在关联退货，不存在销售的情况)
        MemberLevelLog memberLevelLog = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                .eq(MemberLevelLog::getOddNumbers, posOrderPo.getPreOrderNo())
                //为了防止出现两条一样的关联单号，需要取最新的一条
                .orderByDesc(MemberLevelLog::getCreateTime)
                .last(" limit 1"));
        //2、如果没查询到数据，则说明与等级无关
        if (memberLevelLog == null) {
            return;
        }
        ///3、根据等级履历信息查询到前一条等级履历信息
        MemberLevelLog preMemberLevelLog = getPreMemberLevelLog(memberLevelLog);
        //4、将会员等级降级
        memberInfo = downMemberInfo(memberInfo, preMemberLevelLog);
        //5、设置会员履历信息
        memberService.downMemberLevelLog(memberLevelLog, posOrderPo.getOrderNo(), memberInfo);
        //6、查询会员消费订单信息，排除退货相关11111122
        List<PosOrderPo> orderList = posOrderMapper.selectOrderList(memberInfo.getMemberId(), memberLevelLog.getLevelStartTime(), posOrderPo.getCreateTime());
        //7、循环处理(2020-06-01 14:45 与产品经理确认，会员首单买（升级）-退（降级)-再买（这一单不算首单）)
        if (!orderList.isEmpty()) {
            for (PosOrderPo po : orderList) {
                //判断是否进行升降级
                MemberLevelUpPo levelUpPo = getMemberLevelUpPo(memberInfo, po);
                if (levelUpPo != null) {
                    //更改会员信息
                    memberInfo = editMemberInfo(levelUpPo, memberInfo, po);
                    //插入履历信息
                    memberService.insertMemberLog(memberInfo, po.getOrderNo(), levelUpPo);
                }
            }
        }
    }

    /**
     * 保级之后降级会员信息
     *
     * @param memberInfo
     * @param memberLevelDownPo
     * @param logRegulation
     */
    private void fillRegulationMemberInfo(MemberInfo memberInfo, MemberLevelDownPo memberLevelDownPo, MemberLevelLog logRegulation) {
        //查询等级信息
        MemberLevel memberLevel = memberLevelMapper.selectOne(Wrappers.<MemberLevel>lambdaQuery()
                .eq(MemberLevel::getLevelCode, memberLevelDownPo.getAfterLevelCode()));
        LocalDateTime now = LocalDateTime.now();
        memberInfo.setMemberLevel(memberLevelDownPo.getAfterLevel());
        memberInfo.setMemberLevelCode(memberLevelDownPo.getAfterLevelCode());
        memberInfo.setMemberLevelName(memberLevelDownPo.getAfterLevelName());
        memberInfo.setLevelStartTime(logRegulation.getLevelStartTime());
        memberInfo.setLevelEndTime(memberLevel.getDuration() == 0 ? parseTime() : logRegulation.getLevelStartTime().plusMonths(memberLevel.getDuration()));
        memberInfo.setUpdateTime(now);
    }

    /**
     * 会员信息修改
     *
     * @param levelUpPo
     * @param memberInfo
     * @return
     */
    private MemberInfo editMemberInfo(MemberLevelUpPo levelUpPo, MemberInfo memberInfo, PosOrderPo po) {
        //查询等级信息
        MemberLevel memberLevel = memberLevelMapper.selectOne(Wrappers.<MemberLevel>lambdaQuery()
                .eq(MemberLevel::getLevelCode, levelUpPo.getAfterLevelCode()));
        LocalDateTime now = LocalDateTime.now();
        //填充会员信息
        memberInfo.setMemberLevel(levelUpPo.getAfterLevel());
        memberInfo.setMemberLevelCode(levelUpPo.getAfterLevelCode());
        memberInfo.setMemberLevelName(levelUpPo.getAfterLevelName());
        memberInfo.setLevelStartTime(po.getCreateTime());
        memberInfo.setLevelEndTime(memberLevel.getDuration() == 0 ? parseTime() : po.getCreateTime().plusMonths(memberLevel.getDuration()));
        memberInfo.setUpdateTime(now);
        return memberInfo;
    }

    /**
     * 获取升级规则
     *
     * @param memberInfo
     * @param po
     * @return
     */
    private MemberLevelUpPo getMemberLevelUpPo(MemberInfo memberInfo, PosOrderPo po) {
        //根据会员等级，查询升降级规则
        MemberLevelRulePo memberLevelRulePo = memberLevelRuleMapper.selectOne(Wrappers.<MemberLevelRulePo>lambdaQuery()
                .eq(MemberLevelRulePo::getLevelCode, memberInfo.getMemberLevelCode())
                .eq(MemberLevelRulePo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                .ge(MemberLevelRulePo::getEndTime, LocalDateTime.now()).le(MemberLevelRulePo::getStartTime, LocalDateTime.now()));
        if (memberLevelRulePo == null) {
            //如果没有适用的升级规则，直接返回
            return null;
        }
        //根据主表查询升级规则，并按照升级后的等级降序排序
        List<MemberLevelUpPo> upPoList = memberLevelUpMapper.selectList(Wrappers.<MemberLevelUpPo>lambdaQuery()
                .eq(MemberLevelUpPo::getRuleId, memberLevelRulePo.getRuleId())
                .orderByDesc(MemberLevelUpPo::getAfterLevel));
        //如果该等级存在升级规则，则进行判断，否则直接返回
        if (upPoList.isEmpty()) {
            return null;
        }
        //遍历循环，即使有多个满足条件，也只取第一个升级规则
        for (MemberLevelUpPo memberLevelUpPo : upPoList) {
            //判断单次购买:购买金额处于区间，而且当前等级小于升级后等级
            if (memberLevelUpPo.getSingle().equals(CommonStatusEnum.EFFECTIVE.getCode()) && memberLevelUpPo.getFromAmt().compareTo(po.getRealAmt()) <= 0
                    && memberLevelUpPo.getToAmt().compareTo(po.getRealAmt()) >= 0 && memberInfo.getMemberLevel() < memberLevelUpPo.getAfterLevel()) {
                return memberLevelUpPo;
            } else if (memberLevelUpPo.getAcc() != null && memberLevelUpPo.getAcc().equals(CommonStatusEnum.EFFECTIVE.getCode())
                    && memberInfo.getMemberLevel() < memberLevelUpPo.getAfterLevel()) {
                //累计购买：当前等级小于升级后等级
                //1、获取当前等级的时间，有可能查询出多个，需要取最近的一个
                MemberLevelLog memberLevelLog = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                        .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                        .eq(MemberLevelLog::getLevelAfter, memberLevelRulePo.getLevel())
                        .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
                //2、查询订单：会员手机号、订单时间范围、是否包含首单（此处查询结果不会为空，因为执行此操作之前，支付已经完成了）
                LambdaQueryWrapper<PosOrderPo> queryWrapper = Wrappers.<PosOrderPo>lambdaQuery()
                        .eq(PosOrderPo::getMemberId, memberInfo.getMemberId())
                        .gt(PosOrderPo::getCreateTime, memberInfo.getLevelStartTime())
                        .lt(PosOrderPo::getCreateTime, LocalDateTime.now());
                if (memberLevelLog != null && StringUtils.isNotBlank(memberLevelLog.getOddNumbers()) && memberLevelUpPo.getIncludeFirst().equals(CommonStatusEnum.EFFECTIVE.getCode())) {
                    //不为空，才需要进行是否首单的判断
                    queryWrapper.or().eq(PosOrderPo::getOrderNo, memberLevelLog.getOddNumbers());
                }
                //3、获取订单的列表
                List<PosOrderPo> posOrderPoList = posOrderMapper.selectList(queryWrapper);
                //4、判断连续n月是否为空
                if (memberLevelUpPo.getDuration() == null || memberLevelUpPo.getDuration() == 0) {
                    //获取支付总金额
                    BigDecimal payTotalAmt = posOrderPoList.stream().map(e -> {
                        if (e.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                            return e.getRealAmt().abs().negate();
                        } else {
                            return e.getRealAmt().abs();
                        }
                    }).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
                    //如果支付金额大于设置累计金额
                    if (payTotalAmt.compareTo(memberLevelUpPo.getAccFromAmt()) >= 0) {
                        return memberLevelUpPo;
                    }
                } else {
                    //获取支付总金额
                    BigDecimal payTotalAmt;
                    //升级的时间大于连续n月
                    if (memberInfo.getLevelStartTime().plusMonths(memberLevelUpPo.getDuration()).isBefore(po.getCreateTime())) {
                        payTotalAmt = posOrderPoList.isEmpty() ? BigDecimal.ZERO : getTotalPay(posOrderPoList, memberLevelUpPo.getDuration());
                    } else {
                        //连续n月大于升级时间
                        payTotalAmt = posOrderPoList.stream().map(e -> {
                            if (e.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                                return e.getRealAmt().abs().negate();
                            } else {
                                return e.getRealAmt().abs();
                            }
                        }).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
                    }
                    //如果支付金额大于设置累计金额
                    if (payTotalAmt.compareTo(memberLevelUpPo.getAccFromAmt()) >= 0) {
                        return memberLevelUpPo;
                    }
                }
            }
        }
        return null;
    }

    /**
     * 填充会员信息
     *
     * @param memberInfo
     * @param memberLevelUpPo
     */
    private void fillMemberInfo(MemberInfo memberInfo, MemberLevelUpPo memberLevelUpPo, PosOrderPo posOrderPo) {
        //查询等级信息
        MemberLevel memberLevel = memberLevelMapper.selectOne(Wrappers.<MemberLevel>lambdaQuery()
                .eq(MemberLevel::getLevelCode, memberLevelUpPo.getAfterLevelCode()));
        LocalDateTime now = LocalDateTime.now();
        //填充会员信息
        memberInfo.setMemberLevel(memberLevelUpPo.getAfterLevel());
        memberInfo.setMemberLevelCode(memberLevelUpPo.getAfterLevelCode());
        memberInfo.setMemberLevelName(memberLevelUpPo.getAfterLevelName());
        memberInfo.setLevelStartTime(posOrderPo.getCreateTime());
        memberInfo.setLevelEndTime(memberLevel.getDuration() == 0 ? parseTime() : posOrderPo.getCreateTime().plusMonths(memberLevel.getDuration()));
        memberInfo.setUpdateTime(now);
    }

    /**
     * 获取结束时间
     *
     * @return
     */
    private LocalDateTime parseTime() {
        return LocalDateTime.parse("9999-12-31 00:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    /**
     * 获取连续n个月订单数据中总金额最大
     *
     * @param posOrderPoList
     * @return
     */
    private BigDecimal getTotalPay(List<PosOrderPo> posOrderPoList, Integer duration) {
        //存放金额数组
        List<BigDecimal> payList = new ArrayList<>();
        for (PosOrderPo po : posOrderPoList) {
            //设置初始值
            BigDecimal sum;
            //根据该单的订单类型进行赋值
            if (po.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                sum = po.getRealAmt().abs().negate();
            } else {
                sum = po.getRealAmt().abs();
            }
            for (PosOrderPo posOrderPo : posOrderPoList) {
                //排除该单
                if (posOrderPo.getOrderNo().equals(po.getOrderNo())) {
                    continue;
                }
                //判断时间，对区间进行判断，此处的区间是[po.getCreateTime()，po.getCreateTime()+月数]
                if (posOrderPo.getCreateTime().isBefore(po.getCreateTime()) || posOrderPo.getCreateTime().isAfter(po.getCreateTime().plusMonths(duration))) {
                    continue;
                }
                //根据循环的订单计算总值
                if (posOrderPo.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                    sum = sum.subtract(posOrderPo.getRealAmt().abs());
                } else {
                    sum = sum.add(posOrderPo.getRealAmt().abs());
                }
            }
            payList.add(sum);
        }
        return Collections.max(payList);
    }
}
