package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

import java.util.List;


/**
 * @author 梁远
 * @Description 销售订单-》会员等级升降级事件
 * @create 2019-11-14 14:59
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Order4MemberLevelEvent extends ApplicationEvent {

    private List<String> memberIdList;

    public Order4MemberLevelEvent(Object source, List<String> memberIdList) {
        super(source);
        this.memberIdList = memberIdList;
    }
}
