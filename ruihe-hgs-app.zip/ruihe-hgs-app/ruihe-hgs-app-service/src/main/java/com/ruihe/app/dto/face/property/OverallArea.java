package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class OverallArea {
    /**
     * 左边面积值
     */
    private Integer left;
    /**
     * 右边面积值
     */
    private Integer right;
}
