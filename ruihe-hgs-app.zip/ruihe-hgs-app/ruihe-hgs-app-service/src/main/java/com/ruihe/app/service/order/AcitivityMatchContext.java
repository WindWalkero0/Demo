package com.ruihe.app.service.order;

import com.google.common.collect.Lists;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

/**
 * 销售下单活动匹配上下文
 *
 * @author William
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AcitivityMatchContext implements Serializable {

    /**
     * 加价购金额
     */
    @Builder.Default
    private BigDecimal addMoney = BigDecimal.ZERO;
    /**
     * 花费的积分
     */
    @Builder.Default
    private Integer intePayable = BigInteger.ZERO.intValue();
    /**
     * 总优惠金额--不给前端用 我们自己用，负数
     */
    @Builder.Default
    private BigDecimal discountAmt = BigDecimal.ZERO;
    /**
     * 活动虚拟商品
     */
    @Builder.Default
    private final List<PosOrderItemPo> itemList = Lists.newArrayList();
}
