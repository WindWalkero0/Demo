package com.ruihe.app.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 发货商品信息
 *
 * @author Fangtao
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhEnterItem implements Serializable {

    @ApiModelProperty(value = "商品编码/条码", required = true)
    private String goodsBarCode;

    @ApiModelProperty(value = "产品条码", required = true)
    private String prdBarCode;

    @ApiModelProperty(value = "产品名称", required = true)
    private String prdName;

    @ApiModelProperty(value = "发货数量", required = true)
    private Integer deliveryQty;
}
