package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.request.WhU8StockOptItemRequest;
import com.ruihe.app.request.WhU8StockOptRequest;
import com.ruihe.app.service.u8.U8MQProducer;
import com.ruihe.app.service.warehouse.StoreInventoryService;
import com.ruihe.app.vo.u8.U8InventoryItemVo;
import com.ruihe.app.vo.u8.U8InventoryVo;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.warehouse.WhFreeInventoryItemPo;
import com.ruihe.common.dao.bean.warehouse.WhFreeInventoryPo;
import com.ruihe.common.dao.bean.warehouse.WhStockLogPo;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.stock.WhStockBizTypeEnum;
import com.ruihe.app.constant.U8DocumentTypeConfig;
import com.ruihe.app.constant.U8ReceivedConfig;
import com.ruihe.app.constant.U8WareHouseConfig;
import com.ruihe.app.event.WhFreeInventoryEvent;
import com.ruihe.app.mapper.basic.CounterMapper;
import com.ruihe.app.mapper.warehouse.WhFreeInventoryItemMapper;
import com.ruihe.app.mapper.warehouse.WhFreeInventoryMapper;
import com.ruihe.common.constant.CommonConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 自由盘点审核通过事件处理
 *
 * @author William
 */
@Slf4j
@Component
public class WhFreeInventoryListener {

    @Autowired
    private WhFreeInventoryMapper whFreeInventoryMapper;

    @Autowired
    private WhFreeInventoryItemMapper whFreeInventoryItemMapper;

    @Autowired
    private StoreInventoryService storeInventoryService;

    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private U8MQProducer u8MQProducer;

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(WhFreeInventoryEvent event) {
        try {
            //查询自由盘点申请单主表
            WhFreeInventoryPo orderPo = whFreeInventoryMapper.selectById(event.getOrderNo());
            //查询自由盘点明细
            List<WhFreeInventoryItemPo> itemList = whFreeInventoryItemMapper.selectList(Wrappers.<WhFreeInventoryItemPo>lambdaQuery()
                    .eq(WhFreeInventoryItemPo::getApplyNo, event.getOrderNo()));
            //构建库存log数据
            List<WhStockLogPo> whStockLogList = this.extractStockLogList(orderPo, itemList);
            //获取柜台信息（柜台的类型）用于判断
            CounterInformation counterInformation = counterMapper.selectOne(Wrappers.<CounterInformation>lambdaQuery()
                    .eq(CounterInformation::getCounterId, orderPo.getCounterId()));
            /**
             * 2020-03-06 11:14与产品经理确认，自营门店需要U8审核完成之后进行库存更新
             * 2020-03-09 14:35与产品经理确认，审核完成就可以进行库存更新，不需要U8的返回
             */
            //if (counterInformation.getOperationalModel().equals(CounterEnum.AGENT_COUNTER.getKey().toString())) {
            //事务处理
            storeInventoryService.changeStock(orderPo.getCounterId(), whStockLogList);
            WhU8StockOptRequest request = this.extractWhU8StockRequest(orderPo, itemList);
            storeInventoryService.syncStockWithU8(request);
            //}
            //通知U8:2020-03-06 11:14与产品经理确认，加盟店不需要将数据同步到U8
            //2020年5月19日13:37:41 测试不同步
            if (counterInformation.getCounterType().equals(CounterEnum.TEST_COUNTER.getKey())) {
                //测试柜台不同步
                return;
            }
            if (counterInformation.getOperationalModel().equals(CounterEnum.SELF_SUPPORT.getKey().toString())) {
                this.sendMsgToU8(orderPo, itemList);
            }
        } catch (Exception e) {
            log.error("自由盘点处理异常，event{}", JSON.toJSONString(event), e);
        }
    }

    private void sendMsgToU8(WhFreeInventoryPo orderPo, List<WhFreeInventoryItemPo> itemList) {
        //U8那边要的盘点单数据类型和字段（表体）
        Integer i = 0;
        List<U8InventoryItemVo> U8InventoryItemList = new ArrayList<>();
        for (WhFreeInventoryItemPo e : itemList) {
            i++;
            U8InventoryItemVo test = U8InventoryItemVo.builder()
                    .inventory_code(e.getPrdBarCode())
                    .iCVQuantity(e.getBookQty())
                    .quantity(e.getRealQty())
                    .poslineid(i)
                    .memo("")
                    .build();
            U8InventoryItemList.add(test);
        }
        //U8那边要的盘点单数据类型和字段（表头）
        U8InventoryVo build = U8InventoryVo.builder()
                .dDate(orderPo.getCreateTime())
                .cwhcode(orderPo.getCounterId())
                .cirdcode(U8ReceivedConfig.InventoryIn)//门店盘盈入库
                .cordcode(U8ReceivedConfig.InventoryOut)//门店盘亏出库
                .cdepcode(orderPo.getCounterName())
                .cpersoncode(U8WareHouseConfig.HandledBy)//经手人
                .poscode(orderPo.getInvNo())
                .memo("门店盘点")
                .Body(U8InventoryItemList).build();

        //把对象推送到MQ
        u8MQProducer.saveLog(build.getPoscode());
        u8MQProducer.sendMessageToU8(build, U8DocumentTypeConfig.CV_ADD);
    }

    /**
     * 抽取门店盘点对象
     *
     * @param orderPo
     * @param itemList
     * @return
     */
    private List<WhStockLogPo> extractStockLogList(WhFreeInventoryPo orderPo, List<WhFreeInventoryItemPo> itemList) {
        return itemList.stream()
                .map(e ->
                        WhStockLogPo.builder()
                                .counterId(orderPo.getCounterId())
                                .counterName(orderPo.getCounterName())
                                .baCode(orderPo.getBaCode())
                                .baName(orderPo.getBaName())
                                .bizType(WhStockBizTypeEnum.INVENTORY.getCode())
                                .bizNo(orderPo.getApplyNo())
                                .bizTime(orderPo.getCreateTime())
                                .prdBarCode(e.getPrdBarCode())
                                .prdName(e.getPrdName())
                                .goodsBarCode(e.getGoodsBarCode())
                                //此处的盘差数分正负
                                .qty(e.getDiffQty())
                                .prdPrice(e.getPrdPrice())
                                .memberPrice(e.getMemberPrice())
                                .bigCatCode(e.getBigCatCode())
                                .bigCatName(e.getBigCatName())
                                .mediumCatCode(e.getMediumCatCode())
                                .mediumCatName(e.getMediumCatName())
                                .smallCatCode(e.getSmallCatCode())
                                .smallCatName(e.getSmallCatName())
                                .build()
                ).collect(Collectors.toList());
    }

    /**
     * 抽取U8库存接口操作
     *
     * @param orderPo
     * @param itemList
     * @return
     */
    private WhU8StockOptRequest extractWhU8StockRequest(WhFreeInventoryPo orderPo, List<WhFreeInventoryItemPo> itemList) {
        WhU8StockOptRequest request = WhU8StockOptRequest.builder()
                .bizType(WhStockBizTypeEnum.INVENTORY.getCode())
                .bizNo(orderPo.getApplyNo())
                .bizTime(orderPo.getCreateTime())
                .counterId(orderPo.getCounterId())
                .counterName(orderPo.getCounterName())
                .build();
        List<WhU8StockOptItemRequest> newItemList = itemList.stream().map(e ->
                WhU8StockOptItemRequest.builder()
                        .bizType(WhStockBizTypeEnum.INVENTORY.getCode())
                        .bizNo(orderPo.getApplyNo())
                        .bizTime(orderPo.getCreateTime())
                        .counterId(orderPo.getCounterId())
                        .counterName(orderPo.getCounterName())
                        .prdBarCode(e.getPrdBarCode())
                        .prdName(e.getPrdName())
                        .goodsBarCode(e.getGoodsBarCode())
                        .qty(e.getDiffQty())
                        .build()
        ).collect(Collectors.toList());
        request.setItemRequestList(newItemList);
        return request;
    }
}
