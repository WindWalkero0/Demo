package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @author LiangYuan
 * @date 2021-03-11 16:19
 */
@ApiModel(value = "MemberSatEvalSubjectRequest", description = "会员满意度评价题目请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberSatEvalSubjectRequest implements Serializable {

    @NotNull(message = "题目ID不能为空")
    @ApiModelProperty(value = "题目ID")
    private String id;

    @NotNull(message = "问卷评价记录id不能为空")
    @ApiModelProperty(value = "问卷评价记录id")
    private String seId;

    @NotNull(message = "排序序号不能为空")
    @ApiModelProperty(value = "排序序号")
    private Integer sqsNo;

    @ApiModelProperty(value = "选项")
    @Valid
    private List<MemberSatEvalOptionRequest> optionRequestList;

}
