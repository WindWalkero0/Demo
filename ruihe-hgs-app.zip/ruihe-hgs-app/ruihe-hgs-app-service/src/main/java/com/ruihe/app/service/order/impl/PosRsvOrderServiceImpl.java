package com.ruihe.app.service.order.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.app.vo.*;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.dao.bean.order.PosPaymentOrderPo;
import com.ruihe.common.enums.activity.ActivityTypeEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.pojo.response.homepage.AmtAndQty;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.mapper.order.PosOrderItemMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.mapper.order.PosPaymentOrderMapper;
import com.ruihe.app.request.order.BuyHistoryRequest;
import com.ruihe.app.request.order.OrderHistoryRequest;
import com.ruihe.app.request.order.PosRsvOrderQueryRequest;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.app.service.order.PosRsvOrderService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static java.util.regex.Pattern.compile;

/**
 * @author 梁远
 * @Description 预定单查询服务
 * @create 2019-10-19 15:41
 */
@Slf4j
@DS(DBConst.SLAVE)
@Service
public class PosRsvOrderServiceImpl implements PosRsvOrderService {
    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private PosOrderItemMapper posOrderItemMapper;

    @Autowired
    private PosPaymentOrderMapper posPaymentOrderMapper;


    /**
     * 根据条件查询预订单
     *
     * @param request
     * @return
     */
    @Override
    public Response queryRsvOrder(PosRsvOrderQueryRequest request) {
        //手机号判断
        Pattern pattern = compile("^[1]\\d{10}$");
        if (request.getMemberPhone() != null && !request.getMemberPhone().isEmpty() && !pattern.matcher(request.getMemberPhone()).matches()) {
            return Response.errorMsg("手机号码格式有误,请核对后重试!");
        }
        //判断时间问题
        if (request.getStartTime() != null && request.getEndTime() != null && request.getEndTime().isBefore(request.getStartTime())) {
            return Response.errorMsg("结束时间不能大于开始时间!");
        }
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        //分页
        Page<PosOrderPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询
        IPage<PosOrderPo> posOrderPoIPage = posOrderMapper.selectPosOrderPoList(page, request);
        List<PosOrderPo> posOrderPos = posOrderPoIPage.getRecords();
        if (posOrderPos.isEmpty()) {
            return Response.successMsg("暂无数据!");
        }
        //转换page对象
        PageVO pageVO = PageVO.<PosRsvOrderVo>builder()
                .list(ObjectUtils.toList(posOrderPos, PosRsvOrderVo.class))
                .pageNum(posOrderPoIPage.getCurrent())
                .pageSize(posOrderPoIPage.getSize())
                .pages(posOrderPoIPage.getPages())
                .total(posOrderPoIPage.getTotal())
                .build();
        return Response.success(pageVO);
    }

    /**
     * 根据预订单单号查询订单详情
     *
     * @param orderNo
     * @return
     */
    @Override
    public Response queryRsvOrderItem(String orderNo) {
        LambdaQueryWrapper<PosOrderItemPo> queryWrapper = Wrappers.<PosOrderItemPo>lambdaQuery()
                .eq(PosOrderItemPo::getOrderNo, orderNo)
                //不是虚拟商品:is_virtual 是否虚拟商品，1是0否
                .eq(PosOrderItemPo::getIsVirtual, CommonStatusEnum.INVALID.getCode())
                //剩余数量大于等于0
                .gt(PosOrderItemPo::getSurplusQty, 0);
        List<PosOrderItemPo> posOrderItemPos = posOrderItemMapper.selectList(queryWrapper);
        if (posOrderItemPos.isEmpty()) {
            return Response.successMsg("暂无数据!");
        }
        //销售订单子表中可能存在两件相同的产品，一件是促销的，另一件是正常销售的，此处需要进行商品合并
        List<PosOrderItemPo> posOrderItemPoList = posOrderItemPos.stream().collect(
                Collectors.collectingAndThen(Collectors.toCollection(() ->
                        new TreeSet<>(Comparator.comparing(PosOrderItemPo::getPrdBarCode))), ArrayList::new));
        //判断是否去重了
        if (posOrderItemPoList.size() == posOrderItemPos.size()) {
            return Response.success(ObjectUtils.toList(posOrderItemPos, PosRsvOrderItemVo.class));
        }
        //如果确实有重复的元素，则进行处理
        posOrderItemPoList.forEach(e -> {
            for (PosOrderItemPo orderItemPo : posOrderItemPos) {
                //barCode相同而orderNo不同，则进行数量的相加
                if (e.getPrdBarCode().equals(orderItemPo.getPrdBarCode()) && !e.getProType().equals(orderItemPo.getProType())) {
                    e.setSurplusQty(orderItemPo.getSurplusQty() + e.getSurplusQty());
                }
            }
        });
        return Response.success(ObjectUtils.toList(posOrderItemPoList, PosRsvOrderItemVo.class));
    }

    /**
     * 寄存箱查询历史销售记录
     *
     * @param request
     * @return
     */
    @Override
    public Response orderHistory(OrderHistoryRequest request) {
        //时间判断
        if (request.getStartTime() != null && request.getEndTime() != null && request.getEndTime().isBefore(request.getStartTime())) {
            return Response.errorMsg("结束时间不能大于开始时间!");
        }
        //对查询的结束时间进行处理
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        //根据条件查询：类型为‘销售’，订单没退货，以及会员id和时间
        List<String> orderNoList = posOrderMapper.selectOrderHistory(request);
        if (orderNoList.isEmpty()) {
            return Response.successMsg("暂无数据!");
        }
        //设置分页条件
        Page<PosOrderItemPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        IPage<PosOrderItemPo> posOrderItemPoPage = posOrderItemMapper.selectOrderItemPage(page, request);
        List<PosOrderItemPo> itemPoList = posOrderItemPoPage.getRecords();
        if (itemPoList.isEmpty()) {
            return Response.successMsg("暂无数据!");
        }
        PageVO pageVO = PageVO.<OrderHistoryVo>builder()
                .list(ObjectUtils.toList(itemPoList, OrderHistoryVo.class))
                .pageNum(posOrderItemPoPage.getCurrent())
                .pageSize(posOrderItemPoPage.getSize())
                .pages(posOrderItemPoPage.getPages())
                .total(posOrderItemPoPage.getTotal())
                .build();
        return Response.success(pageVO);
    }

    /**
     * 查询会员历史购买记录，以订单维度展示
     *
     * @param request
     * @return
     */
    @Override
    public Response buyHistory(BuyHistoryRequest request) {
        //交易类型
        if (request.getTransType() != null && !request.getTransType().equals(OrderTransTypeEnum.GOODS_OUT.getCode()) && !request.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
            return Response.errorMsg("交易类型错误!");
        }
        //时间判断
        if (request.getStartTime() != null && request.getEndTime() != null && request.getEndTime().isBefore(request.getStartTime())) {
            return Response.errorMsg("结束时间不能大于开始时间!");
        }
        if (request.getStartTime() != null && request.getEndTime() != null && request.getStartTime().until(request.getEndTime(), ChronoUnit.DAYS) >= 365) {
            return Response.errorMsg("查询时间区间请在12个月以内!");
        }
        //对查询的结束时间进行处理
        if (request.getEndTime() != null) {
            request.setEndTime(request.getEndTime().plusDays(1));
        }
        //设置分页条件
        Page<PosOrderPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //开始查询
        IPage<PosOrderPo> posOrderPoIPage = posOrderMapper.selectBuyHistory(page, request);
        List<PosOrderPo> orderPoList = posOrderPoIPage.getRecords();
        if (orderPoList.isEmpty()) {
            return Response.successMsg("暂无数据!");
        }
        //循环处理数据
        orderPoList.forEach(e -> {
                    /**
                     * 2020-05-08 蔡春祥测试，产品经理确认，将查询结果活动类型为发券（4）的情况合并到优惠券活动中（1）
                     */
                    if (e.getActivityType().equals(ActivityTypeEnum.USING_CONPON_4ISSUE.getCode())) {
                        e.setActivityType(ActivityTypeEnum.USING_CONPON_4MEMBER.getCode());
                    }
                    //净销售数量：数量不包括虚拟商品,销售录入的时候没有将虚拟商品放在数量里面
                    //将退货的数据设置成负数
                    if (e.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                        e.setRealAmt(e.getRealAmt().abs().negate());
                        e.setGoodsQty(Math.negateExact(Math.abs(e.getGoodsQty())));
                    }
                }
        );
        //分页展示vo
        PageVO pageVO = PageVO.<BuyHistoryVo>builder()
                .list(ObjectUtils.toList(orderPoList, BuyHistoryVo.class))
                .pageNum(posOrderPoIPage.getCurrent())
                .pageSize(posOrderPoIPage.getSize())
                .pages(posOrderPoIPage.getPages())
                .total(posOrderPoIPage.getTotal())
                .build();
        //销售数量和金额
        AmtAndQty amtAndQty = posOrderMapper.selectAmtAndQty(request);
        Map<String, Serializable> resultMap = Map.ofEntries(
                Map.entry("pageVo", pageVO),
                Map.entry("amtAndQty", amtAndQty)
        );
        return Response.success(resultMap);
    }

    /**
     * 获取历史购买记录的详情
     *
     * @param orderNo
     * @param transType
     * @return
     */
    @Override
    public Response historyItem(String orderNo, Integer transType) {
        if (!OrderTransTypeEnum.GOODS_OUT.getCode().equals(transType) && !OrderTransTypeEnum.GOODS_RETURN.getCode().equals(transType)) {
            return Response.errorMsg("参数错误!");
        }
        //根据订单号查询详情
        List<PosOrderItemPo> posOrderItemPoList = posOrderItemMapper.selectList(Wrappers.<PosOrderItemPo>lambdaQuery()
                .eq(PosOrderItemPo::getOrderNo, orderNo));
        if (posOrderItemPoList.isEmpty()) {
            //页面有数据，查看详情无数据
            return Response.errorMsg("查询出错，请刷新重试!");
        }
        List<PosOrderItemVo> posOrderItemVoList = ObjectUtils.toList(posOrderItemPoList, PosOrderItemVo.class);
        //查询支付方式
        List<PosPaymentOrderPo> paymentOrderPoList = posPaymentOrderMapper.selectList(Wrappers.<PosPaymentOrderPo>lambdaQuery()
                .eq(PosPaymentOrderPo::getOrderNo, orderNo));
        if (paymentOrderPoList.isEmpty()) {
            //没有查询到支付信息
            return Response.errorMsg("查询出错，请刷新重试!");
        }
        List<PosPayMentItemVo> posPaymentItemVoList = ObjectUtils.toList(paymentOrderPoList, PosPayMentItemVo.class);
        //返回前端的前置数据
        BuyHistoryVo buyHistoryVo = new BuyHistoryVo();
        //如果交易类型是销售，则查询是否有关联的退货单
        if (transType.equals(OrderTransTypeEnum.GOODS_OUT.getCode())) {
            PosOrderPo po = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                    .eq(PosOrderPo::getPreOrderNo, orderNo));
            if (po != null) {
                BeanUtils.copyProperties(po, buyHistoryVo);
                buyHistoryVo.setGoodsQty(Math.negateExact(Math.abs(po.getGoodsQty())));
                buyHistoryVo.setRealAmt(po.getRealAmt().abs().negate());
            }
        } else {
            //退货数据设置成负数
            posOrderItemVoList.forEach(e -> {
                e.setPurQty(Math.negateExact(Math.abs(e.getPurQty())));
                e.setAmount(e.getAmount().abs().negate());
            });
            //支付信息设置成负数
            posPaymentItemVoList.forEach(e -> e.setPayAmt(e.getPayAmt().abs().negate()));
            //查询关联的销售单
            PosOrderPo po = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                    .select(PosOrderPo::getPreOrderNo)
                    .eq(PosOrderPo::getOrderNo, orderNo));
            //查询到前置单据不为空
            if (po != null && StringUtils.isNotBlank(po.getPreOrderNo())) {
                PosOrderPo posOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                        .eq(PosOrderPo::getOrderNo, po.getPreOrderNo()));
                if (posOrderPo != null) {
                    //返回的销售单数据都是正数
                    BeanUtils.copyProperties(posOrderPo, buyHistoryVo);
                    buyHistoryVo.setGoodsQty(Math.abs(posOrderPo.getGoodsQty()));
                    buyHistoryVo.setRealAmt(posOrderPo.getRealAmt().abs());
                }
            }
        }
        //返回
        Map<String, Object> resultMap = Map.ofEntries(
                Map.entry("buyHistoryVo", buyHistoryVo),
                Map.entry("posOrderItemVoList", posOrderItemVoList),
                Map.entry("posPaymentItemVoList", posPaymentItemVoList)
        );
        return Response.success(resultMap);
    }

}
