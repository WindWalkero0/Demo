package com.ruihe.app.response;


import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description
 * @author huangjie
 * @create 2021-04-25 16:40
 */
@ApiModel(value = "WxReserveRequest", description = "可选择的护理项目实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WxNursingMemberResponse {
    private Integer id;

    /**
     * 护理项目子类
     */
    private String itemChild;

    /**
     * 状态(0:不可选择,1:可选择)
     */
    private Integer status;

    /**
     * 护理类型(1:按摩 2 :精油 3:原液 4;冻干粉 5:微晶 6;疗程面膜 7:套盒 8:水疗)
     */
//    private Integer type;


}
