package com.ruihe.app.service.analysis;

import com.ruihe.common.pojo.request.analysis.SaleDetailRequest;
import com.ruihe.common.response.Response;

/**
 * @author:Fangtao
 * @Date:2019/10/31 14:07
 */
public interface SalesDetailReportService {
    /**
     * 按条件查询销售小结首页
     */
    Response selectReport(SaleDetailRequest request);


    /**
     * 销售明细报表->销售小结->按条件计算数量与销售额
     */
    Response sumCounterAllStock(SaleDetailRequest request);


    /**
     * 销售明细单--查看详情
     */
    Response typeOfReturn(String orderNo, Integer transType);

    /**
     * 销售明细报表->销售明细->积分兑换类型
     *
     * @param orderNo
     * @return
     */
    Response pointExchangeType(String orderNo, Integer activityType, Integer transType);
}
