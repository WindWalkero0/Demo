package com.ruihe.app.service.integral;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.exception.BizException;

import java.util.Arrays;
import java.util.List;

/**
 * 积分活动区域匹配
 */
public class RangeMatcher {
    /**
     * 这个是活动配置时前端选择的节点数据，只会保存树形菜单中选中的最下层节点
     */
    private final JSONArray selected;

    public RangeMatcher(JSONArray selected) {
        this.selected = selected;
    }

    public boolean match(String selected, RuleContext rc) {
        // 选择按区域或按区域指定柜台
        if ("A".equalsIgnoreCase(selected)||"B".equalsIgnoreCase(selected)) {
            return this.matchArea(rc.getCounter());
        }
        // 选择按按渠道或按渠道指定柜台
        else if ("C".equalsIgnoreCase(selected) || "D".equalsIgnoreCase(selected)) {
            return this.matchChannel(rc.getCounter());
        } else {
            throw new BizException("未知的selected类型: " + selected);
        }
    }

    /**
     * 根据柜台所在组织结构匹配
     */
    public boolean matchOrg(CounterInformation counter) {
        List<String> list = Arrays.asList(
                counter.getOrgAreaId(),
                counter.getOrgMasterId(),
                counter.getOrgOfficeId(),
                counter.getCounterId());
        return doMatch(list);
    }

    /**
     * 根据区域匹配
     */
    public boolean matchArea(CounterInformation counter) {
        List<String> list = Arrays.asList(
                counter.getLargeAreaCode(),
                counter.getProvinceCode(),
                counter.getCityCode(),
                counter.getCountyCode(),
                counter.getCounterId());
        return doMatch(list);
    }

    /**
     * 根据柜台渠道信息匹配
     */
    public boolean matchChannel(CounterInformation counter) {
        List<String> list = Arrays.asList(
                counter.getChannelCode(),
                counter.getCounterId());
        return doMatch(list);
    }

    /**
     * @param list 需要匹配的柜台区域信息
     * @return 成功返回 true，否则 false
     */
    private boolean doMatch(List<String> list) {
        for (Object s : selected) {
            JSONObject jsonObject = (JSONObject) s;
            String code = jsonObject.getString("code");
            if (list.contains(code)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 从选择的组织结构或者渠道构建RangeTree
     * json结构见当前包下的rule_conf.json 里的tree节点
     * 这里因为传入的是array，所以构建一个空的root节点作为根节点
     */
    public static RangeMatcher from(JSONArray json) {
        return new RangeMatcher(json);
    }
}
