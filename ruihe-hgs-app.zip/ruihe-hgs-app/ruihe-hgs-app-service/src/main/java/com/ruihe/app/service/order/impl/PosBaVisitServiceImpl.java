package com.ruihe.app.service.order.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruihe.app.request.member.BaVisitBatchListRequest;
import com.ruihe.app.request.member.BaVisitQueryRequest;
import com.ruihe.app.vo.PosVisitTypeVo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.PosBaVisit;
import com.ruihe.common.dao.bean.base.PosVisitType;
import com.ruihe.common.dao.bean.system.SystemConfigPo;
import com.ruihe.common.dao.mapper.SystemConfigMapper;
import com.ruihe.common.enums.order.PosVisitTypeEnum;
import com.ruihe.common.dao.mapper.PosBaVisitMapper;
import com.ruihe.common.dao.mapper.PosVisitTypeMapper;
import com.ruihe.app.request.member.BaVisitRequest;
import com.ruihe.common.pojo.PageExtVO;
import com.ruihe.common.pojo.context.holder.PosUserContextHolder;
import com.ruihe.app.response.FinancialMonthResponse;
import com.ruihe.common.pojo.response.member.BaVisitTypeResponse;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.BeanUtil;
import com.ruihe.app.service.order.PosBaVisitService;
import com.ruihe.common.utils.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;


/**
 * POS销售
 *
 * @author fly
 */
@Service
@Slf4j
public class PosBaVisitServiceImpl extends ServiceImpl<PosBaVisitMapper, PosBaVisit> implements PosBaVisitService {

    /**
     * 财务月结束日
     */
    private final int END_DAY = 26;

    @Autowired
    private PosBaVisitMapper posBaVisitMapper;

    @Autowired
    private PosVisitTypeMapper posVisitTypeMapper;
    
    @Autowired
    private SystemConfigMapper systemConfigMapper;
    
    private static final String BA_QUERY_DEADLINE = "ba_query_deadline";

    @Override
    public Response addVisit(BaVisitRequest baVisitRequest) {
        PosBaVisit posBaVisit = BeanUtil.copyProperties(baVisitRequest, PosBaVisit.class);
        posBaVisit.setCreateTime(LocalDateTime.now());
        posBaVisit.setUpdateTime(LocalDateTime.now());
        int insert = posBaVisitMapper.insert(posBaVisit);
        if (insert == 0) {
            return Response.errorMsg("系统异常,请稍后重试！");
        }
        BigDecimal visitCount = posBaVisitMapper.getVisitCount(baVisitRequest.getOperationType(), baVisitRequest.getCounterId(), baVisitRequest.getBaCode());
        return Response.success("新增【" + posBaVisit.getOperationType() + "】" + baVisitRequest.getOperationQty() + "人成功,当日累计已新增" + visitCount + "人！");
    }

    /**
     * 批量添加回访记录
     *
     * @param request
     * @return
     */
    @Override
    @DS(DBConst.MASTER)
    public Response addBatchVisit(BaVisitBatchListRequest request) {
        if (request.getBatchRequestList().isEmpty()) {
            return Response.errorMsg("服务内容不能为空！");
        }
        List<PosBaVisit> posBaVisitList = BeanUtil.copyListProperties(request.getBatchRequestList(), PosBaVisit.class);
        posBaVisitList.stream().forEach(u -> {
            u.setCreateTime(LocalDateTime.now());
            u.setUpdateTime(LocalDateTime.now());
        });
        if (!saveBatch(posBaVisitList)) {
            return Response.errorMsg("系统异常，请稍后重试！");
        }
        return Response.success();
    }

    @Override
    public Response selectType() {
        List<PosVisitType> posVisitTypes = posVisitTypeMapper.selectList(Wrappers.<PosVisitType>lambdaQuery()
                .eq(PosVisitType::getStatus, PosVisitTypeEnum.STATUS_EFFECTIVE.getCode())
                .orderByAsc(PosVisitType::getSort));
        List<PosVisitTypeVo> posVisitTypeVos = BeanUtil.copyListProperties(posVisitTypes, PosVisitTypeVo.class);
        return Response.success(posVisitTypeVos);
    }

    /**
     * 服务记录查询-分页
     *
     * @param request
     * @return
     */
    @Override
    @DS(DBConst.SLAVE)
    public Response list(BaVisitQueryRequest request) {
        PosBaVisit posBaVisit = new PosBaVisit();
        // 通过系统配置表获取配置的期限时间
        SystemConfigPo systemConfigPo = systemConfigMapper.selectOne(Wrappers.<SystemConfigPo>lambdaQuery()
                .eq(SystemConfigPo::getParamKey, BA_QUERY_DEADLINE).eq(SystemConfigPo::getStatus, 1));
        if(systemConfigPo == null || StringUtils.isBlank(systemConfigPo.getParamValue())){
            return Response.errorMsg("参数配置未填写完整！");
        }
        // lambda条件
        LambdaQueryWrapper<PosBaVisit> queryWrapper = new LambdaQueryWrapper<>(posBaVisit)
                .eq(PosBaVisit::getCounterId, PosUserContextHolder.get().getCounter().getCounterId())
                .ge(PosBaVisit::getCreateTime, systemConfigPo.getParamValue());

        // 服务类型id
        if (null != request.getTypeId()) {
            queryWrapper.and(q -> {
                q.eq(PosBaVisit::getTypeId, request.getTypeId());
            });
        }
        // 美导编号
        if (StringUtils.isNotBlank(request.getBaCode())) {
            queryWrapper.and(q -> {
                q.eq(PosBaVisit::getBaCode, request.getBaCode());
            });
        }
        // 时间
        if (StringUtils.isNotBlank(request.getStartTime())) {
            queryWrapper.and(q -> {
                q.ge(PosBaVisit::getServiceTime, request.getStartTime());
            });
        }
        if (StringUtils.isNotBlank(request.getEndTime())) {
            queryWrapper.and(q -> {
                q.le(PosBaVisit::getServiceTime, request.getEndTime());
            });
        }
        queryWrapper.orderByDesc(PosBaVisit::getServiceTime);
        // 分页查询
        Page<PosBaVisit> page = new Page<>(request.getPageNumber(), request.getPageSize());
        IPage<PosBaVisit> totalPage = page(page, queryWrapper);
        // 统计数据需要添加分组条件
        queryWrapper.groupBy(PosBaVisit::getTypeId);
        List<BaVisitTypeResponse> visitList = posBaVisitMapper.listVisit(queryWrapper);

        // 获取服务类型详情列表
        List<PosVisitType> posVisitTypeList = posVisitTypeMapper.selectList(Wrappers.<PosVisitType>lambdaQuery());
        if (posVisitTypeList.isEmpty()) {
            Response.errorMsg("服务类型详情为空！");
        }
        // 转换成map用作校验赋值
        Map<Integer, String> visitTypeMap = posVisitTypeList.stream()
                .collect(Collectors.toMap(PosVisitType::getId, PosVisitType::getOperationType, (k1, k2) -> k1));

        // 统计数据的重新赋值
        visitList.stream().forEach(u -> {
            if (visitTypeMap.containsKey(u.getTypeId())) {
                u.setOperationType(visitTypeMap.get(u.getTypeId()));
            }
        });
        // 分页数据的重新赋值
        List<PosBaVisit> posBaVisitList = totalPage.getRecords();
        posBaVisitList.stream().forEach(u -> {
            if (visitTypeMap.containsKey(u.getTypeId())) {
                u.setOperationType(visitTypeMap.get(u.getTypeId()));
            }
        });
        // 将统计数据与分页数据合并展示
        PageExtVO pageExtVO = PageExtVO.<PosBaVisit, List<BaVisitTypeResponse>>builder()
                .data(posBaVisitList)
                // 根据typeId排序
                .extData(visitList.stream().sorted(Comparator.comparing(BaVisitTypeResponse::getTypeId)).collect(Collectors.toList()))
                .total(totalPage.getTotal())
                .page(totalPage.getCurrent())
                .pageSize(totalPage.getSize())
                .totalPage(totalPage.getPages()).build();
        return Response.success(pageExtVO);
    }

    /**
     * 计算当前日期所属财务月的开始日期
     *
     * @return
     */
    @Override
    public Response getFinancialInfo() {
        FinancialMonthResponse response = new FinancialMonthResponse();
        // 获取当前日期
        LocalDate localDate = LocalDate.now();
        response.setCurrentFinancialDate(localDate);

        // 财务月日期判断
        if (localDate.getDayOfMonth() >= END_DAY) {
            response.setStartFinancialDate(LocalDate.of(localDate.getYear(), localDate.getMonth(), END_DAY));
            return Response.success(response);
        }
        response.setStartFinancialDate(LocalDate.of(localDate.minusMonths(1).getYear(), localDate.minusMonths(1).getMonth(), END_DAY));
        return Response.success(response);
    }
}
