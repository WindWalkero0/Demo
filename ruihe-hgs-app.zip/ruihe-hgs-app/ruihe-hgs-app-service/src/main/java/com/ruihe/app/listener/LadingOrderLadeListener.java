package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.request.WhU8StockOptItemRequest;
import com.ruihe.app.request.WhU8StockOptRequest;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.order.PosLadingOrderItemPo;
import com.ruihe.common.dao.bean.order.PosLadingOrderPo;
import com.ruihe.common.dao.bean.warehouse.WhStockLogPo;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.stock.WhStockBizTypeEnum;
import com.ruihe.app.event.LadingOrderLadeEvent;
import com.ruihe.app.mapper.basic.CounterMapper;
import com.ruihe.app.mapper.order.PosLadingOrderItemMapper;
import com.ruihe.app.mapper.order.PosLadingOrderMapper;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.app.service.warehouse.StoreInventoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 预订单【提货】库存更新
 *
 * @author William
 */
@Slf4j
@Component
public class LadingOrderLadeListener {
    @Autowired
    private PosLadingOrderMapper posLadingOrderMapper;

    @Autowired
    private PosLadingOrderItemMapper posLadingOrderItemMapper;

    @Autowired
    private StoreInventoryService storeInventoryService;

    @Autowired
    private CounterMapper counterMapper;


    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(LadingOrderLadeEvent event) {
        try {
            //1、获取提取列表单号
            String orderNo = event.getOrderNo();
            //2、根据单号获取提取单信息
            PosLadingOrderPo posLadingOrderPo = posLadingOrderMapper.selectOne(Wrappers.<PosLadingOrderPo>lambdaQuery()
                    .eq(PosLadingOrderPo::getLadingOrderNo, orderNo));
            //3、根据单号获取提取单详情信息
            List<PosLadingOrderItemPo> itemPoList = posLadingOrderItemMapper.selectList(Wrappers.<PosLadingOrderItemPo>lambdaQuery()
                    .eq(PosLadingOrderItemPo::getLadingOrderNo, orderNo));
            List<WhStockLogPo> whStockLogList = this.extractStockLogList(posLadingOrderPo, itemPoList);
            //4、事务处理
            storeInventoryService.changeStock(posLadingOrderPo.getCounterId(), whStockLogList);
            //5、通知U8（只有自营的门店需要将信息同步到U8）--2020-03-05 09:49与产品经理确认
            CounterInformation counterInformation = counterMapper.selectOne(Wrappers.<CounterInformation>lambdaQuery()
                    .select(CounterInformation::getOperationalModel)
                    .eq(CounterInformation::getCounterId, posLadingOrderPo.getCounterId()));
            if (counterInformation.getOperationalModel().equals(CounterEnum.SELF_SUPPORT.getKey().toString())) {
                WhU8StockOptRequest request = this.extractWhU8StockOptItemRequest(posLadingOrderPo, itemPoList);
                storeInventoryService.syncStockWithU8(request);
            }
        } catch (Exception e) {
            log.error("预订单【提货】库存更新异常，event{}", JSON.toJSONString(event), e);
        }
    }

    /**
     * 抽取门店扣减库存对象
     *
     * @param posLadingOrderPo
     * @param itemPoList
     * @return
     */
    private List<WhStockLogPo> extractStockLogList(PosLadingOrderPo posLadingOrderPo, List<PosLadingOrderItemPo> itemPoList) {
        return itemPoList.stream()
                .map(e ->
                        WhStockLogPo.builder()
                                .counterId(posLadingOrderPo.getCounterId())
                                .counterName(posLadingOrderPo.getCounterName())
                                .baCode(posLadingOrderPo.getBaCode())
                                .baName(posLadingOrderPo.getBaName())
                                .bizType(WhStockBizTypeEnum.LADING.getCode())
                                .bizNo(posLadingOrderPo.getLadingOrderNo())
                                .bizTime(posLadingOrderPo.getCreateTime())
                                .prdBarCode(e.getPrdBarCode())
                                .prdName(e.getPrdName())
                                .goodsBarCode(e.getGoodsBarCode())
                                .qty(Math.negateExact(Math.abs(e.getLadingQty())))
                                .prdPrice(e.getPrdPrice())
                                .memberPrice(e.getMemberPrice())
                                .bigCatCode(e.getBigCatCode())
                                .bigCatName(e.getBigCatName())
                                .mediumCatCode(e.getMediumCatCode())
                                .mediumCatName(e.getMediumCatName())
                                .smallCatCode(e.getSmallCatCode())
                                .smallCatName(e.getSmallCatName())
                                .build()
                ).collect(Collectors.toList());
    }

    /**
     * 抽取U8库存接口操作
     *
     * @param posLadingOrderPo
     * @param itemPoList
     * @return
     */
    private WhU8StockOptRequest extractWhU8StockOptItemRequest(PosLadingOrderPo posLadingOrderPo, List<PosLadingOrderItemPo> itemPoList) {
        WhU8StockOptRequest request = WhU8StockOptRequest.builder()
                .bizType(WhStockBizTypeEnum.LADING.getCode())
                .bizNo(posLadingOrderPo.getLadingOrderNo())
                .bizTime(posLadingOrderPo.getCreateTime())
                .counterId(posLadingOrderPo.getCounterId())
                .counterName(posLadingOrderPo.getCounterName())
                .build();
        List<WhU8StockOptItemRequest> newItemList = itemPoList.stream().map(e ->
                WhU8StockOptItemRequest.builder()
                        .bizType(WhStockBizTypeEnum.LADING.getCode())
                        .bizNo(posLadingOrderPo.getLadingOrderNo())
                        .bizTime(posLadingOrderPo.getCreateTime())
                        .counterId(posLadingOrderPo.getCounterId())
                        .counterName(posLadingOrderPo.getCounterName())
                        .prdBarCode(e.getPrdBarCode())
                        .prdName(e.getPrdName())
                        .goodsBarCode(e.getGoodsBarCode())
                        .qty(Math.abs(e.getLadingQty()))
                        .build()
        ).collect(Collectors.toList());
        request.setItemRequestList(newItemList);
        return request;
    }
}
