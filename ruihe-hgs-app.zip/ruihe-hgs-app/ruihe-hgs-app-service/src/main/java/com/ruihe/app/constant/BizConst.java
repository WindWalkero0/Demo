package com.ruihe.app.constant;

/**
 * 业务需求常量类
 *
 * @author William
 */
public class BizConst {
    /**
     * 空退价格调整商品编码
     */
    public static final String KT_GOODS_BAR_CODE = "TZZK000000";
    /**
     * 空退价格调整商品名称
     */
    public static final String KT_GOODS_NAME = "%s价格调整";
}
