package com.ruihe.app.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AIOverviewCheckResponse {
    /**
     * 是否从未进行过AI测肤
     */
    private boolean neverTest;
    private AIOverviewResponse aiOverviewResponse;
}
