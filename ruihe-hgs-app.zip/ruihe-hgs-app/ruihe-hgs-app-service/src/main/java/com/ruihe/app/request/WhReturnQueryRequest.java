package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-24 9:04
 */
@ApiModel(value = "WhReturnQueryRequest", description = "退库申请请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhReturnQueryRequest implements Serializable {

    @NotBlank(message = "柜台编码不能为空")
    @ApiModelProperty(value = "柜台编码")
    private String counterId;

    @ApiModelProperty(value = "开始时间")
    private LocalDate startTime;

    @ApiModelProperty(value = "结束时间")
    private LocalDate endTime;
}
