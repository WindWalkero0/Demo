package com.ruihe.app.response;

import com.ruihe.app.dto.face.LabelProblemInfo;
import lombok.Data;

import java.util.Map;

@Data
public class AIProblemResponse {

    private String label;

    private String labelChinese;

    private Map<String, LabelProblemInfo> metaInfo;



}
