package com.ruihe.app.service.integral;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.event.Order4IntegralBeforeLevelEvent;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderItemPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderPo;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.dao.bean.system.SystemConfigPo;
import com.ruihe.common.dao.mapper.SystemConfigMapper;
import com.ruihe.common.enums.integral.IntegralBizTypeEnum;
import com.ruihe.common.enums.integral.IntegralTypeEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.enums.system.SystemPosConfigEnum;
import com.ruihe.common.service.event.OnlyAddCouponEvent;
import com.ruihe.app.enums.OrderTypeEnum;
import com.ruihe.app.event.Order4IntegralEvent;
import com.ruihe.app.event.Order4MemberEntranceEvent;
import com.ruihe.app.event.Order4StockEvent;
import com.ruihe.common.dao.mapper.integral.IntegralAccountMapper;
import com.ruihe.common.dao.mapper.integral.IntegralOrderItemMapper;
import com.ruihe.common.dao.mapper.integral.IntegralOrderMapper;
import com.ruihe.app.mapper.member.MemberLevelLogMapper;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.app.mapper.order.PosOrderItemMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.utils.IdGenerator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.MutableTriple;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 积分服务
 *
 * @author William
 */
@Service
@Slf4j
public class IntegralServiceForSum implements ApplicationContextAware {

    @Autowired
    private IntegralRuleEngineAmend integralRuleEngineAmend;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private PosOrderItemMapper posOrderItemMapper;

    @Autowired
    private MemberLevelLogMapper memberLevelLogMapper;

    @Autowired
    private IntegralOrderMapper integralOrderMapper;

    @Autowired
    private IntegralOrderItemMapper integralOrderItemMapper;

    @Autowired
    private IntegralAccountMapper integralAccountMapper;

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private SystemConfigMapper systemConfigMapper;

    private ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    public List integralAmendment(String amendmentTime, List<String> memberList) {
        //根据会员id查询今天有两笔以上订单的用户
        List returnList = new ArrayList();
        for (int i = 0; i < memberList.size(); i++) {
            String orderNo = IdGenerator.getShorterSerialNo("PT");
            String memberId = memberList.get(i);
            List<PosOrderPo> posOrderPos = posOrderMapper.selectOrderListByMember(amendmentTime, memberId);
            MemberInfo memberInfo = memberMapper.selectById(memberId);
            if (posOrderPos.size() < 2) {
                log.error("{}不足两笔销售订单", memberId);
                continue;
            }
            Integer oldIntegralQty = 0;
            Integer newIntegralQty = 0;
            for (int i1 = 0; i1 < posOrderPos.size(); i1++) {
                RuleContext rc = this.extractRuleContext(posOrderPos.get(i1).getOrderNo());
                MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> result = integralRuleEngineAmend.run(rc);
                newIntegralQty += result.getLeft().getIntegralQty();
            }
            //统一退货的都跳过
            List<String> list = new ArrayList();
            for (PosOrderPo posOrderPo : posOrderPos) {
                list.add(posOrderPo.getOrderNo());
            }

            List<IntegralOrderPo> integralOrderPos = integralOrderMapper.selectList(Wrappers.<IntegralOrderPo>lambdaQuery().in(IntegralOrderPo::getBizNo, list));
            for (IntegralOrderPo integralOrderPo : integralOrderPos) {
                oldIntegralQty += integralOrderPo.getIntegralQty();
            }

            if (oldIntegralQty.equals(newIntegralQty)) {
                //老积分新积分相同
                log.info("{}当天的积分相同均为{}没有问题", memberId, oldIntegralQty);
                continue;
            }
            Integer integralDiff = newIntegralQty - oldIntegralQty;
            //弄一个差值的积分订单存入
            String desc = "拆单导致积分受损修复";
            MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> result = this.run(integralDiff, memberInfo, orderNo, desc);
            //事务处理落地数据
            this.changeBalance(result, integralDiff);
            returnList.add(memberInfo.getMemberId());
        }
        return returnList;
    }

    /**
     * 构造rc
     *
     * @param orderNo
     * @return
     */
    private RuleContext extractRuleContext(final String orderNo) {
        /*查询订单信息*/
        PosOrderPo orderPo = posOrderMapper.selectById(orderNo);
        List<PosOrderItemPo> posOrderItemPos = posOrderItemMapper.selectList(Wrappers.<PosOrderItemPo>lambdaQuery().eq(PosOrderItemPo::getOrderNo, orderNo));
        MemberInfo member = memberMapper.selectById(orderPo.getMemberId());
        return RuleContext.builder()
                .member(member)
                .order(orderPo)
                .orderItemList(posOrderItemPos)
                .build();
    }

    private MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> run(Integer diff, MemberInfo memberInfo, String orderNo, String desc) {

        IntegralOrderPo order = IntegralOrderPo.builder()
                .memberId(memberInfo.getMemberId())
                .memberName(memberInfo.getMemberName())
                .memberPhone(memberInfo.getMobilePhone())
                .counterId(memberInfo.getCounterId())
                .counterName(memberInfo.getCounterName())
                .bizType(IntegralBizTypeEnum.INTEGRAL_MAINTAIN.getCode())
                .bizNo(orderNo)
                .bizTime(LocalDateTime.now())
                .bizQty(BigInteger.ZERO.intValue())
                .bizAmt(BigDecimal.ZERO)
                .paidQty(BigInteger.ZERO.intValue())
                .gainQty(diff)
                .integralQty(diff)
                .baCode("admin")
                .baName("admin")
                .createTime(LocalDateTime.now())
                .build();

        IntegralOrderItemPo item = IntegralOrderItemPo.builder()
                .integralOrderId(order.getIntegralOrderId())
                .counterId(memberInfo.getCounterId())
                .counterName(memberInfo.getCounterName())
                .memberId(memberInfo.getMemberId())
                .memberName(memberInfo.getMemberName())
                .memberPhone(memberInfo.getMobilePhone())
                .integralType(IntegralTypeEnum.INTEGRAL_MAINTAIN.getCode())
                .bizType(IntegralBizTypeEnum.INTEGRAL_MAINTAIN.getCode())
                .bizNo(orderNo)
                .bizTime(LocalDateTime.now())
                .bizItemNo(StringUtils.EMPTY)
                .goodsBarCode(StringUtils.EMPTY)
                .integralQty(diff)
                .bizItemDesc(StringUtils.EMPTY)
                .bizItemPrice(BigDecimal.ZERO)
                .bizItemAmt(BigDecimal.ZERO)
                .discountAmt(BigDecimal.ZERO)
                .bizItemQty(BigInteger.ZERO.intValue())
                .activityRuleDesc(desc)
                .multiple(BigDecimal.ZERO)
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();

        IntegralAccountPo account = IntegralAccountPo.builder()
                .memberId(memberInfo.getMemberId())
                .memberName(memberInfo.getMemberName())
                .memberPhone(memberInfo.getMobilePhone())
                .counterId(memberInfo.getCounterId())
                .counterName(memberInfo.getCounterName())
                .avlQty(diff)
                .totalQty(diff)
                .saleQty(diff)
                .exchQty(null)
                .nextExpireTime(null)
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();

        List<IntegralOrderItemPo> integralOrderItemList = new ArrayList<>();
        integralOrderItemList.add(item);
        return new MutableTriple(order, integralOrderItemList, account);
    }

    @Transactional(rollbackFor = Exception.class)
    public void changeBalance(MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> triple, Integer diff) {
        int rows = integralOrderMapper.insert(triple.getLeft());
        if (rows == 0) {
            log.error("积分订单主表插入失败,data={}", triple.getLeft());
            throw new BizException("积分订单主表插入失败");
        }
        //设置子表的integralOrderId
        triple.getMiddle().forEach(e -> e.setIntegralOrderId(triple.getLeft().getIntegralOrderId()));
        rows = integralOrderItemMapper.batchInsert(triple.getMiddle());
        if (rows != triple.getMiddle().size()) {
            log.error("积分订单主表插入失败,data={}", triple.getMiddle());
            throw new BizException("积分订单主表插入失败");
        }
        rows = integralAccountMapper.changeBalance(triple.getRight().getMemberId(), diff, 0, null, false, false);
        if (rows == 0) {
            log.error("【销售积分积累】积分订单主表插入失败or积分更新失败,data={}", triple.getMiddle());
            throw new BizException("【销售积分积累】积分订单主表插入失败or积分更新失败");
        }

    }

    @Transactional(rollbackFor = Exception.class)
    public void integralAmendmentForOrder(String orderNo, String amendmentType) {
        PosOrderPo posOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                .eq(PosOrderPo::getOrderNo, orderNo));
        MemberInfo memberInfo = StringUtils.isBlank(posOrderPo.getMemberId()) ? null : memberMapper.selectById(posOrderPo.getMemberId().trim());
        /*5、库存处理,预订单没有真正出入库操作*/
        if (!OrderTypeEnum.BOOK.getCode().equals(posOrderPo.getOrderType()) && amendmentType.equals("0")) {
            Order4StockEvent order4StockEvent = new Order4StockEvent(this, orderNo);
            this.applicationContext.publishEvent(order4StockEvent);
            return;
        }
        //4、会员入会&升降级-->积分逻辑处理
        if (memberInfo != null && amendmentType.equals("1")) {
            Order4MemberEntranceEvent order4MemberEntranceEvent = new Order4MemberEntranceEvent(this, memberInfo.getMemberId(), orderNo);
            this.applicationContext.publishEvent(order4MemberEntranceEvent);
            return;
        }
        //8、用户购买完以后判断是否有需要发下的优惠券并下发
        if (memberInfo != null && amendmentType.equals("2")) {
            OnlyAddCouponEvent onlyAddCouponEvent = new OnlyAddCouponEvent(memberInfo.getMemberId());
            this.applicationContext.publishEvent(onlyAddCouponEvent);
            return;
        }
        //新规则
        if (memberInfo != null && amendmentType.equals("4")) {
            //2021年1月25日13:39:25 积分控制在等级变化前后等级去计算的
            SystemConfigPo systemConfigPoList = systemConfigMapper.selectOne(Wrappers.<SystemConfigPo>lambdaQuery()
                    .eq(SystemConfigPo::getParamKey, SystemPosConfigEnum.UPGRADE_LEVEL_INTEGRAL.getMsg()));
            if (systemConfigPoList == null || systemConfigPoList.getStatus().equals(CommonStatusEnum.INVALID.getCode())) {
                throw new BizException("缺少积分配置！");
            }
            //0：升级前；1：升级后
            if (systemConfigPoList.getParamValue().equals(BigInteger.ZERO.toString())) {
                Order4IntegralBeforeLevelEvent order4IntegralBeforeLevelEvent = new Order4IntegralBeforeLevelEvent(this, memberInfo.getMemberId(), orderNo);
                this.applicationContext.publishEvent(order4IntegralBeforeLevelEvent);
            } else if (systemConfigPoList.getParamValue().equals(BigInteger.ONE.toString())) {
                //先等级后积分
                Order4MemberEntranceEvent order4MemberEntranceEvent = new Order4MemberEntranceEvent(this, memberInfo.getMemberId(), orderNo);
                this.applicationContext.publishEvent(order4MemberEntranceEvent);
            } else {
                throw new BizException("错误的积分配置！");
            }
        }
        //单独的积分处理
        if (amendmentType.equals("3")) {
            Order4IntegralEvent order4IntegralEvent = new Order4IntegralEvent(this, orderNo);
            this.applicationContext.publishEvent(order4IntegralEvent);
            return;
        }
    }

    public void maintenance(String memberId, String memberPhone, Integer integralQty, String remark) {
        MemberInfo memberInfo = memberMapper.selectById(memberId);
        if (!memberInfo.getMemberCardNumber().equals(memberPhone)) {
            log.error("{}对应的数据库手机号 {}与输入的手机号 {}不同！", memberId, memberInfo.getMemberCardNumber(), memberPhone);
            return;
        }
        String orderNo = IdGenerator.getShorterSerialNo("PT");
        MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> result = this.run(integralQty, memberInfo, orderNo, remark);
        //事务处理落地数据
        this.changeBalance(result, integralQty);
    }
}
