package com.ruihe.app.service.ding;

import com.dingtalk.api.DefaultDingTalkClient;
import com.dingtalk.api.DingTalkClient;
import com.dingtalk.api.request.*;
import com.dingtalk.api.response.*;
import com.ruihe.common.dao.bean.ding.DingConfig;
import com.ruihe.common.exception.BizException;
import com.taobao.api.TaobaoResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 处理钉钉回调请求
 */

@Slf4j
@Service
public class DingApi {
    /**
     * 调用钉钉api需要指定某个组织下的appKey等参数，这些参数是存在数据库里，收到钉钉消息会解密出corpId
     * DingConfig 是根据corpId从数据库里查询出来放到当前请求上下文中，请求完成后要清除掉此变量
     */
    private final ThreadLocal<DingConfig> dingConfig = new ThreadLocal<>();
    private final Map<String, String> accessTokens = new ConcurrentHashMap<>();
    private final String notifyUrl = "https://api.233.rulaizhi.com/pos/ding/notify";

    /**
     * 获取用户信息
     * https://ding-doc.dingtalk.com/doc#/serverapi2/ege851
     */
    public OapiUserGetResponse getUser(String userId) {
        return apiCall(() -> {
            String url = "https://oapi.dingtalk.com/user/get";
            DefaultDingTalkClient client = new DefaultDingTalkClient(url);
            OapiUserGetRequest req = new OapiUserGetRequest();
            req.setUserid(userId);
            req.setHttpMethod("GET");
            return client.execute(req, accessToken());
        });
    }

    /**
     * 查询用户所在考勤组
     * https://ding-doc.dingtalk.com/doc#/serverapi2/uvt47u
     */
    public OapiAttendanceGetusergroupResponse getUserGroup(String userId) {
        return apiCall(() -> {
            String url = "https://oapi.dingtalk.com/topapi/attendance/getusergroup";
            DingTalkClient client = new DefaultDingTalkClient(url);
            OapiAttendanceGetusergroupRequest request = new OapiAttendanceGetusergroupRequest();
            request.setUserid(userId);
            return client.execute(request, accessToken());
        });
    }

    /**
     * 获取考勤组详情, 结果中name字段对应系统中counterId
     * https://ding-doc.dingtalk.com/doc#/serverapi2/ksk4o2/ZDUSE
     */
    public OapiAttendanceGroupQueryResponse getGroupInfo(String opUserId, long groupId) {
        return apiCall(() -> {
            DingTalkClient client = new DefaultDingTalkClient("https://oapi.dingtalk.com/topapi/attendance/group/query");
            OapiAttendanceGroupQueryRequest req = new OapiAttendanceGroupQueryRequest();
            req.setOpUserId(opUserId);
            req.setGroupId(groupId);
            return client.execute(req, accessToken());
        });
    }

    /**
     * 根据审批实例id调用此接口获取审批实例详情
     * https://ding-doc.dingtalk.com/doc#/serverapi2/xgqkvx
     */
    public OapiProcessinstanceGetResponse getProcessInstance(String processInstanceId) {
        return apiCall(() -> {
            DingTalkClient client = new DefaultDingTalkClient("https://oapi.dingtalk.com/topapi/processinstance/get");
            OapiProcessinstanceGetRequest request = new OapiProcessinstanceGetRequest();
            request.setProcessInstanceId(processInstanceId);
            return client.execute(request, accessToken());
        });
    }

    /**
     * 注册业务事件回调接口
     * https://ding-doc.dingtalk.com/doc#/serverapi2/pwz3r5
     */
    public OapiCallBackRegisterCallBackResponse setCallbackUrl() {
        String[] tag = {
                "attendance_check_record",
                "attendance_schedule_change",
                "attendance_overtime_duration",
                "bpms_task_change",
                "bpms_instance_change"
        };
        return apiCall(() -> {
            DingTalkClient client = new DefaultDingTalkClient("https://oapi.dingtalk.com/call_back/register_call_back");
            OapiCallBackRegisterCallBackRequest request = new OapiCallBackRegisterCallBackRequest();
            request.setUrl(notifyUrl);
            request.setAesKey(dingConfig.get().getAesKey());
            request.setToken(dingConfig.get().getToken());
            request.setCallBackTag(List.of(tag));
            return client.execute(request, accessToken());
        });
    }

    /**
     * https://ding-doc.dingtalk.com/doc#/serverapi2/pwz3r5/9350bba9
     * 删除事件回调接口
     */
    public OapiCallBackDeleteCallBackResponse deleteCallbackUrl() {
        return apiCall(() -> {
            DingTalkClient client = new DefaultDingTalkClient("https://oapi.dingtalk.com/call_back/delete_call_back");
            OapiCallBackDeleteCallBackRequest request = new OapiCallBackDeleteCallBackRequest();
            request.setHttpMethod("GET");
            return client.execute(request, accessToken());
        });
    }

    public String accessToken() {
        return accessToken(false);
    }

    public String accessToken(boolean forceRefresh) {
        String corpId = dingConfig.get().getCorpId();
        String accessToken = accessTokens.get(corpId);
        if (!StringUtils.isBlank(accessToken) && !forceRefresh) {
            return accessToken;
        }
        OapiGettokenResponse response = apiCall(() -> {
            String url = "https://oapi.dingtalk.com/gettoken";
            DefaultDingTalkClient client = new DefaultDingTalkClient(url);
            OapiGettokenRequest request = new OapiGettokenRequest();
            request.setAppkey(dingConfig.get().getAppKey());
            request.setAppsecret(dingConfig.get().getAppSecret());
            request.setHttpMethod("GET");
            return client.execute(request);
        });
        if (response == null) {
            throw new BizException("钉钉获取accessToken失败");
        }
        accessToken = response.getAccessToken();
        accessTokens.put(corpId, accessToken);
        return accessToken;
    }

    public DingConfig getConfig() {
        return dingConfig.get();
    }

    public void setConfig(DingConfig config) {
        dingConfig.set(config);
    }

    public void clearConfig() {
        dingConfig.remove();
    }

    /**
     * 处理调用失败重试3次，以及accessToken失效刷新
     */
    private <T extends TaobaoResponse> T apiCall(Callable<T> callable) {
        int retry = 3;
        while (retry-- > 0) {
            try {
                T response = callable.call();
                // accessToken过期, 给我刷新
                if (response.getSubCode().equals("40014")) {
                    accessToken(true);
                    continue;
                }
                return response;
            } catch (Exception e) {
                if (retry == 0) {
                    throw new BizException("钉钉接口调用失败", e);
                }
            }
        }
        // never here
        return null;
    }
}
