package com.ruihe.app.dto.face;

import lombok.Builder;
import lombok.Data;

/**
 * 大类(标签信息) 记录的是每个大类的综合信息(最严重级别,最严重类型,最严重数量,综合扣分)
 */
@Data
@Builder
public class LabelOverviewInfo {

    private String label;//标签
    private String labelName;//标签中文名

    //因为每个指标的严重程度设计的枚举值个数不统一(有的指标严重等级有3个,有的有4个,有的又有5个),为了统一下每个指标的严重程度数值能一致,这里为修复过后的值(以严重等级4为基准,3,5的往4上靠)
    private Integer fixLevel;
    private Integer maxLevel;//标签最严重等级(这里为每个指标的原始等级,不能做调整,因为原始值要在配置表中取对应数值的中文描述,修复过有可能无法取到正确的值)
    private String maxLevelName;//标签最严重中文名

    private Integer maxType;//标签最严重类型
    private String maxTypeName;//标签最严重类型中文名

    private Integer deduct;//扣减分数
    private Integer maxNumber;//标签最严重等级对应数量

    /**
     * 检查当前标签是否含有问题项   如果标签里的任意各项子指标的严重程度都<=1(1是无问题)的话 那么该指标就无问题 反之就又问题
     *
     * @return 各项指标是否有问题
     */
    public boolean thisLabelIsProblemData() {
        return this.getMaxLevel() > 1;
    }

}
