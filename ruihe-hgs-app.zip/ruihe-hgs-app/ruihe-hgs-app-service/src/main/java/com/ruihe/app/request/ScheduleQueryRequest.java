package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author LiangYuan
 * @date 2021-03-31 14:29
 */
@ApiModel(value = "ScheduleQueryRequest", description = "排班管理编辑查询请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScheduleQueryRequest implements Serializable {

    @NotBlank(message = "排班年月不能为空")
    @ApiModelProperty(value = "排班年月")
    private String scheduleMonth;

    @NotNull(message = "排班日不能为空")
    @ApiModelProperty(value = "排班日")
    private Integer scheduleDay;

    @NotBlank(message = "柜台id不能为空")
    @ApiModelProperty(value = "柜台id")
    private String counterId;

}
