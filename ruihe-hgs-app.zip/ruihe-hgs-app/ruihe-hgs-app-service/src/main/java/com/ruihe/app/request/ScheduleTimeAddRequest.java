package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @author LiangYuan
 * @date 2021-03-31 14:29
 */
@ApiModel(value = "ScheduleTimeAddRequest", description = "排班管理新增排班时间信息请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScheduleTimeAddRequest implements Serializable {

    @NotBlank(message = "柜台id不能为空")
    @ApiModelProperty(value = "柜台id")
    private String counterId;

    @NotBlank(message = "柜台名称不能为空")
    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @NotNull(message = "时间类型不能为空")
    @ApiModelProperty(value = "时间类型：0早中晚班，1早晚班")
    private Integer type;

    @NotEmpty(message = "时间不能为空")
    @ApiModelProperty(value = "时间")
    private List<ScheduleTimeRequest> timeRequestList;
}
