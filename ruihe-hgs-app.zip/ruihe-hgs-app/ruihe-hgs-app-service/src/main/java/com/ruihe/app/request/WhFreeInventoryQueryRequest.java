package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author 梁远
 * @Description 自由盘点单查询实体
 * @create 2019-10-22 15:12
 */
@ApiModel(value = "WhFreeInventoryQueryRequest", description = "自由盘点单查询实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhFreeInventoryQueryRequest implements Serializable {

    @NotBlank(message = "柜台编码不能为空")
    @ApiModelProperty(value = "柜台编码")
    private String counterId;

    @ApiModelProperty(value = "开始时间")
    private LocalDate startTime;

    @ApiModelProperty(value = "结束时间")
    private LocalDate endTime;

    @ApiModelProperty(value = "审核状态：0编辑中，1未审核，2一审通过，3一审拒绝，4审核通过，5审核拒绝")
    private Integer status;

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
