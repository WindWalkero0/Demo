package com.ruihe.app.service.ding;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruihe.app.mapper.ding.DingConfigMapper;
import com.ruihe.common.dao.bean.ding.DingCheck;
import com.ruihe.common.dao.bean.ding.DingConfig;
import com.ruihe.common.exception.BizException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.util.function.Tuple2;

/**
 * 处理钉钉回调请求
 */

@Slf4j
@Service
@RequiredArgsConstructor
public class DingService {
    private final DingApi dingApi;
    private final DingConfigMapper configMapper;

    /**
     * 所有加解密的token和aesKey都一样，取第一个就好了
     */
    private DingTalkEncryptor encryptor() {
        DingConfig config = configMapper.first();
        if (config == null) {
            throw new BizException("未找到对应的appKey配置");
        }
        try {
            return new DingTalkEncryptor(config.getToken(), config.getAesKey());
        } catch (DingTalkEncryptException e) {
            throw new BizException(e);
        }
    }

    public Object onMsgReceived(String signature, Long timestamp, String nonce, JSONObject body) {
        String params = "signature:" + signature + " timestamp:" + timestamp + " nonce:" + nonce + " body:" + body;
        try {
            DingTalkEncryptor encryptor = encryptor();

            // 从post请求的body中获取回调信息的加密数据进行解密处理
            String encrypt = body.getString("encrypt");
            Tuple2<String, String> tuple = encryptor.getDecryptMsg(signature, timestamp.toString(), nonce, encrypt);
            String corpId = tuple.getT1();
            String plainText = tuple.getT2();
            JSONObject content = JSON.parseObject(plainText);
            log.info("ding_msg: \n {} \n {}", corpId, plainText);

            DingConfig config = configMapper.findByCropId(corpId);
            dingApi.setConfig(config);

            // 根据回调事件类型做不同的业务处理
            String eventType = content.getString("EventType");
            if (Constant.EVENT_ATTENDANCE_CHECK_RECORD.equals(eventType)) {
                handleAttendanceCheckRecord(content);
            } else if (Constant.EVENT_BPMS_INSTANCE_CHANGE.equals(eventType)) {
                handleBpmsInstanceChange(content);
            }

            // 返回success的加密信息表示回调处理成功
            return encryptor.getEncryptedMap("success", timestamp, nonce, corpId);
        } catch (Exception e) {
            //失败的情况，应用的开发者应该通过告警感知，并干预修复
            log.error("ding callback fail." + params, e);
            return "fail";
        } finally {
            dingApi.clearConfig();
        }
    }

    /**
     * 处理考勤打卡
     * https://ding-doc.dingtalk.com/doc#/serverapi2/geuog4
     */
    public void handleAttendanceCheckRecord(JSONObject content) {
        String groupId = content.getString("groupId");
        String userId = content.getString("userId");
        var groupInfo = dingApi.getGroupInfo(userId, Long.parseLong(groupId));
        String cropId = dingApi.getConfig().getCorpId();
        log.info(JSONObject.toJSONString(groupInfo));
        DingCheck dingCheck = DingCheck.builder()
                .build();
    }

    /**
     * 处理转店审批
     * https://ding-doc.dingtalk.com/doc#/serverapi2/lwwrcu
     */
    public void handleBpmsInstanceChange(JSONObject content) {
        if (!"finish".equals(content.getString("type")) || !"agree".equals(content.getString("result"))) {
        }

        String title = content.getString("title");
        if (title.contains("调店申请")) {

        }
        String processInstanceId = content.getString("processInstanceId");
//        var processInstance = dingApi.getProcessInstance(processInstanceId);

    }

}
