package com.ruihe.app.dto.face.property;

import lombok.Data;

import java.util.List;

@Data
public class Sensitivity {

    private List<SensitivityCategory> sensitivityCategory;

    private String sensitivityMaskPath;

    private Integer typeId;

    private SensitivityOverall sensitivityOverall;
}
