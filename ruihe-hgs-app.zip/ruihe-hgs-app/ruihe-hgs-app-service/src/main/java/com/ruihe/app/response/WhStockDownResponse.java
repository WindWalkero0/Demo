package com.ruihe.app.response;

import com.ruihe.app.vo.WhStockDownVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**

/**
 * 库存打印响应
 * @author qubin
 * @date 2021/5/31 9:01
 */
@ApiModel(value = "WhStockDownResponse", description = " 库存打印响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhStockDownResponse implements Serializable {

    @ApiModelProperty("大分类信息")
    Map<Integer, List<WhStockDownVo>> bigCatInfoList;

    @ApiModelProperty("中分类信息")
    Map<Integer, List<WhStockDownVo>> mediumCatInfoList;

    @ApiModelProperty("小分类信息")
    Map<Integer, List<WhStockDownVo>> smallCatInfoList;
}
