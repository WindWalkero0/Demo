package com.ruihe.app.request;


import com.ruihe.app.vo.WhTransferItemVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

@ApiModel(value = "WhTransferOutRequest", description = "调出单实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhTransferOutRequest implements Serializable {

    @NotBlank(message = "调拨单号不能为空")
    @ApiModelProperty(value = "调拨单号(也做唯一键)")
    private String transferOrderNo;

    @NotNull(message = "确认调出商品总数量不能为空")
    @ApiModelProperty(value = "确认调出商品总数量")
    private Integer ackOutQty;

    @ApiModelProperty(value = "确认调出金额")
    private BigDecimal ackAmt;

    @NotBlank(message = "调出ba代码不能为空")
    @ApiModelProperty(value = "调出ba代码")
    private String outBaCode;

    @NotBlank(message = "调出ba姓名不能为空")
    @ApiModelProperty(value = "调出ba姓名")
    private String outBaName;

    @NotEmpty(message = "调拨单明细不能为空")
    @ApiModelProperty(value = "调拨单明细")
    protected List<WhTransferItemVo> transferItemList;

}
