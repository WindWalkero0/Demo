package com.ruihe.app.response.material;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author qubin
 * @date 2021年07月05日 13:44
 */
@ApiModel(value = "MaterialProjectCategoryResponse", description = "导购助手-资料项目分类响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MaterialProjectCategoryResponse implements Serializable {

    /**
     *  项目id
     */
    @ApiModelProperty("项目id")
    private Integer projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("分类id")
    private Integer  categoryId;

    @ApiModelProperty("等级名称")
    private String categoryName;

    @ApiModelProperty("封面地址")
    private String coverUrl;
}
