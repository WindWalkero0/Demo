package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 退库确认事件
 *
 * @author William
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class WhReturnEvent extends ApplicationEvent {

    /**
     * 单号
     */
    private String orderNo;

    public WhReturnEvent(Object source, String orderNo) {
        super(source);
        this.orderNo = orderNo;
    }
}
