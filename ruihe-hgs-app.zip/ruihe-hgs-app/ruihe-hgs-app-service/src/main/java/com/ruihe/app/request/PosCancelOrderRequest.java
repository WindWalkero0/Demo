package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * 取消下单操作
 *
 * @author William
 */
@ApiModel(value = "PosCancelOrderRequest", description = "取消订单实体")
@Data
@Builder
public class PosCancelOrderRequest implements Serializable {

    @ApiModelProperty("原始订单号")
    private String orderNo;

    @ApiModelProperty("柜台id")
    private String counterId;

    @ApiModelProperty("销售员代码")
    private String baCode;

    @ApiModelProperty("销售员姓名")
    private String baName;

    @ApiModelProperty("交易类型，1销售,2退货")
    private Integer transType;

    @ApiModelProperty("订单类型：1销售,2预定单,3积分兑换")
    private Integer orderType;

}
