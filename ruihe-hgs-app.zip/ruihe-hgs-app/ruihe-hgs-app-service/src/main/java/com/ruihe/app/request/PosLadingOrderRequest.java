package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-19 16:54
 */
@ApiModel(value = "PosLadingOrderRequest", description = "预订单提取保存实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosLadingOrderRequest implements Serializable {

    @NotNull(message = "订单号不能为空")
    @ApiModelProperty(value = "订单号")
    private String orderNo;

    @ApiModelProperty(value = "会员ID")
    private String memberId;

    @NotNull(message = "手机号不能为空")
    @ApiModelProperty(value = "会员手机号")
    private String memberPhone;

    @ApiModelProperty(value = "柜员编码")
    private String baCode;

    @ApiModelProperty(value = "柜员姓名")
    private String baName;

    @ApiModelProperty("是否检查库存，默认为true, 为了0510版本提取预订单，后面删除")
    @Builder.Default
    private Boolean checkStock = true;

    @NotEmpty(message = "预订单提取详情不能为空")
    @ApiModelProperty(value = "预订单提取详情保存实体")
    List<PosLadingOrderItemRequest> posLadingOrderItemRequestList;
}
