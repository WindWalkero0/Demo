package com.ruihe.app.response.member;

import com.ruihe.common.dao.bean.member.MemberActivityProduct;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MemberCouponResponse {

    //是否购买 0否 1购买
    public Integer buyType;

    //子活动uid
    public String activityId;

    //子活动名称
    public String activityName;

    //主活动id
    public String subActivityId;

    //使用结束时时间
    public String stopTime;

    //数量
    public Integer count;

    //couponId
    public String couponId;

    //coupon码
    public String coupon;

    //金额
    public String price;

    //奖励类型 0礼品抵用券  1金额抵用券
    public Integer rewardType;

    //优惠券类型  0 会员活动优惠券  1发券活动优惠券
    public Integer couponType;

    //活动奖励商品信息
    List<MemberActivityProduct> products;

    /**
     * 是否全选  0否 1是
     */
    private Integer selectType;

    /**
     * 可选商品数量
     */
    private Integer selectCount;



}
