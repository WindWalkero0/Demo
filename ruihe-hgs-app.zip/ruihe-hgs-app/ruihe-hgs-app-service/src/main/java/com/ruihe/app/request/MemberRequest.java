package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-14 11:12
 */
@ApiModel(value = "MemberRequest", description = "会员注册实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberRequest implements Serializable {
    @ApiModelProperty(value = "会员姓名")
    private String memberName;
    @ApiModelProperty(value = "手机号")
    private String mobilePhone;
    @ApiModelProperty(value = "生日")
    private String birthday;
    @ApiModelProperty(value = "性别")
    private String gender;
    @ApiModelProperty(value = "省份id")
    private String provinceId;
    @ApiModelProperty(value = "城市id")
    private String cityId;
    @ApiModelProperty(value = "地址")
    private String address;
    @ApiModelProperty(value = "推荐会员手机号")
    private String rcmdMemberPhone;
    @ApiModelProperty(value = "肤质")
    private String skinType;
    @ApiModelProperty(value = "职业")
    private String career;
    @ApiModelProperty(value = "收入")
    private String income;
    @ApiModelProperty(value = "电话")
    private String telephone;
    @ApiModelProperty(value = "备注1")
    private String remarkOne;
}
