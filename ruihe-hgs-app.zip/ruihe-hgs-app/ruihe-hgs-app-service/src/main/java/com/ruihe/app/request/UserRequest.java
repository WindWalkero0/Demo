package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Author 胡坤
 * @Date 2019年10月10日11:45:07
 */
@ApiModel(value = "UserRequest", description = "添加柜员接收类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserRequest implements Serializable {

    @ApiModelProperty(value = "身份证号码")
    public String numberId;

    @ApiModelProperty(value = "手机号码")
    public String phone;

    @ApiModelProperty(value = "姓名")
    public String name;

    @ApiModelProperty(value = "柜台编号")
    public String counterId;

    @ApiModelProperty(value = "柜台名称")
    public String counterName;

    @ApiModelProperty(value = "当前页数")
    public Integer pageNumber;

    @ApiModelProperty(value = "分页大小")
    public Integer pageSize;

    @ApiModelProperty(value = "BA唯一标识")
    public String uniqueId;

    @ApiModelProperty(value = "BA状态")
    public Integer status;

    @ApiModelProperty("验证码")
    private String verificationCode;

}
