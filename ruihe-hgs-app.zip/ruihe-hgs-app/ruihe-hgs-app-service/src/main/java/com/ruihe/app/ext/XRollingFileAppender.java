package com.ruihe.app.ext;

import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.rolling.RollingFileAppender;
import com.ruihe.common.ext.SpringContextHolder;
import com.ruihe.msger.client.MsgerClient;
import com.ruihe.msger.dto.ErrorLogDto;

import java.util.List;

/**
 * 扩展滚动日志文件追加器，异步接收error、fatal级别日志事件时进行钉钉报警
 *
 * @author William
 */
public class XRollingFileAppender extends RollingFileAppender<ILoggingEvent> {

    private MsgerClient msgerClient;

    @Override
    protected void subAppend(ILoggingEvent event) {
        //先将日志刷盘
        super.subAppend(event);
        //解决高并发下调用msgerClient.alarm(errorLogDto);死锁问题
        synchronized (MsgerClient.class) {
            try {
                //获取encoder
                PatternLayoutEncoder patternLayoutEncoder = (PatternLayoutEncoder) super.getEncoder();
                //根据layout模板输出日志
                String logText = patternLayoutEncoder.getLayout().doLayout(event);
                //获取应用id
                String applicationName = SpringContextHolder.getApplicationContext().getApplicationName();
                //组装报警请求
                ErrorLogDto errorLogDto = ErrorLogDto.builder().serviceId(applicationName).webhooks(List.of()).logText(logText).build();
                if (msgerClient == null) {
                    msgerClient = SpringContextHolder.getApplicationContext().getBean(MsgerClient.class);
                }
                // 应用级别的error日志报警
                msgerClient.alarm(errorLogDto);
            } catch (Exception e) {
                //注意error日志已经做了报警处理，此时如果异常再输入到logback会导致递归调用，切记不要输入到日志文件，否则导致OOM
                e.printStackTrace();
            }
        }
    }
}
