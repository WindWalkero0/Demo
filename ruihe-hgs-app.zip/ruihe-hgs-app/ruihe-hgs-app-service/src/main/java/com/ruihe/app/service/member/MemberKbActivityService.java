package com.ruihe.app.service.member;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.enums.InvitingStatusEnum;
import com.ruihe.app.enums.OrderNoPrefixEnum;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.mapper.member.MemberCouponMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.constant.RedisPrefixKeyConst;
import com.ruihe.common.dao.bean.integral.IntegralOrderItemPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderPo;
import com.ruihe.common.dao.bean.member.*;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.dao.mapper.*;
import com.ruihe.common.dao.mapper.integral.IntegralAccountMapper;
import com.ruihe.common.dao.mapper.integral.IntegralOrderItemMapper;
import com.ruihe.common.dao.mapper.integral.IntegralOrderMapper;
import com.ruihe.common.enums.integral.IntegralBizTypeEnum;
import com.ruihe.common.enums.integral.IntegralTypeEnum;
import com.ruihe.common.enums.member.MemberCouponTypeEnum;
import com.ruihe.common.enums.prefix.PrefixEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.service.RedisCacheService;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.TimeUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;


/**
 * 口碑礼
 *
 * @author fly
 */
@Slf4j
@Service
public class MemberKbActivityService {

    @Autowired
    private CustomService customService;

    @Autowired
    private MemberCouponMapper memberCouponMapper;

    @Autowired
    private MemberKbActivityMapper memberKbActivityMapper;

    @Autowired
    private KbCouponProductMapper kbCouponProductMapper;

    @Autowired
    private MemberInvitingMapper memberInvitingMapper;

    @Autowired
    private KbAwardLinkMapper kbAwardLinkMapper;

    @Autowired
    private MemberInfoMapper memberInfoMapper;

    @Autowired
    private IntegralOrderMapper integralOrderMapper;

    @Autowired
    private IntegralOrderItemMapper integralOrderItemMapper;

    @Autowired
    private IntegralAccountMapper integralAccountMapper;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private RedisCacheService redisService;


    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void kbActivity(String orderNo) {
        //校验
        KbAwardLink kbAwardLink = kbAwardLinkMapper.selectOne(Wrappers.<KbAwardLink>lambdaQuery().eq(KbAwardLink::getBizOrderNo,
                orderNo));
        if (kbAwardLink != null) {
            log.error("邀请奖励关系已建立" + orderNo);
            return;
        }
        PosOrderPo posOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery().eq(PosOrderPo::getOrderNo, orderNo));
        if (StringUtils.isBlank(posOrderPo.getMemberId())) {
            //不是会员消费不存在的
            return;
        }
        //找到当前进行中的口碑礼订单
        KbActivity kbActivity = memberKbActivityMapper.selectOne(Wrappers.<KbActivity>lambdaQuery()
                .eq(KbActivity::getStatus, 0)
                .lt(KbActivity::getStartTime, LocalDateTime.now())
                .gt(KbActivity::getEndTime, LocalDateTime.now()));
        if (kbActivity == null) {
            //没有进行中的口碑礼活动
            return;
        }
        //根据单号 查找消费订单
        //找到消费用户的上一级
        MemberInfo memberInfo = memberInfoMapper.selectById(posOrderPo.getMemberId());
        //获取上级用户
        MemberInviting memberInviting = memberInvitingMapper.selectOne(Wrappers.<MemberInviting>lambdaQuery()
                .eq(MemberInviting::getInviteeMemberId, memberInfo.getMemberId())
                .eq(MemberInviting::getInviteLevel, 1));
        if (memberInviting == null) {
            //不存在邀约关系
            return;
        }
        //2021年3月24日19:45:38  邀约关系里冗余了消息
        MemberInviting memberInvitingNew = MemberInviting.builder()
                .invitingId(memberInviting.getInvitingId())
                .kbStatus(InvitingStatusEnum.UN_COMMIT.getCode())
                .remark("")
                .build();
        //如果状态比当前状态大就更新
        if (posOrderPo.getTransType().equals(OrderTransTypeEnum.GOODS_OUT.getCode())) {
            //销售送奖励
            Boolean checkDelivery = checkDelivery(posOrderPo, memberInfo, kbActivity, memberInviting, memberInvitingNew);
            if (!checkDelivery) {
                //没有匹配上
                updateInviting(memberInviting, memberInvitingNew);
                return;
            }
            memberInvitingNew.setKbStatus(InvitingStatusEnum.AWARDED.getCode());
            memberInvitingNew.setRemark("");
            updateInviting(memberInviting, memberInvitingNew);
            award(kbActivity, memberInviting, posOrderPo);
        } else if (posOrderPo.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
            //退货回收奖励
            returnAward(kbActivity, memberInviting, posOrderPo, memberInvitingNew);
            updateInviting(memberInviting, memberInvitingNew);
        }
    }

    /**
     * 更新关联关系冗余一手
     *
     * @param oldInviting
     * @param newInviting
     */
    private void updateInviting(MemberInviting oldInviting, MemberInviting newInviting) {
        if (oldInviting.getKbStatus() == null || newInviting.getKbStatus() > oldInviting.getKbStatus()) {
            newInviting.setUpdateTime(LocalDateTime.now());
            memberInvitingMapper.updateById(newInviting);
        }
        //如果退货了  然后后面又匹配上了那只有未发放已发放才可以更新
        //老的是3  新的是 1 或者 2 的时候更新
        if ((oldInviting.getKbStatus() != null && oldInviting.getKbStatus().equals(InvitingStatusEnum.RECYCLE.getCode()))
                && (newInviting.getKbStatus().equals(InvitingStatusEnum.UN_AWARD.getCode()) || newInviting.getKbStatus().equals(InvitingStatusEnum.AWARDED.getCode()))) {
            newInviting.setUpdateTime(LocalDateTime.now());
            memberInvitingMapper.updateById(newInviting);
        }
    }

    /**
     * 发放奖励
     *
     * @param kbActivity
     * @param memberInviting
     * @param posOrderPo
     */
    private void award(KbActivity kbActivity, MemberInviting memberInviting, PosOrderPo posOrderPo) {
        //查看奖励内容
        MemberInfo memberInfo = memberInfoMapper.selectById(memberInviting.getInvitorMemberId());
        String bizNo = IdGenerator.getShorterSerialNo(OrderNoPrefixEnum.KB.getCode());
        String couponId = IdGenerator.getSerialNo(PrefixEnum.ACTIVITY_COUPON.getCode());
        KbAwardLink build = KbAwardLink.builder()
                .awardTime(LocalDateTime.now())
                .bizOrderNo(posOrderPo.getOrderNo())
                .kbActivityId(kbActivity.getActivityId())
                .transType(posOrderPo.getTransType())
                .invitingId(memberInviting.getInvitingId())
                .integralOrderId(bizNo)
                .kbCouponId(couponId)
                .build();
        if (kbActivity.getAwardConf().getCouponCheck()) {
            //发券
            createCoupon(kbActivity, posOrderPo, memberInfo, couponId);
        }
        if (kbActivity.getAwardConf().getIntegralCheck()) {
            //给积分
            awardIntegral(kbActivity, memberInfo, bizNo);
        }
        kbAwardLinkMapper.insert(build);
    }

    /**
     * 发放积分
     *
     * @param kbActivity
     * @param memberInfo
     * @param bizNo
     */
    private void awardIntegral(KbActivity kbActivity, MemberInfo memberInfo, String bizNo) {
        IntegralOrderPo order = IntegralOrderPo.builder()
                .memberId(memberInfo.getMemberId())
                .memberName(memberInfo.getMemberName())
                .memberPhone(memberInfo.getMobilePhone())
                .counterId(memberInfo.getCounterId())
                .counterName(memberInfo.getCounterName())
                .bizType(IntegralBizTypeEnum.KB_AWARD.getCode())
                .bizNo(bizNo)
                .bizTime(LocalDateTime.now())
                .bizQty(BigInteger.ZERO.intValue())
                .bizAmt(BigDecimal.ZERO)
                .paidQty(BigInteger.ZERO.intValue())
                .gainQty(0)
                .integralQty(kbActivity.getAwardConf().getQty())
                .surplusQty(kbActivity.getAwardConf().getQty())
                .inteType(1)
                .baCode("系统任务")
                .baName("系统任务")
                .createTime(LocalDateTime.now())
                .build();
        integralOrderMapper.insert(order);
        IntegralOrderItemPo item = IntegralOrderItemPo.builder()
                .integralOrderId(order.getIntegralOrderId())
                .discountAmt(BigDecimal.ZERO)
                .integralQty(order.getIntegralQty())
                .counterId(memberInfo.getCounterId())
                .counterName(memberInfo.getCounterName())
                .memberId(memberInfo.getMemberId())
                .memberName(memberInfo.getMemberName())
                .memberPhone(memberInfo.getMobilePhone())
                .bizType(IntegralBizTypeEnum.KB_AWARD.getCode())
                .activityRuleDesc("口碑礼积分奖励")
                .bizNo(order.getBizNo())
                .bizTime(LocalDateTime.now())
                .bizItemNo("")
                .goodsBarCode("")
                .bizItemDesc("")
                .bizItemAmt(BigDecimal.ZERO)
                .bizItemQty(kbActivity.getAwardConf().getQty())
                .integralType(IntegralTypeEnum.KB_AWARD.getCode())
                .multiple(BigDecimal.ZERO)
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
        integralOrderItemMapper.insert(item);
        int rows = integralAccountMapper.changeBalance(order.getMemberId(), kbActivity.getAwardConf().getQty(), 0, null, false, false);
        if (rows == 0) {
            String errorMsg = String.format("口碑礼奖励积分失败,orderNo=%s,memberId=%s,totalQty=%s,paidQty=%s", order.getBizNo(), order.getMemberId(), kbActivity.getAwardConf().getQty(), kbActivity.getAwardConf().getQty());
            log.error(errorMsg);
            throw new BizException("口碑礼奖励积分失败");
        }
    }

    @Ella(Describe = "进行发券", Author = "fly")
    private void createCoupon(KbActivity kbActivity, PosOrderPo posOrderPo, MemberInfo memberInfo, String couponId) {
        MemberCoupon build = MemberCoupon
                .builder()
                .orderNo(posOrderPo.getOrderNo())//关联订单号
                .activityId(kbActivity.getActivityId())//记录活动id
                .activityName(kbActivity.getName())//活动名称
                .subActivityId(kbActivity.getActivityId())
                .subActivityName(kbActivity.getName())
                .memberId(memberInfo.getMemberId())
                .status(0)//优惠券状态
                .couponType(MemberCouponTypeEnum.KB_ACTIVITY.getCode())//优惠券类型
                .couponCount(1)//优惠券个数
                .memberName(memberInfo.getMemberName())//会员名称
                .memberType(memberInfo.getMemberType())//会员类型
                .mobilePhone(memberInfo.getMobilePhone())//手机号
                .openId(memberInfo.getOpenId())//微信openId
                .build();
        //填充时间
        build.setStartTime(TimeUtils.localTimeFormatString(LocalDateTime.now()));
        build.setStopTime(TimeUtils.localTimeFormatString(LocalDateTime.now().plusDays(kbActivity.getAwardConf().getDay())));
        //进行生成优惠券日志
        MemberCouponLog memberCouponLog = MemberCouponLog
                .builder()
                .activityId(kbActivity.getActivityId())//活动id
                .activityName(kbActivity.getName())//活动名称
                .status(build.getStatus())//优惠券状态
                .memberPhone(memberInfo.getMobilePhone())//手机号
                .memberName(memberInfo.getMemberName())//会员名称
                .memberId(memberInfo.getMemberId())//会员id
                .couponType(build.getCouponType())//优惠券类型
                .build();
        build.setCoupon(kbActivity.getAwardConf().getVoucher() == 1 ? IdGenerator.genCouponCode() : null);
        build.setCouponId(couponId);
        build.setCreateTime(LocalDateTime.now());
        //保存优惠券记录
        memberCouponLog.setId(build.getCouponId());
        memberCouponLog.setCreateTime(LocalDateTime.now());
        Integer save = customService.save(memberCouponLog);
        if (save.equals(0)) {
            log.error("保存优惠券记录失败");
            throw new BizException("保存优惠券记录失败");
        }
        Integer row = customService.save(build);
        if (row.equals(0)) {
            log.error("保存优惠券失败");
            throw new BizException("保存优惠券失败");
        }
    }

    /**
     * 回收奖励
     *
     * @param kbActivity
     * @param memberInviting
     * @param posOrderPo
     */
    private void returnAward(KbActivity kbActivity, MemberInviting memberInviting, PosOrderPo posOrderPo, MemberInviting memberInvitingNew) {
        if (!kbActivity.getDeliveryConf().getReturnBack()) {
            return;
        }
        //退回奖励
        KbAwardLink kbAwardLink = kbAwardLinkMapper.selectOne(Wrappers.<KbAwardLink>lambdaQuery().eq(KbAwardLink::getBizOrderNo, posOrderPo.getPreOrderNo()));
        if (kbAwardLink == null) {
            //没有对应的订单
            return;
        }
        memberInvitingNew.setKbStatus(InvitingStatusEnum.RECYCLE.getCode());
        memberInvitingNew.setRemark("该用户虽然已经完成任务,但后续该用户又进行了退货,因此已发放的奖励进行了收回");
        //扣除redis的次数
        reduceRedis(memberInviting);
        String bizNo = IdGenerator.getShorterSerialNo(OrderNoPrefixEnum.KB.getCode());
        KbAwardLink build = KbAwardLink.builder()
                .awardTime(LocalDateTime.now())
                .bizOrderNo(posOrderPo.getOrderNo())
                .preOrderNo(posOrderPo.getPreOrderNo())
                .kbActivityId(kbActivity.getActivityId())
                .transType(posOrderPo.getTransType())
                .invitingId(memberInviting.getInvitingId())
                .integralOrderId(bizNo)
                .build();
        if (kbAwardLink.getKbCouponId() != null && !"".equals(kbAwardLink.getKbCouponId())) {
            //找到券看用了没 没用就给过期掉 过期了就不管了
            String kbCouponId = kbAwardLink.getKbCouponId();
            MemberCoupon memberCoupon = memberCouponMapper.selectOne(Wrappers.<MemberCoupon>lambdaQuery().eq(MemberCoupon::getCouponId, kbCouponId));
            build.setKbCouponId(kbCouponId);
            //优惠券状态 0未使用  1已使用  2已过期  3已取消\n
            if (memberCoupon.getStatus().equals(1)) {
                log.error(memberInviting.getInvitorMemberId() + "的口碑礼券已使用，不能退回！");
            } else {
                memberCouponMapper.update(null, new UpdateWrapper<MemberCoupon>().eq("coupon_id", kbCouponId).set("status", 3));
            }
        }
        if (kbAwardLink.getIntegralOrderId() != null && !"".equals(kbAwardLink.getIntegralOrderId())) {
            returnIntegral(kbAwardLink.getIntegralOrderId(), bizNo);
        }
        kbAwardLinkMapper.insert(build);
    }

    /**
     * 退货之后减少redis的次数
     *
     * @param memberInviting
     */
    private void reduceRedis(MemberInviting memberInviting) {
        String monthKey = String.format(RedisPrefixKeyConst.KB_MONTH_MEMBER_ID, memberInviting.getInvitorMemberId());
        String dayKey = String.format(RedisPrefixKeyConst.KB_DAY_MEMBER_ID, memberInviting.getInvitorMemberId());
        Integer month = redisService.getObject(monthKey);
        Integer day = redisService.getObject(dayKey);
        //减少一次
        if (month != null && month > 0) {
            this.setRedisMonth(month - 1, monthKey);
        }
        if (day != null && day > 0) {
            this.setRedisDay(day - 1, dayKey);
        }

    }

    private void returnIntegral(String integralOrderId, String bizNo) {
        IntegralOrderPo integralOrderPo = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery().eq(IntegralOrderPo::getBizNo, integralOrderId));
        IntegralOrderPo order = IntegralOrderPo.builder()
                .memberId(integralOrderPo.getMemberId())
                .memberName(integralOrderPo.getMemberName())
                .memberPhone(integralOrderPo.getMemberPhone())
                .counterId(integralOrderPo.getCounterId())
                .counterName(integralOrderPo.getCounterName())
                .bizType(IntegralBizTypeEnum.KB_BACK.getCode())
                .bizNo(bizNo)
                .bizTime(LocalDateTime.now())
                .bizQty(BigInteger.ZERO.intValue())
                .bizAmt(BigDecimal.ZERO)
                .paidQty(BigInteger.ZERO.intValue())
                .gainQty(0)
                .integralQty(integralOrderPo.getIntegralQty() * -1)
                .surplusQty(integralOrderPo.getIntegralQty() * -1)
                .inteType(1)
                .baCode("系统任务")
                .baName("系统任务")
                .createTime(LocalDateTime.now())
                .build();
        integralOrderMapper.insert(order);
        IntegralOrderItemPo item = IntegralOrderItemPo.builder()
                .integralOrderId(order.getIntegralOrderId())
                .discountAmt(BigDecimal.ZERO)
                .integralQty(order.getIntegralQty())
                .counterId(integralOrderPo.getCounterId())
                .counterName(integralOrderPo.getCounterName())
                .memberId(integralOrderPo.getMemberId())
                .memberName(integralOrderPo.getMemberName())
                .memberPhone(integralOrderPo.getMemberPhone())
                .bizType(IntegralBizTypeEnum.KB_BACK.getCode())
                .bizNo(order.getBizNo())
                .bizTime(LocalDateTime.now())
                .activityRuleDesc("口碑礼积分扣除")
                .bizItemNo("")
                .goodsBarCode("")
                .bizItemDesc("")
                .bizItemAmt(BigDecimal.ZERO)
                .bizItemQty(integralOrderPo.getIntegralQty() * -1)
                .integralType(IntegralTypeEnum.KB_BACK.getCode())
                .multiple(BigDecimal.ZERO)
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
        integralOrderItemMapper.insert(item);
        int rows = integralAccountMapper.changeBalance(order.getMemberId(), integralOrderPo.getIntegralQty() * -1, 0, null, false, false);
        if (rows == 0) {
            String errorMsg = String.format("口碑礼奖励积分失败,orderNo=%s,memberId=%s,totalQty=%s,paidQty=%s", order.getBizNo(), order.getMemberId(), integralOrderPo.getIntegralQty() * -1, integralOrderPo.getIntegralQty() * -1);
            log.error(errorMsg);
            throw new BizException("口碑礼奖励积分失败");
        }
    }

    /**
     * 校验是否符合奖励发放条件
     *
     * @param posOrderPo
     * @param memberInfo
     * @param kbActivity
     * @return
     */
    @DS(DBConst.MASTER)
    public Boolean checkDelivery(PosOrderPo posOrderPo, MemberInfo memberInfo, KbActivity kbActivity, MemberInviting memberInviting, MemberInviting memberInvitingNew) {
        DeliveryConf deliveryConf = kbActivity.getDeliveryConf();
        //金额判断
        BigDecimal realAmt = posOrderPo.getRealAmt();
        if (realAmt.compareTo(kbActivity.getDeliveryConf().getAmt()) < 0) {
            memberInvitingNew.setKbStatus(InvitingStatusEnum.UN_COMMIT.getCode());
            return false;
        }
        //时间判断
        String cardIssuingTime = memberInfo.getCardIssuingTime();
        LocalDateTime memberTime = null;
        if (cardIssuingTime.length() == 10) {
            DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            memberTime = LocalDate.parse(cardIssuingTime, dtf1).atTime(0, 0, 0);
        } else if (cardIssuingTime.length() == 19) {
            DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            memberTime = LocalDateTime.parse(cardIssuingTime, dtf2);
        }
        if (posOrderPo.getCreateTime().isAfter(memberTime.plusDays(deliveryConf.getDay()))) {
            memberInvitingNew.setKbStatus(InvitingStatusEnum.UN_COMMIT.getCode());
            return false;
        }
        //会员的发卡时间 必须在活动创建时间之后  在结束时间之后也不能匹配到活动了
        if (memberTime.isBefore(kbActivity.getStartTime())) {
            memberInvitingNew.setKbStatus(InvitingStatusEnum.UN_COMMIT.getCode());
            return false;
        }
        //员工判断
        if (!kbActivity.getDeliveryConf().getAllowEmp()) {
            Integer integer = memberKbActivityMapper.selectEmp(memberInviting.getInvitorMemberId());
            if (integer > 0) {
                memberInvitingNew.setKbStatus(InvitingStatusEnum.UN_AWARD.getCode());
                memberInvitingNew.setRemark("该用户虽然已经完成任务,但是您因为是内部员工,不符合奖励发放条件");
                return false;
            }
        }
        //日月次数限制判断
        //这是邀请人的次数限制不是被邀请人的限制
        String monthKey = String.format(RedisPrefixKeyConst.KB_MONTH_MEMBER_ID, memberInviting.getInvitorMemberId());
        String dayKey = String.format(RedisPrefixKeyConst.KB_DAY_MEMBER_ID, memberInviting.getInvitorMemberId());
        Integer month = redisService.getObject(monthKey);
        Integer day = redisService.getObject(dayKey);
        //三种情况 不存在有日限制没月限制 1.有月限制有日限制 2.有月限制没日限制 3.两个都没
        if (month != null && day == null) {
            //是否包含
            if (month >= deliveryConf.getMonLimit()) {
                memberInvitingNew.setKbStatus(InvitingStatusEnum.UN_AWARD.getCode());
                memberInvitingNew.setRemark("超过当月奖励发放限制,系统未发放改笔奖励");
                return false;
            }
            Integer count = month + 1;
            this.setRedisMonth(count, monthKey);
            this.setRedisDay(1, dayKey);
        } else if (month != null && day != null) {
            if (month >= deliveryConf.getMonLimit()) {
                memberInvitingNew.setKbStatus(InvitingStatusEnum.UN_AWARD.getCode());
                memberInvitingNew.setRemark("超过当月奖励发放限制,系统未发放改笔奖励");
                return false;
            }
            if (day >= deliveryConf.getLimit()) {
                memberInvitingNew.setKbStatus(InvitingStatusEnum.UN_AWARD.getCode());
                memberInvitingNew.setRemark("超过当日奖励发放限制,系统未发放改笔奖励");
                return false;
            }
            Integer count = month + 1;
            Integer countDay = day + 1;
            this.setRedisMonth(count, monthKey);
            this.setRedisDay(countDay, dayKey);
        } else if (month == null && day == null) {
            this.setRedisMonth(1, monthKey);
            this.setRedisDay(1, dayKey);
        }
        return true;
    }


    /**
     * 设置redis缓存与失效时间
     *
     * @param count
     * @param key
     */
    private void setRedisMonth(Integer count, String key) {
        //失效时间
        LocalDate now = LocalDate.now();
        LocalDate endTime = LocalDate.of(now.getYear(), now.getMonthValue(), 25);
        if (now.getDayOfMonth() > 25) {
            endTime = endTime.plusMonths(1);
        }
        long timeout = Duration.between(LocalDateTime.now(), LocalDateTime.of(endTime, LocalTime.of(23, 59, 59))).toSeconds();
        //缓存新的key-value值
        redisService.setex(key, count, timeout);
    }

    /**
     * 设置redis缓存与失效时间
     *
     * @param count
     * @param key
     */
    private void setRedisDay(Integer count, String key) {
        //失效时间
        long timeout = Duration.between(LocalDateTime.now(), LocalDateTime.of(LocalDate.now(), LocalTime.of(23, 59, 59))).toSeconds();
        //缓存新的key-value值
        redisService.setex(key, count, timeout);
    }

}
