package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class Pigmentations {
    /**
     * 面积
     */
    private String area;
    /**
     * 面积占比
     */
    private String areaRatio;
    private Integer pigmentationTypeId;
    private Integer level;
    private Integer facePart;

    /**
     * 获取有问题的色素数据
     *
     * @param pigmentations pigmentations
     * @return 是否有问题
     */
    public static boolean getProblemData(Pigmentations pigmentations) {
        return pigmentations.getLevel() > 1;
    }
}
