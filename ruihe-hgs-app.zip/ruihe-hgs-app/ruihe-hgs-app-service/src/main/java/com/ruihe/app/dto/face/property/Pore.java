package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class Pore {
    /**
     * 严重等级
     */
    private Integer level;
    /**
     * 毛孔数量
     */
    private Integer number;
    /**
     * 毛孔图层图片
     */
    private String maskPath;
}
