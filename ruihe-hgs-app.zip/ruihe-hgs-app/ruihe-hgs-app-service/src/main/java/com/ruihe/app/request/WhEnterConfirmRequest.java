package com.ruihe.app.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 门店确认入库实体类
 *
 * @author Fangtao
 */
@ApiModel(value = "WhEnterConfirmRequest", description = "门店确认入库实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhEnterConfirmRequest implements Serializable {
    @ApiModelProperty(value = "入库申请单号")
    private String enterNo;
    @ApiModelProperty(value = "柜台id")
    private String counterId;
    @ApiModelProperty(value = "柜台名称")
    private String counterName;
    @ApiModelProperty(value = "柜员id")
    private String baCode;
    @ApiModelProperty(value = "柜员名称")
    private String baName;
    @ApiModelProperty(value = "发货单号")
    private String deliveryNo;
    @ApiModelProperty(value = "实际入库数量")
    private Integer realQty;
    @ApiModelProperty(value = "发货数量")
    private Integer deliveryQty;
    @ApiModelProperty(value = "入库明细")
    private List<WhEnterItem> enterItemList;

}
