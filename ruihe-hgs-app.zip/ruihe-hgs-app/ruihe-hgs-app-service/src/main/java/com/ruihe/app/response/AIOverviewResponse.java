package com.ruihe.app.response;

import lombok.Data;

@Data
public class AIOverviewResponse {
    //id
    private String id;
    //总分
    private String totalScore;
    //检测时间
    private String testTime;
    //肤质
    private String skin;
    //肤色
    private String facecolor;
    //问题
    private String problem;
}
