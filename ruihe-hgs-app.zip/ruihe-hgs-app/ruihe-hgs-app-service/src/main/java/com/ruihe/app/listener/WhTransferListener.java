package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.request.WhU8StockOptItemRequest;
import com.ruihe.app.request.WhU8StockOptRequest;
import com.ruihe.app.service.u8.U8MQProducer;
import com.ruihe.app.service.warehouse.StoreInventoryService;
import com.ruihe.app.vo.u8.U8TransferItemVo;
import com.ruihe.app.vo.u8.U8TransferVo;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.warehouse.WhStockLogPo;
import com.ruihe.common.dao.bean.warehouse.WhTransferItemPo;
import com.ruihe.common.dao.bean.warehouse.WhTransferPo;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.stock.WhStockBizTypeEnum;
import com.ruihe.app.constant.U8DocumentTypeConfig;
import com.ruihe.app.constant.U8ReceivedConfig;
import com.ruihe.app.constant.U8WareHouseConfig;
import com.ruihe.app.event.WhTransferEvent;
import com.ruihe.app.mapper.basic.CounterMapper;
import com.ruihe.app.mapper.warehouse.WhTransferItemMapper;
import com.ruihe.app.mapper.warehouse.WhTransferMapper;
import com.ruihe.common.constant.CommonConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 调拨确认事件处理
 *
 * @author William
 */
@Slf4j
@Component
public class WhTransferListener {
    @Autowired
    private WhTransferMapper whTransferMapper;

    @Autowired
    private WhTransferItemMapper whTransferItemMapper;

    @Autowired
    private StoreInventoryService storeInventoryService;

    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private U8MQProducer u8MQProducer;

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(WhTransferEvent event) {
        try {
            //查询调拨单主表
            WhTransferPo orderPo = whTransferMapper.selectById(event.getOrderNo());
            //查询调拨单明细
            List<WhTransferItemPo> itemList = whTransferItemMapper.selectList(Wrappers.<WhTransferItemPo>lambdaQuery()
                    .eq(WhTransferItemPo::getTransferOrderNo, event.getOrderNo()));
            Pair<List<WhStockLogPo>, List<WhStockLogPo>> stockLogPair = this.extractStockLogList(orderPo, itemList);
            List<Pair<String, List<WhStockLogPo>>> stockChangeList = List.of(Pair.of(orderPo.getInCounterId(), stockLogPair.getLeft()), Pair.of(orderPo.getInCounterId(), stockLogPair.getRight()));
            //事务处理
            storeInventoryService.changeStock(stockChangeList);
            //通知U8
            List<WhU8StockOptRequest> u8StockOptRequestList = this.extractWhU8StockRequest(orderPo, itemList);
            storeInventoryService.syncStockWithU8(u8StockOptRequestList);
            //将数据传给U8
            CounterInformation counterInformation = counterMapper.selectById(orderPo.getInCounterId());
            String operationalModel = counterInformation.getOperationalModel();
            Integer counterType = counterInformation.getCounterType();
            if (operationalModel.equals(CounterEnum.AGENT_COUNTER.getKey().toString())) {
                //代理商就不同步
                return;
            }
            if (counterType.equals(CounterEnum.TEST_COUNTER.getKey())) {
                //测试柜台不同步
                return;
            }
            this.sendMsgToU8(orderPo, itemList);
        } catch (Exception e) {
            log.error("调拨确认事件处理异常，event{}", JSON.toJSONString(event), e);
        }
    }

    /**
     * 抽取门店扣减库存对象
     *
     * @param orderPo
     * @param itemList
     * @return
     */
    private Pair<List<WhStockLogPo>, List<WhStockLogPo>> extractStockLogList(WhTransferPo orderPo, List<WhTransferItemPo> itemList) {
        List<WhStockLogPo> in = itemList.stream()
                .map(e ->
                        WhStockLogPo.builder()
                                .counterId(orderPo.getInCounterId())
                                .counterName(orderPo.getInCounterName())
                                .baCode(orderPo.getInBaCode())
                                .baName(orderPo.getInBaName())
                                .bizType(WhStockBizTypeEnum.TRANSFER_IN.getCode())
                                .bizNo(orderPo.getTransferOrderNo())
                                .bizTime(orderPo.getCreateTime())
                                .prdBarCode(e.getPrdBarCode())
                                .prdName(e.getPrdName())
                                .goodsBarCode(e.getGoodsBarCode())
                                .qty(Math.abs(e.getAckOutQty()))
                                .prdPrice(e.getPrdPrice())
                                .memberPrice(e.getMemberPrice())
                                .bigCatCode(e.getBigCatCode())
                                .bigCatName(e.getBigCatName())
                                .mediumCatCode(e.getMediumCatCode())
                                .mediumCatName(e.getMediumCatName())
                                .smallCatCode(e.getSmallCatCode())
                                .smallCatName(e.getSmallCatName())
                                .build()
                ).collect(Collectors.toList());
        List<WhStockLogPo> out = itemList.stream()
                .map(e ->
                        WhStockLogPo.builder()
                                .counterId(orderPo.getOutCounterId())
                                .counterName(orderPo.getOutCounterName())
                                .baCode(orderPo.getOutBaCode())
                                .baName(orderPo.getOutBaName())
                                .bizType(WhStockBizTypeEnum.TRANSFER_OUT.getCode())
                                .bizNo(orderPo.getTransferOrderNo())
                                .bizTime(orderPo.getCreateTime())
                                .prdBarCode(e.getPrdBarCode())
                                .prdName(e.getPrdName())
                                .goodsBarCode(e.getGoodsBarCode())
                                .qty(Math.negateExact(Math.abs(e.getInQty())))
                                //.qty(Math.negateExact(Math.abs(e.getAckInQty())))
                                .prdPrice(e.getPrdPrice())
                                .memberPrice(e.getMemberPrice())
                                .bigCatCode(e.getBigCatCode())
                                .bigCatName(e.getBigCatName())
                                .mediumCatCode(e.getMediumCatCode())
                                .mediumCatName(e.getMediumCatName())
                                .smallCatCode(e.getSmallCatCode())
                                .smallCatName(e.getSmallCatName())
                                .build()
                ).collect(Collectors.toList());
        return Pair.of(in, out);
    }

    /**
     * 抽取U8库存接口操作
     *
     * @param orderPo
     * @param itemList
     * @return
     */
    private List<WhU8StockOptRequest> extractWhU8StockRequest(WhTransferPo orderPo, List<WhTransferItemPo> itemList) {
        //调入
        WhU8StockOptRequest inRequest = WhU8StockOptRequest.builder()
                .bizType(WhStockBizTypeEnum.TRANSFER_IN.getCode())
                .bizNo(orderPo.getTransferOrderNo())
                .bizTime(orderPo.getCreateTime())
                .counterId(orderPo.getInCounterId())
                .counterName(orderPo.getInCounterName())
                .build();
        List<WhU8StockOptItemRequest> inItemList = itemList.stream().map(e ->
                WhU8StockOptItemRequest.builder()
                        .bizType(WhStockBizTypeEnum.TRANSFER_IN.getCode())
                        .bizNo(orderPo.getTransferOrderNo())
                        .bizTime(orderPo.getCreateTime())
                        .counterId(orderPo.getInCounterId())
                        .counterName(orderPo.getInCounterName())
                        .prdBarCode(e.getPrdBarCode())
                        .prdName(e.getPrdName())
                        .goodsBarCode(e.getGoodsBarCode())
                        .qty(Math.abs(e.getInQty()))
                        .build()
        ).collect(Collectors.toList());
        inRequest.setItemRequestList(inItemList);
        //调出
        WhU8StockOptRequest outRequest = WhU8StockOptRequest.builder()
                .bizType(WhStockBizTypeEnum.TRANSFER_OUT.getCode())
                .bizNo(orderPo.getTransferOrderNo())
                .bizTime(orderPo.getCreateTime())
                .counterId(orderPo.getInCounterId())
                .counterName(orderPo.getInCounterName())
                .build();
        List<WhU8StockOptItemRequest> outItemList = itemList.stream().map(e ->
                WhU8StockOptItemRequest.builder()
                        .bizType(WhStockBizTypeEnum.TRANSFER_OUT.getCode())
                        .bizNo(orderPo.getTransferOrderNo())
                        .bizTime(orderPo.getCreateTime())
                        .counterId(orderPo.getOutCounterId())
                        .counterName(orderPo.getOutCounterName())
                        .prdBarCode(e.getPrdBarCode())
                        .prdName(e.getPrdName())
                        .goodsBarCode(e.getGoodsBarCode())
                        .qty(Math.negateExact(Math.abs(e.getInQty())))
                        .build()
        ).collect(Collectors.toList());
        outRequest.setItemRequestList(outItemList);
        return List.of(inRequest, outRequest);
    }

    /**
     * 将数据传给U8
     *
     * @param orderPo
     * @param itemList
     */
    private void sendMsgToU8(WhTransferPo orderPo, List<WhTransferItemPo> itemList) {
        Integer i = 0;
        List<U8TransferItemVo> U8TransferItemVoList = new ArrayList<>();
        for (WhTransferItemPo e : itemList) {
            i++;
            U8TransferItemVo test = U8TransferItemVo
                    .builder()
                    .inventory_code(e.getPrdBarCode())
                    .quantity(e.getInQty())
                    .poslineid(i)
                    .memo("")
                    .build();
            U8TransferItemVoList.add(test);
        }
        //U8那边要的发货单数据类型和字段（表头）
        U8TransferVo build = U8TransferVo.builder()
                .poscode(orderPo.getTransferOrderNo())
                .cowhcode(orderPo.getOutCounterId())
                .ciwhcode(orderPo.getInCounterId())
                .cirdcode(U8ReceivedConfig.TransfersIn)//店间调拨入库
                .cordcode(U8ReceivedConfig.TransfersOut)//店间调拨出库
                .codepcode(U8WareHouseConfig.DirectManagementDepartment)//转出部门 全部固定为直营管理部门
                .cidepcode(U8WareHouseConfig.DirectManagementDepartment)//转入部门
                .cpersoncode(U8WareHouseConfig.HandledBy)//经手人
                .memo("店间调拨")
                .Body(U8TransferItemVoList).build();
        //把对象推送到MQ
        u8MQProducer.saveLog(build.getPoscode());
        u8MQProducer.sendMessageToU8(build, U8DocumentTypeConfig.TV_ADD);
    }

}
