package com.ruihe.app.request.plan;

import com.alibaba.fastjson.JSONArray;
import com.ruihe.common.annotation.EnumValidation;
import com.ruihe.common.enums.plan.PlanMemberTypeEnum;
import com.ruihe.common.enums.plan.PlanObjectTypeEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;

/**
 * 新增销售规划请求
 * @author qubin
 * @date 2021/4/2 13:16
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SalesPlanOperateRequest {

    @ApiModelProperty("会员id")
    private String memberId;

    @ApiModelProperty("会员名称")
    private String memberName;

    @ApiModelProperty("会员手机号")
    @NotBlank(message = "手机号不能为空")
    private String memberPhone;

    @ApiModelProperty("规划会员类型")
    @EnumValidation(clazz = PlanMemberTypeEnum.class, method = "getCode", message = "类型错误")
    private String planMemberType;

    @ApiModelProperty("规划金额")
    private BigDecimal planAmt;

    @ApiModelProperty("护理项id")
    private JSONArray planNursingId;

    @ApiModelProperty("护理项名称")
    private JSONArray planNursingItem;

    @ApiModelProperty("美导编号")
    private String baCode;

    @ApiModelProperty("美导名称")
    private String baName;

    @NotBlank(message = "柜台id不能为空")
    @ApiModelProperty("柜台id")
    private String counterId;

    @ApiModelProperty("规划对象类型")
    @EnumValidation(clazz = PlanObjectTypeEnum.class, method = "getCode", message = "类型错误")
    private String planObjectType;

    @ApiModelProperty("对象规划id")
    @NotBlank(message = "规划对象id不能为空")
    private String planObjectId;

}
