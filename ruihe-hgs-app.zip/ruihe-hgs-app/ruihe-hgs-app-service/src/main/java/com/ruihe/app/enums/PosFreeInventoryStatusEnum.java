package com.ruihe.app.enums;

/**
 * @author 梁远
 * @Description 盘点申请状态
 * @create 2019-10-17 15:14
 */
public enum PosFreeInventoryStatusEnum {

    //审核状态：0编辑中()，1待审核，4审核通过，5审核拒绝
    //编辑中
    EDIT(0, "编辑中"),
    //未审核
    UNREVIEWED(1, "待审核"),
    //一审通过
    //FIRSTPASSED(2, "一审通过"),
    //一审拒绝
    // FIRSTREJECTED(3, "一审拒绝"),
    //审核通过
    PASSED(4, "审核通过"),
    //审核拒绝
    REJECTED(5, "审核拒绝");
    private Integer code;
    private String msg;


    PosFreeInventoryStatusEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
