package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

import java.time.LocalDateTime;
import java.util.List;


/**
 * @author 梁远
 * @Description 调用接口，触发优惠券变化操作
 * @create 2020-05-29 10:41
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class CancelAndAddCouponEvent extends ApplicationEvent {

    private String memberId;

    public CancelAndAddCouponEvent(Object source, String memberId) {
        super(source);
        this.memberId = memberId;
    }
}
