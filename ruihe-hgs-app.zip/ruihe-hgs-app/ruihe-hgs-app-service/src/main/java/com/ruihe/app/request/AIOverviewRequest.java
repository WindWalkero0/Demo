package com.ruihe.app.request;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ruihe.app.dto.face.AiFaceDTO;
import com.ruihe.app.po.face.AiFacePO;
import com.ruihe.common.utils.IdGenerator;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;


@Data
public class AIOverviewRequest {

    @NotBlank(message = "unionId不能为空")
    private String unionId;

    @Valid
    @NotNull(message = "肤质检测数据不能为空")
    private AiFaceDTO aiFaceDTO;

    /**
     * 将原始检测对象转化为数据库对应的字段及格式
     *
     * @return 转化后的PO
     */
    public AiFacePO convert2PO() {

        final AiFaceDTO aiFaceResult = this.getAiFaceDTO();

        var aiFacePO = new AiFacePO();
        BeanUtils.copyProperties(this.aiFaceDTO, aiFacePO);
        aiFacePO.setId(IdGenerator.getSerialNo());
        //array
        aiFacePO.setAcnes(JSONArray.toJSONString(aiFaceResult.getAcnes()));
        aiFacePO.setDarkCircle(JSONArray.toJSONString(aiFaceResult.getDarkCircle()));
        aiFacePO.setFatGranule(JSONArray.toJSONString(aiFaceResult.getFatGranule()));
        aiFacePO.setMoisture(JSONArray.toJSONString(aiFaceResult.getMoisture()));
        aiFacePO.setOil(JSONArray.toJSONString(aiFaceResult.getOil()));
        aiFacePO.setPigmentations(JSONArray.toJSONString(aiFaceResult.getPigmentations()));
        aiFacePO.setWrinkles(JSONArray.toJSONString(aiFaceResult.getWrinkles()));
        aiFacePO.setOrgimageFaceLocation(JSONArray.toJSONString(aiFaceResult.getOrgimageFaceLocation()));
        //object
        aiFacePO.setBlackHead(JSONObject.toJSONString(aiFaceResult.getBlackHead()));
        aiFacePO.setImageQuality(JSONObject.toJSONString(aiFaceResult.getImageQuality()));
        aiFacePO.setMoistureOverall(JSONObject.toJSONString(aiFaceResult.getMoistureOverall()));
        aiFacePO.setOilOverall(JSONObject.toJSONString(aiFaceResult.getOilOverall()));
        aiFacePO.setPore(JSONObject.toJSONString(aiFaceResult.getPore()));
        aiFacePO.setPouch(JSONObject.toJSONString(aiFaceResult.getPouch()));
        aiFacePO.setSensitivity(JSONObject.toJSONString(aiFaceResult.getSensitivity()));
        aiFacePO.setStarResult(JSONObject.toJSONString(aiFaceResult.getStarResult()));
        aiFacePO.setBasemapPaths(JSONObject.toJSONString(aiFaceResult.getBasemapPaths()));
        aiFacePO.setEyebrow(JSONObject.toJSONString(aiFaceResult.getEyebrow()));
        aiFacePO.setEyeshape(JSONObject.toJSONString(aiFaceResult.getEyeshape()));
        aiFacePO.setFacePose(JSONObject.toJSONString(aiFaceResult.getFacePose()));
        aiFacePO.setFaceShelter(JSONObject.toJSONString(aiFaceResult.getFaceShelter()));
        return aiFacePO;
    }
}
