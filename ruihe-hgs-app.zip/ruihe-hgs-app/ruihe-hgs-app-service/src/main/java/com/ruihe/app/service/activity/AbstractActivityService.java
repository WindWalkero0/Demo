package com.ruihe.app.service.activity;


import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.bean.member.MemberExcel;
import com.ruihe.common.dao.bean.member.MemberSelect;
import com.ruihe.common.pojo.dto.MemberDTO;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.dao.mapper.MemberExcelMapper;
import com.ruihe.common.dao.mapper.MemberSelectMapper;
import com.ruihe.common.pojo.request.member.MemberInfoRequest;
import com.ruihe.common.service.CommonService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

import static java.util.stream.Collectors.*;

@Service
public class AbstractActivityService {

    private final MemberSelectMapper memberSelectMapper;
    private final MemberExcelMapper memberExcelMapper;
    private final CommonService commonService;
    //private final ThreadPoolTaskExecutor taskExecutor;

    public AbstractActivityService(MemberSelectMapper memberSelectMapper,
                                   MemberExcelMapper memberExcelMapper,
                                   CommonService commonService) {
        this.memberSelectMapper = memberSelectMapper;
        this.memberExcelMapper = memberExcelMapper;
        this.commonService = commonService;
    }

    /**
     * 获取活动搜索会员结果
     *
     * @param activityIds 活动Ids
     * @return Map<activityId, List < MemberDTO>> 每个活动能匹配到的会员
     */
    public Map<String, List<MemberDTO>> getSearchMemberRes(List<String> activityIds) {
        //查询活动配置的会员选择信息
        var whereCondition = Wrappers.<MemberSelect>lambdaQuery()
                .eq(MemberSelect::getIsDel, CommonStatusEnum.EFFECTIVE.getCode())
                .in(MemberSelect::getActivityId, activityIds);

        var memberSelects = memberSelectMapper.selectList(whereCondition);
        var memberDTOList = memberSelects.stream()
                .map(e -> CompletableFuture.supplyAsync(() ->
                        commonService.selectMemberByQuery(e)
                                .stream()//查询单个活动设置的会员
                                .filter(Objects::nonNull)//查询结果为空(匹配不到对应会员的活动)过滤掉
                                .map(MemberInfoRequest::convertToMemberDTO)//将查询出来的会员转为会员DTO
                                .peek(it -> it.currentActivityId = e.getActivityId())
                                .collect(toList())//设置当前会员DTO参与活动的主键
                ))
                .collect(toList());
        //最终查询出来的会员结果
        var memberResult = memberDTOList.stream().map(CompletableFuture::join).collect(toList());
        //以活动Id为key,满足活动的会员们为value,返回查询结果
        return memberResult.stream().collect(toMap(e -> e.get(0).currentActivityId, Function.identity()));
    }

    /**
     * 获取活动Excel导入会员结果
     *
     * @param activityIds 活动Ids
     * @return Map<activityId, List < MemberDTO>> 每个活动能匹配到的会员
     */
    public Map<String, List<MemberDTO>> getExcelImportMemberRes(List<String> activityIds) {
        var whereCondition = Wrappers.<MemberExcel>lambdaQuery().in(MemberExcel::getActivityId, activityIds);
        List<MemberExcel> memberExcels = memberExcelMapper.selectList(whereCondition);
        return memberExcels.stream().collect(groupingBy(MemberExcel::getActivityId, mapping(MemberExcel::convert2MemberDTO, toList())));
    }

}
