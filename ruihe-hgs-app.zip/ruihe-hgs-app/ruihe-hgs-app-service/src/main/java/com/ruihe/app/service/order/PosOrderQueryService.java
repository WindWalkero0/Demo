package com.ruihe.app.service.order;

import com.ruihe.app.request.PosOrderPageQueryRequest;
import com.ruihe.common.response.Response;

/**
 * 订单查询服务
 *
 * @author William
 */
public interface PosOrderQueryService {

    /**
     * 查单退货-订单分页查询
     *
     * @param request
     * @return
     */
    Response pageOrderList4Return(PosOrderPageQueryRequest request);

    /***
     * 查单退货-订单明细
     * @param orderNo 订单号
     * @return
     */
    Response orderItem4Return(final String orderNo);

    /***
     * 查单退货-支付明细
     * @param orderNo 订单号
     * @return
     */
    Response paymentList4Return(final String orderNo);

    /**
     * 会话接口-》根据订单号查询订单详情
     *
     * @param orderNo
     * @return
     */
    Response item(String orderNo);
}
