package com.ruihe.app.enums;

/**
 * @author LiangYuan
 * @description
 * @date 2020-10-13 17:38
 */
public enum WxRestoreEnum {
    /**
     * 用户删除会员卡后可重新找回，当用户本次操作为找回时，该值为1，否则为0
     */
    NEW(0, "新增"),
    RESTORE(1, "找回");

    private Integer code;
    private String msg;


    WxRestoreEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
