package com.ruihe.app.event;

/**
 * 销售订单事件-库存处理
 *
 * @author William
 */
public class Order4StockEvent extends OrderEvent {
    public Order4StockEvent(Object source, String orderNo) {
        super(source, orderNo);
    }
}
