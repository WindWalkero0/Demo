package com.ruihe.app.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.enums.OrderTypeEnum;
import com.ruihe.common.annotation.EnumValidation;
import com.ruihe.common.pojo.request.promotion.SalesProductRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 正常下单操作
 */
@ApiModel(value = "PosSaleOrderRequest", description = "销售-下单实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosSaleOrderRequest implements Serializable {


    @ApiModelProperty("参数版本号")
    private String versionNumber;

    @ApiModelProperty("订单应付金额")
    private String actualMoney;

    @ApiModelProperty("【整单退货必填】原始订单号")
    private String originalOrderNo;

    @NotBlank(message = "柜台id不能为空")
    @ApiModelProperty("【必填】柜台id")
    private String counterId;

    @NotBlank(message = "销售员代码不能为空")
    @ApiModelProperty("【必填】销售员代码")
    private String baCode;

    @NotBlank(message = "销售员姓名不能为空")
    @ApiModelProperty("【必填】销售员姓名")
    private String baName;

    @ApiModelProperty("【非必填】会员id，会员销售/退货/空退/补录必填，预订单非必填")
    private String memberId;

    @ApiModelProperty("【预订单必填写】手机号码")
    private String memberPhone;

    @NotNull(message = "交易类型不能为空")
    @EnumValidation(clazz = OrderTransTypeEnum.class, method = "getCode", message = "交易类型错误")
    @ApiModelProperty("【必填】交易类型，1销售,-1退货")
    private Integer transType;

    @NotNull(message = "订单类型不能为空")
    @EnumValidation(clazz = OrderTypeEnum.class, method = "getCode", message = "订单类型错误")
    @ApiModelProperty("【必填】订单类型：1销售,2预定单")
    private Integer orderType;

    @ApiModelProperty("【订单类型是预订单必填】预定单-预约提货时间")
    private LocalDate rsvPickUpTime;

    @ApiModelProperty("【补录业务必填】业务发生时间，yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime bizTime;

    @ApiModelProperty("【暂时无用】寄存箱ID列表")
    private List<Integer> boxes;

    @ApiModelProperty("【交易类型是销售、空退业务必填】所购商品列表")
    private List<OrderItemRequest> orderItemList;

    @ApiModelProperty("【交易类型是销售、空退业务必填】组合支付列表")
    private List<PaymentOrderRequest> paymentOrderList;

    /**
     * 是否是空退业务
     *
     * @return
     */
    public Boolean isKt() {
        return OrderTransTypeEnum.GOODS_RETURN.getCode().equals(this.transType) && StringUtils.isBlank(this.originalOrderNo);
    }

    /**
     * 购买商品信息
     */
    @ApiModel(value = "OrderItemRequest", description = "销售-商品信息实体")
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OrderItemRequest implements Serializable {
        @ApiModelProperty(value = "【必填】产品条码-对外标准", required = true)
        private String prdBarCode;

        @ApiModelProperty(value = "【必填】商品条码-私有编码", required = true)
        private String goodsBarCode;

        @ApiModelProperty(value = "【必填】购买数量", required = true)
        private Integer purQty;

        @ApiModelProperty(value = "【必填】商品类型  0 兑换活动商品 1 优惠券活动商品 2促销奖励商品 3 正常商品,  4发券活动商品", required = true)
        private Integer proType;

        @ApiModelProperty("商品最终销售价格")
        private BigDecimal resultPrice;

        @ApiModelProperty("商品名称")
        private String prdName;

        @ApiModelProperty("虚拟商品针对优惠券:优惠券id")
        private String couponId;

        @ApiModelProperty("虚拟商品针对优惠券:验证码")
        private String coupon;

        @ApiModelProperty(value = "是否虚拟商品,1虚拟商品，0实物商品--前端不传 java用来自己判断的", hidden = true)
        private Integer isVirtual;

        @ApiModelProperty("关联的活动id-包括促销(真实的活动商品才会用到)")
        private String activityId;

        @ApiModelProperty("关联的活动名称(真实的活动商品才会用到)")
        private String activityName;

        @ApiModelProperty("虚拟商品总价(只有虚拟商品才有)")
        private BigDecimal totalMoney;

        @ApiModelProperty("是否是购物车商品:0购物车(条件商品);1奖励商品;2兼容之前的值")
        private Integer discernType;
    }

    /**
     * 支付信息
     */
    @ApiModel(value = "PaymentOrderRequest", description = "销售-支付信息实体")
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PaymentOrderRequest implements Serializable {

        @ApiModelProperty(value = "【必填】支付渠道:10现金,20银行卡,30微信,40支付宝,50银联二维码,60其他", required = true)
        private String payChannel;

        @ApiModelProperty(value = "【必填】支付金额", required = true)
        private BigDecimal payAmt;
    }


    /**
     * 初始购买商品集合
     */
    @ApiModelProperty("商品集合")
    private List<SalesProductRequest> products;

}
