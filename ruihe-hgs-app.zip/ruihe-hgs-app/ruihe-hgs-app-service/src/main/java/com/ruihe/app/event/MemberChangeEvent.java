package com.ruihe.app.event;

import lombok.Data;


@Data
public class MemberChangeEvent {

    private String memberId;


    public MemberChangeEvent(String memberId) {
        this.memberId = memberId;
    }

}
