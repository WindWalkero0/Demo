package com.ruihe.app.service.gd;

import com.alibaba.fastjson.JSON;
import com.ruihe.app.vo.gd.DistanceDetailVo;
import com.ruihe.app.vo.gd.PositionVo;
import com.ruihe.app.vo.gd.RegeoCodeDetailVo;
import com.ruihe.common.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

/**
 * 高德服务
 * @author qubin
 * @date 2021/4/22 8:57
 */
@Slf4j
@Service
public class GdService {

    @Value("${gaode.key}")
    private String key;

    @Value("${gaode.geocde-url}")
    private String geocodeUrl;

    @Value("${gaode.distance-url}")
    private String distanceUrl;

    @Value("${gaode.regeocode-url}")
    private String regeocodeUrl;

    /**
     * 根据地理位置获取经纬度,
     * @param address
     */
    public Response getLocation(String address){

        if(StringUtils.isBlank(address)){
            return Response.errorMsg("地址不能为空");
        }
        //请求高德
        String locationResponse = WebClient.builder()
                .baseUrl(geocodeUrl+ "?key="+key+"&output=JSON&address="+address)
                .build()
                .get()
                .accept()
                .exchange()
                .block()
                .bodyToMono(String.class)
                .block();
        PositionVo positionVo = JSON.parseObject(locationResponse, PositionVo.class);
        //状态不成功则报错
        if(positionVo == null){
            return Response.errorMsg("获取经纬度转换异常");
        }
        if(!positionVo.getStatus().equals("1")){
            return Response.errorMsg(positionVo.getInfo());
        }
        return Response.success(positionVo);
    }

    /**
     * 获取起始地点和目标地点的距离
     * @param origins  起始坐标，即经纬度，支持100对
     * @param destination  目的坐标， 即经纬度
     */
    public Response getDistance(List<String> origins, String destination){

        if(origins == null || origins.isEmpty()){
            return  Response.errorMsg("起始坐标不能为空");
        }

        if(origins.size() > 100){
            return  Response.errorMsg("起始坐标数量大于100");
        }

        StringBuilder originsStringBuilder = new StringBuilder();
        for(int i = 0; i < origins.size(); i++){
            if(i == origins.size() -1 ){
                originsStringBuilder.append(origins.get(i));
                continue;
            }
            originsStringBuilder.append(origins.get(i)).append("|");

        }

        if(StringUtils.isBlank(destination)){
            return  Response.errorMsg("目的坐标不能为空");
        }
        //请求高德
        String distanceResponse = WebClient.builder()
                .baseUrl(distanceUrl+ "?key="+key+"&output=JSON&origins="+originsStringBuilder+"&destination="+destination)
                .build()
                .get()
                .accept()
                .exchange()
                .block()
                .bodyToMono(String.class)
                .block();
        DistanceDetailVo distanceDetailVo = JSON.parseObject(distanceResponse, DistanceDetailVo.class);
        if(distanceDetailVo == null){
            return Response.errorMsg("获取距离转换异常");
        }
        //状态不成功则报错
        if(!distanceDetailVo.getStatus().equals("1")){
            return Response.errorMsg(distanceDetailVo.getInfo());
        }
        return Response.success(distanceDetailVo);
    }


    /**
     * 根据经纬度获取adcode
     * @param location
     * @return
     */
    public Response getAdcode(String location){

        if(StringUtils.isBlank(location)){
            return Response.errorMsg("经纬度不能为空");
        }
        //请求高德
        String adcodeResponse = WebClient.builder()
                .baseUrl(regeocodeUrl+ "?key="+key+"&output=JSON&location="+location)
                .build()
                .get()
                .accept()
                .exchange()
                .block()
                .bodyToMono(String.class)
                .block();
        RegeoCodeDetailVo regeoCodeDetailVo = JSON.parseObject(adcodeResponse, RegeoCodeDetailVo.class);
        if(regeoCodeDetailVo == null){
            return Response.errorMsg("获取adcode转换异常");
        }

        //状态不成功则报错
        if(!regeoCodeDetailVo.getStatus().equals("1")){
            return Response.errorMsg(regeoCodeDetailVo.getInfo());
        }
        return Response.success(regeoCodeDetailVo);
    }
}
