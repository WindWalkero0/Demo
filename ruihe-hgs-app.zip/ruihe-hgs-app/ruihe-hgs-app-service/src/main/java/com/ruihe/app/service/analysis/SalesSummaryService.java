package com.ruihe.app.service.analysis;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Maps;
import com.ruihe.app.request.SalesSummaryRequest;
import com.ruihe.app.vo.PosSalesSummaryVo;
import com.ruihe.common.dao.bean.base.UserCounter;
import com.ruihe.common.util.LambdaUtil;
import com.ruihe.common.pojo.request.analysis.SaleDetailRequest;
import com.ruihe.app.mapper.analysis.SalesSummaryMapper;
import com.ruihe.app.mapper.basic.UserCounterMapper;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.app.po.analysis.PosPayMentAmtAndQtyPo;
import com.ruihe.app.po.analysis.PosSaleDetailReportPo;
import com.ruihe.app.po.analysis.PosSalesSummaryPo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 分析模块,销售小结统计页面
 *
 * @author:Fangtao
 * @Date:2019/10/30 10:20
 */
@Slf4j
@DS(DBConst.SLAVE)
@Service
public class SalesSummaryService {

    @Autowired
    private SalesSummaryMapper salesSummaryMapper;

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private UserCounterMapper UserCounterMapper;


    /**
     * 销售小结查询页面
     * 柜台下的所有柜员/销售单数或者是退货单数/总销售额
     */
    public Response saleSummary(SalesSummaryRequest request) {
        //定义一个全局的Integer类型的0
        Integer zero = BigInteger.ZERO.intValue();
        //柜台编码必传
        if (StringUtils.isBlank(request.getCounterId())) {
            return Response.errorMsg("柜台编码不能为空");
        }
        //2020年4月8日14:38:11  应该是先找到所有的ba 没有的参数先放置0
        LambdaQueryWrapper<UserCounter> queryWrapper = Wrappers.<UserCounter>lambdaQuery()
                .eq(UserCounter::getCounterCode, request.getCounterId());
        if (StringUtils.isNotBlank(request.getBaCode())) {
            queryWrapper.eq(UserCounter::getEmpId, request.getBaCode());
        }
        List<UserCounter> userCounters = UserCounterMapper.selectList(queryWrapper);
        Map<String, UserCounter> userCountersCollect = userCounters.stream().collect(Collectors.toMap(UserCounter::getEmpId, Function.identity()));
        //将结束时间加一天
        LocalDate endTime = request.getEndTime() == null ? null : request.getEndTime().plusDays(1);
        //根据条件查询销售数据
        List<PosSalesSummaryPo> salesSummaryList = salesSummaryMapper.querySaleSummary(request.getCounterId(), request.getStartTime(), endTime, request.getBaCode());
        //预订单数量的查询
        List<PosSalesSummaryPo> posSalesSummaryPo1 = salesSummaryMapper.queryTakeReturnGoodsQtyByFly(request.getCounterId(), request.getStartTime(), endTime, request.getBaCode());
        Map<String, PosSalesSummaryPo> collect1 = new HashMap<>();
        if (posSalesSummaryPo1 != null && !posSalesSummaryPo1.isEmpty()) {
            collect1 = posSalesSummaryPo1.stream().collect(Collectors.toMap(PosSalesSummaryPo::getBaCode, Function.identity()));
        }
        List<PosSalesSummaryVo.BaSalesSummaryVo> baSalesSummaryList = new ArrayList<>();
        Map<String, PosSalesSummaryPo> collect = salesSummaryList.stream().collect(Collectors.toMap(PosSalesSummaryPo::getBaCode, Function.identity()));
        for (UserCounter userCounter : userCounters) {
            if (!collect.containsKey(userCounter.getEmpId())) {
                PosSalesSummaryPo posSalesSummaryPo = PosSalesSummaryPo.builder()
                        .salesAmt(BigDecimal.ZERO)
                        .salesQty(0)
                        .baCode(userCounter.getEmpId())
                        .baName(userCounter.getName())
                        .bookAmt(BigDecimal.ZERO)
                        .bookQty(0)
                        .orderFormReturnAmt(BigDecimal.ZERO)
                        .orderQty(0)
                        .orderFormReturnQty(0)
                        .returnAmt(BigDecimal.ZERO)
                        .returnOrderQty(0)
                        .skReturnQty(0)
                        .skSalesQty(0)
                        .takeGoodsQty(collect1.containsKey(userCounter.getEmpId()) ? collect1.get(userCounter.getEmpId()).getTakeGoodsQty() : 0)
                        .returnQty(0)
                        .takeReturnQty(collect1.containsKey(userCounter.getEmpId()) ? collect1.get(userCounter.getEmpId()).getTakeReturnQty() : 0)
                        .build();
                salesSummaryList.add(posSalesSummaryPo);
            }
        }
        Map<String, PosSalesSummaryPo> salesSummaryCollect = salesSummaryList.stream().collect(Collectors.toMap(PosSalesSummaryPo::getBaCode, Function.identity()));
        //统计ba新会员数,按照员工进行分组
        List<Map<String, Object>> baNewMemberQtyList = memberMapper.baNewMemberQty(request.getCounterId(), request.getStartTime(), endTime);
        LambdaUtil lambdaUtil = LambdaUtil.builder().sum(0).build();
        Map<String, Integer> baNewMemberQtyMap = baNewMemberQtyList.stream()
                .map(e -> {
                    //lambdaUtil.setSum(lambdaUtil.getSum()+ ((Long) e.get("newMemeberQty")).intValue());
                    HashMap<String, Integer> hashMap = Maps.newHashMap();
                    hashMap.put(e.get("baCode").toString(), ((Long) e.get("newMemeberQty")).intValue());
                    return hashMap;
                })
                .flatMap(e -> e.entrySet().stream())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        for (Map.Entry<String, Integer> entry : baNewMemberQtyMap.entrySet()) {
            if (StringUtils.isNotBlank(request.getBaCode())) {
                if (entry.getKey().equals(request.getBaCode())) {
                    lambdaUtil.setSum(entry.getValue());
                }
            } else {
                lambdaUtil.setSum(lambdaUtil.getSum() + entry.getValue());
            }
        }

        int saleCount = 0;
        int returnCount = 0;
        int saleSkinQty = 0;
        int saleQty = 0;
        int returnSkinQty = 0;
        int returnQty = 0;
        BigDecimal totalSaleAmt = BigDecimal.ZERO;
        BigDecimal salesAmt = BigDecimal.ZERO;
        BigDecimal totalReturnAmt = BigDecimal.ZERO;
        for (PosSalesSummaryPo salesSummary : salesSummaryList) {
            BigDecimal relatedRate = BigDecimal.ZERO;
            if (salesSummary.getOrderQty() != 0) {
                relatedRate = BigDecimal.valueOf(salesSummary.getSkSalesQty() - salesSummary.getSkReturnQty()).divide(BigDecimal.valueOf(salesSummary.getOrderQty() + salesSummary.getReturnOrderQty()), 2, RoundingMode.HALF_UP);
            }
            PosSalesSummaryVo.BaSalesSummaryVo build = PosSalesSummaryVo.BaSalesSummaryVo.builder()
                    .baCode(salesSummary.getBaCode())
                    .baName(salesSummaryCollect.get(salesSummary.getBaCode()) == null ? salesSummary.getBaCode() : salesSummaryCollect.get(salesSummary.getBaCode()).getBaName())
                    .newMemberQty(baNewMemberQtyMap.get(salesSummary.getBaCode()) == null ? zero : baNewMemberQtyMap.get(salesSummary.getBaCode()))
                    // 净销售数量=正常销售数+预定数-退货数-提货退货数(未减提货退货数^)
                    .salesQty(salesSummary.getSalesQty() - salesSummary.getReturnQty())
                    // 净销售额=正常销售额+预定销售额-退货金额-提货退货金额（未减预订单退货数）
                    .salesAmt(salesSummary.getSalesAmt().subtract(salesSummary.getReturnAmt()))
                    .relatedRate(relatedRate)
                    .build();
            baSalesSummaryList.add(build);
            saleQty = saleQty + salesSummary.getSalesQty();
            returnQty = returnQty + salesSummary.getReturnQty();
            saleCount = saleCount + salesSummary.getOrderQty();
            returnCount = returnCount + salesSummary.getReturnOrderQty();
            saleSkinQty = saleSkinQty + salesSummary.getSkSalesQty();
            returnSkinQty = returnSkinQty + salesSummary.getSkReturnQty();
            totalSaleAmt = totalSaleAmt.add(salesSummary.getSalesAmt());
            totalReturnAmt = totalReturnAmt.add(salesSummary.getReturnAmt());
        }
        salesAmt = totalSaleAmt.subtract(totalReturnAmt);
        //头部小计
        if (salesSummaryList.isEmpty()) {
            return Response.errorMsg("暂无数据");
        }
        //2020年4月23日17:43:19  跟销售明细报表用同一个
        PosPayMentAmtAndQtyPo posPayMentAmtAndQtyPo = new PosPayMentAmtAndQtyPo();
        SaleDetailRequest saleDetailRequest = new SaleDetailRequest();
        saleDetailRequest.setEndTime(request.getEndTime().plusDays(1));
        saleDetailRequest.setStartTime(request.getStartTime());
        saleDetailRequest.setCounterId(request.getCounterId());
        saleDetailRequest.setBaCode(request.getBaCode());
        PosSaleDetailReportPo posSaleDetailReportPo = salesSummaryMapper.sumCounterAllStock(saleDetailRequest);
        if (posSaleDetailReportPo != null) {
            posPayMentAmtAndQtyPo.setQty(posSaleDetailReportPo.getSaleQty());
            posPayMentAmtAndQtyPo.setAmt(posSaleDetailReportPo.getSaleAmt());
        } else {
            posPayMentAmtAndQtyPo.setQty(0);
            posPayMentAmtAndQtyPo.setAmt(BigDecimal.ZERO);
        }
        PosSalesSummaryVo posSalesSummaryVo = PosSalesSummaryVo.builder()
                .totalSaleAmt(totalSaleAmt) //总的销售额
                .totalSaleQty(saleQty) //总的销售数量
                .salesOrderQty(saleCount)//销售单数
                // 还差提货退货数^
                .returnOrderQty(returnCount)//退货单数
                // 净销售额=正常销售额+预定销售额-退货金额-提货退货金额（未减预订单退货数）
                .salesAmt(salesAmt) //净销售额
                //.salesAmt(e.getSalesAmt().add(e.getBookAmt()).add(e.getReturnAmt().negate()).subtract(e.getOrderFormReturnAmt()))
                // （未加提货退货金额）
                .returnAmt(totalReturnAmt) //净退货金额
                .build();

        //求销售订单数
        Integer salesOrder = saleCount;
        //求退货订单数
        Integer returnOrder = returnCount;
        posSalesSummaryVo.setTotalSaleQty(posPayMentAmtAndQtyPo.getQty());
        posSalesSummaryVo.setSalesAmt(salesAmt);
        //求客单价
        if (salesOrder + returnOrder != 0) {
            posSalesSummaryVo.setAvgPrice(posSalesSummaryVo.getSalesAmt()
                    .divide(BigDecimal.valueOf(salesOrder + returnOrder), 2, RoundingMode.HALF_UP));
        } else {
            posSalesSummaryVo.setAvgPrice(BigDecimal.ZERO);
        }
        //累计“护肤品”大类销售产品数量
        Integer salesPrdQty = saleSkinQty;
        //累计“护肤品”大类实物退货产品数量
        Integer returnPrdQty = returnSkinQty;


        //总的连带率
        if (salesOrder + returnOrder == 0) {
            posSalesSummaryVo.setRelatedRate(BigDecimal.ZERO);
        } else {
            posSalesSummaryVo.setRelatedRate(BigDecimal.valueOf(salesPrdQty - returnPrdQty)
                    .divide(BigDecimal.valueOf(salesOrder + returnOrder), 2, RoundingMode.HALF_UP));
        }
        posSalesSummaryVo.setBaSalesSummaryList(baSalesSummaryList);
        //总的新会员数
        posSalesSummaryVo.setAllNewMembers(lambdaUtil.getSum());
        return Response.success(posSalesSummaryVo);
    }
}
