package com.ruihe.app.service.member;

import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.app.vo.member.MemberInfoVo;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.constant.NursingConstant;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.nursing.NursingChildConfigPO;
import com.ruihe.common.dao.bean.nursing.NursingMemberPO;
import com.ruihe.common.dao.mapper.NursingChildConfigMapper;
import com.ruihe.common.dao.mapper.NursingMemberMapper;
import com.ruihe.common.dao.mapper.integral.IntegralAccountMapper;
import com.ruihe.common.enums.nursing.NursingMemberStatusEnum;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.request.member.MemberAddNursingRequest;
import com.ruihe.common.pojo.request.member.MemberEditNursingRequest;
import com.ruihe.common.pojo.request.member.MemberSearchNursingRequest;
import com.ruihe.common.pojo.response.member.MemberNursingBaResponse;
import com.ruihe.common.pojo.response.member.MemberNursingResponse;
import com.ruihe.common.response.Response;
import com.ruihe.common.service.ChangeService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
public class MemberNursingService {

    private final NursingMemberMapper nursingMemberMapper;

    private final NursingChildConfigMapper nursingChildConfigMapper;

    private final MemberMapper memberMapper;

    private final IntegralAccountMapper integralAccountMapper;

    @Autowired
    private ChangeService changeService;

    public MemberNursingService(NursingMemberMapper nursingMemberMapper, NursingChildConfigMapper nursingChildConfigMapper, MemberMapper memberMapper, IntegralAccountMapper integralAccountMapper) {
        this.nursingMemberMapper = nursingMemberMapper;
        this.nursingChildConfigMapper = nursingChildConfigMapper;
        this.memberMapper = memberMapper;
        this.integralAccountMapper = integralAccountMapper;
    }

    /**
     * 新增护理包会员
     */
    @Transactional(rollbackFor = Exception.class)
    public Response addNursing(MemberAddNursingRequest request) {
        //判断是否已经存在
        final NursingMemberPO existMember = nursingMemberMapper.selectOne(Wrappers.lambdaQuery(NursingMemberPO.class)
                .eq(NursingMemberPO::getMemberId, request.getMemberId())
                .eq(NursingMemberPO::getCounterId, request.getCounterId()));
        if (ObjectUtils.isNotEmpty(existMember)) {
            throw new BizException("该用户已经存在，无须新增");
        }
        operationNursing(request);
        return Response.successMsg("操作成功");
    }

    /**
     * 填充数据并添加到数据库
     */
    @Transactional(rollbackFor = Exception.class)
    public void operationNursing(MemberAddNursingRequest request) {
        judge(request.getNursingId());
        //组装数据
        NursingMemberPO build = NursingMemberPO
                .builder()
                .baCode(request.getBaCode())
                .baName(request.getBaName())
                .counterId(request.getCounterId())
                .counterName(request.getCounterName())
                .updateTime(LocalDateTime.now())
                .createTime(LocalDateTime.now())
                .memberId(request.getMemberId())
                .memberName(request.getMemberName())
                .mobile(request.getPhone())
                .nursingId(request.getNursingId())
                .nursingItem(request.getNursingItem())
                .type(NursingConstant.NURSING_MEMBER_TYPE_INSERT)
                .status(NursingConstant.NURSING_MEMBER_STATUS_YES)
                .build();
        Optional.of(nursingMemberMapper.insert(build)).filter(c -> !c.equals(0)).orElseThrow(() -> new BizException("添加失败"));
    }

    /**
     * 编辑护理包信息
     */
    @Transactional(rollbackFor = Exception.class)
    public Response editNursing(MemberEditNursingRequest request) {
        //判断是否已经存在
        NursingMemberPO nursingMemberPO =  Optional.ofNullable(nursingMemberMapper.selectOne(Wrappers.lambdaQuery(NursingMemberPO.class)
                .eq(NursingMemberPO::getCounterId, request.getCounterId())
                .eq(NursingMemberPO::getMemberId, request.getMemberId()))).orElseThrow(()
                -> new BizException("该柜台下没有该护理包会员"));
        judge(request.getNursingId());
        //不是护理会员，清空护理项
        NursingMemberPO build = NursingMemberPO
                .builder()
                .status(request.getStatus())
                .nursingId(NursingMemberStatusEnum.NO.getCode().equals(request.getStatus()) ? JSONArray.parseArray("[]") : request.getNursingId())
                .nursingItem(NursingMemberStatusEnum.NO.getCode().equals(request.getStatus()) ? JSONArray.parseArray("[]") : request.getNursingItem())
                .updateTime(LocalDateTime.now())
                .build();
        if (request.getRedistribution().equals(NursingConstant.STATUS_EFFECTIVE)) {
            build.setBaCode(request.getBaCode());
            build.setBaName(request.getBaName());
        }
        //记录修改日志
        Long changeId = changeService.insert(NursingMemberPO.class, nursingMemberPO.getId().toString(), "编辑护理包信息",
                nursingMemberPO.getBaCode(),nursingMemberPO.getBaName());
        build.setChangeId(changeId);
        Optional.of(nursingMemberMapper.update(build, Wrappers.lambdaQuery(NursingMemberPO.class)
                .eq(NursingMemberPO::getMemberId, request.getMemberId())
                .eq(NursingMemberPO::getCounterId, request.getCounterId()))).
                filter(integer -> !integer.equals(0)).orElseThrow(()
                -> new BizException("编辑失败"));
        return Response.successMsg("操作成功");
    }

    /**
     * 查询护理包会员
     */
    public Response searchNursing(MemberSearchNursingRequest request) {
        Optional.ofNullable(request.getPhone())
                .filter(s -> StringUtils.isEmpty(s) || (!StringUtils.isEmpty(s) && s.length() >= 2))
                .orElseThrow(() -> new BizException("请至少输入卡号中2位数字"));
        PageHelper.startPage(request.getPageNumber(), request.getPageSize());
        List<MemberNursingResponse> collect = nursingMemberMapper.selectNursing(request);
        PageInfo<MemberNursingResponse> pageInfo = new PageInfo<>(collect);
        return Response.success(pageInfo);
    }

    private void judge(JSONArray ids) {
        //查询护理包项目
        List<NursingChildConfigPO> nursingChildConfigPOS = nursingChildConfigMapper.selectList(Wrappers.lambdaQuery(NursingChildConfigPO.class).eq(NursingChildConfigPO::getStatus, 1));
        Map<Integer, NursingChildConfigPO> map = nursingChildConfigPOS.stream().collect(Collectors.toMap(NursingChildConfigPO::getId, Function.identity(), (k1, k2) -> k1));
        ids.forEach(id -> {
            Optional.ofNullable(map.get(id)).orElseThrow(() -> new BizException("存在无效的护理包项目"));
        });
    }


    /**
     * 查询护理会员
     */
    public Response selectNursingMember(String phone, String counterId) {
        MemberInfo memberInfo = Optional.ofNullable(memberMapper.selectOne(Wrappers.lambdaQuery(MemberInfo.class)
                .eq(MemberInfo::getMobilePhone, phone))).orElseThrow(()
                -> new BizException("请输入正确的手机号码"));
        if(memberInfo.getStatus() == NursingConstant.STATUS_INVALID){
            throw new BizException("该会员已停用，请启用后操作");
        }
        String memberId = Optional.ofNullable(memberInfo.getMemberId()).filter(s -> !StringUtils.isEmpty(s)).orElseThrow(()
                -> new BizException("会员id为空"));
        IntegralAccountPo integralAccountPo = integralAccountMapper.selectById(memberId);
        NursingMemberPO nursingMemberPO = nursingMemberMapper.selectOne(Wrappers.lambdaQuery(NursingMemberPO.class)
                .eq(NursingMemberPO::getCounterId, counterId)
                .eq(NursingMemberPO::getMemberId, memberInfo.getMemberId()));
        if (nursingMemberPO == null) {
            return Response.successMsg("该会员" + memberInfo.getMemberName() + "(" + phone + ")还不是本店的护理包会员,新增护理记录后将自动确认为护理会员。");
        }
        MemberInfoVo build = MemberInfoVo
                .builder()
                .memberLevelName(memberInfo.getMemberLevelName())
                .memberId(memberInfo.getMemberId())
                .mobilePhone(memberInfo.getMobilePhone())
                .integral(integralAccountPo != null ? integralAccountPo.getAvlQty() : BigInteger.ZERO.intValue())
                .birthday(memberInfo.getBirthday())
                .memberName(memberInfo.getMemberName())
                .nursingStatus(nursingMemberPO == null ? "3" : nursingMemberPO.getStatus())
                .build();
        return Response.success(build);
    }

    /**
     * 查询去重美导信息
     */
    public Response searchBa(String counterId) {
        List<MemberNursingBaResponse> nursingBaResponses = nursingMemberMapper.searchBa(counterId);
        return Response.success(nursingBaResponses);
    }

    public static void main(String[] args) {
        System.out.println(NursingMemberStatusEnum.NO.getCode().equals("3"));
    }
}
