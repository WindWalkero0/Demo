package com.ruihe.app.service.analysis;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Maps;
import com.ruihe.app.vo.SalesVo;
import com.ruihe.app.vo.WhStocksVo;
import com.ruihe.common.dao.bean.warehouse.WhEnterPo;
import com.ruihe.common.dao.bean.warehouse.WhReturnPo;
import com.ruihe.common.enums.stock.WhEnterStatusEnum;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.common.enums.stock.WhReturnStatusEnum;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.mapper.terminal.PosCounterMessageMapper;
import com.ruihe.app.mapper.terminal.PosMessageMapper;
import com.ruihe.app.mapper.warehouse.WhEnterMapper;
import com.ruihe.app.mapper.warehouse.WhReturnMapper;
import com.ruihe.app.po.fa.PosCounterMessagePo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author 梁远
 * @Description
 * @create 2019-12-09 14:32
 */
@Slf4j
@DS(DBConst.SLAVE)
@Service
public class SalesService {

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private PosMessageMapper posMessageMapper;

    @Autowired
    private PosCounterMessageMapper posCounterMessageMapper;

    @Autowired
    private WhReturnMapper whReturnMapper;

    @Autowired
    private WhEnterMapper whEnterMapper;

    /**
     * POS销售首页的数据查询
     *
     * @param counterId
     * @return
     */
    public Response sales(String counterId) {
        LocalDate startTime = LocalDate.now();
        //1、查询昨日销售数据（实际销售、退货）
        List<Map<Integer, Object>> yesterdaySalesList = posOrderMapper.sales(counterId, startTime.minusDays(1), startTime);
        BigDecimal yesterdaySales = getSalesAmt(yesterdaySalesList);
        //2、查询今日销售数据
        List<Map<Integer, Object>> todaySalesList = posOrderMapper.sales(counterId, startTime, startTime.plusDays(1));
        BigDecimal todaySales = getSalesAmt(todaySalesList);
        //3、查询今日新增会员数（会员状态为有效）;2020-04-21:当天新增会员且单笔消费金额大于等于200元的人数
        Integer memberCount = memberMapper.newMemberQty(counterId, startTime);
                /*.selectCount(Wrappers.<MemberInfo>lambdaQuery()
                .eq(MemberInfo::getCounterId, counterId)
                .ge(MemberInfo::getCreateTime, startTime)
                .lt(MemberInfo::getCreateTime, startTime.plusDays(1))
                .eq(MemberInfo::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));*/
        //2020年9月1日11:06:32  message现在有指定柜台的消息 那么这个未读就得去这里面找了
        List<String> allMessages = posMessageMapper.selectMessageCount(counterId);
        boolean flag = false;
        Integer readMessages = 0;
        if (allMessages != null && allMessages.size() > 0) {
            flag = true;
            LambdaQueryWrapper<PosCounterMessagePo> counterWrapper = Wrappers.<PosCounterMessagePo>lambdaQuery()
                    .eq(PosCounterMessagePo::getCounterId, counterId)
                    .in(PosCounterMessagePo::getPosMsgId, allMessages);
            readMessages = posCounterMessageMapper.selectCount(counterWrapper);
        }
        //获取邀约记录的红点数字
        //4、返回数据
        return Response.success(SalesVo.builder()
                .memberCount(memberCount)
                .todaySales(todaySales)
                .yesterdaySales(yesterdaySales)
                .unReadMessages(flag ? allMessages.size() - readMessages : 0)
                .build());
    }

    /**
     * 获取销售金额
     *
     * @param salesList
     * @return
     */
    private BigDecimal getSalesAmt(List<Map<Integer, Object>> salesList) {
        //如果list为空，则说明没有查询到销售数据
        if (salesList.isEmpty()) {
            return BigDecimal.ZERO;
        }
        //将list转为map
        Map<Integer, BigDecimal> salesMap = salesList.stream().map(e -> {
            HashMap<Integer, BigDecimal> hashMap = Maps.newHashMap();
            hashMap.put((Integer) e.get("transType"), (BigDecimal) e.get("realAmt"));
            return hashMap;
        }).flatMap(e -> e.entrySet().stream()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        //分别获取销售和退货金额
        BigDecimal out = salesMap.get(OrderTransTypeEnum.GOODS_OUT.getCode());
        BigDecimal back = salesMap.get(OrderTransTypeEnum.GOODS_RETURN.getCode());
        //对销售和退货金额进行判断并返回
        if (out != null && back != null) {
            return out.subtract(back);
        } else if (out == null && back != null) {
            return back.negate();
        } else {
            return out == null ? BigDecimal.ZERO : out;
        }
    }

    public Response stocks(String counterId) {
        LambdaQueryWrapper<WhReturnPo> whReturnWrapper = Wrappers.<WhReturnPo>lambdaQuery()
                .eq(WhReturnPo::getCounterId, counterId)
                .eq(WhReturnPo::getStatus, WhReturnStatusEnum.APPLY.getCode())
                .ge(WhReturnPo::getCreateTime, LocalDate.now().plusDays(-30))
                .le(WhReturnPo::getCreateTime, LocalDate.now().plusDays(-5));
        Integer unReturnCount = whReturnMapper.selectCount(whReturnWrapper);

        LambdaQueryWrapper<WhEnterPo> whEnterWrapper = Wrappers.<WhEnterPo>lambdaQuery()
                .eq(WhEnterPo::getCounterId, counterId)
                .eq(WhEnterPo::getStatus, WhEnterStatusEnum.ENTERING.getCode())
                .ge(WhEnterPo::getCreateTime, LocalDate.now().plusDays(-30))
                .le(WhEnterPo::getCreateTime, LocalDate.now().plusDays(-3));
        Integer unEnterCount = whEnterMapper.selectCount(whEnterWrapper);

        return Response.success(WhStocksVo.builder().unEnter(unEnterCount).unReturn(unReturnCount).build());
    }
}
