package com.ruihe.app.response.material;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author qubin
 * @date 2021年07月05日 13:44
 */
@ApiModel(value = "MaterialLevelResponse", description = "导购助手-资料级别响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MaterialLevelResponse implements Serializable {

    @ApiModelProperty("主键")
    private Integer id;

    @ApiModelProperty("项目id")
    private Integer projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("图片描述")
    private String picMemo;

    @ApiModelProperty("图片地址")
    private List<String> picUrls;

    @ApiModelProperty("链接地址")
    private String linkUrl;

}
