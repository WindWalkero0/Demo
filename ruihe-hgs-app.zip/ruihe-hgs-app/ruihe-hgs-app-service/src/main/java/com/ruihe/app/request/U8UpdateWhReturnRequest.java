package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2020-03-10 10:43
 */
@ApiModel(value = "U8UpdateWhReturnRequest", description = "U8审核完成之后更新退库申请单请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class U8UpdateWhReturnRequest implements Serializable {

    @ApiModelProperty(value = "申请编号")
    private String returnNo;

    @ApiModelProperty(value = "u8其他出库单号")
    private String u8OrderNo;

    @ApiModelProperty(value = "审核状态：2已通过，4已废弃")
    private Integer status;

    @ApiModelProperty(value = "审核人id")
    private String auditCode;

    @ApiModelProperty(value = "审核人名称")
    private String auditName;

    @ApiModelProperty(value = "审核人部门id")
    private String deptId;

    @ApiModelProperty(value = "审核人部门名称")
    private String deptName;
}
