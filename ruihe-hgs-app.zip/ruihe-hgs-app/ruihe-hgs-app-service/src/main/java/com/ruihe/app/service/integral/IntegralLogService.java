package com.ruihe.app.service.integral;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.mapper.member.MemberActivityMapper;
import com.ruihe.app.mapper.order.PosOrderItemMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.service.order.ActivityOrderService;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.dao.bean.integral.IntegralLogPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderItemPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderPo;
import com.ruihe.common.dao.bean.order.PosOrderActivity;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.dao.mapper.integral.IntegralLogMapper;
import com.ruihe.common.dao.mapper.integral.IntegralOrderMapper;
import com.ruihe.common.enums.integral.IntegralBizTypeEnum;
import com.ruihe.common.enums.order.PosOrderTypeEnum;
import com.ruihe.common.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.MutableTriple;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 积分扣减记录服务
 *
 * @author fly
 */
@Service
@Slf4j
public class IntegralLogService {
    @Autowired
    private IntegralOrderMapper integralOrderMapper;

    @Autowired
    private IntegralLogMapper integralLogMapper;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private MemberActivityMapper memberActivityMapper;

    private static final LocalDateTime businessTime = LocalDateTime.of(2021, 3, 1, 0, 0, 0);

    /**
     * 其实只是增加一个时间条件方便查询快一点点
     */
    private static final LocalDateTime onlineTime = LocalDateTime.of(2021, 2, 1, 0, 0, 0);

    /**
     * 存入积分扣减记录
     *
     * @param rc
     */
    @Transactional(rollbackFor = Exception.class)
    public void saveLog(RuleContext rc) {
        if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(rc.getOrder().getTransType()) && rc.getAccountPo().getOldQty() < 0 && getInteType(rc.getOrder().getBizTime()) == 0) {
            //2021年2月22日19:59:19  如果老积分是负数则这个订单要补上上面负数的积分
            IntegralOrderPo integralOrderOldPo = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery().eq(IntegralOrderPo::getMemberId, rc.getMember().getMemberId())
                    .eq(IntegralOrderPo::getBizNo, rc.getOrder().getOrderNo()));
            //账户积分是负数必然有一个或者多个订单的剩余是负数
            List<IntegralOrderPo> integralOrderNewPos = integralOrderMapper.selectList(Wrappers.<IntegralOrderPo>lambdaQuery()
                    .eq(IntegralOrderPo::getMemberId, rc.getOrder().getMemberId())
                    .lt(IntegralOrderPo::getSurplusQty, 0)
                    .eq(IntegralOrderPo::getInteType, 0)
                    .ge(IntegralOrderPo::getCreateTime, onlineTime)
                    .orderByAsc(IntegralOrderPo::getCreateTime));
            fillNegative(integralOrderNewPos, integralOrderOldPo);
            return;
        }
        if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(rc.getOrder().getTransType()) && rc.getAccountPo().getNewQty() < 0 && getInteType(rc.getOrder().getBizTime()) == 1) {
            IntegralOrderPo integralOrderOldPo = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery().eq(IntegralOrderPo::getMemberId, rc.getMember().getMemberId())
                    .eq(IntegralOrderPo::getBizNo, rc.getOrder().getOrderNo()));
            //2021年2月22日19:59:19  如果老积分是负数则这个订单要补上上面负数的积分
            List<IntegralOrderPo> integralOrderNewPos = integralOrderMapper.selectList(Wrappers.<IntegralOrderPo>lambdaQuery()
                    .eq(IntegralOrderPo::getMemberId, rc.getMember().getMemberId())
                    .lt(IntegralOrderPo::getSurplusQty, 0)
                    .eq(IntegralOrderPo::getInteType, 1)
                    .ge(IntegralOrderPo::getCreateTime, onlineTime)
                    .orderByAsc(IntegralOrderPo::getCreateTime));
            fillNegative(integralOrderNewPos, integralOrderOldPo);
            return;
        }
        if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(rc.getOrder().getTransType()) && rc.getOrder().getIntePayable() <= 0) {
            //购买且没有消耗积分的话  是不需要的
            //如果业务时间是在businessTime 之前就是老积分 老积分就累计在老积分订单上  新积分就无所谓
            //2021年2月22日19:59:19  如果积分是负数则这个订单要补上上面负数的积分
            return;
        }
        if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(rc.getOrder().getTransType())) {
            Boolean usingType = getUsingType(rc.getOrder().getOrderNo());
            //正常销售、预订单、积分兑换跑积分活动
            //找到这个人的老积分订单  要是没有这个扣减的多就是扣的新积分
            //新积分订单都是在这个时间之后
            //上线的时候会会初始化一个老积分订单 就是老的
            //不存在老积分初始化  或者扣减的积分大于老积分就是走的新积分
            //新老积分的判断变成了按积分规则来看 2021年3月22日16:27:04
//            if (rc.getAccountPo().getOldQty() < rc.getOrder().getIntePayable()) {
            if (!usingType) {
                this.deductedNew(rc, IntegralBizTypeEnum.INTEGRAL_EXCH.getCode());
            } else {
                //老积分
                this.deductedOld(rc, IntegralBizTypeEnum.INTEGRAL_EXCH.getCode());
            }

        } else if (OrderTransTypeEnum.GOODS_RETURN.getCode().equals(rc.getOrder().getTransType()) && StringUtils.isNotBlank(rc.getOrder().getPreOrderNo())) {
            //正常销售退货、预订单退货、积分兑换退货【整单退】
            //退货的话  如果积分没有扣减的就直接退到对应订单上  如果对应积分的被扣了  就顺着扣
            IntegralOrderPo integralOrderOldPo = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery().eq(IntegralOrderPo::getMemberId, rc.getMember().getMemberId())
                    .eq(IntegralOrderPo::getBizNo, rc.getOrder().getPreOrderNo()));
            if (integralOrderOldPo == null) {
                //一般情况就是有的不然就是数据问题
                throw new BizException("不存在的前置购买订单！");
            }
            //如果是积分兑换退货就麻烦了
            if (integralOrderOldPo.getPaidQty() != 0) {
                List<IntegralLogPo> integralLogPos = integralLogMapper.selectList(Wrappers.<IntegralLogPo>lambdaQuery().eq(IntegralLogPo::getBizNo, integralOrderOldPo.getBizNo()));
                //如果没有对应的log很有可能是以前的订单
                if (integralLogPos == null || integralLogPos.size() == 0) {
                    this.deductedOldForInteReturn(integralOrderOldPo, rc.getOrder().getOrderNo());
                } else {
                    //找到多个订单 退回积分
                    for (IntegralLogPo integralLogPo : integralLogPos) {
                        IntegralOrderPo integralOrderPo = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery().eq(IntegralOrderPo::getBizNo, integralLogPo.getPreNo()));
                        this.save(rc.getOrder(), integralOrderPo, integralOrderPo.getSurplusQty() + integralLogPo.getInteQty(), integralLogPo.getInteQty(), IntegralBizTypeEnum.INTEGRAL_EXCH_RETURN.getCode());
                        this.updateOrderSurplus(integralOrderPo.getIntegralOrderId(), integralOrderPo.getSurplusQty() + integralLogPo.getInteQty());
                    }
                }
            }
            //退货的正常逻辑没啥问题
            if (integralOrderOldPo.getSurplusQty().equals(integralOrderOldPo.getGainQty())) {
                //相同就是没有扣
                //没有扣就扣对应的订单
                this.save(rc.getOrder(), integralOrderOldPo, 0, integralOrderOldPo.getGainQty(), IntegralBizTypeEnum.SALE_RETURN.getCode());
                this.updateOrderSurplus(integralOrderOldPo.getIntegralOrderId(), 0);
            } else {
                //扣了就按时间顺序减
                //入口限制了积分数量  这里不会有问题
                //空退才是按业务时间来的 整单退的话就看原始订单是新的还是老的
                if (integralOrderOldPo.getInteType() == 0) {
                    this.deductedOld(rc, IntegralBizTypeEnum.SALE_RETURN.getCode());
                } else {
                    this.deductedNew(rc, IntegralBizTypeEnum.SALE_RETURN.getCode());
                }
            }
        }
    }

    /**
     * @param id
     * @param surplusQty
     */
    public void updateOrderSurplus(Integer id, Integer surplusQty) {
        IntegralOrderPo build = IntegralOrderPo.builder().integralOrderId(id).surplusQty(surplusQty).build();
        int update = integralOrderMapper.updateById(build);
        if (update == 0) {
            throw new BizException("积分订单修改剩余积分失败！");
        }
    }


    /**
     * @param posOrderPo
     * @param integralOrderPo
     * @param residueQty      剩余积分
     * @param inteQty         扣减积分
     * @param bizType         积分类型
     */
    public void save(PosOrderPo posOrderPo, IntegralOrderPo integralOrderPo, Integer residueQty, Integer inteQty, String bizType) {
        IntegralLogPo build = IntegralLogPo.builder()
                .memberId(posOrderPo.getMemberId())
                .bizType(bizType)
                .bizInteQty(posOrderPo.getIntePayable())
                .bizNo(posOrderPo.getOrderNo())
                .preNo(integralOrderPo.getBizNo())
                .preInteQty(integralOrderPo.getSurplusQty())
                .inteQty(inteQty)
                .residueQty(residueQty)
                .bizTime(posOrderPo.getBizTime())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
        int insert = integralLogMapper.insert(build);
        if (insert == 0) {
            throw new BizException("积分记录插入失败！");
        }
    }


    /**
     * @param posOrderPo
     * @param integralOrderPo
     * @param residueQty      剩余积分
     * @param inteQty         扣减积分
     * @param bizType         积分类型
     */
    public void save(IntegralOrderPo posOrderPo, IntegralOrderPo integralOrderPo, Integer residueQty, Integer inteQty, String bizType) {
        IntegralLogPo build = IntegralLogPo.builder()
                .memberId(posOrderPo.getMemberId())
                .bizType(bizType)
                .bizInteQty(posOrderPo.getPaidQty())
                .bizNo(posOrderPo.getBizNo())
                .preNo(integralOrderPo.getBizNo())
                .preInteQty(integralOrderPo.getSurplusQty())
                .inteQty(inteQty)
                .residueQty(residueQty)
                .bizTime(posOrderPo.getBizTime())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
        int insert = integralLogMapper.insert(build);
        if (insert == 0) {
            throw new BizException("积分记录插入失败！");
        }
    }

    /**
     * 扣减新积分
     *
     * @param rc
     */
    public void deductedNew(RuleContext rc, String bizType) {
        IntegralOrderPo integralOrderPo = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery().eq(IntegralOrderPo::getBizNo, rc.getOrder().getOrderNo()));
        List<IntegralOrderPo> integralOrderNewPos = integralOrderMapper.selectList(Wrappers.<IntegralOrderPo>lambdaQuery()
                .eq(IntegralOrderPo::getMemberId, rc.getMember().getMemberId())
                .notIn(IntegralOrderPo::getBizType, IntegralBizTypeEnum.INTEGRAL_OLD.getCode())
                .gt(IntegralOrderPo::getSurplusQty, 0)
                .eq(IntegralOrderPo::getInteType, 1)
                .ge(IntegralOrderPo::getCreateTime, onlineTime)
                .orderByAsc(IntegralOrderPo::getCreateTime));
        if (integralOrderNewPos == null || integralOrderNewPos.size() == 0) {
            //这种情况肯定是数据有问题
            throw new BizException("用户" + rc.getMember().getMemberId() + "不存在未消耗的积分订单");
        }
        Integer intePayable = 0;
        if (rc.getOrder().getTransType().equals(-1)) {
            //退货的话
            intePayable = integralOrderPo.getGainQty() * -1;
        } else {
            intePayable = rc.getOrder().getIntePayable();
        }
        for (IntegralOrderPo integralOrderNewPo : integralOrderNewPos) {
            Integer surplusQty = integralOrderNewPo.getSurplusQty();
            if (intePayable <= 0) {
                //见到0就跳出
                break;
            }
            //如果扣减的积分大于
            if (intePayable >= surplusQty) {
                intePayable = intePayable - surplusQty;
                this.save(rc.getOrder(), integralOrderNewPo, intePayable, surplusQty, bizType);
                this.updateOrderSurplus(integralOrderNewPo.getIntegralOrderId(), 0);
            } else {
                this.save(rc.getOrder(), integralOrderNewPo, 0, intePayable, bizType);
                this.updateOrderSurplus(integralOrderNewPo.getIntegralOrderId(), surplusQty - intePayable);
                intePayable = 0;
            }
        }
        if (intePayable > 0) {
            //还存在没有减完的  正常情况下就给减积分的存个负数 后面在加回来吧
            this.updateOrderSurplus(integralOrderPo.getIntegralOrderId(), intePayable * -1);
        }
    }


    /**
     * 扣减新积分重载给空退用
     *
     * @param integralOrderPo
     * @param bizType
     */
    public void deductedNewForEmptyReturn(IntegralOrderPo integralOrderPo, String bizType) {
        List<IntegralOrderPo> integralOrderNewPos;
        if (integralOrderPo.getInteType() == 0) {
            integralOrderNewPos = integralOrderMapper.selectList(Wrappers.<IntegralOrderPo>lambdaQuery()
                    .eq(IntegralOrderPo::getMemberId, integralOrderPo.getMemberId())
                    .gt(IntegralOrderPo::getSurplusQty, 0)
                    .eq(IntegralOrderPo::getInteType, 0)
                    .ge(IntegralOrderPo::getCreateTime, onlineTime)
                    .orderByAsc(IntegralOrderPo::getCreateTime));
        } else {
            integralOrderNewPos = integralOrderMapper.selectList(Wrappers.<IntegralOrderPo>lambdaQuery()
                    .eq(IntegralOrderPo::getMemberId, integralOrderPo.getMemberId())
                    .notIn(IntegralOrderPo::getBizType, IntegralBizTypeEnum.INTEGRAL_OLD.getCode())
                    .gt(IntegralOrderPo::getSurplusQty, 0)
                    .eq(IntegralOrderPo::getInteType, 1)
                    .ge(IntegralOrderPo::getCreateTime, onlineTime)
                    .orderByAsc(IntegralOrderPo::getCreateTime));
        }
        if (integralOrderNewPos == null || integralOrderNewPos.size() == 0) {
            //这种情况肯定是数据有问题
            //也有可能第一个就是空退
//            log.error("用户" + integralOrderPo.getMemberId() + "不存在未消耗的积分订单");
            IntegralOrderPo integralOrder = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery().eq(IntegralOrderPo::getBizNo, integralOrderPo.getBizNo()));
            this.updateOrderSurplus(integralOrder.getIntegralOrderId(), integralOrderPo.getIntegralQty());
            return;
        }
        Integer intePayable = integralOrderPo.getIntegralQty() * -1;
        for (IntegralOrderPo integralOrderNewPo : integralOrderNewPos) {
            Integer surplusQty = integralOrderNewPo.getSurplusQty();
            if (intePayable <= 0) {
                //见到0就跳出
                break;
            }
            //如果扣减的积分大于
            if (intePayable >= surplusQty) {
                intePayable = intePayable - surplusQty;
                this.save(integralOrderPo, integralOrderNewPo, intePayable, surplusQty, bizType);
                this.updateOrderSurplus(integralOrderNewPo.getIntegralOrderId(), 0);
            } else {
                this.save(integralOrderPo, integralOrderNewPo, 0, intePayable, bizType);
                this.updateOrderSurplus(integralOrderNewPo.getIntegralOrderId(), surplusQty - intePayable);
                intePayable = 0;
            }
        }
        if (intePayable != 0) {
            this.updateOrderSurplus(integralOrderPo.getIntegralOrderId(), intePayable * -1);
        }
    }

    /**
     * 扣减新积分
     *
     * @param rc
     */
    public void deductedOld(RuleContext rc, String bizType) {
        List<IntegralOrderPo> integralOrderNewPos = integralOrderMapper.selectList(Wrappers.<IntegralOrderPo>lambdaQuery()
                .eq(IntegralOrderPo::getMemberId, rc.getMember().getMemberId())
                .gt(IntegralOrderPo::getSurplusQty, 0)
                .eq(IntegralOrderPo::getInteType, 0)
                .ge(IntegralOrderPo::getCreateTime, onlineTime)
                .orderByAsc(IntegralOrderPo::getCreateTime));
        if (integralOrderNewPos == null || integralOrderNewPos.size() == 0) {
            //这种情况肯定是数据有问题
            log.error("用户" + rc.getMember().getMemberId() + "不存在未消耗的老积分订单");
            throw new BizException("用户" + rc.getMember().getMemberId() + "不存在未消耗的老积分订单");
        }
        IntegralOrderPo integralOrderPo = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery().eq(IntegralOrderPo::getBizNo, rc.getOrder().getOrderNo()));
        Integer intePayable = 0;
        if (rc.getOrder().getTransType().equals(-1)) {
            //退货的话
            intePayable = integralOrderPo.getGainQty() * -1;
        } else {
            intePayable = rc.getOrder().getIntePayable();
        }
        for (IntegralOrderPo integralOrderNewPo : integralOrderNewPos) {
            Integer surplusQty = integralOrderNewPo.getSurplusQty();
            if (intePayable <= 0) {
                //见到0就跳出
                break;
            }
            //如果扣减的积分大于
            if (intePayable >= surplusQty) {
                intePayable = intePayable - surplusQty;
                this.save(rc.getOrder(), integralOrderNewPo, intePayable, surplusQty, bizType);
                this.updateOrderSurplus(integralOrderNewPo.getIntegralOrderId(), 0);
            } else {
                this.save(rc.getOrder(), integralOrderNewPo, 0, intePayable, bizType);
                this.updateOrderSurplus(integralOrderNewPo.getIntegralOrderId(), surplusQty - intePayable);
                intePayable = 0;
            }
        }
    }


    /**
     * 老的积分兑换的扣减扣减新积分
     *
     * @param integralOrderPo
     */
    public void deductedOldForInteReturn(IntegralOrderPo integralOrderPo, String bizNo) {
        IntegralOrderPo integralOrder = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery().eq(IntegralOrderPo::getBizNo, bizNo));
        IntegralOrderPo integralOrderNewPos = integralOrderMapper.selectOne(Wrappers.<IntegralOrderPo>lambdaQuery()
                .eq(IntegralOrderPo::getMemberId, integralOrderPo.getMemberId())
                .eq(IntegralOrderPo::getBizType, IntegralBizTypeEnum.INTEGRAL_OLD.getCode()));
        if (integralOrderNewPos == null) {
            log.error("用户{}退老积分订单,但是没有老积分维护记录！", integralOrderPo.getMemberId());
            integralOrderNewPos = integralOrderPo;
        }
        //自己给自己加回去退回的积分
        Integer intePayable = integralOrderPo.getPaidQty() * -1;
        this.save(integralOrder, integralOrderNewPos, 0, intePayable, IntegralBizTypeEnum.INTEGRAL_EXCH_RETURN.getCode());
        this.updateOrderSurplus(integralOrderNewPos.getIntegralOrderId(), integralOrderNewPos.getSurplusQty() + intePayable);
    }

    /**
     * 查看用的是新老积分
     * true 老积分 false 新积分
     *
     * @param integralOrderPo
     * @return
     */
    public boolean checkPaidQty(IntegralOrderPo integralOrderPo) {
        if (integralOrderPo.getPaidQty() == 0) {
            //没有使用积分的 无所谓使用了啥
            return true;
        }
        List<IntegralLogPo> integralLogPos = integralLogMapper.selectList(Wrappers.<IntegralLogPo>lambdaQuery().eq(IntegralLogPo::getBizNo, integralOrderPo.getBizNo()));
        if (integralLogPos == null || integralLogPos.size() == 0) {
            //不存在log记录的肯定是老积分
            return true;
        }
        //如果size等于1   则很有可能是扣的老积分
        List<String> collect = integralLogPos.stream().map(IntegralLogPo::getPreNo).collect(Collectors.toList());
        List<IntegralOrderPo> integralOrderPos = integralOrderMapper.selectList(Wrappers.<IntegralOrderPo>lambdaQuery().in(IntegralOrderPo::getBizNo, collect));
        if (integralOrderPos != null && integralOrderPos.size() > 0) {
            IntegralOrderPo integralOrderOldPo = integralOrderPos.get(0);
            if (integralOrderOldPo.getInteType().equals(0)) {
                return true;
            }
        }
        return false;
    }


    /**
     * 通过时间获取积分类型
     * 0 老积分 1 新积分
     *
     * @param localDateTime
     * @return
     */
    public int getInteType(LocalDateTime localDateTime) {
        return localDateTime.isBefore(businessTime) ? 0 : 1;
    }


    /**
     * 通过活动判断新老积分积分类型
     * true 老积分 false 新积分
     *
     * @param orderNo
     * @return
     */
    public Boolean getUsingType(String orderNo) {
        //获取订单号 找到订单明细
        //积分兑换的话 一般一个活动  两个活动的话也是相同的积分兑换活动
        PosOrderPo posOrderPo = posOrderMapper.selectById(orderNo);
        if (posOrderPo == null) {
            throw new BizException("不存在的订单" + orderNo);
        }
        if (posOrderPo.getIntePayable() == null || posOrderPo.getIntePayable() == 0) {
            //没有积分扣减无所谓  都是0
            return false;
        }
        Integer integer = memberActivityMapper.queryIntegralType(orderNo);
        if (integer == null) {
            throw new BizException("缺失新老积分规则" + orderNo);
        }
        return integer == 0;
    }


    /**
     * 填补负数积分
     *
     * @param integralOrderNewPos
     * @param integralOrderPo
     */
    public void fillNegative(List<IntegralOrderPo> integralOrderNewPos, IntegralOrderPo integralOrderPo) {
        if (integralOrderNewPos == null || integralOrderNewPos.size() == 0) {
            //存在负数就没有问题
            log.error(integralOrderPo.getMemberId() + "积分负数,但是没有负数积分的订单");
            return;
        }
        Integer integralQty = integralOrderPo.getSurplusQty();
        for (IntegralOrderPo integralOrderNewPo : integralOrderNewPos) {
            //剩余积分是负数
            if (integralQty <= 0) {
                break;
            }
            Integer negative = integralOrderNewPo.getSurplusQty();
            if (integralQty > negative * -1) {
                integralQty = negative + integralQty;
                this.save(integralOrderPo, integralOrderNewPo, 0, negative, integralOrderPo.getBizType());
                this.updateOrderSurplus(integralOrderNewPo.getIntegralOrderId(), 0);
                this.updateOrderSurplus(integralOrderPo.getIntegralOrderId(), integralQty);
            } else {
                this.save(integralOrderPo, integralOrderNewPo, 0, integralQty, integralOrderPo.getBizType());
                this.updateOrderSurplus(integralOrderNewPo.getIntegralOrderId(), negative + integralQty);
                this.updateOrderSurplus(integralOrderPo.getIntegralOrderId(), 0);
                integralQty = 0;
            }
        }
    }

}
