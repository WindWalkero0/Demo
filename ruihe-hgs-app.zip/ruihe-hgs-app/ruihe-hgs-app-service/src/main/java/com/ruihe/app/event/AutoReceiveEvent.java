package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;


@Data
@EqualsAndHashCode(callSuper = false)
public class AutoReceiveEvent extends ApplicationEvent {

    public AutoReceiveEvent(Object source) {
        super(source);
    }
}
