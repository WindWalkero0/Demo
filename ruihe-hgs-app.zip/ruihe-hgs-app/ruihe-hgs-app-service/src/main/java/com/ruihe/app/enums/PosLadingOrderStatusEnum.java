package com.ruihe.app.enums;

/**
 * @Description 提货单状态
 * @author 梁远
 * @create 2019-10-17 15:14
 */
public enum PosLadingOrderStatusEnum {

    //已提取
    LADED(0, "已提取"),
    //已退货
    REFUND(1, "已退货");
    private Integer code;
    private String msg;


    PosLadingOrderStatusEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
