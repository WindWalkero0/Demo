package com.ruihe.app.constant;

/**
 * u8单据类型名称
 *
 * @author xyf
 */
public class U8DocumentTypeConfig {
    /**
     * 存货档案修改
     **/
    public static final String  MAT_Edit = "MAT_Edit";
    /**
     * 存货档案增加
     **/
    public static final String  MAT_Add = "MAT_Add";
    /**
     * 存货档案修改
     **/
    public static final String  MAT_EDIT = "MAT_EDIT";
    /**
     * 存货档案增加
     **/
    public static final String  MAT_ADD = "MAT_ADD";
    /**
     * 其他入库单
     **/
    public static final String  TI_ADD = "TI_ADD";
    /**
     * 其他出库单
     **/
    public static final String  TO_ADD = "TO_ADD";
    /**
     * 发货单新增
     **/
    public static final String  SASEND_ADD= "SASEND_ADD";
    /**
     * 退货单新增
     **/
    public static final String  RO_ADD= "RO_ADD";
    /**
     * 调拨申请单新增
     **/
    public static final String  TR_ADD= "TR_ADD";
    /**
     * 调拨单新增
     **/
    public static final String  TV_ADD= "TV_ADD";
    /**
     * 调拨申请单失效新增
     **/
    public static final String  TR_CLOSED= "TR_CLOSED";
    /**
     *  盘点单新增
     **/
    public static final String  CV_ADD="CV_ADD";
    /**
     *  加盟商入库
     **/
    public static final String  SO_ADD="SO_ADD";
    /**
     *  确认回调
     **/
    public static final String  RETURN_CONFIRM="RETURN_CONFIRM";
    /**
     *  其他出库单和其他入库单消息后，反馈U8一个消息确认
     **/
    public static final String  POS_RETURN_CONFIRM="POS_RETURN_CONFIRM";
    /**
     * 其他入库单返回u8的确认
     **/
    public static final String  R_TI_ADD = "R_TI_ADD";
    /**
     * 加盟的配货的销售出库单返回u8的确认
     **/
    public static final String  R_SO_ADD = "R_SO_ADD";
    /**
     * 其他出库单返回u8的确认
     **/
    public static final String  R_TO_ADD = "R_TO_ADD";
    /**
     * 发货单反馈
     **/
    public static final String  R_RO_ADD = "R_RO_ADD";
    /**
     * 退货单反馈
     **/
    public static final String  R_SASEND_ADD = "R_SASEND_ADD";
    /**
     * 调拨申请单反馈
     **/
    public static final String  R_TR_ADD = "R_TR_ADD";
    /**
     * 调拨单反馈
     **/
    public static final String  R_TV_ADD = "R_TV_ADD";
    /**
     * 盘点单反馈
     **/
    public static final String  R_CV_ADD= "R_CV_ADD";

    /**
     * 调价单
     **/
    public static final String  SA_CusPrice_Add= "SA_CusPrice_Add";

    /**
     * 退货单要给花果山也来一份
     **/
    public static final String  SO_RDT_ADD= "SO_RDT_ADD";
}
