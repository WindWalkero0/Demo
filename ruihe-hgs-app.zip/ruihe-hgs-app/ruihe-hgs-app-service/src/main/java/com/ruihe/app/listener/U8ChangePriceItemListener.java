package com.ruihe.app.listener;


import com.alibaba.fastjson.JSON;
import com.ruihe.app.event.U8ChangePriceItemEvent;
import com.ruihe.app.service.u8.U8ChangePriceItemService;
import com.ruihe.common.constant.CommonConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.time.LocalDate;

/**
 * u8同步掉价单监听
 * @author qubin
 * @date 2021/4/16 13:14
 */
@Slf4j
@Component
public class U8ChangePriceItemListener {

    @Autowired
    private U8ChangePriceItemService u8ChangePriceItemService;

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(U8ChangePriceItemEvent event) {
        try{
            //获取单号
            String orderNo = event.getOrderNo();
            //生效时间是今天
            LocalDate effectiveTime = LocalDate.now();
            //调用修改订货价方法
            u8ChangePriceItemService.updateProductOrderPrice(orderNo, effectiveTime);

        }catch (Exception e){
            log.error("u8同步调价单修改订货价异常，event{}", JSON.toJSONString(event), e);
        }
    }
}
