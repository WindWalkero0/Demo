package com.ruihe.app.service.activity;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.basic.ProductMapper;
import com.ruihe.common.dao.bean.base.Product;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;


@Service
@Slf4j
public class SimpleProductService {

    private final ProductMapper productMapper;

    public SimpleProductService(ProductMapper productMapper) {
        this.productMapper = productMapper;
    }

    /**
     * 获取产品详情
     *
     * @param productCodes 产品条码集合
     * @return 产品集合
     */
    public List<Product> findAllProducts(List<String> productCodes) {

        if (CollectionUtils.isEmpty(productCodes)) {
            return Collections.emptyList();
        }
        var condition = Wrappers.<Product>lambdaQuery()
                .in(Product::getPrdBarCode, productCodes);
        return productMapper.selectList(condition);
    }


}
