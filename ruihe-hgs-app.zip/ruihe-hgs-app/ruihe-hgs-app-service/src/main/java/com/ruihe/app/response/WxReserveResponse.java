package com.ruihe.app.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author huangjie
 * @Description
 * @create 2021-04-23 10:33
 */
@ApiModel(value = "WxReserveRequest", description = "预约登记列表属性实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WxReserveResponse {

    @ApiModelProperty("时间")
    private String time;

    //("0":不可预约,"1":可以预约)
    @ApiModelProperty("状态")
    private Integer status;
}
