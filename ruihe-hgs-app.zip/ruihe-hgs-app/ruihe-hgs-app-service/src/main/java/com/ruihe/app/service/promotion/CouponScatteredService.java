package com.ruihe.app.service.promotion;

import com.ruihe.app.request.SalesRequest;
import com.ruihe.app.service.order.SalesOrderService;
import com.ruihe.app.service.order.ScatteredService;
import com.ruihe.common.dao.bean.promotion.RewardCloud;
import com.ruihe.common.util.LambdaUtil;
import com.ruihe.common.enums.promotion.PromotionalEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.pojo.request.promotion.SalesProductRequest;
import com.ruihe.common.service.CustomService;
import com.ruihe.app.response.PromotionCouponVo;
import com.ruihe.common.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CouponScatteredService {

    @Autowired
    private CustomService customService;

    @Autowired
    private ScatteredService scatteredService;

    @Autowired
    private SalesOrderService salesOrderService;

    /**
     * 活动匹配
     *
     * @param promotionCouponVo 活动信息
     * @param list              符合的活动集合
     * @param salesRequestOther      购买商品
     */
    public void checkPromotion(PromotionCouponVo promotionCouponVo, List<PromotionCouponVo> list, SalesRequest salesRequestOther,SalesRequest salesRequest) {
        if (salesOrderService.checkActivityPlace(promotionCouponVo.getActivityPlaceType(), promotionCouponVo.getProCouponId(), salesRequestOther) &&
                salesOrderService.checkActivityObject(promotionCouponVo.getActivityObjectType(), promotionCouponVo.getProCouponId(), salesRequestOther.getFlag(), salesRequestOther.getMemberRequest().getMemberId()) &&
                checkSheet(promotionCouponVo, salesRequestOther,salesRequest)) {
            list.add(promotionCouponVo);
        }
    }

    /**
     * 非整单匹配
     *
     * @param promotionCouponVo 发券活动
     * @param salesRequestOther      购买条件
     * @return
     */
    public synchronized Boolean checkSheet(PromotionCouponVo promotionCouponVo, SalesRequest salesRequestOther,SalesRequest salesRequest) {
        //查询购买条件的组合->包含了固定和选择
        List<RewardCloud> rewardClouds = customService.selectList(RewardCloud.builder().isDel(CommonStatusEnum.EFFECTIVE.getCode()).cloudMethod(0).promotionalUid(promotionCouponVo.getProCouponId()).build());
        if (rewardClouds.isEmpty()) {
            return true;
        }
        if (checkFix(salesRequestOther, rewardClouds) && checkSelect(salesRequestOther, rewardClouds)) {
            salesRequest.setProducts(salesRequestOther.getProducts());
            LambdaUtil lambdaUtil = LambdaUtil.builder().count(1).build();
            matchActivityCount(promotionCouponVo, lambdaUtil, salesRequestOther, rewardClouds,salesRequest);
            promotionCouponVo.setCount(lambdaUtil.getCount());
            return true;
        }
        return false;
    }

    private void matchActivityCount(PromotionCouponVo promotionCouponVo, LambdaUtil lambdaUtil, SalesRequest salesRequestOther, List<RewardCloud> rewardClouds,SalesRequest salesRequest) {
        if (promotionCouponVo.getCouponCount() > lambdaUtil.getCount()) {
            if (checkFix(salesRequestOther, rewardClouds) && checkSelect(salesRequestOther, rewardClouds)) {
                salesRequest.setProducts(salesRequestOther.getProducts());
                lambdaUtil.setCount(lambdaUtil.getCount() + 1);
                matchActivityCount(promotionCouponVo, lambdaUtil, salesRequestOther, rewardClouds,salesRequest);
            }
        }

    }

    /**
     * 固定组合
     *
     * @param salesRequest 购买的商品信息
     * @param rewardClouds 购买条件商品
     * @return
     */
    private Boolean checkFix(SalesRequest salesRequest, List<RewardCloud> rewardClouds) {
        List<RewardCloud> collect = rewardClouds.stream().filter(rewardCloud -> rewardCloud.getCloudType().equals(0)).map(rewardCloud -> {//过滤掉选择
            RewardCloud build = RewardCloud.builder().build();
            BeanUtils.copyProperties(rewardCloud, build);
            return build;
        }).collect(Collectors.toList());
        if (collect.isEmpty()) {
            return true;
        }
        LambdaUtil lambdaUtil = LambdaUtil.builder().flag(false).build();
        Map<Integer, List<RewardCloud>> linkMap = scatteredService.sortAll(collect, 0);
        linkMap.forEach((k, v) -> {
            Integer proRange = v.get(0).getProRange();
            if (proRange.equals(PromotionalEnum.PRO2.getKey())) {//指定商品
                lambdaUtil.setFlag(appoint(salesRequest, v));
            } else if (proRange.equals(PromotionalEnum.PRO6.getKey())) {//产品小类
                // TODO: 2020/11/5
            } else if (proRange.equals(PromotionalEnum.PRO1.getKey())) {//产品范围
                // TODO: 2020/11/5
            } else {
                log.error("未知条件类型type={}", proRange);
                throw new BizException("未知条件类型");
            }
        });
        return lambdaUtil.getFlag();
    }

    /**
     * 固定组合->指定产品
     *
     * @param salesRequest 购买的商品信息
     * @param rewardClouds 购买条件商品
     * @return
     */
    private boolean appoint(SalesRequest salesRequest, List<RewardCloud> rewardClouds) {
        List<RewardCloud> collect = rewardClouds.stream().filter(rewardCloud -> rewardCloud.getProRange().equals(PromotionalEnum.PRO2.getKey())).map(rewardCloud -> {//只要特定产品
            RewardCloud build = RewardCloud.builder().build();
            BeanUtils.copyProperties(rewardCloud, build);
            return build;
        }).collect(Collectors.toList());
        if (!collect.isEmpty()) {
            scatteredService.sortAppointProduct(collect);
            Map<Serializable, SalesProductRequest> data = salesOrderService.fillData(salesRequest);
            for (RewardCloud rewardCloud : collect) {//判断购买的商品是否满足基础条件
                SalesProductRequest salesProductRequest = data.get(rewardCloud.getSpecificProductId());
                if (salesProductRequest == null || !scatteredService.operationCondition(rewardCloud, Integer.parseInt(salesProductRequest.getProCount()))) {
                    return false;
                }
            }
            collect.forEach(rewardCloud -> {
                SalesProductRequest salesProductRequest = data.get(rewardCloud.getSpecificProductId());
                //获取购买的商品信息
                List<SalesProductRequest> products = salesRequest.getProducts();
                Iterator<SalesProductRequest> iterator = products.iterator();
                while (iterator.hasNext()) {
                    SalesProductRequest next = iterator.next();
                    if (next.getProId().equals(salesProductRequest.getProId())) {
                        Integer count = Integer.parseInt(next.getProCount()) - Integer.parseInt(rewardCloud.getInputValues());
                        if (count <= 0) {
                            iterator.remove();
                        }
                        next.setProCount(count.toString());
                    }
                }
                //修改完毕
                salesRequest.setProducts(products);
            });
        }
        return true;
    }

    /**
     * 选择组合
     *
     * @param salesRequest 购买的商品信息
     * @param rewardClouds 购买条件商品
     * @return
     */
    private Boolean checkSelect(SalesRequest salesRequest, List<RewardCloud> rewardClouds) {
        List<RewardCloud> collect = rewardClouds.stream().filter(rewardCloud -> rewardCloud.getCloudType().equals(1)).map(rewardCloud -> {//过滤掉选择
            RewardCloud build = RewardCloud.builder().build();
            BeanUtils.copyProperties(rewardCloud, build);
            return build;
        }).collect(Collectors.toList());
        LambdaUtil lambdaUtil = LambdaUtil.builder().flag(false).build();
        if (collect.isEmpty()) {
            return true;
        }
        Map<Integer, List<RewardCloud>> linkMap = scatteredService.sortAll(collect, 1);
        linkMap.forEach((k, v) -> {
            Integer proRange = v.get(0).getProRange();
            if (proRange.equals(PromotionalEnum.PRO2.getKey())) {
                lambdaUtil.setFlag(selectAppointUtil(salesRequest, v));
            } else if (proRange.equals(PromotionalEnum.PRO6.getKey())) {
                // TODO: 2020/11/5
            } else if (proRange.equals(PromotionalEnum.PRO1.getKey())) {
                // TODO: 2020/11/5
            } else {
                log.error("未知条件类型type={}", proRange);
                throw new BizException("未知条件类型");
            }
        });
        return lambdaUtil.getFlag();
    }

    /**
     * 选择组合->指定产品
     *
     * @param salesRequest 购买的商品信息
     * @param rewardClouds 购买条件商品
     * @return
     */
    private boolean selectAppointUtil(SalesRequest salesRequest, List<RewardCloud> rewardClouds) {
        List<RewardCloud> collect = rewardClouds.stream().filter(rewardCloud -> rewardCloud.getProRange().equals(PromotionalEnum.PRO2.getKey())).map(rewardCloud -> {//只要特定产品
            RewardCloud build = RewardCloud.builder().build();
            BeanUtils.copyProperties(rewardCloud, build);
            return build;
        }).collect(Collectors.toList());
        if (!collect.isEmpty()) {
            scatteredService.sortAppointProduct(collect);
            Map<Serializable, SalesProductRequest> data = salesOrderService.fillData(salesRequest);
            for (RewardCloud rewardCloud : collect) {
                SalesProductRequest salesProductRequest = data.get(rewardCloud.getSpecificProductId());
                if (salesProductRequest != null && scatteredService.operationCondition(rewardCloud, Integer.parseInt(salesProductRequest.getProCount()))) {
                    List<SalesProductRequest> products = salesRequest.getProducts();
                    Iterator<SalesProductRequest> iterator = products.iterator();
                    while (iterator.hasNext()) {
                        SalesProductRequest next = iterator.next();
                        if (next.getProId().equals(salesProductRequest.getProId())) {
                            Integer count = Integer.parseInt(next.getProCount()) - Integer.parseInt(rewardCloud.getInputValues());
                            next.setProCount(count.toString());
                            if (count.equals(0)) {
                                iterator.remove();
                            }
                        }
                    }
                    //修改完毕
                    salesRequest.setProducts(products);
                    return true;
                }
            }
        }
        return false;
    }
}

