package com.ruihe.app.constant;

/**
 * u8仓库部门相关的配置
 *
 * @author xyf
 */
public class U8WareHouseConfig {
    /**
     * 次品仓
     **/
    public static final String  DefectiveGoodsWarehouse = "DC017";
    /**
     * 试用装仓
     **/
    public static final String  SampleWarehouse  = "DC004";
    /**
     * 大仓报残仓
     **/
    public static final String  DamagedWarehouse = "DC009";
    /**
     * 转店仓
     **/
    public static final String  ExchangeWarehouse = "DC015";
    /**
     * 直营管理部门
     **/
    public static final String  DirectManagementDepartment = "0018ZYB";
    /**
     * 经手人
     **/
    public static final String  HandledBy = "024";
    /**
     * 虚拟商品
     */
    public static final String  Virtual = "88888888";
}
