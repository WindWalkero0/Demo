package com.ruihe.app.service.order;

import com.ruihe.app.request.order.OrderHistoryRequest;
import com.ruihe.app.request.order.PosRsvOrderQueryRequest;
import com.ruihe.app.request.order.BuyHistoryRequest;
import com.ruihe.common.response.Response;

/**
 * @author 梁远
 * @Description 预定单查询服务
 * @create 2019-10-19 15:40
 */
public interface PosRsvOrderService {
    /**
     * 查询预订单
     *
     * @param request
     * @return
     */
    Response queryRsvOrder(PosRsvOrderQueryRequest request);

    /**
     * 查询预订单明细
     *
     * @param orderNo
     * @return
     */
    Response queryRsvOrderItem(String orderNo);

    /**
     * 寄存箱查询历史销售记录
     *
     * @param request
     * @return
     */
    Response orderHistory(OrderHistoryRequest request);

    /**
     * 查询会员历史购买记录，以订单维度展示
     *
     * @param request
     * @return
     */
    Response buyHistory(BuyHistoryRequest request);

    /**
     * 获取历史购买记录详情
     *
     * @param orderNo
     * @param transType
     * @return
     */
    Response historyItem(String orderNo, Integer transType);
}
