package com.ruihe.app.enums;

/**
 * 导购助手-资料等级类型枚举
 * @author qubin
 * @date 2021/7/5 15:21
 */
public enum MaterialLevelTypeEnum {

    LEVEL_2(2, "二级"),
    LEVEL_3(3, "三级"),
    ;


    private Integer code;
    private String msg;


    MaterialLevelTypeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
