package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 入库确认事件
 *
 * @author William
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class WhEnterEvent extends OrderEvent {

    public WhEnterEvent(Object source, String orderNo) {
        super(source, orderNo);
    }
}
