package com.ruihe.app.listener;

import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.service.MemberInvcodeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.EventListener;
import org.springframework.core.Ordered;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * spring 环境启动或者刷新事件监听
 *
 * @author William
 * @date 2021/3/31 19:33
 */
@Slf4j
@Component
public class SpringContextStartedListener implements ApplicationListener<ApplicationStartedEvent>, Ordered {

    @Autowired
    private MemberInvcodeService memberInvcodeService;

    @Override
    public int getOrder() {
        return 1;
    }

    @Override
    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(ApplicationStartedEvent event) {
        try {
            memberInvcodeService.loadIntoCache();
        } catch (Exception e) {
            log.error("spring context started error", e);
        }
    }

}
