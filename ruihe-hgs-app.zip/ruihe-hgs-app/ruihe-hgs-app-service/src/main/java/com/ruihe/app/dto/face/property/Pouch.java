package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class Pouch {
    private Integer exist;

    private Integer level;

    private String maskPath;

    /**
     * 面积
     */
    private OverallArea overallArea;
}
