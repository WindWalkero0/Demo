package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 销售订单事件-积分处理
 *
 * @author William
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Order4IntegralBeforeLevelEvent extends ApplicationEvent {

    private String memberId;
    private String orderNo;

    public Order4IntegralBeforeLevelEvent(Object source, String memberId, String orderNo) {
        super(source);
        this.memberId = memberId;
        this.orderNo = orderNo;
    }
}
