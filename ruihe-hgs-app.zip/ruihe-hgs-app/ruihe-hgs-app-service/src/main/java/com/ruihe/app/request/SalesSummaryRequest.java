package com.ruihe.app.request;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * @Anthor:Fangtao
 * @Date:2019/12/16 14:24
 */
@Api(value = "销售小结接收类")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SalesSummaryRequest implements Serializable {
    @ApiModelProperty(value = "柜台id")
    @NotNull(message = "柜台编码不能为空")
    private String counterId;
    @ApiModelProperty(value = "开始时间")
    private LocalDate startTime;
    @ApiModelProperty(value = "结束时间")
    private LocalDate endTime;
    @ApiModelProperty(value = "ba id")
    private String baCode;
}
