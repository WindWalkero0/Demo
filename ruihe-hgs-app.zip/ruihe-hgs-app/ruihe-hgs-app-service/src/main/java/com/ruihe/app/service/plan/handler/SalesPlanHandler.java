package com.ruihe.app.service.plan.handler;

import com.ruihe.app.request.plan.SalesPlanInfoQueryRequest;
import com.ruihe.app.request.plan.SalesPlanOperateRequest;
import com.ruihe.common.dao.bean.plan.SalesPlanPo;
import com.ruihe.common.enums.plan.PlanObjectTypeEnum;
import com.ruihe.common.pojo.response.plan.SalesPlanDetailResponse;
import com.ruihe.common.pojo.response.plan.SalesPlanInfoSimpleResponse;
import com.ruihe.common.response.Response;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * 销售规划处理器
 * @author qubin
 * @date 2021/7/15 17:33
 */
public interface SalesPlanHandler {

    /**
     * 销售规划准备
     * @author qubin
     * @date 2021/7/15 17:41
     * @param request 操作请求
     * @return com.ruihe.common.response.Response
     */
    Response prepare(SalesPlanOperateRequest request);

    /**
     * 获取销售规划详情基本信息s
     * @param planObjectId 计划对象id
     * @param bizId 业务id
     * @return com.ruihe.common.response.Response
     */
    Response getBaseDetail(String planObjectId, String bizId);

    /**
     * 获取销售规划详情实际金额及项目信息
     * @author qubin
     * @date 2021/7/16 11:01
     * @param salesPlanDetailResponse  销售规划详情响应
     * @param exitSalesPlanPo  已规划的实体
     * @return com.ruihe.common.response.Response
     */
    void getActAmtAndNursingItem(SalesPlanDetailResponse salesPlanDetailResponse, SalesPlanPo exitSalesPlanPo);

    /**
     * 获取销售规划列表
     * @author qubin
     * @date 2021/7/19 9:40
     * @param memberIdList 会员id集合
     * @param bizIdList 业务id集合
     * @param salesPlanList 销售规划列表
     * @param request  查询请求
     */
    void getBaseInfo(List<String> memberIdList, List<String> bizIdList, List<SalesPlanInfoSimpleResponse> salesPlanList, SalesPlanInfoQueryRequest request);

    /**
     * 批量获取实际金额和实际护理项目
     * @author qubin
     * @date 2021/7/19 9:41
     * @param memberIdList 会员id集合
     * @param request 查询请求
     * @param memberIdAndActAmtMap 会员id实际金额map
     * @return com.ruihe.common.response.Response
     */
    Response getBatchActAmtAndNursingItem(List<String> memberIdList, SalesPlanInfoQueryRequest request, Map<String, BigDecimal> memberIdAndActAmtMap);


}
