package com.ruihe.app.enums;

/**
 * 柜台心跳类型枚举
 *
 * @author qubin
 */
public enum CountHeartbeatTypeEnum {

    COMMON("COMMON", "通用"),

    SPECIAL("SPECIAL", "个性化"),
    ;

    private String code;
    private String msg;


    CountHeartbeatTypeEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
