package com.ruihe.app.service.plan.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.ObjectUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.basic.CounterInfoMapper;
import com.ruihe.app.mapper.member.MemberCouponMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.mapper.plan.SalesPlanMapper;
import com.ruihe.app.request.plan.SalesPlanInfoQueryRequest;
import com.ruihe.app.request.plan.SalesPlanOperateRequest;
import com.ruihe.app.response.plan.SalesPlanCommonResponse;
import com.ruihe.app.service.plan.SalesPlanService;
import com.ruihe.app.service.plan.handler.SalesPlanHandler;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.dao.bean.member.MemberCoupon;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.member.MemberOrderSearchPo;
import com.ruihe.common.dao.bean.nursing.NursingMemberPO;
import com.ruihe.common.dao.bean.nursing.NursingRecordChildPo;
import com.ruihe.common.dao.bean.nursing.NursingRecordPO;
import com.ruihe.common.dao.bean.plan.SalesPlanPo;
import com.ruihe.common.dao.mapper.*;
import com.ruihe.common.dao.mapper.integral.IntegralAccountMapper;
import com.ruihe.common.enums.plan.PlanMemberTypeEnum;
import com.ruihe.common.enums.plan.PlanObjectTypeEnum;
import com.ruihe.common.pojo.response.homepage.MemberIdAndTotalAmt;
import com.ruihe.common.pojo.response.plan.*;
import com.ruihe.common.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.Collator;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

;

/**
 * @author qubin
 * @date 2021/4/2 13:37
 */
@Service
@Slf4j
public class SalesPlanServiceImpl implements SalesPlanService, ApplicationContextAware {

    @Autowired
    private MemberInfoMapper memberInfoMapper;

    @Autowired
    private SalesPlanMapper salesPlanMapper;

    @Autowired
    private IntegralAccountMapper integralAccountMapper;

    @Autowired
    private MemberOrderSearchMapper memberOrderSearchMapper;

    @Autowired
    private NursingRecordMapper nursingRecordMapper;

    @Autowired
    private NursingMemberMapper nursingMemberMapper;

    @Autowired
    private MemberCouponMapper memberCouponMapper;

    @Autowired
    private CounterInfoMapper counterInfoMapper;

    @Autowired
    private NursingRecordChildMapper nursingRecordChildMapper;

    @Autowired
    private PosOrderMapper posOrderMapper;

    private ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(@NonNull ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    private Collator collator = Collator.getInstance(Locale.CHINA);

    @Override
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response operateSalesPlan(SalesPlanOperateRequest request) {

        CounterInformation counterInformation = counterInfoMapper.selectOne(Wrappers.<CounterInformation>lambdaQuery()
                .eq(CounterInformation::getCounterId, request.getCounterId()));
        if (counterInformation == null) {
            return Response.errorMsg("柜台不存在");
        }

        SalesPlanHandler salePlanHandler = this.applicationContext.getBean(PlanObjectTypeEnum.parse(request.getPlanObjectType()).name(), SalesPlanHandler.class);
        if (salePlanHandler == null) {
            return Response.errorMsg("销售规划处理器不存在");
        }
        Response prepareResponse = salePlanHandler.prepare(request);
        if (prepareResponse.getCodeL() != 200) {
            return prepareResponse;
        }
        SalesPlanCommonResponse salesPlanCommonResponse = (SalesPlanCommonResponse) prepareResponse.getData();
        //如果不是销售型会员，把规划项目和规划金额置空
        if (!PlanMemberTypeEnum.SALES.getCode().equals(request.getPlanMemberType())) {
            request.setPlanAmt(new BigDecimal(0));
            request.setPlanNursingId(JSONArray.parseArray("[]"));
            request.setPlanNursingItem(JSONArray.parseArray("[]"));
        }

        //根据bizId查询记录是否存在，存在则更新，否在创建
        SalesPlanPo exitSalesPlanPo = salesPlanMapper.selectOne(Wrappers.<SalesPlanPo>lambdaQuery().eq(SalesPlanPo::getBizId, salesPlanCommonResponse.getBizId()));
        if (exitSalesPlanPo == null) {
            //组装数据
            SalesPlanPo salesPlanPo = SalesPlanPo.builder()
                    .planObjectType(request.getPlanObjectType())
                    .planObjectId(request.getPlanObjectId())
                    .planNursingId(request.getPlanNursingId())
                    .planNursingItem(request.getPlanNursingItem())
                    .planAmt(request.getPlanAmt())
                    .planTime(salesPlanCommonResponse.getPlanTime())
                    .counterId(request.getCounterId())
                    .counterName(counterInformation.getCounterName())
                    .planMemberType(request.getPlanMemberType())
                    .memberId(request.getMemberId())
                    .memberName(request.getMemberName())
                    .memberPhone(request.getMemberPhone())
                    .baCode(request.getBaCode())
                    .baName(request.getBaName())
                    .createTime(LocalDateTime.now())
                    .updateTime(LocalDateTime.now())
                    .bizId(salesPlanCommonResponse.getBizId())
                    .build();

            int save = salesPlanMapper.insert(salesPlanPo);
            if (save != 1) {
                return Response.errorMsg("销售规划添加失败");
            }
            return Response.success();
        }
        //更新数据
        SalesPlanPo salesPlanPo = SalesPlanPo.builder()
                .planObjectType(request.getPlanObjectType())
                .planObjectId(request.getPlanObjectId())
                .planNursingId(request.getPlanNursingId())
                .planNursingItem(request.getPlanNursingItem())
                .planAmt(request.getPlanAmt())
                .planMemberType(request.getPlanMemberType())
                .updateTime(LocalDateTime.now())
                .build();
        //更新
        int updateCount = salesPlanMapper.update(salesPlanPo, Wrappers.lambdaQuery(SalesPlanPo.class)
                .eq(SalesPlanPo::getBizId, salesPlanCommonResponse.getBizId()));
        if (updateCount != 1) {
            return Response.errorMsg("销售规划修改失败");
        }
        return Response.success();
    }

    @DS(DBConst.SLAVE)
    public Response selectSalesPlanInfoDetail(String planObjectType, String planObjectId, String bizId) {
        if (planObjectType == null) {
            return Response.errorMsg("规划对象类型不能为空");
        }
        if (planObjectId == null) {
            return Response.errorMsg("规划对象id为空");
        }

        SalesPlanHandler salePlanHandler = this.applicationContext.getBean(PlanObjectTypeEnum.parse(planObjectType).name(), SalesPlanHandler.class);
        if (salePlanHandler == null) {
            return Response.errorMsg("销售规划处理器不存在");
        }
        Response baseDetailResponse = salePlanHandler.getBaseDetail(planObjectId, bizId);
        if (baseDetailResponse.getCodeL() != 200) {
            return baseDetailResponse;
        }
        SalesPlanDetailResponse build = (SalesPlanDetailResponse) baseDetailResponse.getData();
        //查询会员是否存在
        MemberInfo memberInfo = memberInfoMapper.selectOne(Wrappers.<MemberInfo>lambdaQuery()
                .eq(MemberInfo::getMemberId, build.getMemberId()));
        //手机号必有
        if (!ObjectUtils.isEmpty(memberInfo)) {
            //会员相关数据
            build.setMemberName(memberInfo.getMemberName());
            build.setBirthday(memberInfo.getBirthday());
            build.setMemberLevelCode(memberInfo.memberLevelCode);
            build.setMemberLevelName(memberInfo.getMemberLevelName());
        }

        //查询效果规划记录
        SalesPlanPo exitSalesPlanPo = salesPlanMapper.selectByBizId(build.getBizId());
        if (exitSalesPlanPo != null) {
            //规划相关数据
            build.setPlanAmt(exitSalesPlanPo.getPlanAmt());
            build.setPlanMemberType(exitSalesPlanPo.getPlanMemberType());
            build.setPlanNursingId(exitSalesPlanPo.getPlanNursingId());
            build.setPlanNursingItem(exitSalesPlanPo.getPlanNursingItem());
        }
        if (StringUtils.isNotBlank(build.getMemberId())) {
            //查询会员积分
            IntegralAccountPo integralAccountPo = integralAccountMapper.selectById(memberInfo.getMemberId());
            if (integralAccountPo != null) {
                //积分数据
                build.setTotalQty(integralAccountPo.getTotalQty());
                build.setTotalNewQty(integralAccountPo.getNewQty());
                build.setTotalOldQty(integralAccountPo.getOldQty());
            }
            //查询最近下单
            MemberOrderSearchPo memberOrderSearchPo = memberOrderSearchMapper.selectOne(Wrappers.<MemberOrderSearchPo>lambdaQuery()
                    .eq(MemberOrderSearchPo::getMemberId, build.getMemberId()));
            if (memberOrderSearchPo != null) {
                //最近下单时间
                build.setRecentOrderTime(memberOrderSearchPo.getRecentTime());
            }
            //查询未使用优惠券数量
            List<MemberCoupon> memberCouponList = memberCouponMapper.selectList(Wrappers.<MemberCoupon>lambdaQuery()
                    .eq(MemberCoupon::getMemberId, build.getMemberId())
                    .eq(MemberCoupon::getStatus, 0));
            build.setMemberCouponCount(memberCouponList == null || memberCouponList.size() <= 0 ? 0 : memberCouponList.size());

            //查询最近护理项目
            NursingRecordPO nursingRecordPO = nursingRecordMapper.selectRecentNursingRecordByMemberId(build.getMemberId());
            if (nursingRecordPO != null) {
                //最近护理信息数据
                build.setRecentNursingTime(nursingRecordPO.getCreateTime());
                build.setRecentNursingBaName(nursingRecordPO.getBaName());
            }
            //查询会员护理包项目
            NursingMemberPO nursingMemberPO = nursingMemberMapper.selectOne(Wrappers.<NursingMemberPO>lambdaQuery()
                    .eq(NursingMemberPO::getMemberId, build.getMemberId())
                    .eq(NursingMemberPO::getCounterId, build.getCounterId()));
            if (nursingMemberPO != null) {
                //会员已有护理包项目
                build.setMemberNursingItem(nursingMemberPO.getNursingItem());
                //会员当前护理维护美导名称
                build.setMemberNursingBaName(nursingMemberPO.getBaName());
            }
            salePlanHandler.getActAmtAndNursingItem(build, exitSalesPlanPo);
        }
        return Response.success(build);
    }

    @DS(DBConst.SLAVE)
    public Response selectSalesPlanInfo(SalesPlanInfoQueryRequest request) {
        //参数非空判断
        if (StringUtils.isEmpty(request.getCounterId())) {
            Response.errorMsg("柜台id不能为空");
        }
        if (request.getPlanObjectType() == null) {
            Response.errorMsg("规划对象类型不能为空");
        }
        if (request.getPlanTime() == null) {
            Response.errorMsg("到店时间不能为空");
        }
        List<String> memberIdList = new ArrayList<>();
        List<String> bizIdList = new ArrayList<>();
        SalesPlanInfoQueryResponse build = SalesPlanInfoQueryResponse.builder().build();
        List<SalesPlanInfoSimpleResponse> salesPlanList = new ArrayList<>();

        //获取列表基础数据
        SalesPlanHandler salePlanHandler = this.applicationContext.getBean(PlanObjectTypeEnum.parse(request.getPlanObjectType()).name(), SalesPlanHandler.class);
        if (salePlanHandler == null) {
            return Response.errorMsg("销售规划处理器不存在");
        }
        //查询列表基本数据
        salePlanHandler.getBaseInfo(memberIdList, bizIdList, salesPlanList, request);
        if (salesPlanList.size() == 0) {
            return Response.success();
        }
        //查询会员等级
        List<MemberInfo> memberInfos = memberInfoMapper.selectBatchIds(memberIdList);
        //得到key是memberId，value是会员等级的map
        Map<String, MemberInfo> memberIdAndMemberInfoMap = memberInfos.stream()
                .collect(Collectors.toMap(MemberInfo::getMemberId, memberInfo -> memberInfo));

        Map<String, BigDecimal> memberIdAndActAmtMap = new HashMap<>();
        //key是memberId,value是护理项集合的map
        Map<String, List<String>> memberIdAndActNursingItemMap = new HashMap<>();

        //获取批量实际金额和实际护理项目
        Response actNursingInfoResponse = salePlanHandler.getBatchActAmtAndNursingItem(memberIdList, request, memberIdAndActAmtMap);
        if (actNursingInfoResponse.getCodeL() != 200) {
            return actNursingInfoResponse;
        }
        List<NursingRecordPO> nursingRecordList = (List<NursingRecordPO>) actNursingInfoResponse.getData();
        if (nursingRecordList != null && nursingRecordList.size() > 0) {
            List<String> nursingRecordIdList = new ArrayList<>();
            Map<String, String> recordIdAndMemberIdMap = new HashMap<>();
            nursingRecordList.forEach(nursingRecordPO -> {
                nursingRecordIdList.add(nursingRecordPO.getId());
                recordIdAndMemberIdMap.put(nursingRecordPO.getId(), nursingRecordPO.getMemberId());
            });
            List<NursingRecordChildPo> recordChildList = nursingRecordChildMapper.selectByRecordIdList(nursingRecordIdList);
            recordChildList.forEach(nursingRecordChildPo -> {
                //如果包含，则合并
                if (memberIdAndActNursingItemMap.containsKey(recordIdAndMemberIdMap.get(nursingRecordChildPo.getRecordId()))) {
                    List<String> nursingItemList = memberIdAndActNursingItemMap.get(recordIdAndMemberIdMap.get(nursingRecordChildPo.getRecordId()));
                    nursingItemList.add(nursingRecordChildPo.getNursingItem());
                    memberIdAndActNursingItemMap.put(recordIdAndMemberIdMap.get(nursingRecordChildPo.getRecordId()), nursingItemList);
                } else {
                    List<String> nursingItemList = new ArrayList<>();
                    nursingItemList.add(nursingRecordChildPo.getNursingItem());
                    memberIdAndActNursingItemMap.put(recordIdAndMemberIdMap.get(nursingRecordChildPo.getRecordId()), nursingItemList);
                }
            });
        }
        List<SalesPlanInfoSimpleResponse> responseList = new ArrayList<>();
        BigDecimal totalActAmt = new BigDecimal(0);
        BigDecimal totalPlanAmt = new BigDecimal(0);
        int salesPlanQty = 0;
        if (!bizIdList.isEmpty()) {
            //查询销售规划记录
            List<SalesPlanInfoSimpleResponse> salesPlanPoList = salesPlanMapper.selectByBizIdListAndPlanMemberType(bizIdList,
                    request.getPlanMemberType());
            //构造key是memberId，value是SalesPlanInfoSimpleResponse的map
            Map<String, SalesPlanInfoSimpleResponse> bizIdAndSalesPlanMap = salesPlanPoList.stream().collect(Collectors.
                    toMap(SalesPlanInfoSimpleResponse::getBizId, salesPlanInfoSimpleResponse -> salesPlanInfoSimpleResponse));

            for (SalesPlanInfoSimpleResponse salesPlan : salesPlanList) {
                MemberInfo memberInfo = memberIdAndMemberInfoMap.get(salesPlan.getMemberId());
                if (memberInfo != null) {
                    salesPlan.setMemberLevelName(memberInfo.getMemberLevelName());
                } else {
                    memberInfo = MemberInfo.builder()
                            .memberLevelCode("-1")
                            .memberLevel(-1)
                            .memberLevelName("非会员")
                            .build();
                }
                if (bizIdAndSalesPlanMap.containsKey(salesPlan.getBizId())) {
                    SalesPlanInfoSimpleResponse simple = bizIdAndSalesPlanMap.get(salesPlan.getBizId());
                    salesPlan.setPlanId(simple.getPlanId());
                    salesPlan.setPlanMemberType(simple.getPlanMemberType());
                    salesPlan.setPlanTime(simple.getPlanTime());
                    salesPlan.setPlanNursingItem(simple.getPlanNursingItem());
                    //规划金额
                    salesPlan.setPlanAmt(PlanMemberTypeEnum.SALES.getCode().equals(salesPlan.getPlanMemberType()) ? simple.getPlanAmt() : null);
                    //从map中取出实际销售金额
                    salesPlan.setActAmt(memberIdAndActAmtMap.get(salesPlan.getMemberId()) == null ? new BigDecimal(0) : memberIdAndActAmtMap.get(salesPlan.getMemberId()));
                    //从map中取出实际护理项
                    salesPlan.setActNursingItem(JSONArray.parseArray(JSON.toJSONString(memberIdAndActNursingItemMap.get(salesPlan.getMemberId()))));
                }

                if (request.getMemberLevel() == null && request.getPlanMemberType() == null) {
                    salesPlanQty = salesPlanQty + (salesPlan.getPlanId() != null && salesPlan.getPlanId() > 0 ? 1 : 0);
                    totalActAmt = totalActAmt.add(salesPlan.getActAmt() == null ? new BigDecimal(0) : salesPlan.getActAmt());
                    totalPlanAmt = totalPlanAmt.add(salesPlan.getPlanAmt() == null ? new BigDecimal(0) : salesPlan.getPlanAmt());
                    responseList.add(salesPlan);
                    continue;
                }
                if (request.getMemberLevel() == null && request.getPlanMemberType() != null) {
                    if (request.getPlanMemberType().equals(salesPlan.getPlanMemberType())) {
                        salesPlanQty = salesPlanQty + (salesPlan.getPlanId() != null && salesPlan.getPlanId() > 0 ? 1 : 0);
                        totalActAmt = totalActAmt.add(salesPlan.getActAmt() == null ? new BigDecimal(0) : salesPlan.getActAmt());
                        totalPlanAmt = totalPlanAmt.add(salesPlan.getPlanAmt() == null ? new BigDecimal(0) : salesPlan.getPlanAmt());
                        responseList.add(salesPlan);
                        continue;
                    }
                }
                if (request.getMemberLevel() != null && request.getPlanMemberType() == null) {
                    if (memberInfo != null && request.getMemberLevel() == memberInfo.getMemberLevel()) {
                        salesPlanQty = salesPlanQty + (salesPlan.getPlanId() != null && salesPlan.getPlanId() > 0 ? 1 : 0);
                        totalActAmt = totalActAmt.add(salesPlan.getActAmt() == null ? new BigDecimal(0) : salesPlan.getActAmt());
                        totalPlanAmt = totalPlanAmt.add(salesPlan.getPlanAmt() == null ? new BigDecimal(0) : salesPlan.getPlanAmt());
                        responseList.add(salesPlan);
                        continue;
                    }
                }
                if (request.getMemberLevel() != null && request.getPlanMemberType() != null) {
                    if (memberInfo != null && request.getMemberLevel() == memberInfo.getMemberLevel() && request.getPlanMemberType()
                            .equals(salesPlan.getPlanMemberType())) {
                        salesPlanQty = salesPlanQty + (salesPlan.getPlanId() != null && salesPlan.getPlanId() > 0 ? 1 : 0);
                        totalActAmt = totalActAmt.add(salesPlan.getActAmt() == null ? new BigDecimal(0) : salesPlan.getActAmt());
                        totalPlanAmt = totalPlanAmt.add(salesPlan.getPlanAmt() == null ? new BigDecimal(0) : salesPlan.getPlanAmt());
                        responseList.add(salesPlan);
                    }
                }
            }
        }
        //接待数
        build.setReceptQty(responseList.size());
        //实际规划金额
        build.setTotalActAmt(totalActAmt);
        //规划总金额
        build.setTotalPlanAmt(totalPlanAmt);
        build.setSalesPlanQty(salesPlanQty);
        build.setChildren(responseList);
        return Response.success(build);
    }

    /**
     * @param planTime  规划日期
     * @param counterId 柜台id
     * @return com.ruihe.common.response.Response
     * @author qubin
     * @date 2021/7/19 10:06
     */
    public Response selectTotalMonthSalesPlanInfo(String counterId, String planTime) {
        /**
         *  1.查询柜台所有状态为已确认的护理包会员
         *  2.根据会员id查询等级
         *  3.根据柜台id和规划日期查询已经规划的记录
         *  4.根据会员id和规划日期查询实际销售金额
         */
        if (StringUtils.isBlank(counterId)) {
            return Response.errorMsg("柜台编号不能为空");
        }
        if (StringUtils.isBlank(planTime)) {
            return Response.errorMsg("规划日期不能为空");
        }
        if (planTime.length() != 6) {
            return Response.errorMsg("规划日期格式错误");
        }
        //1.查询柜台所有状态为已确认的护理包会员
        List<NursingMemberPO> nursingMemberPOList = nursingMemberMapper.selectList(Wrappers.<NursingMemberPO>lambdaQuery()
                .eq(NursingMemberPO::getCounterId, counterId)
                .eq(NursingMemberPO::getStatus, 2));
        if (nursingMemberPOList == null || nursingMemberPOList.size() == 0) {
            return Response.success();
        }
        //遍历取出memberId
        List<String> memberIdList = new ArrayList<>();
        nursingMemberPOList.forEach(nursingMemberPO -> { memberIdList.add(nursingMemberPO.getMemberId()); });

        //2.根据会员id查询等级
        //根据会员id查询等级
        List<MemberInfo> memberInfoList = memberInfoMapper.selectList(Wrappers.<MemberInfo>lambdaQuery().in(MemberInfo::getMemberId, memberIdList));
        //key是会员编号，value是等级编号
        Map<String, Integer> memberIdAndLevelMap = memberInfoList.stream().collect(Collectors.toMap(MemberInfo::getMemberId, MemberInfo::getMemberLevel));

        //3.根据柜台id和规划日期查询已经规划的记录
        int year = Integer.parseInt(planTime.substring(0, 4));
        int month = Integer.parseInt(planTime.substring(4, 6));
        LocalDateTime endTime = LocalDateTime.of(year, month, 26, 0, 0, 0);
        LocalDateTime startTime = endTime.minusMonths(1);
        List<SalesPlanPo> salesPlanPoList = salesPlanMapper.selectList(Wrappers.<SalesPlanPo>lambdaQuery()
                .eq(SalesPlanPo::getPlanObjectType, PlanObjectTypeEnum.NURSING_MEMBER.getCode())
                .eq(SalesPlanPo::getCounterId, counterId)
                .ge(SalesPlanPo::getPlanTime, startTime)
                .lt(SalesPlanPo::getPlanTime, endTime));
        //4.根据会员id和规划日期查询实际销售金额
        List<MemberIdAndTotalAmt> memberIdAndTotalAmtMap = posOrderMapper.sumPayAmtGroupByMemberId(memberIdList, startTime, endTime);
        Map<String, BigDecimal> memberIdAndActAmtMap = memberIdAndTotalAmtMap.stream().collect(Collectors.toMap(MemberIdAndTotalAmt::getMemberId, MemberIdAndTotalAmt::getTotalAmt));

        Map<String, MonthSalesPlanTotalInfoDetailResponse> baCodeAndInfoMap = new HashMap<>();
        for(NursingMemberPO nursingMemberPO : nursingMemberPOList) {
            //判断是否包含改美导，如果包含
            MonthSalesPlanTotalInfoDetailResponse monthSalesPlanTotalInfoDetailResponse;
            if (baCodeAndInfoMap.containsKey(nursingMemberPO.getBaCode())) {
                monthSalesPlanTotalInfoDetailResponse = baCodeAndInfoMap.get(nursingMemberPO.getBaCode());

            } else {
                monthSalesPlanTotalInfoDetailResponse = MonthSalesPlanTotalInfoDetailResponse.builder()
                        .baCode(nursingMemberPO.getBaCode())
                        .baName(nursingMemberPO.getBaName())
                        .actAmt(new BigDecimal(0))
                        .planAmt(new BigDecimal(0))
                        .build();
            }
            //会员等级统计
            switch (memberIdAndLevelMap.get(nursingMemberPO.getMemberId())) {
                //体验
                case 1:
                    monthSalesPlanTotalInfoDetailResponse.setExperiencedCount(monthSalesPlanTotalInfoDetailResponse.getExperiencedCount() + 1);
                    break;
                //花粉
                case 2:
                    monthSalesPlanTotalInfoDetailResponse.setPollenCount(monthSalesPlanTotalInfoDetailResponse.getPollenCount() + 1);
                    break;
                 //玫瑰
                case 3:
                    monthSalesPlanTotalInfoDetailResponse.setRoseCount(monthSalesPlanTotalInfoDetailResponse.getRoseCount()+ 1);
                    break;
                 //茉莉
                case 4:
                    monthSalesPlanTotalInfoDetailResponse.setJasmineCount(monthSalesPlanTotalInfoDetailResponse.getJasmineCount()+ 1);
                    break;
                //百合
                case 5:
                    monthSalesPlanTotalInfoDetailResponse.setLilyCount(monthSalesPlanTotalInfoDetailResponse.getLilyCount()+ 1);
                    break;
                //牡丹
                case 6:
                    monthSalesPlanTotalInfoDetailResponse.setPeonyCount(monthSalesPlanTotalInfoDetailResponse.getPeonyCount()+ 1);
                    break;
                default:
            }
            //默认会员数+1
            monthSalesPlanTotalInfoDetailResponse.setMemberCount(monthSalesPlanTotalInfoDetailResponse.getMemberCount() + 1);
            monthSalesPlanTotalInfoDetailResponse.setActAmt(monthSalesPlanTotalInfoDetailResponse.getActAmt()
                    .add(memberIdAndActAmtMap.get(nursingMemberPO.getMemberId()) == null ? new BigDecimal(0) : memberIdAndActAmtMap.get(nursingMemberPO.getMemberId())));
            //规划会员类型统计
            baCodeAndInfoMap.put(nursingMemberPO.getBaCode(), monthSalesPlanTotalInfoDetailResponse);
        }
        //规划类型统计
        for(SalesPlanPo salesPlanPo : salesPlanPoList){
            MonthSalesPlanTotalInfoDetailResponse monthSalesPlanTotalInfoDetailResponse = baCodeAndInfoMap.get(salesPlanPo.getBaCode());
            switch (salesPlanPo.getPlanMemberType()) {
                //销售型
                case "0":
                    monthSalesPlanTotalInfoDetailResponse.setSalesMemberCount(monthSalesPlanTotalInfoDetailResponse.getSalesMemberCount() + 1);
                    break;
                //维护型
                case "1":
                    monthSalesPlanTotalInfoDetailResponse.setMaintenanceMemberCount(monthSalesPlanTotalInfoDetailResponse.getMaintenanceMemberCount()+ 1);
                    break;
                //沉睡型
                case "2":
                    monthSalesPlanTotalInfoDetailResponse.setSleepMemberCount(monthSalesPlanTotalInfoDetailResponse.getSleepMemberCount()+ 1);
                    break;
                default:
            }
            monthSalesPlanTotalInfoDetailResponse.setPlanAmt(monthSalesPlanTotalInfoDetailResponse.getPlanAmt().add(salesPlanPo.getPlanAmt() ==  null ? new BigDecimal(0) : salesPlanPo.getPlanAmt()));
        }
        List<MonthSalesPlanTotalInfoDetailResponse> dataList = new ArrayList<>( baCodeAndInfoMap.values());
        dataList.sort((o1, o2) -> collator.compare(o1.getBaName(), o2.getBaName()));

        MonthSalesPlanTotalInfoResponse monthSalesPlanTotalInfoResponse = MonthSalesPlanTotalInfoResponse.builder()
                .totalPlanAmt(new BigDecimal(0))
                .totalActAmt(new BigDecimal(0))
                .build();
        dataList.forEach(monthSalesPlanTotalInfoDetailResponse -> {
            //未规划人数=总人数-沉睡型-维护型-销售型
            monthSalesPlanTotalInfoDetailResponse.setNoPlanMemberCount(monthSalesPlanTotalInfoDetailResponse.getMemberCount() -
                    monthSalesPlanTotalInfoDetailResponse.getSalesMemberCount() - monthSalesPlanTotalInfoDetailResponse.getSleepMemberCount()
                    - monthSalesPlanTotalInfoDetailResponse.getMaintenanceMemberCount());
            //总会员
            monthSalesPlanTotalInfoResponse.setTotalMemberCount(monthSalesPlanTotalInfoResponse.getTotalMemberCount() + monthSalesPlanTotalInfoDetailResponse.getMemberCount());
            //体验
            monthSalesPlanTotalInfoResponse.setTotalExperiencedCount(monthSalesPlanTotalInfoResponse.getTotalExperiencedCount() + monthSalesPlanTotalInfoDetailResponse.getExperiencedCount());
            //茉莉
            monthSalesPlanTotalInfoResponse.setTotalJasmineCount(monthSalesPlanTotalInfoResponse.getTotalJasmineCount() + monthSalesPlanTotalInfoDetailResponse.getJasmineCount());
            //玫瑰
            monthSalesPlanTotalInfoResponse.setTotalRoseCount(monthSalesPlanTotalInfoResponse.getTotalRoseCount() + monthSalesPlanTotalInfoDetailResponse.getRoseCount());
            //百合
            monthSalesPlanTotalInfoResponse.setTotalLilyCount(monthSalesPlanTotalInfoResponse.getTotalLilyCount() + monthSalesPlanTotalInfoDetailResponse.getLilyCount());
            //牡丹
            monthSalesPlanTotalInfoResponse.setTotalPeonyCount(monthSalesPlanTotalInfoResponse.getTotalPeonyCount() + monthSalesPlanTotalInfoDetailResponse.getPeonyCount());
            //花粉
            monthSalesPlanTotalInfoResponse.setTotalPollenCount(monthSalesPlanTotalInfoResponse.getTotalPollenCount() + monthSalesPlanTotalInfoDetailResponse.getPollenCount());
            //维护型
            monthSalesPlanTotalInfoResponse.setTotalMaintenanceMemberCount(monthSalesPlanTotalInfoResponse.getTotalMaintenanceMemberCount() + monthSalesPlanTotalInfoDetailResponse.getMaintenanceMemberCount());
            //销售型
            monthSalesPlanTotalInfoResponse.setTotalSalesMemberCount(monthSalesPlanTotalInfoResponse.getTotalSalesMemberCount() + monthSalesPlanTotalInfoDetailResponse.getSalesMemberCount());
            //沉睡型
            monthSalesPlanTotalInfoResponse.setTotalSleepMemberCount(monthSalesPlanTotalInfoResponse.getTotalSleepMemberCount() + monthSalesPlanTotalInfoDetailResponse.getSleepMemberCount());
            //未规划
            monthSalesPlanTotalInfoResponse.setTotalNoPlanMemberCount(monthSalesPlanTotalInfoResponse.getTotalNoPlanMemberCount() + monthSalesPlanTotalInfoDetailResponse.getNoPlanMemberCount());
            //规划金额
            monthSalesPlanTotalInfoResponse.setTotalPlanAmt(monthSalesPlanTotalInfoResponse.getTotalPlanAmt().add(monthSalesPlanTotalInfoDetailResponse.getPlanAmt()));
            //实际金额
            monthSalesPlanTotalInfoResponse.setTotalActAmt(monthSalesPlanTotalInfoResponse.getTotalActAmt().add(monthSalesPlanTotalInfoDetailResponse.getActAmt()));
        });
        monthSalesPlanTotalInfoResponse.setDetailResponseList(dataList);
        return Response.success(monthSalesPlanTotalInfoResponse);

    }
}
