package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * @author 梁远
 * @Description 会员入会事件
 * @create 2019-11-14 14:56
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Order4OnlyMemberLevelEvent extends ApplicationEvent {

    private String memberId;
    private String orderNo;

    public Order4OnlyMemberLevelEvent(Object source, String memberId, String orderNo) {
        super(source);
        this.memberId = memberId;
        this.orderNo = orderNo;
    }
}
