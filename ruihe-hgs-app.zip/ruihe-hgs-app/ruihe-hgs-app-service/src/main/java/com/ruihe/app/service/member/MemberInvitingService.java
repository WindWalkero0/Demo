package com.ruihe.app.service.member;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.app.request.KbInvitingPageRequest;
import com.ruihe.app.vo.MemberMyInvVo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.member.KbActivity;
import com.ruihe.common.dao.bean.member.MemberInviting;
import com.ruihe.common.dao.mapper.MemberInvitingMapper;
import com.ruihe.common.dao.mapper.MemberKbActivityMapper;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.MaskUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 邀请关联关系建立，邀请码操作，邀请关系查询
 *
 * @author William
 * @date 2021/3/18 10:26
 */
@Slf4j
@Service
public class MemberInvitingService {
    @Autowired
    private MemberInvitingMapper memberInvitingMapper;

    @Autowired
    private MemberKbActivityMapper memberKbActivityMapper;

    /**
     * 检查邀请关系是否已经存在
     *
     * @param invitorMemberId
     * @param inviteeMemberId
     */
    @DS(DBConst.SLAVE)
    public boolean exsitsInviting(String invitorMemberId, String inviteeMemberId) {
        Integer count = memberInvitingMapper.selectCount(Wrappers.<MemberInviting>lambdaQuery()
                .eq(MemberInviting::getInvitorMemberId, invitorMemberId)
                .eq(MemberInviting::getInviteeMemberId, inviteeMemberId));
        return count > 0;
    }

    /**
     * 建立邀请关系
     *
     * @param invitorMemberId 邀请人邀会员id
     * @param inviteeMemberId 被邀请人会员id
     * @param inviteePhone    被邀请人手机号
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void invitingBinding(String invitorMemberId, String inviteeMemberId, String inviteePhone) {
        int rows = memberInvitingMapper.invitingBinding(invitorMemberId, inviteeMemberId, inviteePhone);
        if (rows != 1) {
            log.warn("建立邀请关系失败,invitorMemberId={},inviteePhone={}", invitorMemberId, inviteePhone);
            throw new BizException("邀请码保存失败");
        }
    }

    /**
     * 我的邀请,分页查询</br>
     * 秉坤之前的推荐会员关系不做展示
     *
     * @param request
     */
    @DS(DBConst.SLAVE)
    public Response pageMyInvs(KbInvitingPageRequest request) {
        if (StringUtils.isBlank(request.getMemberId())) {
            return Response.error("参数错误");
        }
        //找到当前进行中的口碑礼配置
        KbActivity kbActivity = memberKbActivityMapper.selectOne(Wrappers.<KbActivity>lambdaQuery()
                .eq(KbActivity::getStatus, 0)
                .lt(KbActivity::getStartTime, LocalDateTime.now())
                .gt(KbActivity::getEndTime, LocalDateTime.now()));
        if (kbActivity == null) {
            return Response.errorMsg(501, "活动已结束");
        }
        //分页
        Page<MemberInviting> page = new Page<>(request.getPageNumber(), request.getPageSize());
        LambdaQueryWrapper<MemberInviting> memberInvitingLambdaQueryWrapper = Wrappers.<MemberInviting>lambdaQuery()
                .eq(MemberInviting::getInvitorMemberId, request.getMemberId())
                .gt(MemberInviting::getCreateTime, kbActivity.getStartTime())
                .orderByDesc(MemberInviting::getCreateTime);
        Page<MemberInviting> memberInvitingPage = memberInvitingMapper.selectPage(page, memberInvitingLambdaQueryWrapper);
        List<MemberMyInvVo> myInvList = memberInvitingPage.getRecords().stream()
                .map(e ->
                        MemberMyInvVo.builder()
                                .registerTime(e.getCreateTime())
                                .phoneNo(MaskUtils.maskMidPhone(e.getInviteePhone()))
                                .awardStatus(e.getKbStatus())
                                .build()
                ).collect(Collectors.toList());
        //返回前端
        PageVO pageVo = PageVO.<MemberMyInvVo>builder()
                .list(myInvList)
                .pageNum(memberInvitingPage.getCurrent())
                .pageSize(memberInvitingPage.getSize())
                .pages(memberInvitingPage.getPages())
                .total(memberInvitingPage.getTotal())
                .build();
        return Response.success(pageVo);
    }
}
