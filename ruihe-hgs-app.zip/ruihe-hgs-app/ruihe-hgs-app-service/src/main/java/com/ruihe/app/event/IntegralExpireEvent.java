package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 积分过期订单事件
 *
 * @author fly
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class IntegralExpireEvent extends ApplicationEvent {

    public IntegralExpireEvent(Object source) {
        super(source);
    }

}
