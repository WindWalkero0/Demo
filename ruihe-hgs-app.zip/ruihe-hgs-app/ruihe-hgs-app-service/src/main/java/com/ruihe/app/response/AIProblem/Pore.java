package com.ruihe.app.response.AIProblem;

public class Pore {
    private Integer number;
    private Integer level;
    private String image;
    private String layer;
    private String description;
}
