package com.ruihe.app.dto.face;

import com.ruihe.app.dto.face.property.*;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;

@Data
public class AiFaceDTO {
    /**
     * id
     */
    private String id;
    /**
     * 测肤记录ID
     */
    @NotBlank(message = "测肤记录Id不能为空")
    private String photographId;
    /**
     * 黑头
     */
    private BlackHead blackHead;
    /**
     * 痘痘
     */
    private List<Acnes> acnes;
    /**
     * 痘痘图层图片
     */
    private String acneLayer;
    /**
     * 黑眼圈
     */
    private List<DarkCircle> darkCircle;
    /**
     * 黑眼圈图层图片
     */
    private String darkCircleMaskPath;
    /**
     * 眉形
     */
    private Eyebrow eyebrow;
    /**
     * 眼型
     */
    private Eyeshape eyeshape;
    /**
     * 人脸姿态估计
     */
    private FacePose facePose;
    /**
     * 遮挡物
     */
    private FaceShelter faceShelter;
    /**
     * 肤色
     */
    private String facecolor;
    /**
     * 脸型
     */
    private String faceshape;
    /**
     * 脂肪粒
     */
    private List<FatGranule> fatGranule;
    /**
     * 卧蚕
     */
    private Integer furrows;
    /**
     * 图片质量
     */
    private ImageQuality imageQuality;
    /**
     * 是否是人脸
     */
    private Integer isface;
    /**
     * 水分
     */
    private List<Moisture> moisture;
    /**
     * 水分图层图片
     */
    private String moistureMaskPath;
    /**
     * 水分整脸的情况
     */
    private MoistureOverall moistureOverall;
    /**
     * 油分
     */
    private List<Oil> oil;
    /**
     * 油分整脸的情况
     */
    private OilOverall oilOverall;
    /**
     * 油分图层图片
     */
    private String oilMaskPath;
    /**
     * 色素斑
     */
    private List<Pigmentations> pigmentations;
    /**
     * 色斑图层图片
     */
    private String pigmentationLayer;
    /**
     * 毛孔
     */
    private Pore pore;
    /**
     * 眼袋
     */
    private Pouch pouch;
    /**
     * 敏感度
     */
    private Sensitivity sensitivity;
    /**
     * 性别
     */
    private Integer sex;
    /**
     * 肌肤年龄
     */
    private Integer skinAge;
    /**
     * 肤质类型
     */
    private Integer skinType;
    /**
     * 相似明星脸
     */
    private StarResult starResult;
    /**
     * 细纹
     */
    private List<Wrinkles> wrinkles;
    /**
     * 细纹图层图片
     */
    private String wrinkleLayer;
    /**
     * 鱼尾纹图层图片
     */
    private String crowfeetMaskPath;
    /**
     * 原图人脸坐标
     */
    private List<String> orgimageFaceLocation;
    /**
     * 会员ID
     */
    private String memberId;
    /**
     * 面部原始图片
     */
    @NotBlank(message = "原始图片不能为空")
    private String faceOriginImage;
    /**
     * 底图
     */
    private BasemapPaths basemapPaths;

}
