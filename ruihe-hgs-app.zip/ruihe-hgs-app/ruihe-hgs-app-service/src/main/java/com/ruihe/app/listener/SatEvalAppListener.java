package com.ruihe.app.listener;

import com.ruihe.app.event.SatEvalAppEvent;
import com.ruihe.app.service.wx.WxMemberSatService;
import com.ruihe.common.constant.CommonConstant;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

/**
 * 会员满意度评价
 *
 * @author LiangYuan
 * @date 2021-02-04 14:20
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SatEvalAppListener {

    private final WxMemberSatService wxMemberSatService;


    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(SatEvalAppEvent event) {
        try {
            wxMemberSatService.dealMemberSatEvent(event);
        } catch (Exception e) {
            log.error("处理会员满意度销售评价异常,event={},e={}", event, e);
        }
    }
}
