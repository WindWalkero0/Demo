package com.ruihe.app.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

@ApiModel(value = "UserCounterResponse", description = "用户柜台实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserCounterResponse implements Serializable {

    @ApiModelProperty(value = "柜员姓名")
    String name;

    @ApiModelProperty(value = "柜员手机号")
    String phone;

    @ApiModelProperty(value = "柜员唯一键")
    String uniqueId;

    @ApiModelProperty(value = "使用状态")
    Integer status;

    @ApiModelProperty(value = "柜台编号")
    String counterId;

    @ApiModelProperty(value = "身份证号")
    String numberId;

    @ApiModelProperty(value = "所属部门")
    String deptName;

    @ApiModelProperty(value = "最近一次登录时间")
    LocalDateTime lastLoginTime;
}
