package com.ruihe.app.dto.face.property;


import lombok.Data;

@Data
public class BlackHead {
    /**
     * 严重等级
     */
    private Integer level;
    /**
     * 黑头数量
     */
    private Integer number;
    /**
     * 黑头图层图片
     */
    private String maskPath;
}
