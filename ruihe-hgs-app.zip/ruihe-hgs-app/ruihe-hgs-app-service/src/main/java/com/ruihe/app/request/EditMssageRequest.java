package com.ruihe.app.request;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class EditMssageRequest {
    //主键id
    public Integer msgId;
    //定时发送时间
    public LocalDateTime sendTime;
}
