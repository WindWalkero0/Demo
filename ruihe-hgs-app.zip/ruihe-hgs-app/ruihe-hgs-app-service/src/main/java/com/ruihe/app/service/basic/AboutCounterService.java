package com.ruihe.app.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.StatusEnum;
import com.ruihe.common.service.CustomService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@DS(DBConst.SLAVE)
@Service
@Ella(Describe = "柜台管理service")
public class AboutCounterService {

    @Autowired
    private CustomService customService;

    @Ella(Describe = "根据counterId查询柜台信息", Author = "K")
    public CounterInformation selectCounter(String counterId) {
        //查询柜台信息
        return customService.select(CounterInformation.builder()
                .counterId(counterId)
                .isDel(StatusEnum.UN_DELETED.getKey())
                .build());
    }

    @Ella(Describe = "根据counterId查询柜台信息失效的也可以", Author = "K")
    public CounterInformation selectCounterAll(String counterId) {
        //查询柜台信息
        return customService.select(CounterInformation.builder()
                .counterId(counterId)
                //.isDel(StatusEnum.UN_DELETED.getKey())
                .build());
    }

    @Ella(Describe = "查询柜台信息", Author = "K")
    public CounterInformation selectCounterInfo(CounterInformation counterInformation) {
        return customService.select(counterInformation);
    }
}
