package com.ruihe.app.service.member;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.app.mapper.member.MemberVisitMapper;
import com.ruihe.app.request.member.MemberVisitReq;
import com.ruihe.app.response.MemberVisitVO;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.pojo.context.holder.PosUserContextHolder;
import com.ruihe.common.exception.CheckDataException;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Service
public class MemberVisitService {

    private final MemberVisitMapper memberVisitMapper;

    public MemberVisitService(MemberVisitMapper memberVisitMapper) {
        this.memberVisitMapper = memberVisitMapper;
    }

    @DS(DBConst.SLAVE)
    public PageVO<MemberVisitVO> queryBirthDayVisit(MemberVisitReq req) {
        var sessionUser = PosUserContextHolder.get().getCounter();
        String counterId = sessionUser.getCounterId();

        Page<MemberVisitVO> page = new Page<>(req.pageNumber, req.pageSize);
        boolean isCrossYear = req.beginDate.getYear() != req.endDate.getYear();//是否跨年
        String isCrossYearSql = "(date_format(str_to_date(birthday, '%Y-%m-%d'), '%m-%d') between {0} and '12-31' or date_format(str_to_date(birthday, '%Y-%m-%d'), '%m-%d') between '01-01' and {1}) and m.counter_id = {2}";
        String nonCrossYearSql = "date_format(str_to_date(birthday, '%Y-%m-%d'), '%m-%d')  between {0} and {1} and m.counter_id = {2}";
        String beginDate = req.beginDate.format(DateTimeFormatter.ofPattern("MM-dd")).trim();
        String endDate = req.endDate.format(DateTimeFormatter.ofPattern("MM-dd")).trim();
        var conditions = Wrappers.<MemberInfo>query()
                .apply(isCrossYear, isCrossYearSql, beginDate, endDate, counterId)
                .apply(!isCrossYear, nonCrossYearSql, beginDate, endDate, counterId);

        IPage<MemberVisitVO> birthdayVisit = memberVisitMapper.selectBirthdayVisit(page, conditions);
        return PageVO.<MemberVisitVO>builder()
                .list(birthdayVisit.getRecords())
                .pageNum(birthdayVisit.getCurrent())
                .pageSize(birthdayVisit.getSize())
                .pages(birthdayVisit.getPages())
                .total(birthdayVisit.getTotal())
                .build();
    }

    @DS(DBConst.SLAVE)
    public PageVO<MemberVisitVO> queryJoinDateVisit(MemberVisitReq req) {

        var sessionUser = PosUserContextHolder.get().getCounter();
        String counterId = sessionUser.getCounterId();
        String beginDate = req.beginDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String endDate = req.endDate.plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        Page<MemberVisitVO> page = new Page<>(req.pageNumber, req.pageSize);
        IPage<MemberVisitVO> joinDateVisit = memberVisitMapper.selectJoinDateVisit(page, counterId, beginDate, endDate);
        return PageVO.<MemberVisitVO>builder()
                .list(joinDateVisit.getRecords())
                .pageNum(joinDateVisit.getCurrent())
                .pageSize(joinDateVisit.getSize())
                .pages(joinDateVisit.getPages())
                .total(joinDateVisit.getTotal())
                .build();
    }

    @DS(DBConst.SLAVE)
    public PageVO<MemberVisitVO> queryByOrderTime(MemberVisitReq req) {

        var sessionUser = PosUserContextHolder.get().getCounter();
        String counterId = sessionUser.getCounterId();

        Page<MemberVisitVO> page = new Page<>(req.pageNumber, req.pageSize);
        IPage<MemberVisitVO> lastBuyVisit = memberVisitMapper.selectByOrderTime(page, counterId, req);
        return PageVO.<MemberVisitVO>builder()
                .list(lastBuyVisit.getRecords())
                .pageNum(lastBuyVisit.getCurrent())
                .pageSize(lastBuyVisit.getSize())
                .pages(lastBuyVisit.getPages())
                .total(lastBuyVisit.getTotal())
                .build();
    }

    /**
     * @param dateRange 时间范围枚举 {@link MemberVisitReq}
     * @return Pair
     */
    public static Pair<LocalDate, LocalDate> getBeginTimeAndEndTime(String dateRange) {
        LocalDate today = LocalDate.now();
        //生日回访
        switch (dateRange) {
            case "Today": //今天
                return Pair.of(today, today);
            case "ThisWeek": {//这个周
                var begin = today.minusDays(today.getDayOfWeek().getValue() - 1);
                var end = today.plusDays(7 - today.getDayOfWeek().getValue());
                return Pair.of(begin, end);
            }
            case "ThisMonth": {//这个月
                var begin = today.withDayOfMonth(1);
                var end = begin.plusMonths(1).minusDays(1);
                return Pair.of(begin, end);
            }
            //会员入会周期回访
            case "Recent7Day": {//最近7天
                var begin = today.minusDays(6);
                return Pair.of(begin, today);
            }
            case "Recent28Day": {//最近28天
                var begin = today.minusDays(27);
                return Pair.of(begin, today);
            }
            case "Recent56Day": {//最近56天
                var begin = today.minusDays(55);
                return Pair.of(begin, today);
            }
            //购买时间回访
            case "Recent3Day": {//最近3天
                var begin = today.minusDays(2);
                return Pair.of(begin, today);
            }
            case "Recent3Week": {//最近三周
                var begin = today.minusDays(20);
                return Pair.of(begin, today);
            }
            case "Recent3Month": {//最近三月
                var begin = today.minusDays(89);
                return Pair.of(begin, today);
            }
        }
        throw new CheckDataException("请求时间范围取值有误,请在DateRanges中取值");
    }
}
