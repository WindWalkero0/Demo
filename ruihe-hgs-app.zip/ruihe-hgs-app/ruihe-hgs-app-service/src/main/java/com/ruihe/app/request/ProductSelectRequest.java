package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author fly
 * @Description
 * @create 2020年6月5日17:12:26
 */
@ApiModel(value = "ProductSelectRequest", description = "查询产品做扫码")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductSelectRequest implements Serializable {

    @ApiModelProperty(value = "条件")
    private String condition;

    @ApiModelProperty(value = "价格")
    private String price;

}
