package com.ruihe.app.service.activity;

import com.ruihe.common.dao.bean.member.MemberActivity;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ActivityService<T extends MemberActivity, R> {

    private Predicate<T> place;
    private Predicate<T> object;
    private Predicate<T> time;
    private Function<T, R> aaa;

    void setMatchPlaceLogic(Predicate<T> matchPlaceLogic) {
        this.place = matchPlaceLogic;
    }

    List<R> execute(List<T> activities) {
        return activities.stream()
                .filter(place)
                .filter(object)
                .filter(time)
                .map(aaa)
                .collect(Collectors.toList());
    }


}
