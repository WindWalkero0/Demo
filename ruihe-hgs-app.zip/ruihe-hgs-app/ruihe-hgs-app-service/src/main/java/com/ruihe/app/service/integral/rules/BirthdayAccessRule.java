package com.ruihe.app.service.integral.rules;

import com.alibaba.fastjson.JSONObject;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.service.integral.IntegralRule;
import com.ruihe.app.service.integral.MatchResult;
import com.ruihe.app.service.integral.RuleContext;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.Month;

/**
 * 会员生日规则,必须是prototype模式，规避并发
 *
 * @author William
 */
@Scope("prototype")
@Component("birthdayAccessRule")
public class BirthdayAccessRule implements IntegralRule {
    @Autowired
    private PosOrderMapper posOrderMapper;

    @Override
    public MatchResult match(JSONObject conf, RuleContext rc) {
        //获取生日选项代码
        String code = conf.getJSONObject("selected").getString("code");
        LocalDate currentDate = LocalDate.now();
        if (StringUtils.isBlank(rc.getMember().getBirthday())){
            return MatchResult.missMatch("【会员生日】生日当日不匹配,无生日资料！");
        }
        LocalDate birthday = LocalDate.parse(rc.getMember().getBirthday());
        switch (code) {
            case "A":
                return this.a(rc.getMember().getMemberId(), currentDate, birthday);
            case "B":
                return this.b(rc.getMember().getMemberId(), currentDate, birthday);
        }
        return MatchResult.missMatch("【会员生日】生日当日不匹配");
    }

    /**
     * A:生日当日
     *
     * @param currentDate
     * @param birthday
     * @return
     */
    private MatchResult a(String memberId, LocalDate currentDate, LocalDate birthday) {
        if (currentDate.getMonth() == birthday.getMonth() && currentDate.getDayOfMonth() == birthday.getDayOfMonth()) {
            if (this.isFirstOrder(memberId, LocalDate.now(), LocalDate.now().plusDays(1))) {
                return MatchResult.match("【会员生日】生日当日匹配&首单匹配");
            }
            return MatchResult.missMatch("【会员生日】生日当日匹配&首单不匹配");
        } else if (!currentDate.isLeapYear() && birthday.isLeapYear() && Month.FEBRUARY == currentDate.getMonth() && Month.FEBRUARY == birthday.getMonth()) {
            //如果是闰年2月29日生日，平年时则当前日期是2.28时视为匹配
            if (currentDate.getDayOfMonth() == 28 && birthday.getDayOfMonth() == 29) {
                if (this.isFirstOrder(memberId, LocalDate.now(), LocalDate.now().plusDays(1))) {
                    return MatchResult.match("【会员生日】生日当日匹配&首单匹配");
                }
                return MatchResult.missMatch("【会员生日】生日当日匹配&首单不匹配");
            }
        }
        return MatchResult.missMatch("【会员生日】生日当日不匹配");
    }

    /**
     * 首单判断
     *
     * @param memberId
     * @param beginDate
     * @param endDate
     * @return
     */
    private boolean isFirstOrder(String memberId, LocalDate beginDate, LocalDate endDate) {
        //判断是否是时间内首单
        //2020年5月9日15:08:16 会员当月首单 如果买了退 第二次买也算
        Integer integer = posOrderMapper.selectFirstOrder(memberId, beginDate, endDate);
        return integer <= 1;
    }

    /**
     * B:生日当月
     *
     * @param birthday
     * @return
     */
    private MatchResult b(String memberId, LocalDate currentDate, LocalDate birthday) {
        if (birthday.getMonth().compareTo(currentDate.getMonth()) == 0) {
            if (this.isFirstOrder(memberId, currentDate.withDayOfMonth(1), currentDate.plusMonths(1).withDayOfMonth(1))) {
                return MatchResult.match("【会员生日】生日当月匹配&首单匹配");
            }
            return MatchResult.missMatch("【会员生日】生日当月匹配&首单不匹配");
        }
        return MatchResult.missMatch("【会员生日】生日当月不匹配");
    }

}
