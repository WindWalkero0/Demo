package com.ruihe.app.request;

import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author William
 * @Description 查单退货-订单分页查询
 */
@ApiModel(value = "PosOrderPageQueryRequest", description = "查单退货-订单分页查询")
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PosOrderPageQueryRequest extends PageForm implements Serializable {

    @ApiModelProperty(value = "开始时间")
    private LocalDate startTime;

    @ApiModelProperty(value = "结束时间")
    private LocalDate endTime;

    @ApiModelProperty(value = "手机号")
    private String memberPhone;

    @ApiModelProperty(value = "订单类型,全部不传,1销售,2预定单")
    private Integer orderType;
}
