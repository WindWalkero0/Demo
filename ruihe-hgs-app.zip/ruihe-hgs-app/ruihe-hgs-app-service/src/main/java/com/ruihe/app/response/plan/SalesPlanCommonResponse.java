package com.ruihe.app.response.plan;/**
 * @author qubin
 * @date 2021/7/16 10:01
 */

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 销售规划通用响应
 * @author qubin
 * @date 2021年07月16日 10:01
 */
@ApiModel(value = "SalesPlanCommonResponse", description = "销售规划通用响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SalesPlanCommonResponse implements Serializable {

    /**
     * 业务id
     */
    private String bizId;

    /**
     * 规划时间
     */
    private LocalDateTime planTime;
}
