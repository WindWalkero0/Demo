package com.ruihe.app.service.order;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.app.request.SalesRequest;
import com.ruihe.common.dao.bean.promotion.PromotionActivity;
import com.ruihe.common.dao.bean.promotion.PromotionProduct;
import com.ruihe.common.enums.promotion.PromotionalEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.pojo.request.promotion.SalesProductRequest;
import com.ruihe.common.pojo.response.promotion.ActivityProductResponse;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.utils.FullCombinationUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.IntStream;

import static java.util.Comparator.comparing;
import static java.util.Comparator.comparingInt;
import static java.util.stream.Collectors.*;

/**
 * 整单逻辑处理
 *
 * @Author 胡坤
 * @Date 2019年10月24日14:41:23
 */
@Slf4j
@Service
public class UnifiedService {

    @Autowired
    private SalesOrderService salesOrderService;

    @Autowired
    private CustomService customService;

    /**
     * 是否满足购买条件 (满足  返回true  不满足 返回false)
     */
    @DS(DBConst.SLAVE)
    public Boolean checkSheet(PromotionActivity promotionActivity, SalesRequest salesRequest) {

        /**
         * 判断是否有限定产品,目前只有特定产品
         */
        List<PromotionProduct> promotionProducts = customService.selectList(PromotionProduct
                .builder()
                .isDel(CommonStatusEnum.EFFECTIVE.getCode())
                .methodType(0).proRange(PromotionalEnum.PRO2.getKey())
                .promotionType(0)
                .promotionalUid(promotionActivity.getUid())
                .build());

        var shoppingCarProducts = salesRequest.getProducts();

        if (promotionProducts.isEmpty()) {//没有限定产品--判断是否满足金额条件

            boolean matchRes;
            if (promotionActivity.getTotal().equals(0)) {
                //总金额条件
                matchRes = comparisonAmount(promotionActivity, shoppingCarProducts);
            } else if (promotionActivity.getTotal().equals(1)) {
                //总数量条件
                matchRes = comparisonCount(promotionActivity, shoppingCarProducts);
            } else {
                log.error("未知条件类型,type={}", promotionActivity.getTotal());
                throw new BizException("未知条件类型");
            }

            //不符合的就排除掉了 不会走后面逻辑
            if (!matchRes)
                return false;

            Predicate<SalesProductRequest> filterLogic = (e) -> true;
            //确认下整单条件有限定条件时(总金额/总数量)购物车里要排除的商品，确定好后设置给前端
            var excludeProducts = this.confirmWholeActivityProducts(promotionActivity, shoppingCarProducts, filterLogic);
            promotionActivity.setMap(excludeProducts);

        } else {

            //计算最大匹配次数并将购物车里符合条件的商品排除掉
            //应选择组合后能大于等于总金额且最接近总金额限制的产品
            int inputValues = Integer.parseInt(promotionActivity.inputValues);
            int calculateInputValues;

            //购物车里筛选出购买条件的商品逻辑
            Predicate<SalesProductRequest> filterLogic = e -> promotionProducts.stream().anyMatch(limitProduct -> limitProduct.specificProductId.equals(e.getProId()));
            if (promotionActivity.getTotal() == 0) {//总金额

                calculateInputValues = shoppingCarProducts.stream().filter(filterLogic).mapToInt(e -> {
                    //单价 * 数量
                    var price = e.confirmProductPrice();
                    var num = Integer.parseInt(e.getProCount());
                    return price * num;
                }).sum();

            } else if (promotionActivity.getTotal() == 1) {//总数量
                calculateInputValues = shoppingCarProducts.stream().filter(filterLogic).mapToInt(e -> Integer.parseInt(e.getProCount())).sum();
            } else {
                //既不是总金额又不是总数,直接不满足
                log.error("未知条件类型,type={}", promotionActivity.getTotal());
                throw new BizException("未知条件类型");
            }

            boolean matchSuccess = calculateInputValues >= inputValues;//匹配结果
            if (!matchSuccess) {
                return false;//活动未匹配上直接返回
            }

            //限定数量的最大匹配次数(总金额的在后面(confirmWholeActivityProducts方法)会覆盖设置)
            int maxMatchCount = calculateInputValues / inputValues;//计算出来的最大匹配次数
            int matchingCountLimit = promotionActivity.getMatchingCount();//最大匹配次数限制
            promotionActivity.setCount(Math.min(maxMatchCount, matchingCountLimit));//最终最大匹配次数设置

            //确认下整单条件有限定条件时(总金额/总数量)购物车里要排除的商品，确定好后设置给前端
            var excludeProducts = this.confirmWholeActivityProducts(promotionActivity, shoppingCarProducts, filterLogic);
            promotionActivity.setMap(excludeProducts);

        }
        return true;
    }

    /**
     * 确认下整单条件有限定条件时(总金额/总数量)购物车里要排除的商品
     *
     * @param promotionActivity 有限定条件的非整单活动
     * @param shoppingCar       购物车里的商品
     * @param filterLogic       购物车里筛选出限定商品逻辑
     * @return 被排除出来的商品映射
     */
    private Map<String, ActivityProductResponse> confirmWholeActivityProducts(PromotionActivity promotionActivity,
                                                                              List<SalesProductRequest> shoppingCar,
                                                                              Predicate<SalesProductRequest> filterLogic) {

        //特殊情形 如果是整单优惠 那么有限定产品的情况下也要将整个购物车排除掉
        /*var isWholeDiscount = promotionActivity.getRewardType().intValue() == PromotionalEnum.JIANGLI7.getKey().intValue();
        if (isWholeDiscount) {
            return shoppingCar.stream()
                    .map(e -> this.convert2ActivityProductResponse(Map.of(e.getProId(), Long.parseLong(e.getProCount()))).apply(e))//整单优惠
                    .collect(toMap(ActivityProductResponse::getProBarCode, Function.identity(), (e1, e2) -> e1));
        }*/


        //将购物车里带有多个数量的产品集合平铺成只带有一个数量的产品集合,最后再按产品的零售下价格拍下下序：->为的是方便按顺序从购物车里挑出可以满足过滤条件(产品单价和数量)的产品
        var flatProduct = shoppingCar.stream()
                .filter(filterLogic)
                .flatMap(e -> IntStream.rangeClosed(1, Integer.parseInt(e.getProCount())).mapToObj(f -> {
                    var product = new SalesProductRequest();
                    BeanUtils.copyProperties(e, product);
                    product.setProCount("1");
                    return product;
                }))
                .sorted(comparing(SalesProductRequest::confirmProductPrice).reversed().thenComparing(SalesProductRequest::getProId))//按产品单价倒序和产品条码正序的排序
                .collect(toList());

        //因为总数量较简单先处理
        if (promotionActivity.total == 1) {
            //单次排除数量 * 最大匹配次数 = 排除总数量
            var totalProductsNum = Integer.parseInt(promotionActivity.inputValues) * promotionActivity.getCount();
            var proIdAndCountMap = flatProduct.stream().limit(totalProductsNum).collect(groupingBy(SalesProductRequest::getProId, counting()));

            return shoppingCar.stream()
                    .filter(e -> proIdAndCountMap.get(e.getProId()) != null)
                    .map(this.convert2ActivityProductResponse(proIdAndCountMap))//产品数量
                    .collect(toMap(ActivityProductResponse::getProBarCode, Function.identity(), (e1, e2) -> e1));
        }

        var activityTotalAmt = Integer.parseInt(promotionActivity.inputValues) * promotionActivity.getCount();
        //商品单价平铺后的集合
        var flatProductPrices = flatProduct.stream().map(SalesProductRequest::confirmProductPrice).collect(toList());
        return this.getExcludeProduct(activityTotalAmt, flatProduct, flatProductPrices);

    }

    /**
     * @param activityTotalAmt 活动配置总金额
     * @param flatProduct      平铺后的产品集合
     * @param productPrices    平铺后只有的产品价格集合
     * @return 最终确定的商品
     */
    private Map<String, ActivityProductResponse> getExcludeProduct(Integer activityTotalAmt,
                                                                   List<SalesProductRequest> flatProduct,
                                                                   List<Integer> productPrices) {
        //case1 单品价格直接大于或等于总金额,找一个元素就行
        boolean existPriceMoreThan = productPrices.stream().anyMatch(e -> e >= activityTotalAmt);
        if (existPriceMoreThan) {
            //存在单品价格大于总金额的情形,找等于或最接近总金额的单品就行
            return flatProduct.stream()
                    .filter(e -> e.confirmProductPrice() >= activityTotalAmt)//找出单价大于总金额的产品
                    .sorted(comparing(SalesProductRequest::confirmProductPrice))//按产品零售价排序
                    .limit(1)
                    .map(e -> convert2ActivityProductResponse(Map.of(e.getProId(), 1L)).apply(e))//将购物车的对象转换为最终收集对象
                    .collect(toMap(ActivityProductResponse::getProBarCode, Function.identity(), (e1, e2) -> e1));//返回了
        }

        //case2 单品价格直接小于总金额,产品金额累加未达到总金额时按顺序依次取值,当超过总金额时,取剩余商品中金额最小的元素
        AtomicInteger sumAmt = new AtomicInteger(0);
        var lessThenProducts = flatProduct.stream()
                .peek(e -> sumAmt.set(sumAmt.get() + e.confirmProductPrice()))
                .takeWhile(e -> sumAmt.get() <= activityTotalAmt)
                .collect(toList());
        int calculateAmt = lessThenProducts.stream().mapToInt(SalesProductRequest::confirmProductPrice).sum();

        //如果商品按顺序相加小于总金额的逻辑(相加刚刚好的直接就不用再选一个了)
        if (calculateAmt < activityTotalAmt) {
            var lastProduct = flatProduct.stream()
                    .skip(lessThenProducts.size())//从后面开始找
                    .sorted(comparing(SalesProductRequest::confirmProductPrice))//按差额正序排
                    .filter(e -> e.confirmProductPrice() > (activityTotalAmt - calculateAmt))//找大于金额差的所有
                    .collect(toList()).get(0);
            lessThenProducts.add(lastProduct);
        }

        //确定的商品转化后直接就返回了
        Map<String, Long> proIdAndCountMap = lessThenProducts.stream().collect(groupingBy(SalesProductRequest::getProId, counting()));
        return lessThenProducts.stream()
                .map(convert2ActivityProductResponse(proIdAndCountMap))//将购物车的对象转换为最终收集对象
                .collect(toMap(ActivityProductResponse::getProBarCode, Function.identity(), (e1, e2) -> e1));//返回了
    }

    /**
     * 产品价值低于临界值时排除购物车产品的逻辑
     *
     * @param activityTotalAmt 活动配置总金额
     * @param flatProduct      平铺后的产品集合
     * @param productPrices    平铺后只有的产品价格集合
     * @param shoppingCar      购物车里商品
     * @return 最终确定的商品
     */
    private Map<String, ActivityProductResponse> theLogicOfExcludeShoppingCarProductsWhenProductLessThenCriticalValue(Integer activityTotalAmt,
                                                                                                                      List<SalesProductRequest> flatProduct,
                                                                                                                      List<Integer> productPrices,
                                                                                                                      List<SalesProductRequest> shoppingCar) {
        //全组合后所有的情形
        List<List<Integer>> allConditionList = FullCombinationUtil.arrangeSelect(productPrices);
        //每种组合加起来的组合总金额
        Function<List<Integer>, Integer> sumAmt = (e) -> e.stream().reduce(Integer::sum).orElse(0);

        TreeMap<Integer, List<List<Integer>>> finalSortedPriceCombine = allConditionList.parallelStream()
                .filter(e -> sumAmt.apply(e) >= activityTotalAmt)//取出组合中总金额大于活动金额的组合
                .map(e -> e.stream().sorted(comparing(Integer::intValue).reversed()).collect(toList()))//对每种组合内部的产品按价格从高到低进行排序
                .sorted(comparingInt(List::size))//对每种组合之间再进行排序,组合内包含产品单价越高的产品越多的排前面
                .distinct()//对每种组合内部产品相同的组合去重只保留一个
                .collect(groupingBy(e -> Math.abs(sumAmt.apply(e) - activityTotalAmt), TreeMap::new, toList()));//按每种组合内部产品价格之和与总金额的差值的绝对值进行分组,对分组的结果用TreeMap进行排序,排序的结果用List进行收集起来

        //最终确定下来满足条件(最接近活动总金额)的价格集合
        //因为按组合与活动总金额的差值的绝对值进行分组,那么Map里排在前面的的key值就比后面的小,取差值最小的组合(产品集合里金额累加起来最接近活动金额)
        // 然后从差值最小的组合集合中取第一个组合[因为在分组之前就已经排好序了上面sorted()方法]就是满足需求条件的最终组合
        Integer finalKey = finalSortedPriceCombine.keySet().iterator().next();
        List<Integer> finalPriceComb = finalSortedPriceCombine.get(finalKey).get(0);

        //每种金额对应的数量
        Map<Integer, Long> priceAndCountMap = finalPriceComb.stream().collect(groupingBy(Function.identity(), counting()));

        //根据最终金额从购物车里确定产品以及产品的数量
        Map<String, Long> proIdAndCountMap = priceAndCountMap.entrySet().stream().flatMap(entry -> {
            Integer price = entry.getKey();
            Long priceCount = entry.getValue();
            //拿金额去购物车里找出产品,再找出满足该金额产品数量
            return flatProduct.stream().filter(e -> e.confirmProductPrice() == price).limit(priceCount);
        }).collect(groupingBy(SalesProductRequest::getProId, counting()));//最后把找出的产品按产品ID分组并得到该产品的个数

        return shoppingCar.stream()
                .filter(e -> proIdAndCountMap.get(e.getProId()) != null)
                .map(convert2ActivityProductResponse(proIdAndCountMap))
                .collect(toMap(ActivityProductResponse::getProBarCode, Function.identity(), (e1, e2) -> e1));
    }


    private Function<SalesProductRequest, ActivityProductResponse> convert2ActivityProductResponse(Map<String, Long> proIdAndCountMap) {
        return e -> {
            ActivityProductResponse response = new ActivityProductResponse();
            response.setProName(e.getName());
            response.setNormalPrice(e.getProPrice());
            response.setMemberPrice(e.getMemberPrice().toString());
            response.setProBarCode(e.getProId());
            response.setGoodsBarCode(e.getProCode());
            response.setCustomTotal(1);
            response.setCount(1);
            response.setTotal(proIdAndCountMap.get(e.getProId()).intValue());
            return response;
        };
    }


    /**
     * 判断是否满足分类和商品的要求
     */
    private Boolean comparisonProcuct(PromotionActivity promotionActivity, SalesRequest salesRequest) throws Exception {
        List<PromotionProduct> promotionProducts = salesOrderService.selectProduct(promotionActivity.getUid(), null, 0, 0);
        //分类丶指定商品筛选
        return checkClassification(promotionProducts, salesRequest) && limitPro(promotionProducts, salesRequest);
    }

    /**
     * 判断是否满足分类要求(满足  返回true  不满足 返回false)
     */
    private Boolean checkClassification(List<PromotionProduct> promotionProducts, SalesRequest salesRequest) throws Exception {
        //限定产品填充
        Map<String, PromotionProduct> map = fillMap(promotionProducts, PromotionalEnum.PRO6.getKey());
        if (map.isEmpty()) {
            return true;
        }
        //填充购买商品分类
        Map<Serializable, SalesProductRequest> data = salesOrderService.fillClassData(salesRequest);
        return compareProduct(map, data);
    }

    /**
     * 判断是否满足指定商品要求(满足  返回true  不满足 返回false)
     */
    private Boolean limitPro(List<PromotionProduct> promotionProducts, SalesRequest salesRequest) throws Exception {
        //限定产品填充
        Map<String, PromotionProduct> map = fillMap(promotionProducts, PromotionalEnum.PRO2.getKey());
        if (map.isEmpty()) {
            return true;
        }
        //购买商品填充
        Map<Serializable, SalesProductRequest> data = salesOrderService.fillData(salesRequest);
        return compareProduct(map, data);
    }

    /**
     * 商品分类/指定商品填充
     */
    private Map<String, PromotionProduct> fillMap(List<PromotionProduct> promotionProducts, Integer type) {
        Map<String, PromotionProduct> map = new HashMap<>();
        for (PromotionProduct promotionProduct : promotionProducts) {
            if (promotionProduct.getProRange().equals(type)) {
                map.put(promotionProduct.getSpecificProductId(), promotionProduct);
            }
        }
        return map;
    }

    /**
     * 限定商品与购买商品进行比较
     */
    private Boolean compareProduct(Map<String, PromotionProduct> map, Map<?, SalesProductRequest> data) {
        for (Map.Entry<String, PromotionProduct> idSets : map.entrySet()) {
            SalesProductRequest product = data.get(idSets.getKey());
            if (product == null) {
                return false;
            }
        }
        return true;
    }

    /**
     * 判断购买 金额 是否满足(满足  返回true  不满足 返回false)
     */
    private Boolean comparisonAmount(PromotionActivity promotionActivity, List<SalesProductRequest> products) {
        String inputValues = promotionActivity.getInputValues();
        BigDecimal bigDecimalInputValues = new BigDecimal(inputValues);
        //计算购买的商品的价格
        BigDecimal result = null;
        for (SalesProductRequest product : products) {
            String proCount = product.getProCount();
            String proPrice = Integer.toString(product.confirmProductPrice());
            BigDecimal decimalCount = new BigDecimal(proCount);
            BigDecimal decimalProPrice = new BigDecimal(proPrice);
            if (result == null) {
                result = decimalCount.multiply(decimalProPrice);
            } else {
                result = result.add(decimalCount.multiply(decimalProPrice));
            }
        }
        if (result.compareTo(bigDecimalInputValues) > -1) {
            //计算匹配次数
            BigDecimal count = result.divide(bigDecimalInputValues, 0, RoundingMode.DOWN);
            promotionActivity.setCount(promotionActivity.getMatchingCount() >= count.intValue() ? count.intValue() : promotionActivity.getMatchingCount());
            return true;
        }
        return false;
    }

    /**
     * 判断购买数量是否满足  (满足  返回true  不满足 返回false)
     */

    private Boolean comparisonCount(PromotionActivity promotionActivity, List<SalesProductRequest> products) {
        String inputValues = promotionActivity.getInputValues();
        //计算购买的商品的总数量
        int count = 0;
        for (SalesProductRequest product : products) {
            count = count + Integer.parseInt(product.getProCount());
        }
        if (count >= Integer.parseInt(inputValues)) {
            Integer sum = count / Integer.parseInt(inputValues);
            Integer matchingCount = promotionActivity.getMatchingCount();
            promotionActivity.setCount(matchingCount >= sum ? sum : matchingCount);
            return true;
        }
        return false;
    }

}
