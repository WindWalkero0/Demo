package com.ruihe.app.service.activity;


import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.mapper.RewardCloudMapper;
import com.ruihe.common.dao.bean.promotion.PromotionProduct;
import com.ruihe.common.dao.bean.promotion.RewardCloud;
import com.ruihe.common.pojo.dto.PromotionActivityDTO;
import com.ruihe.common.pojo.dto.RewardCloudDTO;
import com.ruihe.common.dao.mapper.PromotionProductMapper;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.*;

@Service
public class PromotionActivityService {

    private final RewardCloudMapper rewardCloudMapper;
    private final PromotionProductMapper promotionProductMapper;

    public PromotionActivityService(RewardCloudMapper rewardCloudMapper, PromotionProductMapper promotionProductMapper) {
        this.rewardCloudMapper = rewardCloudMapper;
        this.promotionProductMapper = promotionProductMapper;
    }

    /**
     * 活动排序优先级(同当前系统逻辑)
     * 1)活动柜台：特定柜台活动优先级高于全部柜台；
     * 2)购买条件：非整单>整单>无条件
     * 3)活动开始时间降序
     */

    /**
     * 获取促销活动整单条件购买限定商品集合
     *
     * @param promotions 促销活动ID集合
     * @return 促销活动购买条件集合
     * Map的 key1：促销活动Id
     * Map的 key2：每个促销活动对应的购买条件的组合索引 索引值：total-inputValues (限定条件类型(总金额 or 总数量) + 条件类型值(大于等于 X 元or件))
     * Map的 value：每个促销活动组合索引对应的具体限定产品集合
     */
    public Map<String, List<PromotionProduct>> queryWholeBuyConditionProduct(List<PromotionActivityDTO> promotions) {

        if (CollectionUtils.isEmpty(promotions)) {
            return Collections.emptyMap();
        }

        //查询出整单的限定商品
        var where = Wrappers.<PromotionProduct>lambdaQuery()
                .in(PromotionProduct::getPromotionalUid, promotions.stream().map(PromotionActivityDTO::getUid).collect(toList()));
        var promotionProducts = promotionProductMapper.selectList(where);

        //如果限定商品为空
        if (CollectionUtils.isEmpty(promotionProducts)) {
            return promotions.stream()
                    .collect(groupingBy(PromotionActivityDTO::getUid, mapping(e -> null, toList())));
        }
        //如果限定商品不为空
        var promotionProductMap = promotionProducts.stream().collect(groupingBy(PromotionProduct::getPromotionalUid));
        return promotions.stream()
                .collect(groupingBy(PromotionActivityDTO::getUid,
                        flatMapping(e -> promotionProductMap.getOrDefault(e.uid, Collections.emptyList()).stream(), toList())));

    }

    /**
     * 获取促销活动非整单条件购买商品集合
     *
     * @param promotionIds 促销活动ID集合
     * @return 促销活动购买条件集合
     * <br>Map的 key1：促销活动Id</br>
     * <br>Map的 key2：每个促销活动对应的购买条件的组合索引 索引值：cloudType-conditionType-count (组合条件 + 条件类型 + 每种条件类型中产品集合的序号)</br>
     * <br>Map的 value：每个促销活动组合索引对应的具体产品集合</br>
     */
    public Map<String, Map<String, List<RewardCloudDTO>>> queryNoneWholeBuyConditionProduct(List<String> promotionIds) {

        if (CollectionUtils.isEmpty(promotionIds)) {
            return Collections.emptyMap();
        }

        var rewardClouds = rewardCloudMapper.findAllNoneWholeBuyConditionProducts(promotionIds);//非整单购买条件商品
        return rewardClouds.stream()
                .filter(e -> e.cloudMethod.equals(0)) //购买
                .collect(groupingBy(RewardCloudDTO::getPromotionalUid,
                        groupingBy(e -> String.format("%s-%s-%s", e.cloudType, e.conditionType, e.count), LinkedHashMap::new, toList())));
    }

    /**
     * 获取促销活动非整单条件奖励商品集合
     *
     * @param promotionIds 促销活动ID集合
     * @return 促销活动购买条件集合
     * Map的 key：促销活动Id
     * Map的 value：促销活动组合奖励和选择奖励
     */
    public Map<String, Pair<List<RewardCloud>, List<RewardCloud>>> equeryNoneWholeRewardProduct(List<String> promotionIds) {

        if (CollectionUtils.isEmpty(promotionIds)) {
            return Collections.emptyMap();
        }
        var rewardClouds = this.findAllActivityBuyAndRewardProduct(promotionIds);//非整单奖励
        return rewardClouds.stream()
                .filter(e -> e.cloudMethod.equals(1)) //奖励
                .collect(groupingBy(RewardCloud::getPromotionalUid))//活动奖励按活动Id分组后对活动奖励进行再次分类
                .entrySet().stream()
                .collect(toMap(
                        Map.Entry::getKey,
                        map -> sortNoneWholeRewardProduct(map.getValue())
                ));
    }


    /**
     * 将单个活动奖励封装成一对固定组合+选择组合
     *
     * @param rewardClouds 单个非整单活动的全部奖励数据
     * @return 一对奖励数据（固定奖励+组合奖励）
     */
    private static Pair<List<RewardCloud>, List<RewardCloud>> sortNoneWholeRewardProduct(List<RewardCloud> rewardClouds) {
        var fixedAndSelected = rewardClouds.stream()
                .filter(e -> e.cloudMethod == 1)
                .collect(partitioningBy(e -> e.cloudType == 0));
        return Pair.of(fixedAndSelected.get(true), fixedAndSelected.get(false));
    }

    /**
     * 获取促销活动非整单条件购买和奖励商品
     *
     * @param promotionIds 促销活动ID集合
     * @return 促销活动购买和奖励商品集合
     */
    private List<RewardCloud> findAllActivityBuyAndRewardProduct(List<String> promotionIds) {

        var where = Wrappers.<RewardCloud>lambdaQuery()
                .in(RewardCloud::getPromotionalUid, promotionIds);
        return rewardCloudMapper.selectList(where);
    }


}
