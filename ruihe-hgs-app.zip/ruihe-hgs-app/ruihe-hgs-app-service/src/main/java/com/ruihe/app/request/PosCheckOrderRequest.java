package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * 正常下单操作
 * @author fly
 */
@ApiModel(value = "PosCheckOrderRequest", description = "销售-匹配活动实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosCheckOrderRequest implements Serializable {

    @NotNull(message = "柜台id不能为空")
    @ApiModelProperty("【必填】柜台id")
    private String counterId;

    @ApiModelProperty("【交易类型是销售、空退业务必填】所购商品列表")
    private List<OrderItemRequest> orderItemList;

    /**
     * 购买商品信息
     */
    @ApiModel(value = "OrderItemRequest", description = "销售-商品信息实体")
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OrderItemRequest implements Serializable {
        @ApiModelProperty(value = "【必填】产品条码-对外标准", required = true)
        private String prdBarCode;

        @ApiModelProperty(value = "【必填】商品条码-私有编码", required = true)
        private String goodsBarCode;

        @ApiModelProperty(value = "【必填】购买数量", required = true)
        private Integer purQty;

        @ApiModelProperty(value = "【必填】商品类型  0 兑换活动商品 1 优惠券活动商品 2促销奖励商品 3 正常商品,  4发券活动商品", required = true)
        private Integer proType;

        @ApiModelProperty("商品最终销售价格")
        private BigDecimal resultPrice;

        @ApiModelProperty("商品名称")
        private String prdName;

        @ApiModelProperty("虚拟商品针对优惠券:优惠券id")
        private String couponId;

        @ApiModelProperty("虚拟商品针对优惠券:验证码")
        private String coupon;

        @ApiModelProperty(value = "是否虚拟商品,1虚拟商品，0实物商品--前端不传 java用来自己判断的", hidden = true)
        private Integer isVirtual;

        @ApiModelProperty("关联的活动id-包括促销(真实的活动商品才会用到)")
        private String activityId;

        @ApiModelProperty("关联的活动名称(真实的活动商品才会用到)")
        private String activityName;

        @ApiModelProperty("虚拟商品总价(只有虚拟商品才有)")
        private BigDecimal totalMoney;

        @ApiModelProperty("是否是购物车商品:0购物车(条件商品);1奖励商品;2兼容之前的值")
        private Integer discernType;
    }
}
