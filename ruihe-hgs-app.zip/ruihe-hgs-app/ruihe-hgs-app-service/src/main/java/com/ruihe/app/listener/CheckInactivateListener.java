package com.ruihe.app.listener;

import com.ruihe.app.event.CheckInactivateEvent;
import com.ruihe.app.service.wx.InActivateChecker;
import com.ruihe.common.constant.CommonConstant;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;


/**
 * 领卡后当天未激活的，给这些用户发送微信消息
 * 当天晚上9点钟发一次
 *
 * @author liangyuan
 * @date 2021年1月20日14:10:56
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CheckInactivateListener {
    private final InActivateChecker checker;

    @EventListener
    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    public void onApplicationEvent(CheckInactivateEvent event) {
        try {
            checker.checkDailyInActivateMember();
        } catch (Exception e) {
            log.error("给未激活用户发送微信模板消息失败,e={}", e);
        }
    }
}
