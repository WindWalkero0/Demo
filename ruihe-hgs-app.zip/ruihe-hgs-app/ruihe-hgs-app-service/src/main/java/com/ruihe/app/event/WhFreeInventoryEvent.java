package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 自由盘点审核通过事件
 *
 * @author William
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class WhFreeInventoryEvent extends ApplicationEvent {
    /**
     * 单号
     */
    private String orderNo;

    public WhFreeInventoryEvent(Object source, String orderNo) {
        super(source);
        this.orderNo = orderNo;
    }
}
