package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class StarResult {
    private String name;
    private String similarity;
    private String starPath;
}
