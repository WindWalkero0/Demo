package com.ruihe.app.service.material;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.material.MaterialKeywordsMapper;
import com.ruihe.app.mapper.material.MaterialMapper;
import com.ruihe.app.po.material.MaterialKeywordsPo;
import com.ruihe.app.po.material.MaterialPo;
import com.ruihe.app.response.material.*;
import com.ruihe.app.vo.material.MaterialKeywordsVo;
import com.ruihe.app.vo.material.MaterialVo;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import java.util.List;
import java.net.URL;

/**
 * 导购助手-材料服务
 *
 * @author qubin
 * @date 2021年07月05日 11:16
 */
@Slf4j
@Service
public class MaterialService {

    @Autowired
    private MaterialMapper materialMapper;

    @Autowired
    private MaterialKeywordsMapper materialKeywordsMapper;

    /**
     * 根据关键字搜索
     *
     * @param keyword
     * @return com.ruihe.common.response.Response
     * @author qubin
     * @date 2021/7/5 13:35
     */
    @DS(DBConst.SLAVE)
    public Response selectByKeywords(String keyword) {
        List<MaterialPo> dataList = materialMapper.selectList(Wrappers.<MaterialPo>lambdaQuery()
                .like(MaterialPo::getTag, keyword)
                .eq(MaterialPo::getStatus, 1)
                .orderByAsc(MaterialPo::getId));
        if (dataList == null || dataList.size() == 0) {
            return Response.success();
        }
        Set<MaterialProjectResponse> projectResponseList = new HashSet<>();
        List<MaterialLevelResponse> picList = new ArrayList<>();
        dataList.forEach(materialPo -> {
            //项目列表
            projectResponseList.add(MaterialProjectResponse.builder()
                    .projectId(materialPo.getProjectId())
                    .projectName(materialPo.getProjectName())
                    .build());
            //图片汇总
            picList.add(MaterialLevelResponse.builder()
                    .linkUrl(materialPo.getLinkUrl())
                    .id(materialPo.getId())
                    .projectName(materialPo.getProjectName())
                    .projectId(materialPo.getProjectId())
                    .picMemo(materialPo.getPicMemo())
                    .picUrls(materialPo.getPicUrls() == null ? new ArrayList<>() : Arrays.asList(materialPo.getPicUrls().split(",")))
                    .build());
        });
        MaterialPicDetailResponse materialPicDetailResponse = MaterialPicDetailResponse.builder()
                .picList(picList)
                .projectResponseList(new ArrayList<>(projectResponseList))
                .build();
        //排序
        materialPicDetailResponse.getPicList().sort(Comparator.comparingInt(MaterialLevelResponse::getId));
        materialPicDetailResponse.getProjectResponseList().sort(Comparator.comparingInt(MaterialProjectResponse::getProjectId));
        return Response.success(materialPicDetailResponse);
    }

    /**
     * 查询全部有效的
     *
     * @return java.util.List<com.ruihe.app.vo.material.MaterialVo>
     * @author qubin
     * @date 2021/7/5 13:42
     */
    @DS(DBConst.SLAVE)
    private List<MaterialVo> selectAll() {
        List<MaterialPo> dataList = materialMapper.selectList(Wrappers.<MaterialPo>lambdaQuery()
                .eq(MaterialPo::getStatus, 1)
                .orderByAsc(MaterialPo::getId));
        return ObjectUtils.toList(dataList, MaterialVo.class);
    }

    /**
     * 查询项目与二级
     *
     * @return com.ruihe.common.response.Response
     * @author qubin
     * @date 2021/7/5 14:23
     */
    @DS(DBConst.SLAVE)
    public Response selectProject() {
        List<MaterialVo> dataList = this.selectAll();
        if (dataList == null || dataList.size() == 0) {
            return Response.success();
        }
        Set<MaterialProjectResponse> projectResponses = new HashSet<>();
        Map<Integer, Set<MaterialProjectCategoryResponse>> categoryResponseMap = new HashMap<>();
        dataList.forEach(materialVo -> {
            //项目列表
            MaterialProjectResponse projectResponse = MaterialProjectResponse.builder()
                    .projectId(materialVo.getProjectId())
                    .projectName(materialVo.getProjectName())
                    .build();
            projectResponses.add(projectResponse);

            if (categoryResponseMap.containsKey(materialVo.getProjectId())) {
                Set<MaterialProjectCategoryResponse> categoryResponseList = categoryResponseMap.get(materialVo.getProjectId());
                categoryResponseList.add(MaterialProjectCategoryResponse.builder()
                        .coverUrl(materialVo.getCoverUrl())
                        .categoryName(materialVo.getCategoryName())
                        .categoryId(materialVo.getCategoryId())
                        .projectId(materialVo.getProjectId())
                        .projectName(materialVo.getProjectName())
                        .build());
                categoryResponseMap.put(materialVo.getProjectId(), categoryResponseList);
            } else {
                Set<MaterialProjectCategoryResponse> categoryResponseList = new HashSet<>();
                categoryResponseList.add(MaterialProjectCategoryResponse.builder()
                        .coverUrl(materialVo.getCoverUrl())
                        .categoryName(materialVo.getCategoryName())
                        .categoryId(materialVo.getCategoryId())
                        .projectId(materialVo.getProjectId())
                        .projectName(materialVo.getProjectName())
                        .build());
                categoryResponseMap.put(materialVo.getProjectId(), categoryResponseList);
            }
        });
        MaterialProjectDetailResponse detailResponse = new MaterialProjectDetailResponse();
        detailResponse.setCategoryResponseMap(categoryResponseMap);

        detailResponse.setProjectResponseList(new ArrayList<>(projectResponses));
        detailResponse.getProjectResponseList().sort(Comparator.comparingInt(MaterialProjectResponse::getProjectId));
        return Response.success(detailResponse);
    }

    /**
     * 根据等级id查询三级或详情
     *
     * @param categoryId
     * @return com.ruihe.common.response.Response
     * @author qubin
     * @date 2021/7/5 14:24
     */
    @DS(DBConst.SLAVE)
    public Response selectByCategoryId(Integer categoryId) {
        LambdaQueryWrapper<MaterialPo> queryWrapper = Wrappers.<MaterialPo>lambdaQuery()
                .eq(MaterialPo::getStatus, 1).eq(MaterialPo::getCategoryId, categoryId);
        List<MaterialPo> materialPos = materialMapper.selectList(queryWrapper);
        if (materialPos == null || materialPos.size() == 0) {
            return Response.success();
        }
        List<MaterialLevelResponse> levelResponses = new ArrayList<>();
        materialPos.forEach(materialPo -> {
            //没有三级，直接返回图片详情
            levelResponses.add(MaterialLevelResponse.builder()
                    .picMemo(materialPo.getPicMemo())
                    .picUrls(materialPo.getPicUrls() == null ? new ArrayList<>() : Arrays.asList(materialPo.getPicUrls().split(",")))
                    .projectId(materialPo.getProjectId())
                    .projectName(materialPo.getProjectName())
                    .id(materialPo.getId())
                    .linkUrl(materialPo.getLinkUrl())
                    .build());
        });
        return Response.success(levelResponses);
    }

    /**
     * 查询关键词
     *
     * @return com.ruihe.common.response.Response
     * @author qubin
     * @date 2021/7/5 15:44
     */
    @DS(DBConst.SLAVE)
    public Response selectKeywords() {
        List<MaterialKeywordsPo> materialKeywordsPoList = materialKeywordsMapper.selectList(Wrappers.<MaterialKeywordsPo>lambdaQuery()
                .eq(MaterialKeywordsPo::getStatus, 1)
                .orderByDesc(MaterialKeywordsPo::getSort)
                .last("limit 10"));
        return Response.success(ObjectUtils.toList(materialKeywordsPoList, MaterialKeywordsVo.class));
    }

    /**
     * 添加水印
     *
     * @param sourceUrl url地址
     * @param response  响应
     * @param waterMarkContent 水印内容
     * @return com.ruihe.common.response.Response
     * @author qubin
     * @date 2021/7/7 16:36
     */
    public void addWatermark(String sourceUrl, HttpServletResponse response, String waterMarkContent) {
        String fileExt = "jpg";
        Font font = new Font("宋体", Font.BOLD, 20);//水印字体，大小
        Color markContentColor = Color.lightGray;//水印颜色
        int degree = 30;//设置水印文字的旋转角度
        float alpha = 0.5f;//设置水印透明度
        ServletOutputStream outputStream = null;
        URL url = null;
        try {
            outputStream = response.getOutputStream();
            url = new URL(sourceUrl);
            DataInputStream dataInputStream = new DataInputStream(url.openStream());
            Image srcImg = ImageIO.read(dataInputStream);//文件转化为图片
            int srcImgWidth = srcImg.getWidth(null);//获取图片的宽
            int srcImgHeight = srcImg.getHeight(null);//获取图片的高
            // 加水印
            BufferedImage bufImg = new BufferedImage(srcImgWidth, srcImgHeight, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = bufImg.createGraphics();//得到画笔
            g.drawImage(srcImg, 0, 0, srcImgWidth, srcImgHeight, null);
            g.setColor(markContentColor); //设置水印颜色
            g.setFont(font);              //设置字体
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_ATOP, alpha));//设置水印文字透明度
            g.rotate(Math.toRadians(degree));//设置水印旋转
            JLabel label = new JLabel(waterMarkContent);
            FontMetrics metrics = label.getFontMetrics(font);
            int width = metrics.stringWidth(label.getText());//文字水印的宽
                int rowsNumber = srcImgHeight / width;// 图片的高  除以  文字水印的宽    ——> 打印的行数(以文字水印的宽为间隔)
                int columnsNumber = srcImgWidth / width;//图片的宽 除以 文字水印的宽   ——> 每行打印的列数(以文字水印的宽为间隔)
                //防止图片太小而文字水印太长，所以至少打印一次
                if (rowsNumber < 1) {
                    rowsNumber = 1;
                }
                if (columnsNumber < 1) {
                    columnsNumber = 1;
                }
                for (int j = -200; j < rowsNumber; j++) {
                    for (int i = -200; i < columnsNumber; i++) {
                        g.drawString(waterMarkContent, i * width + j * width, -i * width + j * width);//画出水印,并设置水印位置
                    }
            }
            g.dispose();// 释放资源
            // 输出图片
            ImageIO.write(bufImg, fileExt, outputStream);
        } catch (Exception e) {
            log.error("添加水印报错" + "url = " + sourceUrl,e);
            e.printStackTrace();
            e.getMessage();
        } finally {
            try {
               if(outputStream != null){
                   outputStream.flush();
                   outputStream.close();
               }
            } catch (Exception e) {
                e.printStackTrace();
                e.getMessage();
            }
        }
    }


}
