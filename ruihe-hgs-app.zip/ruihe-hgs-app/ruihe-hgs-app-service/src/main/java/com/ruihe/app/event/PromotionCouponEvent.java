package com.ruihe.app.event;

import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.pojo.request.promotion.SalesProductRequest;
import lombok.*;
import org.springframework.context.ApplicationEvent;

import java.util.List;


@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
public class PromotionCouponEvent extends ApplicationEvent {

    /**
     * 会员id
     */
    private MemberInfo memberInfo;

    /**
     * 柜台id
     */
    private String counterId;


    /**
     * 订单编号
     */
    private String orderNo;

    /**
     * 活动类型 0兑换活动  1优惠券  2促销活动 3 无活动  4发券活动
     */
    private Integer activityType;

    /**
     * 初始购买商品集合
     */
    private List<SalesProductRequest> products;


    public PromotionCouponEvent(Object source, MemberInfo memberInfo, Integer activityType, String orderNo, List<SalesProductRequest> products,String counterId) {
        super(source);
        this.memberInfo = memberInfo;
        this.activityType = activityType;
        this.orderNo = orderNo;
        this.products = products;
        this.counterId=counterId;

    }

}
