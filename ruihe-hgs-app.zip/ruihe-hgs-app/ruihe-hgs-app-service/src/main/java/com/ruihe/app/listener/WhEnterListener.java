package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.request.WhConfirmEnterRequest;
import com.ruihe.app.request.WhU8StockOptItemRequest;
import com.ruihe.app.request.WhU8StockOptRequest;
import com.ruihe.app.service.warehouse.StoreInventoryService;
import com.ruihe.common.dao.bean.warehouse.WhEnterItemPo;
import com.ruihe.common.dao.bean.warehouse.WhEnterPo;
import com.ruihe.common.dao.bean.warehouse.WhStockLogPo;
import com.ruihe.common.enums.stock.WhEnterStatusEnum;
import com.ruihe.common.enums.stock.WhStockBizTypeEnum;
import com.ruihe.app.event.WhEnterEvent;
import com.ruihe.app.mapper.warehouse.WhEnterItemMapper;
import com.ruihe.app.mapper.warehouse.WhEnterMapper;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.Retry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 确认入库事件处理
 *
 * @author William
 */
@Slf4j
@Component
public class WhEnterListener {
    @Autowired
    private WhEnterMapper whEnterMapper;

    @Autowired
    private WhEnterItemMapper whEnterItemMapper;

    @Autowired
    private StoreInventoryService storeInventoryService;

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(WhEnterEvent event) {
        try {
            //查询入库申请单主表
            WhEnterPo orderPo = whEnterMapper.selectById(event.getOrderNo());
            //查询入库明细
            List<WhEnterItemPo> itemList = whEnterItemMapper.selectList(Wrappers.<WhEnterItemPo>lambdaQuery()
                    .eq(WhEnterItemPo::getEnterNo, event.getOrderNo()));
            //构建库存log表信息
            List<WhStockLogPo> whStockLogList = this.extractStockLogList(orderPo, itemList);
            //2021-04-28 自动入库， 新开柜台富阳总仓可能会有多个发货单【入库单】，不同的入库单有相同的商品，所以此时初始化t_wh_stock批量插入会抛唯一性异常
            Retry.create()
                    .times(3)
                    .interval(500)
                    .exception(DuplicateKeyException.class)
                    .call(() -> {
                        //事务处理,更新库存
                        storeInventoryService.changeStock(orderPo.getCounterId(), whStockLogList);
                    });
            //通知U8
            WhU8StockOptRequest request = this.extractWhU8StockRequest(orderPo, itemList);
            storeInventoryService.syncStockWithU8(request);
        } catch (Exception e) {
            log.error("确认入库事件处理异常，event{}", JSON.toJSONString(event), e);
        }
    }

    /**
     * 抽取门店扣减库存对象
     *
     * @param orderPo
     * @param itemList
     * @return
     */
    private List<WhStockLogPo> extractStockLogList(WhEnterPo orderPo, List<WhEnterItemPo> itemList) {
        return itemList.stream()
                .map(e ->
                        WhStockLogPo.builder()
                                .counterId(orderPo.getCounterId())
                                .counterName(orderPo.getCounterName())
                                .baCode(orderPo.getBaCode())
                                .baName(orderPo.getBaName())
                                .bizType(WhStockBizTypeEnum.ENTER.getCode())
                                .bizNo(orderPo.getEnterNo())
                                .bizTime(orderPo.getCreateTime())
                                .prdBarCode(e.getPrdBarCode())
                                .prdName(e.getPrdName())
                                .goodsBarCode(e.getGoodsBarCode())
                                .qty(Math.abs(e.getRealQty()))
                                .prdPrice(e.getPrdPrice())
                                .memberPrice(e.getMemberPrice())
                                .bigCatCode(e.getBigCatCode())
                                .bigCatName(e.getBigCatName())
                                .mediumCatCode(e.getMediumCatCode())
                                .mediumCatName(e.getMediumCatName())
                                .smallCatCode(e.getSmallCatCode())
                                .smallCatName(e.getSmallCatName())
                                .build()
                ).collect(Collectors.toList());
    }

    /**
     * 抽取U8库存接口操作
     *
     * @param orderPo
     * @param itemList
     * @return
     */
    private WhU8StockOptRequest extractWhU8StockRequest(WhEnterPo orderPo, List<WhEnterItemPo> itemList) {
        WhU8StockOptRequest request = WhU8StockOptRequest.builder()
                .bizType(WhStockBizTypeEnum.ENTER.getCode())
                .bizNo(orderPo.getEnterNo())
                .bizTime(orderPo.getCreateTime())
                .counterId(orderPo.getCounterId())
                .counterName(orderPo.getCounterName())
                .build();
        List<WhU8StockOptItemRequest> newItemList = itemList.stream().map(e ->
                WhU8StockOptItemRequest.builder()
                        .bizType(WhStockBizTypeEnum.ENTER.getCode())
                        .bizNo(orderPo.getEnterNo())
                        .bizTime(orderPo.getCreateTime())
                        .counterId(orderPo.getCounterId())
                        .counterName(orderPo.getCounterName())
                        .prdBarCode(e.getPrdBarCode())
                        .prdName(e.getPrdName())
                        .goodsBarCode(e.getGoodsBarCode())
                        .qty(Math.abs(e.getRealQty()))
                        .build()
        ).collect(Collectors.toList());
        request.setItemRequestList(newItemList);
        return request;
    }
}
