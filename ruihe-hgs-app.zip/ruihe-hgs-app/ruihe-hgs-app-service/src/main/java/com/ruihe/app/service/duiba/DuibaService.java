package com.ruihe.app.service.duiba;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ruihe.app.service.member.MemberService;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderItemPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderPo;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.enums.integral.IntegralBizTypeEnum;
import com.ruihe.common.enums.integral.IntegralTypeEnum;
import com.ruihe.app.enums.OrderNoPrefixEnum;
import com.ruihe.common.dao.mapper.integral.IntegralAccountMapper;
import com.ruihe.common.dao.mapper.integral.IntegralOrderItemMapper;
import com.ruihe.common.dao.mapper.integral.IntegralOrderMapper;
import com.ruihe.common.duiba.CreditConsumeParams;
import com.ruihe.common.duiba.CreditConsumeResult;
import com.ruihe.common.duiba.CreditNotifyParams;
import com.ruihe.common.duiba.CreditTool;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.app.service.integral.IntegralService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;

@Slf4j
@Service
public class DuibaService {
    @Value("${duiba.appKey}")
    private String appKey;
    @Value("${duiba.appSecret}")
    private String appSecret;
    @Value("${duiba.dbredirect}")
    private String dbredirect;

    @Autowired
    private MemberService memberService;
    @Autowired
    private IntegralService integralService;
    @Autowired
    private IntegralOrderMapper integralOrderMapper;
    @Autowired
    private IntegralOrderItemMapper integralOrderItemMapper;
    @Autowired
    private IntegralAccountMapper integralAccountMapper;

    public Response autoLogin(String openId) {
        if (StringUtils.isBlank(openId)) {
            return Response.errorMsg("openId is empty");
        }

        MemberInfo memberInfo = memberService.selectMemberInfo(MemberInfo.builder().openId(openId).build());
        if (memberInfo == null) {
            return Response.errorMsg("member not found");
        }

        IntegralAccountPo accountPo = integralService.selectIntegralAccount(memberInfo.getMemberId());
        if (accountPo == null) {
            return Response.errorMsg("integral not found");
        }

        CreditTool creditTool = new CreditTool(appKey, appSecret);
        String url = creditTool.buildAutoLoginRequest(memberInfo.getMemberId(), (long) accountPo.getAvlQty(), dbredirect);
        return Response.successDataMsg(url, "");
    }

    /**
     * 扣除积分
     */
    @Transactional
    public String consume(HttpServletRequest request) {
        CreditTool tool = new CreditTool(appKey, appSecret);
        boolean success = false;
        String errorMessage = "";
        String bizId = null;
        long credits = 0L;
        try {
            CreditConsumeParams params = tool.parseCreditConsume(request);
            log.info("consume params " + JSONObject.toJSONString(params));

            String memberId = params.getUid();
            IntegralAccountPo accountPo = integralService.selectIntegralAccount(memberId);
            if (accountPo == null) {
                log.error("积分账户为空 " + memberId);
                throw new RuntimeException("积分账户为空");
            }
            var query = new LambdaQueryWrapper<IntegralOrderPo>().eq(IntegralOrderPo::getBizRelationNo, params.getOrderNum());
            IntegralOrderPo exist = integralOrderMapper.selectOne(query);
            if (exist != null) {
                success = true;
                bizId = exist.getBizNo();
                credits = accountPo.getAvlQty();
                return result(success, bizId, credits, errorMessage).toString();
            }

            LocalDateTime now = LocalDateTime.now();
            IntegralOrderPo order = IntegralOrderPo.builder()
                    .memberId(accountPo.getMemberId())
                    .memberName(accountPo.getMemberName())
                    .memberPhone(accountPo.getMemberPhone())
                    .counterId("兑吧")
                    .counterName("兑吧")
                    .bizType(IntegralBizTypeEnum.INTEGRAL_DUIBA.getCode())
                    .bizNo(IdGenerator.getShorterSerialNo(OrderNoPrefixEnum.DB.getCode()))
                    .bizRelationNo(params.getOrderNum())
                    .bizTime(now)
                    .bizQty(1)
                    //此次兑换实际扣除开发者账户费用，单位为分
                    .bizAmt(BigDecimal.valueOf(params.getActualPrice()).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP))
                    .paidQty(-params.getCredits().intValue())
                    .gainQty(0)
                    .integralQty(-params.getCredits().intValue())
                    .baCode("兑吧积分兑换")
                    .baName("兑吧积分兑换")
                    .createTime(now)
                    .build();
            integralOrderMapper.insert(order);

            String desc = params.getDescription();
            if (desc != null && desc.length() > 60) {
                desc = desc.substring(0, 60);
            }
            IntegralOrderItemPo item = IntegralOrderItemPo.builder()
                    .integralOrderId(order.getIntegralOrderId())
                    .discountAmt(BigDecimal.ZERO)
                    .integralQty(order.getIntegralQty())
                    .counterId(order.getCounterId())
                    .counterName(order.getCounterName())
                    .memberId(order.getMemberId())
                    .memberName(order.getMemberName())
                    .memberPhone(order.getMemberPhone())
                    .bizType(IntegralBizTypeEnum.INTEGRAL_DUIBA.getCode())
                    .bizNo(order.getBizNo())
                    .bizRelationNo(order.getBizRelationNo())
                    .bizTime(order.getBizTime())
                    .bizItemNo(params.getItemCode())
                    .goodsBarCode("")
                    .bizItemDesc(desc)
                    .bizItemAmt(order.getBizAmt())
                    .bizItemQty(1)
                    .integralType(IntegralTypeEnum.INTEGRAL_DUIBA.getCode())
                    .multiple(BigDecimal.ZERO)
                    .createTime(now)
                    .updateTime(now)
                    .build();
            integralOrderItemMapper.insert(item);

            integralAccountMapper.changeBalance(memberId, -params.getCredits().intValue(), 0, null, false, false);

            bizId = order.getBizNo(); //开发者业务订单号，保证唯一不重复
            // getCredits()是根据开发者自身业务，获取的用户最新剩余积分数。
            credits = (long) accountPo.getAvlQty() - params.getCredits().intValue();
            success = true;
        } catch (Exception e) {
            errorMessage = e.getMessage();
            log.error("扣除积分失败 ", e);
        }

        return result(success, bizId, credits, errorMessage).toString();
    }

    private CreditConsumeResult result(boolean success, String bizId, long credits, String msg) {
        CreditConsumeResult ccr = new CreditConsumeResult(success);
        ccr.setBizId(bizId);
        ccr.setErrorMessage(msg);
        ccr.setCredits(credits);
        return ccr;
    }

    /**
     * 兑换结果通知
     */
    public String resultNotify(HttpServletRequest request) {
        /*
         *  兑换订单的结果通知请求的解析方法
         *  当兑换订单成功时，兑吧会发送请求通知开发者，兑换订单的结果为成功或者失败，如果为失败，开发者需要将积分返还给用户
         */
        CreditTool tool = new CreditTool(appKey, appSecret);
        CreditNotifyParams params = null;//利用tool来解析这个请求
        try {
            params = tool.parseCreditNotify(request);
            log.info("resultNotify params " + JSONObject.toJSONString(params));
        } catch (Exception e) {
            log.error("解析参数失败", e);
            return "failed";
        }
        if (params.isSuccess()) {
            return "ok";
        }

        String orderNum = params.getOrderNum();
        var query = new LambdaQueryWrapper<IntegralOrderPo>().eq(IntegralOrderPo::getBizRelationNo, params.getOrderNum());
        IntegralOrderPo exist = integralOrderMapper.selectOne(query);
        if (exist == null) {
            log.error("兑吧订单号查询不到 积分纪录 " + orderNum);
            return "failed";
        }

        var queryItem = new LambdaQueryWrapper<IntegralOrderItemPo>().eq(IntegralOrderItemPo::getBizNo, exist.getBizNo());
        IntegralOrderItemPo existItem = integralOrderItemMapper.selectOne(queryItem);
        if (existItem == null) {
            log.error("兑吧订单明细未找到 " + exist.getBizNo());
            return "failed";
        }

        IntegralAccountPo accountPo = integralService.selectIntegralAccount(exist.getMemberId());
        if (accountPo == null) {
            log.error("积分账户为空 " + exist.getMemberId());
            throw new RuntimeException("积分账户为空");
        }

        LocalDateTime now = LocalDateTime.now();
        IntegralOrderPo order = IntegralOrderPo.builder()
                .memberId(accountPo.getMemberId())
                .memberName(accountPo.getMemberName())
                .memberPhone(accountPo.getMemberPhone())
                .counterId("兑吧")
                .counterName("兑吧")
                .bizType(IntegralBizTypeEnum.INTEGRAL_DUIBA_RET.getCode())
                .bizNo(IdGenerator.getShorterSerialNo(OrderNoPrefixEnum.DBR.getCode()))
                .bizRelationNo(params.getOrderNum())
                .bizTime(now)
                .bizQty(1)
                //此次兑换实际扣除开发者账户费用，单位为分
                .bizAmt(exist.getBizAmt())
                .paidQty(-exist.getPaidQty())
                .gainQty(0)
                .integralQty(-exist.getIntegralQty())
                .baCode("兑吧积分退还")
                .baName("兑吧积分退还")
                .createTime(now)
                .build();
        integralOrderMapper.insert(order);
        IntegralOrderItemPo item = IntegralOrderItemPo.builder()
                .integralOrderId(order.getIntegralOrderId())
                .discountAmt(BigDecimal.ZERO)
                .integralQty(order.getIntegralQty())
                .counterId(order.getCounterId())
                .counterName(order.getCounterName())
                .memberId(order.getMemberId())
                .memberName(order.getMemberName())
                .memberPhone(order.getMemberPhone())
                .bizType(IntegralBizTypeEnum.INTEGRAL_DUIBA_RET.getCode())
                .bizNo(order.getBizNo())
                .bizRelationNo(order.getBizRelationNo())
                .bizTime(order.getBizTime())
                .bizItemNo(existItem.getBizItemNo())
                .goodsBarCode("")
                .bizItemDesc(existItem.getBizItemDesc())
                .bizItemAmt(order.getBizAmt())
                .bizItemQty(1)
                .integralType(IntegralTypeEnum.INTEGRAL_DUIBA_RET.getCode())
                .multiple(BigDecimal.ZERO)
                .createTime(now)
                .updateTime(now)
                .build();
        integralOrderItemMapper.insert(item);

        integralAccountMapper.changeBalance(exist.getMemberId(), -exist.getBizQty(), 0, null, false, false);
        return "ok";
    }
}
