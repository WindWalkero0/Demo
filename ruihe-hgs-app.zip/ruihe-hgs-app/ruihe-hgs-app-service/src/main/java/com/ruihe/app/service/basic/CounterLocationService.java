package com.ruihe.app.service.basic;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Lists;
import com.ruihe.app.mapper.basic.CounterLocationMapper;
import com.ruihe.app.mapper.basic.CounterMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.request.counter.CounterLocationQueryRequest;
import com.ruihe.app.response.CounterLocationInfoVo;
import com.ruihe.app.service.gd.GdService;
import com.ruihe.app.vo.gd.DistanceDetailVo;
import com.ruihe.app.vo.gd.DistanceVo;
import com.ruihe.app.vo.gd.PositionVo;
import com.ruihe.app.vo.gd.RegeoCodeDetailVo;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.CounterLocation;
import com.ruihe.common.dao.bean.member.MemberOrderSearchPo;
import com.ruihe.common.dao.bean.nursing.NursingMemberPO;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.dao.mapper.MemberOrderSearchMapper;
import com.ruihe.common.dao.mapper.NursingMemberMapper;
import com.ruihe.common.enums.nursing.NursingMemberStatusEnum;
import com.ruihe.common.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * @author qubin
 * @date 2021/4/23 9:57
 */
@Slf4j
@Service
@Ella(Describe = "柜台地理位置服务", Author = "qubin")
public class CounterLocationService {

    @Autowired
    private CounterLocationMapper counterLocationMapper;

    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private GdService gdService;

    @Autowired
    private NursingMemberMapper nursingMemberMapper;

    @Autowired
    private MemberOrderSearchMapper memberOrderSearchMapper;

    @Autowired
    private PosOrderMapper posOrderMapper;

    /**
     * 初始化地理位置
     *
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response initLocation() {

        List<CounterLocation> counterLocationList = counterLocationMapper.selectList(Wrappers.<CounterLocation>lambdaQuery()
                .eq(CounterLocation::getStatus, 0));
        if (counterLocationList == null || counterLocationList.isEmpty()) {
            return Response.success();
        }
        for (CounterLocation counterLocation : counterLocationList) {
            if (StringUtils.isNotBlank(counterLocation.getCounterAddress())) {
                Response locationResponse = gdService.getLocation(counterLocation.getCounterAddress());
                //判断高德对接的结果
                if (locationResponse.getCodeL() != 200) {
                    log.error("对接高德报错，counterLocation=" + counterLocation);
                    continue;
                }
                PositionVo positionVo = (PositionVo) locationResponse.getData();
                if (positionVo.getGeocodes() == null || positionVo.getGeocodes().isEmpty()) {
                    log.error("柜台地址有错误，需要确认，counterLocation =" + counterLocation);
                    continue;
                }
                //更新地理位置
                int counterInfoUpdateRow = counterMapper.updateById(CounterInformation.builder()
                        .counterId(counterLocation.getCounterId())
                        .location(positionVo.getGeocodes().get(0).getLocation())
                        .updateTime(LocalDateTime.now())
                        .build());
                if (counterInfoUpdateRow != 1) {
                    log.error("更新地址位置至t_counter_info报错，counterLocation = " + counterLocation);
                    continue;
                }
                //更新状态
                int counterLocationUpdateRow = counterLocationMapper.updateById(CounterLocation.builder()
                        .counterId(counterLocation.getCounterId())
                        .adcode(positionVo.getGeocodes().get(0).getAdCode())
                        .location(positionVo.getGeocodes().get(0).getLocation())
                        .updateTime(LocalDateTime.now())
                        .status(1)
                        .build());
                if (counterLocationUpdateRow != 1) {
                    log.error("更新地址位置至t_counter_location报错，counterLocation = " + counterLocation);
                }
            }
        }
        return Response.success("操作成功");
    }

    /**
     * 默认门店按照以下优先级展示
     * <p>
     * 1.默认已有护理包
     * <p>
     * 2.默认最后一次购买记录
     * <p>
     * 3.默认距离最近
     *
     * @param memberId
     * @return
     */
    public Response getDefaultMemberCounter(String memberId, String memberLocation) {
        //1.默认已有护理包,有多个，则取最近的一个
        List<NursingMemberPO> nursingMemberPOList = nursingMemberMapper.selectList(Wrappers.<NursingMemberPO>lambdaQuery()
                .eq(NursingMemberPO::getMemberId, memberId)
                .eq(NursingMemberPO::getStatus, NursingMemberStatusEnum.YES.getCode()).orderByDesc(NursingMemberPO::getCreateTime));
        if (!nursingMemberPOList.isEmpty()) {
            return Response.success(createLocation(counterMapper.selectOne(Wrappers.<CounterInformation>lambdaQuery()
                    .eq(CounterInformation::getCounterId, nursingMemberPOList.get(0).getCounterId())), null));
        }
        //2.默认最后一次购买记录
        MemberOrderSearchPo memberOrderSearchPo = memberOrderSearchMapper.selectOne(Wrappers.<MemberOrderSearchPo>lambdaQuery()
                .eq(MemberOrderSearchPo::getMemberId, memberId));
        if (memberOrderSearchPo != null) {
            PosOrderPo posOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                    .eq(PosOrderPo::getOrderNo, memberOrderSearchPo.getRecentOrder()));
            return Response.success(createLocation(counterMapper.selectOne(Wrappers.<CounterInformation>lambdaQuery()
                    .eq(CounterInformation::getCounterId, posOrderPo.getCounterId())), null));
        }
        /**
         * 3.默认距离最近
         * 3.1 查询区里面的所有门店
         * 3.2 查询门店距离
         */
        if (StringUtils.isBlank(memberLocation)) {
            return Response.success();
        }

        Response adcodeResonse = gdService.getAdcode(memberLocation);
        if (adcodeResonse.getCodeL() != 200) {
            log.error("对接高德查询逆编码报错，locationList=" + memberLocation + ",adcodeResonse = " + adcodeResonse);
            return Response.success();
        }
        RegeoCodeDetailVo regeoCodeDetailVo = (RegeoCodeDetailVo) adcodeResonse.getData();
        if (regeoCodeDetailVo.getRegeoCode() == null) {
            log.error("查询距离返回报错： regeoCodeDetailVo =" + regeoCodeDetailVo);
            return Response.success();
        }
        String adCode = regeoCodeDetailVo.getRegeoCode().getAddressComponent().getAdcode();
        //查询adcode匹配的门店
        List<CounterLocation> counterLocationList = counterLocationMapper.selectList(Wrappers.<CounterLocation>lambdaQuery()
                .eq(CounterLocation::getAdcode, adCode));
        if (counterLocationList == null || counterLocationList.isEmpty()) {
            return Response.success();
        }
        List<String> counterIdList = new ArrayList<>();
        counterLocationList.forEach(counterLocation -> counterIdList.add(counterLocation.getCounterId()));
        //过滤无效的门店
        List<CounterInformation> counterInformationList = counterMapper.selectList(Wrappers.<CounterInformation>lambdaQuery()
                .eq(CounterInformation::getIsDel, 0)
                .eq(CounterInformation::getCounterType, 10001)
                .in(CounterInformation::getCounterId, counterIdList));
        if (counterInformationList == null || counterInformationList.isEmpty()) {
            return Response.success();
        }
        List<String> locationList = new ArrayList<>();
        List<CounterInformation> newCounterInfoList = new ArrayList<>();
        counterInformationList.forEach(counterInformation -> {
            if (StringUtils.isNotBlank(counterInformation.getLocation())) {
                locationList.add(counterInformation.getLocation());
                newCounterInfoList.add(counterInformation);
            }
        });
        //调用高德获取距离
        Response distanceResponse = gdService.getDistance(locationList, memberLocation);
        //判断高德对接的结果
        if (distanceResponse.getCodeL() != 200) {
            log.error("对接高德查询距离报错，locationList=" + locationList + ",memberId="+memberId + ",memberLocation=" + memberLocation+
                    ",distanceResponse=" + distanceResponse.getMsg());
            return Response.success();
        }
        DistanceDetailVo distanceDetailVo = (DistanceDetailVo) distanceResponse.getData();
        if (distanceDetailVo.getResults() == null || distanceDetailVo.getResults().isEmpty()) {
            log.error("查询距离返回报错： distanceDetailVo =" + distanceDetailVo);
            return Response.success();
        }
        Optional<DistanceVo> distanceOp = distanceDetailVo.getResults().stream().min(Comparator.comparing(DistanceVo::getDistance));
        if (distanceOp.isEmpty()) {
            return Response.success();
        }
        return Response.success(createLocation(newCounterInfoList.get(Integer.parseInt(distanceOp.get().getOrigin_id()) - 1),
                Integer.parseInt(distanceOp.get().getDistance())));
    }

    /**
     * 构造地理位置对象
     *
     * @param counterInformation
     * @param distance
     * @return
     */
    private CounterLocationInfoVo createLocation(CounterInformation counterInformation, Integer distance) {
        return CounterLocationInfoVo.builder()
                .counterAddress(counterInformation.getCounterAddress())
                .counterId(counterInformation.getCounterId())
                .counterName(counterInformation.getCounterName())
                .distance(distance)
                .build();
    }

    /**
     * 查询柜台地理位置列表
     *
     * @param request
     * @return
     */
    public Response queryCounterLocation(CounterLocationQueryRequest request) {
        if (request == null) {
            request = new CounterLocationQueryRequest();
        }
        //查询柜台列表。这里没做个数限制
        List<CounterLocationInfoVo> counterLocationInfoVoList = counterMapper.queryCounterLocation(request);
        if (counterLocationInfoVoList == null || counterLocationInfoVoList.isEmpty()) {
            return Response.errorMsg("没有数据");
        }

        if (StringUtils.isBlank(request.getLocation())) {
            //取结果的前50个返回
            return Response.success(counterLocationInfoVoList.size() > 50 ? counterLocationInfoVoList.subList(0, 50) : counterLocationInfoVoList);
        }

        List<CounterLocationInfoVo> allCounterLocationList = new ArrayList<>();
        List<CounterLocationInfoVo> noLocationCounterInfoList = new ArrayList<>();
        //将柜台进行区分，每个100元素
        List<List<CounterLocationInfoVo>> subList = Lists.partition(counterLocationInfoVoList, 100);

        for (List<CounterLocationInfoVo> list : subList) {
            List<String> locationList = new ArrayList<>();
            List<CounterLocationInfoVo> loactionCounterInfoList = new ArrayList<>();
            list.forEach(counterLocationInfoVo -> {
                if (StringUtils.isNotBlank(counterLocationInfoVo.getLocation())) {
                    locationList.add(counterLocationInfoVo.getLocation());
                    loactionCounterInfoList.add(counterLocationInfoVo);
                } else {
                    noLocationCounterInfoList.add(counterLocationInfoVo);
                }
            });
            //调用高德获取距离
            Response distanceResponse = gdService.getDistance(locationList, request.getLocation());
            //判断高德对接的结果
            if (distanceResponse.getCodeL() != 200) {
                log.error("对接高德查询距离报错，locationList=" + locationList + ", request = " + request + ",distanceResponse = "+ distanceResponse.getMsg());
                continue;
            }
            DistanceDetailVo distanceDetailVo = (DistanceDetailVo) distanceResponse.getData();
            if (distanceDetailVo.getResults() == null || distanceDetailVo.getResults().isEmpty()) {
                log.error("查询距离返回报错： distanceDetailVo =" + distanceDetailVo);
                continue;
            }
            distanceDetailVo.getResults().forEach(distanceVo -> {
                loactionCounterInfoList.get(Integer.parseInt(distanceVo.getOrigin_id()) - 1)
                        .setDistance(Integer.parseInt(distanceVo.getDistance()));
            });
            allCounterLocationList.addAll(loactionCounterInfoList);
        }
        allCounterLocationList.sort(Comparator.comparingInt(CounterLocationInfoVo::getDistance));
        allCounterLocationList.addAll(noLocationCounterInfoList);
        return Response.success(allCounterLocationList.size() > 50 ? allCounterLocationList.subList(0, 50) : allCounterLocationList);
    }
}
