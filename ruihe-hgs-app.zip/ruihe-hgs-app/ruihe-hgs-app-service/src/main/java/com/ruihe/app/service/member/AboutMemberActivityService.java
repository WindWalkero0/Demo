package com.ruihe.app.service.member;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.member.MemberActivityProductMapper;
import com.ruihe.app.mapper.member.MemberActivitySonMapper;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.member.*;
import com.ruihe.common.dao.bean.member.MemberIntegralResult;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.service.CustomService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@Repository
public class AboutMemberActivityService {

    @Autowired
    private CustomService customService;

    @Autowired
    private MemberActivitySonMapper memberActivitySonMapper;

    @Autowired
    private MemberActivityProductMapper memberActivityProductMapper;


    @Ella(Describe = "查询子活动信息", Author = "K")
    public MemberActivity selectMemberActivity(MemberActivity memberActivity) {
        return customService.select(memberActivity);
    }

    @Ella(Describe = "查询子活动信息", Author = "K")
    public MemberActivitySon selectMemberActivitySon(MemberActivitySon memberActivitySon) {
        return customService.select(memberActivitySon);
    }

    @Ella(Describe = "查询子活动信息列表", Author = "K")
    public List<MemberActivitySon> selectMemberActivitySonList(MemberActivitySon memberActivitySon) {
        return customService.selectList(memberActivitySon);
    }

    @Ella(Describe = "查询优惠券商品信息集合", Author = "K")
    public List<MemberActivityProduct> selectMemberActivityProducts(MemberActivityProduct memberActivityProduct) {
        return customService.selectList(memberActivityProduct);
    }

    public List<MemberActivitySon> selectMemberActivitySonList(List<String> activityIds) {
        return memberActivitySonMapper.selectList(Wrappers.<MemberActivitySon>lambdaQuery().in(MemberActivitySon::getActivityId, activityIds).isNotNull(MemberActivitySon::getRestrictType));
    }

    /**
     * 获取包含列表
     *
     * @param activityIds
     * @return
     */
    public List<MemberActivityProduct> selectMemberActivityRestrictsInProducts(List<String> activityIds) {
        if (activityIds == null || activityIds.size() == 0) {
            return null;
        }
        return memberActivityProductMapper.selectMemberActivityRestrictsInProducts(activityIds);
    }

    /**
     * 获取排除列表
     *
     * @param activityIds
     * @return
     */
    public List<MemberActivityProduct> selectMemberActivityRestrictsOutProducts(List<String> activityIds) {
        if (activityIds == null || activityIds.size() == 0) {
            return null;
        }
        return memberActivityProductMapper.selectMemberActivityRestrictsOutProducts(activityIds);
    }


    @DS(DBConst.MASTER)
    @Ella(Describe = "更新优惠券信息", Author = "K")
    public void updateCoupon(MemberCoupon memberCoupon, MemberCoupon memberCouponOther) throws BizException {
        Integer update = customService.update(memberCoupon, memberCouponOther);
        if (update.equals(0)) {
            log.error("更新优惠券信息失败,memberCoupon={},memberCouponOther={}", memberCoupon, memberCouponOther);
            throw new BizException("更新优惠券信息失败");
        }
    }

    @Ella(Describe = "查询优惠券信息", Author = "K")
    public MemberCoupon selectMemberCoupon(MemberCoupon memberCoupon) {
        return customService.select(memberCoupon);
    }

    @DS(DBConst.MASTER)
    @Ella(Describe = "保存优惠券使用情况信息", Author = "K")
    public void saveCouponResult(MemberCouponResult couponResult) throws BizException {
        Integer save = customService.save(couponResult);
        if (save.equals(0)) {
            log.error("保存优惠券使用情况信息失败,couponResult={}", couponResult);
            throw new BizException("保存优惠券使用情况信息失败");
        }
    }

    @DS(DBConst.MASTER)
    @Ella(Describe = "保存优惠券记录信息", Author = "K")
    public void saveCouponLog(MemberCouponLog couponLog) throws BizException {
        Integer save = customService.save(couponLog);
        if (save.equals(0)) {
            log.error("保存优惠券信息失败,couponLog={}", couponLog);
            throw new BizException("保存优惠券信息失败");
        }
    }

    @DS(DBConst.MASTER)
    @Ella(Describe = "保存兑换结果信息", Author = "K")
    public void saveIntegralResult(MemberIntegralResult integralResult) throws BizException {
        Integer save = customService.save(integralResult);
        if (save.equals(0)) {
            log.error("保存兑换结果信息失败,integralResult={}", integralResult);
            throw new BizException("保存兑换结果信息失败");
        }
    }

//    @Ella(Describe = "判断活动地点是否匹配  匹配返回true 不匹配返回false", Author = "K")
//    public Boolean checkPlace(String counterId, MemberActivitySon memberActivitySon) {
//        //查询柜台信息
//        CounterInformation counterInformation = counterService.selectCounterInfo(CounterInformation.builder().counterId(counterId).build());
//
//        if (!memberActivitySon.getActivityPlaceType().equals(ActivityEnum.ACTITY_PLACE_TYPE1)) {//不是全部柜台
//            //查询活动关联的区域信息
//            List<ActivityPlace> activityPlaces = activityService.selectActivityPlaces(ActivityPlace
//                    .builder()
//                    .activityType(0)
//                    .isDel(CommonStatusEnum.EFFECTIVE.getCode())
//                    .activityUid(memberActivitySon.getActivityId())
//                    .build());
//            for (ActivityPlace activityPlace : activityPlaces) {
//                if (memberActivitySon.getActivityPlaceType().equals(ActivityEnum.ACTITY_PLACE_TYPE7.getKey())) {//按区域
//                    if (activityPlace.getRegionCode().equals(counterInformation.getCountyCode())) {
//                        return true;
//                    }
//                }
//                if (memberActivitySon.getActivityPlaceType().equals(ActivityEnum.ACTITY_PLACE_TYPE8.getKey())) {//按区域指定柜台
//                    if (activityPlace.getCounterId().equals(counterInformation.getCounterId())) {
//                        return true;
//                    }
//                }
//            }
//        }
//        if (memberActivitySon.getActivityPlaceType().equals(ActivityEnum.ACTITY_PLACE_TYPE1.getKey())) {//全部柜台
//            return true;
//        }
//        return false;
//    }

//    @Ella(Describe = "判断活动对象是否匹配  匹配返回true 不匹配返回false", Author = "K")
//    public Boolean checkObject(String memberId, MemberActivitySon memberActivitySon) {
//        if (memberActivitySon.getActivityObjectType().equals(ActivityEnum.ACTITY_OBJECT1.getKey())) {//全部会员
//            return true;
//        }
//        if (memberActivitySon.getActivityObjectType().equals(ActivityEnum.ACTITY_OBJECT2.getKey())) {//搜索对象
//            //查询搜索条件
//            MemberSelect memberSelect = activityService.selectMemberSelect(MemberSelect
//                    .builder()
//                    .isDel(CommonStatusEnum.EFFECTIVE.getCode())
//                    .activityType(0)
//                    .activityId(memberActivitySon.getActivityId())
//                    .build());
//            //数据库搜索出来的条件填充到搜索信息
//            commonService.fillMemberSelect(memberSelect);
//            List<MemberInfoRequest> memberInfoRequests = commonService.selectMemberByQuery(memberSelect);
//            if (!memberInfoRequests.isEmpty()) {
//                for (MemberInfoRequest memberInfoRequest : memberInfoRequests) {
//                    if (memberInfoRequest.getMemberId().equals(memberId)) {
//                        return true;
//                    }
//                }
//            }
//        }
//        return false;
//    }
}
