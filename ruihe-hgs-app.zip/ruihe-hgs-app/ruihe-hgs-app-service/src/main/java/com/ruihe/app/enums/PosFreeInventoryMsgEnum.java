package com.ruihe.app.enums;

/**
 * @author 梁远
 * @Description 单审核操作信息
 * @create 2019-10-17 15:14
 */
public enum PosFreeInventoryMsgEnum {

    //申请单作成
    UNREVIEWED(1, "盘点申请单作成"),
    //柜台确认盘点
    //FIRSTPASSED(2, "柜台确认盘点"),
    //柜台盘点拒绝
    //FIRSTREJECTED(3, "柜台盘点拒绝"),
    //审核通过
    PASSED(4, "审核通过"),
    //审核拒绝
    REJECTED(5, "审核拒绝");
    private Integer code;
    private String msg;


    PosFreeInventoryMsgEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
