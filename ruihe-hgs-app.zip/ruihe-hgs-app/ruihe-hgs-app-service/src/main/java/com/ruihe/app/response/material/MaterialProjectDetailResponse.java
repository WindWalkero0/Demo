package com.ruihe.app.response.material;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author qubin
 * @date 2021年07月05日 13:44
 */
@ApiModel(value = "MaterialProjectDetailResponse", description = "导购助手-资料项目详情响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MaterialProjectDetailResponse implements Serializable {

    @ApiModelProperty("项目集合")
    private List<MaterialProjectResponse> projectResponseList;

    @ApiModelProperty("项目分类响应")
    private Map<Integer, Set<MaterialProjectCategoryResponse>> categoryResponseMap;
}
