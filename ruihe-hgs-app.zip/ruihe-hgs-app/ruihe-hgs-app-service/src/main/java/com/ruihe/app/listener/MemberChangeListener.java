package com.ruihe.app.listener;

import com.ruihe.app.event.MemberChangeEvent;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.service.MemberCouponSingleOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

@Slf4j
@Component
public class MemberChangeListener {

    @Autowired
    private MemberCouponSingleOperation memberCouponSingleOperation;

    @Autowired
    private CustomService customService;

    @Async(CommonConstant.POS_COUPON_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(MemberChangeEvent event) {
        try {
            memberCouponSingleOperation.cancelMemberCoupon(event.getMemberId());
            MemberInfo memberInfo = customService.select(MemberInfo.builder().memberId(event.getMemberId()).build());
            memberCouponSingleOperation.reprocessCoupon(memberInfo);
        } catch (Exception e) {
            log.error("当会员等级发生了变化的时候,进行相关优惠券停用.error,memberId={}", event.getMemberId(), e);
        }
    }
}
