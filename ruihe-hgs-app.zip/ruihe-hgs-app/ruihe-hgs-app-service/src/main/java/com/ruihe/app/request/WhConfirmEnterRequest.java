package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 门店入库单确认实体类
 *
 * @author Fangtao
 * @date 2020/3/12 19:19
 */
@ApiModel(value = "WhConfirmEnterRequest", description = "门店入库单确认实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhConfirmEnterRequest implements Serializable {

    @NotNull(message = "柜台id不能为空")
    @ApiModelProperty(value = "柜台id")
    private String counterId;

    @NotNull(message = "柜员id不能为空")
    @ApiModelProperty(value = "柜员id")
    private String baCode;

    @NotNull(message = "入库单号不能为空")
    @ApiModelProperty(value = "入库单号")
    private String enterNo;

    @ApiModelProperty(value = "自动确认入库类型 0否 1是")
    private Integer receiveType;
}
