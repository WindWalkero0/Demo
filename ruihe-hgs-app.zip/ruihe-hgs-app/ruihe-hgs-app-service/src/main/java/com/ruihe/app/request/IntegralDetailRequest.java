package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-12-27 10:59
 */
@ApiModel(value = "IntegralDetailRequest", description = "微信获取个人积分明细实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IntegralDetailRequest implements Serializable {

    @NotBlank(message = "会员id不能为空")
    @ApiModelProperty("会员id")
    private String memberId;

    @ApiModelProperty("类型：全部：不传，获取：0，支出：1")
    private Integer type;

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
