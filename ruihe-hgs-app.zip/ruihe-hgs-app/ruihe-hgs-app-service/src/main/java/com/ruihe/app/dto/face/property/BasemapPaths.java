package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class BasemapPaths {
    /**
     * 底图1URL,颜色为#809ED1（痘痘、色斑、黑头、脂肪
     * 粒维度可视化需要）
     */
    private String path1;
    /**
     * 底图2URL,颜色为#B6D0C9（水、油、细纹维度可视化
     * 需要
     */
    private String path2;
    /**
     * 底图3URL,颜色为#FFEECF（黑眼圈、卧蚕、眼袋、毛
     * 孔维度可视化需要）
     */
    private String path3;
}
