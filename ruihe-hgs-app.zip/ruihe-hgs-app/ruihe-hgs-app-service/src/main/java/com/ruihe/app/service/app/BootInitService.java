package com.ruihe.app.service.app;


import com.ruihe.common.response.Response;

public interface BootInitService {

    /**
     * 启动初始化
     *
     * @return
     */
    Response init();
}
