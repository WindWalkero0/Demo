package com.ruihe.app.service.order.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.app.service.order.ScatteredService;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.pojo.request.promotion.SalesProductRequest;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.util.*;

@Slf4j
@DS(DBConst.SLAVE)
@Service
public class OperationMatchCount {

    @Autowired
    private CustomService customService;

    @Autowired
    private ScatteredService scatteredService;

//    @Ella(Describe = "非整单条件进行匹配", Author = "K")
//    public void operationCount(PromotionActivity promotionActivity, List<SalesProductRequest> products, SalesRequest salesRequest) {
//        SalesRequest salesRequestOther = SalesRequest.builder().build();
//        BeanUtils.copyProperties(salesRequest, salesRequestOther);
//        List<SalesProductRequest> collect = products.stream().map(salesProductRequest -> {
//            SalesProductRequest build = SalesProductRequest.builder().build();
//            BeanUtils.copyProperties(salesProductRequest, build);
//            return build;
//        }).collect(Collectors.toList());
//        salesRequestOther.setProducts(collect);
//        List<RewardCloud> rewardClouds = customService.selectList(RewardCloud.builder().isDel(CommonStatusEnum.EFFECTIVE.getCode()).cloudMethod(0).promotionalUid(promotionActivity.getUid()).build());
//        List<RewardCloud> rewardClouds3 = operationProduct(rewardClouds, 0, PromotionalEnum.PRO1.getKey());//得到购买(固定)的组合--商品范围
//        List<RewardCloud> rewardClouds4 = operationProduct(rewardClouds, 1, PromotionalEnum.PRO2.getKey());//得到购买(选择)的组合--指定商品
//        List<RewardCloud> rewardClouds5 = operationProduct(rewardClouds, 1, PromotionalEnum.PRO6.getKey());//得到购买(选择)的组合--商品小类
//        List<RewardCloud> rewardClouds6 = operationProduct(rewardClouds, 1, PromotionalEnum.PRO1.getKey());//得到购买(选择)的组合--商品范围
//    }
//
//    @Ella(Describe = "非整单进行匹配", Author = "K")
//    public void matchCount(List<RewardCloud> rewardClouds, SalesRequest salesRequest, PromotionActivity promotionActivity) {
//        List<SalesProductRequest> salesProductRequests = salesRequest.getProducts();
//        List<RewardCloud> rewardClouds1 = operationProduct(rewardClouds, 0, PromotionalEnum.PRO2.getKey());//得到购买(固定)的组合--指定商品
//        if (!rewardClouds1.isEmpty()) {//扣除指定商品的信息
//            Iterator<SalesProductRequest> iterator = salesProductRequests.iterator();
//            while (iterator.hasNext()) {
//                SalesProductRequest salesProductRequest = iterator.next();
//                rewardClouds1.stream().forEach(rewardCloud -> {
//                    if (salesProductRequest.getProId().equals(rewardCloud.getGoodsBarCode())) {
//                        Integer temp = Integer.parseInt(salesProductRequest.getProCount()) - Integer.parseInt(rewardCloud.getInputValues());
//                        salesProductRequest.setProCount(temp.toString());
//                    }
//                });
//            }
//        }
//        //进行分类和范围匹配查看是否满足
//        scatteredService.classification(salesRequest, rewardClouds, promotionActivity);
//    }


    @Ella(Describe = "购买的商品进行分类", Author = "K")
    public Map<Serializable, List<SalesProductRequest>> operationClass(List<SalesProductRequest> products) {
        Map<Serializable, List<SalesProductRequest>> map = new HashMap<>();
        products.stream().forEach(product -> {
            Product productOther = customService.select(Product.builder().prdBarCode(product.getProId()).build());
            if (productOther == null) {
                log.error("购买的商品现不存在我们商品库中{}",product.getProId());
                throw new BizException("购买的商品现不存在我们商品库中,请先同步商品信息::product.getProId()");
            }
            List<SalesProductRequest> list = map.get(productOther.getSmallCatCode());
            if (list == null || list.isEmpty()) {
                list = new ArrayList<>();
                list.add(product);
                map.put(productOther.getSmallCatCode(), list);
            } else {
                list.add(product);
                map.put(productOther.getSmallCatCode(), list);
            }
            scatteredService.sortProduct(list);//排序
        });
        return map;
    }


}
