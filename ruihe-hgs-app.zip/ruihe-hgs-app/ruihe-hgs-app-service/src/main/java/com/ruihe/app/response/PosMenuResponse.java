package com.ruihe.app.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * pos菜单配置表
 *
 * @author William
 */
@ApiModel(value = "PosMenuResponse", description = "pos菜单配置响应实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosMenuResponse implements Serializable {
    /**
     * 功能代码
     **/
    @ApiModelProperty(value = "功能代码")
    private String funcCode;
    /**
     * 功能名称
     **/
    @ApiModelProperty(value = "功能名称")
    private String funcName;
    /**
     * 该功能【自营店】是否启用,0不启用,1启用
     **/
    @ApiModelProperty(value = "【自营店】是否启用")
    private Boolean selfOperateEnable;
    /**
     * 该功能【加盟商】是否启用,0不启用,1启用
     **/
    @ApiModelProperty(value = "【加盟商】是否启用")
    private Boolean franchiseEnable;
    /**
     * 该功能【全局配置】是否启用,0不启用,1启用
     **/
    @ApiModelProperty(value = "【全局配置】是否启用")
    private Boolean enable;
}
