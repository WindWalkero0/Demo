package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class Eyeshape {
    /**
     * 单双眼皮
     */
    private Integer eyelid;
    /**
     * 眼睛宽窄
     */
    private Integer narrow;
    /**
     * 外眼角的上扬或下垂
     */
    private Integer updown;
}
