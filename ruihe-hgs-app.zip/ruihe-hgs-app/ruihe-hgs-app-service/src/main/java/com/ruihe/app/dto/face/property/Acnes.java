package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class Acnes {
    /**
     * 痘痘类型
     */
    private Integer acneTypeId;
    /**
     * 严重等级
     */
    private Integer level;
    /**
     * 痘痘数量
     */
    private Integer number;
    /**
     * 部位
     */
    private Integer facePart;

    public static boolean getProblemData(Acnes acnes) {
        return acnes.getLevel() > 1;
    }
}
