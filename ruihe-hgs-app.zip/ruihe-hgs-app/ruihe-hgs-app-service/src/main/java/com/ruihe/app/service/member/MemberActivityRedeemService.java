package com.ruihe.app.service.member;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.member.MemberActivityProductMapper;
import com.ruihe.app.mapper.member.MemberActivitySonMapper;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.dao.bean.member.MemberActivity;
import com.ruihe.common.dao.bean.member.MemberActivityProduct;
import com.ruihe.common.dao.bean.member.MemberActivitySon;
import com.ruihe.common.enums.member.MemberActivityEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.pojo.dto.MemberActivityProductDTO;
import com.ruihe.common.pojo.response.member.MemberActivityRedeemResponse;
import com.ruihe.common.service.ActivityService;
import com.ruihe.app.mapper.member.MemberActivityMapper;
import com.ruihe.app.request.member.MemberActivityCouponRequest;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.TimeUtils;
import com.ruihe.app.service.integral.IntegralService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class MemberActivityRedeemService {

    private final MemberActivityMapper memberActivityMapper;

    private final IntegralService integralService;

    private final ActivityService activityService;

    private final MemberActivitySonMapper memberActivitySonMapper;

    private final MemberActivityProductMapper memberActivityProductMapper;

    public MemberActivityRedeemService(MemberActivityMapper memberActivityMapper,
                                       IntegralService integralService,
                                       ActivityService activityService,
                                       MemberActivitySonMapper memberActivitySonMapper,
                                       MemberActivityProductMapper memberActivityProductMapper) {
        this.memberActivityMapper = memberActivityMapper;
        this.integralService = integralService;
        this.activityService = activityService;
        this.memberActivitySonMapper = memberActivitySonMapper;
        this.memberActivityProductMapper = memberActivityProductMapper;
    }

    /**
     * 查询积分兑换活动
     *
     * @param request 查询入参
     * @return 返回符合的积分兑换条件
     */
    @DS(DBConst.SLAVE)
    public Response selectRedeemNew(MemberActivityCouponRequest request) {
        //查询积分信息--引入新积分和老积分概念如果typeRule等于0就查询老积分如果typeRule等于1就查询新积分
        IntegralAccountPo accountPo = integralService.selectIntegralAccount(request.getMemberId());
        IntegralAccountPo integralAccountPo = accountPo == null ? IntegralAccountPo.builder().newQty(BigInteger.ZERO.bitCount()).oldQty(BigInteger.ZERO.bitCount()).build() : accountPo;
        //根据新老积分查询符合的活动信息列表
        List<MemberActivitySon> memberActivitySons = searchActivities(integralAccountPo, MemberActivityEnum.OLD_TYPE_RULE.getKey(), request);
        List<MemberActivitySon> list = memberActivitySons.isEmpty() ? searchActivities(integralAccountPo, MemberActivityEnum.NEW_TYPE_RULE.getKey(), request) : memberActivitySons;
        List<MemberActivityRedeemResponse> collect = list.stream().map(memberActivitySon -> {
            //组装返回信息
            MemberActivityRedeemResponse memberActivityRedeemResponse = new MemberActivityRedeemResponse();
            BeanUtils.copyProperties(memberActivitySon, memberActivityRedeemResponse);
            //组装商品信息
            List<MemberActivityProductDTO> products = memberActivityProductMapper.selectList(Wrappers.lambdaQuery(MemberActivityProduct.class)
                    .eq(MemberActivityProduct::getIsDel, CommonStatusEnum.EFFECTIVE.getCode())
                    .notIn(MemberActivityProduct::getRewardType, 2)
                    .eq(MemberActivityProduct::getActivityId, memberActivitySon.getActivityId())).stream().map(memberActivityProduct -> {
                MemberActivityProductDTO build = MemberActivityProductDTO.builder().build();
                BeanUtils.copyProperties(memberActivityProduct, build);
                return build;
            }).collect(Collectors.toList());
            memberActivityRedeemResponse.setProducts(products);
            //填充新老总积分信息
            memberActivityRedeemResponse.setBuyType(memberActivitySon.getBuyType());
            return memberActivityRedeemResponse;
        }).sorted(Comparator.comparing(MemberActivityRedeemResponse::getRequiredIntegral)).collect(Collectors.toList());
        MemberIntegralResponse memberIntegralResponse = MemberIntegralResponse.builder()
                .list(collect)
                .newQty(integralAccountPo.getNewQty())
                .oldQty(integralAccountPo.getOldQty())
                .ruleType(memberActivitySons.isEmpty() ? MemberActivityEnum.NEW_TYPE_RULE.getKey() : MemberActivityEnum.OLD_TYPE_RULE.getKey())
                .totalQty(integralAccountPo.getNewQty() + integralAccountPo.getOldQty())
                .build();
        return Response.success(memberIntegralResponse);
    }

    /**
     * 根据新老积分查询符合的活动信息列表
     *
     * @param typeRule 0老积分;1新积分
     * @param request  查询条件
     * @return 符合的子活动列表
     */
    private List<MemberActivitySon> searchActivities(IntegralAccountPo integralAccountPo, Integer typeRule, MemberActivityCouponRequest request) {
        //查询积分活动信息
        List<MemberActivitySon> collect = new ArrayList<>();
        memberActivityMapper.selectList(Wrappers.lambdaQuery(MemberActivity.class)
                .eq(MemberActivity::getIsDel, BigInteger.ONE.bitCount())
                .eq(MemberActivity::getTemplateType, BigInteger.ZERO.bitCount())
                .eq(MemberActivity::getTypeRule, typeRule)
                .eq(MemberActivity::getSubjectType, MemberActivityEnum.EXCHANGE_ACTIVITY.getKey())
                .eq(MemberActivity::getActivityType, request.getType())
                .le(MemberActivity::getReceiveStartTime, TimeUtils.longFormatString(System.currentTimeMillis()))
                .ge(MemberActivity::getReceiveStopTime, TimeUtils.longFormatString(System.currentTimeMillis()))
                .le(MemberActivity::getSubjectStartTime, TimeUtils.longFormatString(System.currentTimeMillis()))
                .ge(MemberActivity::getSubjectStopTime, TimeUtils.longFormatString(System.currentTimeMillis())))
                .forEach(memberActivity -> {
                    collect.addAll(memberActivitySonMapper.selectList(Wrappers.lambdaQuery(MemberActivitySon.class)
                            .eq(MemberActivitySon::getSubjectId, memberActivity.getActivityId())
                            .eq(MemberActivitySon::getIsDel, CommonStatusEnum.EFFECTIVE.getCode())).stream()
                            //进行条件过滤
                            .filter(memberActivitySon -> !activityService.checkLimit(request.getMemberId(), memberActivitySon) &&
                                    activityService.checkPlace(request.getCounterId(), memberActivitySon) &&//地点是否满足
                                    activityService.checkObject(request.getMemberId(), memberActivitySon) && //会员积分模块查询
                                    activityService.checkIntegral(integralAccountPo, memberActivitySon, typeRule))//满足积分条件
                            .peek(memberActivitySon -> memberActivitySon.setBuyType(memberActivity.getBuyType())).collect(Collectors.toList()));
                });
        return collect;
    }

//    @Ella(Describe = "查询积分兑换活动", Author = "K")
//    @DS(DBConst.SLAVE)
//    public Response selectRedeem(MemberActivityCouponRequest request) {
//        LambdaUtil lambdaUtil = LambdaUtil.builder().sum(0).build();
//        //设置分页信息
//        PageHelper.startPage(request.getPageNumber(), request.getPageSize());
//        //先查询所有正在进行中且有效的积分活动
//        List<MemberActivity> memberActivities = selectActivityByTime(request);
//        List<MemberActivityRedeemResponse> memberActivityRedeemResponses = new ArrayList<>();
//        Integer size = 0;
//        //进行活动匹配
//        if (!memberActivities.isEmpty()) {
//            memberActivityRedeemResponses = operationRedeem(memberActivities, request, size, lambdaUtil);
//        }
//        PageInfo<MemberActivityRedeemResponse> info = new PageInfo<>(memberActivityRedeemResponses);
//        info.setTotal(memberActivityRedeemResponses.isEmpty() ? 0 : countActivityByTime(request) - lambdaUtil.getSum());
//        int count = (int) (countActivityByTime(request) - lambdaUtil.getSum());
//        info.setPages(count % request.getPageSize() == 0 ? count / request.getPageSize() : count / request.getPageSize() + 1);
//        return Response.success(info);
//    }
//
//    @Ella(Describe = "兑换活动进行匹配处理")
//    private List<MemberActivityRedeemResponse> operationRedeem(List<MemberActivity> memberActivities, MemberActivityCouponRequest request, Integer size, LambdaUtil lambdaUtil) {
//        //查询会员积分
//        IntegralAccountPo integralAccountPo = integralService.selectIntegralAccount(request.getMemberId());
//        //查询所有有效且正在进行或者未开始且有效的活动
//        if (integralAccountPo == null) {//数据没有补全给填充0
//            integralAccountPo = new IntegralAccountPo();
//            integralAccountPo.setAvlQty(0);
//            integralAccountPo.setExchQty(0);
//            integralAccountPo.setSaleQty(0);
//            integralAccountPo.setTotalQty(0);
//            integralAccountPo.setExpiredQty(0);
//            integralAccountPo.setExpiringQty(0);
//        }
//        List<MemberActivityRedeemResponse> collect = new ArrayList<>();
//        for (MemberActivity memberActivity : memberActivities) {
//            List<MemberActivitySon> memberActivitySons = operationLimit(memberActivity, request, integralAccountPo, size, lambdaUtil);
//            if (!memberActivitySons.isEmpty()) {
//                memberActivitySons.forEach(memberActivitySon -> {
//                    MemberActivityRedeemResponse memberActivityRedeemResponse = new MemberActivityRedeemResponse();
//                    BeanUtils.copyProperties(memberActivitySon, memberActivityRedeemResponse);
//
//                    final List<MemberActivityProduct> memberActivityProducts = memberActivityService.selectMemberActivityProducts(MemberActivityProduct
//                            .builder()
//                            .isDel(CommonStatusEnum.EFFECTIVE.getCode())
//                            .activityId(memberActivitySon.getActivityId())
//                            .build());
//                    memberActivityRedeemResponse.setProducts(MemberActivityProduct.convert2DTO(memberActivityProducts));
//                    memberActivityRedeemResponse.setBuyType(memberActivity.getBuyType()); //积分兑换活动为什么要返回"是否购买"这个字段???
//                    collect.add(memberActivityRedeemResponse);
//                });
//            }
//        }
//        Iterator<MemberActivityRedeemResponse> iterator = collect.iterator();
//        while (iterator.hasNext()) {
//            MemberActivityRedeemResponse next = iterator.next();
//            if (StringUtils.isEmpty(next.getProducts())) { //这里为什么会为空? 上一步for循环已经设置了该值的
//                iterator.remove();
//                lambdaUtil.setSum(lambdaUtil.getSum() + 1);
//            }
//        }
//        return collect;
//    }
//
//    @Ella(Describe = "查询子活动并处理", Author = "K")
//    private List<MemberActivitySon> operationLimit(MemberActivity memberActivity, MemberActivityCouponRequest request, IntegralAccountPo integralAccountPo, Integer size, LambdaUtil lambdaUtil) {
//        //根据主活动查询子活动的信息
//        List<MemberActivitySon> memberActivitySons = memberActivityService.selectMemberActivitySonList(MemberActivitySon
//                .builder()
//                .subjectId(memberActivity.getActivityId())
//                .isDel(CommonStatusEnum.EFFECTIVE.getCode())//查询有效的
//                .build());
//        Iterator<MemberActivitySon> iterator = memberActivitySons.iterator();
//        while (iterator.hasNext()) {
//            MemberActivitySon memberActivitySon = iterator.next();
//            if (TimeUtils.dateToStamp(memberActivity.getReceiveStartTime()) >= System.currentTimeMillis() || TimeUtils.dateToStamp(memberActivity.getReceiveStopTime()) <= System.currentTimeMillis()) {
//                iterator.remove();//未在领用时间内
//                size++;
//                continue;
//            }
//            //检测是否超过上限;是否满足地点;是否满足对象;积分值
//            if (activityService.checkLimit(request.getMemberId(), memberActivitySon) ||
//                    !activityService.checkPlace(request.getCounterId(), memberActivitySon) ||
//                    !activityService.checkObject(request.getMemberId(), memberActivitySon) || //会员积分模块查询
//                    !activityService.checkIntegral(integralAccountPo, memberActivitySon)  //会员积分模块查询
//            ) {
//                iterator.remove();
//                size++;
//            }
//        }
//        lambdaUtil.setSum(size);
//        return memberActivitySons;
//    }
//
//    @Ella(Describe = "查询所有正在进行中且有效的积分活动", Author = "K")
//    private List<MemberActivity> selectActivityByTime(MemberActivityCouponRequest request) {
//        //填充现在时间
//        request.setNowTime(TimeUtils.longFormatString(System.currentTimeMillis()));
//        return memberActivityMapper.selectMemberActivityByTime(request);
//    }
//
//    @Ella(Describe = "查询所有正在进行中且有效的积分活动的个数", Author = "K")
//    private Long countActivityByTime(MemberActivityCouponRequest request) {
//        //填充现在时间
//        request.setNowTime(TimeUtils.longFormatString(System.currentTimeMillis()));
//        return memberActivityMapper.countActivityByTime(request);
//    }

}
