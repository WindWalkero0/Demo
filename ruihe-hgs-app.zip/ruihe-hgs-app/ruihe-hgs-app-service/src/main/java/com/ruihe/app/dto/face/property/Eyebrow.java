package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class Eyebrow {
    /**
     * 左眼眉形
     */
    private Integer left;
    /**
     * 右眼眉形
     */
    private Integer right;
}
