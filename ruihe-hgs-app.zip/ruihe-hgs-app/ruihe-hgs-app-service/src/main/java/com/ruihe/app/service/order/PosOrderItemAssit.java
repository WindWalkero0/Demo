package com.ruihe.app.service.order;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 选购商品辅助计算
 *
 * @author William
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosOrderItemAssit implements Serializable {
    /**
     * 订单金额
     */
    private BigDecimal payableAmt;

    /**
     * 购买数量
     */
    private Integer purQty;

    /**
     * 购买数量
     */
    private Integer skQty;

    /**
     * 参加促销商品总价格
     */
    private BigDecimal totalMoney;

}
