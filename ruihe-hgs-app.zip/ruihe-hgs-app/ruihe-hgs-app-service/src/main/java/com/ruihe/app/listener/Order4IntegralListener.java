package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.service.integral.IntegralLogService;
import com.ruihe.app.service.integral.IntegralRuleEngine;
import com.ruihe.app.service.integral.IntegralService;
import com.ruihe.app.service.integral.RuleContext;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.integral.IntegralAccountPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderItemPo;
import com.ruihe.common.dao.bean.integral.IntegralOrderPo;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.app.event.Order4IntegralEvent;
import com.ruihe.app.mapper.basic.CounterMapper;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.app.mapper.order.PosOrderItemMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.enums.integral.IntegralBizTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.MutableTriple;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import java.util.List;

/**
 * 销售订单事件-积分业务处理
 * <p>
 * 销售+出-》增加积分
 * 销售+退-》扣减积分
 * 预订单+出-》增加积分
 * 预订单+退-》扣减积分
 * 积分兑换+出-》扣减积分
 * 积分兑换+退-》增加积分
 * </p>
 *
 * @author William
 */
@Slf4j
@Component
public class Order4IntegralListener {

    @Autowired
    private IntegralRuleEngine integralRuleEngine;

    @Autowired
    private IntegralService integralService;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private IntegralLogService integralLogService;

    @Autowired
    private PosOrderItemMapper posOrderItemMapper;

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private CounterMapper counterMapper;

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener(fallbackExecution = true)
    public void onApplicationEvent(Order4IntegralEvent event) {
        try {
            //构造rc
            RuleContext rc = this.extractRuleContext(event.getOrderNo());
            if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(rc.getOrder().getTransType())) {
                //正常销售、预订单、积分兑换跑积分活动
                MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> result = integralRuleEngine.run(rc);
                //事务处理落地数据
                integralService.changeBalance(result);
                integralLogService.saveLog(rc);
            } else if (OrderTransTypeEnum.GOODS_RETURN.getCode().equals(rc.getOrder().getTransType()) && StringUtils.isNotBlank(rc.getOrder().getPreOrderNo())) {
                //正常销售退货、预订单退货、积分兑换退货【整单退】
                integralService.changeBalance(rc.getOrder());
                integralLogService.saveLog(rc);
            } else if (OrderTransTypeEnum.GOODS_RETURN.getCode().equals(rc.getOrder().getTransType()) && StringUtils.isBlank(rc.getOrder().getPreOrderNo())) {
                //空退货走默认积分规则进行扣减积分
                MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> result = integralRuleEngine.run4DirectGoodsReturn(rc);
                integralService.changeBalance(result);
                integralLogService.deductedNewForEmptyReturn(result.getLeft(), IntegralBizTypeEnum.SALE_RETURN.getCode());
            }
        } catch (Exception e) {
            log.error("积分业务处理异常，event{}", JSON.toJSONString(event), e);
        }

    }

    /**
     * 构造rc
     *
     * @param orderNo
     * @return
     */
    private RuleContext extractRuleContext(final String orderNo) {
        /*查询订单信息*/
        PosOrderPo orderPo = posOrderMapper.selectById(orderNo);
        List<PosOrderItemPo> posOrderItemPos = posOrderItemMapper.selectList(Wrappers.<PosOrderItemPo>lambdaQuery().eq(PosOrderItemPo::getOrderNo, orderNo));
        MemberInfo member = memberMapper.selectById(orderPo.getMemberId());
        CounterInformation counter = counterMapper.selectById(orderPo.getCounterId());
        IntegralAccountPo integralAccountPo = integralService.selectIntegralAccount(orderPo.getMemberId());
        return RuleContext.builder()
                .member(member)
                .counter(counter)
                .accountPo(integralAccountPo)
                .order(orderPo)
                .orderItemList(posOrderItemPos)
                .build();
    }
}
