package com.ruihe.app.service.task;


import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.event.Order4MemberLevelEvent;
import com.ruihe.app.event.U8ChangePriceItemEvent;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.app.mapper.u8.U8ChangePriceItemMapper;
import com.ruihe.app.request.WhConfirmEnterRequest;
import com.ruihe.app.service.basic.CounterLocationService;
import com.ruihe.app.service.heartbeat.CounterHeartbeatService;
import com.ruihe.app.service.integral.IntegralService;
import com.ruihe.app.service.u8.U8InventoryResend;
import com.ruihe.app.service.warehouse.WhEnterService;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.constant.AppointType;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.system.SystemConfigPo;
import com.ruihe.common.dao.bean.u8.U8ChangePriceItemPo;
import com.ruihe.common.dao.bean.warehouse.WhEnterPo;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.common.enums.system.SystemConfigEnum;
import com.ruihe.common.response.Response;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.utils.TimeUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class AppTaskService implements ApplicationContextAware {

    @Autowired
    private IntegralService integralService;

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private CustomService customService;

    @Autowired
    private WhEnterService whEnterService;

    @Autowired
    private U8InventoryResend u8InventoryResend;

    @Autowired
    private U8ChangePriceItemMapper u8ChangePriceItemMapper;

    @Autowired
    private CounterHeartbeatService counterHeartbeatService;

    private ApplicationContext applicationContext;

    private final String AUTO_RECEIVE_BA = "auto:receive_ba";

    @Autowired
    private CounterLocationService counterLocationService;

    @Autowired
    private RedisTemplate<Object, Object> redisTemplate;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Ella(Describe = "积分失效", Author = "K")
    @DS(DBConst.MASTER)
    public Response expire() {
        integralService.expire();
        return Response.successMsg("操作成功!");
    }

    /**
     * 每天凌晨2点触发
     */
    @DS(DBConst.MASTER)
    public Response downgrade() {
        //查询到期会员id的list(不包含花粉会员和体验会员---永久有效)
        List<String> memberIdList = memberMapper.selectMemberIdList(LocalDateTime.now());
        //如果不为空，进行等级判断
        if (!memberIdList.isEmpty()) {
            Order4MemberLevelEvent order4MemberLevelEvent = new Order4MemberLevelEvent(this, memberIdList);
            applicationContext.publishEvent(order4MemberLevelEvent);
        }
        return Response.successMsg("操作成功!");
    }

    /**
     * 发送失败的盘点单每30分钟重发一次
     */
    @DS(DBConst.MASTER)
    public Response inventoryResend() {
        u8InventoryResend.u8InventoryResend();
        return Response.successMsg("操作成功!");
    }

    /**
     * 先查询配置信息
     * 是否生效
     * 查询指定的柜台类型
     * 根据柜台类型查询柜台的入库单
     * 如果入库单有没有入库的,查询是否满足自动确认收货配置
     * 满足调用入库接口不满足跳过
     *
     * @return
     */
    @Ella(Describe = "自动确认收货")
    public Response autoReceive() {
        SystemConfigPo config = customService.select(SystemConfigPo.builder().paramKey(SystemConfigEnum.AUTO_RANGE.getCode()).build());
        SystemConfigPo jmConfig = customService.select(SystemConfigPo.builder().paramKey(SystemConfigEnum.AUTO_JM.getCode()).paramValue("1").build());
        SystemConfigPo zyConfig = customService.select(SystemConfigPo.builder().paramKey(SystemConfigEnum.AUTO_ZY.getCode()).paramValue("1").build());
        if (config != null) {
            //获取到周期值,周期对应的单位是天固定的
            Long dateRange = Long.valueOf(config.getParamValue());
            Long time = (dateRange + 1) * 24 * 60 * 60 * 1000;//因为是X天后 所以在在原有的基础上加1一天
            //处理直营
            if (jmConfig != null) {
                //查询所有的直营门店
                List<CounterInformation> counterInformationList = customService.selectListAppoint(
                        CounterInformation.builder().counterId(AppointType.appointString).build(),
                        CounterInformation.builder().operationalModel(CounterEnum.AGENT_COUNTER.getKey().toString()).build());
                operationEnter(counterInformationList, time);
            }
            //处理直营
            if (zyConfig != null) {
                List<CounterInformation> counterInformationList = customService.selectListAppoint(
                        CounterInformation.builder().counterId(AppointType.appointString).build(),
                        CounterInformation.builder().operationalModel(CounterEnum.SELF_SUPPORT.getKey().toString()).build());
                operationEnter(counterInformationList, time);
            }
        }
        return Response.successMsg("操作成功");
    }

    @Ella(Describe = "查询柜台的入库单")
    public void operationEnter(List<CounterInformation> counterInformationList, Long time) {
        counterInformationList.forEach(counterInformation -> {
            //查询指定柜台的诶确认的入库单
            List<WhEnterPo> whEnterPos = customService.selectList(WhEnterPo.builder().counterId(counterInformation.getCounterId()).status(1).build());
            whEnterPos.forEach(whEnterPo -> {
                //获取时间查看是否满足
                Long createTime = TimeUtils.timeChange(TimeUtils.getStartTime(TimeUtils.localTimeFormatString(whEnterPo.getCreateTime()), 0));
                Long l = createTime + time;
                //当前时间
                Long nowTime = TimeUtils.timeChange(TimeUtils.getStartTime(TimeUtils.localTimeFormatString(LocalDateTime.now()), 0));
                if (nowTime >= l) {//说明需要入库
                    //进行入库操作
                    //获取自动入库BA
                    String baCode = (String) redisTemplate.opsForValue().get(AUTO_RECEIVE_BA);
                    Response  response = whEnterService.confirmEnter(WhConfirmEnterRequest.builder().baCode(baCode).counterId(counterInformation.getCounterId()).receiveType(1).enterNo(whEnterPo.getEnterNo()).build());
                    if(response.getCodeL() != 200){
                        log.error("自动确认收货报警：" + response.getData());
                    }
                }
            });
        });
    }

    @Ella(Describe = "新积分失效", Author = "fly")
    @DS(DBConst.MASTER)
    public Response newExpire() {
        integralService.newExpire();
        return Response.successMsg("操作成功!");
    }

    @Ella(Describe = "修改订货价", Author = "qubin")
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response changeOrderPrice(){

        //根据先同步的先执行进行查询
        List<U8ChangePriceItemPo> dataList = u8ChangePriceItemMapper.selectList(Wrappers.<U8ChangePriceItemPo>lambdaQuery()
                .eq(U8ChangePriceItemPo::getStatus,0)
                .le(U8ChangePriceItemPo::getEffectiveTime, LocalDate.now().plusDays(1))
                .orderByAsc(U8ChangePriceItemPo::getSyncTime));
        if(dataList == null || dataList.size() <= 0){
            return Response.successMsg("操作成功!");
        }

        List<String> orderNoList = new ArrayList<>();
        dataList.forEach(whU8ChangePriceItemPo -> {
            if(!orderNoList.contains(whU8ChangePriceItemPo.getOrderNo())){
                orderNoList.add(whU8ChangePriceItemPo.getOrderNo());
            }
        });
            for(String orderNo : orderNoList){
                U8ChangePriceItemEvent event = new U8ChangePriceItemEvent(this, orderNo);
                applicationContext.publishEvent(event);
            }
        return Response.successMsg("操作成功!");
    }

    @Ella(Describe = "检查心跳", Author = "qubin")
    public Response checkHeartbeat(){
        return counterHeartbeatService.checkHeartbeat();
    }

    @Ella(Describe = "初始化柜台地理位置", Author = "qubin")
    public Response initCounterLocation(){
        return counterLocationService.initLocation();
    }
}
