package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 会员未激活消息发送事件
 *
 * @author liangyuan
 * @date 2021年1月20日14:10:56
 */

@Data
@EqualsAndHashCode(callSuper = false)
public class CheckInactivateEvent extends ApplicationEvent {

    public CheckInactivateEvent(Object source) {
        super(source);
    }
}
