package com.ruihe.app.enums;

/**
 * @author luojie
 * @program ruihe-top
 * @description 库存类型枚举
 * @create: 2021/7/5 14:37
 */
public enum StockTypeEnum {

    STOCK_NONE(0, "仅展示库存为0"),
    STOCK_NON_ZERO(1, "不展示库存为0"),
    STOCK_ALL(2, "全部");

    private Integer code;
    private String name;

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    StockTypeEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }
    
    public static String getName(int code) {
        for (StockTypeEnum s : StockTypeEnum.values()) {
            if (s.getCode() == code) {
                return s.name();
            }
        }
        return null;
    }

    public static Integer getCode(String name) {
        for (StockTypeEnum s : StockTypeEnum.values()) {
            if (s.getName().equals(name)) {
                return s.code;
            }
        }
        return -1;
    }

    public static StockTypeEnum getByCode(Integer code){
        for (StockTypeEnum constants : values()) {
            if (constants.getCode().equals(code)) {
                return constants;
            }
        }
        return STOCK_ALL;
    }
}
