package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author LiangYuan
 * @date 2021-03-31 14:29
 */
@ApiModel(value = "ScheduleTimeRequest", description = "排班管理排班时间信息请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScheduleTimeRequest implements Serializable {

    @ApiModelProperty(value = "时间类型:0周一至周四，1周五至周日")
    private Integer type;

    @ApiModelProperty(value = "早班开始")
    private String morningStart;

    @ApiModelProperty(value = "早班结束")
    private String morningEnd;

    @ApiModelProperty(value = "中班开始")
    private String noonStart;

    @ApiModelProperty(value = "中班结束")
    private String noonEnd;

    @ApiModelProperty(value = "晚班开始")
    private String nightStart;

    @ApiModelProperty(value = "晚班结束")
    private String nightEnd;
}
