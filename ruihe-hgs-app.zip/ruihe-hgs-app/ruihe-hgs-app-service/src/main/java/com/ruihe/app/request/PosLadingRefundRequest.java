package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-21 15:15
 */
@ApiModel(value = "PosLadingRefundRequest", description = "提货单退货请求")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosLadingRefundRequest implements Serializable {

    @NotBlank(message = "订单号不能为空")
    @ApiModelProperty(value = "订单号")
    private String orderNo;

    @NotBlank(message = "提货单号不能为空")
    @ApiModelProperty(value = "提货单号")
    private String ladingOrderNo;

    @ApiModelProperty(value = "退货操作-柜员编号")
    private String baCode;

    @ApiModelProperty(value = "退货操作-姓名")
    private String baName;
}
