package com.ruihe.app.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * 门店入库实体类
 *
 * @author Fangtao
 */
@ApiModel(value = "WhEnter4U8Request", description = "门店入库单实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhEnter4U8Request implements Serializable {

    @NotBlank(message = "柜台id不能为空")
    @ApiModelProperty(value = "柜台id")
    private String counterId;

    @NotBlank(message = "柜台名称不能为空")
    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @NotBlank(message = "柜员id不能为空")
    @ApiModelProperty(value = "柜员id")
    private String baCode;

    @NotBlank(message = "柜员名称不能为空")
    @ApiModelProperty(value = "柜员名称")
    private String baName;

    @NotBlank(message = "发货单号不能为空")
    @ApiModelProperty(value = "发货单号")
    private String deliveryNo;

    @NotNull(message = "实际入库数量不能为空")
    @ApiModelProperty(value = "实际入库数量")
    private Integer realQty;

    @NotNull(message = "入库总金额不能为空")
    @ApiModelProperty(value = "入库总金额")
    private BigDecimal realAmt;

    @NotEmpty(message = "入库明细不能为空")
    @ApiModelProperty(value = "入库明细")
    private List<WhEnterItem> enterItemList;

}
