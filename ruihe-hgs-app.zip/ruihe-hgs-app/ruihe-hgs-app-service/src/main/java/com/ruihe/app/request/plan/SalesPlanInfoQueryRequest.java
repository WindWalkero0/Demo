package com.ruihe.app.request.plan;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * 销售规划查询请求
 * @author qubin
 * @date 2021/4/7 9:57
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SalesPlanInfoQueryRequest {

    /**
     * 柜台id
     */
    @NotBlank
    private String counterId;

    /**
     * 如果是日销售规划-规划时间(yyyy-MM-dd)
     * 如果是月销售规划-规划时间(yyyy-MM)
     */
    @NotBlank
    private String planTime;

    /**
     * 规划对象类型(1-APPOINTMENT)
     */
    @NotBlank
    private String planObjectType;

    /**
     * 会员等级code(非会员和前端约定传-1)
     */
    private Integer memberLevel;

    /**
     * 规划会员类型
     */
    private String planMemberType;

    /**
     * 美导编号
     */
    private String baCode;

}
