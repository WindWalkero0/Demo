package com.ruihe.app.enums;

/**
 * 订单号前缀
 */
public enum OrderNoPrefixEnum {

    //
    NSMP("NSMP", "销售订单"),
    //
    SRMP("SRMP", "销售退货"),
    PXMP("PXMP", "积分兑换"),
    DGMP("DGMP", "预定单提货"),
    RGMP("RGMP", "预订单退货"),
    LS("LS-", "小票号"),
    PMT("PMT", "支付订单号"),
    IM("IM", "积分导入"),
    PC("PC", "积分清零"),
    KB("KB", "口碑礼积分奖励"),
    STOCK_OPT_4U8("U8S", "u8库存操作流水号"),
    DB("DB", "兑吧积分兑换"),
    DBR("DBR", "兑吧积分退还"),
    ;

    private String code;
    private String msg;


    OrderNoPrefixEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
