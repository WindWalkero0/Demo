package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-12-26 14:50
 */
@ApiModel(value = "RegisterRequest", description = "微信注册实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegisterRequest implements Serializable {

    @NotBlank(message = "手机号不能为空")
    @ApiModelProperty("手机号")
    private String mobilePhone;

    @ApiModelProperty("姓名")
    private String memberName;

    @ApiModelProperty("性别")
    private String gender;

    @ApiModelProperty("生日")
    private String birthday;

    @ApiModelProperty("邀请人邀请码")
    private String invCode;

    @Builder.Default
    @ApiModelProperty("上一步错误码，默认-1")
    private Integer preStatus = -1;

//    @ApiModelProperty("推荐人")
//    private String rcmdMemberPhone;

    @NotBlank(message = "没有授权")
    @ApiModelProperty("微信opedId")
    private String openId;
}
