package com.ruihe.app.service.order;

import com.ruihe.app.request.PosSaleOrderRequest;
import com.ruihe.common.response.Response;

/***
 * pos终端下单操作,销售下单、退货下单、空退
 * @author William
 */
public interface PosSaleOrderService {
    /**
     * 销售下单【正常销售（附加促销活动）、预订单、积分兑换】
     * 退货下单【正常销售（附加促销活动）、预订单、积分兑换】、以及空退
     *
     * @param request
     * @return Response 响应
     */
    Response placeOrder(PosSaleOrderRequest request) throws Exception;

}
