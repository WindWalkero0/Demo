package com.ruihe.app.listener;

import com.ruihe.app.event.Order4DepositBoxEvent;
import com.ruihe.common.constant.CommonConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

/**
 * 销售订单事件-寄存箱业务处理
 * TODO
 *
 * @author William
 */
@Slf4j
@Component
public class Order4DepositBoxListener {

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @TransactionalEventListener
    public void onApplicationEvent(Order4DepositBoxEvent event) {
        log.info("orderQty===寄存箱==={}", event.getOrderNo());

    }
}
