package com.ruihe.app.enums;

/**
 * @Description 盘点单是否删除
 * @author 梁远
 * @create 2019-10-17 15:14
 */
public enum PosFreeInventoryIsDelEnum {

    //删除：0有效，1无效
    //编辑中
    EFFECTIVE(0, "有效"),
    //未审核
    INVALID(1, "无效");
    private Integer code;
    private String msg;


    PosFreeInventoryIsDelEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
