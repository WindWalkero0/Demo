package com.ruihe.app.service.activity;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.dao.bean.activity.ActivityPlace;
import com.ruihe.common.dao.bean.member.MemberActivity;
import com.ruihe.common.dao.bean.member.MemberActivitySon;
import com.ruihe.common.pojo.dto.MemberActivityDTO;
import com.ruihe.common.pojo.dto.MemberActivitySonDTO;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.app.mapper.member.MemberActivityMapper;
import com.ruihe.app.mapper.member.MemberActivitySonMapper;
import com.ruihe.app.mapper.promotion.ActivityPlaceMapper;
import com.ruihe.common.utils.TimeUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.*;

@Service
public class MemberActivityService {

    private final AbstractActivityService abstractActivityService;
    private final MemberActivityMapper memberActivityMapper;
    private final MemberActivitySonMapper memberActivitySonMapper;
    private final ActivityPlaceMapper activityPlaceMapper;

    public MemberActivityService(AbstractActivityService abstractActivityService, MemberActivityMapper memberActivityMapper, MemberActivitySonMapper memberActivitySonMapper, ActivityPlaceMapper activityPlaceMapper) {
        this.abstractActivityService = abstractActivityService;
        this.memberActivityMapper = memberActivityMapper;
        this.memberActivitySonMapper = memberActivitySonMapper;
        this.activityPlaceMapper = activityPlaceMapper;
    }

    /**
     * 获取有效且现在正在进行的会员活动
     *
     * @return 会员活动DTO列表
     */
    List<MemberActivityDTO> findEffectiveMemberActivity() {

        var whereCondition = Wrappers.<MemberActivity>lambdaQuery()
                .eq(MemberActivity::getIsDel, CommonStatusEnum.EFFECTIVE.getCode())
                .lt(MemberActivity::getSubjectStartTime, TimeUtils.longFormatString(System.currentTimeMillis()));
        var memberActivities = memberActivityMapper.selectList(whereCondition);

        if (CollectionUtils.isEmpty(memberActivities)) {
            return Collections.emptyList();
        }
        return memberActivities.stream().map(MemberActivity::convert2DTO).collect(toList());
    }

    /**
     * 获取单个会员活动的子活动
     *
     * @param activityId 会员活动Id
     * @return 会员活动的子活动
     */
    List<MemberActivitySonDTO> findOneMemberActivitySon(String activityId) {

        if (activityId == null) {
            return Collections.emptyList();
        }

        var sonWhereCondition = Wrappers.<MemberActivitySon>lambdaQuery()
                .eq(MemberActivitySon::getIsDel, CommonStatusEnum.EFFECTIVE.getCode())
                .eq(MemberActivitySon::getSubjectId, activityId);
        return memberActivitySonMapper.selectList(sonWhereCondition).stream().map(MemberActivitySon::convert2DTO).collect(toList());
    }

    /**
     * 获取多个会员活动的子活动
     *
     * @param activityIds 会员活动Id集合
     * @return key:会员活动Id,value:会员活动的子活动对象集合
     */
    Map<String, List<MemberActivitySonDTO>> findAllMemberActivitySon(List<String> activityIds) {

        if (CollectionUtils.isEmpty(activityIds)) {
            return Collections.emptyMap();
        }

        //查询会员活动子表
        var sonWhereCondition = Wrappers.<MemberActivitySon>lambdaQuery()
                .eq(MemberActivitySon::getIsDel, CommonStatusEnum.EFFECTIVE.getCode())
                .in(MemberActivitySon::getSubjectId, activityIds);
        return memberActivitySonMapper.selectList(sonWhereCondition).stream().collect(groupingBy(MemberActivitySon::getSubjectId, mapping(MemberActivitySon::convert2DTO, toList())));
    }

    /**
     * 获取多个会员活动的子活动2
     *
     * @param activities 会员活动集合
     * @return key:会员活动Id,value:会员活动的子活动对象集合
     */
    List<MemberActivityDTO> findAllMemberActivitySon2(List<MemberActivityDTO> activities) {

        if (CollectionUtils.isEmpty(activities)) {
            return Collections.emptyList();
        }

        var activityIds = activities.stream().map(MemberActivityDTO::getActivityId).collect(toList());
        //查询会员活动子表
        var sonWhereCondition = Wrappers.<MemberActivitySon>lambdaQuery()
                .eq(MemberActivitySon::getIsDel, CommonStatusEnum.EFFECTIVE.getCode())
                .in(MemberActivitySon::getSubjectId, activityIds);
        var sonMap = memberActivitySonMapper.selectList(sonWhereCondition)
                .stream().collect(groupingBy(MemberActivitySon::getSubjectId,
                        mapping(MemberActivitySon::convert2DTO, toList())));
        return activities.stream().peek(e -> e.sons = sonMap.get(e.activityId)).collect(toList());
    }

    /**
     * 获取子活动的活动地点
     *
     * @param activitySonIds 会员子活动的id集合
     * @return 会员子活动的地点集合
     */
    Map<String, List<ActivityPlace>> findAllMemberActivitySonPlace(List<String> activitySonIds) {

        if (CollectionUtils.isEmpty(activitySonIds)) {
            return Collections.emptyMap();
        }

        var placeWhereCondition = Wrappers.<ActivityPlace>lambdaQuery()
                .in(ActivityPlace::getActivityUid, activitySonIds);
        return activityPlaceMapper.selectList(placeWhereCondition).stream().collect(groupingBy(ActivityPlace::getActivityUid));
    }

    /**
     * 获取子活动的活动地点2
     *
     * @param activitySons 会员子活动集合
     * @return 会员子活动的地点集合
     */
    List<MemberActivitySonDTO> findAllMemberActivitySonPlace2(List<MemberActivitySonDTO> activitySons) {

        if (CollectionUtils.isEmpty(activitySons)) {
            return Collections.emptyList();
        }

        var sonIds = activitySons.stream().map(MemberActivitySonDTO::getActivityId).collect(toList());
        var placeWhereCondition = Wrappers.<ActivityPlace>lambdaQuery()
                .in(ActivityPlace::getActivityUid, sonIds);
        var placesMap = activityPlaceMapper.selectList(placeWhereCondition).stream().collect(groupingBy(ActivityPlace::getActivityUid));

        return activitySons.stream().peek(e -> placesMap.get(e.activityId)).collect(toList());
    }

    /**
     * 获取一个子活动
     *
     * @param activitySonId
     * @return
     */
    List<ActivityPlace> findOneMemberActivitySonPlace(String activitySonId) {

        if (activitySonId == null) {
            return Collections.emptyList();
        }

        var placeWhereCondition = Wrappers.<ActivityPlace>lambdaQuery()
                .eq(ActivityPlace::getActivityUid, activitySonId);
        return activityPlaceMapper.selectList(placeWhereCondition);
    }
/*

    void ddd(String memberId, CounterInformation counterInformation) throws ExecutionException, InterruptedException {

        //查询会员活动主表
        var memberActivities = this.findEffectiveMemberActivity();

        //查询会员活动子表
        var sonWhereCondition = Wrappers.<MemberActivitySon>lambdaQuery()
                .eq(MemberActivitySon::getIsDel, CommonStatusEnum.EFFECTIVE.getCode())
                .in(MemberActivitySon::getSubjectId, memberActivities.stream().map(MemberActivityDTO::getActivityId).collect(toList()));
        var memberSonActivities = memberActivitySonMapper.selectList(sonWhereCondition).stream().map(MemberActivitySon::convert2DTO).collect(toList());

        //查询会员搜索条件
        var searchTypeActivityIds = memberSonActivities.stream().filter(e -> e.activityObjectType.equals(ActivityEnum.ACTITY_OBJECT2.getKey())).map(MemberActivitySonDTO::getActivityId).collect(toList());
        var searchMemberRes = CompletableFuture.supplyAsync(() -> abstractActivityService.getSearchMemberRes(searchTypeActivityIds));

        //查询Excel导入
        var excelTypeActivityIds = memberSonActivities.stream().filter(e -> e.activityObjectType.equals(ActivityEnum.ACTITY_OBJECT3.getKey())).map(MemberActivitySonDTO::getActivityId).collect(toList());
        var excelImportMemberRes = CompletableFuture.supplyAsync(() -> abstractActivityService.getExcelImportMemberRes(searchTypeActivityIds));

        //查询会员地点
        var placeWhereCondition = Wrappers.<ActivityPlace>lambdaQuery()
                .in(ActivityPlace::getActivityUid, memberSonActivities.stream().map(MemberActivitySonDTO::getActivityId).collect(toList()));
        var activityPlaces = activityPlaceMapper.selectList(placeWhereCondition);


        var searchMember = searchMemberRes.get();
        var excelImport = excelImportMemberRes.get();

        List<MemberActivitySonDTO> collect = memberSonActivities.stream()
//                .filter(e -> ActivityMatchLogic.checkActivityPlace(e.getActivityPlaceType(), activityPlaces, counterInformation))
//                .filter(e -> ActivityMatchLogic.checkActivityObject(e.activityId, e.activityObjectType, memberId, searchMember, excelImport))
                .collect(toList());

    }
*/

}
