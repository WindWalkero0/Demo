package com.ruihe.app.dto.face.property;

public class OrgimageFaceLocation {
}
