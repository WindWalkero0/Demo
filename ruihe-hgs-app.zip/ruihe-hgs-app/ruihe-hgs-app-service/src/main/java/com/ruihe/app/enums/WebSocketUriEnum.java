package com.ruihe.app.enums;

/**
 * websocket消息推送业务uri
 *
 * @author William
 */
public enum WebSocketUriEnum {
    //
    SALE_REPORT_ORDER("sale", "admin首页-销售速报-单条数据"),
    SALE_REPORT_ACC("acc", "admin首页-销售速报-累计金额+数量"),
    INTEGRAL("int", "admin会员管理首页-积分速报-单条数据");

    private String code;
    private String msg;


    WebSocketUriEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
