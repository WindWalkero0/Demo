package com.ruihe.app.request;

import com.ruihe.common.annotation.FieldName;
import com.ruihe.common.pojo.request.promotion.SalesProductRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Api(value = "销售录入匹配促销活动接收类")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SalesRequest implements Serializable {

    @ApiModelProperty("商品集合")
    @FieldName(name = "商品集合")
    private List<SalesProductRequest> products;

    @ApiModelProperty("会员信息")
    @FieldName(name = "会员信息")
    private SalesMemberRequest memberRequest;

    @ApiModelProperty(value = "BA柜台编号")
    @FieldName(name = "BA柜台编号")
    public String counterId;

    @ApiModelProperty("【补录业务必填】业务发生时间，yyyy-MM-dd HH:mm:ss")
    private String bizTime;

    @ApiModelProperty("是否是会员")
    private Boolean flag;

    /**
     * 已匹配活动的集合
     */
    private List<String> ids;
}
