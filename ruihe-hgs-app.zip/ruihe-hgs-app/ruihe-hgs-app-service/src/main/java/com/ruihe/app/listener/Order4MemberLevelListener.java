package com.ruihe.app.listener;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.member.*;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.app.event.Order4MemberLevelEvent;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.service.member.MemberService;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.dao.bean.member.MemberLevel;
import com.ruihe.common.dao.bean.member.MemberLevelDownPo;
import com.ruihe.common.dao.bean.member.MemberLevelLog;
import com.ruihe.common.dao.bean.member.MemberLevelRulePo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.enums.status.CommonStatusEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 定时任务-根据销售金额处理会员降级
 *
 * @author 梁远
 * @Description
 * @create 2019-11-15 17:37
 */
@Slf4j
@Component
public class Order4MemberLevelListener {

    @Autowired
    private MemberLevelMapper memberLevelMapper;

    @Autowired
    private MemberLevelRuleMapper memberLevelRuleMapper;

    @Autowired
    private MemberLevelDownMapper memberLevelDownMapper;

    @Autowired
    private MemberLevelLogMapper memberLevelLogMapper;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private MemberService memberService;

    @Autowired
    private MemberMapper memberMapper;

    @Async(CommonConstant.POS_THREAD_POOL_NAME)
    @EventListener
    public void onApplicationEvent(Order4MemberLevelEvent event) {
        try {

            //获取会员id的list
            List<String> memberIdList = event.getMemberIdList();
            for (String memberId : memberIdList) {
                //根据会员id查询会员信息
                MemberInfo memberInfo = memberMapper.selectById(memberId);
                //记录此时会员的等级信息
                Integer memberLevel = memberInfo.getMemberLevel();
                //1、获取有效期为永久有效(为0的时候)的会员等级
                List<MemberLevel> memberLevelList = memberLevelMapper.selectList(Wrappers.<MemberLevel>lambdaQuery()
                        .eq(MemberLevel::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                        .eq(MemberLevel::getDuration, 0));
                //2、获取等级编码列表
                List<String> codeList = memberLevelList.stream().map(MemberLevel::getLevelCode).collect(Collectors.toList());
                //3、如果包含会员的当前等级级别，则不用进行降级处理
                if (codeList.contains(memberInfo.getMemberLevelCode())) {
                    return;
                }
                //4、根据当前会员等级，查询升降级规则
                MemberLevelRulePo memberLevelRulePo = memberLevelRuleMapper.selectOne(Wrappers.<MemberLevelRulePo>lambdaQuery()
                        .eq(MemberLevelRulePo::getLevelCode, memberInfo.getMemberLevelCode())
                        .eq(MemberLevelRulePo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                        .ge(MemberLevelRulePo::getEndTime, LocalDateTime.now())
                        .le(MemberLevelRulePo::getStartTime, LocalDateTime.now()));
                if (memberLevelRulePo == null) {
                    //如果在该时间段内没有对应的升降级数据，则不处理，直接返回
                    return;
                }
                //5、根据主表查询降级规则,并按照等级降级排序
                List<MemberLevelDownPo> downPoList = memberLevelDownMapper.selectList(Wrappers.<MemberLevelDownPo>lambdaQuery()
                        .eq(MemberLevelDownPo::getRuleId, memberLevelRulePo.getRuleId())
                        .orderByDesc(MemberLevelDownPo::getAfterLevel));
                if (downPoList == null || downPoList.isEmpty()) {
                    //如果该等级不存在降级规则，直接返回
                    return;
                }
                //6、判断降级后等级
                for (MemberLevelDownPo memberLevelDownPo : downPoList) {
                    //1)获取当前等级的开始时间，有可能查询出多个，需要取最近的一个
                    MemberLevelLog memberLevelLog = memberLevelLogMapper.selectOne(Wrappers.<MemberLevelLog>lambdaQuery()
                            .eq(MemberLevelLog::getMemberId, memberInfo.getMemberId())
                            .eq(MemberLevelLog::getLevelAfter, memberLevelRulePo.getLevel())
                            .eq(MemberLevelLog::getStatus, CommonStatusEnum.EFFECTIVE.getCode()));
                    //2)查询订单：会员手机号、订单时间范围、是否包含首单（此处查询结果可能会为空）,此处直接用会员信息中的等级时间
                    LambdaQueryWrapper<PosOrderPo> queryWrapper = Wrappers.<PosOrderPo>lambdaQuery()
                            .eq(PosOrderPo::getMemberId, memberInfo.getMemberId())
                            .gt(PosOrderPo::getCreateTime, memberInfo.getLevelStartTime())
                            .lt(PosOrderPo::getCreateTime, memberInfo.getLevelEndTime());
                    if (memberLevelLog != null && StringUtils.isNotBlank(memberLevelLog.getOddNumbers()) && memberLevelDownPo.getIncludeFirst().equals(CommonStatusEnum.EFFECTIVE.getCode())) {
                        //如果会员升降级等级记录不为空，则进行首单判断
                        queryWrapper.or().eq(PosOrderPo::getOrderNo, memberLevelLog.getOddNumbers());
                    }
                    List<PosOrderPo> posOrderPoList = posOrderMapper.selectList(queryWrapper);
                    if (!posOrderPoList.isEmpty()) {
                        //3）获取支付总金额
                        BigDecimal payTotalAmt = posOrderPoList.stream().map(e -> {
                            if (e.getTransType().equals(OrderTransTypeEnum.GOODS_RETURN.getCode())) {
                                return e.getRealAmt().abs().negate();
                            } else {
                                return e.getRealAmt().abs();
                            }
                        }).reduce(BigDecimal::add).get();
                        //4）如果支付金额小于设置累计金额
                        if (payTotalAmt.compareTo(memberLevelDownPo.getAccAmt()) < 0) {
                            //填充会员信息
                            fillMemberInfo(memberInfo, memberLevelDownPo);
                            //处理等级信息
                            memberService.changeMemberLevel(memberLevelRulePo, memberInfo, memberLevelDownPo.getDescription());
                            //结束循环
                            break;
                        }
                    } else {
                        //5）没有支付记录，说明需要降级处理
                        fillMemberInfo(memberInfo, memberLevelDownPo);
                        //处理等级信息
                        memberService.changeMemberLevel(memberLevelRulePo, memberInfo, memberLevelDownPo.getDescription());
                        //结束循环
                        break;
                    }
                }
                //7、等级遍历结束之后，查看当前会员等级与遍历之后的会员信息中的等级是否一致
                if (memberLevel.equals(memberInfo.getMemberLevel())) {
                    //说明会员满足保级的条件，先将会员信息进行修改（等级时间更新）
                    updateMemberInfo(memberInfo);
                    //对等级履历进行填充修改
                    memberService.updateRelegationMemberInfo(memberInfo);
                }
            }
        } catch (Exception e) {
            log.error("会员等级到期处理异常，event{}", JSON.toJSONString(event), e);
        }
    }

    /**
     * 更新保级的会员信息
     *
     * @param memberInfo
     */
    private void updateMemberInfo(MemberInfo memberInfo) {
        //根据会员等级查询出等级信息
        MemberLevel memberLevel = memberLevelMapper.selectOne(Wrappers.<MemberLevel>lambdaQuery()
                .eq(MemberLevel::getLevelCode, memberInfo.getMemberLevelCode()));
        //填充会员信息
        memberInfo.setMemberLevel(memberLevel.getLevel());
        memberInfo.setMemberLevelCode(memberLevel.getLevelCode());
        memberInfo.setMemberLevelName(memberLevel.getLevelName());
        //等级时间起====上次等级结束时间
        memberInfo.setLevelStartTime(memberInfo.getLevelEndTime());
        //等级时间止====上次等级结束时间+有效期
        memberInfo.setLevelEndTime(memberLevel.getDuration() == 0 ? parseTime() : memberInfo.getLevelEndTime().plusMonths(memberLevel.getDuration()));
        memberInfo.setUpdateTime(LocalDateTime.now());
    }

    /**
     * 填充会员信息
     *
     * @param memberInfo
     * @param memberLevelDownPo
     */
    private void fillMemberInfo(MemberInfo memberInfo, MemberLevelDownPo memberLevelDownPo) {
        //查询等级信息
        MemberLevel memberLevel = memberLevelMapper.selectOne(Wrappers.<MemberLevel>lambdaQuery()
                .eq(MemberLevel::getLevelCode, memberLevelDownPo.getAfterLevelCode()));
        //填充会员信息
        memberInfo.setMemberLevel(memberLevelDownPo.getAfterLevel());
        memberInfo.setMemberLevelCode(memberLevelDownPo.getAfterLevelCode());
        memberInfo.setMemberLevelName(memberLevelDownPo.getAfterLevelName());
        //等级时间起====上次等级结束时间
        memberInfo.setLevelStartTime(memberInfo.getLevelEndTime());
        //等级时间止====上次等级结束时间+有效期
        memberInfo.setLevelEndTime(memberLevel.getDuration() == 0 ? parseTime() : memberInfo.getLevelEndTime().plusMonths(memberLevel.getDuration()));
        memberInfo.setUpdateTime(LocalDateTime.now());
    }

    /**
     * 获取结束时间
     *
     * @return
     */
    private LocalDateTime parseTime() {
        return LocalDateTime.parse("9999-12-31 00:00:00", DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

}
