package com.ruihe.app.service.order.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.app.mapper.warehouse.*;
import com.ruihe.app.request.PosLadingOrderRequest;
import com.ruihe.app.request.PosLadingRefundRequest;
import com.ruihe.app.service.order.PosLadingOrderService;
import com.ruihe.app.service.u8.U8MQProducer;
import com.ruihe.app.vo.PosLadingOrderItemListVo;
import com.ruihe.app.vo.PosLadingOrderItemVo;
import com.ruihe.app.vo.PosLadingOrderVo;
import com.ruihe.app.vo.u8.*;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.order.PosLadingOrderItemPo;
import com.ruihe.common.dao.bean.order.PosLadingOrderPo;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.dao.bean.warehouse.WhFreeInventoryItemPo;
import com.ruihe.common.dao.bean.warehouse.WhFreeInventoryPo;
import com.ruihe.common.dao.bean.warehouse.WhReturnItemPo;
import com.ruihe.common.dao.bean.warehouse.WhReturnPo;
import com.ruihe.common.dao.bean.warehouse.WhStockPo;
import com.ruihe.common.dao.bean.warehouse.WhTransferItemPo;
import com.ruihe.common.dao.bean.warehouse.WhTransferPo;
import com.ruihe.common.dao.bean.warehouse.WhU8ConfirmLogPo;
import com.ruihe.common.enums.base.CounterEnum;
import com.ruihe.app.constant.U8DocumentTypeConfig;
import com.ruihe.app.constant.U8ReceivedConfig;
import com.ruihe.app.constant.U8WareHouseConfig;
import com.ruihe.app.enums.OrderNoPrefixEnum;
import com.ruihe.app.enums.PosLadingOrderStatusEnum;
import com.ruihe.app.event.LadingOrderLadeEvent;
import com.ruihe.app.event.LadingOrderLadeReturnEvent;
import com.ruihe.app.mapper.basic.CounterMapper;
import com.ruihe.app.mapper.basic.ProductMapper;
import com.ruihe.app.mapper.member.MemberMapper;
import com.ruihe.app.mapper.order.PosLadingOrderItemMapper;
import com.ruihe.app.mapper.order.PosLadingOrderMapper;
import com.ruihe.app.mapper.order.PosOrderItemMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.app.request.PosLadingOrderItemRequest;
import com.ruihe.app.request.order.PosRsvOrderQueryRequest;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.common.pojo.PageVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static java.util.regex.Pattern.compile;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author ly
 * @since 2019-10-19
 */
@Service
@Slf4j
public class PosLadingLadingOrderServiceImpl implements PosLadingOrderService, ApplicationContextAware {
    @Autowired
    private PosLadingOrderMapper posLadingOrderMapper;

    @Autowired
    private PosLadingOrderItemMapper posLadingOrderItemMapper;

    @Autowired
    private PosOrderItemMapper posOrderItemMapper;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private CounterMapper counterMapper;

    @Autowired
    private WhStockMapper whStockMapper;

    @Autowired
    private U8MQProducer u8MQProducer;

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private WhReturnItemMapepr whReturnItemMapepr;

    @Autowired
    private WhReturnMapper whReturnMapper;

    @Autowired
    private WhTransferMapper whTransferMapper;

    @Autowired
    private WhFreeInventoryMapper whFreeInventoryMapper;

    @Autowired
    private WhFreeInventoryItemMapper whFreeInventoryItemMapper;

    @Autowired
    private WhTransferItemMapper whTransferItemMapper;

    @Autowired
    private WhU8ConfirmLogMapper whU8ConfirmLogMapper;

    private ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    /**
     * 预订单提取
     *
     * @param request
     * @return
     */
    @Override
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response lade(PosLadingOrderRequest request) throws BizException {
        Pattern pattern = compile("^[1]\\d{10}$");
        if (request.getMemberPhone() != null && !request.getMemberPhone().isEmpty() && !pattern.matcher(request.getMemberPhone()).matches()) {
            return Response.errorMsg("手机号码格式有误,请核对后重试!");
        }
        //根据订单号获取预订单
        LambdaQueryWrapper<PosOrderPo> wrapper = Wrappers.<PosOrderPo>lambdaQuery().eq(PosOrderPo::getOrderNo, request.getOrderNo());
        PosOrderPo posOrderPo = posOrderMapper.selectOne(wrapper);
        if (posOrderPo == null) {
            return Response.errorMsg("根据订单号未查询到订单信息!");
        }
        //根据订单号查询预订单详情
        List<PosOrderItemPo> posOrderItemPos = posOrderItemMapper.selectList(Wrappers.<PosOrderItemPo>lambdaQuery()
                .eq(PosOrderItemPo::getOrderNo, request.getOrderNo())
                //取货的时候优先取带活动的（带活动的id不为空或者0）  退货的时候  优先退不带活动的
                .orderByDesc(PosOrderItemPo::getActivityId));
        if (posOrderItemPos.isEmpty()) {
            return Response.errorMsg("根据订单号未查询到订单信息!");
        }
        //获取提取主表信息
        PosLadingOrderPo posLadingOrderPo = this.extractPosLadingOrderPo(request, posOrderPo);
        if (StringUtils.isNotBlank(request.getMemberId())) {
            posLadingOrderPo.setMemberId(request.getMemberId());
            posLadingOrderPo.setMemberName(posOrderPo.getMemberName());
        }
        //获取提取详情
        List<PosLadingOrderItemRequest> posLadingOrderItemRequestList = request.getPosLadingOrderItemRequestList();
        if (org.springframework.util.ObjectUtils.isEmpty(posLadingOrderItemRequestList)) {
            return Response.errorMsg("提取列表为空!");
        }
        //判断提取列表中不能含有虚拟商品
        for (PosLadingOrderItemRequest posLadingOrderItemRequest : posLadingOrderItemRequestList) {
            Product product = productMapper.selectById(posLadingOrderItemRequest.getPrdBarCode());
            if (product == null) {
                return Response.errorMsg("不能有虚拟商品" + "“" + posLadingOrderItemRequest.getPrdName() + "”!");
            }
        }
        //获取提取总数
        posLadingOrderPo.setLadingQty(posLadingOrderItemRequestList.stream().mapToInt(PosLadingOrderItemRequest::getLadingQty).sum());
        //提取详情表中的barCode和数量的map，详情表中的产品编码不会存在重复的情况
        Map<String, Integer> collect = posLadingOrderItemRequestList.stream().collect(Collectors.toMap(PosLadingOrderItemRequest::getPrdBarCode, PosLadingOrderItemRequest::getLadingQty));
        List<PosOrderItemPo> posOrderItemPosForU8 = new ArrayList<>();
        //根据夏宇飞要求，对库存进行判断，不抛异常
        for (PosOrderItemPo posOrderItemPo : posOrderItemPos) {
            Integer qty = collect.get(posOrderItemPo.getPrdBarCode());
            //如果没有数据，则继续循环
            if (qty == null || qty.equals(0)) {
                continue;
            }
            //首先查询该柜台下的产品库存是否充足
            WhStockPo whStockPo = whStockMapper.selectOne(Wrappers.<WhStockPo>lambdaQuery()
                    .select(WhStockPo::getStock)
                    .eq(WhStockPo::getPrdBarCode, posOrderItemPo.getPrdBarCode())
                    .eq(WhStockPo::getCounterId, posOrderItemPo.getCounterId()));
            if (whStockPo == null || whStockPo.getStock() < qty) {
                if(request.getCheckStock()) {
                    return Response.errorMsg(posOrderItemPo.getPrdName() + "库存不足，无法提货!");
                }
            }
        }
        //循环预订单子表，对剩余数量进行更新
        for (PosOrderItemPo posOrderItemPo : posOrderItemPos) {
            PosOrderItemPo posOrderItemPoForU8 = new PosOrderItemPo();
            BeanUtils.copyProperties(posOrderItemPo, posOrderItemPoForU8);
            Integer qty = collect.get(posOrderItemPo.getPrdBarCode());
            //如果没有数据，则继续循环
            if (qty == null || qty.equals(0)) {
                continue;
            }
            /*//首先查询该柜台下的产品库存是否充足
            WhStockPo whStockPo = whStockMapper.selectOne(Wrappers.<WhStockPo>lambdaQuery()
                    .select(WhStockPo::getStock)
                    .eq(WhStockPo::getPrdBarCode, posOrderItemPo.getPrdBarCode())
                    .eq(WhStockPo::getCounterId, posOrderItemPo.getCounterId()));
            if (whStockPo == null || whStockPo.getStock() < qty) {
                log.error("库存不足，无法提货!,request={},whStockPo={}", request, whStockPo);
                throw new BizException("库存不足，无法提货!");
            }*/
            //如果有数据，则进行数据操作
            if (qty >= posOrderItemPo.getSurplusQty()) {
                qty = qty - posOrderItemPo.getSurplusQty();
                collect.put(posOrderItemPo.getPrdBarCode(), qty);
                posOrderItemPo.setSurplusQty(0);
                posOrderItemPoForU8.setPurQty(posOrderItemPoForU8.getSurplusQty());
            } else {
                posOrderItemPo.setSurplusQty(posOrderItemPo.getSurplusQty() - qty);
                collect.put(posOrderItemPo.getPrdBarCode(), 0);
                posOrderItemPoForU8.setPurQty(qty);
            }
            posOrderItemPo.setUpdateTime(LocalDateTime.now());
            //更新预订单子表信息
            Integer rows = posOrderItemMapper.update(posOrderItemPo, Wrappers.<PosOrderItemPo>lambdaUpdate()
                    .eq(PosOrderItemPo::getOrderNo, request.getOrderNo())
                    .eq(PosOrderItemPo::getPrdBarCode, posOrderItemPo.getPrdBarCode())
                    .eq(PosOrderItemPo::getActivityId, posOrderItemPo.getActivityId())
                    .eq(PosOrderItemPo::getDiscernType, posOrderItemPo.getDiscernType()));
            if (rows.equals(0)) {
                log.error("提取失败!request={},posOrderItemPo={}", request, posOrderItemPo);
                throw new BizException("提取失败!");
            }
            posOrderItemPosForU8.add(posOrderItemPoForU8);
        }
        //获取详情表，并进行批量插入
        List<PosLadingOrderItemPo> posLadingOrderItemPoList = this.extractPosLadingOrderItemPoList(request.getOrderNo(), posLadingOrderItemRequestList, posLadingOrderPo);
        Integer rows = posLadingOrderItemMapper.batchInsert(posLadingOrderItemPoList);
        if (rows != posLadingOrderItemPoList.size()) {
            log.error("提取失败!,posLadingOrderItemPoList={},rows={}", posLadingOrderItemPoList, rows);
            throw new BizException("提取失败!");
        }
        //如果是最后一次就是减法
        BigDecimal apportionAmt;
        //当前销售总额
        BigDecimal extractSum = BigDecimal.ZERO;
        //预订单销售总额
        BigDecimal orderAmt = posOrderPo.getOrderAmt();
        //总优惠金额
        BigDecimal discountAmt = posOrderPo.getDiscountAmt();
        if (posOrderPo.getSurplusQty() - posLadingOrderPo.getLadingQty() == 0) {
            //最后一次的分摊金额就是之前总分摊的金额减去所有的分摊金额之和
            List<PosLadingOrderPo> posLadingOrderPos = posLadingOrderMapper.selectList(Wrappers.<PosLadingOrderPo>lambdaQuery()
                    .eq(PosLadingOrderPo::getOrderNo, posOrderPo.getOrderNo())
                    .eq(PosLadingOrderPo::getStatus, PosLadingOrderStatusEnum.LADED.getCode()));
            for (PosLadingOrderPo ladingOrderPo : posLadingOrderPos) {
                //计算出前几次提货所分摊的总额
                extractSum = extractSum.add(ladingOrderPo.getApportionAmt() == null ? BigDecimal.ZERO : ladingOrderPo.getApportionAmt());
            }
            //获取最后一次分摊总额
            apportionAmt = discountAmt.abs().subtract(extractSum);
        } else {
            for (PosLadingOrderItemPo posLadingOrderItemPo : posLadingOrderItemPoList) {
                //计算出本次提取的商品的总额
                extractSum = extractSum.add(posLadingOrderItemPo.getMemberPrice().multiply(new BigDecimal(posLadingOrderItemPo.getLadingQty())));
            }
            //分摊金额就是当前销售总额 占总销售额的比例 乘以总优惠金额
            BigDecimal amt = extractSum.divide(orderAmt, 2, RoundingMode.HALF_UP);
            apportionAmt = amt.multiply(discountAmt).abs();
        }
        posLadingOrderPo.setApportionAmt(apportionAmt);
        //插入提取主表
        Integer rows1 = posLadingOrderMapper.insert(posLadingOrderPo);
        if (rows1.equals(0)) {
            log.error("提取失败!posLadingOrderPo={}", posLadingOrderPo);
            throw new BizException("提取失败!");
        }
        //更新预订单表中库存
        PosOrderPo updatePosOrderPo = PosOrderPo.builder()
                .surplusQty(posOrderPo.getSurplusQty() - posLadingOrderPo.getLadingQty())
                .lastPickUpTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now()).build();
        if (updatePosOrderPo.getSurplusQty() < 0) {
            if(request.getCheckStock()){
                log.error("提取数量大于库存数量,提取失败!request={},qt={}", request, updatePosOrderPo.getSurplusQty());
                throw new BizException("提取数量大于库存数量,提取失败!");
            }else{
                updatePosOrderPo.setSurplusQty(00);
            }

        }
        Integer rows2 = posOrderMapper.update(updatePosOrderPo, Wrappers.<PosOrderPo>lambdaUpdate().eq(PosOrderPo::getOrderNo, request.getOrderNo()));
        if (rows2.equals(0)) {
            log.error("提取失败!request={},updatePosOrderPo={}", request, updatePosOrderPo);
            throw new BizException("提取失败!");
        }
        /**
         * 对库存进行相应的更新（2020-03-05 09:49与产品经理确认，无论自营还是加盟，都需要扣减库存）
         */
        LadingOrderLadeEvent ladingOrderLadeEvent = new LadingOrderLadeEvent(this, posLadingOrderPo.getLadingOrderNo());
        applicationContext.publishEvent(ladingOrderLadeEvent);

        //预订单提货同步到u8
        boolean check = check(posOrderPo);
        if (check) {
            U8ShipmentsVo u8ShipmentsVo = this.buildSaleOrder(posLadingOrderPo, posOrderItemPosForU8);
            u8MQProducer.saveLog(u8ShipmentsVo.getPoscode());
            u8MQProducer.sendMessageToU8(u8ShipmentsVo, U8DocumentTypeConfig.SASEND_ADD);
        }
        return Response.success();
    }

    /**
     * 构建提取子表列表
     *
     * @param orderNo
     * @param requestList
     * @param posLadingOrderPo
     * @return
     */
    private List<PosLadingOrderItemPo> extractPosLadingOrderItemPoList(String orderNo, List<PosLadingOrderItemRequest> requestList, PosLadingOrderPo posLadingOrderPo) {
        return requestList.stream().map(e -> {
            //根据产品条码查询产品信息
            PosOrderItemPo posOrderItemPo = posOrderItemMapper.selectOne(Wrappers.<PosOrderItemPo>lambdaQuery()
                    .eq(PosOrderItemPo::getPrdBarCode, e.getPrdBarCode())
                    .eq(PosOrderItemPo::getOrderNo, orderNo)
                    .last(" limit 1"));
            PosLadingOrderItemPo posLadingOrderItemPo = PosLadingOrderItemPo.builder()
                    .orderNo(posLadingOrderPo.getOrderNo())
                    .ladingOrderNo(posLadingOrderPo.getLadingOrderNo())
                    .prdPrice(posOrderItemPo.getPrdPrice())
                    .memberPrice(posOrderItemPo.getMemberPrice())
                    .bigCatCode(posOrderItemPo.getBigCatCode())
                    .bigCatName(posOrderItemPo.getBigCatName())
                    .mediumCatCode(posOrderItemPo.getMediumCatCode())
                    .mediumCatName(posOrderItemPo.getMediumCatName())
                    .smallCatCode(posOrderItemPo.getSmallCatCode())
                    .smallCatName(posOrderItemPo.getSmallCatName())
                    .prdBarCode(e.getPrdBarCode())
                    .goodsBarCode(e.getGoodsBarCode())
                    .prdName(e.getPrdName())
                    .ladingQty(e.getLadingQty())
                    .createTime(LocalDateTime.now())
                    .updateTime(LocalDateTime.now()).build();
            return posLadingOrderItemPo;
        }).collect(Collectors.toList());
    }

    /**
     * 构建保存时候的提货订单
     *
     * @param request
     * @param posOrderPo
     * @return
     */
    private PosLadingOrderPo extractPosLadingOrderPo(PosLadingOrderRequest request, PosOrderPo posOrderPo) {
        return PosLadingOrderPo.builder()
                .orderNo(request.getOrderNo())
                .ladingOrderNo(IdGenerator.getShorterSerialNo(OrderNoPrefixEnum.DGMP.getCode()))
                .status(PosLadingOrderStatusEnum.LADED.getCode())
                .orderTime(posOrderPo.getCreateTime())
                .baCode(request.getBaCode())
                .baName(request.getBaName())
                //此处将提取数量设置为0，实际提取数量在之后进行计算
                .ladingQty(0)
                .receiptNo(posOrderPo.getReceiptNo())
                .counterId(posOrderPo.getCounterId())
                .baCode(request.getBaCode())
                .baName(request.getBaName())
                .orderChanCode(posOrderPo.getOrderChanCode())
                .orderChanName(posOrderPo.getOrderChanName())
                .memberPhone(request.getMemberPhone())
                .counterName(posOrderPo.getCounterName())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
    }

    /**
     * 查询会员提货单列表
     *
     * @param request
     * @return
     */
    @Override
    public Response ladingList(PosRsvOrderQueryRequest request) {
        //手机号判断
        Pattern pattern = compile("^[1]\\d{10}$");
        if (request.getMemberPhone() != null && !request.getMemberPhone().isEmpty() && !pattern.matcher(request.getMemberPhone()).matches()) {
            return Response.errorMsg("手机号码格式有误,请核对后重试!");
        }
        //判断时间问题
        if (request.getStartTime() != null && request.getEndTime() != null && request.getEndTime().isBefore(request.getStartTime())) {
            return Response.errorMsg("结束时间不能大于开始时间!");
        }
        //进行查询
        LambdaQueryWrapper<PosLadingOrderPo> queryWrapper = Wrappers.<PosLadingOrderPo>lambdaQuery()
                .eq(PosLadingOrderPo::getCounterId, request.getCounterId())
                //现在是退货的时候多插了一组   那么在查单退货的时候 不展示存在有关联退货单的订单
                .isNull(PosLadingOrderPo::getAssociatedNo)
                //根据预定日期和提货日期进行降序
                .orderByDesc(PosLadingOrderPo::getOrderTime)
                .orderByDesc(PosLadingOrderPo::getCreateTime);
        if (StringUtils.isNotBlank(request.getMemberId())) {
            queryWrapper.eq(PosLadingOrderPo::getMemberId, request.getMemberId());
        }
        if (StringUtils.isNotBlank(request.getMemberPhone())) {
            queryWrapper.eq(PosLadingOrderPo::getMemberPhone, request.getMemberPhone());
        }
        if (request.getStartTime() != null) {
            queryWrapper.ge(PosLadingOrderPo::getCreateTime, request.getStartTime());
        }
        if (request.getEndTime() != null) {
            queryWrapper.lt(PosLadingOrderPo::getCreateTime, request.getEndTime().plusDays(1));
        }
        //分页
        Page<PosLadingOrderPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        //查询
        IPage<PosLadingOrderPo> posLadingOrderIPage = posLadingOrderMapper.selectPage(page, queryWrapper);
        List<PosLadingOrderPo> posLadingOrderPos = posLadingOrderIPage.getRecords();
        if (posLadingOrderPos.isEmpty()) {
            return Response.successMsg("暂无数据!");
        }
        //转换page对象
        PageVO pageVO = PageVO.<PosLadingOrderVo>builder()
                .list(ObjectUtils.toList(posLadingOrderPos, PosLadingOrderVo.class))
                .pageNum(posLadingOrderIPage.getCurrent())
                .pageSize(posLadingOrderIPage.getSize())
                .pages(posLadingOrderIPage.getPages())
                .total(posLadingOrderIPage.getTotal())
                .build();
        return Response.success(pageVO);
    }

    /**
     * 查询提货/退货单明细
     *
     * @param ladingOrderNo
     * @return
     */
    @Override
    public Response ladingItem(String ladingOrderNo) {
        //查询主表信息
        PosLadingOrderPo posLadingOrderPo = posLadingOrderMapper.selectOne(Wrappers.<PosLadingOrderPo>lambdaQuery()
                .eq(PosLadingOrderPo::getLadingOrderNo, ladingOrderNo));
        //查询子表信息
        List<PosLadingOrderItemPo> list = posLadingOrderItemMapper.selectList(Wrappers.<PosLadingOrderItemPo>lambdaQuery()
                .eq(PosLadingOrderItemPo::getLadingOrderNo, ladingOrderNo));
        if (list.isEmpty()) {
            //主表显示有数据，而查询却没有结果
            return Response.successMsg("未查询到数据,请刷新重试!");
        }
        PosLadingOrderItemVo itemVo = PosLadingOrderItemVo.builder().itemListVoList(ObjectUtils.toList(list, PosLadingOrderItemListVo.class)).build();
        itemVo.setUserId(posLadingOrderPo.getBaCode());
        itemVo.setUserName(posLadingOrderPo.getBaName());
        return Response.success(itemVo);
    }

    /**
     * 提货单退货
     *
     * @param request
     * @return 假如用户下了一笔3件商品的预订单，后来第一次来提货了2件，过了2天又通过提货退货入口把这2件商品给退货了，那用户的预订单剩余可提还是3件
     */
    @Override
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response refund(PosLadingRefundRequest request) throws BizException {
        //查询条件
        LambdaQueryWrapper<PosLadingOrderItemPo> queryWrapper = Wrappers.<PosLadingOrderItemPo>lambdaQuery()
                .eq(PosLadingOrderItemPo::getLadingOrderNo, request.getLadingOrderNo());
        List<PosLadingOrderItemPo> posLadingOrderItemPos = posLadingOrderItemMapper.selectList(queryWrapper);
        String orderNo = IdGenerator.getShorterSerialNo(OrderNoPrefixEnum.RGMP.getCode());
        for (int i = 0; i < posLadingOrderItemPos.size(); i++) {
            PosLadingOrderItemPo posLadingOrderItemPo = posLadingOrderItemPos.get(i);
            posLadingOrderItemPo.setLadingOrderNo(orderNo);
        }
        Integer rows = posLadingOrderItemMapper.batchInsert(posLadingOrderItemPos);
        if (rows.equals(0)) {
            log.error("退货失败!request={},posLadingOrderItemPos={}", request, posLadingOrderItemPos);
            throw new BizException("退货失败!");
        }
        //2、根据ID更新提货单表
        //2020年5月6日11:31:45   删除了refundBaName refundBaCode
        LambdaUpdateWrapper<PosLadingOrderPo> wrapperOld = Wrappers.<PosLadingOrderPo>lambdaUpdate().eq(PosLadingOrderPo::getLadingOrderNo, request.getLadingOrderNo());
        PosLadingOrderPo posLadingOrderPoOld = PosLadingOrderPo.builder()
                .associatedNo(orderNo)
                .updateTime(LocalDateTime.now()).build();
        rows = posLadingOrderMapper.update(posLadingOrderPoOld, wrapperOld);
        //现在是退货的时候多插了一组   那么在查单退货的时候 不展示存在有关联退货单的订单
        if (rows.equals(0)) {
            log.error("退货失败!request={},posLadingOrderPoOld={}", request, posLadingOrderPoOld);
            throw new BizException("退货失败!");
        }
        LambdaUpdateWrapper<PosLadingOrderPo> wrapper = Wrappers.<PosLadingOrderPo>lambdaUpdate().eq(PosLadingOrderPo::getLadingOrderNo, request.getLadingOrderNo());
        PosLadingOrderPo posLadingOrderPo = posLadingOrderMapper.selectOne(wrapper);
        posLadingOrderPo.setStatus(PosLadingOrderStatusEnum.REFUND.getCode());
        posLadingOrderPo.setBaCode(request.getBaCode());
        posLadingOrderPo.setBaName(request.getBaName());
        posLadingOrderPo.setLadingOrderNo(orderNo);
        posLadingOrderPo.setAssociatedNo(null);
        posLadingOrderPo.setCreateTime(LocalDateTime.now());
        posLadingOrderPo.setUpdateTime(LocalDateTime.now());
        rows = posLadingOrderMapper.insert(posLadingOrderPo);
        if (rows.equals(0)) {
            log.error("退货失败!request={},posLadingOrderPo={}", request, posLadingOrderPo);
            throw new BizException("退货失败!");
        }
        //3、更新订单主子表的剩余数量信息
        PosOrderPo posOrderPo = this.extractPosOrderPo(request);
        rows = posOrderMapper.updateById(posOrderPo);
        if (rows.equals(0)) {
            log.error("退货失败!request={},posOrderPo={}", request, posOrderPo);
            throw new BizException("退货失败!");
        }
        Map<String, List<PosOrderItemPo>> posOrderItemPoMap = this.extractPosOrderItemPoList(request);
        rows = posOrderItemMapper.batchUpdate(posOrderItemPoMap.get("list"));
        if (rows.equals(0)) {
            log.error("退货失败!request={},list={}", request, posOrderItemPoMap.get("list"));
            throw new BizException("退货失败!");
        }
        //4、根据柜台的ID和商品信息对库存进行更新（2020-03-05 09:49与产品经理确认，无论自营还是加盟，都需要扣减库存）
        LadingOrderLadeReturnEvent ladingOrderLadeReturnEvent = new LadingOrderLadeReturnEvent(this, orderNo);
        applicationContext.publishEvent(ladingOrderLadeReturnEvent);

        //同步给u8
        boolean check = check(posOrderPo);
        if (check) {
            U8GoodsReturnVo u8GoodsReturnVo = this.buildReturnOrder(posLadingOrderPo, posOrderItemPoMap.get("listForU8"));
            u8MQProducer.saveLog(u8GoodsReturnVo.getPoscode());
            u8MQProducer.sendMessageToU8(u8GoodsReturnVo, U8DocumentTypeConfig.RO_ADD);
        }
        return Response.successMsg("退货成功!");
    }

    /**
     * 获取订单子表信息
     *
     * @param request
     * @return
     */
    private Map<String, List<PosOrderItemPo>> extractPosOrderItemPoList(PosLadingRefundRequest request) {
        //根据提货单号获取提货单子表信息
        List<PosLadingOrderItemPo> posLadingOrderItemPoList = posLadingOrderItemMapper.selectList(Wrappers.<PosLadingOrderItemPo>lambdaQuery()
                .eq(PosLadingOrderItemPo::getLadingOrderNo, request.getLadingOrderNo()));
        //预订单提取详情表中的产品数据不会重复
        Map<String, Integer> barCodeList = posLadingOrderItemPoList.stream().collect(Collectors.toMap(PosLadingOrderItemPo::getPrdBarCode, PosLadingOrderItemPo::getLadingQty));
        //根据订单号查询预订单子表
        List<PosOrderItemPo> posOrderItemPoList = posOrderItemMapper.selectList(Wrappers.<PosOrderItemPo>lambdaQuery()
                //取货的时候优先取带活动的  退货的时候  优先退不带活动的(ActivityId为0的时候没活动)
                .eq(PosOrderItemPo::getOrderNo, request.getOrderNo()).orderByAsc(PosOrderItemPo::getActivityId));

        //根据产品编号去重(此处暂时不考虑提货的产品问题)
//        List<PosOrderItemPo> posOrderItemPos = posOrderItemPoList.stream().collect(
//                Collectors.collectingAndThen(Collectors.toCollection(() ->
//                        new TreeSet<>(Comparator.comparing(o -> o.getPrdBarCode()))), ArrayList::new));
        //返回数据
        List<PosOrderItemPo> posOrderItemPoListForU8 = new ArrayList<>();
        //优先返回的是参与活动的商品
        List<PosOrderItemPo> list = new ArrayList<>();
        //循环更新数据
        for (PosOrderItemPo posOrderItemPo : posOrderItemPoList) {
            PosOrderItemPo posOrderItemPoForU8 = new PosOrderItemPo();
            BeanUtils.copyProperties(posOrderItemPo, posOrderItemPoForU8);
            Integer integer = barCodeList.get(posOrderItemPo.getPrdBarCode());
            if (integer == null || integer.equals(0)) {
                continue;
            }
            if (posOrderItemPo.getPurQty().equals(posOrderItemPo.getSurplusQty())) {
                continue;
            }
            Integer purQty = posOrderItemPo.getPurQty();
            Integer surplusQty = posOrderItemPo.getSurplusQty();
            if (purQty - surplusQty <= integer) {
                posOrderItemPo.setSurplusQty(purQty);
                posOrderItemPo.setUpdateTime(LocalDateTime.now());
                barCodeList.put(posOrderItemPo.getPrdBarCode(), integer - purQty + surplusQty);
                posOrderItemPoForU8.setPurQty(purQty - surplusQty);
            } else {
                posOrderItemPo.setSurplusQty(posOrderItemPo.getSurplusQty() + integer);
                posOrderItemPo.setUpdateTime(LocalDateTime.now());
                posOrderItemPoForU8.setPurQty(integer);
            }
            list.add(posOrderItemPo);
            posOrderItemPoListForU8.add(posOrderItemPoForU8);
        }
        Map<String, List<PosOrderItemPo>> map = new HashMap<>();
        map.put("list", list);
        map.put("listForU8", posOrderItemPoListForU8);
        return map;
    }

    /**
     * 获取订单主表信息
     *
     * @param request
     * @return
     */
    private PosOrderPo extractPosOrderPo(PosLadingRefundRequest request) {
        //根据提货单号获取提货单主表信息
        PosLadingOrderPo posLadingOrderPo = posLadingOrderMapper.selectOne(Wrappers.<PosLadingOrderPo>lambdaQuery()
                .eq(PosLadingOrderPo::getLadingOrderNo, request.getLadingOrderNo()));
        //根据订单号查询预订单主表
        PosOrderPo posOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery()
                .eq(PosOrderPo::getOrderNo, request.getOrderNo()));
        posOrderPo.setSurplusQty(posOrderPo.getSurplusQty() + posLadingOrderPo.getLadingQty());
        posOrderPo.setUpdateTime(LocalDateTime.now());
        return posOrderPo;
    }

    /**
     * 预订单提货同步u8
     *
     * @param posLadingOrderPo
     * @param posOrderItemPoForU8
     * @return
     */
    private U8ShipmentsVo buildSaleOrder(PosLadingOrderPo posLadingOrderPo, List<PosOrderItemPo> posOrderItemPoForU8) {
        Integer i = 0;
        List<U8ShipmentsItemVo> u8ShipmentsItemVoList = new ArrayList<>();
        for (PosOrderItemPo e : posOrderItemPoForU8) {
            i++;
            U8ShipmentsItemVo test = U8ShipmentsItemVo
                    .builder()
                    .inventory_code(e.getPrdBarCode())
                    .warehouse_code(posLadingOrderPo.getCounterId())
                    .quantity(e.getPurQty())
                    .taxrate(BigDecimal.ZERO)
                    .price(e.getSalePrice())
                    .taxpricel(e.getSalePrice())
                    .money(e.getSalePrice().multiply(new BigDecimal(e.getPurQty())))
                    .tax(BigDecimal.ZERO)
                    .sum(e.getMemberPrice().multiply(new BigDecimal(e.getPurQty())))
                    .poslineid(i)
                    .memo("")
                    .build();
            u8ShipmentsItemVoList.add(test);
        }
        if (posLadingOrderPo.getApportionAmt().compareTo(BigDecimal.ZERO) != 0) {
            U8ShipmentsItemVo test = U8ShipmentsItemVo
                    .builder()
                    .inventory_code(U8WareHouseConfig.Virtual)
                    .warehouse_code(posLadingOrderPo.getCounterId())
                    .quantity(1)
                    .taxrate(BigDecimal.ZERO)
                    .price(posLadingOrderPo.getApportionAmt().negate())
                    .taxpricel(posLadingOrderPo.getApportionAmt().negate())
                    .money(posLadingOrderPo.getApportionAmt().negate())
                    .tax(BigDecimal.ZERO)
                    .sum(posLadingOrderPo.getApportionAmt().negate())
                    .poslineid(i + 1)
                    .memo("")
                    .build();
            u8ShipmentsItemVoList.add(test);

        }
        //U8那边要的发货单数据类型和字段（表头）
        U8ShipmentsVo build = U8ShipmentsVo.builder()
                .poscode(posLadingOrderPo.getLadingOrderNo())
                .operation_type("普通销售")
                .saletype("自营销售(02)")
                .custcode(posLadingOrderPo.getCounterId())
                .deptcode(U8WareHouseConfig.DirectManagementDepartment)
                .cPersonCode(U8WareHouseConfig.HandledBy)
                .dDate(posLadingOrderPo.getCreateTime())
                .memo(posLadingOrderPo.getOrderNo())
                .Body(u8ShipmentsItemVoList).build();
        //把对象推送到MQ
        return build;
    }

    /**
     * 预订单提货同步u8
     *
     * @param posLadingOrderPo
     * @param posLadingOrderItemPoForU8
     * @return
     */
    private U8ShipmentsVo buildSaleOrder(List<PosLadingOrderItemPo> posLadingOrderItemPoForU8, PosLadingOrderPo posLadingOrderPo) {
        Integer i = 0;
        List<U8ShipmentsItemVo> u8ShipmentsItemVoList = new ArrayList<>();
        for (PosLadingOrderItemPo e : posLadingOrderItemPoForU8) {
            i++;
            U8ShipmentsItemVo test = U8ShipmentsItemVo
                    .builder()
                    .inventory_code(e.getPrdBarCode())
                    .warehouse_code(posLadingOrderPo.getCounterId())
                    .quantity(e.getLadingQty())
                    .taxrate(BigDecimal.ZERO)
                    .price(e.getMemberPrice())
                    .taxpricel(e.getMemberPrice())
                    .money(e.getMemberPrice().multiply(new BigDecimal(e.getLadingQty())))
                    .tax(BigDecimal.ZERO)
                    .sum(e.getMemberPrice().multiply(new BigDecimal(e.getLadingQty())))
                    .poslineid(i)
                    .memo("")
                    .build();
            u8ShipmentsItemVoList.add(test);
        }
        if (posLadingOrderPo.getApportionAmt() != null && posLadingOrderPo.getApportionAmt().compareTo(BigDecimal.ZERO) != 0) {
            U8ShipmentsItemVo test = U8ShipmentsItemVo
                    .builder()
                    .inventory_code(U8WareHouseConfig.Virtual)
                    .warehouse_code(posLadingOrderPo.getCounterId())
                    .quantity(1)
                    .taxrate(BigDecimal.ZERO)
                    .price(posLadingOrderPo.getApportionAmt().negate())
                    .taxpricel(posLadingOrderPo.getApportionAmt().negate())
                    .money(posLadingOrderPo.getApportionAmt().negate())
                    .tax(BigDecimal.ZERO)
                    .sum(posLadingOrderPo.getApportionAmt().negate())
                    .poslineid(i + 1)
                    .memo("")
                    .build();
            u8ShipmentsItemVoList.add(test);

        }
        //U8那边要的发货单数据类型和字段（表头）
        U8ShipmentsVo build = U8ShipmentsVo.builder()
                .poscode(posLadingOrderPo.getLadingOrderNo())
                .operation_type("普通销售")
                .saletype("自营销售(02)")
                .custcode(posLadingOrderPo.getCounterId())
                .deptcode(U8WareHouseConfig.DirectManagementDepartment)
                .cPersonCode(U8WareHouseConfig.HandledBy)
                .dDate(posLadingOrderPo.getCreateTime())
                .memo(posLadingOrderPo.getOrderNo())
                .Body(u8ShipmentsItemVoList).build();
        //把对象推送到MQ
        return build;
    }

    /**
     * 预订单提货退货单同步u8
     *
     * @param posLadingOrderPo
     * @param posOrderItemPoForU8
     * @return
     */
    private U8GoodsReturnVo buildReturnOrder(PosLadingOrderPo posLadingOrderPo, List<PosOrderItemPo> posOrderItemPoForU8) {
        Integer i = 0;
        List<U8GoodsReturnItemVo> u8GoodsReturnItemVoList = new ArrayList<>();
        for (PosOrderItemPo e : posOrderItemPoForU8) {
            i++;
            U8GoodsReturnItemVo test = U8GoodsReturnItemVo
                    .builder()
                    .inventory_code(e.getPrdBarCode())
                    .warehouse_code(posLadingOrderPo.getCounterId())
                    .quantity(e.getPurQty())
                    .taxrate(BigDecimal.ZERO)
                    .price(e.getSalePrice())
                    .taxpricel(e.getSalePrice())
                    .money(e.getSalePrice().multiply(new BigDecimal(e.getPurQty())))
                    .tax(BigDecimal.ZERO)
                    .sum(e.getSalePrice().multiply(new BigDecimal(e.getPurQty())))
                    .poslineid(i)
                    .memo("")
                    .build();
            u8GoodsReturnItemVoList.add(test);
        }
        if (posLadingOrderPo.getApportionAmt().compareTo(BigDecimal.ZERO) != 0) {
            U8GoodsReturnItemVo test = U8GoodsReturnItemVo
                    .builder()
                    .inventory_code(U8WareHouseConfig.Virtual)
                    .warehouse_code(posLadingOrderPo.getCounterId())
                    .quantity(1)
                    .taxrate(BigDecimal.ZERO)
                    .price(posLadingOrderPo.getApportionAmt().negate())
                    .taxpricel(posLadingOrderPo.getApportionAmt().negate())
                    .money(posLadingOrderPo.getApportionAmt().negate())
                    .tax(BigDecimal.ZERO)
                    .sum(posLadingOrderPo.getApportionAmt().negate())
                    .poslineid(i + 1)
                    .memo("")
                    .build();
            u8GoodsReturnItemVoList.add(test);

        }
        //U8那边要的预订单退货数据类型和字段（表头）
        U8GoodsReturnVo build = U8GoodsReturnVo.builder()
                .poscode(posLadingOrderPo.getLadingOrderNo())
                .operation_type("普通销售")
                .saletype("自营销售(02)")
                .custcode(posLadingOrderPo.getCounterId())
                .deptcode(U8WareHouseConfig.DirectManagementDepartment)
                .cPersonCode(U8WareHouseConfig.HandledBy)
                .dDate(posLadingOrderPo.getCreateTime())
                .memo(posLadingOrderPo.getOrderNo())
                .Body(u8GoodsReturnItemVoList).build();
        //把对象推送到MQ
        return build;
    }

    /**
     * 预订单提货退货单同步u8
     *
     * @param posLadingOrderPo
     * @param posLadingOrderItemPoForU8
     * @return
     */
    private U8GoodsReturnVo buildReturnOrder(List<PosLadingOrderItemPo> posLadingOrderItemPoForU8, PosLadingOrderPo posLadingOrderPo) {
        Integer i = 0;
        List<U8GoodsReturnItemVo> u8GoodsReturnItemVoList = new ArrayList<>();
        for (PosLadingOrderItemPo e : posLadingOrderItemPoForU8) {
            i++;
            U8GoodsReturnItemVo test = U8GoodsReturnItemVo
                    .builder()
                    .inventory_code(e.getPrdBarCode())
                    .warehouse_code(posLadingOrderPo.getCounterId())
                    .quantity(e.getLadingQty())
                    .taxrate(BigDecimal.ZERO)
                    .price(e.getMemberPrice())
                    .taxpricel(e.getMemberPrice())
                    .money(e.getMemberPrice().multiply(new BigDecimal(e.getLadingQty())))
                    .tax(BigDecimal.ZERO)
                    .sum(e.getMemberPrice().multiply(new BigDecimal(e.getLadingQty())))
                    .poslineid(i)
                    .memo("")
                    .build();
            u8GoodsReturnItemVoList.add(test);
        }
        if (posLadingOrderPo.getApportionAmt().compareTo(BigDecimal.ZERO) != 0) {
            U8GoodsReturnItemVo test = U8GoodsReturnItemVo
                    .builder()
                    .inventory_code(U8WareHouseConfig.Virtual)
                    .warehouse_code(posLadingOrderPo.getCounterId())
                    .quantity(1)
                    .taxrate(BigDecimal.ZERO)
                    .price(posLadingOrderPo.getApportionAmt().negate())
                    .taxpricel(posLadingOrderPo.getApportionAmt().negate())
                    .money(posLadingOrderPo.getApportionAmt().negate())
                    .tax(BigDecimal.ZERO)
                    .sum(posLadingOrderPo.getApportionAmt().negate())
                    .poslineid(i + 1)
                    .memo("")
                    .build();
            u8GoodsReturnItemVoList.add(test);

        }
        //U8那边要的预订单退货数据类型和字段（表头）
        U8GoodsReturnVo build = U8GoodsReturnVo.builder()
                .poscode(posLadingOrderPo.getLadingOrderNo())
                .operation_type("普通销售")
                .saletype("自营销售(02)")
                .custcode(posLadingOrderPo.getCounterId())
                .deptcode(U8WareHouseConfig.DirectManagementDepartment)
                .cPersonCode(U8WareHouseConfig.HandledBy)
                .dDate(posLadingOrderPo.getCreateTime())
                .memo(posLadingOrderPo.getOrderNo())
                .Body(u8GoodsReturnItemVoList).build();
        //把对象推送到MQ
        return build;
    }

    /**
     * 判断是否上传u8
     *
     * @param posOrderPo
     * @return
     */
    private boolean check(PosOrderPo posOrderPo) {
        //同步给u8
        CounterInformation counterInformation = counterMapper.selectById(posOrderPo.getCounterId());
        String operationalModel = counterInformation.getOperationalModel();
        Integer counterType = counterInformation.getCounterType();
        if (operationalModel.equals(CounterEnum.AGENT_COUNTER.getKey().toString())) {
            //代理商就不同步
            return false;
        }
        if (counterType.equals(CounterEnum.TEST_COUNTER.getKey())) {
            //测试柜台不同步
            return false;
        }
        //u8不同步测试会员的订单
        //2020年6月17日17:47:53  存在测试会员去正式店买东西的情况去掉这个判断
        return true;
    }

    @Override
    public Response fillAssociated(String orderNo) {
        //2020年5月6日14:49:23 根据订单循环找到预订单的提货列表
        LambdaQueryWrapper<PosOrderPo> wrapper = Wrappers.<PosOrderPo>lambdaQuery().eq(PosOrderPo::getOrderType, 2);
        if (orderNo != null && !" ".equals(orderNo) && !"".equals(orderNo)) {
            wrapper.eq(PosOrderPo::getOrderNo, orderNo);
        }
        List<PosOrderPo> posOrderPoList = posOrderMapper.selectList(wrapper);
        int size = posOrderPoList.size();
        int updateCount = 0;
        for (PosOrderPo posOrderPo : posOrderPoList) {
            //对比提货和退货的数量  如果存在退货品种数量 完全相同就填充提货单的关联退货单
            List<PosLadingOrderPo> posLadingOrderPoTiList = posLadingOrderMapper.selectList(Wrappers.<PosLadingOrderPo>lambdaQuery()
                    .eq(PosLadingOrderPo::getOrderNo, posOrderPo.getOrderNo())
                    .eq(PosLadingOrderPo::getStatus, 0)
                    .isNull(PosLadingOrderPo::getAssociatedNo));
            if (posLadingOrderPoTiList == null || posLadingOrderPoTiList.isEmpty()) {
                continue;
            }
            Map<String, List<PosLadingOrderItemPo>> tiMap = new HashMap();
            for (PosLadingOrderPo posLadingOrderPo : posLadingOrderPoTiList) {
                List<PosLadingOrderItemPo> posLadingOrderItemPoTiList = posLadingOrderItemMapper.selectList(Wrappers.<PosLadingOrderItemPo>lambdaQuery()
                        .eq(PosLadingOrderItemPo::getLadingOrderNo, posLadingOrderPo.getLadingOrderNo()));
                if (posLadingOrderItemPoTiList == null || posLadingOrderItemPoTiList.isEmpty()) {
                    log.error("预订单：{}存在order不存在item", posLadingOrderPo.getLadingOrderNo());
                } else {
                    tiMap.put(posLadingOrderPo.getLadingOrderNo(), posLadingOrderItemPoTiList);
                }
            }

            List<PosLadingOrderPo> posLadingOrderPoAssociatedNoList = posLadingOrderMapper.selectList(Wrappers.<PosLadingOrderPo>lambdaQuery()
                    .eq(PosLadingOrderPo::getOrderNo, posOrderPo.getOrderNo())
                    .eq(PosLadingOrderPo::getStatus, 0)
                    .isNotNull(PosLadingOrderPo::getAssociatedNo));
            List collect = null;
            if (posLadingOrderPoAssociatedNoList != null && posLadingOrderPoAssociatedNoList.size() > 0) {
                collect = posLadingOrderPoAssociatedNoList.stream().map(PosLadingOrderPo::getAssociatedNo).collect(Collectors.toList());
            }
            LambdaQueryWrapper<PosLadingOrderPo> eq = Wrappers.<PosLadingOrderPo>lambdaQuery()
                    .eq(PosLadingOrderPo::getOrderNo, posOrderPo.getOrderNo())
                    .eq(PosLadingOrderPo::getStatus, 1);
            if (collect != null && collect.size() > 0) {
                eq.notIn(PosLadingOrderPo::getLadingOrderNo, collect);
            }
            List<PosLadingOrderPo> posLadingOrderPoTuiList = posLadingOrderMapper.selectList(eq);

            if (posLadingOrderPoTuiList == null || posLadingOrderPoTuiList.isEmpty()) {
                continue;
            }
            Map<String, List<PosLadingOrderItemPo>> tuiMap = new HashMap();
            for (PosLadingOrderPo posLadingOrderPo : posLadingOrderPoTuiList) {
                List<PosLadingOrderItemPo> posLadingOrderItemPoTiList = posLadingOrderItemMapper.selectList(Wrappers.<PosLadingOrderItemPo>lambdaQuery()
                        .eq(PosLadingOrderItemPo::getLadingOrderNo, posLadingOrderPo.getLadingOrderNo()));
                if (posLadingOrderItemPoTiList == null || posLadingOrderItemPoTiList.isEmpty()) {
                    log.error("预订单：{}存在order不存在item", posLadingOrderPo.getLadingOrderNo());
                } else {
                    tuiMap.put(posLadingOrderPo.getLadingOrderNo(), posLadingOrderItemPoTiList);
                }
            }

            //先判断种类的数量 就是list的长度 长度相等就可以进一步比较
            List<String> tiList = new ArrayList<>(tiMap.keySet());
            List<String> tuiList = new ArrayList<>(tuiMap.keySet());
            int tiSize = tiList.size();
            int tuiSize = tuiList.size();
            for (int i = 0; i < tiSize; i++) {
                List<PosLadingOrderItemPo> posLadingOrderItemPosTi = tiMap.get(tiList.get(i));
                for (int j = 0; j < tuiSize; j++) {
                    List<PosLadingOrderItemPo> posLadingOrderItemPosTui = tuiMap.get(tuiList.get(j));
                    //种类相等就可以继续比较
                    if (posLadingOrderItemPosTui == null) {
                        continue;
                    }
                    AtomicBoolean flag = new AtomicBoolean(false);
                    if (posLadingOrderItemPosTui.size() == posLadingOrderItemPosTi.size()) {
                        flag.set(true);
                        Map<String, PosLadingOrderItemPo> collectTi = posLadingOrderItemPosTi.stream().collect(Collectors.toMap(PosLadingOrderItemPo::getPrdBarCode, Function.identity()));
                        Map<String, PosLadingOrderItemPo> collectTui = posLadingOrderItemPosTui.stream().collect(Collectors.toMap(PosLadingOrderItemPo::getPrdBarCode, Function.identity()));
                        collectTi.forEach((k, v) -> {
                            if (collectTui.get(k) == null || !collectTui.get(k).getLadingQty().equals(v.getLadingQty())) {
                                flag.set(false);
                            }
                        });
                    }

                    if (flag.get()) {
                        //这个应该就是完全对上的吧
                        updateCount++;
                        PosLadingOrderPo posLadingOrderPo = posLadingOrderMapper.selectById(tiList.get(i));
                        posLadingOrderPo.setAssociatedNo(tuiList.get(j));
                        posLadingOrderMapper.updateById(posLadingOrderPo);
                        tuiMap.remove(tuiList.get(j));
                        break;
                    }
                }
            }
        }
        return Response.success("预订单总数 " + size + " ,已经填充 " + updateCount + " 条");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Response u8FailResend(String orderNo, String type, boolean flag) {
        //先去confirm里面找对应的订单
        WhU8ConfirmLogPo whU8ConfirmLogPo = whU8ConfirmLogMapper.selectOne(Wrappers.<WhU8ConfirmLogPo>lambdaQuery().eq(WhU8ConfirmLogPo::getPosOrderNo, orderNo).eq(WhU8ConfirmLogPo::getStatus, 01));
        if (whU8ConfirmLogPo == null) {
            return Response.success("不存在的订单！");
        }
        String confirmType = whU8ConfirmLogPo.getType();
        if (!confirmType.equals(type)) {
            return Response.success("不存在的订单类型！");
        }
        whU8ConfirmLogPo.setStatus("03");
        whU8ConfirmLogPo.setUpdateTime(LocalDateTime.now());
        int i = whU8ConfirmLogMapper.updateById(whU8ConfirmLogPo);
        if (i == 0) {
            return Response.errorMsg("修改状态失败！");
        }
        switch (confirmType) {
            case U8DocumentTypeConfig.R_SASEND_ADD:
                this.resendSaleOrder(orderNo, flag);
                break;
            case U8DocumentTypeConfig.R_RO_ADD:
                this.resendReturnOrder(orderNo, flag);
                break;
            case U8DocumentTypeConfig.R_TR_ADD:
                this.resendTransferApplyOrder(orderNo);
                break;
            case U8DocumentTypeConfig.R_TV_ADD:
                this.resendTransferOrder(orderNo);
                break;
            case U8DocumentTypeConfig.R_CV_ADD:
                this.resendInventoryOrder(orderNo);
                break;
            default:
                throw new BizException("不存在的订单类型：" + confirmType);
        }
        return Response.success("重发成功！");
    }

    private void resendSaleOrder(String orderNo, Boolean flag) {
        //flag 是否是预订单
        if (flag) {
            PosLadingOrderPo posLadingOrderPo = posLadingOrderMapper.selectOne(Wrappers.<PosLadingOrderPo>lambdaQuery().eq(PosLadingOrderPo::getLadingOrderNo, orderNo));
            List<PosLadingOrderItemPo> posLadingOrderItemList = posLadingOrderItemMapper.selectList(Wrappers.<PosLadingOrderItemPo>lambdaQuery().eq(PosLadingOrderItemPo::getLadingOrderNo, orderNo));
            U8ShipmentsVo u8ShipmentsVo = this.buildSaleOrder(posLadingOrderItemList, posLadingOrderPo);
            u8MQProducer.sendMessageToU8(u8ShipmentsVo, U8DocumentTypeConfig.SASEND_ADD);
        } else {
            PosOrderPo posOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery().eq(PosOrderPo::getOrderNo, orderNo));
            List<PosOrderItemPo> posOrderItemList = posOrderItemMapper.selectList(Wrappers.<PosOrderItemPo>lambdaQuery().eq(PosOrderItemPo::getOrderNo, orderNo));
            U8ShipmentsVo u8ShipmentsVo = this.buildSaleOrder(posOrderPo, posOrderItemList);
            u8MQProducer.sendMessageToU8(u8ShipmentsVo, U8DocumentTypeConfig.SASEND_ADD);
        }
    }

    private void resendReturnOrder(String orderNo, Boolean flag) {
        //flag 是否是预订单
        if (flag) {
            PosLadingOrderPo posLadingOrderPo = posLadingOrderMapper.selectOne(Wrappers.<PosLadingOrderPo>lambdaQuery().eq(PosLadingOrderPo::getLadingOrderNo, orderNo));
            List<PosLadingOrderItemPo> posLadingOrderItemList = posLadingOrderItemMapper.selectList(Wrappers.<PosLadingOrderItemPo>lambdaQuery().eq(PosLadingOrderItemPo::getLadingOrderNo, orderNo));
            U8GoodsReturnVo u8GoodsReturnVo = this.buildReturnOrder(posLadingOrderItemList, posLadingOrderPo);
            u8MQProducer.sendMessageToU8(u8GoodsReturnVo, U8DocumentTypeConfig.RO_ADD);
        } else {
            PosOrderPo posOrderPo = posOrderMapper.selectOne(Wrappers.<PosOrderPo>lambdaQuery().eq(PosOrderPo::getOrderNo, orderNo));
            List<PosOrderItemPo> posOrderItemList = posOrderItemMapper.selectList(Wrappers.<PosOrderItemPo>lambdaQuery().eq(PosOrderItemPo::getOrderNo, orderNo));
            U8GoodsReturnVo u8GoodsReturnVo = this.buildReturnOrder(posOrderPo, posOrderItemList);
            u8MQProducer.sendMessageToU8(u8GoodsReturnVo, U8DocumentTypeConfig.RO_ADD);
        }
    }

    private void resendTransferApplyOrder(String orderNo) {
        WhReturnPo whReturnPo = whReturnMapper.selectOne(Wrappers.<WhReturnPo>lambdaQuery().eq(WhReturnPo::getReturnNo, orderNo));
        List<WhReturnItemPo> whReturnItemPos = whReturnItemMapepr.selectList(Wrappers.<WhReturnItemPo>lambdaQuery().eq(WhReturnItemPo::getReturnNo, orderNo));
        this.sendMsgToU8(whReturnPo, whReturnItemPos);
    }

    private void resendTransferOrder(String orderNo) {
        WhTransferPo orderPo = whTransferMapper.selectById(orderNo);
        List<WhTransferItemPo> itemList = whTransferItemMapper.selectList(Wrappers.<WhTransferItemPo>lambdaQuery().eq(WhTransferItemPo::getTransferOrderNo, orderNo));
        this.sendMsgToU8(orderPo, itemList);
    }

    private void resendInventoryOrder(String orderNo) {
        WhFreeInventoryPo whFreeInventoryPo = whFreeInventoryMapper.selectOne(Wrappers.<WhFreeInventoryPo>lambdaQuery().eq(WhFreeInventoryPo::getInvNo, orderNo));
        List<WhFreeInventoryItemPo> whFreeInventoryItemPos = whFreeInventoryItemMapper.selectList(Wrappers.<WhFreeInventoryItemPo>lambdaUpdate().eq(WhFreeInventoryItemPo::getApplyNo, whFreeInventoryPo.getApplyNo()));
        this.sendMsgToU8(whFreeInventoryPo, whFreeInventoryItemPos);
    }

    private void sendMsgToU8(WhFreeInventoryPo orderPo, List<WhFreeInventoryItemPo> itemList) {
        //U8那边要的盘点单数据类型和字段（表体）
        Integer i = 0;
        List<U8InventoryItemVo> U8InventoryItemList = new ArrayList<>();
        for (WhFreeInventoryItemPo e : itemList) {
            i++;
            U8InventoryItemVo test = U8InventoryItemVo.builder()
                    .inventory_code(e.getPrdBarCode())
                    .quantity(e.getRealQty())
                    .iCVQuantity(e.getBookQty())
                    .poslineid(i)
                    .memo("")
                    .build();
            U8InventoryItemList.add(test);
        }
        //U8那边要的盘点单数据类型和字段（表头）
        U8InventoryVo build = U8InventoryVo.builder()
                .dDate(orderPo.getCreateTime())
                .cwhcode(orderPo.getCounterId())
                .cirdcode(U8ReceivedConfig.InventoryIn)//门店盘盈入库
                .cordcode(U8ReceivedConfig.InventoryOut)//门店盘亏出库
                .cdepcode(orderPo.getCounterName())
                .cpersoncode(U8WareHouseConfig.HandledBy)//经手人
                .poscode(orderPo.getInvNo())
                .memo("门店盘点")
                .Body(U8InventoryItemList).build();

        //把对象推送到MQ
        u8MQProducer.sendMessageToU8(build, U8DocumentTypeConfig.CV_ADD);
    }

    private void sendMsgToU8(WhTransferPo orderPo, List<WhTransferItemPo> itemList) {
        Integer i = 0;
        List<U8TransferItemVo> U8TransferItemVoList = new ArrayList<>();
        for (WhTransferItemPo e : itemList) {
            i++;
            U8TransferItemVo test = U8TransferItemVo
                    .builder()
                    .inventory_code(e.getPrdBarCode())
                    .quantity(e.getInQty())
                    .poslineid(i)
                    .memo("")
                    .build();
            U8TransferItemVoList.add(test);
        }
        //U8那边要的发货单数据类型和字段（表头）
        U8TransferVo build = U8TransferVo.builder()
                .poscode(orderPo.getTransferOrderNo())
                .cowhcode(orderPo.getOutCounterId())
                .ciwhcode(orderPo.getInCounterId())
                .cirdcode(U8ReceivedConfig.TransfersIn)//店间调拨入库
                .cordcode(U8ReceivedConfig.TransfersOut)//店间调拨出库
                .codepcode(U8WareHouseConfig.DirectManagementDepartment)//转出部门 全部固定为直营管理部门
                .cidepcode(U8WareHouseConfig.DirectManagementDepartment)//转入部门
                .cpersoncode(U8WareHouseConfig.HandledBy)//经手人
                .memo("店间调拨")
                .Body(U8TransferItemVoList).build();
        //把对象推送到MQ
        u8MQProducer.sendMessageToU8(build, U8DocumentTypeConfig.TV_ADD);
    }

    private void sendMsgToU8(WhReturnPo orderPo, List<WhReturnItemPo> itemList) {
        Integer i = 0;
        List<U8TransferApplyItemVo> U8TransferApplyItemVoList = new ArrayList<>();
        for (WhReturnItemPo e : itemList) {
            i++;
            U8TransferApplyItemVo test = U8TransferApplyItemVo
                    .builder()
                    .inventory_code(e.getPrdBarCode())
                    .quantity(e.getApplyQty())
                    .poslineid(i)
                    .memo("")
                    .build();
            U8TransferApplyItemVoList.add(test);
        }

        //不同退货类型去不同的仓库不同的业务类型
        //0可用试用装退回，1报废试用装退回，2转店退回，3质量问题退回，4过敏退回，5公司召回，6到货少货，7活动赠品退回，8其他
        String ciwhcode = U8WareHouseConfig.DefectiveGoodsWarehouse; //固定次品仓
        String cirdcode = U8ReceivedConfig.DirectIn; //直营退货入库
        String cordcode = U8ReceivedConfig.DirectOut; //直营退货出库
        if (orderPo.getReason() == 1) {
            ciwhcode = U8WareHouseConfig.DamagedWarehouse; //2020年4月14日11:45:41 大仓报残仓
            cirdcode = U8ReceivedConfig.SampleSackIn;//试用退货入库
            cordcode = U8ReceivedConfig.SampleSackOut;//试用退货出库
        } else if (orderPo.getReason() == 0) {
            //2020年4月17日10:19:30 试用装全部到大仓报残仓
            ciwhcode = U8WareHouseConfig.DamagedWarehouse; //大仓报残仓
            cirdcode = U8ReceivedConfig.SampleSackIn;//试用退货入库
            cordcode = U8ReceivedConfig.SampleSackOut;//试用退货出库
        } else if (orderPo.getReason() == 2) {
            //直营转加盟
            ciwhcode = U8WareHouseConfig.ExchangeWarehouse; //转店仓 暂时只有仓库是转店仓
        }

        //U8那边要的发货单数据类型和字段（表头）
        U8TransferApplyVo build = U8TransferApplyVo.builder()
                .poscode(orderPo.getReturnNo())
                .cowhcode(orderPo.getCounterId())
                .ciwhcode(ciwhcode) //固定次品仓
                .cirdcode(cirdcode)//直营退货入库
                .cordcode(cordcode)//直营退货出库
                .trackingno(StringUtils.defaultString(orderPo.getTrackingNo()))
                .memo("门店退库申请")
                .Body(U8TransferApplyItemVoList).build();
        //把对象推送到MQ
        u8MQProducer.sendMessageToU8(build, U8DocumentTypeConfig.TR_ADD);
    }

    private U8ShipmentsVo buildSaleOrder(PosOrderPo orderPo, List<PosOrderItemPo> posOrderItemList) {
        Integer i = 0;
        List<U8ShipmentsItemVo> u8ShipmentsItemVoList = new ArrayList<>();
        for (PosOrderItemPo e : posOrderItemList) {
            i++;
            U8ShipmentsItemVo test = U8ShipmentsItemVo
                    .builder()
                    .inventory_code(e.getIsVirtual() == 0 ? e.getPrdBarCode() : U8WareHouseConfig.Virtual)
                    .warehouse_code(e.getCounterId())
                    .quantity(e.getPurQty())
                    .taxrate(BigDecimal.ZERO)
                    .price(e.getSalePrice())
                    .taxpricel(e.getSalePrice())
                    .money(e.getAmount())
                    .tax(BigDecimal.ZERO)
                    .sum(e.getAmount())
                    .poslineid(i)
                    .memo("")
                    .build();
            u8ShipmentsItemVoList.add(test);
        }
        //U8那边要的发货单数据类型和字段（表头）
        U8ShipmentsVo build = U8ShipmentsVo.builder()
                .poscode(orderPo.getOrderNo())
                .operation_type("普通销售")
                .saletype("自营销售(02)")
                .custcode(orderPo.getCounterId())
                .deptcode(U8WareHouseConfig.DirectManagementDepartment)
                .cPersonCode(U8WareHouseConfig.HandledBy)
                .dDate(orderPo.getCreateTime())
                .memo("商品销售")
                .Body(u8ShipmentsItemVoList).build();
        //把对象推送到MQ
        return build;
    }

    private U8GoodsReturnVo buildReturnOrder(PosOrderPo orderPo, List<PosOrderItemPo> posOrderItemList) {
        //U8那边要的退货单数据类型和字段（表体）
        Integer i = 0;
        List<U8GoodsReturnItemVo> u8GoodsReturnItemVoList = new ArrayList<>();
        for (PosOrderItemPo e : posOrderItemList) {
            i++;
            U8GoodsReturnItemVo test = U8GoodsReturnItemVo
                    .builder()
                    .inventory_code(e.getIsVirtual() == 0 ? e.getPrdBarCode() : U8WareHouseConfig.Virtual)
                    .u8sendlineid(null)
                    .warehouse_code(e.getCounterId())
                    .quantity(e.getPurQty())
                    .taxrate(BigDecimal.ZERO)
                    .price(e.getSalePrice())
                    .taxpricel(e.getSalePrice())
                    .money(e.getAmount())
                    .tax(BigDecimal.ZERO)
                    .sum(e.getAmount())
                    .poslineid(i)
                    .memo("")
                    .build();
            u8GoodsReturnItemVoList.add(test);
        }
        //U8那边要的发货单数据类型和字段（表头）
        U8GoodsReturnVo build = U8GoodsReturnVo.builder()
                .poscode(orderPo.getOrderNo())
                .operation_type("普通销售")
                .saletype("自营销售(02)")
                .custcode(orderPo.getCounterId())
                .deptcode(U8WareHouseConfig.DirectManagementDepartment)
                .u8sendcode("")
                .cPersonCode(U8WareHouseConfig.HandledBy)
                .dDate(orderPo.getCreateTime())
                .memo("商品退货")
                .Body(u8GoodsReturnItemVoList).build();
        //把对象推送到MQ
        return build;
    }
}
