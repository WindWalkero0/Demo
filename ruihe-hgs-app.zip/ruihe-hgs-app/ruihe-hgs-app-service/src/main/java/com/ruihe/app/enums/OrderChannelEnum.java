package com.ruihe.app.enums;

/**
 * 销售渠道
 * @author William
 */
public enum OrderChannelEnum {
    /**
     * 0，实体门店
     **/
    SHOP("SHOP", "实体门店"),
    /**
     * 1，天猫
     **/
    TMALL("TMALL", "天猫"),
    /**
     * 2，京东
     **/
    JD("JD", "京东");

    private String code;
    private String msg;


    OrderChannelEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
