package com.ruihe.app.request;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author luojie
 * @program ruihe-top
 * @description 库存打印请求参数实体类
 * @create: 2021/7/6 13:21
 */
@ApiOperation(notes = "库存打印请求参数", value = "库存打印请求参数")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhStockPrintRequest {
    @NotBlank(message = "柜台Id不能为空")
    @ApiModelProperty(value = "柜台Id", required = true)
    String counterId;
    
    @NotNull(message = "打印查询条件类型不能为空")
    @ApiModelProperty(value = "打印查询条件类型(0-按分类 1-按系列)", required = true)
    Integer queryType;
    
    @ApiModelProperty("库存数量查询类型(0-仅展示0 1-展示非0 其他-展示所有)")
    Integer stockType; 
    
    @ApiModelProperty("大类编号")
    String bigCatCode;
    
    @ApiModelProperty("中类编号")
    String mediumCatCode;
    
    @ApiModelProperty("小类编号")
    String smallCatCode;
    
    @ApiModelProperty("系列编号")
    String seriesCode;
}
