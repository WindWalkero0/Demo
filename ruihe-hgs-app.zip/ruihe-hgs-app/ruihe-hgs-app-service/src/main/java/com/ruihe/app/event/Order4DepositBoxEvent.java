package com.ruihe.app.event;

/**
 * 销售订单事件-寄存箱处理
 *
 * @author William
 */
public class Order4DepositBoxEvent extends OrderEvent {
    public Order4DepositBoxEvent(Object source, String orderNo) {
        super(source, orderNo);
    }
}
