package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class Types {
    private Integer hat;
    private Integer hair;
    private Integer glass;
    private Integer sticker;
    private Integer mask;
    private Integer facial;
}
