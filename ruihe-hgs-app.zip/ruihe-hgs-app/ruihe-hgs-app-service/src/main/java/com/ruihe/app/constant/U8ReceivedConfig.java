package com.ruihe.app.constant;

/**
 * u8收发类别
 *
 * @author xyf
 */
public class U8ReceivedConfig {
    /**
     * 直营退货入库
     **/
    public static final String  DirectIn = "106";
    /**
     * 直营退货出库
     **/
    public static final String  DirectOut = "206";
    /**
     * 试用装退货入库
     **/
    public static final String  SampleSackIn  = "110";
    /**
     * 试用装退货出库
     **/
    public static final String  SampleSackOut = "227";
    /**
     *105店间调拨入库
     **/
    public static final String  TransfersIn = "105";
    /**
     *205店间调拨出库
     **/
    public static final String  TransfersOut = "205";
    /**
     *107门店盘盈入库
     **/
    public static final String  InventoryIn = "107";
    /**
     *207门店盘亏出库
     **/
    public static final String  InventoryOut = "207";

}
