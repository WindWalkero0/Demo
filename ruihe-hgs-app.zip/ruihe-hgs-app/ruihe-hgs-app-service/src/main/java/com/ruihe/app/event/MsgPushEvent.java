package com.ruihe.app.event;

import com.ruihe.msger.dto.PushRequestDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * 消息推送事件
 * 目前支持极光推送
 */
@Getter
@EqualsAndHashCode(callSuper = false)
public class MsgPushEvent extends ApplicationEvent {
    private final PushRequestDto pushRequestDto;

    public MsgPushEvent(Object source, PushRequestDto pushRequestDto) {
        super(source);
        this.pushRequestDto = pushRequestDto;
    }
}
