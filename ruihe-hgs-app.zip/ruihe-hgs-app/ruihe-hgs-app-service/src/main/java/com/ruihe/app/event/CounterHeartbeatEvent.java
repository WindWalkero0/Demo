package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;


/**
 * 柜台心跳时间
 * @author qubin
 * @date 2021/4/17 13:05
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class CounterHeartbeatEvent extends ApplicationEvent {

    /**
     * 柜台id
     */
    private String counterId;

    public CounterHeartbeatEvent(Object source, String counterId) {
        super(source);
        this.counterId = counterId;
    }
}
