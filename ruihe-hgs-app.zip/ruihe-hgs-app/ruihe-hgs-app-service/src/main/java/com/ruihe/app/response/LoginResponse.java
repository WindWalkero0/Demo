package com.ruihe.app.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/***
 * 登录响应
 * @author ku
 */
@ApiModel(value = "LoginResponse", description = "登录响应实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoginResponse implements Serializable {
    @ApiModelProperty("会话token")
    private String token;

    @ApiModelProperty("门店编号")
    private String counterId;

    @ApiModelProperty("门店名称")
    private String counterName;

    @ApiModelProperty("柜员code")
    private String baCode;

    @ApiModelProperty("柜员姓名")
    private String baName;

    @ApiModelProperty("柜员手机号")
    private String phoneNo;

    @ApiModelProperty("柜员状态")
    private Integer status;

    @ApiModelProperty("柜台手机号")
    private String counterPhone;

    @ApiModelProperty("柜台地址")
    private String counterAddress;

    @ApiModelProperty("运营模式 自营/代理商 自营10005/加盟10006")
    private String operationalModel;
}
