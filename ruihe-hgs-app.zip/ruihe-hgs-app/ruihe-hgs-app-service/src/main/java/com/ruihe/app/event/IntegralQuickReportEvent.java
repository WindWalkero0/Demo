package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 积分订单事件，处理websocket消息
 *
 * @author fly
 */
@Data
public class IntegralQuickReportEvent extends ApplicationEvent {

    /**
     * 订单号
     */
    private Integer IntegralOrderNo;

    /**
     * Create a new ApplicationEvent.
     *
     * @param source the object on which the event initially occurred (never {@code null})
     */
    public IntegralQuickReportEvent(Object source, Integer IntegralOrderNo) {
        super(source);
        this.IntegralOrderNo = IntegralOrderNo;
    }

}
