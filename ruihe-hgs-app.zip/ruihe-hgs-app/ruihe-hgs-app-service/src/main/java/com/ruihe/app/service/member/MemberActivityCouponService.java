package com.ruihe.app.service.member;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ruihe.app.request.member.MemberActivityRedeemRequest;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.activity.ActivityPlace;
import com.ruihe.common.dao.bean.base.CounterInformation;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.member.*;
import com.ruihe.common.dao.bean.promotion.PromotionCoupon;
import com.ruihe.common.dao.bean.promotion.PromotionCouponProduct;
import com.ruihe.common.dao.bean.promotion.PromotionProduct;
import com.ruihe.common.dao.bean.warehouse.WhStockPo;
import com.ruihe.common.dao.mapper.KbCouponProductMapper;
import com.ruihe.common.dao.mapper.MemberKbActivityMapper;
import com.ruihe.common.enums.member.MemberActivityEnum;
import com.ruihe.common.enums.member.MemberCouponTypeEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.pojo.dto.MemberActivityProductDTO;
import com.ruihe.common.service.ActivityService;
import com.ruihe.common.service.CommonService;
import com.ruihe.common.service.CustomService;
import com.ruihe.app.mapper.member.MemberActivityMapper;
import com.ruihe.app.mapper.member.MemberActivitySonMapper;
import com.ruihe.app.mapper.member.MemberCouponMapper;
import com.ruihe.app.request.member.MemberCheckCouponRequest;
import com.ruihe.app.response.member.MemberCouponResponse;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.response.Response;
import com.ruihe.common.util.LambdaUtil;
import com.ruihe.common.utils.TimeUtils;
import com.ruihe.app.service.basic.AboutCounterService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.ruihe.common.enums.activity.ActivityEnum.*;


@Slf4j
@Service
public class MemberActivityCouponService {

    @Autowired
    private AboutMemberActivityService memberActivityService;

    @Autowired
    private MemberActivityMapper memberActivityMapper;

    @Autowired
    private ActivityService activityService;

    @Autowired
    private AboutCounterService counterService;

    @Autowired
    private CustomService customService;

    @Autowired
    private MemberCouponMapper memberCouponMapper;

    @Autowired
    private MemberActivitySonMapper activitySonMapper;

    @Autowired
    private MemberKbActivityMapper memberKbActivityMapper;

    @Autowired
    private KbCouponProductMapper kbCouponProductMapper;


    @Ella(Describe = "判断是否能使用优惠券")
    @DS(DBConst.SLAVE)
    public Response checkCoupon(MemberCheckCouponRequest request) {
        LambdaUtil lambdaUtil = LambdaUtil.builder().money(BigDecimal.ZERO).build();
        String couponId = request.getCouponId();
        List<MemberCheckCouponRequest.OrderItemRequest> orderItemList = request.getOrderItemList();
        orderItemList.forEach(orderItemRequest -> {//计算商品总价格
            Product product = customService.select(Product.builder().prdBarCode(orderItemRequest.getPrdBarCode()).build());
            lambdaUtil.setMoney(lambdaUtil.getMoney().add(product.getMemberPrice().multiply(new BigDecimal(orderItemRequest.getPurQty()))));
        });
        MemberCoupon memberCoupon = customService.select(MemberCoupon.builder().couponId(couponId).build());
        if (memberCoupon.getCouponType().equals(1)) {
            //发券活动的优惠券
            List<PromotionProduct> promotionProducts = customService.selectList(PromotionProduct.builder().promotionalUid(memberCoupon.getActivityId()).isDel(1).build());
            if (!promotionProducts.isEmpty()) {
                Map<String, PromotionProduct> map = new HashMap<>();
                promotionProducts.forEach(promotionProduct -> {
                    map.put(promotionProduct.getSpecificProductId(), promotionProduct);
                });
                orderItemList.forEach(orderItemRequest -> {
                    if (map.get(orderItemRequest.getPrdBarCode()) == null) {//存在限定外的商品,不允许使用
                        log.error("订单中包含无法使用该优惠券的产品，请核对后重试");
                        throw new BizException("订单中包含无法使用该优惠券的产品，请核对后重试");
                    }

                });
            }
            //判断是否发券活动满足使用规则
            PromotionCoupon promotionCoupon = customService.select(PromotionCoupon.builder().proCouponId(memberCoupon.getActivityId()).build());
            if (lambdaUtil.getMoney().compareTo(promotionCoupon.getNeedMoney()) == -1) {//购买的价格小条件的金额,不满足
                return Response.errorMsg("本次领用需购买金额>=" + promotionCoupon.getNeedMoney());
            }
            return Response.successMsg("满足使用条件");
        } else if (memberCoupon.getCouponType().equals(MemberCouponTypeEnum.KB_ACTIVITY.getCode())) {
            return Response.successMsg("满足使用条件");
        }
        judgeMemberCoupon(memberCoupon.getCouponId());
        //查询主活动
        MemberActivity memberActivity = memberActivityService.selectMemberActivity(MemberActivity
                .builder()
                .activityId(request.getSubActivityId())
                .build());
        if (memberActivity == null) {//如果为空说明数据是有问题的 ,为了测试先给他通过--在正式的时候不会出现这样的错误
            customService.update(MemberCoupon.builder().status(CommonStatusEnum.INVALID.getCode()).build(), MemberCoupon.builder().subActivityId(request.getSubActivityId()).build());
            return Response.errorMsg("数据删除不完整造成此优惠券不能再使用--请忽略");
        }        //查看是否需要购买
        if (memberActivity.getBuyType().equals(0)) {//不需要购买,直接使用
            return Response.successMsg("满足使用条件");
        } else {//需要购买条件
            //查询子活动
            MemberActivitySon memberActivitySon = memberActivityService.selectMemberActivitySon(MemberActivitySon
                    .builder()
                    .activityId(request.getActivityId())
                    .build());
            //查看条件
            BigDecimal conditionPrice = new BigDecimal(memberActivitySon.getMoneyCondition());//购买金额条件
            //最后的价格,与设置的条件进行对比
            if (lambdaUtil.getMoney().compareTo(conditionPrice) == -1) {//购买的价格小条件的金额,不满足
                return Response.errorMsg("本次领用需购买金额>=" + conditionPrice);
            }
            return Response.successMsg("满足使用条件");
        }
    }

    /**
     * 查询该优惠券是否可以使用(针对于薅羊毛!!!!)
     *
     * @param couponId
     */
    private void judgeMemberCoupon(String couponId) {
        MemberCoupon memberCoupon = memberCouponMapper.selectOne(Wrappers.lambdaQuery(MemberCoupon.class)
                .eq(MemberCoupon::getCouponId, couponId)
                .eq(MemberCoupon::getStatus, 0)
                .eq(MemberCoupon::getIsDel, 1));
        if (memberCoupon == null) {
            log.warn("该优惠券已经失效couponId={}", couponId);
            throw new BizException("该优惠券已经失效");
        }
        //查询是否是合并优惠券如果是优惠券
        if (memberCoupon.getCouponType().equals(0)) {
            //只要会员活动发的券
            //查询活动
            MemberActivity memberActivity = memberActivityMapper.selectOne(Wrappers.lambdaQuery(MemberActivity.class).eq(MemberActivity::getActivityId, memberCoupon.getSubActivityId()));
            if (memberActivity != null) {
                //判断活动类型:生日礼-入会礼一年只能用一张;
                if (memberActivity.getActivityType().equals(MemberActivityEnum.BIRTHDAY_TYPE.getKey()) || memberActivity.getActivityType().equals(MemberActivityEnum.ADMISSION_TYPE.getKey())) {
                    String startTime = CommonService.getStartTime();
                    String endTime = CommonService.getEndTime();
                    //查询本年度已使用过且状态为正常的优惠券个数(根据主活动来查)
                    Integer count = memberCouponMapper.selectCount(Wrappers.lambdaQuery(MemberCoupon.class)
                            .eq(MemberCoupon::getMemberId, memberCoupon.getMemberId())
                            .eq(MemberCoupon::getSubActivityId, memberCoupon.getSubActivityId())
                            .ge(MemberCoupon::getStartTime, startTime)
                            .le(MemberCoupon::getStopTime, endTime)
                            .eq(MemberCoupon::getStatus, 1)
                            .eq(MemberCoupon::getIsDel, 1));
                    if (count >= 1) {
                        log.error("(生日礼/入会礼)发现有超额发放的优惠券:{}", memberCoupon.getCouponId());
                        throw new BizException("该优惠券在活动范围内已达到使用上限,请下次活动时间在使用");
                    }
                } else {//其他礼券在规定时间内查看是否超过多余的使用次数
                    //查询该子活动能发放到多少优惠券
                    Integer couponCount = activitySonMapper.selectOne(Wrappers.lambdaQuery(MemberActivitySon.class)
                            .eq(MemberActivitySon::getActivityId, memberCoupon.getActivityId())).getCouponCount();
                    //查询改子活动已经使用的优惠券有多少
                    Integer count = memberCouponMapper.selectCount(Wrappers.lambdaQuery(MemberCoupon.class)
                            .eq(MemberCoupon::getMemberId, memberCoupon.getMemberId())
                            .eq(MemberCoupon::getActivityId, memberCoupon.getActivityId())
                            .eq(MemberCoupon::getStatus, 1)
                            .eq(MemberCoupon::getIsDel, 1));
                    if (count >= couponCount) {
                        log.error("普通优惠券发现有超额发放的优惠券:{}", memberCoupon.getCouponId());
                        throw new BizException("该优惠券在活动范围内已达到使用上限,请下次活动时间在使用");
                    }
                }
            }
        }
    }

    @Ella(Describe = "查询优惠券信息", Author = "K")
    @DS(DBConst.SLAVE)
    public Response selectCoupon(MemberActivityRedeemRequest request) {
        Integer size = 0;
        //填充现在时间
        request.setNowTime(TimeUtils.longFormatString(System.currentTimeMillis()));
        //设置分页信息
        PageHelper.startPage(request.getPageNumber(), 50);
        //根据会员id查询所有有效且未使用的且正在使用期间的优惠券信息
        List<MemberCoupon> memberCoupons = memberActivityMapper.selectMemberCoupons(request);
        List<MemberCouponResponse> memberCouponResponses = new ArrayList<>();
        if (!memberCoupons.isEmpty()) {
            //将不符合活动的排出
            size = removeCoupon(memberCoupons, request);//过滤掉不符合条件的会员优惠券 PS:这里只处理了会员活动
            memberCouponResponses = memberCoupons.stream().map(memberCoupon -> {
                //再处理促销活动发券
                MemberCouponResponse build = MemberCouponResponse
                        .builder()
                        .buyType(1)//默认需要购买
                        .activityId(memberCoupon.getActivityId())
                        .activityName(memberCoupon.getActivityName())
                        .stopTime(memberCoupon.getStopTime())
                        .couponId(memberCoupon.getCouponId())
                        .couponType(memberCoupon.getCouponType())//优惠券类型
                        .subActivityId(memberCoupon.getSubActivityId())
                        .coupon(StringUtils.isEmpty(memberCoupon.getCoupon()) ? null : memberCoupon.getCoupon())
                        .count(1)
                        .build();
                List<MemberActivityProduct> memberActivityProducts = new ArrayList<>();
                //查询会员商品信息
                //2021年3月16日14:54:56 0是会员活动 1是发券活动 2是口碑礼
                if (memberCoupon.getCouponType().equals(MemberCouponTypeEnum.COUPON_ACTIVITY.getCode())) {
                    //发券活动设置活动奖励
                    List<PromotionCouponProduct> promotionCouponProducts = customService.selectList(PromotionCouponProduct.builder().proCouponId(memberCoupon.getActivityId()).isDel(CommonStatusEnum.EFFECTIVE.getCode()).build());
                    memberActivityProducts.addAll(promotionCouponProducts.stream().map(promotionCouponProduct -> {
                        MemberActivityProduct memberActivityProduct = MemberActivityProduct
                                .builder()
                                .activityId(promotionCouponProduct.getProCouponId())//设置活动id
                                .isDel(promotionCouponProduct.getIsDel())
                                .count(promotionCouponProduct.getCount())//设置数量
                                .createTime(promotionCouponProduct.getCreateTime())
                                .goodsBarCode(promotionCouponProduct.getGoodsBarCode())
                                .prdBarCode(promotionCouponProduct.getPrdBarCode())
                                .prdName(promotionCouponProduct.getPrdName())
                                .price(promotionCouponProduct.getPrdPrice())
                                .rewardType(promotionCouponProduct.getRewardType())
                                .build();
                        return memberActivityProduct;
                    }).collect(Collectors.toList()));
                } else if (memberCoupon.getCouponType().equals(MemberCouponTypeEnum.MEMBER_ACTIVITY.getCode())) {
                    //会员活动
                    MemberActivitySon memberActivitySon = customService.select(MemberActivitySon.builder().activityId(memberCoupon.getActivityId()).build());
                    memberActivityProducts = memberActivityService.selectMemberActivityProducts(MemberActivityProduct
                            .builder()
                            .isDel(CommonStatusEnum.EFFECTIVE.getCode())
                            .activityId(memberCoupon.getActivityId())
                            .build());
                    memberActivityProducts.parallelStream().forEach(memberActivityProduct -> {
                        WhStockPo whStockPo = customService.select(WhStockPo.builder().counterId(request.getCounterId()).goodsBarCode(memberActivityProduct.getGoodsBarCode()).prdBarCode(memberActivityProduct.getPrdBarCode()).build());
                        if (whStockPo == null) {
                            memberActivityProduct.setStock(0);
                        } else {
                            memberActivityProduct.setStock(whStockPo.getStock());
                        }
                    });
                    build.setSelectType(memberActivitySon.getSelectType());
                    build.setSelectCount(memberActivitySon.getSelectCount());
                } else if (memberCoupon.getCouponType().equals(MemberCouponTypeEnum.KB_ACTIVITY.getCode())) {
                    KbActivity kbActivity = memberKbActivityMapper.selectById(memberCoupon.getActivityId());
                    List<KbCouponProduct> kbCouponProducts = kbCouponProductMapper.selectList(Wrappers.<KbCouponProduct>lambdaQuery()
                            .eq(KbCouponProduct::getKbCouponId, memberCoupon.getActivityId()));
                    memberActivityProducts = kbCouponProducts.stream().map(e -> {
                        MemberActivityProduct memberActivityProduct = new MemberActivityProduct();
                        BeanUtils.copyProperties(e, memberActivityProduct);
                        memberActivityProduct.setActivityId(e.getKbCouponId());
                        return memberActivityProduct;
                    }).collect(Collectors.toList());
                    memberActivityProducts.parallelStream().forEach(memberActivityProduct -> {
                        WhStockPo whStockPo = customService.select(WhStockPo.builder().counterId(request.getCounterId()).goodsBarCode(memberActivityProduct.getGoodsBarCode()).prdBarCode(memberActivityProduct.getPrdBarCode()).build());
                        if (whStockPo == null) {
                            memberActivityProduct.setStock(0);
                        } else {
                            memberActivityProduct.setStock(whStockPo.getStock());
                        }
                    });
                    build.setSelectType(kbActivity.getAwardConf().getSelectType());
                    build.setSelectCount(kbActivity.getAwardConf().getSelectCount());
                    build.setBuyType(kbActivity.getAwardConf().getNeedBuy() ? 1 : 0);
                }
                build.setProducts(memberActivityProducts);//活动奖励商品
                build.setRewardType(memberActivityProducts.get(0).getRewardType());
                if (memberCoupon.getCouponType().equals(0)) {
                    MemberActivitySon memberActivitySon = customService.select(MemberActivitySon.builder().activityId(memberCoupon.getActivityId()).build());
                    MemberActivity memberActivity = customService.select(MemberActivity.builder().activityId(memberActivitySon.getSubjectId()).build());
                    build.setBuyType(memberActivity.getBuyType());
                }
                memberActivityProducts.stream().forEach(memberActivityProduct -> {
                    build.setPrice(StringUtils.isEmpty(build.getPrice()) ? new BigDecimal(memberActivityProduct.getPrice()).toString() : new BigDecimal(build.getPrice()).add(new BigDecimal(memberActivityProduct.getPrice())).toString());
                });
                if (StringUtils.isEmpty(build.getActivityId())) {
                    log.error("检测到优惠券的活动编码为空");
                    throw new BizException("检测到优惠券的活动编码为空");
                }
                return build;
            }).collect(Collectors.toList());
        }
        PageInfo<MemberCouponResponse> info = new PageInfo<>(memberCouponResponses);
        List<MemberCoupon> list = memberActivityMapper.selectMemberCoupons(request);
        info.setTotal(list.isEmpty() ? 0 : list.size() - size);
        info.setPages((list.size() - size) % request.getPageSize() == 0 ? (list.size() - size) / request.getPageSize() : (list.size() - size) / request.getPageSize() + 1);
        if (memberCouponResponses.isEmpty()) {
            info.setPages(request.getPageNumber());
        }
        return Response.success(info);
    }


    @Ella(Describe = "检验coupon是否正确")
    public Response checkCouponNumber(String coupon, String couponId) {
        if (StringUtils.isEmpty(coupon)) {
            return Response.errorMsg("请输入验证码");
        }
        if (StringUtils.isEmpty(couponId)) {
            return Response.errorMsg("优惠券信息不完整");
        }
        MemberCoupon memberCoupon = memberActivityService.selectMemberCoupon(MemberCoupon.builder().isDel(CommonStatusEnum.EFFECTIVE.getCode()).couponId(couponId).coupon(coupon).build());
        if (memberCoupon == null) {
            return Response.errorMsg(MemberActivityEnum.COUPON_ERROR.getValue());
        }
        if (!memberCoupon.getStatus().equals(0)) {
            return Response.errorMsg("该优惠券不可用");
        }
        return Response.successMsg("检验通过");
    }

    @Ella(Describe = "将不符合活动的排出", Author = "K")
    private Integer removeCoupon(List<MemberCoupon> memberCoupons, MemberActivityRedeemRequest request) {
        Integer size = 0;
        Iterator<MemberCoupon> iterator = memberCoupons.iterator();
        while (iterator.hasNext()) {
            MemberCoupon memberCoupon = iterator.next();
            //coupon_type==null的情形 为什么couponType会为空?
            if (memberCoupon.getCouponType() == null) {
                memberCoupon.setCouponType(0);
            }
            //促销管理优惠券先不处理,这里只管会员优惠券的情形
            if (memberCoupon.getCouponType().equals(1)) {
                continue;
            }
//            Boolean flag = commonService.checkCoupon(memberCoupon);
//            if (flag) {
//                iterator.remove();
//                continue;
//            }
            //查询是否满足该柜台
            MemberActivitySon memberActivitySon = memberActivityService.selectMemberActivitySon(MemberActivitySon.builder().activityId(memberCoupon.getActivityId()).build());
            if (memberActivitySon == null) {
                //口碑礼活动是没有子活动的  而且没有柜台限制
                continue;
            }
            if (!memberActivitySon.getActivityPlaceType().equals(ACTITY_PLACE_TYPE1.getKey())) {
                //获取到柜台信息
                CounterInformation counterInformation = counterService.selectCounterInfo(CounterInformation
                        .builder()
                        .counterId(request.getCounterId())
                        .build());
                List<ActivityPlace> activityPlaces = activityService.selectActivityPlaces(ActivityPlace
                        .builder()
                        .activityUid(memberCoupon.getActivityId())
                        .placeType(memberActivitySon.getActivityPlaceType())
                        .build());
                //按区域 || 按区域指定柜台
                if (memberActivitySon.getActivityPlaceType().equals(ACTITY_PLACE_TYPE7.getKey()) ||
                        memberActivitySon.getActivityPlaceType().equals(ACTITY_PLACE_TYPE8.getKey())) {
                    Integer integer = checkAndRemove(iterator, activityPlaces, counterInformation);
                    size = size + integer;
                } else {
                    /*
                     * 处理匹配过滤逻辑
                     */
                    Predicate<ActivityPlace> checkActivityMatch = it -> {
                        if (memberActivitySon.getActivityPlaceType().equals(ACTITY_PLACE_TYPE3.getKey())) {
                            //组织机构
                            return counterInformation.getOrgMasterId().equals(it.getDepartmentId());
                        } else if (memberActivitySon.getActivityPlaceType().equals(ACTITY_PLACE_TYPE5.getKey())) {
                            //按渠道
                            return counterInformation.getChannelCode().equals(it.getChannelCode());
                        } else if (memberActivitySon.getActivityPlaceType().equals(ACTITY_PLACE_TYPE4.getKey()) ||
                                memberActivitySon.getActivityPlaceType().equals(ACTITY_PLACE_TYPE6.getKey())) {
                            //组织机构指定柜台 && 渠道指定柜台
                            boolean match = memberActivitySon.getActivityPlaceType().equals(ACTITY_PLACE_TYPE4.getKey()) ?
                                    counterInformation.getOrgMasterId().equals(it.getDepartmentId()) : counterInformation.getChannelCode().equals(it.getChannelCode());
                            return counterInformation.getCounterId().equals(it.getCounterId())
                                    && match;
                        } else {
                            //若新添加活动范围枚举，需要在此处处理额外逻辑
                            return false;
                        }
                    };
                    List<ActivityPlace> matchRes = activityPlaces.stream().filter(checkActivityMatch).collect(Collectors.toList());
                    if (matchRes.isEmpty()) {
                        iterator.remove();
                    } else {
                        size++;
                    }
                }
            }


        }
        return size;
    }

    @Ella(Describe = "进行比较清除", Author = "K")
    private Integer checkAndRemove(Iterator<MemberCoupon> iterator, List<ActivityPlace> activityPlaces, CounterInformation counterInformation) {
        Integer size = 0;
        Boolean flag = false;
        for (ActivityPlace activityPlace : activityPlaces) {
            if (StringUtils.isEmpty(activityPlace.getRegionCode())) {
                flag = true;//代表按区域指定柜台!!!!因为前端没传regionCode
            } else {
                if (activityPlace.getRegionCode().equals(counterInformation.getCountyCode())) {
                    flag = true;//代表按区域!!!!因为传了regionCode
                }
            }
        }
        //不符合进行清除
        if (!flag) {
            iterator.remove();
            size++;
        }
        return size;
    }
}
