package com.ruihe.app.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruihe.common.utils.LocalDateUtils;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 消息
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosMessageResponse implements Serializable {

    @ApiModelProperty(value = "消息标题")
    private String title;

    @ApiModelProperty(value = "时间")
    @JsonFormat(pattern = LocalDateUtils.DATE_TIME)
    private LocalDateTime sendTime;

    @ApiModelProperty(value = "渲染url")
    private String url;

    @ApiModelProperty(value = "是否已读：0未读，1已读")
    private Integer read;

    @ApiModelProperty(value = "消息ID")
    private Integer msgId;
}
