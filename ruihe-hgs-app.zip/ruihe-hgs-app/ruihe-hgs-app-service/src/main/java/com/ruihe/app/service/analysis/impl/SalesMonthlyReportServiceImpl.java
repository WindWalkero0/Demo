package com.ruihe.app.service.analysis.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.google.common.collect.Maps;
import com.ruihe.app.po.analysis.PosDetailReportConditionPo;
import com.ruihe.app.po.analysis.PosMonthlyReportConditionPo;
import com.ruihe.app.po.analysis.PosSalesDetailsPo;
import com.ruihe.app.po.analysis.PosSalesMonthlyReportPo;
import com.ruihe.app.service.analysis.SalesMonthlyReportService;
import com.ruihe.app.vo.MonthlyReportVo;
import com.ruihe.app.vo.PosDetailReportConditionVo;
import com.ruihe.app.vo.PosSalesDetailsVo;
import com.ruihe.app.vo.PosSalesMonthlyReportVo;
import com.ruihe.common.pojo.request.analysis.MonthlyReportRequest;
import com.ruihe.common.pojo.request.analysis.SalesMonthlyRequest;
import com.ruihe.app.mapper.analysis.SalesMonthlyReportMapper;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 销售月报表
 *
 * @author:Fangtao
 * @Date:2019/11/4 16:56
 */

/*      1、销售数量：查询时间段内（正常销售单销售数量-正常销售单退货数量）-（预订单销售数量-退货单退货数量）--->=销售商品数量-退货商品数量，
            1)销售商品数量：销售单中除促销赠品及积分兑换等虚拟商品数量外的实物商品数量
            2)退货商品数量：退货单中除促销赠品及积分兑换等虚拟商品数量外的实物商品数量
        2、购买金额：查询时间段内（正常销售单销售金额-正常销售单退货金额）-（预订单销售金额-退货单退货金额）--->=
        销售金额（∑=销售商品数量*商品价格）- 退货金额（∑=退货商品数量*商品价格）*/
@Slf4j
@DS(DBConst.SLAVE)
@Service
public class SalesMonthlyReportServiceImpl implements SalesMonthlyReportService {
    @Autowired
    private SalesMonthlyReportMapper salesMonthlyReportMapper;

    /**
     * 销售月报表
     */
    @Override
    public Response saleReport(SalesMonthlyRequest request) {
        if (request.getCounterId() == null || request.getMonth() == null) {
            return Response.successMsg("柜台编码或时间不能为空");
        }
        //数据查询
        List<PosSalesMonthlyReportPo> posSalesMonthlyReportList = salesMonthlyReportMapper.queryMonthReport(request.getCounterId(),
                request.getMonth().atDay(1), request.getMonth().atEndOfMonth().plusDays(1));
        //构建净销售总数和总金额
        PosSalesMonthlyReportVo total = posSalesMonthlyReportList.isEmpty() ?
                PosSalesMonthlyReportVo.builder().qty(BigInteger.ZERO.intValue()).amt(BigDecimal.ZERO).build()
                : posSalesMonthlyReportList.parallelStream()
                .map(e -> PosSalesMonthlyReportVo.builder().qty(e.getGoodsQty()).amt(e.getRealAmt()).build())
                .reduce((acc, item) -> {
                    acc.setQty(item.getQty() + acc.getQty());
                    acc.setAmt(item.getAmt().add(acc.getAmt()));
                    return acc;
                }).get();
        HashMap<String, Object> map = Maps.newHashMap();
        map.put("agg", total);
        map.put("list", ObjectUtils.toList(posSalesMonthlyReportList, MonthlyReportVo.class));
        return Response.success(map);
    }


    /**
     * 销售月报表->销售明细报表->条件搜索
     */
    @Override
    public Response saleDetailReportCondition(MonthlyReportRequest request) {
        //添加查询结束时间
        LocalDate endTime = request.getTime() == null ? null : request.getTime().plusDays(1);
        //销售月报表->销售明细报表->条件搜索汇总
        PosMonthlyReportConditionPo posDetailReportConditionPos = salesMonthlyReportMapper.queryDetails(request, endTime);
        //List<PosDetailReportConditionPo> posDetailReportConditionPos1 = salesMonthlyReportMapper.queryType(request, endTime);
        //销售月报表->销售明细报表->条件搜索下半部分
        List<PosDetailReportConditionPo> list = salesMonthlyReportMapper.queryDetailsReport(request, endTime);
        List<Object> posReportConditionPoList = ObjectUtils.toList(list, PosDetailReportConditionVo.class);
        Map<String, Object> map = new HashMap<>();
        map.put("top1", posDetailReportConditionPos);
        //map.put("top2",posDetailReportConditionPos1);
        map.put("list", posReportConditionPoList);
        return Response.success(map);
    }

    /**
     * 销售月报表->销售明细报表->销售明细
     */
    @Override
    public Response saleDetail(String orderNo) {
        List<PosSalesDetailsPo> posSalesDetailsPosList = salesMonthlyReportMapper.querySaleDetail(orderNo);
        return Response.success(ObjectUtils.toList(posSalesDetailsPosList, PosSalesDetailsVo.class));
    }
}
