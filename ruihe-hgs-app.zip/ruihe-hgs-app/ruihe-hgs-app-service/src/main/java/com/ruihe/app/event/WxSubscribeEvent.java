package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import me.chanjar.weixin.mp.bean.message.WxMpXmlMessage;
import org.springframework.context.ApplicationEvent;


/**
 * 处理会员订阅
 *
 * @author LiangYuan
 * @date 2021-01-23 18:01
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class WxSubscribeEvent extends ApplicationEvent {

    private WxMpXmlMessage msg;

    public WxSubscribeEvent(Object source, WxMpXmlMessage msg) {
        super(source);
        this.msg = msg;
    }
}
