package com.ruihe.app.service.order;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.google.gson.internal.LinkedHashTreeMap;
import com.ruihe.app.request.SalesRequest;
import com.ruihe.common.dao.bean.base.Product;
import com.ruihe.common.dao.bean.promotion.ProductScope;
import com.ruihe.common.dao.bean.promotion.PromotionActivity;
import com.ruihe.common.dao.bean.promotion.RewardCloud;
import com.ruihe.common.util.LambdaUtil;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.enums.promotion.PromotionalEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.common.pojo.response.promotion.ActivityProductResponse;
import com.ruihe.common.service.CustomService;
import com.ruihe.common.pojo.request.promotion.SalesProductRequest;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.app.service.order.impl.OperationMatchCount;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 非整单逻辑处理
 *
 * @Author 胡坤
 * @Date 2019年10月24日14:41:23
 */
@Slf4j
@DS(DBConst.SLAVE)
@Service
public class ScatteredService {

    @Autowired
    private SalesOrderService salesOrderService;

    @Autowired
    private CustomService customService;

    @Autowired
    private OperationMatchCount operationMatchCount;

    /**
     * @param promotionActivity 要进行判断的是否能够能匹配上本次购买的活动
     * @param salesRequest      前端传过来的购买参数
     * @return 是否能匹配上
     */
    @Ella(Describe = "是否满足购买条件 (满足  返回true  不满足 返回false)")
    public Boolean checkSheet(PromotionActivity promotionActivity, SalesRequest salesRequest) {
        List<RewardCloud> rewardClouds = customService.selectList(RewardCloud.builder().isDel(CommonStatusEnum.EFFECTIVE.getCode()).cloudMethod(0).promotionalUid(promotionActivity.getUid()).build());
        if (rewardClouds.isEmpty()) {
            return true;
        }
        /**
         * 对分购物车是商品进行分类排序处理  指定->分类->范围(指定)->范围(分类)
         */
        Map<String, ActivityProductResponse> map = new HashMap<>();
        if (this.checkFix(salesRequest, rewardClouds, map, promotionActivity) //下单促销活动匹配
                && this.checkSelect(salesRequest, rewardClouds, map, promotionActivity)) {
            LambdaUtil lambdaUtil = LambdaUtil.builder().count(1).build();
            matchActivityCount(salesRequest, rewardClouds, lambdaUtil, promotionActivity, map);
            promotionActivity.setCount(lambdaUtil.getCount());
            map.forEach((k, v) -> {
                if (v.getCount() > promotionActivity.getCount()) {
                    v.setCount(promotionActivity.getCount());
                    map.put(k, v);
                }
            });
            promotionActivity.setMap(map);
            return true;
        }
        return false;
    }

    @Ella(Describe = "匹配活动", Author = "K")
    public void matchActivityCount(SalesRequest salesRequest, List<RewardCloud> rewardClouds, LambdaUtil lambdaUtil, PromotionActivity promotionActivity, Map<String, ActivityProductResponse> map) {
        if (promotionActivity.getMatchingCount() > lambdaUtil.getCount()) {
            if (checkFix(salesRequest, rewardClouds, map, promotionActivity) && checkSelect(salesRequest, rewardClouds, map, promotionActivity)) {
                lambdaUtil.setCount(lambdaUtil.getCount() + 1);
                matchActivityCount(salesRequest, rewardClouds, lambdaUtil, promotionActivity, map);
            }
        }
    }

    @Ella(Describe = "对条件进行排序")
    public void sortRewards(Map<Integer, List<RewardCloud>> map, Map<Integer, List<RewardCloud>> linkMap, Integer cloudType) {
        map.forEach((k, v) -> {
            v.stream().forEach(rewardCloud -> {
                if (rewardCloud.getConditionType().equals(cloudType)) {//特定产品
                    linkMap.put(k, v);
                }
            });
        });
    }

    @Ella(Describe = "固定和选择排序")
    public Map<Integer, List<RewardCloud>> sortAll(List<RewardCloud> rewardClouds, Integer cloudType) {
        Map<Integer, List<RewardCloud>> map = new HashMap<>();

        for (RewardCloud rewardCloud : rewardClouds) {
            if (rewardCloud.getCloudType().equals(cloudType)) {
                List<RewardCloud> rewardClouds1 = map.get(rewardCloud.getCount());
                if (rewardClouds1 != null) {
                    rewardClouds1.add(rewardCloud);
                    map.put(rewardCloud.getCount(), rewardClouds1);
                } else {
                    rewardClouds1 = new ArrayList<>();
                    rewardClouds1.add(rewardCloud);
                    map.put(rewardCloud.getCount(), rewardClouds1);
                }
            }
        }
        Map<Integer, List<RewardCloud>> linkMap = new LinkedHashTreeMap<>();
        sortRewards(map, linkMap, PromotionalEnum.PRO2.getKey());//指定产品进行排列
        sortRewards(map, linkMap, PromotionalEnum.PRO6.getKey());//分类进行排列
        sortRewards(map, linkMap, PromotionalEnum.PRO1.getKey());//范围进行排列
        return linkMap;
    }

    /**
     * @param salesRequest      购买的请求
     * @param rewardClouds      非整单条件需要满足的限定商品
     * @param map
     * @param promotionActivity 非整单条件的活动
     * @return 固定组合是否满足条件本次购买
     */
    @Ella(Describe = "是否满足固定组合")
    public Boolean checkFix(SalesRequest salesRequest, List<RewardCloud> rewardClouds, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        LambdaUtil lambdaUtil = LambdaUtil.builder().flag(true).build();
        Map<Integer, List<RewardCloud>> linkMap = this.sortAll(rewardClouds, 0);
        List<Boolean> booleanList = new ArrayList<>();
        this.matchFix(linkMap, booleanList, salesRequest, lambdaUtil, map, promotionActivity);
        return lambdaUtil.getFlag();
    }

    /**
     * @param linkMap           对非整单购买条件分组后的产品(特定、小类、特定产品)
     * @param booleanList
     * @param salesRequest      购买参数
     * @param lambdaUtil
     * @param map
     * @param promotionActivity
     */
    @Ella(Describe = "固定匹配")
    private void matchFix(Map<Integer, List<RewardCloud>> linkMap, List<Boolean> booleanList, SalesRequest salesRequest, LambdaUtil lambdaUtil, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        linkMap.forEach((k, v) -> {
            Integer proRange = v.get(0).getProRange();
            if (proRange.equals(PromotionalEnum.PRO2.getKey())) {//指定商品
                if (appoint(salesRequest, v, map, promotionActivity)) {
                    booleanList.add(true);
                } else {
                    booleanList.add(false);
                }
            } else if (proRange.equals(PromotionalEnum.PRO6.getKey())) {//产品小类
                if (classification(salesRequest, v, map, promotionActivity)) {
                    booleanList.add(true);
                } else {
                    booleanList.add(false);
                }
            } else if (proRange.equals(PromotionalEnum.PRO1.getKey())) {//产品范围
                if (fixedProductScope(salesRequest, v, map, promotionActivity)) {
                    booleanList.add(true);
                } else {
                    booleanList.add(false);
                }
            } else {
                log.error("未知条件类型type={}", proRange);
                throw new BizException("未知条件类型");
            }
        });
        booleanList.stream().forEach(flag -> {
            if (!flag) {
                lambdaUtil.setFlag(false);
            }
        });
    }

    @Ella(Describe = "商品范围(固定组合类型) 固定组合只有一个")
    public Boolean fixedProductScope(SalesRequest salesRequest, List<RewardCloud> rewardClouds, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        List<RewardCloud> rewardClouds3 = operationProduct(rewardClouds, 0, PromotionalEnum.PRO1.getKey());//得到购买(固定)的组合--商品范围
        if (rewardClouds3 != null && !rewardClouds3.isEmpty()) {
            //固定组合
            return scopeAppoint(salesRequest, rewardClouds3, map, promotionActivity) && scopeClassification(salesRequest, rewardClouds3, map, promotionActivity);
        }
        return true;
    }

    @Ella(Describe = "商品范围-----指定商品(固定组合类型)")
    public Boolean scopeAppoint(SalesRequest salesRequest, List<RewardCloud> rewardClouds, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        for (RewardCloud rewardCloud : rewardClouds) {
            //填充指定商品
            List<ProductScope> productScopes = customService.selectList(ProductScope.builder().activityUid(rewardCloud.getPromotionalUid()).rewardUid(rewardCloud.getRewardUid()).proRange(PromotionalEnum.PRO2.getKey()).cloudMethod(rewardCloud.getCloudMethod()).count(rewardCloud.getCount()).cloudType(rewardCloud.getCloudType()).isDel(CommonStatusEnum.EFFECTIVE.getCode()).build());
            if (productScopes == null || productScopes.isEmpty()) {
                continue;
            }
            productScopes.stream().forEach(productScope -> {
                Product product = customService.select(Product.builder().prdBarCode(productScope.getSpecificProductId()).build());
                productScope.setNormalPrice(product.getSalePrice().toString());
            });
            //价格从低到高进行排序
            Collections.sort(productScopes, new Comparator<ProductScope>() {
                @Override
                public int compare(ProductScope productScope, ProductScope productScopeOther) {
                    return new BigDecimal(productScopeOther.getNormalPrice()).compareTo(new BigDecimal(productScope.getNormalPrice()));
                }
            });
            Map<Serializable, SalesProductRequest> data = salesOrderService.fillData(salesRequest);
            //进行比较
            return fixedScopeCompareOther(productScopes, data, rewardCloud, salesRequest, map, promotionActivity);
        }
        return true;
    }

    @Ella(Describe = "商品范围----商品分类(固定组合类型)")
    public Boolean scopeClassification(SalesRequest salesRequest, List<RewardCloud> rewardClouds, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        for (RewardCloud rewardCloud : rewardClouds) {
            //查询范围里面的分类信息
            List<ProductScope> productScopes = customService.selectList(ProductScope.builder().activityUid(rewardCloud.getPromotionalUid()).rewardUid(rewardCloud.getRewardUid()).proRange(PromotionalEnum.PRO6.getKey()).cloudMethod(0).count(rewardCloud.getCount()).cloudType(rewardCloud.getCloudType()).isDel(CommonStatusEnum.EFFECTIVE.getCode()).build());
            if (productScopes == null || productScopes.isEmpty()) {
                continue;
            }
            Map<Serializable, List<SalesProductRequest>> listMap = operationMatchCount.operationClass(salesRequest.getProducts());
            return fixedScopeCompare(productScopes, listMap, rewardCloud, salesRequest, map, promotionActivity);
        }
        return true;
    }

    @Ella(Describe = "购买商品降序排列", Author = "K")
    public void sortProduct(List<SalesProductRequest> products) {
        Collections.sort(products, new Comparator<SalesProductRequest>() {
            @Override
            public int compare(SalesProductRequest salesProductRequest, SalesProductRequest salesProductRequestOther) {
                return new BigDecimal(salesProductRequestOther.getProPrice()).compareTo(new BigDecimal(salesProductRequest.getProPrice()));
            }
        });
    }


    @Ella(Describe = "购买商品降升序排列")
    public void sortProductAnther(List<SalesProductRequest> products) {
        Collections.sort(products, new Comparator<SalesProductRequest>() {
            @Override
            public int compare(SalesProductRequest salesProductRequest, SalesProductRequest salesProductRequestOther) {
                return new BigDecimal(salesProductRequest.getProPrice()).compareTo(new BigDecimal(salesProductRequestOther.getProPrice()));
            }
        });
    }

    @Ella(Describe = "范围商品进行排序", Author = "K")
    public void sortScopeProduct(List<ProductScope> productScopes) {
        Collections.sort(productScopes, new Comparator<ProductScope>() {
            @Override
            public int compare(ProductScope productScope, ProductScope productScopeOther) {

                return new BigDecimal(productScopeOther.getNormalPrice()).compareTo(new BigDecimal(productScope.getNormalPrice()));
            }
        });
    }

    @Ella(Describe = "是否满足选择组合")
    public Boolean checkSelect(SalesRequest salesRequest, List<RewardCloud> rewardClouds, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        LambdaUtil lambdaUtil = LambdaUtil.builder().flag(true).build();
        Map<Integer, List<RewardCloud>> linkMap = sortAll(rewardClouds, 1);
        List<Boolean> booleanList = new ArrayList<>();
        matchSelect(linkMap, booleanList, salesRequest, lambdaUtil, map, promotionActivity);
        return lambdaUtil.getFlag();
    }

    @Ella(Describe = "选择组合")
    public void matchSelect(Map<Integer, List<RewardCloud>> linkMap, List<Boolean> booleanList, SalesRequest salesRequest, LambdaUtil lambdaUtil, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        linkMap.forEach((k, v) -> {
            Integer proRange = v.get(0).getProRange();
            if (proRange.equals(PromotionalEnum.PRO2.getKey())) {
                if (selectAppointUtil(salesRequest, v, map)) {
                    booleanList.add(true);
                } else {
                    booleanList.add(false);
                }
            } else if (proRange.equals(PromotionalEnum.PRO6.getKey())) {
                if (selectClassificationUtil(salesRequest, v, map)) {
                    booleanList.add(true);
                } else {
                    booleanList.add(false);
                }
            } else if (proRange.equals(PromotionalEnum.PRO1.getKey())) {
                if (selectProductScope(salesRequest, v, map, promotionActivity)) {
                    booleanList.add(true);
                } else {
                    booleanList.add(false);
                }
            } else {
                log.error("未知条件类型type={}", proRange);
                throw new BizException("未知条件类型");
            }
        });
        booleanList.stream().forEach(flag -> {
            if (!flag) {
                lambdaUtil.setFlag(false);
            }
        });
    }

    @Ella(Describe = "商品分类判断----(固定组合类型)")
    public Boolean classification(SalesRequest salesRequest, List<RewardCloud> rewardClouds, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        List<RewardCloud> collect = rewardClouds.stream().filter(rewardCloud -> rewardCloud.getCloudType().equals(0)).filter(rewardCloud -> rewardCloud.getProRange().equals(PromotionalEnum.PRO6.getKey())).map(rewardCloud -> {
            RewardCloud build = RewardCloud.builder().build();
            BeanUtils.copyProperties(rewardCloud, build);
            return build;
        }).collect(Collectors.toList());
        if (collect != null && !collect.isEmpty()) {
            Map<Serializable, List<SalesProductRequest>> listMap = operationMatchCount.operationClass(salesRequest.getProducts());
            return fixedCompare(collect, listMap, salesRequest, map, promotionActivity);
        }
        return true;

    }

    @Ella(Describe = "指定商品----(固定组合类型)")
    public Boolean appoint(SalesRequest salesRequest, List<RewardCloud> rewardClouds, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        List<RewardCloud> collect = rewardClouds.stream().filter(rewardCloud -> rewardCloud.getCloudType().equals(0)).filter(rewardCloud -> rewardCloud.getProRange().equals(PromotionalEnum.PRO2.getKey())).map(rewardCloud -> {
            RewardCloud build = RewardCloud.builder().build();
            BeanUtils.copyProperties(rewardCloud, build);
            return build;
        }).collect(Collectors.toList());
        if (collect != null && !collect.isEmpty()) {
            sortAppointProduct(collect);
            Map<Serializable, SalesProductRequest> listMap = salesOrderService.fillData(salesRequest);
            return fixedCompareOther(collect, listMap, salesRequest, map, promotionActivity);
        }
        return true;
    }

    @Ella(Describe = "固定-范围-商品分类")
    public Boolean fixedScopeCompare(List<ProductScope> productScopes, Map<Serializable, List<SalesProductRequest>> data, RewardCloud rewardCloud, SalesRequest salesRequest, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        LambdaUtil lambdaUtil = LambdaUtil.builder().count(0).build();
        List<SalesProductRequest> salesProductRequestList = new ArrayList<>();//符合范围的商品暂存
        Map<String, SalesProductRequest> activitiesMap = promotionActivity.getActivitiesMap();
        if (activitiesMap == null) {
            activitiesMap = new HashMap<>();
        }
        for (ProductScope productScope : productScopes) {
            //先判断数量总数量上是否满足
            List<SalesProductRequest> list = data.get(productScope.getProductClassId());
            if (list != null) {
                salesProductRequestList.addAll(list);
                //如果获取到了商品再进行数量/金额/金额范围比较--现在只有数量比较
                list.stream().forEach(salesProductRequest -> {
                    lambdaUtil.setCount(lambdaUtil.getCount() + Integer.parseInt(salesProductRequest.getProCount()));
                });
            }
        }
        Integer ant = Integer.parseInt(rewardCloud.getInputValues());//规定的数量
        if (lambdaUtil.getCount() >= ant) {//数量上满足
            //价格从高到低进行排序
            sortDesc(salesProductRequestList, salesRequest.getFlag());
            for (SalesProductRequest salesProductRequest : salesProductRequestList) {//参加活动的商品,以及商品数量扣除
                if (ant > 0) {
                    Product product = customService.select(Product.builder().prdBarCode(salesProductRequest.getProId()).build());
//                    activitiesMap.put(salesProductRequest.getProId(), salesProductRequest);
                    Integer count = Integer.parseInt(salesProductRequest.getProCount());
                    Integer surplus = count - ant;
                    /**
                     * 进行符合商品分割
                     */
                    ActivityProductResponse activityProductResponse = map.get(salesProductRequest.getProId());
                    if (activityProductResponse != null) {
                        Integer sum = activityProductResponse.getTotal() + (surplus >= 0 ? ant : Integer.parseInt(salesProductRequest.getProCount()));
                        activityProductResponse.setCount(activityProductResponse.getCount() + 1);
                        activityProductResponse.setTotal(sum);
                        map.put(salesProductRequest.getProId(), activityProductResponse);
                    } else {
                        ActivityProductResponse build = ActivityProductResponse
                                .builder()
                                .customTotal(Integer.parseInt(rewardCloud.getInputValues()))
                                .proBarCode(salesProductRequest.getProId())
                                .goodsBarCode(salesProductRequest.getProCode())
                                .normalPrice(product.getSalePrice().toString())
                                .memberPrice(product.getMemberPrice().toString())
                                .proName(product.getPrdName())
                                .count(1)
                                .total(surplus >= 0 ? ant : Integer.parseInt(salesProductRequest.getProCount()))
                                .build();
                        map.put(salesProductRequest.getProId(), build);
                    }
                    /**
                     * 第N件折扣逻辑处理
                     */
                    if (promotionActivity.getRewardType().equals(PromotionalEnum.JIANGLI6.getKey())) {
                        SalesProductRequest mapSales = activitiesMap.get(salesProductRequest.getProId());
                        if (mapSales != null) {
                            Integer sum = Integer.parseInt(mapSales.getProCount()) + (surplus >= 0 ? ant : Integer.parseInt(salesProductRequest.getProCount()));
                            mapSales.setProCount(sum.toString());
                        } else {
                            activitiesMap.put(salesProductRequest.getProId(), SalesProductRequest
                                    .builder()
                                    .proCount(surplus >= 0 ? ant.toString() : salesProductRequest.getProCount())
                                    .proId(salesProductRequest.getProId())
                                    .build());
                        }
                        //重置参与活动的商品信息
                        promotionActivity.setActivitiesMap(activitiesMap);
                    }
                    ant = surplus >= 0 ? 0 : ant - count;
                    salesProductRequest.setProCount(surplus > 0 ? surplus.toString() : "0");
                    if (surplus < 0) {
                        continue;
                    }
                }
            }
            //重置商品
            productReset(salesRequest, salesProductRequestList);
            return true;
        }
        return false;
    }


    @Ella(Describe = "固定-范围-指定商品")
    public Boolean fixedScopeCompareOther(List<ProductScope> productScopes, Map<Serializable, SalesProductRequest> data, RewardCloud rewardCloud, SalesRequest salesRequest, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        LambdaUtil lambdaUtil = LambdaUtil.builder().count(0).build();
        List<SalesProductRequest> salesProductRequestList = new ArrayList<>();//符合范围条件的商品
        Map<String, SalesProductRequest> activitiesMap = promotionActivity.getActivitiesMap();
        if (activitiesMap == null) {
            activitiesMap = new HashMap<>();
        }
        productScopes.stream().forEach(productScope -> {//计算数量满足的条件
            SalesProductRequest salesProductRequest = data.get(productScope.getSpecificProductId());
            if (salesProductRequest != null) {
                salesProductRequestList.add(salesProductRequest);
                lambdaUtil.setCount(lambdaUtil.getCount() + Integer.parseInt(salesProductRequest.getProCount()));
            }
        });
        Integer anInt = Integer.parseInt(rewardCloud.getInputValues());
        if (lambdaUtil.getCount() >= anInt) {//满足数量条件
            //价格从高到低进行排序
            sortDesc(salesProductRequestList, salesRequest.getFlag());
            for (SalesProductRequest salesProductRequest : salesProductRequestList) {
                if (Integer.parseInt(salesProductRequest.getProCount()) <= 0) {
                    continue;
                }
                if (anInt > 0) {
                    Product product = customService.select(Product.builder().prdBarCode(salesProductRequest.getProId()).build());
                    Integer surplus = Integer.parseInt(salesProductRequest.getProCount()) - anInt;
                    /**
                     * 进行符合商品分割
                     */
                    ActivityProductResponse activityProductResponse = map.get(salesProductRequest.getProId());
                    if (activityProductResponse != null) {
                        activityProductResponse.setCount(activityProductResponse.getCount() + 1);
                        Integer count = activityProductResponse.getTotal() + (surplus >= 0 ? anInt : Integer.parseInt(salesProductRequest.getProCount()));
                        activityProductResponse.setTotal(count);
                        map.put(salesProductRequest.getProId(), activityProductResponse);
                    } else {
                        ActivityProductResponse build = ActivityProductResponse
                                .builder()
                                .customTotal(Integer.parseInt(rewardCloud.getInputValues()))
                                .proBarCode(salesProductRequest.getProId())
                                .goodsBarCode(salesProductRequest.getProCode())
                                .normalPrice(product.getSalePrice().toString())
                                .memberPrice(product.getMemberPrice().toString())
                                .proName(product.getPrdName())
                                .count(1)
                                .total(surplus >= 0 ? anInt : Integer.parseInt(salesProductRequest.getProCount()))
                                .build();
                        map.put(salesProductRequest.getProId(), build);
                    }
                    /**
                     * 第N件折扣逻辑处理
                     */
                    if (promotionActivity.getRewardType().equals(PromotionalEnum.JIANGLI6.getKey())) {
                        log.info("进入第N件折扣处理逻辑");
                        SalesProductRequest mapSales = activitiesMap.get(salesProductRequest.getProId());
                        if (mapSales != null) {
                            Integer count = Integer.parseInt(mapSales.getProCount()) + (surplus >= 0 ? anInt : Integer.parseInt(salesProductRequest.getProCount()));
                            mapSales.setProCount(count.toString());
                            activitiesMap.put(salesProductRequest.getProId(), mapSales);
                        } else {
                            activitiesMap.put(salesProductRequest.getProId(), SalesProductRequest
                                    .builder()
                                    .proCount(surplus >= 0 ? anInt.toString() : salesProductRequest.getProCount())
                                    .proId(salesProductRequest.getProId())
                                    .build());
                        }
                        promotionActivity.setActivitiesMap(activitiesMap);
                    }
                    anInt = surplus >= 0 ? 0 : anInt - Integer.parseInt(salesProductRequest.getProCount());
                    salesProductRequest.setProCount(surplus >= 0 ? surplus.toString() : "0");
                    if (surplus < 0) {
                        continue;
                    }
                }
            }
            //商品重置
            productReset(salesRequest, salesProductRequestList);
            return true;
        }
        return false;
    }

    @Ella(Describe = "产品范围--商品重置", Author = "K")
    public void productReset(SalesRequest salesRequest, List<SalesProductRequest> salesProductRequests) {
        List<SalesProductRequest> products = salesRequest.getProducts();
        products.stream().forEach(salesProductRequest -> {
            salesProductRequests.stream().forEach(salesProductRequestOther -> {
                if (salesProductRequest.getProId().equals(salesProductRequestOther.getProId())) {
                    salesProductRequest.setProCount(salesProductRequestOther.getProCount());
                }
            });
        });
        salesRequest.setProducts(products);
    }


    @Ella(Describe = "产品范围--价格从高到低排序", Author = "K")
    public void sortDesc(List<SalesProductRequest> salesProductRequestList, Boolean flag) {
        Collections.sort(salesProductRequestList, new Comparator<SalesProductRequest>() {
            @Override
            public int compare(SalesProductRequest salesProductRequest, SalesProductRequest salesProductRequestOther) {
                Product product = customService.select(Product.builder().prdBarCode(salesProductRequest.getProId()).build());
                Product productOther = customService.select(Product.builder().prdBarCode(salesProductRequestOther.getProId()).build());
                return flag ? productOther.getMemberPrice().compareTo(product.getMemberPrice()) :
                        productOther.getSalePrice().compareTo(product.getSalePrice());
            }
        });
    }

    @Ella(Describe = "根据会员信息由低到高排列", Author = "K")
    public void sortAsc(List<SalesProductRequest> salesProductRequestList, Boolean flag) {
        Collections.sort(salesProductRequestList, new Comparator<SalesProductRequest>() {
            @Override
            public int compare(SalesProductRequest salesProductRequest, SalesProductRequest salesProductRequestOther) {
                Product product = customService.select(Product.builder().prdBarCode(salesProductRequest.getProId()).build());
                Product productOther = customService.select(Product.builder().prdBarCode(salesProductRequestOther.getProId()).build());
                return flag ? product.getMemberPrice().compareTo(productOther.getMemberPrice()) :
                        product.getSalePrice().compareTo(productOther.getSalePrice());
            }
        });
    }

    @Ella(Describe = "固定-指定商品")
    public Boolean fixedCompareOther(List<RewardCloud> collect, Map<Serializable, SalesProductRequest> data, SalesRequest salesRequest, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        for (RewardCloud rewardCloud : collect) {
            SalesProductRequest salesProductRequest = data.get(rewardCloud.getSpecificProductId());
            if (salesProductRequest == null || !operationCondition(rewardCloud, Integer.parseInt(salesProductRequest.getProCount()))) {
                return false;
            }
        }
        Map<String, SalesProductRequest> activitiesMap = promotionActivity.getActivitiesMap();
        if (activitiesMap == null) {
            activitiesMap = new HashMap<>();
        }
        for (RewardCloud rewardCloud : collect) {
            SalesProductRequest salesProductRequest = data.get(rewardCloud.getSpecificProductId());
            //进行扣除
            List<SalesProductRequest> products = salesRequest.getProducts();
            Iterator<SalesProductRequest> iterator = products.iterator();
            while (iterator.hasNext()) {
                SalesProductRequest next = iterator.next();
                if (next.getProId().equals(salesProductRequest.getProId())) {
                    Product product = customService.select(Product.builder().prdBarCode(salesProductRequest.getProId()).build());
                    Integer count = Integer.parseInt(next.getProCount()) - Integer.parseInt(rewardCloud.getInputValues());
                    if (count <= 0) {
                        iterator.remove();
                    }
                    if (promotionActivity.getRewardType().equals(PromotionalEnum.JIANGLI6.getKey())) {
                        //活动商品统计
                        SalesProductRequest salesProductRequestOther = activitiesMap.get(next.getProId());
                        if (salesProductRequestOther == null) {
                            activitiesMap.put(next.getProId(), SalesProductRequest
                                    .builder()
                                    .proCount(rewardCloud.getInputValues())
                                    .proId(next.getProId())
                                    .build());
                        } else {
                            Integer sum = Integer.parseInt(salesProductRequestOther.getProCount()) + Integer.parseInt(rewardCloud.getInputValues());
                            salesProductRequestOther.setProCount(sum.toString());
                            activitiesMap.put(next.getProId(), salesProductRequestOther);
                        }
                        promotionActivity.setActivitiesMap(activitiesMap);
                    }
                    next.setProCount(count.toString());
                    operationReward(map, next, product, rewardCloud);
                }
            }
            //修改完毕
            salesRequest.setProducts(products);
        }
        return true;
    }

    @Ella(Describe = "固定-分类")
    public Boolean fixedCompare(List<RewardCloud> collect, Map<Serializable, List<SalesProductRequest>> data, SalesRequest salesRequest, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        for (RewardCloud rewardCloud : collect) {
            List<SalesProductRequest> list = data.get(rewardCloud.getProductClassId());
            if (list == null || list.isEmpty()) {
                return false;
            }
            LambdaUtil lambdaUtil = LambdaUtil.builder().count(0).build();
            list.stream().forEach(salesProductRequest -> {
                lambdaUtil.setCount(lambdaUtil.getCount() + Integer.parseInt(salesProductRequest.getProCount()));
            });
            //如果获取到了商品再进行数量/金额/金额范围比较--现在只有数量比较
            if (!operationCondition(rewardCloud, lambdaUtil.getCount())) {
                return false;
            }
        }
        Map<String, SalesProductRequest> activitiesMap = promotionActivity.getActivitiesMap();
        if (activitiesMap == null) {
            activitiesMap = new HashMap<>();
        }
        List<SalesProductRequest> salesProductRequestList = new ArrayList<>();
        for (RewardCloud rewardCloud : collect) {
            List<SalesProductRequest> list = data.get(rewardCloud.getProductClassId());
            //进行排序
            sortProduct(list);
            //移除指定分类的数量
            Integer customCount = Integer.parseInt(rewardCloud.getInputValues());
            Iterator<SalesProductRequest> iterator = list.iterator();
            while (iterator.hasNext()) {
                //判断第一个商品是否满足,如果不满足就下一个
                SalesProductRequest next = iterator.next();
                Product product = customService.select(Product.builder().prdBarCode(next.getProId()).build());
                operationReward(map, next, product, rewardCloud);
                Integer count = Integer.parseInt(next.getProCount());
                SalesProductRequest salesProductRequest = activitiesMap.get(next.getProId());
                //活动商品处理
                if (promotionActivity.getRewardType().equals(PromotionalEnum.JIANGLI6.getKey())) {
                    if (salesProductRequest != null) {
                        Integer sum = Integer.parseInt(salesProductRequest.getProCount()) + (count >= customCount ? customCount : Integer.parseInt(salesProductRequest.getProCount()));
                        salesProductRequest.setProCount(sum.toString());
                        activitiesMap.put(salesProductRequest.getProId(), salesProductRequest);
                    } else {
                        activitiesMap.put(next.getProId(), SalesProductRequest
                                .builder()
                                .proCount(count >= customCount ? customCount.toString() : count.toString())
                                .proId(next.getProId())
                                .build());
                    }
                    promotionActivity.setActivitiesMap(activitiesMap);
                }
                if (count >= customCount) {
                    Integer result = count - customCount;
                    next.setProCount(result.toString());
                    salesProductRequestList.add(next);
                    break;//跳出循环
                } else {
                    customCount = customCount - count;
                    next.setProCount("0");
                    salesProductRequestList.add(next);
                    iterator.remove();
                    continue;
                }
            }
        }
        //匹配完成一次需要对数据进行更新
        salesRequest.getProducts().stream().forEach(salesProductRequest -> {
            salesProductRequestList.stream().forEach(salesProductRequest1 -> {
                if (salesProductRequest1.getProId().equals(salesProductRequest.getProId())) {
                    salesProductRequest.setProCount(salesProductRequest1.getProCount());
                }
            });
        });
        List<SalesProductRequest> products = salesRequest.getProducts();
        Iterator<SalesProductRequest> iterator = products.iterator();
        while (iterator.hasNext()) {
            SalesProductRequest next = iterator.next();
            if (next.getProCount().equals("0")) {
                iterator.remove();
            }
        }
        salesRequest.setProducts(null);
        salesRequest.setProducts(products);
        return true;
    }

    @Ella(Describe = "填充非整单-套装特价")
    public void operationReward(Map<String, ActivityProductResponse> map, SalesProductRequest salesProductRequest, Product product, RewardCloud rewardCloud) {
        ActivityProductResponse activityProductResponse = map.get(salesProductRequest.getProId());
        if (activityProductResponse != null) {
            activityProductResponse.setCount(activityProductResponse.getCount() + 1);
            activityProductResponse.setTotal(activityProductResponse.getCount() * Integer.parseInt(rewardCloud.getInputValues()));
            map.put(salesProductRequest.getProId(), activityProductResponse);
        } else {
            ActivityProductResponse build = ActivityProductResponse
                    .builder()
                    .customTotal(Integer.parseInt(rewardCloud.getInputValues()))
                    .proBarCode(product.getPrdBarCode())
                    .goodsBarCode(product.getGoodsBarCode())
                    .normalPrice(product.getSalePrice().toString())
                    .memberPrice(product.getMemberPrice().toString())
                    .proName(product.getPrdName())
                    .count(1)
                    .total(1 * Integer.parseInt(rewardCloud.getInputValues()))
                    .build();
            map.put(salesProductRequest.getProId(), build);
        }
    }

    @Ella(Describe = "商品范围(选择组合类型) ")
    public Boolean selectProductScope(SalesRequest salesRequest, List<RewardCloud> rewardClouds, Map<String, ActivityProductResponse> map, PromotionActivity promotionActivity) {
        List<RewardCloud> collect = rewardClouds.stream().filter(rewardCloud -> rewardCloud.getCloudType().equals(1)).filter(rewardCloud -> rewardCloud.getProRange().equals(PromotionalEnum.PRO1.getKey())).map(rewardCloud -> {//得到选择组合产品范围
            RewardCloud build = RewardCloud.builder().build();
            BeanUtils.copyProperties(rewardCloud, build);
            return build;
        }).collect(Collectors.toList());
        if (collect != null && !collect.isEmpty()) {
            return scopeClassification(salesRequest, collect, map, promotionActivity) && scopeAppoint(salesRequest, collect, map, promotionActivity);
        }
        return true;
    }

    @Ella(Describe = "商品分类----(选择组合类型)")
    public Boolean selectClassificationUtil(SalesRequest salesRequest, List<RewardCloud> rewardClouds, Map<String, ActivityProductResponse> map) {
        List<RewardCloud> collect = rewardClouds.stream().filter(rewardCloud -> rewardCloud.getCloudType().equals(1)).filter(rewardCloud -> rewardCloud.getProRange().equals(PromotionalEnum.PRO6.getKey())).map(rewardCloud -> {//得到选择组合特定产品
            RewardCloud build = RewardCloud.builder().build();
            BeanUtils.copyProperties(rewardCloud, build);
            return build;
        }).collect(Collectors.toList());
        if (collect != null && !collect.isEmpty()) {
            Map<Serializable, List<SalesProductRequest>> listMap = operationMatchCount.operationClass(salesRequest.getProducts());
            return selectCompareUtilOther(collect, listMap, salesRequest, map);
        }
        return true;
    }

    @Ella(Describe = "指定商品----(选择组合类型)")
    public Boolean selectAppointUtil(SalesRequest salesRequest, List<RewardCloud> rewardClouds, Map<String, ActivityProductResponse> map) {
        List<RewardCloud> collect = rewardClouds.stream().filter(rewardCloud -> rewardCloud.getCloudType().equals(1)).filter(rewardCloud -> rewardCloud.getProRange().equals(PromotionalEnum.PRO2.getKey())).map(rewardCloud -> {//得到选择组合特定产品
            RewardCloud build = RewardCloud.builder().build();
            BeanUtils.copyProperties(rewardCloud, build);
            return build;
        }).collect(Collectors.toList());
        //进行排序
        sortAppointProduct(collect);
        if (!collect.isEmpty()) {
            Map<Serializable, SalesProductRequest> data = salesOrderService.fillData(salesRequest);
            return selectCompareUtil(collect, data, salesRequest, map);
        }

        return true;
    }

    @Ella(Describe = "根据价格进行排序", Author = "K")
    public List<RewardCloud> sortAppointProduct(List<RewardCloud> rewardClouds) {
        rewardClouds.stream().forEach(rewardCloud -> {
            Product product = customService.select(Product.builder().prdBarCode(rewardCloud.getSpecificProductId()).build());
            if (product == null) {
                log.error("购买的商品现不存在我们商品库中~{}", rewardCloud.getSpecificProductId());
                throw new BizException("购买的商品现不存在我们商品库中,请先同步商品信息::rewardCloud.getSpecificProductId()");
            }
            rewardCloud.setNormalPrice(product.getSalePrice().toString());
            rewardCloud.setMemberPrice(product.getMemberPrice().toString());
        });
        if (rewardClouds.size() > 1) {
            Collections.sort(rewardClouds, new Comparator<RewardCloud>() {
                @Override
                public int compare(RewardCloud rewardCloud, RewardCloud rewardCloudOther) {
                    return new BigDecimal(rewardCloudOther.getNormalPrice()).compareTo(new BigDecimal(rewardCloud.getNormalPrice()));
                }
            });
        }
        return rewardClouds;
    }

    @Ella(Describe = "数据进行比较  选择-指定商品")
    public Boolean selectCompareUtil(List<RewardCloud> rewardClouds, Map<Serializable, SalesProductRequest> data, SalesRequest salesRequest, Map<String, ActivityProductResponse> map) {
        for (RewardCloud rewardCloud : rewardClouds) {
            SalesProductRequest salesProductRequest = data.get(rewardCloud.getSpecificProductId());
            if (salesProductRequest != null && operationCondition(rewardCloud, Integer.parseInt(salesProductRequest.getProCount()))) {
                //进行扣除
                List<SalesProductRequest> products = salesRequest.getProducts();
                Iterator<SalesProductRequest> iterator = products.iterator();
                while (iterator.hasNext()) {
                    SalesProductRequest next = iterator.next();
                    if (next.getProId().equals(salesProductRequest.getProId())) {
                        Product product = customService.select(Product.builder().prdBarCode(next.getProId()).build());
                        operationReward(map, next, product, rewardCloud);
                        Integer count = Integer.parseInt(next.getProCount()) - Integer.parseInt(rewardCloud.getInputValues());
                        next.setProCount(count.toString());
                        if (count.equals(0)) {
                            iterator.remove();
                        }
                    }
                }
                //修改完毕
                salesRequest.setProducts(products);
                return true;
            }
        }
        return false;
    }

    @Ella(Describe = "选择-商品分类")
    public Boolean selectCompareUtilOther(List<RewardCloud> collect, Map<Serializable, List<SalesProductRequest>> data, SalesRequest salesRequest, Map<String, ActivityProductResponse> map) {
        for (RewardCloud rewardCloud : collect) {
            List<SalesProductRequest> list = data.get(rewardCloud.getProductClassId());
            LambdaUtil lambdaUtil = LambdaUtil.builder().count(0).build();
            list.stream().forEach(salesProductRequest -> {
                lambdaUtil.setCount(lambdaUtil.getCount() + Integer.parseInt(salesProductRequest.getProCount()));
            });
            //如果获取到了商品再进行数量/金额/金额范围比较--现在只有数量比较
            if (operationCondition(rewardCloud, lambdaUtil.getCount())) {
                //进行排序
                sortProduct(list);
                //移除指定分类的数量
                Integer customCount = Integer.parseInt(rewardCloud.getInputValues());
                Iterator<SalesProductRequest> iterator = list.iterator();
                List<SalesProductRequest> salesProductRequestList = new ArrayList<>();
                while (iterator.hasNext()) {
                    //判断第一个商品是否满足,如果不满足就下一个
                    SalesProductRequest next = iterator.next();
                    Product product = customService.select(Product.builder().prdBarCode(next.getProId()).build());
                    operationReward(map, next, product, rewardCloud);
                    Integer count = Integer.parseInt(next.getProCount());
                    if (count >= customCount) {
                        Integer result = count - customCount;
                        next.setProCount(result.toString());
                        salesProductRequestList.add(next);
                        break;
                    } else {
                        customCount = customCount - count;
                        next.setProCount("0");
                        salesProductRequestList.add(next);
                        iterator.remove();
                    }
                }
                List<SalesProductRequest> products = salesRequest.getProducts();
                Iterator<SalesProductRequest> salesProductRequestIterator = products.iterator();
                while (salesProductRequestIterator.hasNext()) {
                    SalesProductRequest next = salesProductRequestIterator.next();
                    salesProductRequestList.stream().forEach(salesProductRequest -> {
                        if (next.getProId().equals(salesProductRequest.getProId())) {
                            next.setProCount(salesProductRequest.getProCount());
                            if (next.getProCount().equals("0")) {
                                iterator.remove();
                            }
                        }
                    });
                }
                salesRequest.setProducts(products);
                return true;
            }
        }
        return false;
    }

    @Ella(Describe = "判断数量/金额/金额范围是否满足 0 金额 1数量 2金额范围---目前只有数量")
    public Boolean operationCondition(RewardCloud rewardCloud, Integer proCount) {
        if (rewardCloud.getType().equals(1)) {//判断是否满足数量
            String inputValues = rewardCloud.getInputValues();
            //计算购买的商品的总数量
            if (proCount >= Integer.parseInt(inputValues)) {
                return true;
            }
            return false;
        } else {
            log.error("未知条件类型,type={}", rewardCloud);
            throw new BizException("未知条件类型");
        }
    }

    @Ella(Describe = "得到商品信息", Author = "K")
    public List<RewardCloud> operationProduct(List<RewardCloud> rewardClouds, Integer cloudType, Integer proRange) {
        return rewardClouds.stream()
                .filter(rewardCloud -> rewardCloud.getCloudType().equals(cloudType))
                .filter(rewardCloud -> rewardCloud.getProRange().equals(proRange))
                .map(rewardCloud -> {
                    RewardCloud build = RewardCloud.builder().build();
                    BeanUtils.copyProperties(rewardCloud, build);
                    return build;
                }).collect(Collectors.toList());
    }
}
