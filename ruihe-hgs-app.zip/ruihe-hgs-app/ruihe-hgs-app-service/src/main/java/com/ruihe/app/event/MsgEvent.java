package com.ruihe.app.event;

import com.ruihe.msger.dto.MsgerRequestDto;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;

/**
 * 短信发送事件
 *
 * @author William
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class MsgEvent extends ApplicationEvent {
    private MsgerRequestDto msgerRequestDto;

    /**
     * Create a new ApplicationEvent.
     *
     * @param source the object on which the event initially occurred (never {@code null})
     */
    public MsgEvent(Object source, MsgerRequestDto msgerRequestDto) {
        super(source);
        this.msgerRequestDto = msgerRequestDto;
    }
}
