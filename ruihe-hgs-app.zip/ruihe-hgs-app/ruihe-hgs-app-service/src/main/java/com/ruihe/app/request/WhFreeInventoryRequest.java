package com.ruihe.app.request;

import com.ruihe.app.enums.PosFreeInventoryStatusEnum;
import com.ruihe.common.annotation.EnumValidation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-22 16:12
 */
@ApiModel(value = "WhFreeInventoryRequest", description = "新增盘点单请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhFreeInventoryRequest implements Serializable {

    @ApiModelProperty(value = "盘点单号,新增的时候可以为空")
    private String applyNo;

    @ApiModelProperty(value = "盘点原因")
    private Integer invRsn;

    @EnumValidation(clazz = PosFreeInventoryStatusEnum.class, method = "getCode", message = "状态错误")
    @ApiModelProperty(value = "审核状态：0编辑中，1未审核，2一审通过，3一审拒绝，4审核通过，5审核拒绝")
    private Integer status;

    @NotBlank(message = "柜台编码不能为空")
    @ApiModelProperty(value = "柜台编码")
    private String counterId;

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "柜员id")
    private String baCode;

    @ApiModelProperty(value = "柜员名称")
    private String baName;

    @NotEmpty(message = "无盘点数据，不能保存!")
    @ApiModelProperty(value = "盘点单详情请求实体")
    @Valid
    List<WhFreeInventoryItemRequest> itemRequestList;
}
