package com.ruihe.app.response;

import com.ruihe.app.response.AIComprehensive.*;
import lombok.Data;


import java.util.List;

@Data
public class AIComprehensiveResponse {

    private String totalScore;

    private String image;

    private List<String> scoreDetail;

    private SkinInfo skinInfo;

    private WaterOil waterOil;

    //肤质
    private SkinType skinType;

    //肤色
    private Facecolor facecolor;

    private List<Health> health;

}
