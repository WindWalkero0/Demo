package com.ruihe.app.response.AIComprehensive;

import lombok.Data;

@Data
public class SkinType {
    private String property;
    private String description;
}
