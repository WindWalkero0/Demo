package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-28 16:30
 */
@ApiModel(value = "WhU8StockOptRequest", description = "U8系统库存变动操作主表请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhU8StockOptRequest implements Serializable {

    @ApiModelProperty("柜台id/仓库id")
    private String counterId;

    @ApiModelProperty("柜台名称/仓库名称")
    private String counterName;

    @ApiModelProperty("业务类型")
    private String bizType;

    @ApiModelProperty("业务单号")
    private String bizNo;

    @ApiModelProperty("业务发生时间，对账有很大用处")
    private LocalDateTime bizTime;

    @ApiModelProperty("U8系统库存变动操作子表请求实体")
    private List<WhU8StockOptItemRequest> itemRequestList;

}
