package com.ruihe.app.service.basic;

import com.ruihe.common.response.Response;

import java.util.List;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-24 10:35
 */
public interface QueryProductService {
    /**
     * 根据商品条码查询商品信息，同时展示库存数量
     *
     * @param barCode
     * @return
     */
    Response selectProductStock(String counterId, String barCode);

    /**
     * 根据商品条码查询商品信息
     *
     * @param prdBarCode
     * @return
     */
    Response selectProduct(String prdBarCode);

    /**
     * 根据商品条码查询商品信息，同时展示库存数量
     *
     * @param counterId
     * @param prdBraCodeList
     * @return
     */
    Response selectProductStockByAPP(String counterId, List<String> prdBraCodeList);

    /**
     * 查询商品做条码展示
     *
     * @param condition
     * @param price
     * @return
     */
    Response selectProductBarCode(String condition,String price);

    /**
     * 
     * @author qubin
     * @date 查询子分类 13:20
     * @param parentId 
     * @return com.ruihe.common.response.Response
     */
    Response selectChildrenCat(Integer parentId);
        
    /**
     * 查询大分类
     * @author qubin
     * @date 2021/5/17 13:20 
     * @return com.ruihe.common.response.Response
     */
    Response selectBigCat();
    
    /**
     * 
     * @author qubin
     * @date 查询系列 13:44
 * @return com.ruihe.common.response.Response
     */
    Response selectSeries();

    /**
     * 根据商品条码查询
     *
     * @param goodsBarCode
     * @return
     */
     Response searchProductByGoodsBarCode(String goodsBarCode);

}
