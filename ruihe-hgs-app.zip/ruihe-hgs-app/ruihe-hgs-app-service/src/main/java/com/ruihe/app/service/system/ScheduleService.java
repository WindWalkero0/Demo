package com.ruihe.app.service.system;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.request.ScheduleAddRequest;
import com.ruihe.app.request.ScheduleEmpRequest;
import com.ruihe.app.request.ScheduleQueryRequest;
import com.ruihe.app.request.ScheduleTimeAddRequest;
import com.ruihe.app.vo.*;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.bean.system.PosScheduleCounterPo;
import com.ruihe.common.dao.bean.system.PosScheduleEmpPo;
import com.ruihe.common.dao.bean.system.PosSchedulePo;
import com.ruihe.common.dao.bean.system.PosScheduleTimePo;
import com.ruihe.common.dao.mapper.system.PosScheduleCounterMapper;
import com.ruihe.common.dao.mapper.system.PosScheduleEmpMapper;
import com.ruihe.common.dao.mapper.system.PosScheduleMapper;
import com.ruihe.common.dao.mapper.system.PosScheduleTimeMapper;
import com.ruihe.common.enums.prefix.PrefixEnum;
import com.ruihe.common.response.Response;
import com.ruihe.common.util.CheckIsEmpty;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.ObjectUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author LiangYuan
 * @date 2021-03-31 13:44
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ScheduleService {

    private final PosScheduleEmpMapper posScheduleEmpMapper;
    private final PosScheduleCounterMapper posScheduleCounterMapper;
    private final PosScheduleMapper posScheduleMapper;
    private final PosScheduleTimeMapper posScheduleTimeMapper;

    /**
     * 查询排班列表
     *
     * @param counterId
     * @param yearMonth
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response scheduleList(String counterId, String yearMonth) {
        //查询排班信息
        PosSchedulePo posSchedulePo = posScheduleMapper.selectOne(Wrappers.<PosSchedulePo>lambdaQuery()
                .eq(PosSchedulePo::getCounterId, counterId)
                .eq(PosSchedulePo::getScheduleMonth, yearMonth));
        //门店美导的排班汇总
        Map<String, ScheduleEmpSummaryVo> nameMap = new HashMap<>();
        List<ScheduleEmpVo> empVoList = new ArrayList<>();
        if (posSchedulePo != null) {
            //获取排班信息
            List<PosScheduleEmpPo> empPoList = posScheduleEmpMapper.selectList(Wrappers.<PosScheduleEmpPo>lambdaQuery()
                    .eq(PosScheduleEmpPo::getSId, posSchedulePo.getId())
                    .orderByAsc(PosScheduleEmpPo::getScheduleDay));
            List<ScheduleEmpVo> empList = ObjectUtils.toList(empPoList, ScheduleEmpVo.class);
            empVoList.addAll(empList);
            empVoList.forEach(e -> {
                ScheduleEmpSummaryVo empSummaryVo = ScheduleEmpSummaryVo.builder()
                        .baName(e.getBaName())
                        .morningCount(0)
                        .noonCount(0)
                        .nightCount(0)
                        .build();
                //排班数据
                ScheduleEmpSummaryVo scheduleEmpSummaryVo = nameMap.get(e.getBaName());
                //排班类型
                switch (e.getType()) {
                    case 0:
                        if (scheduleEmpSummaryVo != null) {
                            scheduleEmpSummaryVo.setMorningCount(scheduleEmpSummaryVo.getMorningCount() + 1);
                        } else {
                            empSummaryVo.setMorningCount(1);
                            nameMap.put(e.getBaName(), empSummaryVo);
                        }
                        break;
                    case 1:
                        if (scheduleEmpSummaryVo != null) {
                            scheduleEmpSummaryVo.setNoonCount(scheduleEmpSummaryVo.getNoonCount() + 1);
                        } else {
                            empSummaryVo.setNoonCount(1);
                            nameMap.put(e.getBaName(), empSummaryVo);
                        }
                        break;
                    case 2:
                        if (scheduleEmpSummaryVo != null) {
                            scheduleEmpSummaryVo.setNightCount(scheduleEmpSummaryVo.getNightCount() + 1);
                        } else {
                            empSummaryVo.setNightCount(1);
                            nameMap.put(e.getBaName(), empSummaryVo);
                        }
                        break;
                    default:
                        break;
                }
            });
        }
        List<ScheduleEmpSummaryVo> summaryVoList = new ArrayList<>(nameMap.values());
        List<ScheduleTimeVo> timeVoList = new ArrayList<>();
        //查询排班时间
        PosScheduleCounterPo posScheduleCounterPo = posScheduleCounterMapper.selectOne(Wrappers.<PosScheduleCounterPo>lambdaQuery()
                .eq(PosScheduleCounterPo::getCounterId, counterId));
        if (posScheduleCounterPo != null) {
            List<PosScheduleTimePo> timePoList = posScheduleTimeMapper.selectList(Wrappers.<PosScheduleTimePo>lambdaQuery()
                    .eq(PosScheduleTimePo::getScId, posScheduleCounterPo.getId()));
            //获取上班时间
            timeVoList = ObjectUtils.toList(timePoList, ScheduleTimeVo.class);
        }
        ScheduleVo scheduleVo = ScheduleVo.builder()
                .scheduleEmpVoList(empVoList)
                .timeVoList(timeVoList)
                .empSummaryVoList(summaryVoList)
                .build();
        return Response.success(scheduleVo);
    }

    /**
     * 查询排班列表(暂时不使用,等新安卓过来在调通)
     *
     * @param counterId
     * @param yearMonth
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response reservedScheduleList(String counterId, String yearMonth, String yearNextMonth) {
        //查询排班信息
        List<PosSchedulePo> posSchedulePoList = posScheduleMapper.selectList(Wrappers.<PosSchedulePo>lambdaQuery()
                .eq(PosSchedulePo::getCounterId, counterId)
                .and(m -> m.eq(PosSchedulePo::getScheduleMonth, yearMonth)
                        .or(e -> e.eq(PosSchedulePo::getScheduleMonth, yearNextMonth))));

        //门店美导的排班汇总
        Map<String, ScheduleEmpSummaryVo> nameMap = new HashMap<>();
        List<ScheduleEmpVo> empVoList = new ArrayList<>();
        if (!posSchedulePoList.isEmpty()) {
            //获取排班信息
            for (PosSchedulePo posSchedulePo : posSchedulePoList) {
                if (posSchedulePo.getScheduleMonth().equals(yearMonth)) {
                    List<PosScheduleEmpPo> empPoList = posScheduleEmpMapper.selectList(Wrappers.<PosScheduleEmpPo>lambdaQuery()
                            .eq(PosScheduleEmpPo::getSId, posSchedulePo.getId())
                            .ge(PosScheduleEmpPo::getScheduleDay, 26)
                            .le(PosScheduleEmpPo::getScheduleDay, 31)
                            .orderByAsc(PosScheduleEmpPo::getScheduleDay)
                            .orderByDesc(PosScheduleEmpPo::getCreateTime));
                    List<ScheduleEmpVo> empList = ObjectUtils.toList(empPoList, ScheduleEmpVo.class);
                    empVoList.addAll(empList);
                } else if (posSchedulePo.getScheduleMonth().equals(yearNextMonth)) {
                    List<PosScheduleEmpPo> empPoList = posScheduleEmpMapper.selectList(Wrappers.<PosScheduleEmpPo>lambdaQuery()
                            .eq(PosScheduleEmpPo::getSId, posSchedulePo.getId())
                            .ge(PosScheduleEmpPo::getScheduleDay, 1)
                            .le(PosScheduleEmpPo::getScheduleDay, 25)
                            .orderByAsc(PosScheduleEmpPo::getScheduleDay)
                            .orderByDesc(PosScheduleEmpPo::getCreateTime));
                    List<ScheduleEmpVo> empList = ObjectUtils.toList(empPoList, ScheduleEmpVo.class);
                    empVoList.addAll(empList);
                }
            }
            empVoList.forEach(e -> {
                ScheduleEmpSummaryVo empSummaryVo = ScheduleEmpSummaryVo.builder()
                        .baName(e.getBaName())
                        .morningCount(0)
                        .noonCount(0)
                        .nightCount(0)
                        .build();
                //排班数据
                ScheduleEmpSummaryVo scheduleEmpSummaryVo = nameMap.get(e.getBaName());
                //排班类型
                switch (e.getType()) {
                    case 0:
                        if (scheduleEmpSummaryVo != null) {
                            scheduleEmpSummaryVo.setMorningCount(scheduleEmpSummaryVo.getMorningCount() + 1);
                        } else {
                            empSummaryVo.setMorningCount(1);
                            nameMap.put(e.getBaName(), empSummaryVo);
                        }
                        break;
                    case 1:
                        if (scheduleEmpSummaryVo != null) {
                            scheduleEmpSummaryVo.setNoonCount(scheduleEmpSummaryVo.getNoonCount() + 1);
                        } else {
                            empSummaryVo.setNoonCount(1);
                            nameMap.put(e.getBaName(), empSummaryVo);
                        }
                        break;
                    case 2:
                        if (scheduleEmpSummaryVo != null) {
                            scheduleEmpSummaryVo.setNightCount(scheduleEmpSummaryVo.getNightCount() + 1);
                        } else {
                            empSummaryVo.setNightCount(1);
                            nameMap.put(e.getBaName(), empSummaryVo);
                        }
                        break;
                    default:
                        break;
                }
            });
        }
        List<ScheduleEmpSummaryVo> summaryVoList = new ArrayList<>(nameMap.values());
        List<ScheduleTimeVo> timeVoList = new ArrayList<>();
        //查询排班时间
        PosScheduleCounterPo posScheduleCounterPo = posScheduleCounterMapper.selectOne(Wrappers.<PosScheduleCounterPo>lambdaQuery()
                .eq(PosScheduleCounterPo::getCounterId, counterId));
        if (posScheduleCounterPo != null) {
            List<PosScheduleTimePo> timePoList = posScheduleTimeMapper.selectList(Wrappers.<PosScheduleTimePo>lambdaQuery()
                    .eq(PosScheduleTimePo::getScId, posScheduleCounterPo.getId()));
            //获取上班时间
            timeVoList = ObjectUtils.toList(timePoList, ScheduleTimeVo.class);
        }
        ScheduleVo scheduleVo = ScheduleVo.builder()
                .scheduleEmpVoList(empVoList)
                .timeVoList(timeVoList)
                .empSummaryVoList(summaryVoList)
                .type(posScheduleCounterPo != null ? posScheduleCounterPo.getType() : 0)
                .build();
        return Response.success(scheduleVo);
    }

    /**
     * 排班编辑查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response scheduleQuery(ScheduleQueryRequest request) {
        PosSchedulePo posSchedulePo = posScheduleMapper.selectOne(Wrappers.<PosSchedulePo>lambdaQuery()
                .eq(PosSchedulePo::getCounterId, request.getCounterId())
                .eq(PosSchedulePo::getScheduleMonth, request.getScheduleMonth()));
        if (posSchedulePo == null) {
            return Response.successMsg("暂无数据!");
        }
        List<PosScheduleEmpPo> empPoList = posScheduleEmpMapper.selectList(Wrappers.<PosScheduleEmpPo>lambdaQuery()
                .eq(PosScheduleEmpPo::getSId, posSchedulePo.getId())
                .eq(PosScheduleEmpPo::getScheduleDay, request.getScheduleDay()));
        List<ScheduleEmpVo> empVoList = ObjectUtils.toList(empPoList, ScheduleEmpVo.class);
        return Response.success(empVoList);
    }

    /**
     * 排班新增/编辑
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response scheduleInfo(ScheduleAddRequest request) {
        //判断是修改还是新增时排班为空
        if(request.getType() != null){
            Integer type = request.getType();
            if (type == 0 && request.getEmpRequestList().isEmpty()) {
                return Response.errorMsg("排班美导不能为空");
            }
        }

        //每个班次同一美导仅可排一次
        if (!request.getEmpRequestList().isEmpty()) {
            List<ScheduleEmpRequest> list = request.getEmpRequestList();
            try {
                list.stream().collect(Collectors.toMap(e -> e.getBaCode() + e.getType(), Function.identity()));
            } catch (IllegalStateException e) {
                return Response.errorMsg("每个班次同一美导仅可排一次");
            }
        }
        //查询主表
        PosSchedulePo posSchedulePo = posScheduleMapper.selectOne(Wrappers.<PosSchedulePo>lambdaQuery()
                .eq(PosSchedulePo::getCounterId, request.getCounterId())
                .eq(PosSchedulePo::getScheduleMonth, request.getScheduleMonth()));
        if (posSchedulePo != null) {
            //将子表当前排班日全部删除
            posScheduleEmpMapper.delete(Wrappers.<PosScheduleEmpPo>lambdaQuery()
                    .eq(PosScheduleEmpPo::getSId, posSchedulePo.getId())
                    .eq(PosScheduleEmpPo::getScheduleDay, request.getScheduleDay()));
            if (!request.getEmpRequestList().isEmpty()) {
                this.doItem(request, posSchedulePo);
            }
            return Response.successMsg("编辑成功!");
        } else {
            PosSchedulePo schedulePo = ObjectUtils.toObject(request, PosSchedulePo.class);
            schedulePo.setId(IdGenerator.getRandomId(PrefixEnum.PB.getCode(), 8));
            schedulePo.setCreateTime(LocalDateTime.now());
            schedulePo.setUpdateTime(LocalDateTime.now());
            posScheduleMapper.insert(schedulePo);
            this.doItem(request, schedulePo);
            return Response.successMsg("新增成功!");
        }
    }

    /**
     * 排班美导
     *
     * @param request
     * @param posSchedulePo
     */
    private void doItem(ScheduleAddRequest request, PosSchedulePo posSchedulePo) {
        List<PosScheduleEmpPo> list = ObjectUtils.toList(request.getEmpRequestList(), PosScheduleEmpPo.class);
        for (PosScheduleEmpPo posScheduleEmpPo : list) {
            posScheduleEmpPo.setSId(posSchedulePo.getId());
            posScheduleEmpPo.setScheduleDay(request.getScheduleDay());
            posScheduleEmpPo.setCreateTime(LocalDateTime.now());
            posScheduleEmpPo.setUpdateTime(LocalDateTime.now());
            posScheduleEmpMapper.insert(posScheduleEmpPo);
        }
    }

    /**
     * 上班时间编辑查询
     *
     * @param counterId
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response timeQuery(String counterId) {
        PosScheduleCounterPo posScheduleCounterPo = posScheduleCounterMapper.selectOne(Wrappers.<PosScheduleCounterPo>lambdaQuery()
                .eq(PosScheduleCounterPo::getCounterId, counterId));
        if (posScheduleCounterPo == null) {
            return Response.successMsg("暂无数据!");
        }
        List<PosScheduleTimePo> timePoList = posScheduleTimeMapper.selectList(Wrappers.<PosScheduleTimePo>lambdaQuery()
                .eq(PosScheduleTimePo::getScId, posScheduleCounterPo.getId()));
        List<ScheduleTimeVo> timeVoList = ObjectUtils.toList(timePoList, ScheduleTimeVo.class);
        ScheduleCounterVo scheduleCounterVo = ObjectUtils.toObject(posScheduleCounterPo, ScheduleCounterVo.class);
        scheduleCounterVo.setTimeVoList(timeVoList);
        return Response.success(scheduleCounterVo);
    }

    /**
     * 上班时间新增/编辑
     *
     * @param request
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response timeInfo(ScheduleTimeAddRequest request) {
        PosScheduleCounterPo posScheduleCounterPo = posScheduleCounterMapper.selectOne(Wrappers.<PosScheduleCounterPo>lambdaQuery()
                .eq(PosScheduleCounterPo::getCounterId, request.getCounterId()));
        if (posScheduleCounterPo != null) {
            posScheduleCounterPo.setType(request.getType());
            posScheduleCounterPo.setUpdateTime(LocalDateTime.now());
            posScheduleCounterMapper.updateById(posScheduleCounterPo);
            //全部删除
            posScheduleTimeMapper.delete(Wrappers.<PosScheduleTimePo>lambdaQuery()
                    .eq(PosScheduleTimePo::getScId, posScheduleCounterPo.getId()));
            this.doTime(request, posScheduleCounterPo);
            return Response.successMsg("编辑成功!");
        } else {
            //排班柜台信息
            PosScheduleCounterPo scheduleCounterPo = ObjectUtils.toObject(request, PosScheduleCounterPo.class);
            scheduleCounterPo.setId(IdGenerator.getRandomId(PrefixEnum.PBC.getCode(), 8));
            scheduleCounterPo.setCreateTime(LocalDateTime.now());
            scheduleCounterPo.setUpdateTime(LocalDateTime.now());
            posScheduleCounterMapper.insert(scheduleCounterPo);
            this.doTime(request, scheduleCounterPo);
            return Response.successMsg("新增成功!");
        }
    }

    /**
     * 柜台排班时间
     *
     * @param request
     * @param posScheduleCounterPo
     */
    private void doTime(ScheduleTimeAddRequest request, PosScheduleCounterPo posScheduleCounterPo) {
        //排班时间信息
        List<PosScheduleTimePo> timePoList = ObjectUtils.toList(request.getTimeRequestList(), PosScheduleTimePo.class);
        for (PosScheduleTimePo timePo : timePoList) {
            if (timePoNull(timePo)) {
                timePo = timePoList.get(0);
                timePo.setType(1);

            }
            timePo.setScId(posScheduleCounterPo.getId());
            timePo.setCreateTime(LocalDateTime.now());
            timePo.setUpdateTime(LocalDateTime.now());
            posScheduleTimeMapper.insert(timePo);
        }
    }

    /**
     * 判断是否为空
     *
     * @param timePo
     * @return
     */
    private boolean timePoNull(PosScheduleTimePo timePo) {
        PosScheduleTimePo object = ObjectUtils.toObject(timePo, PosScheduleTimePo.class);
        object.setType(null);
        return CheckIsEmpty.checkObjAllFieldsIsNull(object);
    }
}
