package com.ruihe.app.enums;

/**
 * 交易类型，1销售,-1退货
 *
 * @author fangtao
 */
public enum OrderTransTypeEnum {

    /**
     * 1，销售
     **/
    GOODS_OUT(1, "出货"),
    /**
     * 2，退货
     **/
    GOODS_RETURN(-1, "退货"),
    ;


    private Integer code;
    private String msg;


    OrderTransTypeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
