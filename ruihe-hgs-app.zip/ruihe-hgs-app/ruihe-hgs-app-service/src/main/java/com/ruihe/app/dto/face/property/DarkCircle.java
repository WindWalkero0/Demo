package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class DarkCircle {

    private Integer type;

    private Integer level;

    private Integer position;

    public static boolean getProblemData(DarkCircle darkCircle) {
        return darkCircle.getLevel() > 1;
    }
}

