package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;


/**
 * @author 梁远
 * @Description 各个渠道、柜台的分时销售数据
 * @create 2019-11-14 14:59
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SalesDataEvent extends ApplicationEvent {

    private String orderNo;

    public SalesDataEvent(Object source, String orderNo) {
        super(source);
        this.orderNo = orderNo;
    }
}
