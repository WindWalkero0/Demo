package com.ruihe.app.service.promotion;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.app.mapper.promotion.PromotionCouponMapper;
import com.ruihe.app.request.SalesMemberRequest;
import com.ruihe.app.request.SalesRequest;
import com.ruihe.app.service.order.SalesOrderService;
import com.ruihe.common.dao.bean.member.MemberCoupon;
import com.ruihe.common.dao.bean.member.MemberCouponLog;
import com.ruihe.common.dao.bean.member.MemberInfo;
import com.ruihe.common.annotation.Ella;
import com.ruihe.common.dao.bean.promotion.PromotionCoupon;
import com.ruihe.common.enums.prefix.PrefixEnum;
import com.ruihe.common.pojo.request.promotion.SalesProductRequest;
import com.ruihe.common.service.CustomService;
import com.ruihe.app.response.PromotionCouponVo;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.TimeUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@Ella(Describe = "促销活动", Author = "K")
public class AboutPromotionService {


    private final CustomService customService;

    private final SalesOrderService salesOrderService;

    private final CouponScatteredService couponScatteredService;

    private final PromotionCouponMapper promotionCouponMapper;

    public AboutPromotionService(CustomService customService, SalesOrderService salesOrderService, CouponScatteredService couponScatteredService, PromotionCouponMapper promotionCouponMapper) {
        this.customService = customService;
        this.salesOrderService = salesOrderService;
        this.couponScatteredService = couponScatteredService;
        this.promotionCouponMapper = promotionCouponMapper;
    }

    @Transactional(rollbackFor = Exception.class)
    public void matchPromotion(MemberInfo memberInfo, Integer activityType, String orderNo, List<SalesProductRequest> salesProductRequests, String counterId) {
        List<PromotionCouponVo> list = new ArrayList<>();
        SalesRequest salesRequest = SalesRequest.builder().products(salesProductRequests).memberRequest(SalesMemberRequest.builder().memberId(memberInfo.getMemberId()).build()).counterId(counterId).build();
        salesOrderService.fillPrice(salesRequest);
        salesRequest.setFlag(true);
        //查询活动集合
        List<PromotionCoupon> promotionCoupons = promotionCouponMapper.selectList(Wrappers.lambdaQuery(PromotionCoupon.class)
                .eq(PromotionCoupon::getStatus, 0)
                .eq(PromotionCoupon::getEffective, 1)
                .eq(PromotionCoupon::getIsDel, 1)
                .le(PromotionCoupon::getStartTime, LocalDateTime.now())
                .ge(PromotionCoupon::getStopTime, LocalDateTime.now())
                .orderByAsc(PromotionCoupon::getSort)
                .orderByDesc(PromotionCoupon::getCreateTime));
        promotionCoupons.stream().filter(promotionCoupon -> {
            if (promotionCoupon.getCheckDiscount().equals(1) && activityType.equals(3)) {//如果参加优惠了就不再发券了
                return true;
            }
            return promotionCoupon.getCheckDiscount().equals(0);//没有已参加优惠发券要求
        }).forEach(promotionCoupon -> {
            PromotionCouponVo build = PromotionCouponVo.builder().build();
            BeanUtils.copyProperties(promotionCoupon, build);
            SalesRequest salesRequestOther = SalesRequest.builder().build();
            BeanUtils.copyProperties(salesRequest, salesRequestOther);
            List<SalesProductRequest> collect =
                    salesRequestOther.getProducts().stream().map(salesProductRequest -> {
                        SalesProductRequest salesProductRequest1 = SalesProductRequest.builder().build();
                        BeanUtils.copyProperties(salesProductRequest, salesProductRequest1);
                        return salesProductRequest1;
                    }).collect(Collectors.toList());
            salesRequestOther.setProducts(collect);
            couponScatteredService.checkPromotion(build, list, salesRequestOther, salesRequest);
        });
        list.forEach(promotionCouponVo -> {
            //进行发券
            createCoupon(promotionCouponVo, orderNo, memberInfo);
        });
    }


    @Ella(Describe = "进行发券", Author = "K")
    private void createCoupon(PromotionCouponVo promotionCouponVo, String orderNo, MemberInfo memberInfo) {
        MemberCoupon build = MemberCoupon
                .builder()
                .orderNo(orderNo)//关联订单号
                .activityId(promotionCouponVo.getProCouponId())//记录活动id
                .activityName(promotionCouponVo.getCouponName())//活动名称
                .memberId(memberInfo.getMemberId())
                .status(0)//优惠券状态
                .couponType(1)//优惠券类型
                .couponCount(1)//优惠券个数
                .memberName(memberInfo.getMemberName())//会员名称
                .memberType(memberInfo.getMemberType())//会员类型
                .mobilePhone(memberInfo.getMobilePhone())//手机号
                .openId(memberInfo.getOpenId())//微信openId
                .build();
        //填充时间
        if (promotionCouponVo.getUseType().equals(0)) {//指定时间
            build.setStartTime(TimeUtils.localTimeFormatString(promotionCouponVo.getCouponStartTime()));
            build.setStopTime(TimeUtils.localTimeFormatString(promotionCouponVo.getCouponStopTime()));
        } else if (promotionCouponVo.getUseType().equals(1)) {//相对时间
            long nowTime = System.currentTimeMillis();//获取到现在时间
            Long startDay = promotionCouponVo.getStartDay();//开始天数
            build.setStartTime(TimeUtils.longFormatString(nowTime + startDay * 24 * 60 * 60 * 1000));
            Long effectiveDay = promotionCouponVo.getEffectiveDay();//有效天数
            if (effectiveDay.equals(0L)) {
                build.setStopTime(TimeUtils.getEndTime(TimeUtils.longFormatString(System.currentTimeMillis()), 0));
            } else {
                build.setStopTime(TimeUtils.longFormatString(effectiveDay * 24 * 60 * 60 * 1000 + nowTime + startDay * 24 * 60 * 60 * 1000));
            }
        } else {
            log.error("未知活动类型,type={}", promotionCouponVo.getUseType());
            throw new BizException("未知活动类型");
        }
        //进行生成优惠券日志
        MemberCouponLog memberCouponLog = MemberCouponLog
                .builder()
                .activityId(promotionCouponVo.getProCouponId())//活动id
                .activityName(promotionCouponVo.getCouponName())//活动名称
                .status(build.getStatus())//优惠券状态
                .memberPhone(memberInfo.getMobilePhone())//手机号
                .memberName(memberInfo.getMemberName())//会员名称
                .memberId(memberInfo.getMemberId())//会员id
                .couponType(build.getCouponType())//优惠券类型
                .build();
        for (int i = 0; i < promotionCouponVo.getCount(); i++) {
            build.setCoupon(promotionCouponVo.getCheckType().equals(1) ? IdGenerator.genCouponCode() : null);
            build.setCouponId(IdGenerator.getSerialNo(PrefixEnum.ACTIVITY_COUPON.getCode()));
            build.setCreateTime(LocalDateTime.now());
            //保存优惠券记录
            memberCouponLog.setId(build.getCouponId());
            memberCouponLog.setCreateTime(LocalDateTime.now());
            Integer save = customService.save(memberCouponLog);
            if (save.equals(0)) {
                log.error("保存优惠券记录失败");
                throw new BizException("保存优惠券记录失败");
            }
            Integer row = customService.save(build);
            if (row.equals(0)) {
                log.error("保存优惠券失败");
                throw new BizException("保存优惠券失败");
            }
        }
    }
}
