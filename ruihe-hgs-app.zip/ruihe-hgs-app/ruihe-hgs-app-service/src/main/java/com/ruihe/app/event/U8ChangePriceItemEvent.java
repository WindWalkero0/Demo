package com.ruihe.app.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.context.ApplicationEvent;


/**
 * u8同步调价单事件
 * @author qubin
 * @date 2021/4/16 13:05
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class U8ChangePriceItemEvent extends ApplicationEvent {

    /**
     * 单号
     */
    private String orderNo;

    public U8ChangePriceItemEvent(Object source, String orderNo) {
        super(source);
        this.orderNo = orderNo;
    }
}
