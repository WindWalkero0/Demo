package com.ruihe.app.service.analysis;

import com.ruihe.common.pojo.request.analysis.MonthlyReportRequest;
import com.ruihe.common.pojo.request.analysis.SalesMonthlyRequest;
import com.ruihe.common.response.Response;

/**
 * 销售月报表
 *
 * @author:Fangtao
 * @Date:2019/11/4 16:55
 */
public interface SalesMonthlyReportService {
    /**
     * 销售月报表
     */
    Response saleReport(SalesMonthlyRequest request);

    /**
     * 销售月报表->销售明细报表->条件搜索
     */
    Response saleDetailReportCondition(MonthlyReportRequest request);

    /**
     * 销售月报表->销售明细报表->销售明细
     */
    Response saleDetail(String orderNo);
}
