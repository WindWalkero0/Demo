package com.ruihe.app.dto.face.property;

import lombok.Data;

@Data
public class Oil {

    private Integer level;

    private Integer facePart;

}
