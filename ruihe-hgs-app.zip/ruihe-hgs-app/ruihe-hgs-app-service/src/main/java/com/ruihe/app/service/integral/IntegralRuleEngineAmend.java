package com.ruihe.app.service.integral;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.base.Joiner;
import com.google.common.collect.Maps;
import com.ruihe.app.service.member.AboutMemberActivityService;
import com.ruihe.common.dao.bean.integral.*;
import com.ruihe.common.dao.bean.member.MemberActivity;
import com.ruihe.common.dao.bean.member.MemberActivitySon;
import com.ruihe.common.dao.bean.order.PosOrderItemPo;
import com.ruihe.common.dao.bean.order.PosOrderPo;
import com.ruihe.common.enums.activity.ActivityTypeEnum;
import com.ruihe.common.enums.integral.IntegralBizTypeEnum;
import com.ruihe.common.enums.integral.IntegralRuleTypeEnum;
import com.ruihe.common.enums.integral.IntegralSaleTypeEnum;
import com.ruihe.common.enums.integral.IntegralTypeEnum;
import com.ruihe.common.enums.order.OrderItemProductTypeEnum;
import com.ruihe.common.enums.status.CommonStatusEnum;
import com.ruihe.app.enums.OrderTransTypeEnum;
import com.ruihe.common.dao.mapper.integral.IntegralActivityMapper;
import com.ruihe.common.dao.mapper.integral.IntegralAttachActivityMappingMapper;
import com.ruihe.app.mapper.member.MemberActivityMapper;
import com.ruihe.app.mapper.order.PosOrderMapper;
import com.ruihe.common.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.MutableTriple;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 积分规则引擎
 *
 * @author William
 */
@Slf4j
@Component
public class IntegralRuleEngineAmend {

    @Autowired
    private IntegralActivityMapper integralActivityMapper;

    @Autowired
    private IntegralAttachActivityMappingMapper integralAttachActivityMappingMapper;

    @Autowired
    private PosOrderMapper posOrderMapper;

    @Autowired
    private MemberActivityMapper memberActivityMapper;

    @Autowired
    private AboutMemberActivityService memberActivityService;

    /**
     * 执行销售订单积分规则链，至少返回默认积分规则匹配结果
     *
     * @param rc
     * @return
     */
    public MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> run(RuleContext rc) {
        /*查询当前积分活动,主/附属活动都包含*/
        LocalDate bizTime = rc.getOrder().getBizTime().toLocalDate();
        LambdaQueryWrapper<IntegralActivityPo> queryWrapper = Wrappers.<IntegralActivityPo>lambdaQuery()
                .le(IntegralActivityPo::getStartTime, bizTime)
                .ge(IntegralActivityPo::getEndTime, bizTime)
                .eq(IntegralActivityPo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                .orderByDesc(IntegralActivityPo::getSeq);
        List<IntegralActivityPo> integralActivities = integralActivityMapper.selectList(queryWrapper);
        if (integralActivities == null || integralActivities.isEmpty()) {
            log.error("默认积分活动规则未配置,rc={}", rc);
            throw new BizException("默认积分活动规则未配置");
        }
        //按订单商品类型、金额倒序排序，正常商品在前&金额倒序
        rc.getOrderItemList().sort(Comparator.comparing(PosOrderItemPo::getProType, (c1, c2) -> {
            if (OrderItemProductTypeEnum.NORMAL.getCode().equals(c2)) {
                return BigInteger.ONE.intValue();
            }
            return c2.compareTo(c1);
        }).reversed().thenComparing(e -> {
            //虚拟商品排在最后
            if (e.getIsVirtual() == BigInteger.ONE.intValue()) {
                return e.getAmount();
            }
            return e.getAmount().abs();
        }).reversed());
        /*筛选出主活动*/
        List<IntegralActivityPo> mainActivityList = integralActivities.stream()
                .filter(e -> !IntegralRuleTypeEnum.ATTACH.getCode().equals(e.getRuleType()))
                .collect(Collectors.toList());
        /*查找出主活动对应的附属活动*/
        Map<Integer, IntegralActivityPo> activityMap = integralActivities.stream().collect(Collectors.toMap(IntegralActivityPo::getIntegralActivityId, Function.identity()));
        List<Integer> mainActivityIdList = mainActivityList.stream().map(e -> e.getIntegralActivityId()).collect(Collectors.toList());
        LambdaQueryWrapper<IntegralAttachActivityMappingPo> activityMappingQueryWrapper = Wrappers.<IntegralAttachActivityMappingPo>lambdaQuery()
                .in(IntegralAttachActivityMappingPo::getActivityId, mainActivityIdList)
                .orderByDesc(IntegralAttachActivityMappingPo::getActivityId, IntegralAttachActivityMappingPo::getCreateTime);
        List<IntegralAttachActivityMappingPo> attachActivityMappingList = integralAttachActivityMappingMapper.selectList(activityMappingQueryWrapper);
        Map<Integer, List<IntegralAttachActivityMappingPo>> attachActivityMapping = attachActivityMappingList.stream().collect(Collectors.groupingBy(IntegralAttachActivityMappingPo::getActivityId));
        //取得默认规则
        IntegralActivityPo defaultRule = mainActivityList.get(mainActivityList.size() - 1);
        /*遍历主活动，默认积分活动必须放在最后处理*/
        for (IntegralActivityPo activity : mainActivityList) {
            //判断业务发生时间是否在活动期间
            if (rc.getOrder().getBizTime().isBefore(activity.getStartTime().atStartOfDay()) ||
                    rc.getOrder().getBizTime().isAfter(activity.getEndTime().plusDays(1).atStartOfDay())) {
                //不在活动期间
                continue;
            }
            if (StringUtils.isBlank(activity.getRuleConf())) {
                log.error("积分活动准入规则未配置,id={},name={}", activity.getIntegralActivityId(), activity.getActivityName());
                throw new BizException("积分活动未配置");
            }
            /*匹配主活动规则*/
            MutableTriple<IntegralActivityPo, MatchResult, Map<String, Pair<IntegralActivityPo, BigDecimal>>> mt = this.match(activity, defaultRule, rc);
            if (mt.getMiddle().missMatch()) {
                continue;
            }
            /*跑附属活动规则*/
            Map<String, MatchResult.MatchResultItem> finalMultipleMap = this.runAttachRule(activityMap, attachActivityMapping, activity, defaultRule, mt.getRight(), rc);
            //同时跑默认规则
            if (activity.getRunDefaultRule()) {
                MutableTriple<IntegralActivityPo, MatchResult, Map<String, Pair<IntegralActivityPo, BigDecimal>>> mt2 = this.match(defaultRule, defaultRule, rc);
                Map<String, MatchResult.MatchResultItem> finalMultipleMap2 = this.runAttachRule(activityMap, attachActivityMapping, defaultRule, defaultRule, mt2.getRight(), rc);
                //合并结果，替换默认规则系数
                finalMultipleMap.entrySet().parallelStream().forEach(e -> {
                    //替换掉之前的默认规则系数
                    if (IntegralRuleTypeEnum.DEFAULT.getCode().equals(e.getValue().getMainActivity().getRuleType())
                            && finalMultipleMap2.containsKey(e.getKey())) {
                        e.setValue(finalMultipleMap2.get(e.getKey()));
                    }
                });
            }
            return this.buildIntegralTriple(rc, finalMultipleMap);
        }
        //一个活动也没匹配上则返回null，实际上是不可能出现的，至少会匹配上默认规则，否则就是默认规则时间配置错误
        log.error(String.format("订单%s没有匹配上一个积分规则", rc.getOrder().getOrderNo()));
        throw new BizException(String.format("订单%s没有匹配上一个积分规则", rc.getOrder().getOrderNo()));
    }

    /**
     * 跑附属活动规则
     *
     * @param activityMap
     * @param attachActivityMapping
     * @param activity
     * @param defaultRule
     * @param mainMatchResult
     * @param rc
     * @return
     */
    private Map<String, MatchResult.MatchResultItem> runAttachRule(Map<Integer, IntegralActivityPo> activityMap,
                                                                   Map<Integer, List<IntegralAttachActivityMappingPo>> attachActivityMapping,
                                                                   IntegralActivityPo activity,
                                                                   IntegralActivityPo defaultRule,
                                                                   Map<String, Pair<IntegralActivityPo, BigDecimal>> mainMatchResult,
                                                                   RuleContext rc) {
        List<IntegralAttachActivityMappingPo> attachActivityList = attachActivityMapping.get(activity.getIntegralActivityId());
        if (attachActivityList != null && !attachActivityList.isEmpty()) {
            //附属活动有多个都被匹配到时则取最后一个活动的积分系数
            MutableTriple<IntegralActivityPo, MatchResult, Map<String, Pair<IntegralActivityPo, BigDecimal>>> attachMatchResult = null;
            for (IntegralAttachActivityMappingPo am : attachActivityList) {
                IntegralActivityPo attachActivity = activityMap.get(am.getAttachActivityId());
                MutableTriple<IntegralActivityPo, MatchResult, Map<String, Pair<IntegralActivityPo, BigDecimal>>> mt2 = this.match(attachActivity, defaultRule, rc);
                if (mt2.getMiddle().missMatch()) {
                    continue;
                }
                attachMatchResult = mt2;
            }
            //如果附属规则未匹配上则使用主规则的匹配结果
            if (attachMatchResult != null) {
                //合并主/附属活动积分系数
                return this.merge(mainMatchResult, attachMatchResult.getRight(), rc);
            }
        }
        return this.merge(mainMatchResult, null, rc);
    }

    /**
     * 合并主/附属活动积分系数
     *
     * @param mainActivity
     * @param attachActivity
     * @return
     */
    private Map<String, MatchResult.MatchResultItem> merge(Map<String, Pair<IntegralActivityPo, BigDecimal>> mainActivity, Map<String, Pair<IntegralActivityPo, BigDecimal>> attachActivity, RuleContext rc) {
        if (attachActivity == null || attachActivity.isEmpty()) {
            return rc.getOrderItemList().parallelStream().map(e -> {
                Pair<IntegralActivityPo, BigDecimal> pair = mainActivity.get(e.getPrdBarCode());
                StringBuilder sb = new StringBuilder();
                if (e.getIsVirtual() == BigInteger.ONE.intValue()) {
                    //如果虚拟商品是积分兑换活动则展示“积分兑换”，其他展示“折扣抵消”
                    sb.append(OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode().equals(e.getProType()) ? "积分兑换" : "折扣抵消");
                } else if (pair.getLeft() != null) {
                    sb.append(String.format("积分系数：%s；%s", pair.getRight().toString(), pair.getLeft().getActivityName()));
                }
                MatchResult.MatchResultItem build = MatchResult.MatchResultItem
                        .builder()
                        .mainActivity(pair.getLeft())
                        .multiple(pair.getRight())
                        .reason(sb.toString())
                        .build();
                return Map.entry(e.getPrdBarCode(), build);
            }).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (o, n) -> n));
        }
        //替换产品编码对应的积分系数，使之不为0
        return rc.getOrderItemList().parallelStream().map(e -> {
            //如果是虚拟商品，title则展示“积分兑换”“优惠券”“促销”
            if (e.getIsVirtual() == BigInteger.ONE.intValue()) {
                String msg = OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode().equals(e.getProType()) ? "积分兑换" : "折扣抵消";
                return Map.entry(e.getPrdBarCode(), MatchResult.MatchResultItem.builder().reason(msg).multiple(BigDecimal.ZERO).build());
            }
            Pair<IntegralActivityPo, BigDecimal> mainPair = mainActivity.get(e.getPrdBarCode());
            Pair<IntegralActivityPo, BigDecimal> attachPair = attachActivity.get(e.getPrdBarCode());
            if (mainPair.getLeft() == null && attachPair.getLeft() == null) {
                //未匹配商规则展示空
                return Map.entry(e.getPrdBarCode(), MatchResult.MatchResultItem.builder().multiple(BigDecimal.ZERO).build());
            }
            if (mainPair.getLeft() != null && attachPair.getLeft() == null) {
                String reason = Joiner.on(StringUtils.EMPTY)
                        .join(String.format("积分系数：%s；", mainPair.getRight().toString()), mainPair.getLeft().getActivityName());
                MatchResult.MatchResultItem build = MatchResult.MatchResultItem
                        .builder()
                        .mainActivity(mainPair.getLeft())
                        .multiple(mainPair.getRight())
                        .reason(reason)
                        .build();
                return Map.entry(e.getPrdBarCode(), build);
            }
            if (mainPair.getLeft() == null && attachPair.getLeft() != null) {
                String reason = Joiner.on(StringUtils.EMPTY)
                        .join(String.format("积分系数：%s；", attachPair.getRight().toString()), attachPair.getLeft().getActivityName());
                MatchResult.MatchResultItem build = MatchResult.MatchResultItem
                        .builder()
                        .subActivity(attachPair.getLeft())
                        .multiple(attachPair.getRight())
                        .reason(reason)
                        .build();
                return Map.entry(e.getPrdBarCode(), build);
            }
            //主规则、附属规则都匹配上后再判断附属方式：1替换主规则计算结果,2累加主规则计算结果
            if (Objects.requireNonNull(attachPair.getLeft()).getAttachWay() == BigInteger.TWO.intValue()) {
                String reason = Joiner.on(StringUtils.EMPTY)
                        .join(String.format("积分系数：%s；", mainPair.getRight().toString()), mainPair.getLeft().getActivityName(),
                                "《加》",
                                String.format("积分系数：%s；", attachPair.getRight().toString()), attachPair.getLeft().getActivityName());
                MatchResult.MatchResultItem build = MatchResult.MatchResultItem
                        .builder()
                        .mainActivity(mainPair.getLeft())
                        .subActivity(attachPair.getLeft())
                        .multiple(mainPair.getRight().add(attachPair.getRight()))
                        .reason(reason)
                        .build();
                return Map.entry(e.getPrdBarCode(), build);
            } else {
                String reason = Joiner.on(StringUtils.EMPTY)
                        .join(String.format("积分系数：%s；", attachPair.getRight().toString()), attachPair.getLeft().getActivityName(),
                                "《替换》",
                                String.format("积分系数：%s；", mainPair.getRight().toString()), mainPair.getLeft().getActivityName());
                MatchResult.MatchResultItem build = MatchResult.MatchResultItem
                        .builder()
                        .mainActivity(mainPair.getLeft())
                        .subActivity(attachPair.getLeft())
                        .multiple(attachPair.getRight())
                        .reason(reason)
                        .build();
                return Map.entry(e.getPrdBarCode(), build);
            }
        }).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (o, n) -> n));
    }

    /**
     * 匹配活动规则
     *
     * @param activity
     * @param rc
     * @return
     */
    private MutableTriple<IntegralActivityPo, MatchResult, Map<String, Pair<IntegralActivityPo, BigDecimal>>> match(IntegralActivityPo activity, IntegralActivityPo defaultRule, RuleContext rc) {
        final Map<String, Pair<IntegralActivityPo, BigDecimal>> goodsPairMap = Maps.newHashMap();
        JSONObject json = JSON.parseObject(activity.getRuleConf());
        if (json.isEmpty()) {
            log.error("积分活动准入规则未配置,id={},name={}", activity.getIntegralActivityId(), activity.getActivityName());
            throw new BizException("积分活动配置为{}");
        }
        //规则模板匹配结果
        MutableTriple<IntegralActivityPo, MatchResult, Map<String, Pair<IntegralActivityPo, BigDecimal>>> ruleTplMatch = this.ruleTplMatch(json, activity, defaultRule, rc);
        if (!ruleTplMatch.getMiddle().match()) {
            return ruleTplMatch;
        }
        if (ruleTplMatch.getRight() != null) {
            goodsPairMap.putAll(ruleTplMatch.getRight());
        }
        //活动对象
        JSONObject specialMemeber = json.getJSONObject("special_memeber");
        if (specialMemeber != null && specialMemeber.getBooleanValue("enable")) {
            Map<String, String> memberLevelMap = specialMemeber.getJSONArray("levels")
                    .stream()
                    .map(e -> (JSONObject) e)
                    .collect(Collectors.toMap(k -> k.getString("code"), v -> v.getString("msg")));
            if (!memberLevelMap.containsKey(rc.getMember().getMemberLevelCode())) {
                return MutableTriple.of(activity, MatchResult.missMatch("活动对象不匹配"), null);
            }
        }
        //入会日期
        JSONObject membershipDate = json.getJSONObject("membership_date");
        if (membershipDate != null && membershipDate.getBooleanValue("enable")) {
            String selected = membershipDate.getJSONObject("selected").getString("code");
            if ("001".equals(selected)) {
                //活动期间入会
                Boolean bValid = rc.getMember().getCreateTime().isAfter(activity.getStartTime().atStartOfDay()) &&
                        rc.getMember().getCreateTime().isBefore(activity.getEndTime().plusDays(1).atStartOfDay());
                if (!bValid) {
                    return MutableTriple.of(activity, MatchResult.missMatch("入会日期【活动期间】不匹配"), null);
                }
            } else if ("002".equals(selected)) {
                //非活动期间入会
                Boolean bValid = rc.getMember().getCreateTime().isBefore(activity.getStartTime().atStartOfDay()) ||
                        rc.getMember().getCreateTime().isAfter(activity.getEndTime().plusDays(1).atStartOfDay());
                if (!bValid) {
                    return MutableTriple.of(activity, MatchResult.missMatch("入会日期【非活动期间】不匹配"), null);
                }
            }
        }
        //获取积分奖励系数
        JSONObject award = json.getJSONObject("award");
        String _multiple = award.getString("multiple");
        //默认规则模板积分系数，按会员等级取不同的系数
        if ("default".equals(activity.getRuleTpl())) {
            Map<String, String> memberLevelMultipleMap = award.getJSONArray("member_levels")
                    .stream()
                    .map(e -> (JSONObject) e)
                    .collect(Collectors.toMap(k -> k.getString("code"), v -> v.getString("multiple")));
            _multiple = memberLevelMultipleMap.get(rc.getMember().getMemberLevelCode());
        }
        final BigDecimal multiple = new BigDecimal(_multiple);
        //非特定商品规则模板各商品的积分系数
        if (!"special_goods".equals(activity.getRuleTpl())) {
            Map<String, Pair<IntegralActivityPo, BigDecimal>> tempGoodsPairMap = rc.getOrderItemList()
                    .stream()
                    .collect(Collectors.toMap(PosOrderItemPo::getPrdBarCode, e -> {
                        //虚拟商品排除
                        if (e.getIsVirtual() == BigInteger.ONE.intValue()) {
                            return Pair.of(null, BigDecimal.ZERO);
                        }
                        return Pair.of(activity, multiple);
                    }, (o, n) -> n));
            goodsPairMap.putAll(tempGoodsPairMap);
        }
        return MutableTriple.of(activity, MatchResult.match("匹配"), goodsPairMap);
    }

    /**
     * 规则模板匹配
     *
     * @param activity
     * @param defaultRule
     * @param rc
     * @return
     */
    private MutableTriple<IntegralActivityPo, MatchResult, Map<String, Pair<IntegralActivityPo, BigDecimal>>> ruleTplMatch(JSONObject json, IntegralActivityPo activity, IntegralActivityPo defaultRule, RuleContext rc) {
        //规则模板匹配
        if ("normal".equals(activity.getRuleTpl())) {
            //一般规则直接通过
            return MutableTriple.of(activity, MatchResult.match(activity.getRuleTpl() + "规则模板-一般规则，匹配"), null);
        } else if ("birthday".equals(activity.getRuleTpl())) {
            //规则模板-会员生日
            MatchResult rr = this.match(json.getJSONObject(activity.getRuleTpl()), rc);
            //目前只开发&逻辑规则，只要有一个不匹配则后续规则不用再执行
            return MutableTriple.of(activity, rr, null);
        } else if ("special_goods".equals(activity.getRuleTpl())) {
            //规则模板-特定商品
            JSONObject specialGoods = json.getJSONObject(activity.getRuleTpl());
            Map<String, String> specialGoodsMap = specialGoods.getJSONArray("goods")
                    .stream()
                    .map(e -> (JSONObject) e)
                    .collect(Collectors.toMap(k -> k.getString("code"), v -> v.getString("msg")));
            //获取逻辑运算符
            String logicOpter = specialGoods.getString("logic");
            //如果是与运算,则判断是否包含全部商品
            Set<String> orderGoodsSet = rc.getOrderItemList().stream().map(e -> e.getPrdBarCode()).collect(Collectors.toSet());
            if ("&".equals(logicOpter)) {
                if (!specialGoodsMap.keySet().stream().allMatch(e -> orderGoodsSet.contains(e))) {
                    return MutableTriple.of(activity, MatchResult.missMatch("规则模板-特定商品,&运算未通过"), null);
                }
            }
            if ("|".equals(logicOpter)) {
                if (!specialGoodsMap.keySet().stream().anyMatch(e -> orderGoodsSet.contains(e))) {
                    return MutableTriple.of(activity, MatchResult.missMatch("规则模板-特定商品,|运算未通过"), null);
                }
            }
            //获取积分系数
            BigDecimal multiple = specialGoods.getBigDecimal("multiple");
            String awardLimit = specialGoods.getString("award_limit");
            //获取默认规则积分系数
            Map<String, BigDecimal> defaultMemberLevelMultipleMap = JSON.parseObject(defaultRule.getRuleConf())
                    .getJSONObject("award")
                    .getJSONArray("member_levels")
                    .stream()
                    .map(e -> (JSONObject) e)
                    .collect(Collectors.toMap(k -> k.getString("code"), v -> v.getBigDecimal("multiple")));
            Map<String, Pair<IntegralActivityPo, BigDecimal>> goodsPairMap = rc.getOrderItemList().stream().collect(Collectors.toMap(PosOrderItemPo::getPrdBarCode, e -> {
                //优惠券、积分兑换、促销活动、发券活动虚拟商品排除
                if (e.getIsVirtual() == BigInteger.ONE.intValue()) {
                    return Pair.of(null, BigDecimal.ZERO);
                }
                //单品只有选中的商品才享受的积分系数
                if ("single".equals(awardLimit) && specialGoodsMap.containsKey(e.getPrdBarCode())) {
                    return Pair.of(activity, multiple);
                }
                //否则订单所有商品都享受指定积分系数
                if ("whole".equals(awardLimit)) {
                    return Pair.of(activity, multiple);
                }
                //单品其他，如果选择了同时执行默认规则，则商品按默认规则系数执行赠送
                if (activity.getRunDefaultRule()) {
                    //此处计算的不完整，还要继续匹配默认规则的附属规则，故在run方法里进行合并
                    return Pair.of(defaultRule, defaultMemberLevelMultipleMap.get(rc.getMember().getMemberLevelCode()));
                } else {
                    //否则不赠送
                    return Pair.of(null, BigDecimal.ZERO);
                }
            }, (o, n) -> n));
            return MutableTriple.of(activity, MatchResult.match("规则模板-特定商品,匹配"), goodsPairMap);
        } else if ("special_time".equals(activity.getRuleTpl())) {
            //规则模板-特定时间,仅限首单
            JSONObject specialTime = json.getJSONObject(activity.getRuleTpl());
            LocalDate beginTime = LocalDate.parse(specialTime.getString("begin_time"));
            LocalDate endTime = LocalDate.parse(specialTime.getString("end_time"));
            if (rc.getOrder().getBizTime().isBefore(beginTime.atStartOfDay()) ||
                    rc.getOrder().getBizTime().isAfter(endTime.plusDays(1).atStartOfDay())) {
                return MutableTriple.of(activity, MatchResult.missMatch("规则模板-特定时间-不在特定时间范围内"), null);
            }
            //判断是否是特定时间内首单
            LambdaQueryWrapper<PosOrderPo> queryWrapper = Wrappers.<PosOrderPo>lambdaQuery()
                    .eq(PosOrderPo::getMemberId, rc.getMember().getMemberId())
                    .between(PosOrderPo::getBizTime, beginTime, endTime.plusDays(1).atStartOfDay());
            Integer orderTimes = posOrderMapper.selectCount(queryWrapper);
            if (orderTimes > BigInteger.ONE.intValue()) {
                return MutableTriple.of(activity, MatchResult.missMatch("规则模板-特定时间-在特定时间范围内，但不是首单"), null);
            } else {
                return MutableTriple.of(activity, MatchResult.match("规则模板-特定时间-首单在特定时间范围内"), null);
            }
        } else if ("default".equals(activity.getRuleTpl())) {
            //默认规则模板直接通过
            return MutableTriple.of(activity, MatchResult.match(activity.getRuleTpl() + "规则模板-默认规则，匹配"), null);
        }
        return MutableTriple.of(activity, MatchResult.missMatch(activity.getRuleTpl() + "规则模板不存在"), null);
    }

    /**
     * 构造积分操作对象
     *
     * @param rc
     * @param activityMatchResult
     * @return
     */
    private MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> buildIntegralTriple(RuleContext rc, Map<String, MatchResult.MatchResultItem> activityMatchResult) {
        //业务类型
        String bizType = this.extractBizType(rc);
        List<PosOrderItemPo> orderItemList = rc.getOrderItemList();
        //价格从大到小排序？？？？
        Collections.sort(orderItemList, (o1, o2) -> o2.getSalePrice().compareTo(o1.getSalePrice()));
        List<IntegralOrderItemPo> integralOrderItemList = orderItemList
                .stream()
                .map(e -> {
                    MatchResult.MatchResultItem matchResultItem = activityMatchResult.get(e.getPrdBarCode());
                    BigDecimal discountAmt = e.getIsVirtual() == BigInteger.ZERO.intValue() ? e.getAmount().subtract(e.getShareAmt()) : BigDecimal.ZERO;
                    IntegralOrderItemPo item = IntegralOrderItemPo.builder()
                            .activityId(matchResultItem.getMainActivity() != null ? matchResultItem.getMainActivity().getIntegralActivityId() : null)
                            .activityDesc(matchResultItem.getMainActivity() != null ? matchResultItem.getMainActivity().getActivityName() : null)
                            .subActivityId(matchResultItem.getSubActivity() != null ? matchResultItem.getSubActivity().getIntegralActivityId() : null)
                            .subActivityDesc(matchResultItem.getSubActivity() != null ? matchResultItem.getSubActivity().getActivityName() : null)
                            .multiple(matchResultItem.getMultiple())
                            .activityRuleDesc(matchResultItem.getReason())
                            .counterId(rc.getOrder().getCounterId())
                            .counterName(rc.getOrder().getCounterName())
                            .memberId(rc.getOrder().getMemberId())
                            .memberName(rc.getOrder().getMemberName())
                            .memberPhone(rc.getOrder().getMemberPhone())
                            .bizType(bizType)
                            .salesType(this.extractSaleType(e.getIsVirtual()))
                            .integralType(this.extractIntegralType(e))
                            .bizNo(rc.getOrder().getOrderNo())
                            .bizTime(rc.getOrder().getBizTime())
                            .bizItemNo(e.getPrdBarCode())
                            .goodsBarCode(e.getGoodsBarCode())
                            .bizItemDesc(e.getPrdName())
                            .bizItemQty(e.getPurQty())
                            .bizItemPrice(e.getSalePrice())
                            .bizItemAmt(e.getAmount())
                            .discountAmt(discountAmt)
                            .createTime(LocalDateTime.now())
                            .updateTime(LocalDateTime.now())
                            .build();
                    //实物商品才计算抵扣金额,如果抵扣金额已扣减完则不再计算,优惠金额为负数
                    if (e.getIsVirtual() == BigInteger.ZERO.intValue() && !e.getAmount().equals(e.getShareAmt())) {
                        //计算抵扣金额，从单品金额从大到小排序进行抵扣,抵扣金额大于0才进行计算
                        BigDecimal surplus = e.getAmount().add(rc.getOrder().getDiscountAmt());
                        if (surplus.compareTo(BigDecimal.ZERO) <= BigInteger.ZERO.intValue()) {
                            item.setDiscountAmt(e.getAmount().negate());
                            rc.getOrder().setDiscountAmt(surplus);
                        } else {
                            item.setDiscountAmt(rc.getOrder().getDiscountAmt());
                            //扣减至0
                            rc.getOrder().setDiscountAmt(BigDecimal.ZERO);
                        }

                        if (e.getShareAmt().compareTo(e.getAmount()) > BigInteger.ZERO.intValue()) {
                            //优惠金额是正数【场景是加价购的商品价格为0】，更新理由,折扣抵消xx元，剩余金额计算积分;
                            item.setActivityRuleDesc(String.format("加%s元购买，剩余金额计算积分；%s", item.getDiscountAmt().toString(), matchResultItem.getReason()));
                        } else {
                            //优惠金额是负数【正常促销、积分兑换】，更新理由,折扣抵消xx元，剩余金额计算积分;
                            item.setActivityRuleDesc(String.format("折扣抵消%s元，剩余金额计算积分；%s", item.getDiscountAmt().toString(), matchResultItem.getReason()));
                        }
                    }
                    //秉坤系统产生小数时往上取整数
                    //如果积分兑换项  就变成负积分
                    if (e.getProType() == OrderItemProductTypeEnum.INTEGRAL_EXCH.getCode().intValue()) {
                        MemberActivitySon memberActivitySon = memberActivityService.selectMemberActivitySon(MemberActivitySon.builder().activityId(e.getActivityId()).build());
                        MemberActivity memberActivity = memberActivityService.selectMemberActivity(MemberActivity.builder().activityId(memberActivitySon.getSubjectId()).build());
                        if (memberActivity != null) {
                            item.setIntegralQty(new BigDecimal(memberActivitySon.getRequiredIntegral()).negate().intValue());
                        } else {
                            item.setIntegralQty(0);
                        }
                    } else {
                        Integer integralQty = item.getBizItemAmt().add(item.getDiscountAmt()).multiply(matchResultItem.getMultiple()).setScale(0, RoundingMode.HALF_UP).intValue();
                        item.setIntegralQty(integralQty);
                    }
                    //直接根据订单明细上的分摊后金额进行计算
                    /*
                    item.setIntegralQty(e.getShareAmt().multiply(matchResultItem.getMultiple()).setScale(0, RoundingMode.HALF_UP).intValue());
                    if (item.getActivityId() != null && e.getAmount().abs().compareTo(e.getShareAmt().abs()) > BigInteger.ZERO.intValue()) {
                        item.setActivityRuleDesc(String.format("折扣抵消%s元，剩余金额计算积分；%s", item.getDiscountAmt().toString(), matchResultItem.getReason()));
                    }
                    */
                    return item;
                }).collect(Collectors.toList());
        //积分兑换应付积分
        Integer paidQty = Math.negateExact(Math.abs(rc.getOrder().getIntePayable()));
        //返还总积分
        Integer gainQty = integralOrderItemList.stream().mapToInt(e -> e.getIntegralQty() > 0 ? e.getIntegralQty() : 0).sum();
        //可获得的总积分
        Integer totalQty = gainQty + paidQty;
        IntegralOrderPo order = IntegralOrderPo.builder()
                .memberId(rc.getOrder().getMemberId())
                .memberName(rc.getOrder().getMemberName())
                .memberPhone(rc.getOrder().getMemberPhone())
                .counterId(rc.getOrder().getCounterId())
                .counterName(rc.getOrder().getCounterName())
                .bizType(bizType)
                .bizQty(rc.getOrder().getGoodsQty())
                .bizNo(rc.getOrder().getOrderNo())
                .bizTime(rc.getOrder().getBizTime())
                .bizAmt(rc.getOrder().getRealAmt())
                .baCode(rc.getOrder().getBaCode())
                .baName(rc.getOrder().getBaName())
                .paidQty(paidQty)
                .gainQty(gainQty)
                .integralQty(totalQty)
                .createTime(LocalDateTime.now())
                .build();
        IntegralAccountPo account = IntegralAccountPo.builder()
                .memberId(rc.getOrder().getMemberId())
                .memberName(rc.getOrder().getMemberName())
                .memberPhone(rc.getOrder().getMemberPhone())
                .counterId(rc.getMember().getCounterId())
                .counterName(rc.getMember().getCounterName())
                .avlQty(totalQty)
                .totalQty(totalQty)
                .saleQty(totalQty)
                .exchQty(Math.abs(rc.getOrder().getIntePayable()))
                .nextExpireTime(rc.getOrder().getBizTime().plusYears(1).plusDays(1))
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
        return new MutableTriple(order, integralOrderItemList, account);
    }

    /**
     * 销售：未使用积分兑换：
     * 积分兑换：销售时使用了积分兑换；
     * 退货：退货订单不包括积分兑换；空退归属于退货
     * 积分维护：后台手动积分维护；
     * 积分清零：系统自动积分清零时；
     * 积分兑换退货：退货关联的销售单使用了积分兑换（目前业务不支持）
     */
    private String extractBizType(RuleContext rc) {
        Integer transType = rc.getOrder().getTransType();
        Integer activityType = rc.getOrder().getActivityType();
        if (OrderTransTypeEnum.GOODS_OUT.getCode().equals(transType)) {
            if (ActivityTypeEnum.INTEGRAL_EXCH.getCode().equals(activityType)) {
                return IntegralBizTypeEnum.INTEGRAL_EXCH.getCode();
            } else {
                return IntegralBizTypeEnum.SALE.getCode();
            }
        }
        if (OrderTransTypeEnum.GOODS_RETURN.getCode().equals(transType)) {
            //空退处理
            if (StringUtils.isBlank(rc.getOrder().getPreOrderNo())) {
                return IntegralBizTypeEnum.SALE_RETURN.getCode();
            }
            if (ActivityTypeEnum.INTEGRAL_EXCH.getCode().equals(activityType)) {
                return IntegralBizTypeEnum.INTEGRAL_EXCH_RETURN.getCode();
            } else {
                return IntegralBizTypeEnum.SALE_RETURN.getCode();
            }
        }
        return null;
    }

    /**
     * 销售类型：
     * 实物：正常销售；
     * 虚拟商品：促销；
     *
     * @param isVirtual
     * @return
     */
    private String extractSaleType(Integer isVirtual) {
        if (isVirtual == BigInteger.ONE.intValue()) {
            return IntegralSaleTypeEnum.VIRTUAL.getCode();
        }
        return IntegralSaleTypeEnum.NORMAL.getCode();
    }

    /**
     * 积分类型:
     * 积分兑换：订单中积分兑换的虚拟商品
     * 购买积分：实物或者除积分兑换类型外的虚拟优惠商品
     * 积分维护：积分维护情况
     * 积分清零：积分清零情况
     *
     * @param posOrderItemPo
     * @return
     */
    private String extractIntegralType(PosOrderItemPo posOrderItemPo) {
        if (ActivityTypeEnum.INTEGRAL_EXCH.getCode().equals(posOrderItemPo.getProType())) {
            return IntegralTypeEnum.INTEGRAL_EXCH.getCode();
        }
        return IntegralTypeEnum.SALE.getCode();
    }

    /**
     * 空退时执行积分默认规则
     *
     * @param rc
     * @return
     */
    public MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> run4DirectGoodsReturn(RuleContext rc) {
        /*查询当前积分活动,主/附属活动都包含*/
        LocalDate bizTime = rc.getOrder().getBizTime().toLocalDate();
        LambdaQueryWrapper<IntegralActivityPo> queryWrapper = Wrappers.<IntegralActivityPo>lambdaQuery()
                .le(IntegralActivityPo::getStartTime, bizTime)
                .ge(IntegralActivityPo::getEndTime, bizTime)
                .eq(IntegralActivityPo::getStatus, CommonStatusEnum.EFFECTIVE.getCode())
                .eq(IntegralActivityPo::getRuleType, IntegralRuleTypeEnum.DEFAULT.getCode())
                .orderByDesc(IntegralActivityPo::getSeq);
        List<IntegralActivityPo> integralActivities = integralActivityMapper.selectList(queryWrapper);
        if (integralActivities == null || integralActivities.isEmpty()) {
            log.error("默认积分活动规则未配置,rc={}", rc);
            throw new BizException("默认积分活动规则未配置");
        }
        //默认规则在优先级最低
        IntegralActivityPo defaultActivity = integralActivities.get(0);
        MutableTriple<IntegralActivityPo, MatchResult, Map<String, Pair<IntegralActivityPo, BigDecimal>>> mt = this.match(defaultActivity, defaultActivity, rc);
        if (mt.getMiddle().missMatch()) {
            log.error("空退无法匹配默认规则,mt={}", mt);
            throw new BizException("空退无法匹配默认规则");
        }
        //合并主/附属活动积分系数
        Map<String, MatchResult.MatchResultItem> finalMultipleMap = this.merge(mt.getRight(), null, rc);
        MutableTriple<IntegralOrderPo, List<IntegralOrderItemPo>, IntegralAccountPo> mutableTriple = this.buildIntegralTriple(rc, finalMultipleMap);
        //将积分值置为负数
        mutableTriple.getRight().setAvlQty(Math.negateExact(Math.abs(mutableTriple.getRight().getAvlQty())));
        mutableTriple.getRight().setTotalQty(Math.negateExact(Math.abs(mutableTriple.getRight().getTotalQty())));
        mutableTriple.getRight().setSaleQty(Math.negateExact(Math.abs(mutableTriple.getRight().getSaleQty())));
        mutableTriple.getRight().setExchQty(BigInteger.ZERO.intValue());
        mutableTriple.getLeft().setGainQty(Math.negateExact(Math.abs(mutableTriple.getLeft().getGainQty())));
        mutableTriple.getLeft().setIntegralQty(Math.negateExact(Math.abs(mutableTriple.getLeft().getIntegralQty())));
        mutableTriple.getMiddle().forEach(e -> {
            e.setIntegralQty(Math.negateExact(Math.abs(e.getIntegralQty())));
        });
        return mutableTriple;
    }

    public MatchResult match(JSONObject conf, RuleContext rc) {
        //获取生日选项代码
        String code = conf.getJSONObject("selected").getString("code");
        LocalDate currentDate = LocalDate.now();
        if (StringUtils.isBlank(rc.getMember().getBirthday())){
            return MatchResult.missMatch("【会员生日】生日当日不匹配,无生日资料！");
        }
        LocalDate birthday = LocalDate.parse(rc.getMember().getBirthday());
        switch (code) {
            case "A":
                return this.a(rc.getMember().getMemberId(), currentDate, birthday);
            case "B":
                return this.b(rc.getMember().getMemberId(), currentDate, birthday);
        }
        return MatchResult.missMatch("【会员生日】生日当日不匹配");
    }

    /**
     * A:生日当日
     *
     * @param currentDate
     * @param birthday
     * @return
     */
    private MatchResult a(String memberId, LocalDate currentDate, LocalDate birthday) {
        if (currentDate.getMonth() == birthday.getMonth() && currentDate.getDayOfMonth() == birthday.getDayOfMonth()) {
            //2020年6月19日18:07:42 补单的拆单的 如果能走到当日的话 那肯定是首单
            if (true) {
                log.error("{}匹配到了生日当日首单" + memberId);
                return MatchResult.match("【会员生日】生日当日匹配&首单匹配");
            }
            return MatchResult.missMatch("【会员生日】生日当日匹配&首单不匹配");
        } else if (!currentDate.isLeapYear() && birthday.isLeapYear() && Month.FEBRUARY == currentDate.getMonth() && Month.FEBRUARY == birthday.getMonth()) {
            //如果是闰年2月29日生日，平年时则当前日期是2.28时视为匹配
            if (currentDate.getDayOfMonth() == 28 && birthday.getDayOfMonth() == 29) {
                if (true) {
                    log.error("{}匹配到了生日当日首单" + memberId);
                    return MatchResult.match("【会员生日】生日当日匹配&首单匹配");
                }
                return MatchResult.missMatch("【会员生日】生日当日匹配&首单不匹配");
            }
        }
        return MatchResult.missMatch("【会员生日】生日当日不匹配");
    }

    /**
     * 首单判断
     *
     * @param memberId
     * @param beginDate
     * @param endDate
     * @return
     */
    private boolean isFirstOrder(String memberId, LocalDate beginDate, LocalDate endDate) {
        //判断是否是时间内首单
        //2020年5月9日15:08:16 会员当月首单 如果买了退 第二次买也算
        //2020年6月19日17:59:44  补单的话  拆单的所有都算是首单
        //当月的话 还是得判断一下
        Integer integer = posOrderMapper.selectFirstOrder(memberId, beginDate, endDate);
        return integer <= 1;
    }


    /**
     * B:生日当月
     *
     * @param birthday
     * @return
     */
    private MatchResult b(String memberId, LocalDate currentDate, LocalDate birthday) {
        if (birthday.getMonth().compareTo(currentDate.getMonth()) == 0) {
            //那当月的判断就应该是月初到昨天之前的  毕竟都是隔天处理 今天处理昨天的 那就是对的 如果没有就是首单  如果有就不是
            if (this.isFirstOrder(memberId, currentDate.withDayOfMonth(1), currentDate.minusDays(1))){
                log.error("{}匹配到了生日当月首单" ,  memberId);
                return MatchResult.match("【会员生日】生日当月匹配&首单匹配");
            }
            return MatchResult.missMatch("【会员生日】生日当月匹配&首单不匹配");
        }
        return MatchResult.missMatch("【会员生日】生日当月不匹配");
    }

}
