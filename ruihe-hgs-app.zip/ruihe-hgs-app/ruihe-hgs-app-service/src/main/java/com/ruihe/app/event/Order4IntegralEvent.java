package com.ruihe.app.event;

/**
 * 销售订单事件-积分处理
 *
 * @author William
 */
public class Order4IntegralEvent extends OrderEvent {
    public Order4IntegralEvent(Object source, String orderNo) {
        super(source, orderNo);
    }
}
