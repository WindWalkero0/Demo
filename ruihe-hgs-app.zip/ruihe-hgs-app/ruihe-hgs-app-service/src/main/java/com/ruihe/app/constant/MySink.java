package com.ruihe.app.constant;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

/**
 * @author LiangYuan
 * @description
 * @date 2020-10-19 11:11
 */
public interface MySink {

    /**
     * 接收会员积分
     */
    //String INPUT_INTEGRAL = "input_integral";

    /**
     * 接收会员等级
     */
    String INPUT_LEVEL = "input_level";

    /**
     * 接收会员订单
     */
    String INPUT_ORDER = "input_order";

    //@Input(MySink.INPUT_INTEGRAL)
    //SubscribableChannel inputIntegral();

    @Input(MySink.INPUT_LEVEL)
    SubscribableChannel inputLevel();

    @Input(MySink.INPUT_ORDER)
    SubscribableChannel inputOrder();
}
