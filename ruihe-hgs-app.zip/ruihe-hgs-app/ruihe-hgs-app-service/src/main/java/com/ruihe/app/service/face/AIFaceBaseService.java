package com.ruihe.app.service.face;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.ruihe.app.dto.face.AiFaceDTO;
import com.ruihe.app.dto.face.property.*;
import com.ruihe.app.po.face.AiFacePO;
import com.ruihe.common.constant.AiFaceConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.BeanUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.Map;


@Slf4j
@Service
public class AIFaceBaseService {

    private final RedisTemplate<Object, Object> redisTemplate;

    public AIFaceBaseService(RedisTemplate<Object, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    /**
     * 从Redis里拿到问题对应的描述
     *
     * @param label 问题对应的大类
     * @return 大类下所有属性的问题描述
     */
    public Map<String, String> getDescriptionConfigFromRedis(String label) {
        return (Map<String, String>) redisTemplate.opsForHash().get(AiFaceConstant.descriptionConfigRedis, label);
    }

    /**
     * 从Redis里拿到问题对应的分值
     *
     * @param label 问题对应的大类
     * @return 大类下所有属性的问题分值
     */
    public Map<String, Integer> getScoreConfigFromRedis(String label) {
        return (Map<String, Integer>) redisTemplate.opsForHash().get(AiFaceConstant.scoreConfigRedis, label);
    }

    /**
     * 从Redis里拿到肤质检测所有属性以及属性值得中文描述
     *
     * @param label 问题对应的大类
     * @return 大类下所有所有属性以及属性值得中文描述Pair<属性中文名, 属性值中文名>
     */
    public Map<String, String> getPropertyNameConfigFromRedis(String label) {
        return (Map<String, String>) redisTemplate.opsForHash().get(AiFaceConstant.propertyNameConfigRedis, label);
    }

    /**
     * 获取标签里属性的中文名称
     * @param label 标签
     * @return 标签中文名
     */
    public String getLabelChinese(String label) {
        return this.getLabelPropertyAndPropertyValueChinese(label, label, StringUtils.EMPTY).getLeft();
    }

    /**
     * 获取标签里属性的中文名称
     *
     * @param label       标签
     * @param propertyKey 属性
     * @return 属性中文名
     */
    public String getLabelPropertyChinese(String label, String propertyKey) {
        return this.getLabelPropertyAndPropertyValueChinese(label, propertyKey, StringUtils.EMPTY).getLeft();
    }

    /**
     * 获取属性值的中文名称
     *
     * @param label         标签
     * @param propertyKey   属性
     * @param propertyValue 属性值
     * @return 属性值中文名
     */
    public String getLabelPropertyValueChinese(String label, String propertyKey, Integer propertyValue) {
        return this.getLabelPropertyAndPropertyValueChinese(label, propertyKey, String.valueOf(propertyValue)).getRight();
    }

    /**
     * 获取属性值的中文名称
     *
     * @param label         标签
     * @param propertyKey   属性
     * @param propertyValue 属性值
     * @return 属性值中文名
     */
    public String getLabelPropertyValueChinese(String label, String propertyKey, String propertyValue) {
        return this.getLabelPropertyAndPropertyValueChinese(label, propertyKey, String.valueOf(propertyValue)).getRight();
    }

    /**
     * 从标签里拿到某个标签下特定属性(或者属性值)对应的中文
     * <p>
     * AI肤质检测会返回所有的检测指标结果，指标结果分为很多大类（标签），大类里有很多属性（标签的属性），
     * 前端展示需要知道大类或者大类里属性对应的中文名，或者大类里属性的属性值对应的中文含义。那么这里的思路是先获取到所有属性（大类和大类的属性）并按大类分组(详见{@link  AIFaceBaseService#getPropertyNameConfigFromRedis(String)}方法)
     * <p>
     * 分组后的值也是个Map对象(本方法里propertyName对象)，键:属性，值:属性的中文名；若属性的值带也有说明的话，会出现键:属性_enum，值对属性值对应的枚举字符串<p>
     *
     * @param label         标签
     * @param propertyKey   标签的属性
     * @param propertyValue 标签的属性值
     * @return Pair<属性对应的中文名, 属性值对应的中文名>
     */
    private Pair<String, String> getLabelPropertyAndPropertyValueChinese(String label, String propertyKey, String propertyValue) {

        final Map<String, String> propertyNameMap = this.getPropertyNameConfigFromRedis(label);
        final String propertyChinese = propertyNameMap.get(propertyKey);
        final String propertyEnum = propertyNameMap.get(String.format("%s_enum", propertyKey));
        if (StringUtils.isNotBlank(propertyEnum)) {
            final Map<String, String> propertyEnumMap = JSONObject.parseObject(propertyEnum, new TypeReference<>() {
            });
            final String propertyValueChinese = propertyEnumMap.get(propertyValue);
            return Pair.of(propertyChinese, propertyValueChinese);
        }
        return Pair.of(propertyChinese, null);
    }

    /**
     * 将PO对象转化为DTO对象
     *
     * @param aiFacePO PO
     * @return DTO
     */
    public AiFaceDTO convert2DTO(AiFacePO aiFacePO) {

        final AiFaceDTO aiFaceDTO = new AiFaceDTO();
        BeanUtils.copyProperties(aiFacePO, aiFaceDTO);
        //array
        aiFaceDTO.setAcnes(JSONArray.parseArray(aiFacePO.getAcnes(), Acnes.class));
        aiFaceDTO.setDarkCircle(JSONArray.parseArray(aiFacePO.getDarkCircle(), DarkCircle.class));
        aiFaceDTO.setFatGranule(JSONArray.parseArray(aiFacePO.getFatGranule(), FatGranule.class));
        aiFaceDTO.setMoisture(JSONArray.parseArray(aiFacePO.getMoisture(), Moisture.class));
        aiFaceDTO.setOil(JSONArray.parseArray(aiFacePO.getOil(), Oil.class));
        aiFaceDTO.setPigmentations(JSONArray.parseArray(aiFacePO.getPigmentations(), Pigmentations.class));
        aiFaceDTO.setWrinkles(JSONArray.parseArray(aiFacePO.getWrinkles(), Wrinkles.class));
        aiFaceDTO.setOrgimageFaceLocation(JSONArray.parseArray(aiFacePO.getOrgimageFaceLocation(), String.class));
        //object
        aiFaceDTO.setBlackHead(JSONObject.parseObject(aiFacePO.getBlackHead(), BlackHead.class));
        aiFaceDTO.setImageQuality(JSONObject.parseObject(aiFacePO.getImageQuality(), ImageQuality.class));
        aiFaceDTO.setMoistureOverall(JSONObject.parseObject(aiFacePO.getMoistureOverall(), MoistureOverall.class));
        aiFaceDTO.setOilOverall(JSONObject.parseObject(aiFacePO.getOilOverall(), OilOverall.class));
        aiFaceDTO.setPore(JSONObject.parseObject(aiFacePO.getPore(), Pore.class));
        aiFaceDTO.setPouch(JSONObject.parseObject(aiFacePO.getPouch(), Pouch.class));
        aiFaceDTO.setSensitivity(JSONObject.parseObject(aiFacePO.getSensitivity(), Sensitivity.class));
        aiFaceDTO.setStarResult(JSONObject.parseObject(aiFacePO.getStarResult(), StarResult.class));
        aiFaceDTO.setBasemapPaths(JSONObject.parseObject(aiFacePO.getBasemapPaths(), BasemapPaths.class));
        aiFaceDTO.setEyebrow(JSONObject.parseObject(aiFacePO.getEyebrow(), Eyebrow.class));
        aiFaceDTO.setEyeshape(JSONObject.parseObject(aiFacePO.getEyeshape(), Eyeshape.class));
        aiFaceDTO.setFacePose(JSONObject.parseObject(aiFacePO.getFacePose(), FacePose.class));
        aiFaceDTO.setFaceShelter(JSONObject.parseObject(aiFacePO.getFaceShelter(), FaceShelter.class));
        return aiFaceDTO;
    }
}
