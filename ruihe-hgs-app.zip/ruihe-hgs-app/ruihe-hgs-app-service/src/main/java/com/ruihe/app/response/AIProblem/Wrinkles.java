package com.ruihe.app.response.AIProblem;

public class Wrinkles {
    private Integer level;
    private Integer image;
    private String layer;

}
