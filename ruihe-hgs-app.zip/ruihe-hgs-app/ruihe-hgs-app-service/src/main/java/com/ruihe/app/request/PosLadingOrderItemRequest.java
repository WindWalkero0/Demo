package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-19 17:17
 */
@ApiModel(value = "PosLadingOrderItemRequest", description = "预订单提取详情保存实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PosLadingOrderItemRequest implements Serializable {

    @ApiModelProperty(value = "产品条码", required = true)
    private String prdBarCode;

    @ApiModelProperty(value = "商品条码", required = true)
    private String goodsBarCode;

    @ApiModelProperty(value = "商品名称", required = true)
    private String prdName;

    @ApiModelProperty(value = "提取数量", required = true)
    private Integer ladingQty;
}
