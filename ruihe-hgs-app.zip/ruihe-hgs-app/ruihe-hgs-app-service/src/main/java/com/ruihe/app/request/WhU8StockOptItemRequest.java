package com.ruihe.app.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @Description
 * @author 梁远
 * @create 2019-10-28 16:36
 */
@ApiModel(value = "WhU8StockOptItemRequest", description = "U8系统库存变动操作子表请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhU8StockOptItemRequest implements Serializable {

    @ApiModelProperty("柜台id/仓库id")
    private String counterId;

    @ApiModelProperty("柜台名称/仓库名称")
    private String counterName;

    @ApiModelProperty("业务类型")
    private String bizType;

    @ApiModelProperty("业务单号")
    private String bizNo;

    @ApiModelProperty("业务发生时间，对账有很大用处")
    private LocalDateTime bizTime;

    @ApiModelProperty("产品编码/条码")
    private String prdBarCode;

    @ApiModelProperty("商品编码")
    private String goodsBarCode;

    @ApiModelProperty("产品名称")
    private String prdName;

    @ApiModelProperty("出入库数量")
    private Integer qty;
}
