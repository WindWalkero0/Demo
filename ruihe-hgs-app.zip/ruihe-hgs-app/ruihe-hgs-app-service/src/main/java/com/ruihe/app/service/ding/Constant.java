package com.ruihe.app.service.ding;

public class Constant {
    /**
     * 创建应用，验证回调URL创建有效事件（第一次保存回调URL之前）
     */
    public static final String EVENT_CHECK_CREATE_SUITE_URL = "check_create_suite_url";

    /**
     * 创建应用，验证回调URL变更有效事件（第一次保存回调URL之后）
     */
    public static final String EVENT_CHECK_UPADTE_SUITE_URL = "check_update_suite_url";

    /**
     * suite_ticket推送事件
     * suite_ticket用于用签名形式生成accessToken(访问钉钉服务端的凭证)，需要保存到应用的db。
     * 钉钉会定期向本callback url推送suite_ticket新值用以提升安全性。
     * 应用在获取到新的时值时，保存db成功后，返回给钉钉success加密串（如本demo的return）
     */
    public static final String EVENT_SUITE_TICKET = "suite_ticket";

    /**
     * 企业授权开通应用事件
     * 本事件应用应该异步进行授权开通企业的初始化，目的是尽最大努力快速返回给钉钉服务端。用以提升企业管理员开通应用体验
     * 即使本接口没有收到数据或者收到事件后处理初始化失败都可以后续再用户试用应用时从前端获取到corpId并拉取授权企业信息，进而初始化开通及企业。
     */
    public static final String EVENT_TMP_AUTH_CODE = "tmp_auth_code";

    /**
     * 员工打卡事件
     */
    public static final String EVENT_ATTENDANCE_CHECK_RECORD = "attendance_check_record";

    /**
     * 审批实例开始，结束
     */
    public static final String EVENT_BPMS_INSTANCE_CHANGE = "bpms_instance_change";
}
