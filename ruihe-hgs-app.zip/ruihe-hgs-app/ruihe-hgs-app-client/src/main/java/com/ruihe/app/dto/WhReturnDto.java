package com.ruihe.app.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2019-10-24 10:19
 */
@ApiModel(value = "WhReturnDto", description = "退库申请审核请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhReturnDto implements Serializable {

    @ApiModelProperty(value = "申请编号")
    private String returnNo;

    @ApiModelProperty(value = "审核状态：2已通过，4已废弃")
    private Integer status;

    @ApiModelProperty(value = "审核人id")
    private String auditCode;

    @ApiModelProperty(value = "审核人名称")
    private String auditName;

    @ApiModelProperty(value = "审核人部门id")
    private String deptId;

    @ApiModelProperty(value = "审核人部门名称")
    private String deptName;
}
