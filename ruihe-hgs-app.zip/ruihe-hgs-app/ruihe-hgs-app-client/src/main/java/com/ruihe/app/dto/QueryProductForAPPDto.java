package com.ruihe.app.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-19 17:16
 */
@ApiModel(value = "QueryProductForAPPDto", description = "APP请求商品实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QueryProductForAPPDto implements Serializable {

    @ApiModelProperty(value = "柜台号")
    private String counterId;

    @ApiModelProperty(value = "产品列表")
    private List<String> prdBraCodeList;
}
