package com.ruihe.app.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Anthor:Fangtao
 * @Date:2019/11/22 19:01
 */
@ApiModel(value = "WhTransferDto", description = "调拨单处理审核请求实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhTransferDto implements Serializable {
    @ApiModelProperty(value = "申请编号")
    private String transferOrderNo;
    @ApiModelProperty(value = "审核状态,1审核通过,2审核未通过")
    private Integer auditStatus;
    @ApiModelProperty(value = "审核人id")
    private String auditCode;
    @ApiModelProperty(value = "审核人名称")
    private String auditName;
}
