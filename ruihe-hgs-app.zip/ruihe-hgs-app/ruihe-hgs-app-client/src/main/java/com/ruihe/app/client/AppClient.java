package com.ruihe.app.client;

import com.ruihe.app.dto.WhTransferDto;
import com.ruihe.app.dto.CheckFreeInventroyDto;
import com.ruihe.app.dto.WhReturnDto;
import com.ruihe.common.pojo.ResultVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author 梁远
 * @Description 单据审核处理
 * @create 2019-11-19 16:11
 */
@FeignClient("svc-ruihe-app")
public interface AppClient {


    /**
     * 自由盘点审核处理
     *
     * @param request
     * @return
     */
    @PostMapping("/pos/wh/free_inv/audit")
    ResultVO<?> freeInventoryAudit(@RequestBody CheckFreeInventroyDto request);

    /**
     * 退库申请审核处理
     *
     * @param request
     * @return
     */
    @PostMapping("/pos/wh/return/audit")
    ResultVO<?> whReturnAudit(@RequestBody WhReturnDto request);

    /**
     * 调拨单处理审核
     */
    @PostMapping("/pos/wh/transfer/audit")
    ResultVO<?> whTransferAudit(@RequestBody WhTransferDto request);

}
