package com.ruihe.app.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 梁远
 * @Description
 * @create 2019-11-19 17:16
 */
@ApiModel(value = "CheckFreeInventroyDto", description = "自由盘点审核请求实体类")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CheckFreeInventroyDto implements Serializable {

    @ApiModelProperty(value = "盘点单号", required = true)
    private String applyNo;

    @ApiModelProperty(value = "审核状态：1待审核，4审核通过，5审核拒绝", required = true)
    private Integer status;

    @ApiModelProperty(value = "审核人id", required = true)
    private String auditCode;

    @ApiModelProperty(value = "审核人名称", required = true)
    private String auditName;

    @ApiModelProperty(value = "审核人部门id", required = true)
    private String deptId;

    @ApiModelProperty(value = "审核人部门名称", required = true)
    private String deptName;
}
