package com.ruihe.dt;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.elasticsearch.ElasticsearchRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.data.elasticsearch.ReactiveElasticsearchRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.data.redis.RedisRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * @author Administrator
 */
@EnableDiscoveryClient
@EnableFeignClients(basePackages = {"com.ruihe.msger"})
@EnableAsync
@SpringBootApplication(
        exclude = {
                ElasticsearchRepositoriesAutoConfiguration.class,
                ReactiveElasticsearchRepositoriesAutoConfiguration.class,
                HibernateJpaAutoConfiguration.class,
                JpaRepositoriesAutoConfiguration.class,
                RedisRepositoriesAutoConfiguration.class
        }
)
@ComponentScan({"com.ruihe.common.*", "com.ruihe.msger.*", "com.ruihe.dt.*"})
@MapperScan({"com.ruihe.common.dao", "com.ruihe.dt.mapper"})
@EnableAspectJAutoProxy(exposeProxy = true)
public class DataCenterApplication {

    public static void main(String[] args) {
        SpringApplication.run(DataCenterApplication.class, args);
    }

}
