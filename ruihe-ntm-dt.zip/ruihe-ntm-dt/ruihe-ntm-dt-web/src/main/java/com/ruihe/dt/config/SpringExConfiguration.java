package com.ruihe.dt.config;

import com.ruihe.common.constant.CommonConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * spring扩展配置<br/>
 *
 * @author William
 * @since JDK 1.8
 */
@Slf4j
@Configuration
public class SpringExConfiguration {

    /**
     * 自定义异步线程池，可控制线程数
     */
    @Bean(name = CommonConstant.DT_THREAD_POOL_NAME, destroyMethod = "destroy")
    public ThreadPoolTaskExecutor taskExecutor() {
        return newThreadPool(CommonConstant.DT_THREAD_POOL_NAME);
    }

    /**
     * 自定义异步线程池，可控制线程数
     */
    @Bean(name = CommonConstant.DT_THREAD_POOL_NAME, destroyMethod = "destroy")
    public ThreadPoolTaskExecutor reportTaskExecutor() {
        return newThreadPool(CommonConstant.DT_THREAD_POOL_NAME);
    }

    private ThreadPoolTaskExecutor newThreadPool(String name) {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        // 诊断jvm信息时很有用
        executor.setThreadNamePrefix(name);
        // 标准设置,cpu内核数*2,设置过大将影响线程上线文切换,开销巨大,整个msger应用只使用这一个线程池
        int maxPoolSize = Runtime.getRuntime().availableProcessors();
        // 单线程listener设计模式也能得到高吞吐量
        executor.setCorePoolSize(maxPoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        // 队列最大数,拒绝使用Integer.MAX,并发过大时产生oom,可能导致jvm假死/宕机,提前做好堆内存容量规划并修改jvm启动参数
        executor.setQueueCapacity(50000);
        // 等待队列任务执行完毕后才能关闭
        executor.setWaitForTasksToCompleteOnShutdown(true);
        // 设置拒绝策略,超过队列最大数则直接丢弃当前所提交的任务以保护系统
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
        return executor;
    }
}
