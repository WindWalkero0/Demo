package com.ruihe.dt.config;

import com.ruihe.dt.rabbit.RabbitConstants;
import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

/**
 * @author fly
 */
@Configuration
public class CssQueueConfig {

    /**
     * 创建一个延时队列
     */
    @Bean
    public Queue queue() {
        return new Queue(RabbitConstants.AI_CSS_CALL_JOB_QUEUE, true);
    }

    @Bean
    public CustomExchange exchange() {
        Map<String, Object> args = new HashMap<String, Object>();
        args.put("x-delayed-type", "direct");
        return new CustomExchange(RabbitConstants.AI_CSS_CALL_JOB_EXCHANGE, "x-delayed-message", true, false, args);
    }

    @Bean
    public Binding binding() {
        return BindingBuilder.bind(queue()).to(exchange()).with(RabbitConstants.AI_CSS_CALL_JOB_ROUTING).noargs();
    }

}
