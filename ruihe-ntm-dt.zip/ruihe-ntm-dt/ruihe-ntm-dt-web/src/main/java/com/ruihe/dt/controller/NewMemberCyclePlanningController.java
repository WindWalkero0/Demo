package com.ruihe.dt.controller;


import com.ruihe.common.response.Response;
import com.ruihe.dt.request.NewMemberCyclePlanningPageRequest;
import com.ruihe.dt.service.NewMemberCyclePlanningService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/dt/pos/newmember_cycle_planning")
@Api(description = "新会员培育周期查询")
public class NewMemberCyclePlanningController {

    @Autowired
    private NewMemberCyclePlanningService newMemberCyclePlanningService;

    @ApiOperation(value = "查询不同周期新会员详情")
    @PostMapping("/page_query")
    public Response pageQuery(@RequestBody @Validated NewMemberCyclePlanningPageRequest newMemberCyclePlanningPageRequest) {
        return newMemberCyclePlanningService.pageQuery(newMemberCyclePlanningPageRequest);
    }
}
