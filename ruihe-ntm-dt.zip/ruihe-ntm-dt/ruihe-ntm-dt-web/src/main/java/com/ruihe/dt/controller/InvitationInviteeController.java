package com.ruihe.dt.controller;

import com.ruihe.dt.po.InvitationConfig;
import com.ruihe.dt.request.*;
import com.ruihe.dt.service.InvitationInviteeService;
import com.ruihe.dt.service.InvitationJobService;
import com.ruihe.dt.service.InvitationQueryService;
import com.ruihe.common.response.Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author fly
 */
@RestController
@RequestMapping("/dt/pos/inv/invitee")
@Api(description = "会员邀约任务")
public class InvitationInviteeController {

    @Autowired
    private InvitationInviteeService invitationInviteeService;

    @Autowired
    private InvitationQueryService invitationQueryService;

    @Autowired
    private InvitationJobService invitationJobService;
    private InvitationJobChangeRequest invitationJobChangeRequest;

    @ApiOperation(value = "会员邀约任务列表")
    @PostMapping("select_page")
    public Response selectPage(@RequestBody @Validated InvitationJobPageRequest invitationJobPageRequest) {
        return invitationJobService.selectPage(invitationJobPageRequest);
    }

    @ApiOperation(value = "会员邀约任务详情")
    @PostMapping("select_item")
    public Response selectItem(@RequestParam(value = "jobId") Long jobId) {
        return invitationJobService.selectItem(jobId);
    }

    @ApiOperation(value = "查询可邀约列表")
    @PostMapping("select_avl_page")
    public Response selectAvlPage(@RequestBody @Validated InvitationInviteePageRequest invitationInviteePageRequest) {
        return invitationInviteeService.selectAvlPage(invitationInviteePageRequest);
    }

    @ApiOperation(value = "查询截止日期")
    @PostMapping("select_expiry_date")
    public Response selectExpiryDate() {
        return invitationInviteeService.selectExpiryDate();
    }

    @ApiOperation(value = "查询可邀约总数")
    @PostMapping("select_count")
    public Response selectCount(@RequestParam(value = "counterId") String counterId) {
        return invitationInviteeService.selectCount(counterId);
    }

    @ApiOperation(value = "创建会员邀约任务")
    @PostMapping("add_job")
    public Response addJob(@RequestBody @Validated InvitationJobRequest invitationJobRequest) {
        InvitationConfig invitationConfig = invitationQueryService.getInvitationConfig();
        return invitationJobService.addJob(invitationJobRequest, invitationConfig);
    }

    @ApiOperation(value = "修改会员邀约任务")
    @PostMapping("update_job")
    public Response updateJob(@RequestBody @Validated InvitationJobChangeRequest invitationJobChangeRequest) {
        return invitationJobService.updateJob(invitationJobChangeRequest);
    }

    @ApiOperation(value = "会员签到")
    @PostMapping("member_sign")
    public Response memberSign(@RequestBody @Validated InvitationTaskChangeRequest invitationTaskChangeRequest) {
        return invitationJobService.memberSign(invitationTaskChangeRequest);
    }

    @ApiOperation(value = "红点展示")
    @PostMapping("show_red")
    public Response counterId(@RequestParam(value = "counterId") String counterId, @RequestParam(value = "baCode") String baCode) {
        return invitationJobService.showRed(counterId, baCode);
    }

    @ApiOperation(value = "未跟进任务数量")
    @PostMapping("un_follow_task_sum")
    public Response unFollowTask(@RequestParam(value = "counterId") String counterId, @RequestParam(value = "baCode") String baCode) {
        return invitationJobService.unFollowTask(counterId, baCode);
    }

    @ApiOperation(value = "未跟进任务列表")
    @PostMapping("un_follow_task_list")
    public Response unFollowTaskList(@RequestParam(value = "counterId") String counterId, @RequestParam(value = "baCode") String baCode) {
        return invitationJobService.unFollowTaskList(counterId, baCode);
    }

    @ApiOperation(value = "获取文字")
    @PostMapping("get_text")
    public Response getText(@RequestParam(value = "taskId") Long taskId) {
        return invitationJobService.getText(taskId);
    }

    @ApiOperation(value = "模拟mq回调测试用")
    @PostMapping("receive_msg")
    public Response receiveMsg(@RequestParam(value = "json") String json) {
        String baPhone = invitationJobService.receiveMsg(json);
        invitationJobService.commitJob(baPhone, json);
        return Response.successMsg("okok!");
    }
}
