package com.ruihe.dt.controller.css;

import com.ruihe.common.response.Response;
import com.ruihe.dt.service.css.CssTaskService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author fly
 */
@RestController
@RequestMapping("/dt/job/dispatch")
@Api(description = "会员邀约任务")
public class CssTaskController {

    @Autowired
    private CssTaskService cssTaskService;

    @ApiOperation(value = "推送ai回访任务")
    @PostMapping("/push_css_task")
    public Response pushCssTask() {
        return cssTaskService.pushCssTask();
    }

    @ApiOperation(value = "手动推送ai回访任务")
    @PostMapping("/push_css_task_acc")
    public Response pushCssTaskAcc(@RequestParam(value = "day") Integer day) {
        return cssTaskService.pushCssTaskForTest(day);
    }

}
