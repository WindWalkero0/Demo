package com.ruihe.dt.controller;

import com.ruihe.dt.service.InvitationJobService;
import com.ruihe.common.response.Response;
import com.ruihe.dt.service.NewMemberCyclePlanningService;
import com.ruihe.dt.service.MonthlyPlanService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author fly
 */
@RestController
@RequestMapping("/dt/job/dispatch")
@Api(description = "会员邀约任务")
public class InvitationTaskController {
    @Autowired
    private NewMemberCyclePlanningService newMemberCyclePlanningService;

    @Autowired
    private InvitationJobService invitationJobService;

    @Autowired
    private MonthlyPlanService monthlyPlanService;

    @ApiOperation(value = "推送ai邀约任务")
    @PostMapping("/push_inv_task")
    public Response pushInvitationTask() {
        return invitationJobService.pushInvitationTask();
    }

    @ApiOperation(value = "推送ai邀约任务")
    @PostMapping("/push_inv_task_acc")
    public Response pushInvitationTaskAcc(@RequestParam(value = "day") Integer day) {
        return invitationJobService.pushInvitationTaskForAcc(day);
    }

    @ApiOperation(value = "自动签到")
    @PostMapping("/auto_sign")
    public Response autoSign() {
        return invitationJobService.autoSign();
    }

    @ApiOperation(value = "7天更新两次失败的通话的人的状态为可选择")
    @PostMapping("/check_again")
    public Response checkAgain() {
        return invitationJobService.checkAgain();
    }

    @ApiOperation(value = "每天校验一下是否异常")
    @PostMapping("/check_data")
    public Response checkData() {
        System.out.println("每天校验一下是否异常");
        return invitationJobService.checkData();
    }

    @ApiOperation(value = "下载新会员培育周期的数据")
    @PostMapping("/download")
    public Response download() {
        return newMemberCyclePlanningService.downloadByCsv();
    }

    //命名方式修改,防止冲突保留老接口,下个版本在删除
    @ApiOperation(value = "下载门店单日目标数据")
    @PostMapping("/download_day_goal_by_csv")
    public Response downloadDayGoalByCsv() {
        return monthlyPlanService.downloadDayGoalByCsv();
    }

    @ApiOperation(value = "下载门店月度目标数据")
    @PostMapping("/download_month_goal_by_csv")
    public Response downloadMonthGoalByCsv() {
        return monthlyPlanService.downloadMonthGoalByCsv();
    }

    @ApiOperation(value = "下载门店护理包月度目标数据")
    @PostMapping("/download_month_care_pack_goal_by_csv")
    public Response downloadMonthCarePackGoalByCsv() {
        return monthlyPlanService.downloadMonthCarePackGoalByCsv();
    }


    @ApiOperation(value = "通过共享文件获取会员目标数据")
    @PostMapping("/download_member_goal_by_csv")
    public Response downloadMemberGoalByCsv() {
        return monthlyPlanService.downloadMemberGoalByCsv();
    }

    @ApiOperation(value = "通过共享文件获取1.0目标数据")
    @PostMapping("/download_ba_visit_goal_by_csv")
    public Response downloadBaVisitGoalByCsv() {
        return monthlyPlanService.downloadBaVisitGoalByCsv();
    }


    @ApiOperation(value = "xxl-job定时测试")
    @PostMapping("/test")
    public Response testXxlJob() {
        return newMemberCyclePlanningService.testXxlJob();
    }

}
