package com.ruihe.dt.controller;


import com.ruihe.common.response.Response;
import com.ruihe.dt.service.MonthlyPlanService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/dt/pos/monthly_plan")
@Api(tags = "门店月度目标详情查询", value = "门店月度目标详情查询")
public class MonthlyPlanController {
    @Autowired
    private MonthlyPlanService monthlyPlanService;
    
    @ApiOperation(value = "门店日/月度目标详情")
    @PostMapping("/query_performance_target")
    @ApiImplicitParam(name = "financialMonth", value = "财务月（格式：年-月）", required = true)
    public Response queryPerformanceTarget(String financialMonth) {
        return monthlyPlanService.queryPerformanceTarget(financialMonth);
    }
    
    @ApiOperation(value = "月度护理包目标详情")
    @PostMapping("/query_care_pack")
    @ApiImplicitParam(name = "financialMonth", value = "财务月（格式：年-月）", required = true)
    public Response queryCarePack(String financialMonth){
        return monthlyPlanService.queryCarePack(financialMonth);
    }

    @ApiOperation(value = "会员目标详情")
    @PostMapping("/query_member_details")
    @ApiImplicitParam(name = "financialMonth", value = "财务月（格式：年-月）", required = true)
    public Response queryMemberDetails(String financialMonth){
        return monthlyPlanService.queryMemberDetails(financialMonth);
    }

    @ApiOperation(value = "1.0目标详情")
    @PostMapping("/query_one_details")
    @ApiImplicitParam(name = "financialMonth", value = "财务月（格式：年-月）", required = true)
    public Response queryOneDetails(String financialMonth){
        return monthlyPlanService.queryOneDetails(financialMonth);
    }
}
