package com.ruihe.dt.config;

import com.ruihe.dt.rabbit.RabbitConstants;
import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

/**
 * @author fly
 */
@Configuration
public class XdelayConfig {

    /**
     * 创建一个立即消费队列
     */
    @Bean
    public Queue immediateQueue() {
        // 第一个参数是创建的queue的名字，第二个参数是是否支持持久化
        return new Queue(RabbitConstants.AI_INV_CALL_JOB_QUEUE, true);
    }


    @Bean
    public CustomExchange delayExchange() {
        Map<String, Object> args = new HashMap<String, Object>();
        args.put("x-delayed-type", "direct");
        return new CustomExchange(RabbitConstants.AI_INV_CALL_JOB_EXCHANGE, "x-delayed-message", true, false, args);
    }


    @Bean
    public Binding bindingNotify() {
        return BindingBuilder.bind(immediateQueue()).to(delayExchange()).with(RabbitConstants.AI_INV_CALL_JOB_ROUTING).noargs();
    }

}
