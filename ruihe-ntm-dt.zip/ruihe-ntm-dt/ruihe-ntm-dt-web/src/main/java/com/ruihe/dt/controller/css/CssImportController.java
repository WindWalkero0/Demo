package com.ruihe.dt.controller.css;

import com.ruihe.common.profile.BufferedProfile;
import com.ruihe.common.response.Response;
import com.ruihe.dt.request.InvitationImportPageRequest;
import com.ruihe.dt.request.css.CssImportPageRequest;
import com.ruihe.dt.service.InvitationImportService;
import com.ruihe.dt.service.css.CssImportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * @author fly
 */
@RestController
@RequestMapping("/dt/admin/css/import")
@Api(description = "会员回访任务")
public class CssImportController {

    @Autowired
    private CssImportService cssImportService;

    /**
     * 会员回访分页查询
     */
    @BufferedProfile(begin = true, minTime = 200)
    @ApiOperation(value = "会员回访分页查询")
    @PostMapping("/page_list")
    public Response pageList(@RequestBody CssImportPageRequest request) {
        return cssImportService.pageList(request);
    }

    /**
     * 会员回访明细分页查询
     */
    @BufferedProfile(begin = true, minTime = 200)
    @ApiOperation(value = "会员回访明细分页查询")
    @PostMapping("/item_page_list")
    public Response itemPageList(@RequestBody CssImportPageRequest request) {
        return cssImportService.itemPageList(request);
    }

    /**
     * 会员回访excel导入
     */
    @ApiOperation(value = "会员回访excel导入")
    @PostMapping("/css_plan_import")
    public Response invitationPlanImport(@RequestPart(value = "file") MultipartFile file,
                                         @RequestParam(value = "importName") String importName,
                                         @RequestParam(value = "startTime") String startTime,
                                         @RequestParam(value = "planQty") Integer planQty,
                                         @RequestParam(value = "planCallTime") String planCallTime) {
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        //1是回访
        return cssImportService.cssPlanImport(file, importName, LocalDate.parse(startTime, df), planQty, planCallTime, "1");
    }

    /**
     * 会员邀约excel导入
     */
    @ApiOperation(value = "会员回访excel导入补充")
    @PostMapping("/import_supplement")
    public Response importSupplement(@RequestPart(value = "file") MultipartFile file,
                                     @RequestParam(value = "planNo") String planNo) {
        return cssImportService.importSupplement(file, planNo);
    }

}
