package com.ruihe.dt.response.css;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 会员回访响应
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "CssTaskEvalKeywordResponse", description = "评价关键字")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CssTaskEvalKeywordResponse implements Serializable {
    @ApiModelProperty(value = "关键字")
    private String key;

    @ApiModelProperty(value = "匹配的文本")
    private String text;
}
