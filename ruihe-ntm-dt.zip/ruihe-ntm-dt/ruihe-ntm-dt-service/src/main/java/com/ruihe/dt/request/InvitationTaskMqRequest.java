package com.ruihe.dt.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * 会员邀约记录响应
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "InvitationTaskMqResponse", description = "会员邀约记录mq响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvitationTaskMqRequest implements Serializable {

    @ApiModelProperty(value = "任务ID")
    private Long taskId;

    @ApiModelProperty(value = "baCode")
    private String baCode;

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "会员名称")
    private String memberName;

    @ApiModelProperty(value = "会员名称")
    private String memberPhone;

    @ApiModelProperty(value = "性别")
    private String memberSex;

    @ApiModelProperty(value = "标签护理邀约 体验邀约")
    private String tag;

    @ApiModelProperty(value = "期望到点时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectArrTime;

    //"add_information":{"dynamic_semantics":"我是花间堂IT工程部门店的AI客服助理，给您来电是因为您是我们VIP会员，现可以享受一张无门槛50元现金券，限时领取，您看您明天有时间过来领取吗",
    // "Dynamic_A": "EEEUUE","Dynamic_B": "BBBBBB"}

    @ApiModelProperty(value = "期望到点时间")
    private InvitationTaskInformationRequest add_information;
}
