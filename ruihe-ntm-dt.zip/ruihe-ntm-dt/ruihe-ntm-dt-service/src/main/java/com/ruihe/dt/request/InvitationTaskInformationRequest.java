package com.ruihe.dt.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * 会员邀约记录响应
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "InvitationTaskInformationRequest", description = "邀约新增字段")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvitationTaskInformationRequest implements Serializable {

    //"add_information":{"dynamic_semantics":"我是花间堂IT工程部门店的AI客服助理，给您来电是因为您是我们VIP会员，现可以享受一张无门槛50元现金券，限时领取，您看您明天有时间过来领取吗",
    // "Dynamic_A": "EEEUUE","Dynamic_B": "BBBBBB"}

    /**
     * 这一期只用这个字段
     */
    @ApiModelProperty(value = "字段1")
    private String dynamic_semantics;

    @ApiModelProperty(value = "字段2")
    private String Dynamic_A;

    @ApiModelProperty(value = "字段3")
    private String Dynamic_B;


}
