package com.ruihe.dt.enums;

import org.springframework.util.StringUtils;

/**
 * 新会员培育周期回访,完成状态枚举
 * @author huangjie
 * @date 2021-04-13
 */
public enum CompleteStatusEnum {

    UNFINISHED(1, "未完成"),
    FINISH_LIMIT(2, "完成底线"),
    FINISH_BASIC(3, "完成基础");

    private Integer key;
    private String value;


    CompleteStatusEnum(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public static CompleteStatusEnum instance(Integer key) {
        if (key == null) {
            return null;
        }
        for (CompleteStatusEnum e : values()) {
            if (e.getKey().equals(key)) {
                return e;
            }
        }
        return null;
    }

    public static CompleteStatusEnum getString(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (CompleteStatusEnum e : values()) {
            if (e.getValue().equals(value)) {
                return e;
            }
        }
        return null;
    }

}
