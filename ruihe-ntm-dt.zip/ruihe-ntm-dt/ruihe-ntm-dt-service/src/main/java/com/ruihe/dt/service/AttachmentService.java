package com.ruihe.dt.service;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.pagehelper.PageHelper;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.constant.MsgerTplConstant;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.BeanUtil;
import com.ruihe.common.utils.IPUtils;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.dt.event.MsgEvent;
import com.ruihe.dt.invitation.*;
import com.ruihe.dt.mapper.*;
import com.ruihe.dt.po.*;
import com.ruihe.dt.rabbit.XdelaySender;
import com.ruihe.dt.request.*;
import com.ruihe.dt.response.*;
import com.ruihe.msger.dto.MsgerRequestDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author fly
 * @date 2020年11月6日14:03:42
 */
@Slf4j
@Service
public class AttachmentService {

    @Autowired
    private AttachmentMapper attachmentMapper;

    /**
     * 接收附件消息
     *
     * @param json
     */
    public void receiveMsg(String json) {
        AttachmentMqResponse attachmentMqResponse = JSONObject.parseObject(json, AttachmentMqResponse.class);
        //刘那边是单个任务确认回来的
        AttachmentPo attachmentPo = attachmentMapper.selectById(attachmentMqResponse.getPos_task_id());
        if (attachmentPo == null) {
            //不存在就新增  存在就修改
            AttachmentPo build = AttachmentPo.builder()
                    .taskId(attachmentMqResponse.getPos_task_id())
                    .createTime(LocalDateTime.now())
                    .updateTime(LocalDateTime.now())
                    .taskType(attachmentMqResponse.getOutbound_task_type())
                    .build();
            if (!attachmentMqResponse.getJava_data_additional_type().equals(AttachmentAdditionalTypeEnum.TEXT.getCode())
                    && !attachmentMqResponse.getJava_data_additional_type().equals(AttachmentAdditionalTypeEnum.URL.getCode())) {
                throw new BizException("不存在的类型！{}" + json);
            }
            if (attachmentMqResponse.getJava_data_additional_type().equals(AttachmentAdditionalTypeEnum.TEXT.getCode())) {
                build.setText(attachmentMqResponse.getJava_data_additional());
            }
            if (attachmentMqResponse.getJava_data_additional_type().equals(AttachmentAdditionalTypeEnum.URL.getCode())) {
                build.setUrl(attachmentMqResponse.getJava_data_additional());
            }
            attachmentMapper.insert(build);
        } else {
            if (attachmentPo.getText() != null && attachmentPo.getUrl() != null) {
                log.warn("重复提交的任务！{}", json);
                return;
            }
            if (attachmentMqResponse.getJava_data_additional_type().equals(AttachmentAdditionalTypeEnum.TEXT.getCode())) {
                attachmentPo.setText(attachmentMqResponse.getJava_data_additional());
            }
            if (attachmentMqResponse.getJava_data_additional_type().equals(AttachmentAdditionalTypeEnum.URL.getCode())) {
                attachmentPo.setUrl(attachmentMqResponse.getJava_data_additional());
            }
            attachmentPo.setUpdateTime(LocalDateTime.now());
            attachmentMapper.updateById(attachmentPo);
        }
    }


}
