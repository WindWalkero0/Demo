package com.ruihe.dt.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 会员邀约记录响应
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "InvitationPlanResponse", description = "会员邀约记录响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvitationImportResponse implements Serializable {
    @ApiModelProperty(value = "计划编号")
    private String planNo;
    @ApiModelProperty(value = "计划名称")
    private String planName;
    @ApiModelProperty(value = "操作人id")
    private String optId;
    @ApiModelProperty(value = "操作人名称")
    private String optName;
    @ApiModelProperty(value = "状态0未开始 1进行中 2已结束")
    private Integer status;
    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
    @ApiModelProperty(value = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;
    @ApiModelProperty(value = "过期时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startTime;
    @ApiModelProperty(value = "过期时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endTime;
}
