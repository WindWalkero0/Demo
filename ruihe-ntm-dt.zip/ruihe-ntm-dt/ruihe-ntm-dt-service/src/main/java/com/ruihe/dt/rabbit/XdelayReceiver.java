package com.ruihe.dt.rabbit;


import com.rabbitmq.client.Channel;
import com.ruihe.dt.service.InvitationJobService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 * @author fly
 */
@Component
@EnableRabbit
@Configuration
@Slf4j
public class XdelayReceiver {

    @Autowired
    private InvitationJobService invitationJobService;

    @RabbitListener(queues = RabbitConstants.AI_INV_CALLBACK_QUEUE)
    public void acceptInvitation(String json, Message message, Channel channel) throws Exception {
        //接收ai邀约回调
        Long deliveryTag = 0L;
        try {
            deliveryTag = (Long) message.getHeaders().get(AmqpHeaders.DELIVERY_TAG);
            String baPhone = invitationJobService.receiveMsg(json);
            invitationJobService.commitJob(baPhone, json);
        } catch (Exception e) {
            log.error("AI邀约队列消费失败,e{}", e.toString());
        } finally {
            channel.basicAck(deliveryTag, false);
        }
    }
}
