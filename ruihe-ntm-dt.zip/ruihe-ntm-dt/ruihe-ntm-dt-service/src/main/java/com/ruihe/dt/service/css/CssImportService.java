package com.ruihe.dt.service.css;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.Lists;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.pojo.context.holder.AdminUserContextHolder;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.BeanUtil;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.dt.invitation.CssImportStatusEnum;
import com.ruihe.dt.invitation.CssTaskCssStatusEnum;
import com.ruihe.dt.invitation.CssTaskStatusEnum;
import com.ruihe.dt.invitation.InvitationAvlInviteeStatusEnum;
import com.ruihe.dt.mapper.css.CssImportItemMapper;
import com.ruihe.dt.mapper.css.CssImportMapper;
import com.ruihe.dt.mapper.css.CssTaskMapper;
import com.ruihe.dt.po.*;
import com.ruihe.dt.po.css.CssImportItemPo;
import com.ruihe.dt.po.css.CssImportPo;
import com.ruihe.dt.po.css.CssTaskPo;
import com.ruihe.dt.request.css.CssImportPageRequest;
import com.ruihe.dt.response.css.CssImportItemResponse;
import com.ruihe.dt.response.css.CssImportResponse;
import com.ruihe.dt.service.InvitationImportService;
import com.ruihe.dt.service.InvitationQueryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.springframework.aop.framework.AopContext;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * @author fly
 */
@Slf4j
@Service
@RequiredArgsConstructor
@EnableAspectJAutoProxy(exposeProxy = true, proxyTargetClass = true)
public class CssImportService {
    private final CssImportItemMapper cssImportItemMapper;
    private final CssImportMapper cssImportMapper;
    private final CssTaskMapper cssTaskMapper;
    private final InvitationQueryService invitationQueryService;

    @DS(DBConst.MASTER)
    public Response cssPlanImport(MultipartFile file, String importName,
                                  LocalDate startTime, Integer planQty,
                                  String planCallTime, String aiType) {
        //最近的一份过期之前不能添加新的
        List<CssTaskPo> cssTaskPos = cssTaskMapper.selectList(Wrappers.<CssTaskPo>lambdaQuery()
                .eq(CssTaskPo::getStatus, CssTaskStatusEnum.UN_START.getCode()));
        if (!(cssTaskPos == null || cssTaskPos.isEmpty())) {
            return Response.errorMsg("前一份调研表还在进行中!");
        }
        if (LocalDate.now().isAfter(startTime)) {
            return Response.errorMsg("开始时间不能早于今天！");
        }
        //名称2 -10个字
        //结束时间不能大于开始时间
        if (importName.length() > 20 || importName.length() < 2) {
            return Response.errorMsg("不合法的名称！");
        }
        try (Workbook workbook = WorkbookFactory.create(file.getInputStream())) {
            //导入之前先保存一份
            String planNo = IdGenerator.getPromotionCouponId("CSS");
            if (workbook.getNumberOfSheets() == 0) {
                return Response.errorMsg("文件格式不正确，没有sheet！");
            }
            final CssImportPo cssImportPo = this.buildCssPlan(planNo, importName, startTime, planCallTime, planQty);
            int rows = cssImportMapper.insert(cssImportPo);
            if (rows == 0) {
                return Response.errorMsg("会员回访导入失败！");
            }
            Map<String, CounterInformation> counterMap = invitationQueryService.getCounterMap();
            Map<String, MemberLevel> memberLevelMap = invitationQueryService.getMemberLevelMap();

            CssImportService o1 = (CssImportService) AopContext.currentProxy();
            //异步解析
            new Thread(() ->
                    o1.extractSheet(planNo, workbook, counterMap, memberLevelMap, planQty, startTime, aiType)
            ).start();
        } catch (Exception e) {
            log.error("cssPlanService.extractSheet.sheet.error,", e);
            return Response.errorMsg("导入异常，文件格式不正确！");
        }
        return Response.successMsg("处理中。。。");
    }

    /**
     * 构建新的list 并一起提交
     *
     * @param itemList
     * @param counterMap
     * @param memberLevelMap
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public void subCommit(List<CssImportItemPo> itemList, Map<String, CounterInformation> counterMap, Map<String, MemberLevel> memberLevelMap, LocalDate planCallTime, String aiType) {
        List<CssTaskPo> list = new ArrayList<>();
        itemList.forEach(itemPo -> {
            CounterInformation counterInformation = counterMap.get(itemPo.getCounterName());
            MemberLevel memberLevel = memberLevelMap.get(itemPo.getMemberLevelName());
            //填充新的类   查询他的任务表中的邀约结果 时间插入
            list.add(CssTaskPo.builder()
                    .id(IdGenerator.getLongSerialNo())
                    .status(InvitationAvlInviteeStatusEnum.UNCHECK.getCode())
                    .birthday(itemPo.getBirthday())
                    .cardIssueTime(itemPo.getCardIssueTime())
                    .counterId(counterInformation == null ? null : counterInformation.getCounterId())
                    .counterName(itemPo.getCounterName())
                    .baCode(itemPo.getBaCode())
                    .baName(itemPo.getBaName())
                    .createTime(LocalDateTime.now())
                    .updateTime(LocalDateTime.now())
                    .integralQty(itemPo.getIntegralQty())
                    .lastestTrxTime(itemPo.getLastestTrxTime())
                    .levelChangeTime(itemPo.getLevelChangeTime())
                    .memberLevelCode(memberLevel.getLevelCode())
                    .memberLevelName(itemPo.getMemberLevelName())
                    .memberName(itemPo.getMemberName())
                    .memberPhone(itemPo.getMemberPhone())
                    .memberSex(itemPo.getMemberSex())
                    .orgAreaCode(counterInformation == null ? null : counterInformation.getOrgAreaId())
                    .orgAreaName(itemPo.getOrgAreaName())
                    .orgOfficeCode(counterInformation == null ? null : counterInformation.getOrgOfficeId())
                    .orgOfficeName(counterInformation == null ? null : counterInformation.getOrgOfficeName())
                    .orgPrincipalCode(counterInformation == null ? null : counterInformation.getOrgMasterId())
                    .orgPrincipalName(counterInformation == null ? null : counterInformation.getOrgMasterName())
                    .planNo(itemPo.getPlanNo())
                    .planCallTime(planCallTime)
                    .tag(itemPo.getTag())
                    .cssStatus(CssTaskCssStatusEnum.KD_02.getCode())
                    .aiType(aiType)
                    .build());
        });
        cssImportItemMapper.batchInsert(itemList);
        cssTaskMapper.batchInsert(list);
    }

    private CssImportPo buildCssPlan(String planNo, String importName, LocalDate startTime, String planCallTime, Integer planQty) {
        var userInformation = AdminUserContextHolder.get();
        return CssImportPo.builder()
                .planNo(planNo)
                .planName(importName)
                .planQty(planQty)
                .planTime(planCallTime)
                .startTime(startTime)
                .optId(userInformation.getEmpId())
                .optName(userInformation.getName())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .build();
    }

    /**
     * 解析Excel
     *
     * @param planId
     * @param workbook
     * @param counterMap
     * @param memberLevelMap
     */
    public void extractSheet(String planId, Workbook workbook,
                             Map<String, CounterInformation> counterMap,
                             Map<String, MemberLevel> memberLevelMap,
                             Integer qty, LocalDate planCallTime, String aiType) {
        //按时间和那个次数分组
        List<CssImportItemPo> itemList = Lists.newArrayList();
        CssImportService o1 = (CssImportService) AopContext.currentProxy();
        //天数
        AtomicInteger cot = new AtomicInteger(0);
        IntStream.range(0, workbook.getNumberOfSheets()).parallel().forEach(e -> {
            Sheet sheet = workbook.getSheetAt(e);
            for (Row row : sheet) {
                if (row.getRowNum() < 1) {
                    continue;
                }
                CssImportItemPo item = this.extractRow(planId, row);
                if (item == null) {
                    continue;
                }
                itemList.add(item);
                //分段提交
                if (itemList.size() == qty) {
                    o1.subCommit(itemList, counterMap, memberLevelMap, planCallTime.plusDays(cot.get()), aiType);
                    //一天一提交
                    cot.getAndIncrement();
                    //然后置空
                    itemList.clear();
                }
            }
        });
        //没有1000个时也提交
        if (itemList.size() > 0) {
            o1.subCommit(itemList, counterMap, memberLevelMap, planCallTime.plusDays(cot.get()), aiType);
        }
    }

    /**
     * 构造积分导入明细
     *
     * @param planNo
     * @param row
     * @return
     */
    public CssImportItemPo extractRow(String planNo, Row row) {
        CssImportItemPo item = CssImportItemPo.builder().id(IdGenerator.getLongSerialNo()).planNo(planNo).status(true).build();
        try {
            List<String> cellValues = Lists.newArrayList();
            for (Cell cell : row) {
                String value = cell.getCellTypeEnum() == CellType.NUMERIC
                        ? Long.toString(((long) cell.getNumericCellValue()))
                        : cell.getStringCellValue();
                cellValues.add(value);
            }
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            //如果整行数据为空则跳过
            String concat = org.apache.commons.lang3.StringUtils.join(cellValues.iterator(), org.apache.commons.lang3.StringUtils.EMPTY);
            if (org.apache.commons.lang3.StringUtils.isBlank(concat)) {
                return null;
            }
            StringBuilder sb = new StringBuilder();
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(0))) {
                item.setOrgAreaName(cellValues.get(0).trim());
            } else {
                sb.append("区域不正确");
                item.setStatus(Boolean.FALSE);
                item.setOrgAreaName(cellValues.get(0));
            }
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(1))) {
                item.setCounterName(cellValues.get(1).trim());
            } else {
                sb.append("柜台不正确");
                item.setStatus(Boolean.FALSE);
                item.setCounterName(cellValues.get(1));
            }
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(2))) {
                item.setBaName(cellValues.get(2).trim());
            } else {
                sb.append("ba名称不正确");
                item.setStatus(Boolean.FALSE);
                item.setBaName(cellValues.get(2));
            }
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(3))) {
                item.setBaCode(cellValues.get(3).trim());
            } else {
                sb.append("ba编码不正确");
                item.setStatus(Boolean.FALSE);
                item.setCounterName(cellValues.get(3));
            }
            try {
                if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(4))) {
                    item.setCardIssueTime(LocalDateTime.parse(cellValues.get(4).trim(), formatter));
                }
            } catch (Exception e) {
                item.setStatus(Boolean.FALSE);
                sb.append(String.format("入会时间【%s】不正确，格式YYYY-MM-DD", cellValues.get(4)));
            }
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(5))) {
                item.setMemberLevelName(cellValues.get(5).trim());
            } else {
                sb.append("会员等级不正确");
                item.setStatus(Boolean.FALSE);
                item.setMemberLevelName(cellValues.get(5));
            }
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(6))) {
                item.setMemberName(cellValues.get(6).trim());
            } else {
                sb.append("会员名称不正确");
                item.setStatus(Boolean.FALSE);
                item.setMemberName(cellValues.get(6));
            }
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(7))) {
                item.setMemberSex(cellValues.get(7).trim());
            } else {
                sb.append("会员性别不正确");
                item.setStatus(Boolean.FALSE);
                item.setMemberSex(cellValues.get(7));
            }
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(8)) && cellValues.get(8).trim().length() == 11) {
                item.setMemberPhone(cellValues.get(8).trim());
            } else {
                sb.append(String.format("手机号【%s】格式不正确", cellValues.get(8)));
                item.setStatus(Boolean.FALSE);
                item.setMemberPhone(cellValues.get(8));
            }
            try {
                if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(9))) {
                    item.setBirthday(LocalDate.parse(cellValues.get(9).trim()));
                }
            } catch (Exception e) {
                item.setStatus(Boolean.FALSE);
                sb.append(String.format("会员生日【%s】不正确，格式YYYY-MM-DD", cellValues.get(9)));
            }
            try {
                int qty = Integer.parseInt(cellValues.get(10));
                if (cellValues.get(10).trim().length() > 6) {
                    sb.append(String.format("积分值【%s】不正确，不能超过6位数", cellValues.get(10)));
                    item.setStatus(Boolean.FALSE);
                } else {
                    item.setIntegralQty(qty);
                }
            } catch (Exception e) {
                sb.append(String.format("积分值【%s】不正确，不能为空且只能为整数", cellValues.get(10)));
                item.setStatus(Boolean.FALSE);
            }
            try {
                if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(11))) {
                    item.setLastestTrxTime(LocalDateTime.parse(cellValues.get(11).trim(), formatter));
                }
            } catch (Exception e) {
                item.setStatus(Boolean.FALSE);
                sb.append(String.format("最后一次购买时间【%s】不正确，格式YYYY-MM-DD", cellValues.get(11)));
            }
            try {
                if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(12))) {
                    item.setLevelChangeTime(LocalDateTime.parse(cellValues.get(12).trim(), formatter));
                }
            } catch (Exception e) {
                item.setStatus(Boolean.FALSE);
                sb.append(String.format("等级调整日期【%s】不正确，格式YYYY-MM-DD", cellValues.get(12)));
            }
            if (org.apache.commons.lang3.StringUtils.isNotBlank(cellValues.get(13))) {
                item.setTag(cellValues.get(13).trim());
            } else {
                sb.append("会员标签不正确");
                item.setStatus(Boolean.FALSE);
                item.setTag(cellValues.get(13));
            }
            item.setRemark(item.getStatus() ? "导入成功" : sb.toString());
        } catch (Exception e) {
            log.error("InvitationImportService.extractSheet.row.error,", e);
            item.setStatus(Boolean.FALSE);
            String errMsg = "导入异常，格式不正确，行：" + row.getRowNum();
            item.setRemark(errMsg);
        }
        return item;
    }

    /**
     * 主表分页查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response pageList(CssImportPageRequest request) {
        Page<CssImportPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        LambdaQueryWrapper<CssImportPo> queryWrapper = Wrappers.<CssImportPo>lambdaQuery();
        if (request.getName() != null && !"".equals(request.getName())) {
            queryWrapper.like(CssImportPo::getPlanName, request.getName());
        }
        if (request.getStartTime() != null) {
            queryWrapper.ge(CssImportPo::getStartTime, request.getStartTime());
        }
        if (request.getEndTime() != null) {
            queryWrapper.lt(CssImportPo::getStartTime, request.getEndTime().plusDays(1));
        }
        queryWrapper.orderByDesc(CssImportPo::getCreateTime);
        Page<CssImportPo> cssImportPoPage = cssImportMapper.selectPage(page, queryWrapper);
        List<CssImportResponse> cssImportResponse = BeanUtil.copyListProperties(cssImportPoPage.getRecords(), CssImportResponse.class);
        List<CssImportPo> records = cssImportPoPage.getRecords();
        //补充状态
        if (records != null && records.size() > 0) {
            List<String> collect = records.stream().map(CssImportPo::getPlanNo).collect(Collectors.toList());
            //获取未开始的数量
            List<CssUnTaskQtyPo> unTaskQty = cssTaskMapper.getUnTaskQty(collect);
            List<CssUnTaskQtyPo> taskQty = cssTaskMapper.getTaskQty(collect);
            Map<String, Integer> unCollect = unTaskQty.stream().collect(Collectors.toMap(CssUnTaskQtyPo::getPlanNo, CssUnTaskQtyPo::getQty));
            Map<String, Integer> allCollect = taskQty.stream().collect(Collectors.toMap(CssUnTaskQtyPo::getPlanNo, CssUnTaskQtyPo::getQty));
            for (CssImportResponse importResponse : cssImportResponse) {
                importResponse.setAllQty(allCollect.get(importResponse.getPlanNo()) == null ? 0 : allCollect.get(importResponse.getPlanNo()));
                importResponse.setEndQty((allCollect.get(importResponse.getPlanNo()) == null ? 0 : allCollect.get(importResponse.getPlanNo())) - (unCollect.get(importResponse.getPlanNo()) == null ? 0 : unCollect.get(importResponse.getPlanNo())));
                importResponse.setStatus(CssImportStatusEnum.END.getCode());
                if (unCollect.get(importResponse.getPlanNo()) != null && unCollect.get(importResponse.getPlanNo()) > 0) {
                    //存在task就是进行中
                    importResponse.setStatus(CssImportStatusEnum.STARTING.getCode());
                    if (importResponse.getStartTime().isAfter(LocalDate.now())) {
                        //存在task切 开始时间大于现在就是未开始
                        importResponse.setStatus(CssImportStatusEnum.UN_START.getCode());
                    }
                }
                //补充结束时间
                CssTaskPo cssTaskPo = cssTaskMapper.selectOne(Wrappers.<CssTaskPo>lambdaQuery()
                        .eq(CssTaskPo::getPlanNo, importResponse.getPlanNo()).orderByDesc(CssTaskPo::getPlanCallTime)
                        .last("LIMIT 0,1"));
                importResponse.setEndTime(cssTaskPo == null ? null : cssTaskPo.getPlanCallTime());
            }
        }
        //补充进度
        PageVO pageVO = PageVO.<CssImportResponse>builder()
                .list(cssImportResponse)
                .pages(cssImportPoPage.getPages())
                .total(cssImportPoPage.getTotal())
                .pageSize(cssImportPoPage.getSize())
                .pageNum(cssImportPoPage.getCurrent()).build();
        return Response.success(pageVO);
    }


    /**
     * 子表分页查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response itemPageList(CssImportPageRequest request) {
        Page<CssImportItemPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        Page<CssImportItemPo> cssImportItemPoPage = cssImportItemMapper.selectPage(page, Wrappers.<CssImportItemPo>lambdaQuery()
                .eq(CssImportItemPo::getPlanNo, request.getPlanNo())
                .orderByDesc(CssImportItemPo::getId));
        PageVO pageVO = PageVO.<CssImportItemResponse>builder()
                .list(BeanUtil.copyListProperties(cssImportItemPoPage.getRecords(), CssImportItemResponse.class))
                .pages(cssImportItemPoPage.getPages())
                .total(cssImportItemPoPage.getTotal())
                .pageSize(cssImportItemPoPage.getSize())
                .pageNum(cssImportItemPoPage.getCurrent()).build();
        return Response.success(pageVO);
    }

    /**
     * 补充名单
     *
     * @param file
     * @param planNo
     * @return
     */
    @DS(DBConst.MASTER)
    public Response importSupplement(MultipartFile file, String planNo) {
        CssImportPo cssImportPo = cssImportMapper.selectOne(Wrappers.<CssImportPo>lambdaQuery().eq(CssImportPo::getPlanNo, planNo));
        if (cssImportPo == null) {
            return Response.errorMsg("不存在的导入名单!");
        }
        CssTaskPo cssTaskPo = cssTaskMapper.selectOne(Wrappers.<CssTaskPo>lambdaQuery()
                .eq(CssTaskPo::getStatus, CssTaskStatusEnum.UN_START.getCode())
                .eq(CssTaskPo::getPlanNo, planNo).orderByDesc(CssTaskPo::getPlanCallTime).last("LIMIT 1"));
        if (cssTaskPo == null) {
            return Response.errorMsg("任务已结束,请新建回访任务！");
        }

        Map<String, CounterInformation> counterMap = invitationQueryService.getCounterMap();
        Map<String, MemberLevel> memberLevelMap = invitationQueryService.getMemberLevelMap();
        try (Workbook workbook = WorkbookFactory.create(file.getInputStream())) {
            //导入之前先保存一份
            if (workbook.getNumberOfSheets() == 0) {
                return Response.errorMsg("文件格式不正确，没有sheet！");
            }
            CssImportService o1 = (CssImportService) AopContext.currentProxy();
            //异步解析
            new Thread(() ->
                    o1.extractSheet(planNo, workbook, counterMap, memberLevelMap, cssImportPo.getPlanQty(), cssTaskPo.getPlanCallTime().plusDays(1), "1")
            ).start();
        } catch (Exception e) {
            log.error("cssPlanService.extractSheet.sheet.error,", e);
            return Response.errorMsg("导入异常，文件格式不正确！");
        }
        return Response.successMsg("处理中。。。");
    }
}
