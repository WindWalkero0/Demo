package com.ruihe.dt.service.css;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.dt.invitation.CssTaskCssStatusEnum;
import com.ruihe.dt.invitation.CssTaskStatusEnum;
import com.ruihe.dt.mapper.css.CssEvalScoreKeywordMapper;
import com.ruihe.dt.mapper.css.CssEvalScoreMapper;
import com.ruihe.dt.mapper.css.CssImportMapper;
import com.ruihe.dt.mapper.css.CssTaskMapper;
import com.ruihe.dt.po.css.CssEvalScoreKeywordPo;
import com.ruihe.dt.po.css.CssEvalScorePo;
import com.ruihe.dt.po.css.CssImportPo;
import com.ruihe.dt.po.css.CssTaskPo;
import com.ruihe.dt.rabbit.CssMQSender;
import com.ruihe.dt.request.css.CssTaskMqRequest;
import com.ruihe.dt.response.css.CssTaskEvalKeywordResponse;
import com.ruihe.dt.response.css.CssTaskEvalResponse;
import com.ruihe.dt.response.css.CssTaskMqResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;


/**
 * @author fly
 */
@Slf4j
@Service
@RequiredArgsConstructor
@EnableAspectJAutoProxy(exposeProxy = true, proxyTargetClass = true)
public class CssTaskService {
    private final CssTaskMapper cssTaskMapper;
    private final CssImportMapper cssImportMapper;
    private final CssEvalScoreMapper cssEvalScoreMapper;
    private final CssEvalScoreKeywordMapper cssEvalScoreKeywordMapper;
    private final CssMQSender cssMQSender;

    /**
     * 每天定时触发
     *
     * @return
     */
    @DS(DBConst.MASTER)
    public Response pushCssTask() {
        //查询job里面 未开始的 并且时间是今天的
        LambdaQueryWrapper<CssTaskPo> queryWrapper = Wrappers.<CssTaskPo>lambdaQuery()
                .eq(CssTaskPo::getPlanCallTime, LocalDate.now())
                .eq(CssTaskPo::getStatus, CssTaskStatusEnum.UN_START.getCode())
                .orderByDesc(CssTaskPo::getId);
        List<CssTaskPo> cssTaskPos = cssTaskMapper.selectList(queryWrapper);
        if (cssTaskPos == null || cssTaskPos.size() == 0) {
            return Response.successMsg("不存在需要执行的回访任务");
        }
        CssImportPo cssImportPo = cssImportMapper.selectById(cssTaskPos.get(0).getPlanNo());
        if (cssImportPo == null) {
            log.error("不存在的回访任务");
            return Response.successMsg("不存在的回访任务");
        }
        String planTime = cssImportPo.getPlanTime();
        //格式 9-10
        String[] split = planTime.split("-");
        //9点准时发起
        LocalDateTime startTime = LocalDate.now().atTime(Integer.parseInt(split[0]), 0, 0);
        long time = Duration.between(LocalDateTime.now(), startTime).toMillis();
        for (CssTaskPo cssTaskPo : cssTaskPos) {
            CssTaskMqRequest cssTaskMqRequest = ObjectUtils.toObject(cssTaskPo, CssTaskMqRequest.class);
            cssTaskMqRequest.setTag(cssTaskPo.getAiType());
            cssTaskMqRequest.setTaskId(cssTaskPo.getId());
            cssTaskMqRequest.setGiftInfo("积分礼品卷");
            //几点提交是个问题
            //找到开始时间
            cssMQSender.send(JSONObject.toJSONString(cssTaskMqRequest), Integer.parseInt(Long.toString(time)));
        }
        //更新task中的状态为进行中
        cssTaskMapper.update(null, new UpdateWrapper<CssTaskPo>()
                .eq("plan_call_time", LocalDate.now())
                .eq("status", CssTaskStatusEnum.UN_START.getCode())
                .set("call_time", LocalDateTime.now())
                .set("status", CssTaskStatusEnum.STARTING.getCode()));
        return Response.successMsg("提交任务完成！");
    }


    /**
     * 每天定时触发
     *
     * @return
     */
    @DS(DBConst.MASTER)
    public Response pushCssTaskForTest(Integer day) {
        //查询job里面 未开始的 并且时间是今天的
        LambdaQueryWrapper<CssTaskPo> queryWrapper = Wrappers.<CssTaskPo>lambdaQuery()
                .eq(CssTaskPo::getPlanCallTime, LocalDate.now().plusDays(day))
                .eq(CssTaskPo::getStatus, CssTaskStatusEnum.UN_START.getCode())
                .orderByDesc(CssTaskPo::getId);
        List<CssTaskPo> cssTaskPos = cssTaskMapper.selectList(queryWrapper);
        if (cssTaskPos == null || cssTaskPos.size() == 0) {
            return Response.successMsg("不存在需要执行的回访任务");
        }
        for (CssTaskPo cssTaskPo : cssTaskPos) {
            CssTaskMqRequest cssTaskMqRequest = ObjectUtils.toObject(cssTaskPo, CssTaskMqRequest.class);
            //几点提交是个问题
            cssTaskMqRequest.setTag(cssTaskPo.getAiType());
            cssTaskMqRequest.setGiftInfo("积分礼品卷");
            cssTaskMqRequest.setTaskId(cssTaskPo.getId());
            cssMQSender.send(JSONObject.toJSONString(cssTaskMqRequest), 1000);
        }
        //更新task中的状态为进行中
        cssTaskMapper.update(null, new UpdateWrapper<CssTaskPo>()
                .eq("plan_call_time", LocalDate.now().plusDays(day))
                .eq("status", CssTaskStatusEnum.UN_START.getCode())
                .set("call_time", LocalDateTime.now())
                .set("status", CssTaskStatusEnum.STARTING.getCode()));
        return Response.successMsg("提交任务完成！");
    }

    /**
     * 接收mq消息
     *
     * @param json
     */
    @Transactional(rollbackFor = Exception.class)
    public void receiver(String json) {
        CssTaskMqResponse cssTaskMqResponse = JSONObject.parseObject(json, CssTaskMqResponse.class);
        CssTaskPo cssTaskPo = cssTaskMapper.selectById(cssTaskMqResponse.getPos_task_id());
        if (cssTaskPo == null) {
            log.error("不存在的回访任务{}", cssTaskMqResponse);
            return;
        }
        if (!cssTaskPo.getCssStatus().equals(CssTaskCssStatusEnum.KD_02.getCode())) {
            log.error("重复提交的任务{}", cssTaskMqResponse);
            return;
        }
        List<CssTaskEvalResponse> evals = cssTaskMqResponse.getDialog_text();
        if (evals != null) {
            List<CssEvalScorePo> cssEvalScorePos = new ArrayList<>();
            List<CssEvalScoreKeywordPo> cssEvalScoreKeywordPos = new ArrayList<>();
            evals.forEach(e -> {
                if (e.getEval_tag() != null) {
                    CssEvalScorePo cssEvalScorePo = CssEvalScorePo.builder().createTime(LocalDateTime.now())
                            .evalTag(e.getEval_tag())
                            .taskId(cssTaskMqResponse.getPos_task_id())
                            .score(e.getScore())
                            .statement(JSONObject.toJSONString(e.getText_man_list()))
                            .build();
                    cssEvalScorePos.add(cssEvalScorePo);
                }
                List<CssTaskEvalKeywordResponse> keywords = e.getKeywords();
                //可能存在重复项  要整合到text中
                if (keywords != null) {
                    Set<String> keySet = keywords.stream().map(CssTaskEvalKeywordResponse::getKey).collect(Collectors.toSet());
                    for (String keyword : keySet) {
                        List<String> texts = new ArrayList<>();
                        keywords.forEach(key -> {
                            if (keyword.equals(key.getKey())) {
                                texts.add(key.getText());
                            }
                        });
                        CssEvalScoreKeywordPo cssEvalScoreKeywordPo = CssEvalScoreKeywordPo.builder().createTime(LocalDateTime.now())
                                .evalTag(e.getEval_tag())
                                .taskId(cssTaskMqResponse.getPos_task_id())
                                .text(JSONObject.toJSONString(texts))
                                .word(keyword)
                                .build();
                        cssEvalScoreKeywordPos.add(cssEvalScoreKeywordPo);
                    }
                }
            });

            if (cssEvalScorePos.size() > 0) {
                cssEvalScoreMapper.batchInsert(cssEvalScorePos);
            }
            if (cssEvalScoreKeywordPos.size() > 0) {
                cssEvalScoreKeywordMapper.batchInsert(cssEvalScoreKeywordPos);
            }
        }
        //修改主表的状态
        CssTaskPo cssTaskPoNew = CssTaskPo.builder()
                .audioUrl(cssTaskMqResponse.getVoice_url())
                .cssStatus(cssTaskMqResponse.getTask_result_desc())
                .id(cssTaskMqResponse.getPos_task_id())
                .updateTime(LocalDateTime.now())
                .build();
        cssTaskMapper.updateById(cssTaskPoNew);
    }
}
