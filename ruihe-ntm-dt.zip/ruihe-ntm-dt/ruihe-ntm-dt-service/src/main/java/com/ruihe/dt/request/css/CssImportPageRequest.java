package com.ruihe.dt.request.css;

import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * 会员回访导入
 *
 * @author fly
 */
@ApiModel(value = "CssImportPageRequest", description = "会员回访导入分页查询请求")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CssImportPageRequest extends PageForm {

    @ApiModelProperty("导入日期-开始时间")
    private LocalDate startTime;

    @ApiModelProperty("导入日期-结束时间")
    private LocalDate endTime;

    @ApiModelProperty("导入名称")
    private String name;

    @ApiModelProperty("计划编码")
    private String planNo;
}
