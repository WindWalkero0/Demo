package com.ruihe.dt.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 会员邀约记录响应
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "InvitationJobResponse", description = "会员邀约记录响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvitationTaskResponse implements Serializable {
    @ApiModelProperty(value = "任务ID")
    private Long taskId;

    @ApiModelProperty(value = "会员名称")
    private String memberName;

    @ApiModelProperty(value = "会员手机号")
    private String memberPhone;

    @ApiModelProperty(value = "会员手机号")
    private String memberLevel;

    @ApiModelProperty(value = "标签")
    private String tag;

    @ApiModelProperty(value = "状态  0未开始 1接受 2拒绝 3待确认 4终止")
    private Integer status;

    @ApiModelProperty(value = "邀约结果描述")
    private String invResult;

    @ApiModelProperty(value = "显示签到按钮")
    private Boolean showStatus;

    @ApiModelProperty(value = "显示查看按钮")
    private Boolean showText;

    @ApiModelProperty(value = "到店状态 0待定 1未到店 2签到")
    private Integer arrStatus;

    @ApiModelProperty(value = "预约到店时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectArrTime;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

}
