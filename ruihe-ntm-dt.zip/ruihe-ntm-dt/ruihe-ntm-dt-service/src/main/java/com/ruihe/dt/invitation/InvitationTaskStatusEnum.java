package com.ruihe.dt.invitation;

import org.springframework.util.StringUtils;

/**
 * AI邀约计划
 *
 * @author fly
 */
public enum InvitationTaskStatusEnum {

    UN_START(0, "未开始"),
    ACCEPT(1, "接受"),
    REFUSE(2, "拒绝"),
    UN_CONFIRMED(3, "待确认"),
    STOP(4, "已停止"),
    ;

    private Integer code;
    private String msg;


    InvitationTaskStatusEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static InvitationTaskStatusEnum instance(String code) {
        if (code == null) {
            return null;
        }
        for (InvitationTaskStatusEnum e : values()) {
            if (e.getCode().equals(code)) {
                return e;
            }
        }
        return null;
    }

    public static InvitationTaskStatusEnum getMsg(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (InvitationTaskStatusEnum e : values()) {
            if (e.getMsg().equals(value)) {
                return e;
            }
        }
        return null;
    }

}
