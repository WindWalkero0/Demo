package com.ruihe.dt.service;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.dao.mapper.fa.ParameterConfigMapper;
import com.ruihe.dt.mapper.InvitationAvlInviteeMapper;
import com.ruihe.dt.mapper.QueryHgsMapper;
import com.ruihe.dt.po.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author fly
 * @date 2020年11月6日14:03:42
 */
@Slf4j
@Service
@DS(DBConst.HGS)
public class InvitationQueryService {

    @Autowired
    private InvitationAvlInviteeMapper invitationAvlInviteeMapper;

    @Autowired
   private ParameterConfigMapper parameterConfigMapper;

    @Autowired
    private QueryHgsMapper queryHgsMapper;

    /**
     * 获取hgs的柜台的map
     *
     * @return
     */
    public Map<String, CounterInformation> getCounterMap() {
        List<CounterInformation> counterInformationList = queryHgsMapper.selectCounter();
        return counterInformationList.stream().collect(Collectors.toMap(CounterInformation::getCounterName, e -> e));
    }

    public Map<String, CounterInformation> getCounterIdMap() {
        List<CounterInformation> counterInformationList = queryHgsMapper.selectAllCounter();
        return counterInformationList.stream().collect(Collectors.toMap(CounterInformation::getCounterId, e -> e));
    }

    /**
     * 获取hgs的等级
     *
     * @return
     */
    public Map<String, MemberLevel> getMemberLevelMap() {
        List<MemberLevel> memberLevelList = queryHgsMapper.selectLevel();
        return memberLevelList.stream().collect(Collectors.toMap(MemberLevel::getLevelName, e -> e));
    }

    /**
     * 获取ba手机号
     *
     * @return
     */
    public String getBaPhone(String baCode) {
        return queryHgsMapper.getBaPhone(baCode);
    }

    /**
     * 登录里面获取用户
     *
     * @return
     */
    public UserAccount getUserAccount(String account) {
        return queryHgsMapper.getUserAccount(account);
    }

    /**
     * 登录里面获取用户
     *
     * @return
     */
    public UserInformation getUserInformation(String account) {
        return queryHgsMapper.getUserInformation(account);
    }

    /**
     * 获取邀约的配置
     *
     * @return
     */
    public InvitationConfig getInvitationConfig() {
        String json = parameterConfigMapper.selectById("INVITATION_CONFIG").getValue();
        return JSONObject.parseObject(json, InvitationConfig.class);
    }
}
