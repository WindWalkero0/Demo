package com.ruihe.dt.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.List;

/**
 * @author fly
 */
@ApiModel(value = "InvitationJobRequest", description = "添加会员邀约任务")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvitationJobRequest {

    @ApiModelProperty(value = "柜台编码")
    @NotBlank(message = "柜台编码不能为空")
    private String counterId;

    @ApiModelProperty(value = "柜台编码")
    @NotBlank(message = "柜台编码不能为空")
    private String counterName;

    @ApiModelProperty(value = "ba编码")
    @NotBlank(message = "ba编码不能为空")
    private String baCode;

    @ApiModelProperty(value = "ba名称")
    @NotBlank(message = "ba编码不能为空")
    private String baName;

    @ApiModelProperty(value = "期望到店时间")
    @NotNull(message = "期望到店时间不能为空")
    private LocalDate expectArrTime;

    @ApiModelProperty(value = "会员编码集合")
    @NotEmpty(message = "会员编码集合")
    private List<Long> memberList;

    @ApiModelProperty(value = "导入编码")
    private String planNo;
}
