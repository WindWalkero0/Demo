package com.ruihe.dt.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.time.LocalDate;
import java.util.List;

/**
 * @author fly
 */
@ApiModel(value = "InvitationInviteePageRequest", description = "分页可邀约会员邀约")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvitationInviteePageRequest extends PageForm {

    @ApiModelProperty(value = "计划编码")
    private String planNo;

    @ApiModelProperty(value = "柜台编码")
    @NotBlank(message = "柜台编码不能为空")
    private String counterId;

    @ApiModelProperty(value = "ba编码")
    @NotBlank(message = "ba编码不能为空")
    private String baCode;

    @ApiModelProperty(value = "会员名称")
    private String memberName;

    @ApiModelProperty(value = "会员手机号")
    private String memberPhone;

    @ApiModelProperty(value = "会员等级")
    private List<String> memberLevelNames;

    @ApiModelProperty(value = "会员等级")
    private List<String> memberCheckedIds;

    @ApiModelProperty(value = "到店时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate arrStartTime;

    @ApiModelProperty(value = "到店时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate arrEndTime;

    @ApiModelProperty(value = "邀约时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate invStartTime;

    @ApiModelProperty(value = "邀约时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate invEndTime;
}
