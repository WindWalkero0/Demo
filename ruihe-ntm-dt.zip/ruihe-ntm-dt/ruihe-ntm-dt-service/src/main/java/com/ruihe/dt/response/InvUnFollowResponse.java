package com.ruihe.dt.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

/**
 * 会员
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "InvUnFollowResponse", description = "任务子项为处理数量")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvUnFollowResponse implements Serializable {
    @ApiModelProperty(value = "任务ID")
    private LocalDate expectArrTime;

    @ApiModelProperty(value = "数量")
    private List<InvitationTaskResponse> list;
}
