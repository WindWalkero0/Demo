package com.ruihe.dt.request.css;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 会员回访MQ推送实体
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "CssTaskMqRequest", description = "会员回访MQ推送实体")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CssTaskMqRequest implements Serializable {

    @ApiModelProperty(value = "任务ID")
    private Long taskId;

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "会员名称")
    private String memberName;

    @ApiModelProperty(value = "会员名称")
    private String memberPhone;

    @ApiModelProperty(value = "性别")
    private String memberSex;

    @ApiModelProperty(value = "礼物")
    private String giftInfo;

    @ApiModelProperty(value = "类型 后期扩展  现在只有回访")
    private String tag;
}
