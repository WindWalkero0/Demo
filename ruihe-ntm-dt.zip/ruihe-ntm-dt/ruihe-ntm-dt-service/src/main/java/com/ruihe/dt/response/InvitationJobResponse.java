package com.ruihe.dt.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 会员邀约记录响应
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "InvitationJobResponse", description = "会员邀约记录响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvitationJobResponse implements Serializable {
    @ApiModelProperty(value = "任务ID")
    private Long jobId;

    @ApiModelProperty(value = "邀约人数")
    private Integer invQty;

    @ApiModelProperty(value = "接受人数")
    private Integer acceptQty;

    @ApiModelProperty(value = "待确认人数")
    private Integer tbcQty;

    @ApiModelProperty(value = "ba编码")
    private String baCode;

    @ApiModelProperty(value = "ba名称")
    private String baName;

    @ApiModelProperty(value = "柜台编码")
    private String counterId;

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "状态  0未开始 1进行中 2已完成 3已停止")
    private Integer status;

    @ApiModelProperty(value = "未处理数量")
    private Integer unConfirmedQty;

    @ApiModelProperty(value = "预约到店时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectArrTime;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

}
