package com.ruihe.dt.enums;

import org.springframework.util.StringUtils;

/**
 * 新会员周期回访,入会周期枚举
 *
 * @author huangjie
 * @date 2021-04-13
 */
public enum NewMemberCycleEnum {

    SEVEN_DAYS(7, "首次购买后第2-8天"),
    TWENTY_ONE_DAYS(21, "首次购买后第9-29天"),
    SIXTY_DAYS(60, "首次购买后第30-60天"),
    NINETY_DAYS(90, "首次购买后第61-90天");

    private Integer key;
    private String value;


    NewMemberCycleEnum(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public static NewMemberCycleEnum instance(Integer key) {
        if (key == null) {
            return null;
        }
        for (NewMemberCycleEnum e : values()) {
            if (e.getKey().equals(key)) {
                return e;
            }
        }
        return null;
    }

    public static NewMemberCycleEnum getString(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (NewMemberCycleEnum e : values()) {
            if (e.getValue().equals(value)) {
                return e;
            }
        }
        return null;
    }
}
