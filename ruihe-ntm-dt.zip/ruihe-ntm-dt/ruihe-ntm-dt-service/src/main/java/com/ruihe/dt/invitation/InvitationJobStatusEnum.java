package com.ruihe.dt.invitation;

import org.springframework.util.StringUtils;

/**
 * AI邀约计划
 *
 * @author fly
 */
public enum InvitationJobStatusEnum {

    UN_START(0, "未开始"),
    STARTING(1, "进行中"),
    END(2, "已完成"),
    STOP(3, "已停止"),
    ;

    private Integer code;
    private String msg;


    InvitationJobStatusEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static InvitationJobStatusEnum instance(String code) {
        if (code == null) {
            return null;
        }
        for (InvitationJobStatusEnum e : values()) {
            if (e.getCode().equals(code)) {
                return e;
            }
        }
        return null;
    }

    public static InvitationJobStatusEnum getMsg(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (InvitationJobStatusEnum e : values()) {
            if (e.getMsg().equals(value)) {
                return e;
            }
        }
        return null;
    }

}
