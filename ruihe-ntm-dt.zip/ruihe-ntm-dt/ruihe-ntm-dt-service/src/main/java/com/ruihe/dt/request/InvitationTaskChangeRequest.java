package com.ruihe.dt.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

/**
 * @author fly
 */
@ApiModel(value = "InvitationTaskChangeRequest", description = "会员邀约签到")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvitationTaskChangeRequest {

    @ApiModelProperty(value = "工作id")
    @NotNull(message = "工作id不能为空")
    private Long taskId;

    @ApiModelProperty(value = "到店状态 1当天未到店 2已签到")
    @NotNull(message = "到店状态不能为空")
    private Integer status;

}
