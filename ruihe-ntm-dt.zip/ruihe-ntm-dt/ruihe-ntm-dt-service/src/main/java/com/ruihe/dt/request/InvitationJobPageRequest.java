package com.ruihe.dt.request;

import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * @author fly
 */
@ApiModel(value = "InvitationJobPageRequest", description = "美导邀约记录分页查询")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvitationJobPageRequest extends PageForm {

    @ApiModelProperty(value = "柜台编码")
    @NotBlank(message = "柜台编码不能为空")
    private String counterId;

    @ApiModelProperty(value = "ba编码")
    @NotBlank(message = "ba编码不能为空")
    private String baCode;

    @ApiModelProperty(value = "开始时间")
    @NotNull(message = "开始时间不能为空")
    private LocalDate startTime;

    @ApiModelProperty(value = "结束时间")
    @NotNull(message = "结束时间不能为空")
    private LocalDate endTime;
}
