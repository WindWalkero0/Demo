package com.ruihe.dt.invitation;

import org.springframework.util.StringUtils;

/**
 * 任务类型  1 邀约 2 回访
 *
 * @author fly
 */
public enum AttachmentTypeEnum {

    INV_01(1, "邀约"),
    CSS_01(2, "回访"),
    ;

    private Integer code;
    private String msg;


    AttachmentTypeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static AttachmentTypeEnum instance(String code) {
        if (code == null) {
            return null;
        }
        for (AttachmentTypeEnum e : values()) {
            if (e.getCode().equals(code)) {
                return e;
            }
        }
        return null;
    }

    public static AttachmentTypeEnum getMsg(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (AttachmentTypeEnum e : values()) {
            if (e.getMsg().equals(value)) {
                return e;
            }
        }
        return null;
    }

}
