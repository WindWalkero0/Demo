package com.ruihe.dt.enums;

import org.springframework.util.StringUtils;

/**
 * 月度规划中英文枚举
 *
 * @author huangjie
 * @Date:2021年07月07日
 */
public enum MonthlyPlanEnum {
    FINANCIAL_MONTH( "记账期间_财务期间","financialMonth"),
    ATTRIBUTES( "属性","attributes"),
    MOST_SECTORS( "大部门","mostSectors"),
    SMALL_SECTORS( "小部门","smallSectors"),
    AREA( "区域","area"),
    STORE_NAME( "门店名称","storeName"),
    TARGET_LEVEL( "目标层级","targetLevel"),
    STORE_GOAL( "门店目标","storeGoal"),
    WEEKDAY_GOAL( "平日目标","weekdayGoal"),
    WEEKEND_GOAL( "周末及活动目标","weekendGoal"),
    MEMBERS_DAY_GOAL( "会员日目标","membersDayGoal"),

    NEW_CONSUMPTION_GOAL( "经营新会员人均消费目标","newConsumptionGoal"),
    NEW_NUM_GOAL("经营新会员购买人数目标", "newNumGoal"),
    NEW_PERFORMANCE_GOAL("经营新会员购买金额业绩目标", "newPerformanceGoal"),
    NEW_PERCENTAGE_GOAL("经营新会员购买金额占比目标", "newPercentageGoal"),
    NEW_CONSUMPTION_COMPLETION("经营新会员人均消费", "newConsumptionCompletion"),
    NEW_ORDER_GOAL("经营新会员订单数目标", "newOrderGoal"),
    OLD_NUM_GOAL("老会员购买人数目标","oldNumGoal"),
    OLD_PERFORMANCE_GOAL("老会员购买金额业绩目标","oldPerformanceGoal"),
    OLD_PERCENTAGE_GOAL("老会员购买金额占比目标", "oldPercentageGoal"),
    OLD_CONSUMPTION_GOAL("老会员人均消费目标","oldConsumptionGoal"),
    OLD_ORDER_GOAL("老会员订单数目标","oldOrderGoal"),

    NUMBER_OF_NURSING_MEMBERS_GOAL( "护理会员数量目标","numberOfNursingMembersGoal"),
    MEMBER_CARE_FREQUENCY_GOAL( "会员护理频次目标","memberCareFrequencyGoal"),
    NUMBER_OF_NURSING_SERVICE_GOAL( "护理服务次数目标","numberOfNursingServiceGoal"),
    NUMBER_OF_BA_SERVICES_GOAL( "美导护理服务次数/月/人目标","numberOfBaServicesGoal"),
    MEMBER_SERVICE_SATISFACTION_GOAL( "会员服务满意度目标","memberServiceSatisfactionGoal"),
    ADD_PAG_SUM_GOAL( "新会员新增护理包数量目标","addPagSumGoal"),
    VOUCHER_NUM_GOAL( "体验劵发放量目标","voucherNumGoal"),
    EYE_TRIM_NUM_GOAL( "修眉量目标","eyeTrimNumGoal"),
    EXPERIENCE_NUM_GOAL( "体验人数目标","experienceNumGoal"),
    BA_SER_FRE_DAY_GOAL( "美导护理服务次数/日/人目标","baSerFreDayGoal"),
    STORE_LOGIC_GOAL( "门店业绩逻辑目标","storeLogicGoal"),
    DAILY_LOGIC_GOAL( "门店平日业绩逻辑目标","dailyLogicGoal"),
    WEEKEND_LOGIC_GOAL( "门店周末业绩逻辑目标","weekendLogicGoal"),
    MEMBERS_DAY_LOGIC_GOAL( "门店会员日业绩逻辑目标","membersDayLogicGoal"),
    BUY_SUM_LOGIC_GOAL( "经营新会员购买人数逻辑目标","buySumLogicGoal"),
    OLD_BUY_SUM_LOGIC_GOAL( "老会员购买人数逻辑目标","oldBuySumLogicGoal"),
    SER_FRE_LOGIC_GOAL( "护理服务次数逻辑目标","serFreLogicGoal"),
    EXP_ISS_LOGIC_GOAL( "体验券发放量逻辑目标","expIssLogicGoal"),
    EYE_TRI_LOGIC_GOAL( "修眉量逻辑目标","eyeTriLogicGoal"),
    EYE_TRY_LOGIC_GOAL( "体验人数逻辑目标","eyeTryLogicGoal"),
    VOUCHER_NUM_COMPLETION( "体验券发放量","voucherNumCompletion"),
    EYE_TRIM_NUM_COMPLETION( "修眉量","eyeTrimNumCompletion"),
    EXPERIENCE_NUM_COMPLETION( "体验人数","experienceNumCompletion"),
    OLD_INVITE_SUM( "老会员邀约人数","oldInviteSum"),
    RES_NUR_SUM( "预约护理人数","resNurSum"),
    AVA_SALE_SUM( "可销售总人数","avaSaleSum"),
    COUNTER_NAME( "柜台名称","counterName"),
    STORE_ACHIEVEMENT( "分摊后金额","storeAchievement"),
    ORDER_SUM( "订单数","orderSum"),
    BUY_SUM( "购买数量","buySum"),
    NEW_NUM_COMPLETION("经营新会员人数", "newNumCompletion"),
    NEW_PERFORMANCE_COMPLETION("经营新会员金额", "newPerformanceCompletion"),
    MEM_BUY_SUM( "经营新会员购买数量","memBuySum"),
    NEW_ORDER_COMPLETION("经营新会员订单数", "newOrderCompletion"),
    OLD_ORDER_COMPLETION("老会员订单数","oldOrderCompletion"),
    OLD_PERFORMANCE_COMPLETION("老会员金额","oldPerformanceCompletion"),
    OLD_MEM_BUY_SUM( "老会员购买数量","oldMemBuySum"),
    OLD_NUM_COMPLETION("老会员人数","oldNumCompletion"),
    WEEKDAY_ACHIEVEMENT( "平日业绩","weekdayAchievement"),
    WEEKEND_ACHIEVEMENT( "周末及活动业绩","weekendAchievement"),
    MEMBERS_DAY_ACHIEVEMENT( "会员日业绩","membersDayAchievement"),
    WEEKDAYS( "平日天数","weekdays"),
    WEEKEND_DAYS( "周末及活动天数","weekendDays"),
    MEMBER_DAYS( "会员日天数","memberDays"),
    WEEKDAY_DAILY_AVERAGE( "平日日均","weekdayDailyAverage"),
    WEEKEND_DAILY_AVERAGE( "周末及活动日均","weekendDailyAverage"),
    MEMBER_DAYS_DAILY_AVERAGE( "会员日日均","memberDaysDailyAverage"),
    OLD_CONSUMPTION_COMPLETION( "老会员人均消费","oldConsumptionCompletion"),
    MEM_TOTAL_MONEY( "会员总金额","memTotalMoney"),
    NEW_UNIVALENT_COMPLETION( "经营新会员客单价","newUnivalentCompletion"),
    OLD_UNIVALENT_COMPLETION( "老会员客单价","oldUnivalentCompletion"),
    OLD_PERCENTAGE_COMPLETION( "老会员购买金额占比","oldPercentageCompletion"),
    BA_SUM( "美导人数","baSum"),
    BA_SER_FRE( "美导护理次数","baSerFre"),
    NUMBER_OF_BA_SERVICES_FULFIL( "美导护理服务次数/月/人","numberOfBaServicesFulfil"),
    NUMBER_OF_NURSING_SERVICE_FULFIL( "门店护理次数","numberOfNursingServiceFulfil"),
    NUMBER_OF_NURSING_MEMBERS_FULFIL( "护理会员数量","numberOfNursingMembersFulfil"),
    MEMBER_CARE_FREQUENCY_FULFIL( "会员护理频次","memberCareFrequencyFulfil"),
    NUR_MEM_BUY_MONEY( "有护理的会员的消费金额","nurMemBuyMoney"),
    NUR_PAC_AVG_MONEY( "护理包人均消费","nurPacAvgMoney"),
    NUR_PAC_SUM( "护理包数量","nurPacSum"),
    LAST_MON_NUR_PAC_SUM( "截止上月护理包数量","lastMonNurPacSum"),
    NUR_PAC_SUM_ADD( "护理包数量净增","nurPacSumAdd"),
    LAST_DAY_NUR_PAC_SUM( "截止昨日护理包数量","lastDayNurPacSum"),
    ADD_MEM_NUR_PAC( "新增会员新增护理包","addMemNurPac"),
    MON_DAY_SUM( "整月天数","monDaySum"),
    TOTAL_DAYS( "当前天数","totalDays"),
    BA_NUR_SER_FRE_COE( "美导护理服务次数系数","baNurSerFreCoe"),
    OLD_UNIVALENT_GOAL( "老会员客单价目标","oldUnivalentGoal"),
    NEW_UNIVALENT_GOAL( "经营新会员客单价目标","newUnivalentGoal"),
    MEM_MONEY( "新会员金额","memMoney"),
    NEW_PERCENTAGE_COMPLETION( "经营新会员购买金额占比","newPercentageCompletion"),
    ADD_MEM_BUY_PER( "新增会员购买金额占比","addMemBuyPer"),
    STORE_SYNC_RATE( "门店业绩同步率","storeSyncRate"),
    WEEKDAY_SYNC_RATE( "平日业绩同步率","weekdaySyncRate"),
    WEEKEND_SYNC_RATE( "周末及活动业绩同步率","weekendSyncRate"),
    MEMBERS_DAY_SYNC_RATE( "会员日业绩同步率","membersDaySyncRate"),
    NEW_NUM_SYNC( "经营新会员购买人数同步率","newNumSync"),
    OLD_NUM_SYNC( "老会员购买人数同步率","oldNumSync"),
    VOUCHER_NUM_SYNC( "体验券发放量同步率","voucherNumSync"),
    EYE_TRIM_NUM_SYNC( "修眉量同步率","eyeTrimNumSync"),
    EXPERIENCE_NUM_SYNC( "体验人数同步率","experienceNumSync"),
    NUMBER_OF_NURSING_SERVICE_SYNC( "门店护理服务次数同步率","numberOfNursingServiceSync"),
    STORE_MON_DIFF( "门店业绩月度差额","storeMonDiff"),
    MEM_BUY_MON_DIFF( "经营新会员购买金额业绩月度差额","memBuyMonDiff"),
    MEM_BUY_SUM_MON_DIFF( "经营新会员购买人数月度差额","memBuySumMonDiff"),
    OLD_MEM_BUY_MON_DIFF( "老会员购买金额月度差额","oldMemBuyMonDiff"),
    OLD_BUY_SUM_MON_DIFF( "老会员购买人数月度差额","oldBuySumMonDiff"),
    BA_NUR_SER_DA( "美导护理服务次数/日/人","baNurSerDa"),
    STORE_DAILY_AVERAGE( "门店业绩日均","storeDailyAverage"),
    COUNTER_ID( "柜台ID","counterId"),
    MEMBER_SERVICE_SATISFACTION_FULFIL( "满意度得分","memberServiceSatisfactionFulfil"),
    CUR_DATE( "当前日期","curDate"),
    OPINIONS_NUM_GOAL("口碑人数目标","opinionsNumGoal"),
    OPINIONS_NUM_COMPLETION("口碑人数","opinionsNumCompletion"),
    OPINIONS_NUM_SYNC("口碑人数同步率","opinionsNumSync");
    private String key;
    private String value;


    MonthlyPlanEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public static MonthlyPlanEnum instance(String key) {
        if (key == null) {
            return null;
        }
        for (MonthlyPlanEnum e : values()) {
            if (e.getKey().equals(key)) {
                return e;
            }
        }
        return null;
    }

    public static MonthlyPlanEnum getString(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (MonthlyPlanEnum e : values()) {
            if (e.getValue().equals(value)) {
                return e;
            }
        }
        return null;
    }
}
