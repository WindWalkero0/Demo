package com.ruihe.dt.request;

import com.ruihe.common.pojo.PageForm;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * @author fly
 */
@ApiModel(value = "InvitationUnFollowRequest", description = "美导未处理分页查询")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvitationUnFollowRequest extends PageForm {

    @ApiModelProperty(value = "柜台编码")
    @NotBlank(message = "柜台编码不能为空")
    private String counterId;

    @ApiModelProperty(value = "ba编码")
    @NotBlank(message = "ba编码不能为空")
    private String baCode;

}
