package com.ruihe.dt.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 会员邀约记录响应
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "InvitationAvlInviteeResponse", description = "会员邀约记录响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvitationAvlInviteeResponse implements Serializable {

    @ApiModelProperty(value = "id回传的时候用")
    private Long id;

    @ApiModelProperty(value = "任务编码回传的时候用")
    private String planNo;

    @ApiModelProperty(value = "会员等级")
    private String memberLevelName;

    @ApiModelProperty(value = "会员名称")
    private String memberName;

    @ApiModelProperty(value = "会员手机号")
    private String memberPhone;

    @ApiModelProperty(value = "标签")
    private String tag;

    @ApiModelProperty(value = "邀约结果")
    private String invResult;

    @ApiModelProperty(value = "给对话文本用")
    private Long taskId;

    @ApiModelProperty(value = "是否展示查看按钮")
    private Boolean showText;

    @ApiModelProperty(value = "最近一次邀约结果")
    private Integer lastestArrStatus;

    @ApiModelProperty(value = "最近一次到店时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime lastestArrTime;

    @ApiModelProperty(value = "最近一次邀约时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime lastestInvTime;

}
