package com.ruihe.dt.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 会员邀约记录响应
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "InvitationTaskMqResponse", description = "会员邀约记录mq响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvitationTaskMqResponse implements Serializable {

    @ApiModelProperty(value = "任务ID")
    private Long pos_task_id;

    @ApiModelProperty(value = "状态 0未开始 1接受 2拒绝 3待确认 4终止")
    private Integer task_result_desc;

    @ApiModelProperty(value = "响应描述")
    private String task_result_text;

}
