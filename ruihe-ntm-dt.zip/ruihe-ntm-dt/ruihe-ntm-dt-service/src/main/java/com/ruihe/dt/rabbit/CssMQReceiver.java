package com.ruihe.dt.rabbit;


import com.rabbitmq.client.Channel;
import com.ruihe.dt.service.css.CssTaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 * @author fly
 */
@Component
@EnableRabbit
@Configuration
@Slf4j
public class CssMQReceiver {

    @Autowired
    private CssTaskService cssTaskService;

    @RabbitListener(queues = RabbitConstants.AI_CSS_CALLBACK_QUEUE)
    public void acceptInvitation(String json, Message message, Channel channel) throws Exception {
        //接收ai邀约回调
        Long deliveryTag = 0L;
        try {
            log.info("css__________json:      " + json);
            deliveryTag = (Long) message.getHeaders().get(AmqpHeaders.DELIVERY_TAG);
            //处理回访业务
            cssTaskService.receiver(json);
        } catch (Exception e) {
            log.error("AI邀约队列消费失败,e{}", e.toString());
        } finally {
            channel.basicAck(deliveryTag, false);
        }
    }
}
