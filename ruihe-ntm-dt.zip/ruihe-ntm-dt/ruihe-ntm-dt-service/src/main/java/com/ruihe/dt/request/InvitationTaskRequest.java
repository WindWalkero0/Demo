package com.ruihe.dt.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author fly
 */
@ApiModel(value = "会员邀约任务")
@Data
public class InvitationTaskRequest {

    @ApiModelProperty(value = "工作id")
    @NotNull(message = "工作id不能为空")
    private Long taskId;

    @ApiModelProperty(value = "到店状态 0当天未到店 1已签到")
    @NotNull(message = "到店状态不能为空")
    private Integer status;

}
