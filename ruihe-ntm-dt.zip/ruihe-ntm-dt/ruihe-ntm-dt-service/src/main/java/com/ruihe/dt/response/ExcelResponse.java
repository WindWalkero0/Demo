package com.ruihe.dt.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * excal表头中英文下标
 *
 * @author huangjie
 * @Date:2021年07月02日
 */
@ApiModel(value = "InvitationAvlInviteeResponse", description = "excal表头中英文下标")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExcelResponse {

    @ApiModelProperty(value = "中文表头")
    private String chineseHeader;

    @ApiModelProperty(value = "英文表头")
    private String englishHeader;

    @ApiModelProperty(value = "下标")
    private Integer subscript;
}
