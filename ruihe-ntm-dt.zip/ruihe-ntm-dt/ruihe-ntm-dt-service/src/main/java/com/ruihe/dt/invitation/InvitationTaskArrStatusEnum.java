package com.ruihe.dt.invitation;

import org.springframework.util.StringUtils;

/**
 * AI邀约计划
 *
 * @author fly
 */
public enum InvitationTaskArrStatusEnum {

    UN_CHECK(0, "待定"),
    UN_SHOP(1, "当天未到店"),
    SIGNED(2, "已签到"),
    ;

    private Integer code;
    private String msg;


    InvitationTaskArrStatusEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static InvitationTaskArrStatusEnum instance(String code) {
        if (code == null) {
            return null;
        }
        for (InvitationTaskArrStatusEnum e : values()) {
            if (e.getCode().equals(code)) {
                return e;
            }
        }
        return null;
    }

    public static InvitationTaskArrStatusEnum getMsg(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (InvitationTaskArrStatusEnum e : values()) {
            if (e.getMsg().equals(value)) {
                return e;
            }
        }
        return null;
    }

}
