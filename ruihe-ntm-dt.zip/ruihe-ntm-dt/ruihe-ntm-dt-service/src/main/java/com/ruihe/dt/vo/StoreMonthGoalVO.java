package com.ruihe.dt.vo;

import com.ruihe.dt.po.StoreDayGoalInfoPo;
import com.ruihe.dt.po.StoreMonthlyGoalInfoPo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author luojie
 * @program ruihe-top
 * @description 门店月度目标-展示实体类
 * @create: 2021/6/21 17:43
 */
@ApiModel(value = "StoreMonthGoalVO", description = "门店月度目标实体类")
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class StoreMonthGoalVO implements Serializable {
    
    @ApiModelProperty(value = "门店每日目标信息")
    private List<StoreDayGoalInfoPo> storeDayGoalInfoPoList;
    
    @ApiModelProperty(value = "门店月度目标信息")
    private StoreMonthlyGoalInfoPo storeMonthlyGoalInfoPo;
}
