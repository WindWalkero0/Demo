package com.ruihe.dt.rabbit;

import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author fly
 */
@Service
public class CssMQSender {
    @Autowired
    private RabbitTemplate rabbitTemplate;

    public void send(String json, int delayTime) {
        this.rabbitTemplate.convertAndSend(RabbitConstants.AI_CSS_CALL_JOB_EXCHANGE,
                RabbitConstants.AI_CSS_CALL_JOB_ROUTING, json, new MessagePostProcessor() {
                    @Override
                    public Message postProcessMessage(Message message) throws AmqpException {
                        message.getMessageProperties().setDelay(delayTime);
                        //消息持久化
                        //message.getMessageProperties().setDeliveryMode(MessageDeliveryMode.PERSISTENT);
                        return message;
                    }
                });
    }
}
