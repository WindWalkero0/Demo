package com.ruihe.dt.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 附件响应
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "AttachmentMqResponse", description = "附件响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentMqResponse implements Serializable {

    @ApiModelProperty(value = "任务ID")
    private Long pos_task_id;

    @ApiModelProperty(value = "# 任务类型  1 邀约 2 回访")
    private Integer java_data_additional_type;

    @ApiModelProperty(value = "# 附加信息类型  1 交互数据 2 录音地址")
    private Integer outbound_task_type;

    @ApiModelProperty(value = "响应描述")
    private String java_data_additional;
}
