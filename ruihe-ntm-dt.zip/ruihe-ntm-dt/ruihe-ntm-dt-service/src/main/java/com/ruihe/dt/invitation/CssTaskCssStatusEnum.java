package com.ruihe.dt.invitation;

import org.springframework.util.StringUtils;

/**
 * AI回访
 *
 * @author fly
 */
public enum CssTaskCssStatusEnum {

    //科大的状态 估计有点多
    //这个KD_02是自己定义初始化状态
    //0 3 15 20 6  目前遇到的也就这么多

    KD_02(-2, "未提交"),
    KD_01(-1, "超时"),
    KD_0(0, "成功"),
    KD_2(2, "正在通话中"),
    KD_3(3, "无法接通"),
    KD_4(4, "关机"),
    KD_5(5, "用户正忙"),
    KD_6(6, "空号"),
    KD_7(7, "号码错误"),
    KD_8(8, "用户拒接"),
    KD_9(9, "停机"),
    KD_15(15, "客户接听后并主动挂机"),
    KD_16(16, "客户掉线"),
    KD_18(18, "接通"),
    KD_19(19, "转人工"),
    KD_20(20, "用户未接"),
    KD_22(22, "来电提醒"),
    KD_23(23, "呼入限制"),
    KD_25(25, "呼叫转移"),
    KD_26(26, "网络故障"),
    KD_27(27, "呼出受限"),
    KD_28(28, "线路故障"),
    ;

    private Integer code;
    private String msg;


    CssTaskCssStatusEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static CssTaskCssStatusEnum instance(String code) {
        if (code == null) {
            return null;
        }
        for (CssTaskCssStatusEnum e : values()) {
            if (e.getCode().equals(code)) {
                return e;
            }
        }
        return null;
    }

    public static CssTaskCssStatusEnum getMsg(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (CssTaskCssStatusEnum e : values()) {
            if (e.getMsg().equals(value)) {
                return e;
            }
        }
        return null;
    }

}
