package com.ruihe.dt.invitation;

import org.springframework.util.StringUtils;

/**
 * AI回访计划
 *
 * @author fly
 */
public enum CssTaskStatusEnum {

    UN_START(0, "未开始"),
    STARTING(1, "进行中"),
    ;

    private Integer code;
    private String msg;


    CssTaskStatusEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static CssTaskStatusEnum instance(String code) {
        if (code == null) {
            return null;
        }
        for (CssTaskStatusEnum e : values()) {
            if (e.getCode().equals(code)) {
                return e;
            }
        }
        return null;
    }

    public static CssTaskStatusEnum getMsg(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (CssTaskStatusEnum e : values()) {
            if (e.getMsg().equals(value)) {
                return e;
            }
        }
        return null;
    }

}
