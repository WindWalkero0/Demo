package com.ruihe.dt.enums;

import org.springframework.util.StringUtils;

/**
 * 会员回访周期中英文枚举
 *
 * @author huangjie
 * @Date:2021年07月07日
 */
public enum NewMemberCyclePlanEnum {
    CUR_DATE( "当前日期","curDate"),
    COUNTER_ID("发卡柜台编码","counterId"),
    COUNTER_NAME("发卡柜台","counterName"),
    BA_CODE("发卡BA","baCode"),
    BA_NAME("发卡BA姓名","baName"),
    MEMBER_ID("会员标识","memberId"),
    CURRENT_CYCLE("当前周期","currentCycle"),
    MEMBER_NAME("会员名称","memberName"),
    MEMBER_PHONE("会员手机号","memberPhone"),
    SIGNUP_DATE("入会日期","signupDate"),
    SIGNUP_MEMBER_LEVEL("入会等级","signupMemberLevel"),
    CURRENT_MEMBER_LEVEL("当前等级","currentMemberLevel"),
    FIRST_ORDER_AMT("首单金额","firstOrderAmt"),
    NURSING_LIMIT_OF7DAYS("7天底线护理","nursingLimitOf7days"),
    NURSING_BASIC_OF7DAYS("7天基础护理","nursingBasicOf7days"),
    QTY_OF7DAYS_NURSED("7天已护理","qtyOf7daysNursed"),
    SALE_LIMIT_OF7DAYS("7天底线销售","saleLimitOf7days"),
    SALE_BASIC_OF7DAYS("7天基础销售","saleBasicOf7days"),
    ATY_OF7DAYS_SALE("7天已销售","qtyOf7daysSale"),
    STATUS_OF7DAYS("7天完成状态","statusOf7days"),
    NURSING_LIMIT_OF21DAYS("21天底线护理","nursingLimitOf21days"),
    NURSING_BASIC_OF21DAYS("21天基础护理","nursingBasicOf21days"),
    QTY_OF21DAYS_NURSED("21天已护理","qtyOf21daysNursed"),
    SALE_LIMIT_OF21DAYS("21天底线销售","saleLimitOf21days"),
    SALE_BASIC_OF21DAYS("21天基础销售","saleBasicOf21days"),
    QTY_OF21DAYS_SALE("21天已销售","qtyOf21daysSale"),
    STATUS_OF21DAYS("21天完成状态","statusOf21days"),
    NURSING_LIMIT_OF60DAYS("60天底线护理","nursingLimitOf60days"),
    NURSING_BASIC_OF60DAYS("60天基础护理","nursingBasicOf60days"),
    QTY_OF60DAYS_NURSED("60天已护理","qtyOf60daysNursed"),
    SALE_LIMIT_OF60DAYS("60天底线销售","saleLimitOf60days"),
    SALE_BASIC_OF60DAYS("60天基础销售","saleBasicOf60days"),
    QTY_OF60DAYS_SALE("60天已销售","qtyOf60daysSale"),
    STATUS_OF60DAYS("60天完成状态","statusOf60days"),
    NURSING_LIMIT_OF90DAYS("90天底线护理","nursingLimitOf90days"),
    NURSING_BASIC_OF90DAYS("90天基础护理","nursingBasicOf90days"),
    QTY_OF90DAYS_NURSED("90天已护理","qtyOf90daysNursed"),
    SALE_LIMIT_OF90DAYS("90天底线销售","saleLimitOf90days"),
    SALE_BASIC_OF90DAYS("90天基础销售","saleBasicOf90days"),
    QTY_OF90DAYS_SALE("90天已销售","qtyOf90daysSale"),
    STATUS_OF90DAYS("90天完成状态","statusOf90days"),
    SALES_TARGET_OF90DAYS("90天销售目标","salesTargetOf90days"),
    SALES_AMT_OF90DAYS("90天销售金额","salesAmtOf90days"),
    REMAINING_AMT_OF90DAYS("90天目标剩余金额","remainingAmtOf90days"),
    DEADLINE("周期截至日","deadline"),
    REMAINING_DAYS("本周期剩余天数","remainingDays"),
    RESULT_GOAL("与目标判断结果","resultGoal");
    private String key;
    private String value;

    NewMemberCyclePlanEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public static NewMemberCyclePlanEnum instance(String key) {
        if (key == null) {
            return null;
        }
        for (NewMemberCyclePlanEnum e : values()) {
            if (e.getKey().equals(key)) {
                return e;
            }
        }
        return null;
    }

    public static NewMemberCyclePlanEnum getString(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (NewMemberCyclePlanEnum e : values()) {
            if (e.getValue().equals(value)) {
                return e;
            }
        }
        return null;
    }

}
