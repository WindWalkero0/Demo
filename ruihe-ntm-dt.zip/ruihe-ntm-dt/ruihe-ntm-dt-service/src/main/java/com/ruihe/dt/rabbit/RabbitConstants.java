package com.ruihe.dt.rabbit;

/**
 * @author fly
 */
public class RabbitConstants {

    /**
     * 邀约推送
     */
    public static final String AI_INV_CALL_JOB_QUEUE = "AI_INV_CALL_JOB_QUEUE";
    public static final String AI_INV_CALL_JOB_EXCHANGE = "AI_INV_CALL_JOB_EXCHANGE";
    public static final String AI_INV_CALL_JOB_ROUTING = "AI_INV_CALL_JOB_ROUTING";

    /**
     * 邀约接收
     */
    public static final String AI_INV_CALLBACK_QUEUE = "AI_INV_CALLBACK_QUEUE";
    public static final String AI_INV_CALLBACK_EXCHANGE = "AI_INV_CALLBACK_EXCHANGE";
    public static final String AI_INV_CALLBACK_ROUTING = "AI_INV_CALLBACK_ROUTING";

    /**
     * 回访推送
     */
    public static final String AI_CSS_CALL_JOB_QUEUE = "AI_CSS_CALL_JOB_QUEUE";
    public static final String AI_CSS_CALL_JOB_EXCHANGE = "AI_CSS_CALL_JOB_EXCHANGE";
    public static final String AI_CSS_CALL_JOB_ROUTING = "AI_CSS_CALL_JOB_ROUTING";

    /**
     * 回访接收
     */
    public static final String AI_CSS_CALLBACK_QUEUE = "AI_CSS_CALLBACK_QUEUE";
    public static final String AI_CSS_CALLBACK_EXCHANGE = "AI_CSS_CALLBACK_EXCHANGE";
    public static final String AI_CSS_CALLBACK_ROUTING = "AI_CSS_CALLBACK_ROUTING";

    /**
     * 附件接收
     */
    public static final String AI_ADDITIONAL_CALL_BACK_QUEUE = "AI_ADDITIONAL_CALL_BACK_QUEUE";
    public static final String AI_ADDITIONAL_CALL_BACK_EXCHANGE = "AI_ADDITIONAL_CALL_BACK_EXCHANGE";
    public static final String AI_ADDITIONAL_CALL_BACK_ROUTING = "AI_ADDITIONAL_CALL_BACK_ROUTING";
}
