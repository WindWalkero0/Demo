package com.ruihe.dt.enums;

import com.ruihe.common.enums.member.MemberLevelEnum;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;

/**
 * 新会员培育周期->首单金额范围
 *
 * @author huangjie
 * @date 2021-04-13
 */
public enum FirstOrderAmtEnum {
    RANGE_1(1, "800以下", BigDecimal.valueOf(0), BigDecimal.valueOf(800)),
    RANGE_2(2, "800~1800", BigDecimal.valueOf(800), BigDecimal.valueOf(1800)),
    RANGE_3(3, "1800~2800", BigDecimal.valueOf(1800), BigDecimal.valueOf(2800)),
    RANGE_4(4, "2800~5000", BigDecimal.valueOf(2800), BigDecimal.valueOf(5000)),
    RANGE_5(5, "5000+", BigDecimal.valueOf(5000), BigDecimal.valueOf(1000000)),
    ;

    private Integer code;
    private String desc;
    private BigDecimal min;
    private BigDecimal max;


    FirstOrderAmtEnum(Integer code, String desc, BigDecimal min, BigDecimal max) {
        this.code = code;
        this.desc = desc;
        this.min = min;
        this.max = max;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getDesc() {
        return this.desc;
    }

    public BigDecimal getMin() {
        return this.min;
    }

    public BigDecimal getMax() {
        return this.max;
    }

    public static FirstOrderAmtEnum instance(Integer key) {
        if (key == null) {
            return null;
        }
        for (FirstOrderAmtEnum e : values()) {
            if (e.getCode().equals(key)) {
                return e;
            }
        }
        return null;
    }

    public static FirstOrderAmtEnum getString(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (FirstOrderAmtEnum e : values()) {
            if (e.getDesc().equals(value)) {
                return e;
            }
        }
        return null;
    }
}
