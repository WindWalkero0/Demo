package com.ruihe.dt.listener;

import com.ruihe.dt.event.MsgEvent;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.msger.client.MsgerClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

/**
 * 异步发送短信服务
 *
 * @author William
 */
@Slf4j
@Component
public class MsgListener {

    @Autowired
    private MsgerClient msgerClient;

    @Async(CommonConstant.DT_THREAD_POOL_NAME)
    @TransactionalEventListener(fallbackExecution = true)
    public void onApplicationEvent(MsgEvent event) {
        msgerClient.send(event.getMsgerRequestDto());
    }
}