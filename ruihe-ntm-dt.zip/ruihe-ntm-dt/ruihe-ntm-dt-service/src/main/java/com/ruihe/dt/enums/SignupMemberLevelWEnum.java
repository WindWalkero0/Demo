package com.ruihe.dt.enums;


import org.springframework.util.StringUtils;

/**
 * 新会员培育周期回访,会员等级枚举
 * @author huangjie
 * @date 2021-04-13
 */
public enum  SignupMemberLevelWEnum {

    EXPERIENCE_MEMBER(1, "体验会员"),
    POLLEN_MEMBER(2, "花粉会员"),
    ROSE_MEMBER(3, "玫瑰会员"),
    JASMINE_MEMBER(4, "茉莉会员"),
    LILY_MEMBER(5, "百合会员"),
    PEONY_MEMBER(6, "牡丹会员");

    private Integer key;
    private String value;


    SignupMemberLevelWEnum(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public Integer getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public static SignupMemberLevelWEnum instance(Integer key) {
        if (key == null) {
            return null;
        }
        for (SignupMemberLevelWEnum e : values()) {
            if (e.getKey().equals(key)) {
                return e;
            }
        }
        return null;
    }

    public static SignupMemberLevelWEnum getString(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (SignupMemberLevelWEnum e : values()) {
            if (e.getValue().equals(value)) {
                return e;
            }
        }
        return null;
    }
}
