package com.ruihe.dt.rabbit;


import com.rabbitmq.client.Channel;
import com.ruihe.dt.service.AttachmentService;
import com.ruihe.dt.service.css.CssTaskService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 * @author fly
 */
@Component
@EnableRabbit
@Configuration
@Slf4j
public class AttachmentMQReceiver {

    @Autowired
    private AttachmentService attachmentService;

    @RabbitListener(queues = RabbitConstants.AI_ADDITIONAL_CALL_BACK_QUEUE)
    public void acceptAttachment(String json, Message message, Channel channel) throws Exception {
        //接收ai邀约回调
        Long deliveryTag = 0L;
        try {
            deliveryTag = (Long) message.getHeaders().get(AmqpHeaders.DELIVERY_TAG);
            //处理回访业务
            attachmentService.receiveMsg(json);
        } catch (DuplicateKeyException e) {
            log.warn("附件队列消费失败,python重复推送并发插入违反唯一约束,json={}", json, e);
        } catch (Exception e) {
            log.error("附件队列消费失败,json={}", json, e);
        } finally {
            channel.basicAck(deliveryTag, false);
        }
    }
}
