package com.ruihe.dt.service;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.context.holder.PosUserContextHolder;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ConversionUtil;
import com.ruihe.dt.enums.*;
import com.ruihe.dt.mapper.*;
import com.ruihe.dt.po.*;
import com.ruihe.dt.response.ExcelResponse;
import com.ruihe.dt.vo.StoreMonthGoalVO;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.util.stream.Collectors.toList;

@Slf4j
@Service
public class MonthlyPlanService {
    @Value("${guanbi.counter_sales_csv_url}")
    private String csvCounterSalesUrl;

    @Value("${guanbi.monthly_planning_csv_url}")
    private String monthlyPlanningCsvUrl;


    private static final List<String> pros = List.of("postingDate", "financialMonth", "counterId", "counterName", "dailyTargetAmt", "actualDailyAmt", "curDate");

    private static final List<String> monthPros = List.of("financialMonth", "counterId", "counterName", "storeGoal", "weekendGoal", "membersDayGoal", "weekdayGoal", "storeLogicGoal", "dailyLogicGoal", "weekendLogicGoal", "membersDayLogicGoal", "storeAchievement", "weekendAchievement", "membersDayAchievement", "weekdayAchievement", "storeSyncRate", "weekendSyncRate", "membersDaySyncRate", "weekdaySyncRate", "totalDays", "weekendDays", "memberDays", "weekdays", "storeDailyAverage", "weekendDailyAverage", "memberDaysDailyAverage", "weekdayDailyAverage", "curDate");

    private static final List<String> monthCarePackPros = List.of("financialMonth", "counterId", "counterName", "numberOfNursingMembersGoal", "memberCareFrequencyGoal", "numberOfNursingServiceGoal", "numberOfBaServicesGoal", "memberServiceSatisfactionGoal", "numberOfNursingMembersFulfil", "memberCareFrequencyFulfil", "numberOfNursingServiceFulfil", "numberOfBaServicesFulfil", "memberServiceSatisfactionFulfil", "numberOfNursingServiceSync", "curDate");

    private static final List<String> memberPros = List.of("curDate", "financialMonth", "counterId", "counterName", "newPercentageGoal", "newPercentageCompletion", "newConsumptionGoal", "newConsumptionCompletion", "newUnivalentGoal", "newUnivalentCompletion", "newPerformanceGoal", "newPerformanceCompletion", "newNumGoal", "newNumCompletion", "newNumSync", "newOrderGoal", "newOrderCompletion", "oldPercentageGoal", "oldPercentageCompletion", "oldPerformanceGoal", "oldPerformanceCompletion", "oldNumGoal", "oldNumCompletion", "oldNumSync", "oldConsumptionGoal", "oldConsumptionCompletion", "oldOrderGoal", "oldOrderCompletion", "oldUnivalentGoal", "oldUnivalentCompletion");

    private static final List<String> onePros = List.of("curDate", "financialMonth", "counterId", "counterName", "voucherNumGoal", "voucherNumCompletion", "voucherNumSync", "eyeTrimNumGoal", "eyeTrimNumCompletion", "eyeTrimNumSync", "experienceNumGoal", "experienceNumCompletion", "experienceNumSync", "opinionsNumGoal", "opinionsNumCompletion", "opinionsNumSync");

    @Autowired
    private StoreDayGoalInfoMapper storeDayGoalInfoMapper;

    @Autowired
    private StoreMonthlyGoalInfoMapper storeMonthlyGoalInfoMapper;

    @Autowired
    private MonthTargetOfCarePackMapper monthTargetOfCarePackMapper;

    @Autowired
    private MemberGoalsMapper memberGoalsMapper;

    @Autowired
    private OneGoalMapper oneGoalMapper;


    /**
     * ;通过共享文件获取门店单日目标数据
     *
     * @return
     */
    @DS(DBConst.MASTER)
    public Response downloadDayGoalByCsv() {
        MonthlyPlanService o1 = (MonthlyPlanService) AopContext.currentProxy();
        //异步解析
        new Thread(() ->
                o1.download()
        ).start();
        return Response.success();
    }

    public void download() {
        List<StoreDayGoalInfoPo> storeDayGoalInfoList = new ArrayList<>();
        try {
            BufferedReader bufferedReader = getBufferedReader(csvCounterSalesUrl, 80);
            String line;
            List<ExcelResponse> list = new ArrayList<>();
            Boolean boo = true;
            while ((line = bufferedReader.readLine()) != null) {
                String[] row = line.split(CommonConstant.COMMA);
                if (boo) {
                    List<String> headerList = Arrays.asList(row);
                    for (int j = 0; j < headerList.size(); j++) {
                        ExcelResponse excelResponse = ExcelResponse.builder()
                                .chineseHeader(headerList.get(j))
                                .englishHeader(StoreDayGoalEnum.instance(headerList.get(j).replace("\uFEFF", "")).getValue())
                                .subscript(j)
                                .build();
                        list.add(excelResponse);
                    }
                    boo = false;
                    continue;
                }
                JSONObject tempJson = getJSONObject(row, pros, list);
                StoreDayGoalInfoPo storeDayGoalInfoPo = tempJson.toJavaObject(StoreDayGoalInfoPo.class);
                storeDayGoalInfoList.add(storeDayGoalInfoPo);
            }
            bufferedReader.close();
        } catch (Exception e) {
            log.error("StoreDayGoalInfoService.downloadDayGoalByCsv.getBiDate.error", e);
        }

        //批量插入
        this.batchInsertDayGoal(storeDayGoalInfoList);
    }

    /**
     * ;批量插入门店单日规划数据(5000条/每次)
     *
     * @param storeDayGoalInfoList
     * @return
     */
    public void batchInsertDayGoal(List<StoreDayGoalInfoPo> storeDayGoalInfoList) {
        int pageSize = 5000, pageIndex = 0;
        while (true) {
            List<?> tempList = getAllList(storeDayGoalInfoList, pageSize, pageIndex);
            if (tempList == null) {
                return;
            }
            int res = storeDayGoalInfoMapper.batchInsert(tempList);
            if (res != tempList.size()) {
                throw new BizException("门店单日目标批量插入失败");
            }
            pageIndex++;
        }
    }

    /**
     * ;通过共享文件获取门店月度规划数据
     *
     * @return
     */
    @DS(DBConst.MASTER)
    public Response downloadMonthGoalByCsv() {
        List<?> storeMonthGoalInfoList = new ArrayList<>();
        try {
            storeMonthGoalInfoList = getInfoList(monthlyPlanningCsvUrl,30,monthPros,1);
        } catch (Exception e) {
            log.error("StoreDayGoalInfoService.downloadMonthGoalByCsv.getBiDate.error", e);
            return Response.errorMsg("门店月度目标数据下载失败!");
        }

        //批量插入
        this.batchInsertMonthGoal(storeMonthGoalInfoList);
        return Response.success();
    }


    /**
     * ;通过共享文件获取门店护理包月度规划数据
     *
     * @return
     */
    @DS(DBConst.MASTER)
    public Response downloadMonthCarePackGoalByCsv() {
        List<?> monthTargetOfCarePackList = new ArrayList<>();
        try {
            monthTargetOfCarePackList = getInfoList(monthlyPlanningCsvUrl,30,monthCarePackPros,2);
        } catch (Exception e) {
            log.error("StoreDayGoalInfoService.downloadMonthGoalByCsv.getBiDate.error", e);
            return Response.errorMsg("门店月度目标数据下载失败!");
        }

        //批量插入
        this.batchInsertMonthCarePackGoal(monthTargetOfCarePackList);

        return Response.success();
    }

    /**
     * ;批量插入门店月度规划数据(5000条/每次)
     *
     * @param storeMonthGoalInfoList
     * @return
     */
    public void batchInsertMonthGoal(List<?> storeMonthGoalInfoList) {
        int pageSize = 5000, pageIndex = 0;
        while (true) {
            List<?> tempList = getAllList(storeMonthGoalInfoList, pageSize, pageIndex);
            if (tempList == null) {
                return;
            }
            int res = storeMonthlyGoalInfoMapper.batchInsert(tempList);
            if (res != tempList.size()) {
                throw new BizException("门店月度目标批量插入失败");
            }
            pageIndex++;
        }
    }

    /**
     * ;批量插入门店护理包月度规划数据(5000条/每次)
     *
     * @param monthTargetOfCarePackList
     * @return
     */
    public void batchInsertMonthCarePackGoal(List<?> monthTargetOfCarePackList) {
        int pageSize = 5000, pageIndex = 0;
        while (true) {
            List<?> tempList = getAllList(monthTargetOfCarePackList, pageSize, pageIndex);
            if (tempList == null) {
                return;
            }
            int res = monthTargetOfCarePackMapper.batchInsert(tempList);
            if (res != tempList.size()) {
                throw new BizException("门店护理包月度目标批量插入失败");
            }
            pageIndex++;
        }
    }

    /**
     * 获取门店月度业绩目标信息
     *
     * @param financialMonth 财务月
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response queryPerformanceTarget(String financialMonth) {
        // 校验入参是否为空
        if (StringUtils.isBlank(financialMonth)) {
            return Response.errorMsg("请选择财务月");
        }

        String counterId = PosUserContextHolder.get().getCounter().getCounterId();
        // 获取当前日期
        LocalDate currentDate = LocalDate.now();
        // 查询财务月每日目标信息列表
        List<StoreDayGoalInfoPo> storeDayGoalInfoPoList = storeDayGoalInfoMapper.selectList(Wrappers.<StoreDayGoalInfoPo>lambdaQuery()
                .eq(StoreDayGoalInfoPo::getCurDate, currentDate)
                .eq(StoreDayGoalInfoPo::getCounterId, counterId)
                .eq(StoreDayGoalInfoPo::getFinancialMonth, financialMonth)
                .orderByAsc(StoreDayGoalInfoPo::getPostingDate));

        //获取财务月目标信息
        StoreMonthlyGoalInfoPo storeMonthlyGoalInfoPo = storeMonthlyGoalInfoMapper.selectOne(Wrappers.<StoreMonthlyGoalInfoPo>lambdaQuery()
                .eq(StoreMonthlyGoalInfoPo::getCurDate, currentDate)
                .eq(StoreMonthlyGoalInfoPo::getCounterId, counterId)
                .eq(StoreMonthlyGoalInfoPo::getFinancialMonth, financialMonth)
                .last("limit 1"));

        // 当前日期没有数据，获取前一天数据
        if (storeDayGoalInfoPoList.isEmpty()) {
            storeDayGoalInfoPoList = storeDayGoalInfoMapper.selectList(Wrappers.<StoreDayGoalInfoPo>lambdaQuery()
                    .eq(StoreDayGoalInfoPo::getCurDate, currentDate.minusDays(1))
                    .eq(StoreDayGoalInfoPo::getCounterId, counterId)
                    .eq(StoreDayGoalInfoPo::getFinancialMonth, financialMonth));
        }
        if (storeMonthlyGoalInfoPo == null) {
            storeMonthlyGoalInfoPo = storeMonthlyGoalInfoMapper.selectOne(Wrappers.<StoreMonthlyGoalInfoPo>lambdaQuery()
                    .eq(StoreMonthlyGoalInfoPo::getCurDate, currentDate.minusDays(1))
                    .eq(StoreMonthlyGoalInfoPo::getCounterId, counterId)
                    .eq(StoreMonthlyGoalInfoPo::getFinancialMonth, financialMonth)
                    .last("limit 1"));
        }

        // 同步率转换成百分比
        // 门店业绩同步率
        if (storeMonthlyGoalInfoPo != null) {
            storeMonthlyGoalInfoPo.setStoreSyncRate(ConversionUtil.stringToPercent(storeMonthlyGoalInfoPo.getStoreSyncRate()));
            storeMonthlyGoalInfoPo.setWeekdaySyncRate(ConversionUtil.stringToPercent(storeMonthlyGoalInfoPo.getWeekdaySyncRate()));
            storeMonthlyGoalInfoPo.setWeekendSyncRate(ConversionUtil.stringToPercent(storeMonthlyGoalInfoPo.getWeekendSyncRate()));
            storeMonthlyGoalInfoPo.setMembersDaySyncRate(ConversionUtil.stringToPercent(storeMonthlyGoalInfoPo.getMembersDaySyncRate()));
        }

        StoreMonthGoalVO storeMonthGoalVO = StoreMonthGoalVO.builder()
                .storeDayGoalInfoPoList(storeDayGoalInfoPoList)
                .storeMonthlyGoalInfoPo(storeMonthlyGoalInfoPo)
                .build();
        return Response.success(storeMonthGoalVO);
    }

    /**
     * 获取门店月度护理包目标信息
     *
     * @param financialMonth 财务月
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response queryCarePack(String financialMonth) {
        // 校验入参是否为空
        if (StringUtils.isBlank(financialMonth)) {
            return Response.errorMsg("请选择财务月");
        }

        // 获取当前日期
        LocalDate currentDate = LocalDate.now();


        // 查询财务月的护理包信息
        MonthTargetOfCarePackPo monthTargetOfCarePackPo = monthTargetOfCarePackMapper.selectOne(Wrappers.<MonthTargetOfCarePackPo>lambdaQuery()
                .eq(MonthTargetOfCarePackPo::getCurDate, currentDate)
                .eq(MonthTargetOfCarePackPo::getCounterId, PosUserContextHolder.get().getCounter().getCounterId())
                .eq(MonthTargetOfCarePackPo::getFinancialMonth, financialMonth)
                .last("limit 1"));

        // 如果查询当前日期数据为空，改为查询前一天
        if (monthTargetOfCarePackPo == null) {
            monthTargetOfCarePackPo = monthTargetOfCarePackMapper.selectOne(Wrappers.<MonthTargetOfCarePackPo>lambdaQuery()
                    .eq(MonthTargetOfCarePackPo::getCurDate, currentDate.minusDays(1))
                    .eq(MonthTargetOfCarePackPo::getCounterId, PosUserContextHolder.get().getCounter().getCounterId())
                    .eq(MonthTargetOfCarePackPo::getFinancialMonth, financialMonth)
                    .last("limit 1"));
        }

        // 护理服务次数完成同步率 - 转换成百分比
        if (monthTargetOfCarePackPo != null) {
            monthTargetOfCarePackPo.setNumberOfNursingServiceSync(ConversionUtil.stringToPercent(monthTargetOfCarePackPo.getNumberOfNursingServiceSync()));
        }
        return Response.success(monthTargetOfCarePackPo);
    }

    /**
     * ;通过共享文件获取会员目标数据
     *
     * @return
     */
    @DS(DBConst.MASTER)
    public Response downloadMemberGoalByCsv() {
        List<?> memberGoalsPoList = new ArrayList<>();
        try {
            memberGoalsPoList = getInfoList(monthlyPlanningCsvUrl,30,memberPros,3);
        } catch (Exception e) {
            log.error("StoreDayGoalInfoService.downloadMemberGoalByCsv.getBiDate.error", e);
            return Response.errorMsg("会员目标数据下载失败!");
        }

        //批量插入
        this.batchInsertMemberGoal(memberGoalsPoList);
        return Response.success();
    }


    /**
     * ;批量插入门店护理包月度规划数据(5000条/每次)
     *
     * @param memberGoalsPoList
     * @return
     */
    public void batchInsertMemberGoal(List<?> memberGoalsPoList) {
        int pageSize = 5000, pageIndex = 0;
        while (true) {
            List<?> tempList = getAllList(memberGoalsPoList, pageSize, pageIndex);
            if (tempList == null) {
                return;
            }
            int res = memberGoalsMapper.batchInsert(tempList);
            if (res != tempList.size()) {
                throw new BizException("会员目标批量插入失败");
            }
            pageIndex++;
        }
    }


    /**
     * ;通过共享文件获取1.0目标数据
     *
     * @return
     */
    @DS(DBConst.MASTER)
    public Response downloadBaVisitGoalByCsv() {
        List<?> baVisitGoalPoList = new ArrayList<>();
        try {
            baVisitGoalPoList = getInfoList(monthlyPlanningCsvUrl,30,onePros,4);
        } catch (Exception e) {
            log.error("StoreDayGoalInfoService.downloadMemberGoalByCsv.getBiDate.error", e);
            return Response.errorMsg("1.0目标数据下载失败!");
        }

        //批量插入
        this.batchInsertOneGoal(baVisitGoalPoList);
        return Response.success();
    }

    /**
     * ;批量插入1.0目标数据(5000条/每次)
     *
     * @param oneGoalPoList
     * @return
     */
    public void batchInsertOneGoal(List<?> oneGoalPoList) {
        int pageSize = 5000, pageIndex = 0;
        while (true) {
            List<?> tempList = getAllList(oneGoalPoList, pageSize, pageIndex);
            if (tempList == null) {
                return;
            }
            int res = oneGoalMapper.batchInsert(tempList);
            if (res != tempList.size()) {
                throw new BizException("ba规划目标批量插入失败");
            }
            pageIndex++;
        }
    }

    public JSONObject getJSONObject(String[] row, List<String> pros, List<ExcelResponse> list) {
        Map<String, String> collect = getHeadList(list, row, pros);
        JSONObject tempJson = new JSONObject();
        tempJson.putAll(collect);
        return tempJson;
    }

    public BufferedReader getBufferedReader(String url, int num) throws Exception {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new SmbFileInputStream(new SmbFile(url))), num * 1024 * 1024);
        return bufferedReader;
    }

    public List<?> getAllList(List<?> oneGoalPoList, int pageSize, int pageIndex) {
        List<?> tempList = oneGoalPoList.stream()
                .skip(pageSize * pageIndex)
                .limit(pageSize)
                .collect(toList());
        if (tempList.size() == 0) {
            return null;
        }
        return tempList;
    }


    public List<?> getInfoList(String url, int num, List<String> pros, int type) throws Exception {
        BufferedReader bufferedReader = getBufferedReader(url, num);
        List<StoreMonthlyGoalInfoPo> storeMonthGoalInfoList = new ArrayList<>();
        List<MonthTargetOfCarePackPo> monthTargetOfCarePackList = new ArrayList<>();
        List<MemberGoalPo> memberGoalsPoList = new ArrayList<>();
        List<BaVisitGoalPo> baVisitGoalPoList = new ArrayList<>();
        String line;
        List<ExcelResponse> list = new ArrayList<>();
        Boolean boo = true;
        while ((line = bufferedReader.readLine()) != null) {
            String[] row = line.split(CommonConstant.COMMA);
            if (boo) {
                list = getList(row);
                boo = false;
                continue;
            }
            JSONObject tempJson = getJSONObject(row, pros, list);
            System.out.println(tempJson);
            if (type == 1) {
                StoreMonthlyGoalInfoPo storeMonthlyGoalInfoPo = tempJson.toJavaObject(StoreMonthlyGoalInfoPo.class);
                storeMonthGoalInfoList.add(storeMonthlyGoalInfoPo);
            }
            if (type == 2) {
                MonthTargetOfCarePackPo monthTargetOfCarePackPo = tempJson.toJavaObject(MonthTargetOfCarePackPo.class);
                monthTargetOfCarePackList.add(monthTargetOfCarePackPo);
            }
            if (type == 3) {
                MemberGoalPo memberGoalsPo = tempJson.toJavaObject(MemberGoalPo.class);
                memberGoalsPoList.add(memberGoalsPo);
            }
            if (type == 4) {
                System.out.println("hh"+tempJson);
                BaVisitGoalPo baVisitGoalPo = tempJson.toJavaObject(BaVisitGoalPo.class);
                System.out.println("kk"+baVisitGoalPo);
                baVisitGoalPoList.add(baVisitGoalPo);
            }

        }
        bufferedReader.close();
        if (type == 1) {
            return storeMonthGoalInfoList;
        }
        if (type == 2) {
            return monthTargetOfCarePackList;
        }
        if (type == 3) {
            return memberGoalsPoList;
        }
        if (type == 4) {
            return baVisitGoalPoList;
        }
        return null;
    }

    private List<ExcelResponse> getList(String[] row) {
        List<ExcelResponse> list = new ArrayList<>();
        List<String> headerList = Arrays.asList(row);
        for (int j = 0; j < headerList.size(); j++) {
            ExcelResponse excelResponse = ExcelResponse.builder()
                    .chineseHeader(headerList.get(j))
                    .englishHeader(MonthlyPlanEnum.instance(headerList.get(j).replace("\uFEFF", "")) != null ? MonthlyPlanEnum.instance(headerList.get(j).replace("\uFEFF", "")).getValue() : "")
                    .subscript(j)
                    .build();
            list.add(excelResponse);
        }
        return list;
    }

    public Map<String, String> getHeadList(List<ExcelResponse> list, String[] row, List<String> prolist) {
        Map<String, Integer> headList = list.stream().collect(Collectors.toMap(ExcelResponse::getEnglishHeader, ExcelResponse::getSubscript));
        Map<String, String> collect = IntStream.range(0, prolist.size()).boxed().map(idx ->
                Map.entry(prolist.get(idx), StringUtils.defaultString(row[headList.get(prolist.get(idx))]))
        ).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        return collect;
    }

    /**
     * 获取会员目标详情信息
     *
     * @param financialMonth 财务月
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response queryMemberDetails(String financialMonth) {
        // 校验入参是否为空
        if (StringUtils.isBlank(financialMonth)) {
            return Response.errorMsg("请选择财务月");
        }

        // 获取当前日期
        LocalDate currentDate = LocalDate.now();

        // 查询财务月的会员信息
        MemberGoalPo memberGoalsPo = memberGoalsMapper.selectOne(Wrappers.<MemberGoalPo>lambdaQuery()
                .eq(MemberGoalPo::getCurDate, currentDate)
                .eq(MemberGoalPo::getCounterId, PosUserContextHolder.get().getCounter().getCounterId())
                .eq(MemberGoalPo::getFinancialMonth, financialMonth)
                .last("limit 1"));

        // 会员目标同步率 - 转换成百分比
        if (memberGoalsPo != null) {
            memberGoalsPo.setNewNumSync(ConversionUtil.stringToPercent(memberGoalsPo.getNewNumSync()));
            memberGoalsPo.setOldNumSync(ConversionUtil.stringToPercent(memberGoalsPo.getOldNumSync()));
            memberGoalsPo.setNewPercentageGoal(ConversionUtil.stringToPercent(memberGoalsPo.getNewPercentageGoal()));
            memberGoalsPo.setNewPercentageCompletion(ConversionUtil.stringToPercent(memberGoalsPo.getNewPercentageCompletion()));
            memberGoalsPo.setOldPercentageGoal(ConversionUtil.stringToPercent(memberGoalsPo.getOldPercentageGoal()));
            memberGoalsPo.setOldPercentageCompletion(ConversionUtil.stringToPercent(memberGoalsPo.getOldPercentageCompletion()));
        }
        return Response.success(memberGoalsPo);
    }

    /**
     * 获取1.0目标详情信息
     *
     * @param financialMonth 财务月
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response queryOneDetails(String financialMonth) {
        // 校验入参是否为空
        if (StringUtils.isBlank(financialMonth)) {
            return Response.errorMsg("请选择财务月");
        }

        // 获取当前日期
        LocalDate currentDate = LocalDate.now();

        // 查询财务月的1.0目标信息
        BaVisitGoalPo oneGoalPo = oneGoalMapper.selectOne(Wrappers.<BaVisitGoalPo>lambdaQuery()
                .eq(BaVisitGoalPo::getCurDate, currentDate)
                .eq(BaVisitGoalPo::getCounterId, PosUserContextHolder.get().getCounter().getCounterId())
                .eq(BaVisitGoalPo::getFinancialMonth, financialMonth)
                .last("limit 1"));

        // 1.0目标同步率 - 转换成百分比
        if (oneGoalPo != null) {
            oneGoalPo.setExperienceNumSync(ConversionUtil.stringToPercent(oneGoalPo.getExperienceNumSync()));
            oneGoalPo.setEyeTrimNumSync(ConversionUtil.stringToPercent(oneGoalPo.getEyeTrimNumSync()));
            oneGoalPo.setOpinionsNumSync(ConversionUtil.stringToPercent(oneGoalPo.getOpinionsNumSync()));
            oneGoalPo.setVoucherNumSync(ConversionUtil.stringToPercent(oneGoalPo.getVoucherNumSync()));
        }
        return Response.success(oneGoalPo);
    }
}
