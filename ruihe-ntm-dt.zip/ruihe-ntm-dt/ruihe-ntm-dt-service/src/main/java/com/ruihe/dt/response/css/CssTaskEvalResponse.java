package com.ruihe.dt.response.css;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 会员回访响应
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "CssTaskEvalResponse", description = "评价得分")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CssTaskEvalResponse implements Serializable {
    @ApiModelProperty(value = "评价标签")
    private String eval_tag;

    @ApiModelProperty(value = "得分")
    private Integer score;

    @ApiModelProperty(value = "回复文本")
    private List<String> text_man_list;

    @ApiModelProperty(value = "评价关键字")
    private List<CssTaskEvalKeywordResponse> keywords;

}
