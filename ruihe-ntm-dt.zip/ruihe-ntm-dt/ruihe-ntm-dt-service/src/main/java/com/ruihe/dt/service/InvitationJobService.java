package com.ruihe.dt.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.pagehelper.PageHelper;
import com.ruihe.dt.event.MsgEvent;
import com.ruihe.dt.invitation.InvitationAvlInviteeStatusEnum;
import com.ruihe.dt.invitation.InvitationJobStatusEnum;
import com.ruihe.dt.invitation.InvitationTaskArrStatusEnum;
import com.ruihe.dt.invitation.InvitationTaskStatusEnum;
import com.ruihe.dt.mapper.*;
import com.ruihe.dt.po.*;
import com.ruihe.dt.rabbit.XdelaySender;
import com.ruihe.dt.request.*;
import com.ruihe.dt.response.InvUnFollowResponse;
import com.ruihe.dt.response.InvitationJobResponse;
import com.ruihe.dt.response.InvitationTaskMqResponse;
import com.ruihe.dt.response.InvitationTaskResponse;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.constant.MsgerTplConstant;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.BeanUtil;
import com.ruihe.common.utils.IPUtils;
import com.ruihe.common.utils.IdGenerator;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.msger.dto.MsgerRequestDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author fly
 * @date 2020年11月6日14:03:42
 */
@Slf4j
@Service
public class InvitationJobService implements ApplicationContextAware {

    @Autowired
    private InvitationImportMapper invitationImportMapper;

    @Autowired
    private InvitationAvlInviteeMapper invitationAvlInviteeMapper;

    @Autowired
    private InvitationJobMapper invitationJobMapper;

    @Autowired
    private InvitationTaskMapper invitationTaskMapper;

    @Autowired
    private InvitationQueryService invitationQueryService;

    @Autowired
    private InvitationJobService invitationJobService;

    @Autowired
    private AttachmentMapper attachmentMapper;

    @Autowired
    private XdelaySender xdelaySender;

    private ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    /**
     * 添加邀约任务
     *
     * @param invitationJobRequest
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response addJob(InvitationJobRequest invitationJobRequest, InvitationConfig invitationConfig) {
        LocalDate expectArrTime = invitationJobRequest.getExpectArrTime();
        if (expectArrTime.compareTo(LocalDate.now()) < 0) {
            return Response.errorMsg("邀约时间不能晚于明天！");
        }
        if (expectArrTime.compareTo(LocalDate.now().plusDays(invitationConfig.getDays())) > 0) {
            return Response.errorMsg("只能添加" + invitationConfig.getDays() + "天内的邀约！");
        }
        //一个美导一天只能有5个正常的邀约计划  一个20个人
        if (invitationJobRequest.getMemberList().size() > invitationConfig.getTaskMax()) {
            return Response.errorMsg("一次最多添加" + invitationConfig.getTaskMax() + "人！");
        }
        if (expectArrTime.isEqual(LocalDate.now().plusDays(1)) && LocalDateTime.now().isBefore(LocalDate.now().atTime(9, 0, 0))) {
            return Response.errorMsg("请在9:00后邀约明天来店的会员！");
        }
        if (expectArrTime.isEqual(LocalDate.now().plusDays(1)) && LocalDateTime.now().isAfter(LocalDate.now().atTime(18, 0, 0))) {
            return Response.errorMsg("请在18:00前邀约明天来店的会员！");
        }
        List<InvitationJobPo> invitationJobPos = invitationJobMapper.selectList(Wrappers.<InvitationJobPo>lambdaQuery()
                .eq(InvitationJobPo::getExpectArrTime, invitationJobRequest.getExpectArrTime())
                .eq(InvitationJobPo::getBaCode, invitationJobRequest.getBaCode())
                //测试的时候 就存在了今天打今天的  变成了其余状态
                .in(InvitationJobPo::getStatus, InvitationJobStatusEnum.UN_START.getCode(), InvitationJobStatusEnum.STARTING.getCode(), InvitationJobStatusEnum.END.getCode()));
        if (invitationJobPos != null && invitationJobPos.size() >= invitationConfig.getJobMax()) {
            for (InvitationJobPo invitationJobPo : invitationJobPos) {
                if (!invitationJobPo.getCounterId().equals(invitationJobRequest.getCounterId())) {
                    return Response.errorMsg("您已在其他柜台创建邀约任务！一天最多" + invitationConfig.getJobMax() + "个邀约计划！");
                }
            }
            return Response.errorMsg("一天最多" + invitationConfig.getJobMax() + "个邀约计划！");
        }
        List<InvitationImportPo> invitationImportPos = invitationImportMapper.selectList(Wrappers.<InvitationImportPo>lambdaQuery()
                .ge(InvitationImportPo::getEndTime, LocalDateTime.now()));
        if (invitationImportPos == null || invitationImportPos.isEmpty()) {
            return Response.successMsg("暂无可邀约会员");
        }
        Long jobId = IdGenerator.getShorterSerialNo();
        InvitationJobPo invitationJobPo = InvitationJobPo.builder()
                .jobId(jobId)
                .planNo(invitationImportPos.get(0).getPlanNo())
                .status(InvitationJobStatusEnum.UN_START.getCode())
                .baCode(invitationJobRequest.getBaCode())
                .baName(invitationJobRequest.getBaName())
                .counterId(invitationJobRequest.getCounterId())
                .counterName(invitationJobRequest.getCounterName())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .expectArrTime(invitationJobRequest.getExpectArrTime())
                .invQty(invitationJobRequest.getMemberList().size())
                .acceptQty(0)
                .tbcQty(0)
                .commitCot(0)
                .build();
        List<InvitationTaskPo> invitationTaskPos = buildTask(invitationJobRequest, jobId);
        invitationJobMapper.insert(invitationJobPo);
        invitationTaskMapper.batchInsert(invitationTaskPos);
        //添加任务之后 把添加的会员在可添加列表里面的状态改为已选取
        int update = invitationAvlInviteeMapper.updateByIds(invitationJobRequest.getMemberList(), InvitationAvlInviteeStatusEnum.CHECKED.getCode(), InvitationAvlInviteeStatusEnum.UNCHECK.getCode());
        if (update != invitationJobRequest.getMemberList().size()) {
            throw new BizException("存在用户已被其余任务选中！");
        }
        //填加任务的时候提交到延时队列 延时到指定任务时间当天的 某个时间点
        //当天转钟之前是可以停止的   那么就不能实时提交了   晚上定时提交  找没有停止的任务发起就行
        //2020年12月8日16:50:42  如果是提交的是明天的任务  且在9点到6点之间那么就实时提交
        if (expectArrTime.isEqual(LocalDate.now().plusDays(1))
                && LocalDateTime.now().isAfter(LocalDate.now().atTime(9, 0, 0))
                && LocalDateTime.now().isBefore(LocalDate.now().atTime(18, 0, 0))) {
            //之间提交了
            invitationJobService.pushInvitationTaskForAcc(1);
        }
        return Response.successMsg("操作成功！");
    }

    /**
     * 接收消息
     *
     * @param json
     */
    public String receiveMsg(String json) {
        InvitationTaskMqResponse invitationTaskMqResponse = JSONObject.parseObject(json, InvitationTaskMqResponse.class);
        //刘那边是单个任务确认回来的
        InvitationTaskPo invitationTaskPo = invitationTaskMapper.selectById(invitationTaskMqResponse.getPos_task_id());
        if (invitationTaskPo == null) {
            throw new BizException("不存在的任务！{}" + json);
        }
        return invitationQueryService.getBaPhone(invitationTaskPo.getBaCode());
    }


    /**
     * 更新任务
     *
     * @param json
     * @param baPhone
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public void commitJob(String baPhone, String json) {
        InvitationTaskMqResponse invitationTaskMqResponse = JSONObject.parseObject(json, InvitationTaskMqResponse.class);
        //刘那边是单个任务确认回来的
        InvitationTaskPo invitationTaskPo = invitationTaskMapper.selectById(invitationTaskMqResponse.getPos_task_id());
        if (invitationTaskPo == null) {
            log.error("不存在的任务！" + json);
            return;
        }
        if (!invitationTaskPo.getStatus().equals(InvitationTaskStatusEnum.UN_START.getCode())) {
            log.warn("重复的提交的任务！" + json);
            return;
        }
        //邀约成功的时候给用户发短信
        if (invitationTaskMqResponse.getTask_result_desc().equals(InvitationTaskStatusEnum.ACCEPT.getCode())) {
            MsgerRequestDto smsRequest = MsgerRequestDto.builder()
                    .contact(invitationTaskPo.getMemberPhone())
                    .template(MsgerTplConstant.STD_ACCEPT_INVITATION)
                    .params(Map.ofEntries(
                            Map.entry("inv_counter_name", invitationTaskPo.getCounterName()),
                            Map.entry("inv_date", invitationTaskPo.getExpectArrTime().toString()),
                            Map.entry("inv_time", invitationTaskMqResponse.getTask_result_text())
                            )
                    ).ip(IPUtils.getLocalIP())
                    .build();
            applicationContext.publishEvent(new MsgEvent(this, smsRequest));
        }
        //待确认时候给用户发短信
        if (invitationTaskMqResponse.getTask_result_desc().equals(InvitationTaskStatusEnum.UN_CONFIRMED.getCode())) {
            MsgerRequestDto smsRequest = MsgerRequestDto.builder()
                    .contact(invitationTaskPo.getMemberPhone())
                    .template(MsgerTplConstant.STD_UN_CONFIRMED_INVITATION)
                    .ip(IPUtils.getLocalIP())
                    .build();
            applicationContext.publishEvent(new MsgEvent(this, smsRequest));
        }
        //未接通时候给用户发短信
        if (invitationTaskMqResponse.getTask_result_desc().equals(InvitationTaskStatusEnum.REFUSE.getCode()) && "用户未接".equals(invitationTaskMqResponse.getTask_result_text())) {
            MsgerRequestDto smsRequest = MsgerRequestDto.builder()
                    .contact(invitationTaskPo.getMemberPhone())
                    .template(MsgerTplConstant.STD_UN_ACCESS_INVITATION)
                    .ip(IPUtils.getLocalIP())
                    .build();
            applicationContext.publishEvent(new MsgEvent(this, smsRequest));
        }
        InvitationTaskPo invitationTaskPoNew = new InvitationTaskPo();
        invitationTaskPoNew.setTaskId(invitationTaskPo.getTaskId());
        invitationTaskPoNew.setStatus(invitationTaskMqResponse.getTask_result_desc());
        if (invitationTaskMqResponse.getTask_result_desc() == 5) {
            //2020年11月17日11:38:53  刘那边存在一个5的未知状态  我们这边按2来处理
            invitationTaskPoNew.setStatus(InvitationTaskStatusEnum.REFUSE.getCode());
        }
        invitationTaskPoNew.setInvResult(invitationTaskMqResponse.getTask_result_text());
        invitationTaskPoNew.setUpdateTime(LocalDateTime.now());
        int updateTask = invitationTaskMapper.updateById(invitationTaskPoNew);
        if (updateTask == 0) {
            throw new BizException("更新邀约状态失败！" + invitationTaskMqResponse);
        }
        //加锁
        InvitationJobPo invitationJobPo = invitationTaskMapper.getJobByIdWithLock(invitationTaskPo.getJobId());
        if (invitationTaskMqResponse.getTask_result_desc().equals(InvitationTaskStatusEnum.ACCEPT.getCode())) {
            invitationJobPo.setAcceptQty(invitationJobPo.getAcceptQty() + 1);
        }
        if (invitationTaskMqResponse.getTask_result_desc().equals(InvitationTaskStatusEnum.UN_CONFIRMED.getCode())) {
            invitationJobPo.setTbcQty(invitationJobPo.getTbcQty() + 1);
        }
        //如果出现了自选全部完事了 就更新主表的状态为已经完成
        Integer commitCotLockJob = invitationJobPo.getCommitCot() + 1;
        if (commitCotLockJob.equals(invitationJobPo.getInvQty())) {
            //查询ba的手机号
            invitationJobPo.setStatus(InvitationJobStatusEnum.END.getCode());
            //更新主表的时候就得发短信了
            MsgerRequestDto smsRequest = MsgerRequestDto.builder()
                    //这个是给美导发的
                    .contact(baPhone)
                    .template(MsgerTplConstant.STD_FINISH_INVITATION_JOB)
                    .params(Map.ofEntries(
                            Map.entry("inv_date", invitationTaskPo.getExpectArrTime().toString()),
                            Map.entry("inv_accept_qty", invitationJobPo.getAcceptQty().toString()),
                            Map.entry("inv_uncertain_qty", invitationJobPo.getTbcQty().toString())
                            )
                    ).ip(IPUtils.getLocalIP())
                    .build();
            applicationContext.publishEvent(new MsgEvent(this, smsRequest));
        }
        invitationJobPo.setCommitCot(commitCotLockJob);
        invitationJobPo.setUpdateTime(LocalDateTime.now());
        invitationJobMapper.updateById(invitationJobPo);
        //后面的任务 把没有拨打的会员的选择状态变成未选中
        if (invitationTaskMqResponse.getTask_result_desc().equals(InvitationTaskStatusEnum.STOP.getCode())) {
            int update = invitationAvlInviteeMapper.updateById(InvitationAvlInviteePo.builder()
                    .id(invitationTaskPo.getAvlId()).status(InvitationAvlInviteeStatusEnum.UNCHECK.getCode()).build());
            if (update == 0) {
                log.error("更新邀约状态失败！{}", invitationTaskMqResponse);
            }
        }

    }

    /**
     * 修改邀约任务
     *
     * @param invitationJobChangeRequest
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response updateJob(InvitationJobChangeRequest invitationJobChangeRequest) {
        //修改邀约计划的话  多半是暂停任务
        InvitationJobPo invitationJobPo = invitationJobMapper.selectById(invitationJobChangeRequest.getJobId());
        if (invitationJobPo == null) {
            return Response.errorMsg("不存在的任务！");
        }
        if (invitationJobPo.getStatus().equals(invitationJobChangeRequest.getStatus())) {
            return Response.errorMsg("请勿重复操作！");
        }
        if (invitationJobPo.getStatus().equals(InvitationJobStatusEnum.STARTING.getCode())) {
            return Response.errorMsg("任务正在进行，无法停止！");
        }
        if (invitationJobPo.getStatus().equals(InvitationJobStatusEnum.END.getCode())) {
            return Response.errorMsg("任务已经完成，无法停止！");
        }
        //要把暂停的人给选中去掉
        List<InvitationTaskPo> invitationTaskPos = invitationTaskMapper.selectList(Wrappers.<InvitationTaskPo>lambdaQuery().eq(InvitationTaskPo::getJobId, invitationJobChangeRequest.getJobId()));
        if (invitationTaskPos != null && invitationTaskPos.size() > 0) {
            List<Long> collect = invitationTaskPos.stream().map(InvitationTaskPo::getAvlId).collect(Collectors.toList());
            List<Long> taskCollect = invitationTaskPos.stream().map(InvitationTaskPo::getTaskId).collect(Collectors.toList());
            invitationAvlInviteeMapper.update(null, new UpdateWrapper<InvitationAvlInviteePo>().in("id", collect)
                    .set("status", InvitationAvlInviteeStatusEnum.UNCHECK.getCode()));
            //里面的状态也是已经停止
            invitationTaskMapper.update(null, new UpdateWrapper<InvitationTaskPo>().in("task_id", taskCollect)
                    .set("status", InvitationTaskStatusEnum.STOP.getCode()));
        }
        int update = invitationJobMapper.updateById(InvitationJobPo.builder()
                .jobId(invitationJobChangeRequest.getJobId())
                .status(invitationJobChangeRequest.getStatus())
                .build());
        if (update == 0) {
            return Response.errorMsg("操作失败！");
        }
        return Response.successMsg("操作成功！");
    }

    /**
     * 会员签到
     *
     * @param invitationTaskChangeRequest
     * @return
     */
    @DS(DBConst.MASTER)
    public Response memberSign(InvitationTaskChangeRequest invitationTaskChangeRequest) {
        //修改子项的签到结果 时间
        InvitationTaskPo invitationTaskPo = invitationTaskMapper.selectById(invitationTaskChangeRequest.getTaskId());
        if (invitationTaskPo == null) {
            return Response.errorMsg("不存在的任务！");
        }
        if (invitationTaskPo.getArrStatus().equals(invitationTaskChangeRequest.getStatus())) {
            return Response.errorMsg("请勿重复操作！");
        }
        int update = invitationTaskMapper.updateById(InvitationTaskPo.builder()
                .taskId(invitationTaskChangeRequest.getTaskId())
                .signinTime(LocalDateTime.now())
                .arrStatus(invitationTaskChangeRequest.getStatus())
                .build());
        if (update == 0) {
            return Response.errorMsg("操作失败！");
        }
        return Response.successMsg("操作成功！");
    }

    /**
     * 创建邀约任务子项
     *
     * @param invitationJobRequest
     * @return
     */
    private List<InvitationTaskPo> buildTask(InvitationJobRequest invitationJobRequest, Long jobId) {
        List<InvitationAvlInviteePo> invitationAvlInviteePos = invitationAvlInviteeMapper.selectList(Wrappers.<InvitationAvlInviteePo>lambdaQuery()
                .in(InvitationAvlInviteePo::getId, invitationJobRequest.getMemberList()));
        return invitationAvlInviteePos.stream().map(e ->
                InvitationTaskPo.builder()
                        .taskId(IdGenerator.getLongSerialNo())
                        .planNo(e.getPlanNo())
                        .jobId(jobId)
                        .avlId(e.getId())
                        .arrStatus(InvitationTaskArrStatusEnum.UN_CHECK.getCode())
                        .baCode(invitationJobRequest.getBaCode())
                        .baName(invitationJobRequest.getBaName())
                        .counterId(invitationJobRequest.getCounterId())
                        .counterName(invitationJobRequest.getCounterName())
                        .expectArrTime(invitationJobRequest.getExpectArrTime())
                        .memberBirthday(e.getBirthday())
                        .memberName(e.getMemberName())
                        .memberPhone(e.getMemberPhone())
                        .memberLevel(e.getMemberLevelName())
                        .memberSex(e.getMemberSex())
                        .status(InvitationTaskStatusEnum.UN_START.getCode())
                        .createTime(LocalDateTime.now())
                        .updateTime(LocalDateTime.now())
                        .addInformation(e.getAddInformation())
                        .tag(e.getTag())
                        .recheck(false)
                        .build()
        ).collect(Collectors.toList());
    }

    /**
     * 查询美导下的邀约计划列表
     *
     * @param invitationJobPageRequest
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectPage(InvitationJobPageRequest invitationJobPageRequest) {
        Page<InvitationJobPo> page = new Page<>(invitationJobPageRequest.getPageNumber(), invitationJobPageRequest.getPageSize());
        LambdaQueryWrapper<InvitationJobPo> queryWrapper = Wrappers.<InvitationJobPo>lambdaQuery()
                .eq(InvitationJobPo::getBaCode, invitationJobPageRequest.getBaCode())
                .eq(InvitationJobPo::getCounterId, invitationJobPageRequest.getCounterId())
                .ge(InvitationJobPo::getExpectArrTime, invitationJobPageRequest.getStartTime())
                .lt(InvitationJobPo::getExpectArrTime, invitationJobPageRequest.getEndTime().plusDays(1));
        Page<InvitationJobPo> invitationJobPoPage = invitationJobMapper.selectPage(page, queryWrapper);
        List<InvitationJobPo> invitationJobPos = invitationJobPoPage.getRecords();
        //漏了个红点提示
        Map<Long, Integer> map;
        List<InvitationJobResponse> invitationJobResponses = BeanUtil.copyListProperties(invitationJobPos, InvitationJobResponse.class);
        if (invitationJobPos != null && !invitationJobPos.isEmpty()) {
            List<Long> jobs = invitationJobPos.stream().map(InvitationJobPo::getJobId).collect(Collectors.toList());
            List<InvUnConfirmQtyPo> unConfirmQty = invitationTaskMapper.getUnConfirmQty(jobs);
            map = unConfirmQty.stream().collect(Collectors.toMap(InvUnConfirmQtyPo::getJobId, InvUnConfirmQtyPo::getQty));
            invitationJobResponses.forEach(e -> {
                e.setUnConfirmedQty(map.get(e.getJobId()) == null ? 0 : map.get(e.getJobId()));
            });
        }
        PageVO pageVO = PageVO.<InvitationJobResponse>builder()
                .list(invitationJobResponses)
                .pages(invitationJobPoPage.getPages())
                .total(invitationJobPoPage.getTotal())
                .pageSize(invitationJobPoPage.getSize())
                .pageNum(invitationJobPoPage.getCurrent()).build();
        return Response.success(pageVO);
    }

    /**
     * 会员邀约计划详情
     * 只有有红点的时候才能请求这个
     * 找到当前job下的所有task是带确认的设置为已读
     *
     * @param jobId
     * @return
     */
    @DS(DBConst.MASTER)
    public Response selectItem(Long jobId) {
        List<InvitationTaskPo> invitationTaskPos = invitationTaskMapper.selectList(Wrappers.<InvitationTaskPo>lambdaQuery()
                .eq(InvitationTaskPo::getJobId, jobId));
        //调这个接口  就相当于点进去查看了待处理的   把task里面的未读变成已读状态
        if (invitationTaskPos != null && invitationTaskPos.size() > 0) {
            List<Long> collect = invitationTaskPos.stream()
                    .filter(e -> e.getStatus().equals(InvitationTaskStatusEnum.UN_CONFIRMED.getCode()))
                    .filter(e -> e.getIsRead().equals(false))
                    .map(InvitationTaskPo::getTaskId).collect(Collectors.toList());
            if (collect.size() > 0) {
                invitationTaskMapper.update(null, new UpdateWrapper<InvitationTaskPo>().in("task_id", collect).set("is_read", true));
            }
        }
        List<Long> collect = invitationTaskPos.stream().map(InvitationTaskPo::getTaskId).collect(Collectors.toList());
        List<AttachmentPo> attachmentPos = attachmentMapper.selectList(Wrappers.<AttachmentPo>lambdaQuery()
                .isNotNull(AttachmentPo::getText).in(AttachmentPo::getTaskId, collect));
        List<Long> attTaskIds = attachmentPos.stream().map(AttachmentPo::getTaskId).collect(Collectors.toList());
        //显示签到按钮
        List<InvitationTaskResponse> invitationTaskResponses = BeanUtil.copyListProperties(invitationTaskPos, InvitationTaskResponse.class);
        invitationTaskResponses.forEach(e -> {
            e.setShowStatus(false);
            if (e.getStatus().equals(InvitationTaskStatusEnum.UN_CONFIRMED.getCode())) {
                e.setShowStatus(true);
            }
            e.setShowText(false);
            if (attTaskIds.contains(e.getTaskId())) {
                e.setShowText(true);
            }
        });
        return Response.success(invitationTaskResponses);
    }


    /**
     * 0点之后没有点签到的进行签到处理
     *
     * @return
     */
    @DS(DBConst.MASTER)
    public Response autoSign() {
        //找到当天没有签到的
        List<InvitationTaskPo> invitationTaskPos = invitationTaskMapper.selectList(Wrappers.<InvitationTaskPo>lambdaQuery()
                //间隔一天  因为假设28号任务就是27号打电话  28号签到  29号的定时
                .le(InvitationTaskPo::getExpectArrTime, LocalDate.now().plusDays(-1))
                .eq(InvitationTaskPo::getStatus, InvitationTaskStatusEnum.ACCEPT.getCode())
                .eq(InvitationTaskPo::getArrStatus, InvitationTaskArrStatusEnum.UN_CHECK));
        List<InvitationTaskPo> invitationTaskPosUn = invitationTaskMapper.selectList(Wrappers.<InvitationTaskPo>lambdaQuery()
                //间隔一天  因为假设28号任务就是27号打电话  28号签到  29号的定时
                .le(InvitationTaskPo::getExpectArrTime, LocalDate.now().plusDays(-1))
                .eq(InvitationTaskPo::getStatus, InvitationTaskStatusEnum.UN_CONFIRMED.getCode())
                .eq(InvitationTaskPo::getArrStatus, InvitationTaskArrStatusEnum.UN_CHECK));
        if (invitationTaskPos != null && invitationTaskPos.size() > 0) {
            List<Long> collect = invitationTaskPos.stream().map(InvitationTaskPo::getTaskId).collect(Collectors.toList());
            invitationTaskMapper.update(null, new UpdateWrapper<InvitationTaskPo>().in("task_id", collect)
                    .set("arr_status", InvitationTaskArrStatusEnum.SIGNED.getCode())
                    .set("signin_time", LocalDateTime.now()));
        }
        if (invitationTaskPosUn != null && invitationTaskPosUn.size() > 0) {
            //待确认的
            List<Long> collectUm = invitationTaskPosUn.stream().map(InvitationTaskPo::getTaskId).collect(Collectors.toList());
            invitationTaskMapper.update(null, new UpdateWrapper<InvitationTaskPo>().in("task_id", collectUm)
                    .set("arr_status", InvitationTaskArrStatusEnum.UN_SHOP.getCode())
                    .set("signin_time", LocalDateTime.now()));
        }
        return Response.successMsg("执行自动确认完毕！");
    }

    /**
     * 晚上1点推送还未进行的当天的消息给队列
     *
     * @return
     */
    @DS(DBConst.MASTER)
    @Transactional(rollbackFor = Exception.class)
    public Response pushInvitationTask() {
        //查询job里面 未开始的 并且时间是今天的 28号的任务  就得27号打
        LambdaQueryWrapper<InvitationJobPo> queryWrapper = Wrappers.<InvitationJobPo>lambdaQuery()
                .eq(InvitationJobPo::getExpectArrTime, LocalDate.now().plusDays(1))
                .eq(InvitationJobPo::getStatus, InvitationJobStatusEnum.UN_START.getCode());
        List<InvitationJobPo> invitationJobPos = invitationJobMapper.selectList(queryWrapper);
        if (invitationJobPos == null || invitationJobPos.size() == 0) {
            return Response.successMsg("不存在需要执行的邀约任务");
        }
        List<Long> collect = invitationJobPos.stream().map(InvitationJobPo::getJobId).collect(Collectors.toList());
        //用jobId去找task
        List<InvitationTaskPo> invitationTaskPos = invitationTaskMapper.selectList(Wrappers.<InvitationTaskPo>lambdaQuery().in(InvitationTaskPo::getJobId, collect).orderByDesc(InvitationTaskPo::getJobId));
        for (InvitationTaskPo invitationTaskPo : invitationTaskPos) {
            InvitationTaskMqRequest invitationTaskMqRequest = ObjectUtils.toObject(invitationTaskPo, InvitationTaskMqRequest.class);
            InvitationTaskInformationRequest build = InvitationTaskInformationRequest.builder().dynamic_semantics(invitationTaskPo.getAddInformation()).build();
            invitationTaskMqRequest.setAdd_information(build);
            //几点提交是个问题
            LocalDateTime startTime = LocalDate.now().atTime(9, 0, 0);
            long time = Duration.between(LocalDateTime.now(), startTime).toMillis();
            xdelaySender.send(JSONObject.toJSONString(invitationTaskMqRequest), Integer.parseInt(Long.toString(time)));
        }
        //更新task中的状态为进行中
        invitationJobMapper.update(null, new UpdateWrapper<InvitationJobPo>().in("job_id", collect).set("status", InvitationJobStatusEnum.STARTING.getCode()));
        return Response.successMsg("提交任务完成！");
    }

    /**
     * 手动触发明天的 或者当天的   这个就是测试用的
     *
     * @return
     */
    @DS(DBConst.MASTER)
    public Response pushInvitationTaskForAcc(Integer day) {
        //查询job里面 未开始的 并且时间是今天的
        LambdaQueryWrapper<InvitationJobPo> queryWrapper = Wrappers.<InvitationJobPo>lambdaQuery()
                .eq(InvitationJobPo::getExpectArrTime, LocalDate.now().plusDays(day))
                .eq(InvitationJobPo::getStatus, InvitationJobStatusEnum.UN_START.getCode());
        List<InvitationJobPo> invitationJobPos = invitationJobMapper.selectList(queryWrapper);
        if (invitationJobPos == null || invitationJobPos.size() == 0) {
            return Response.successMsg("不存在需要执行的邀约任务");
        }
        List<Long> collect = invitationJobPos.stream().map(InvitationJobPo::getJobId).collect(Collectors.toList());
        //用jobId去找task
        List<InvitationTaskPo> invitationTaskPos = invitationTaskMapper.selectList(Wrappers.<InvitationTaskPo>lambdaQuery().in(InvitationTaskPo::getJobId, collect));
        for (InvitationTaskPo invitationTaskPo : invitationTaskPos) {
            InvitationTaskMqRequest invitationTaskMqRequest = ObjectUtils.toObject(invitationTaskPo, InvitationTaskMqRequest.class);
            InvitationTaskInformationRequest build = InvitationTaskInformationRequest.builder().dynamic_semantics(invitationTaskPo.getAddInformation()).build();
            invitationTaskMqRequest.setAdd_information(build);
            //几点提交是个问题
            xdelaySender.send(JSONObject.toJSONString(invitationTaskMqRequest), 1000);
        }
        //更新task中的状态为进行中
        invitationJobMapper.update(null, new UpdateWrapper<InvitationJobPo>().in("job_id", collect).set("status", InvitationJobStatusEnum.STARTING.getCode()));
        return Response.successMsg("提交任务完成！");
    }

    /**
     * 查询红点
     *
     * @param counterId
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response showRed(String counterId, String baCode) {
        Integer unConfirmSum = invitationTaskMapper.getUnConfirmSum(counterId, baCode);
        return Response.success(unConfirmSum);
    }


    /**
     * 未跟进的任务数量
     *
     * @param counterId
     * @param baCode
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response unFollowTask(String counterId, String baCode) {
        //判断是否存在正在进行的任务
        List<InvitationImportPo> invitationImportPos = invitationImportMapper.selectList(Wrappers.<InvitationImportPo>lambdaQuery()
                .ge(InvitationImportPo::getEndTime, LocalDateTime.now()).le(InvitationImportPo::getStartTime, LocalDateTime.now()));
        if (invitationImportPos == null || invitationImportPos.isEmpty()) {
            return Response.success(0);
        }
        String planNo = invitationImportPos.get(0).getPlanNo();
        Integer unFollowQty = invitationTaskMapper.getUnFollowQty(counterId, baCode, planNo);
        return Response.success(unFollowQty);
    }


    /**
     * 未跟进的任务列表
     *
     * @param counterId
     * @param baCode
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response unFollowTaskList(String counterId, String baCode) {
        List<InvUnFollowResponse> unFollowResponses = new ArrayList<>();
        //判断是否存在正在进行的任务
        List<InvitationImportPo> invitationImportPos = invitationImportMapper.selectList(Wrappers.<InvitationImportPo>lambdaQuery()
                .ge(InvitationImportPo::getEndTime, LocalDateTime.now()).le(InvitationImportPo::getStartTime, LocalDateTime.now()));
        if (invitationImportPos == null || invitationImportPos.isEmpty()) {
            return Response.success(unFollowResponses);
        }
        String planNo = invitationImportPos.get(0).getPlanNo();
        List<InvitationTaskPo> unFollowList = invitationTaskMapper.getUnFollowList(counterId, baCode, planNo);
        if (unFollowList == null || unFollowList.size() == 0) {
            return Response.success(unFollowResponses);
        }
        //获取文本
        Set<LocalDate> collect = unFollowList.stream().map(InvitationTaskPo::getExpectArrTime).collect(Collectors.toSet());
        Set<Long> taskIds = unFollowList.stream().map(InvitationTaskPo::getTaskId).collect(Collectors.toSet());
        List<AttachmentPo> attachmentPos = attachmentMapper.selectList(Wrappers.<AttachmentPo>lambdaQuery()
                .isNotNull(AttachmentPo::getText).in(AttachmentPo::getTaskId, taskIds));
        List<Long> attTaskIds = attachmentPos.stream().map(AttachmentPo::getTaskId).collect(Collectors.toList());
        for (LocalDate localDate : collect) {
            InvUnFollowResponse build = InvUnFollowResponse.builder().expectArrTime(localDate).build();
            List<InvitationTaskResponse> invitationTaskResponse = new ArrayList<>();
            for (InvitationTaskPo invitationTaskPo : unFollowList) {
                if (invitationTaskPo.getExpectArrTime().equals(localDate)) {
                    InvitationTaskResponse o = ObjectUtils.toObject(invitationTaskPo, InvitationTaskResponse.class);
                    o.setShowText(false);
                    if (attTaskIds.contains(o.getTaskId())) {
                        o.setShowText(true);
                    }
                    invitationTaskResponse.add(o);
                }
            }
            build.setList(invitationTaskResponse);
            unFollowResponses.add(build);
        }
        return Response.success(unFollowResponses);
    }

    /**
     * 获取文字
     *
     * @param taskId
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response getText(Long taskId) {
        AttachmentPo attachmentPo = attachmentMapper.selectById(taskId);
        return Response.success(attachmentPo == null ? null : JSONArray.parse(attachmentPo.getText()));
    }

    /**
     * 7天更新两次失败的通话的人的状态为可选择
     *
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @DS(DBConst.MASTER)
    public Response checkAgain() {
        //找到7天之前是task是失败的会员  变成可选择
        List<InvitationTaskPo> invitationTaskPos = invitationTaskMapper.selectList(Wrappers.<InvitationTaskPo>lambdaQuery()
                .eq(InvitationTaskPo::getStatus, InvitationTaskStatusEnum.REFUSE.getCode())
                .in(InvitationTaskPo::getInvResult, "用户未接", "无法接通", "用户正忙", "正在通话中", "机器人代接")
                .eq(InvitationTaskPo::getRecheck, false)
                .lt(InvitationTaskPo::getUpdateTime, LocalDateTime.now().plusDays(-6)));
        if (invitationTaskPos == null || invitationTaskPos.size() == 0) {
            log.info("不存在需要执行的7天之外未接通的会员");
            return Response.successMsg("不存在需要执行的7天之外未接通的会员");
        }
        List<InvitationImportPo> invitationImportPos = invitationImportMapper.selectList(Wrappers.<InvitationImportPo>lambdaQuery()
                .ge(InvitationImportPo::getEndTime, LocalDateTime.now()).le(InvitationImportPo::getStartTime, LocalDateTime.now()));
        if (invitationImportPos == null || invitationImportPos.isEmpty()) {
            return Response.successMsg("没有进行中的任务！");
        }
        List<Long> taskIds = invitationTaskPos.stream().map(InvitationTaskPo::getTaskId).collect(Collectors.toList());
        invitationTaskMapper.update(null, new UpdateWrapper<InvitationTaskPo>()
                .in("task_id", taskIds)
                .set("recheck", true));
        List<Long> collect = invitationTaskPos.stream().map(InvitationTaskPo::getAvlId).collect(Collectors.toList());
        log.info("任务ID的会员置为可选择！------{}", collect);
        invitationAvlInviteeMapper.update(null, new UpdateWrapper<InvitationAvlInviteePo>()
                .in("id", collect).eq("plan_no", invitationImportPos.get(0).getPlanNo())
                .set("status", InvitationAvlInviteeStatusEnum.UNCHECK.getCode()));

        return null;
    }

    /**
     * 每天5点的时候校验时间间隔很长没有完成的任务
     * 每天6点的时候校验时间间隔很长没有完成的任务
     *
     * @return
     */
    public Response checkData() {
        List<InvitationJobPo> invitationJobPos = invitationJobMapper.selectList(Wrappers.<InvitationJobPo>lambdaQuery()
                .eq(InvitationJobPo::getStatus, InvitationJobStatusEnum.STARTING.getCode())
                .eq(InvitationJobPo::getExpectArrTime, LocalDate.now().plusDays(1))
                .lt(InvitationJobPo::getCreateTime, LocalDateTime.now().plusHours(-1)));
        if (invitationJobPos != null && invitationJobPos.size() > 0) {
            List<Long> collect = invitationJobPos.stream().map(InvitationJobPo::getJobId).collect(Collectors.toList());
            log.error("邀约任务1个小时了还未完成{}", collect);
        }
        return Response.successMsg("执行完毕！");
    }
}
