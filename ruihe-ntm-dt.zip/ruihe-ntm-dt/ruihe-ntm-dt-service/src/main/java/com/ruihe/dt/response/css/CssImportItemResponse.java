package com.ruihe.dt.response.css;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 会员回访记录响应
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "CssImportItemResponse", description = "会员回访记录响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CssImportItemResponse implements Serializable {

    @ApiModelProperty(value = "柜台名称")
    private String counterName;

    @ApiModelProperty(value = "大区")
    private String orgAreaName;

    @ApiModelProperty(value = "ba编码")
    private String baCode;

    @ApiModelProperty(value = "ba名称")
    private String baName;

    @ApiModelProperty(value = "手机号")
    private String memberPhone;

    @ApiModelProperty(value = "名称")
    private String memberName;

    @ApiModelProperty(value = "生日")
    private LocalDate birthday;

    @ApiModelProperty(value = "注册时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime cardIssueTime;

    @ApiModelProperty(value = "等级")
    private String memberLevelName;

    @ApiModelProperty(value = "积分")
    private Integer integralQty;

    @ApiModelProperty(value = "最后一次购买时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime lastestTrxTime;

    @ApiModelProperty(value = "等级变化时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime levelChangeTime;

    @ApiModelProperty(value = "标签")
    private String tag;

}
