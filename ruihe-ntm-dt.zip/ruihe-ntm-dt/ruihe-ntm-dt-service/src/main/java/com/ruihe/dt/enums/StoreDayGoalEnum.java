package com.ruihe.dt.enums;

import org.springframework.util.StringUtils;

/**
 * 单日销售规划中英文枚举
 *
 * @author huangjie
 * @Date:2021年07月07日
 */
public enum StoreDayGoalEnum {
    POSTING_DATE( "记账期间","postingDate"),
    CUR_DATE( "当前日期","curDate"),
    FINANCIAL_MONTH("记账期间_财务期间","financialMonth"),
    COUNTER_ID("柜台id","counterId"),
    COUNTER_NAME("门店名称","counterName"),
    DAILY_TARGET_AMT("门店日业绩目标","dailyTargetAmt"),
    ACTUAL_DAILY_AMT("订单实付金额","actualDailyAmt"),
    ATTRIBUTES("属性","attributes"),
    MOST_SECTORS("大部门","mostSectors"),
    AMALL_SECTORS("小部门","smallSectors"),
    AREA("区域","area"),
    DAILY_JUDGMENT("每日判断","dailyJudgment"),
    WEEK("星期","week");
    private String key;
    private String value;


    StoreDayGoalEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public static StoreDayGoalEnum instance(String key) {
        if (key == null) {
            return null;
        }
        for (StoreDayGoalEnum e : values()) {
            if (e.getKey().equals(key)) {
                return e;
            }
        }
        return null;
    }

    public static StoreDayGoalEnum getString(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (StoreDayGoalEnum e : values()) {
            if (e.getValue().equals(value)) {
                return e;
            }
        }
        return null;
    }
}
