package com.ruihe.dt.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

/**
 * @author fly
 */
@ApiModel(value = "InvitationJobChangeRequest", description = "会员邀约更新任务")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvitationJobChangeRequest {

    @ApiModelProperty(value = "工作id")
    @NotNull(message = "工作id不能为空")
    private Long jobId;

    @ApiModelProperty(value = "状态  0未开始 1进行中 2已完成 3已停止")
    @NotNull(message = "状态不能为空")
    private Integer status;

}
