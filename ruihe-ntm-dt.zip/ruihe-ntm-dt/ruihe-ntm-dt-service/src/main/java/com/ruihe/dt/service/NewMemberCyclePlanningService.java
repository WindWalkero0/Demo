package com.ruihe.dt.service;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.common.constant.CommonConstant;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.exception.BizException;
import com.ruihe.common.pojo.PageVO;
import com.ruihe.common.pojo.context.holder.PosUserContextHolder;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.ObjectUtils;
import com.ruihe.dt.enums.*;
import com.ruihe.dt.mapper.NewMemberCyclePlanningMapper;
import com.ruihe.dt.po.NewMemberCyclePlanningPo;
import com.ruihe.dt.request.NewMemberCyclePlanningPageRequest;
import com.ruihe.dt.response.ExcelResponse;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;
import lombok.extern.slf4j.Slf4j;
import net.bytebuddy.implementation.bytecode.Throw;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.util.stream.Collectors.toList;

@Slf4j
@Service
public class NewMemberCyclePlanningService {
    @Value("${guanbi.domain}")
    private String domain;
    @Value("${guanbi.email}")
    private String email;
    @Value("${guanbi.password}")
    private String password;
    @Value("${guanbi.login_url}")
    private String loginUrl;
    @Value("${guanbi.download_token_url}")
    private String downloadTokenUrl;
    @Value("${guanbi.download_url}")
    private String downloadUrl;
    @Value("${guanbi.csv_url}")
    private String csvUrl;


    private static final List<String> pros = List.of("curDate", "counterId", "counterName", "baCode", "baName", "memberId", "currentCycle", "memberName", "memberPhone", "signupDate", "signupMemberLevel", "currentMemberLevel", "firstOrderAmt", "nursingLimitOf7days", "nursingBasicOf7days", "qtyOf7daysNursed", "saleLimitOf7days", "saleBasicOf7days", "qtyOf7daysSale", "statusOf7days", "nursingLimitOf21days", "nursingBasicOf21days", "qtyOf21daysNursed", "saleLimitOf21days", "saleBasicOf21days", "qtyOf21daysSale", "statusOf21days", "nursingLimitOf60days", "nursingBasicOf60days", "qtyOf60daysNursed", "saleLimitOf60days", "saleBasicOf60days", "qtyOf60daysSale", "statusOf60days", "nursingLimitOf90days", "nursingBasicOf90days", "qtyOf90daysNursed", "saleLimitOf90days", "saleBasicOf90days", "qtyOf90daysSale", "statusOf90days", "salesTargetOf90days", "salesAmtOf90days", "remainingAmtOf90days", "deadline", "remainingDays");


    @Autowired
    private NewMemberCyclePlanningMapper newMemberCyclePlanningMapper;

    @Autowired
    private MonthlyPlanService monthlyPlanService;

    /**
     * ;通过调用观远接口获取新会员培育周期的数据
     *
     * @return
     */
    @DS(DBConst.MASTER)
    public Response downloadByRest() {
        String json = buildRequest();
        //调用观远登录接口,返回token调用其他接口
//        TcpClient tcpClient = TcpClient
//                .create()
//                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5); //5毫秒

        String getLoginToken = WebClient.builder()
//                .clientConnector(new ReactorClientHttpConnector(HttpClient.from(tcpClient)))
                .baseUrl(loginUrl)
                .build()
                .post()
                .header("ContentType", "application/json; charset=utf-8")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .block()
                .bodyToMono(String.class)
                .block();
        //先获取下载数据的控制token

        String getDownloadToken = WebClient.builder()
//                .clientConnector(new ReactorClientHttpConnector(HttpClient.from(tcpClient)))
                .baseUrl(downloadTokenUrl)
                .build()
                .get()
                .header("token", JSON.parseObject(getLoginToken).getJSONObject("response").getString("token"))
                .header("ContentType", "application/json")
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .block()
                .bodyToMono(String.class)
                .block();

        //下载所需要的当天新会员数据
        String downLoadNewMemberData = WebClient.builder()
//                .clientConnector(new ReactorClientHttpConnector(HttpClient.from(tcpClient)))
                .baseUrl(downloadUrl + JSON.parseObject(getDownloadToken).getString("dataFetchToken"))
                .codecs(config -> config.defaultCodecs().maxInMemorySize(16 * 1024 * 1024))
                .build()
                .post()
                .header("ContentType", "application/json")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{}")
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .block()
                .bodyToMono(String.class)
                .block();
        JSONObject jsonObject = JSONObject.parseObject(downLoadNewMemberData);
        if (!CommonConstant.OK.equalsIgnoreCase(jsonObject.getString("result"))) {
            return Response.errorMsg("获取观远数据失败!");
        }
        List<NewMemberCyclePlanningPo> newMemberCyclePlanningList = jsonObject.getJSONObject("response")
                .getJSONArray("data")
                .stream()
                .map(e -> {
                    JSONArray array = (JSONArray) e;
                    Map<String, String> collect = IntStream.range(0, pros.size()).boxed().map(idx ->
                            Map.entry(pros.get(idx), StringUtils.defaultString((String) array.get(idx)))
                    ).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
                    JSONObject tempJson = new JSONObject();
                    tempJson.putAll(collect);
                    return tempJson.toJavaObject(NewMemberCyclePlanningPo.class);
                }).collect(Collectors.toList());
        //批量插入
        this.batchInsertNewMember(newMemberCyclePlanningList);
        return Response.success();
    }

    /**
     * ;通过共享文件获取新会员培育周期的数据
     *
     * @return
     */
    @DS(DBConst.MASTER)
    public Response downloadByCsv() {
        List<NewMemberCyclePlanningPo> newMemberCyclePlanningList = new ArrayList<>();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new SmbFileInputStream(new SmbFile(csvUrl))), 30 * 1024 * 1024);
            String line;
            List<ExcelResponse> list = new ArrayList<>();
            Boolean boo = true;
            while ((line = bufferedReader.readLine()) != null) {
                String[] row = line.split(CommonConstant.COMMA);
                if (boo) {
                    List<String> headerList = Arrays.asList(row);
                    for (int j = 0; j < headerList.size(); j++) {
                        ExcelResponse excalResponse = ExcelResponse.builder()//Excel
                                .chineseHeader(headerList.get(j))
                                .englishHeader(NewMemberCyclePlanEnum.instance(headerList.get(j).replace("\uFEFF", "")).getValue())
                                .subscript(j)
                                .build();
                        list.add(excalResponse);
                    }
                    boo = false;
                    continue;
                }
                Map<String, String> collect = monthlyPlanService.getHeadList(list, row, pros);
                JSONObject tempJson = new JSONObject();
                tempJson.putAll(collect);
                NewMemberCyclePlanningPo newMemberCyclePlanningPo = tempJson.toJavaObject(NewMemberCyclePlanningPo.class);
                newMemberCyclePlanningList.add(newMemberCyclePlanningPo);
            }
            bufferedReader.close();
        } catch (Exception e) {
            log.error("NewMemberCyclePlanningService.downloadByCsv.getBiDate.error", e);
            return Response.errorMsg("新会员培育周期数据下载失败!");
        }
        //批量插入
        this.batchInsertNewMember(newMemberCyclePlanningList);
        return Response.success();
    }

    /**
     * ;批量插入新会员培育计划数据(5000条/每次)
     *
     * @param newMemberList
     * @return
     */
    public void batchInsertNewMember(List<NewMemberCyclePlanningPo> newMemberList) {
        int pageSize = 5000, pageIndex = 0;
        while (true) {
            List<?> tempList = monthlyPlanService.getAllList(newMemberList,pageSize,pageIndex );
            if (tempList == null) {
                return;
            }
            int res = newMemberCyclePlanningMapper.batchInsert(tempList);
            if (res != tempList.size()) {
                throw new BizException("新会员培育周期批量插入失败");
            }
            pageIndex++;
        }
    }


    /**
     * 新会员培育计划数据分页查询
     *
     * @param request
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response pageQuery(NewMemberCyclePlanningPageRequest request) {
        //分页
        Page<NewMemberCyclePlanningPo> page = new Page<>(request.getPageNumber(), request.getPageSize());
        LambdaQueryWrapper<NewMemberCyclePlanningPo> queryWrapper = Wrappers.<NewMemberCyclePlanningPo>lambdaQuery()
                .eq(NewMemberCyclePlanningPo::getCurDate, LocalDate.now().toString());
        String counterId = PosUserContextHolder.get().getCounter().getCounterId();
        queryWrapper.eq(NewMemberCyclePlanningPo::getCounterId, counterId);
        //通过手机号码或者用户名查询
        if (StringUtils.isNotBlank(request.getMemberNameOrPhone())) {
            queryWrapper.and(wrapper ->
                    wrapper.eq(NewMemberCyclePlanningPo::getMemberName, request.getMemberNameOrPhone().trim())
                            .or()
                            .eq(NewMemberCyclePlanningPo::getMemberPhone, request.getMemberNameOrPhone().trim()));
        }
        //当前周期
        if (request.getCurrentCycle() != null) {
            NewMemberCycleEnum newMemberCycleEnum = NewMemberCycleEnum.instance(request.getCurrentCycle());
            if (newMemberCycleEnum == null) {
                return Response.errorMsg("参数错误");
            }
            queryWrapper.eq(NewMemberCyclePlanningPo::getCurrentCycle, newMemberCycleEnum.getValue());
        }
        //首单金额
        if (request.getFirstOrderAmt() != null) {
            FirstOrderAmtEnum firstOrderAmtEnum = FirstOrderAmtEnum.instance(request.getFirstOrderAmt());
            if (firstOrderAmtEnum == null) {
                return Response.errorMsg("参数错误");
            }
            //greate then
            queryWrapper.gt(NewMemberCyclePlanningPo::getFirstOrderAmt, firstOrderAmtEnum.getMin());
            //less equal
            queryWrapper.le(NewMemberCyclePlanningPo::getFirstOrderAmt, firstOrderAmtEnum.getMax());
        }
        //入会等级
        if (request.getSignupMemberLevel() != null) {
            SignupMemberLevelWEnum signupMemberLevelWEnum = SignupMemberLevelWEnum.instance(request.getSignupMemberLevel());
            if (signupMemberLevelWEnum == null) {
                return Response.errorMsg("参数错误");
            }
            queryWrapper.eq(NewMemberCyclePlanningPo::getSignupMemberLevel, signupMemberLevelWEnum.getValue());
        }

        //如果完成状态不等于空,通过当前周期来确定完成状态
        if (request.getCompleteStatus() != null) {
            CompleteStatusEnum completeStatusEnum = CompleteStatusEnum.instance(request.getCompleteStatus());
            if (completeStatusEnum == null) {
                return Response.errorMsg("参数错误");
            }
            if (NewMemberCycleEnum.SEVEN_DAYS.getKey().equals(request.getCurrentCycle())) {
                queryWrapper.eq(NewMemberCyclePlanningPo::getStatusOf7days, completeStatusEnum.getValue());
            } else if (NewMemberCycleEnum.TWENTY_ONE_DAYS.getKey().equals(request.getCurrentCycle())) {
                queryWrapper.eq(NewMemberCyclePlanningPo::getStatusOf21days, completeStatusEnum.getValue());
            } else if (NewMemberCycleEnum.SIXTY_DAYS.getKey().equals(request.getCurrentCycle())) {
                queryWrapper.eq(NewMemberCyclePlanningPo::getStatusOf60days, completeStatusEnum.getValue());
            } else if (NewMemberCycleEnum.NINETY_DAYS.getKey().equals(request.getCurrentCycle())) {
                queryWrapper.eq(NewMemberCyclePlanningPo::getStatusOf90days, completeStatusEnum.getValue());
            }
        }

        //查询当前周期的新会员培育信息
        Page<NewMemberCyclePlanningPo> newMemberCyclePlanningPoPage = newMemberCyclePlanningMapper.selectPage(page, queryWrapper);
        List<NewMemberCyclePlanningPo> newMemberCyclePlanningPoList = newMemberCyclePlanningPoPage.getRecords();
        if (newMemberCyclePlanningPoList.isEmpty()) {
            return Response.successMsg("暂无数据!");
        }
        //返回前端1
        PageVO pageVo = PageVO.<NewMemberCyclePlanningPo>builder()
                .list(ObjectUtils.toList(newMemberCyclePlanningPoList, NewMemberCyclePlanningPo.class))
                .total(newMemberCyclePlanningPoPage.getTotal())
                .pageNum(newMemberCyclePlanningPoPage.getCurrent())
                .pageSize(newMemberCyclePlanningPoPage.getSize())
                .pages(newMemberCyclePlanningPoPage.getPages()).build();
        return Response.success(pageVo);
    }

    private String buildRequest() {
        byte[] bytes = password.getBytes();
        //Base64 加密
        String encoded = Base64.getEncoder().encodeToString(bytes);
        JSONObject json = new JSONObject();
        //在观远系统中的域名，非网址的域名
        json.put("domain", domain);
        // 登录的邮箱
        json.put("email", email);
        //原始密码经过Base64编码后的字符串
        json.put("password", encoded);
        return json.toJSONString();
    }
    /**
     * ;通过共享文件获取新会员培育周期的数据
     *
     * @return
     */
    public Response testXxlJob() {
        log.error("xxljob测试打印!!!!");
        return Response.success();
    }

}
