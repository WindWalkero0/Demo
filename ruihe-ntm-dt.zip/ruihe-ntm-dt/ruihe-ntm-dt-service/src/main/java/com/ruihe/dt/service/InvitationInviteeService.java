package com.ruihe.dt.service;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ruihe.dt.invitation.InvitationAvlInviteeStatusEnum;
import com.ruihe.dt.mapper.*;
import com.ruihe.dt.po.AttachmentPo;
import com.ruihe.dt.po.InvitationAvlInviteePo;
import com.ruihe.dt.po.InvitationImportPo;
import com.ruihe.dt.po.InvitationTaskPo;
import com.ruihe.dt.request.InvitationInviteePageRequest;
import com.ruihe.dt.response.InvitationAvlInviteeResponse;
import com.ruihe.common.constant.DBConst;
import com.ruihe.common.response.Response;
import com.ruihe.common.utils.BeanUtil;
import com.ruihe.common.pojo.PageVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author fly
 * @date 2020年11月6日14:03:42
 */
@Slf4j
@Service
public class InvitationInviteeService {

    @Autowired
    private InvitationImportMapper invitationImportMapper;

    @Autowired
    private InvitationAvlInviteeMapper invitationAvlInviteeMapper;

    @Autowired
    private InvitationJobMapper invitationJobMapper;

    @Autowired
    private InvitationTaskMapper invitationTaskMapper;

    @Autowired
    private AttachmentMapper attachmentMapper;

    /**
     * 分页查询 ba下的邀约计划
     *
     * @param invitationInviteePageRequest
     * @return
     */
    @DS(DBConst.SLAVE)
    public Response selectAvlPage(InvitationInviteePageRequest invitationInviteePageRequest) {
        //获取当前没有过期的plan
        List<InvitationImportPo> invitationImportPos = invitationImportMapper.selectList(Wrappers.<InvitationImportPo>lambdaQuery()
                .ge(InvitationImportPo::getEndTime, LocalDateTime.now()).le(InvitationImportPo::getStartTime, LocalDateTime.now()));
        if (invitationImportPos == null || invitationImportPos.isEmpty()) {
            return Response.successMsg("暂无可邀约会员");
        }
        Page<InvitationAvlInviteePo> page = new Page<>(invitationInviteePageRequest.getPageNumber(), invitationInviteePageRequest.getPageSize());
        LambdaQueryWrapper<InvitationAvlInviteePo> queryWrapper = Wrappers.<InvitationAvlInviteePo>lambdaQuery()
                .eq(InvitationAvlInviteePo::getStatus, InvitationAvlInviteeStatusEnum.UNCHECK.getCode())
                //2021年1月25日10:49:03 都是店长操作不需要精确到美导了
                //2021年1月27日11:02:36 先还原
                //2021年3月18日15:59:13 都是店长操作不需要精确到美导了
//                .eq(InvitationAvlInviteePo::getBaCode, invitationInviteePageRequest.getBaCode())
                .eq(InvitationAvlInviteePo::getCounterId, invitationInviteePageRequest.getCounterId())
                .eq(InvitationAvlInviteePo::getPlanNo, invitationImportPos.get(0).getPlanNo())
                .orderByDesc(InvitationAvlInviteePo::getId);
        if (invitationInviteePageRequest.getArrStartTime() != null && invitationInviteePageRequest.getArrEndTime() != null) {
            queryWrapper.ge(InvitationAvlInviteePo::getLastestArrTime, invitationInviteePageRequest.getArrStartTime())
                    .lt(InvitationAvlInviteePo::getLastestArrTime, invitationInviteePageRequest.getArrEndTime().plusDays(1));
        }
        if (invitationInviteePageRequest.getInvStartTime() != null && invitationInviteePageRequest.getInvEndTime() != null) {
            queryWrapper.ge(InvitationAvlInviteePo::getLastestInvTime, invitationInviteePageRequest.getInvStartTime())
                    .lt(InvitationAvlInviteePo::getLastestInvTime, invitationInviteePageRequest.getInvEndTime().plusDays(1));
        }
        if (invitationInviteePageRequest.getMemberName() != null && !"".equals(invitationInviteePageRequest.getMemberName())) {
            //mybatis or的写法
            queryWrapper.and(wrapper -> wrapper.like(InvitationAvlInviteePo::getMemberName, invitationInviteePageRequest.getMemberName()).or().eq(InvitationAvlInviteePo::getMemberPhone, invitationInviteePageRequest.getMemberName()));
        }
        if (invitationInviteePageRequest.getMemberLevelNames() != null && invitationInviteePageRequest.getMemberLevelNames().size() > 0) {
            queryWrapper.in(InvitationAvlInviteePo::getMemberLevelName, invitationInviteePageRequest.getMemberLevelNames());
        }
        //已经选中的查不到
        if (invitationInviteePageRequest.getMemberCheckedIds() != null && invitationInviteePageRequest.getMemberCheckedIds().size() > 0) {
            queryWrapper.notIn(InvitationAvlInviteePo::getId, invitationInviteePageRequest.getMemberCheckedIds());
        }
        Page<InvitationAvlInviteePo> invitationAvlInviteePoPage = invitationAvlInviteeMapper.selectPage(page, queryWrapper);
        List<InvitationAvlInviteePo> invitationAvlInviteePos = invitationAvlInviteePoPage.getRecords();
        List<InvitationAvlInviteeResponse> returnList = new ArrayList<>();
        //实时邀约结果
        //不能按task来   最近一次的到店  和最近一次的打电话是两组
        if (invitationAvlInviteePos != null && invitationAvlInviteePos.size() > 0) {
            List<String> collect1 = invitationAvlInviteePos.stream().map(InvitationAvlInviteePo::getMemberPhone).collect(Collectors.toList());
            List<InvitationTaskPo> invitationTaskPos = invitationTaskMapper.selectLastMemberTask(collect1);
            List<InvitationTaskPo> invitationTaskPoSignS = invitationTaskMapper.selectLastMemberTaskSign(collect1);
            Map<String, InvitationTaskPo> collect;
            Map<String, InvitationTaskPo> signCollect;
            Map<String, InvitationTaskPo> finalCollect = null;
            Map<String, InvitationTaskPo> finalSignCollect = null;
            List<Long> attTaskIds = null;
            if (invitationTaskPos != null && !invitationTaskPos.isEmpty()) {
                //获取文本列表填充
                Set<Long> taskSet = invitationTaskPos.stream().map(InvitationTaskPo::getTaskId).collect(Collectors.toSet());
                List<AttachmentPo> attachmentPos = attachmentMapper.selectList(Wrappers.<AttachmentPo>lambdaQuery()
                        .isNotNull(AttachmentPo::getText).in(AttachmentPo::getTaskId, taskSet));
                attTaskIds = attachmentPos.stream().map(AttachmentPo::getTaskId).collect(Collectors.toList());
                collect = invitationTaskPos.stream().collect(Collectors.toMap(InvitationTaskPo::getMemberPhone, e -> e));
                signCollect = invitationTaskPoSignS.stream().collect(Collectors.toMap(InvitationTaskPo::getMemberPhone, e -> e));
                finalCollect = collect;
                finalSignCollect = signCollect;
            }
            Map<String, InvitationTaskPo> finalCollect1 = finalCollect;
            Map<String, InvitationTaskPo> finalSignCollect1 = finalSignCollect;
            List<Long> finalAttTaskIds = attTaskIds;
            invitationAvlInviteePos.forEach(e -> {
                InvitationTaskPo invitationTaskPo = finalCollect1 == null ? null : finalCollect1.get(e.getMemberPhone());
                InvitationTaskPo invitationTaskSignPo = finalSignCollect1 == null ? null : finalSignCollect1.get(e.getMemberPhone());
                e.setInvResult(invitationTaskPo == null ? null : invitationTaskPo.getInvResult());
                e.setLastestArrStatus(invitationTaskPo == null ? null : invitationTaskPo.getStatus());
                e.setLastestArrTime(invitationTaskSignPo == null ? null : invitationTaskSignPo.getSigninTime());
                e.setLastestInvTime(invitationTaskPo == null ? null : invitationTaskPo.getUpdateTime());
                InvitationAvlInviteeResponse invitationAvlInviteeResponse = BeanUtil.copyProperties(e, InvitationAvlInviteeResponse.class);
                invitationAvlInviteeResponse.setShowText(false);
                if (invitationTaskPo != null && finalAttTaskIds.contains(invitationTaskPo.getTaskId())) {
                    invitationAvlInviteeResponse.setShowText(true);
                    invitationAvlInviteeResponse.setTaskId(invitationTaskPo.getTaskId());
                }
                returnList.add(invitationAvlInviteeResponse);
            });
        }
        PageVO pageVO = PageVO.<InvitationAvlInviteeResponse>builder()
                .list(returnList)
                .pages(invitationAvlInviteePoPage.getPages())
                .total(invitationAvlInviteePoPage.getTotal())
                .pageSize(invitationAvlInviteePoPage.getSize())
                .pageNum(invitationAvlInviteePoPage.getCurrent()).build();
        return Response.success(pageVO);
    }

    /**
     * 获取剩余可邀约人数
     *
     * @param counterId
     * @return
     */
    public Response selectCount(String counterId) {
        List<InvitationImportPo> invitationImportPos = invitationImportMapper.selectList(Wrappers.<InvitationImportPo>lambdaQuery()
                .ge(InvitationImportPo::getEndTime, LocalDateTime.now()).le(InvitationImportPo::getStartTime, LocalDateTime.now()));
        if (invitationImportPos == null || invitationImportPos.isEmpty()) {
            return Response.success(0);
        }
        LambdaQueryWrapper<InvitationAvlInviteePo> queryWrapper = Wrappers.<InvitationAvlInviteePo>lambdaQuery()
                .eq(InvitationAvlInviteePo::getStatus, InvitationAvlInviteeStatusEnum.UNCHECK.getCode())
                .eq(InvitationAvlInviteePo::getCounterId, counterId)
                .eq(InvitationAvlInviteePo::getPlanNo, invitationImportPos.get(0).getPlanNo())
                .orderByDesc(InvitationAvlInviteePo::getId);
        Integer count = invitationAvlInviteeMapper.selectCount(queryWrapper);
        return Response.success(count);
    }

    /**
     * 获取截止日期
     *
     * @return
     */
    public Response selectExpiryDate() {
        List<InvitationImportPo> invitationImportPos = invitationImportMapper.selectList(Wrappers.<InvitationImportPo>lambdaQuery()
                .ge(InvitationImportPo::getEndTime, LocalDateTime.now()).le(InvitationImportPo::getStartTime, LocalDateTime.now()));
        if (invitationImportPos == null || invitationImportPos.isEmpty()) {
            return Response.success("");
        }
        String expiryDate = invitationImportPos.get(0).getEndTime().toString().substring(0, 10);
        return Response.success(expiryDate);
    }
}
