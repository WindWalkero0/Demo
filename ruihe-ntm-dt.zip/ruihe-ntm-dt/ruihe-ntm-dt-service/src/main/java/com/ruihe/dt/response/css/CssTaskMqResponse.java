package com.ruihe.dt.response.css;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 会员回访记录mq响应
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@ApiModel(value = "CssTaskMqResponse", description = "会员回访记录mq响应")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CssTaskMqResponse implements Serializable {

    @ApiModelProperty(value = "任务ID")
    private Long pos_task_id;

    @ApiModelProperty(value = "状态 0未开始 1接受 2拒绝 3待确认 4终止")
    private Integer task_result_desc;

    @ApiModelProperty(value = "录音地址")
    private String voice_url;

    @ApiModelProperty(value = "描述")
    private List<CssTaskEvalResponse> dialog_text;
}
