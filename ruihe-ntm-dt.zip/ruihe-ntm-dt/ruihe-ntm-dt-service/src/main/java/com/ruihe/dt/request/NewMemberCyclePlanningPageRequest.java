package com.ruihe.dt.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@ApiModel(value = "NewMemberCyclePlanningPageRequest", description = "分页新会员周期规划查询")
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class NewMemberCyclePlanningPageRequest {

    @ApiModelProperty(value = "当前周期,7/21/60/90")
    @NotNull(message = "当前周期不能为空")
    private Integer currentCycle;

    @ApiModelProperty(value = "会员信息")
    private String memberNameOrPhone;

    @ApiModelProperty(value = "首单金额,1:800以下,2:800~1800,3:1800~2800,4:2800~5000,5:5000+")
    private Integer firstOrderAmt;

    @ApiModelProperty(value = "入会等级,1:体验会员,2:花粉会员,3:玫瑰会员,4:茉莉会员,5:百合会员,6:牡丹会员")
    private Integer signupMemberLevel;

    @ApiModelProperty(value = "完成状态,1未完成,2完成底线,3完成基础")
    private Integer completeStatus;

    @NotNull(message = "页数不能为空")
    @ApiModelProperty(value = "每页显示数量")
    private Integer pageSize;

    @NotNull(message = "页码不能为空")
    @ApiModelProperty(value = "页码")
    private Integer pageNumber;
}
