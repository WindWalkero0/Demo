package com.ruihe.dt.invitation;

import org.springframework.util.StringUtils;

/**
 * 附加信息类型
 *
 * @author fly
 */
public enum AttachmentAdditionalTypeEnum {

    TEXT(1, "录音文本"),
    URL(2, "录音地址"),
    ;

    private Integer code;
    private String msg;


    AttachmentAdditionalTypeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static AttachmentAdditionalTypeEnum instance(String code) {
        if (code == null) {
            return null;
        }
        for (AttachmentAdditionalTypeEnum e : values()) {
            if (e.getCode().equals(code)) {
                return e;
            }
        }
        return null;
    }

    public static AttachmentAdditionalTypeEnum getMsg(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        for (AttachmentAdditionalTypeEnum e : values()) {
            if (e.getMsg().equals(value)) {
                return e;
            }
        }
        return null;
    }

}
