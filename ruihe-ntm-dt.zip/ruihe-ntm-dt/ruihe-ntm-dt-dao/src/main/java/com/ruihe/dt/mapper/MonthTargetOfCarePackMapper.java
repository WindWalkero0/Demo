package com.ruihe.dt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.MonthTargetOfCarePackPo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MonthTargetOfCarePackMapper extends BaseMapper<MonthTargetOfCarePackPo> {

    /**
     * 批量插入门店护理会员月度目标
     *
     * @param monthTargetOfCarePackPos
     * @return
     */
    int batchInsert(List<?> monthTargetOfCarePackPos);
}
