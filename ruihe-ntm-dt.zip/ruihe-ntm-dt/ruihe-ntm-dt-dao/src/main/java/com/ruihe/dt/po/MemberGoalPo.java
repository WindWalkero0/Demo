package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author huangjie
 * @description
 * @date 2021年07月15日14:56:52
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_member_goal")
public class MemberGoalPo implements Serializable {
    /**
     * 当前日期
     */
    private String curDate;

    /**
     * 财务月
     */
    private String financialMonth;

    /**
     * 柜台编号
     */
    private String counterId;

    /**
     * 柜台名称
     */
    private String counterName;

    /**
     * 经营新会员购买金额占比目标
     */
    private String newPercentageGoal;

    /**
     * 经营新会员购买金额占比完成情况
     */
    private String newPercentageCompletion;

    /**
     * 经营新会员人均消费目标
     */
    private String newConsumptionGoal;

    /**
     * 经营新会员人均消费完成情况
     */
    private String newConsumptionCompletion;

    /**
     * 经营新会员客单价目标
     */
    private String newUnivalentGoal;

    /**
     * 经营新会员客单价完成情况
     */
    private String newUnivalentCompletion;

    /**
     * 经营新会员购买金额业绩目标
     */
    private String newPerformanceGoal;

    /**
     * 经营新会员金额完成情况
     */
    private String newPerformanceCompletion;

    /**
     * 经营新会员购买人数目标
     */
    private String newNumGoal;

    /**
     * 经营新会员人数完成情况
     */
    private String newNumCompletion;

    /**
     * 经营新会员购买人数同步率
     */
    private String newNumSync;

    /**
     * 经营新会员订单数目标
     */
    private String newOrderGoal;

    /**
     * 经营新会员订单数完成情况
     */
    private String newOrderCompletion;

    /**
     * 老会员购买金额占比目标
     */
    private String oldPercentageGoal;

    /**
     * 老会员购买金额占比完成情况
     */
    private String oldPercentageCompletion;

    /**
     * 老会员购买金额业绩目标
     */
    private String oldPerformanceGoal;

    /**
     * 老会员金额完成情况
     */
    private String oldPerformanceCompletion;

    /**
     * 老会员购买人数目标
     */
    private String oldNumGoal;

    /**
     * 老会员人数完成情况
     */
    private String oldNumCompletion;

    /**
     * 老会员购买人数同步率
     */
    private String oldNumSync;

    /**
     * 老会员人均消费目标
     */
    private String oldConsumptionGoal;

    /**
     * 老会员人均消费完成情况
     */
    private String oldConsumptionCompletion;

    /**
     * 老会员订单数目标
     */
    private String oldOrderGoal;

    /**
     * 老会员订单数完成情况
     */
    private String oldOrderCompletion;

    /**
     * 老会员客单价目标
     */
    private String oldUnivalentGoal;

    /**
     * 老会员客单价完成情况
     */
    private String oldUnivalentCompletion;


}
