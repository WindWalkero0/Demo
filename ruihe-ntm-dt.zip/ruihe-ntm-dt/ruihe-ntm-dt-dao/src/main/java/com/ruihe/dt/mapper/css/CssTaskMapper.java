package com.ruihe.dt.mapper.css;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.CssUnTaskQtyPo;
import com.ruihe.dt.po.css.CssTaskPo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * AI回访任务子表
 *
 * @author fly
 */
@Mapper
public interface CssTaskMapper extends BaseMapper<CssTaskPo> {

    /**
     * 批量插入
     *
     * @param cssTaskPos
     * @return
     */
    int batchInsert(List<CssTaskPo> cssTaskPos);


    /**
     * 获取未执行的数量来判断任务开始没
     *
     * @param planNo
     * @return
     */
    List<CssUnTaskQtyPo> getUnTaskQty(List<String> planNo);

    /**
     * 获取全量
     *
     * @param planNo
     * @return
     */
    List<CssUnTaskQtyPo> getTaskQty(List<String> planNo);
}
