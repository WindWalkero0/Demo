package com.ruihe.dt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.InvitationImportItemPo;
import com.ruihe.dt.po.query.InvitationImportItemDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员邀约子表
 *
 * @author fly
 */
@Mapper
public interface InvitationImportItemMapper extends BaseMapper<InvitationImportItemPo> {


    /**
     * 批量导入
     *
     * @param list
     * @return
     */
    int batchInsert(@Param("list") List<InvitationImportItemPo> list);


    /**
     * 邀约导入的排重后列表
     * 
     * @param list in 条件
     * @return
     */
    List<InvitationImportItemDTO> checkRepeatList(@Param("itemList") List<InvitationImportItemDTO> list);
}
