package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author fly
 * @description
 * @date 2020年10月28日10:30:52
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_attachment")
public class AttachmentPo implements Serializable {

    /**
     * 计划编号
     */
    @TableId(value = "task_id")
    private Long taskId;

    /**
     * 任务类型  1 邀约 2 回访
     */
    private Integer taskType;

    /**
     * 文字描述
     */
    private String text;

    /**
     * 录音地址
     */
    private String url;

    /**
     * 领取时间
     */
    private LocalDateTime createTime;

    /**
     * 激活时间
     */
    private LocalDateTime updateTime;

}
