package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author 梁远
 * @Description 用户信息表
 * @create 2019-06-13 10:35
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_employee")
public class UserInformation implements Serializable {

    /**
     * 用户ID
     */
    @TableId(value = "emp_id", type = IdType.NONE)
    private String empId;

    /**
     * 用户账号
     */
    private String account;

    /**
     * 用户账号状态
     */
    private Integer accountStatus;

    /**
     * 所属品牌
     */
    private String brandName;

    /**
     * 姓名
     */
    private String name;

    /**
     * 岗位代码
     */
    private String positionCode;

    /**
     * 岗位名称
     */
    private String positionName;

    /**
     * 联系电话
     */
    @TableField(whereStrategy = FieldStrategy.IGNORED, insertStrategy = FieldStrategy.IGNORED, updateStrategy = FieldStrategy.IGNORED)
    private String telephone;

    /**
     * 部门代码
     */
    private String deptCode;

    /**
     * 部门名称
     */
    private String deptName;

    /**
     * 部门类型
     */
    private Integer deptType;

    /**
     * 手机号码
     */
    private String phoneNo;

    /**
     * email
     */
    @TableField(whereStrategy = FieldStrategy.IGNORED, insertStrategy = FieldStrategy.IGNORED, updateStrategy = FieldStrategy.IGNORED)
    private String email;

    /**
     * 身份证
     */
    private String idCard;

    /**
     * 状态
     */
    private Integer status;

    /**
     * 最近一次入职日期
     */
    @TableField(whereStrategy = FieldStrategy.IGNORED, insertStrategy = FieldStrategy.IGNORED, updateStrategy = FieldStrategy.IGNORED)
    private LocalDate recentEntryTime;

    /**
     * 最近一次离职日期
     */
    @TableField(whereStrategy = FieldStrategy.IGNORED, insertStrategy = FieldStrategy.IGNORED, updateStrategy = FieldStrategy.IGNORED)
    private LocalDate recentLeaveTime;

    /**
     * 建立日期
     */
    private LocalDateTime createTime;

    /**
     * 更新日期
     */
    private LocalDateTime updateTime;

}
