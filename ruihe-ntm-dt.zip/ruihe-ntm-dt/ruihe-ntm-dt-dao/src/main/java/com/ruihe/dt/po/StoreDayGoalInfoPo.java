package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author huangjie
 * @description
 * @date 2021年06月18日14:56:52
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_store_day_goal_info")
public class StoreDayGoalInfoPo implements Serializable {

    /**
     * 当前日期
     */
    private String curDate;

    /**
     * 记账日期
     */
    private String postingDate;

    /**
     * 财务月
     */
    private String financialMonth;

    /**
     *柜台编号
     */
    private String counterId;

    /**
     * 柜台名称
     */
    private String counterName;

    /**
     * 门店日目标金额
     */
    private String dailyTargetAmt;

    /**
     * 门店日实际金额
     */
    private String actualDailyAmt;

}
