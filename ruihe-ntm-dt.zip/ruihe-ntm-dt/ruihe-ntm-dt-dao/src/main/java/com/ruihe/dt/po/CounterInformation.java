package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_counter_info")
public class CounterInformation implements Serializable {

    @TableId(value = "counter_id", type = IdType.NONE)
    public String counterId;

    //测试区分 正式柜台/测试柜台-------------添加必填
    public Integer counterType;

    //品牌名称-------------添加必填
    public String brandName;

    //柜台名称-------------添加必填
    public String counterName;

    //大区code-------------添加必填
    public String largeAreaCode;

    //大区名称-------------添加必填
    public String largeAreaName;

    //省份code-------------添加必填
    public String provinceCode;

    //省份名称-------------添加必填
    public String provinceName;

    //城市code-------------添加必填
    public String cityCode;

    //城市名称-------------添加必填
    public String cityName;

    //县级code-------------添加必填
    public String countyCode;

    //县级名称-------------添加必填
    public String countyName;

    //柜台邮政编码
    public String counterPostalCode;

    //柜台简称
    public String counterAbbrev;

    //柜台地址
    public String counterAddress;

    //运营模式   自营/代理商
    public String operationalModel;

    //所属渠道code-------------添加必填
    public String channelCode;

    //所属渠道名称-------------添加必填
    public String channelName;

    //是否有pos机 是/否-------------添加必填
    public Integer isPosExit;

    //柜台协同区分 协同/不协同-------------添加必填
    public Integer counterCooperative;

    //柜台电话
    public String counterPhone;

    //组织模式：大区代码
    public String orgAreaId;

    //组织模式：大区名称
    public String orgAreaName;

    //组织模式：办事处代码
    public String orgOfficeId;

    //组织模式：办事处名称
    public String orgOfficeName;

    //组织模式-柜台主管
    public String orgMasterId;

    //组织模式-柜台主管名称
    public String orgMasterName;

    //柜台主管用户ID-------------添加必填
    public String principalEmpId;

    //value = "柜台主管用户状态-------------无需添加，默认为1（有效），后台返回0的时候，隐藏柜台主管
    public Integer principalEmpStatus;

    //value = "柜台主管姓名-------------添加必填
    public String principalEmpName;

    //value = "柜台主管岗位代码-------------添加必填
    public String principalEmpPositionCode;

    //value = "柜台主管岗位名-------------添加必填称
    public String principalEmpPositionName;

    //value = "柜台主管-所属部门代码-------------添加必填称
    public String principalEmpDeptCode;

    //value = "柜台主管-所属部门名称-------------添加必填称
    public String principalEmpDeptName;

    //是否删除 0默认 正常,1删除
    public Integer isDel;

    //寄存箱功是否启用,0空/启用,2停用
    public Integer depositBoxStatus;

    //value = "SN号，柜台设备编号-------------添加非必填
    public String sn;

    //创建时间
    public LocalDateTime createTime;

    //停业时间
    public LocalDateTime stopTime;

    //停业重开日期
    public LocalDateTime reopenTime;

    //修改时间
    public LocalDateTime updateTime;
}
