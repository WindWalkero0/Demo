package com.ruihe.dt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.InvitationJobPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * AI邀约任务主表
 *
 * @author fly
 */
@Mapper
public interface InvitationJobMapper extends BaseMapper<InvitationJobPo> {

}
