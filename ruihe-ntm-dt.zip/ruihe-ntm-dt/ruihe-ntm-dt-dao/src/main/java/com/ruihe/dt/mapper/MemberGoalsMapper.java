package com.ruihe.dt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.MemberGoalPo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MemberGoalsMapper extends BaseMapper<MemberGoalPo> {

    /**
     * 批量插入会员目标
     *
     * @param memberGoalsPoList
     * @return
     */
    int batchInsert(List<?> memberGoalsPoList);
}
