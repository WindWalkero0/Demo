package com.ruihe.dt.po;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 邀约的配置项
 *
 * @author Administrator
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvitationConfig implements Serializable {

    /**
     * 周期 多久天可以打一次电话
     */
    private Integer period;

    /**
     * 可以预约多久后的时间
     */
    private Integer days;

    /**
     * 一天最多多少邀约任务
     */
    private Integer jobMax;

    /**
     * 一个邀约任务最多多少个人
     */
    private Integer taskMax;

    /**
     * 一天最多能多少个邀约成功的人
     */
    private Integer invitationMax;

}
