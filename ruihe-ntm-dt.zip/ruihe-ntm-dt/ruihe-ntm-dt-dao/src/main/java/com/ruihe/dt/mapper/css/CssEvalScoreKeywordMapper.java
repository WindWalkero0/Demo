package com.ruihe.dt.mapper.css;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.css.CssEvalScoreKeywordPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


/**
 * AI回访关键词
 *
 * @author fly
 */
@Mapper
public interface CssEvalScoreKeywordMapper extends BaseMapper<CssEvalScoreKeywordPo> {

    /**
     * 批量导入
     *
     * @param list
     * @return
     */
    int batchInsert(@Param("list") List<CssEvalScoreKeywordPo> list);
}
