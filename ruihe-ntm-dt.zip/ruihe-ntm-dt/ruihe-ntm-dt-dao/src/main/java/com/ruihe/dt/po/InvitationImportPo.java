package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author fly
 * @description
 * @date 2020年10月28日10:30:52
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_invitation_import")
public class InvitationImportPo implements Serializable {

    /**
     * 计划编号
     */
    @TableId("plan_no")
    private String planNo;

    /**
     * 计划名称
     */
    private String planName;

    /**
     * 操作人id
     */
    private String optId;

    /**
     * 操作人名称
     */
    private String optName;

    /**
     * 过期时间
     */
    private LocalDateTime startTime;

    /**
     * 过期时间
     */
    private LocalDateTime endTime;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 激活时间
     */
    private LocalDateTime updateTime;
}
