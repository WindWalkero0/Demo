package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
/**
 * @author huangjie
 * @description
 * @date 2021年06月19日14:56:52
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_month_target_of_care_pack")
public class MonthTargetOfCarePackPo implements Serializable {

    /**
     * 当前日期
     */
    private String curDate;

    /**
     * 财务月
     */
    private String financialMonth;

    /**
     * 柜台编号
     */
    private String counterId;

    /**
     * 柜台名称
     */
    private String counterName;

    /**
     * 护理会员数量目标
     */
    private String numberOfNursingMembersGoal;

    /**
     * 会员护理频次目标
     */
    private String memberCareFrequencyGoal;

    /**
     * 护理服务次数目标
     */
    private String numberOfNursingServiceGoal;

    /**
     * 美导护理服务次数/月/人
     */
    private String numberOfBaServicesGoal;

    /**
     * 会员服务满意度目标
     */
    private String memberServiceSatisfactionGoal;

    /**
     * 护理会员数量完成情况
     */
    private String numberOfNursingMembersFulfil;

    /**
     * 会员护理频次完成情况
     */
    private String memberCareFrequencyFulfil;

    /**
     * 护理服务次数完成情况
     */
    private String numberOfNursingServiceFulfil;

    /**
     * 美导护理服务次数/月/人完成情况
     */
    private String numberOfBaServicesFulfil;

    /**
     * 会员服务满意度完成情况
     */
    private String memberServiceSatisfactionFulfil;

    /**
     * 护理服务次数完成同步率
     */
    private String numberOfNursingServiceSync;

}
