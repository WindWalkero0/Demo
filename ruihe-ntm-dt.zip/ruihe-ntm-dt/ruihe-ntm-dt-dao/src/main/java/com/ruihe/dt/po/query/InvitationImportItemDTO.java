package com.ruihe.dt.po.query;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author luojie
 * @program ruihe-top
 * @description 邀约导入明细查询实体
 * @create: 2021/6/25 9:44
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvitationImportItemDTO {
    @ApiModelProperty("计划编号")
    private String planNo;
    
    @ApiModelProperty("手机号")
    private String memberPhone;
    
    @ApiModelProperty("标签")
    private String tag;
}
