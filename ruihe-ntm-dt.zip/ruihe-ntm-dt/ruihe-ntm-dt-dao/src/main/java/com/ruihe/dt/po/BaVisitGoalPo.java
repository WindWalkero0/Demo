package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author huangjie
 * @description
 * @date 2021年07月15日14:56:52
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_ba_visit_goal")
public class BaVisitGoalPo implements Serializable {

    /**
     * 当前日期
     */
    private String curDate;

    /**
     * 财务月
     */
    private String financialMonth;

    /**
     * 柜台编号
     */
    private String counterId;

    /**
     * 柜台名称
     */
    private String counterName;

    /**
     *体验券发放量目标
     */
    private String voucherNumGoal;

    /**
     *体验券发放量完成情况
     */
    private String voucherNumCompletion;

    /**
     *体验券发放量同步率
     */
    private String voucherNumSync;

    /**
     *修眉量目标
     */
    private String eyeTrimNumGoal;

    /**
     *修眉量完成情况
     */
    private String eyeTrimNumCompletion;

    /**
     *修眉量同步率
     */
    private String eyeTrimNumSync;

    /**
     *体验人数目标
     */
    private String experienceNumGoal;

    /**
     *体验人数完成情况
     */
    private String experienceNumCompletion;

    /**
     *体验人数同步率
     */
    private String experienceNumSync;

    /**
     *口碑人数目标
     */
    private String opinionsNumGoal;

    /**
     *口碑人数完成情况
     */
    private String opinionsNumCompletion;

    /**
     *口碑人数同步率
     */
    private String opinionsNumSync;


}
