package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author fly
 * @description
 * @date 2020年10月28日10:30:52
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_invitation_import_item")
public class InvitationImportItemPo implements Serializable {

    /**
     * 自增id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 计划编号
     */
    private String planNo;

    /**
     * 柜台名称
     */
    private String counterId;

    /**
     * 柜台名称
     */
    private String counterName;

    /**
     * 大区
     */
    private String orgAreaName;

    /**
     * 大区
     */
    private String baName;

    /**
     * 大区
     */
    private String baCode;

    /**
     * 手机号
     */
    private String memberPhone;

    /**
     * 名称
     */
    private String memberName;

    /**
     * 名称
     */
    private String memberSex;

    /**
     * 生日
     */
    private LocalDate birthday;

    /**
     * 注册时间
     */
    private LocalDateTime cardIssueTime;

    /**
     * 等级
     */
    private String memberLevelName;

    /**
     * 积分
     */
    private Integer integralQty;

    /**
     * 最后一次购买时间
     */
    private LocalDateTime lastestTrxTime;

    /**
     * 等级变化时间
     */
    private LocalDateTime levelChangeTime;

    /**
     * 标签
     */
    private String tag;

    /**
     * 添加的信息
     */
    private String addInformation;

    /**
     * 导入状态
     */
    private Boolean status;

    /**
     * 导入描述
     */
    private String remark;

}
