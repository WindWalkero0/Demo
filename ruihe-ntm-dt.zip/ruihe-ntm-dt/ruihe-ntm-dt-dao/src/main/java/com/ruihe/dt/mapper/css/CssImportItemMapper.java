package com.ruihe.dt.mapper.css;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.css.CssImportItemPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会员回访导入子表
 *
 * @author fly
 */
@Mapper
public interface CssImportItemMapper extends BaseMapper<CssImportItemPo> {


    /**
     * 批量导入
     *
     * @param list
     * @return
     */
    int batchInsert(@Param("list") List<CssImportItemPo> list);
}
