package com.ruihe.dt.po.css;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author fly
 * @description
 * @date 2020年10月28日10:30:52
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_css_eval_keyword")
public class CssEvalScoreKeywordPo implements Serializable {

    /**
     * 计划编号
     */
    @TableId(value = "task_id", type = IdType.AUTO)
    private Long taskId;

    /**
     * 评价标签
     */
    private String evalTag;

    /**
     * 标签下的关键词
     */
    private String word;

    /**
     * 标签下的关键词
     */
    private String text;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;
}
