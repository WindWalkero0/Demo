package com.ruihe.dt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.InvitationImportPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * AI邀约会员导入主表
 *
 * @author fly
 */
@Mapper
public interface InvitationImportMapper extends BaseMapper<InvitationImportPo> {

}
