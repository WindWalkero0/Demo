package com.ruihe.dt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.StoreMonthlyGoalInfoPo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface StoreMonthlyGoalInfoMapper extends BaseMapper<StoreMonthlyGoalInfoPo> {

    /**
     * 批量插入门店月度规划
     *
     * @param storeMonthlyGoalInfoPos
     * @return
     */
    int batchInsert(List<?> storeMonthlyGoalInfoPos);
}
