package com.ruihe.dt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.InvUnConfirmQtyPo;
import com.ruihe.dt.po.InvitationJobPo;
import com.ruihe.dt.po.InvitationTaskPo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * AI邀约任务子表
 *
 * @author fly
 */
@Mapper
public interface InvitationTaskMapper extends BaseMapper<InvitationTaskPo> {

    /**
     * 批量插入
     *
     * @param invitationTaskPos
     * @return
     */
    int batchInsert(List<InvitationTaskPo> invitationTaskPos);


    /**
     * 查询用户最近一次打电话的记录
     *
     * @param ids
     * @return
     */
    List<InvitationTaskPo> selectLastMemberTask(List<String> ids);

    /**
     * 查询用户最近一次的到店签到记录
     *
     * @param ids
     * @return
     */
    List<InvitationTaskPo> selectLastMemberTaskSign(List<String> ids);

    /**
     * 查询子项为解决
     *
     * @param jobs
     * @return
     */
    List<InvUnConfirmQtyPo> getUnConfirmQty(List<Long> jobs);

    /**
     * 查询总的
     *
     * @param counterId
     * @param baCode
     * @return
     */
    Integer getUnConfirmSum(String counterId, String baCode);

    /**
     * 查询已完成的数量 lock
     *
     * @param planId
     * @return
     */
    Integer getCommitCotLockJob(Long planId);


    /**
     * 查询未跟进确认数量
     *
     * @param counterId
     * @param baCode
     * @return
     */
    Integer getUnFollowQty(String counterId, String baCode,String planNo);


    /**
     * 查询未跟进确认列表
     *
     * @param counterId
     * @param baCode
     * @return
     */
    List<InvitationTaskPo> getUnFollowList(String counterId, String baCode,String planNo);

    /**
     * 查询未跟进确认列表
     *
     * @param jobId
     * @return
     */
    InvitationJobPo getJobByIdWithLock(Long jobId);
}
