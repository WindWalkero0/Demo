package com.ruihe.dt.mapper;


import com.ruihe.dt.po.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 查询另一个库的数据
 *
 * @author fly
 */
@Mapper
public interface QueryHgsMapper {

    /**
     * 查询柜台
     *
     * @return
     */
    List<CounterInformation> selectCounter();

    /**
     * 查询柜台
     *
     * @return
     */
    List<CounterInformation> selectAllCounter();
    /**
     * 查询等级
     *
     * @return
     */
    List<MemberLevel> selectLevel();

    /**
     * 获取ba手机号
     *
     * @param baCode
     * @return
     */
    String getBaPhone(@Param("baCode") String baCode);

    /**
     * 获取用户
     *
     * @param account
     * @return
     */
    UserAccount getUserAccount(@Param("account") String account);

    /**
     * 获取用户
     *
     * @param account
     * @return
     */
    UserInformation getUserInformation(@Param("account") String account);
}
