package com.ruihe.dt.po;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 会员邀约记录响应,任务子项为处理数量
 *
 * @author fly
 * @Date:2020年11月6日10:48:45
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CssUnTaskQtyPo implements Serializable {
    /**
     * 任务ID
     */
    private String planNo;

    /**
     * 数量
     */
    private Integer qty;

}
