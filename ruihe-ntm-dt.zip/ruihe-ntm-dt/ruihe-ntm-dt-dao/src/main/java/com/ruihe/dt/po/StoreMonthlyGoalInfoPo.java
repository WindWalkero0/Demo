package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author huangjie
 * @description
 * @date 2021年06月19日14:56:52
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_store_monthly_goal_info")
public class StoreMonthlyGoalInfoPo implements Serializable {

    /**
     * 当前日期
     */
    private String curDate;

    /**
     * 财务月
     */
    private String financialMonth;

    /**
     * 柜台编号
     */
    private String counterId;

    /**
     * 柜台名称
     */
    private String counterName;

    /**
     * 门店目标
     */
    private String storeGoal;

    /**
     * 周末及活动目标
     */
    private String weekendGoal;

    /**
     * 会员日目标
     */
    private String membersDayGoal;

    /**
     * 平日目标
     */
    private String weekdayGoal;

    /**
     * 门店业绩逻辑目标
     */
    private String storeLogicGoal;

    /**
     * 门店平日业绩逻辑目标
     */
    private String dailyLogicGoal;

    /**
     * 门店周末业绩逻辑目标
     */
    private String weekendLogicGoal;

    /**
     * 门店会员日业绩逻辑目标
     */
    private String membersDayLogicGoal;

    /**
     * 门店完成业绩
     */
    private String storeAchievement;

    /**
     * 门店周末完成业绩
     */
    private String weekendAchievement;
    /**
     * 门店会员日完成业绩
     */
    private String membersDayAchievement;


    /**
     * 门店平日完成业绩
     */
    private String weekdayAchievement;

    /**
     * 门店业绩同步率
     */
    private String storeSyncRate;

    /**
     * 周末及活动业绩同步率
     */
    private String weekendSyncRate;

    /**
     * 会员日业绩同步率
     */
    private String membersDaySyncRate;

    /**
     * 平日业绩同步率
     */
    private String weekdaySyncRate;

    /**
     * 总天数
     */
    private String totalDays;

    /**
     * 周末天数
     */
    private String weekendDays;

    /**
     * 会员日天数
     */
    private String memberDays;

    /**
     * 平日天数
     */
    private String weekdays;

    /**
     * 门店日均业绩
     */
    private String storeDailyAverage;

    /**
     * 周末日均业绩
     */
    private String weekendDailyAverage;

    /**
     * 会员日日均业绩
     */
    private String memberDaysDailyAverage;

    /**
     * 平日日均业绩
     */
    private String weekdayDailyAverage;

}
