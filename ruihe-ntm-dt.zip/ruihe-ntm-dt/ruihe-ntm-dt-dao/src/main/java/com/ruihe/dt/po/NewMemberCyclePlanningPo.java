package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.ruihe.common.annotation.FieldName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author huangjie
 * @description
 * @date 2021年04月11日21:30:52
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_new_member_cycle_planning")
public class NewMemberCyclePlanningPo implements Serializable {
    /**
     * 当前日期
     */
    @FieldName(name = "当前日期")
    private String curDate;

    /**
     * 发卡柜台编号
     */
    private String counterId;

    /**
     * 发卡柜台名称
     */
    private String counterName;

    /**
     * 发卡BA
     */
    private String baCode;

    /**
     * 发卡BA姓名
     */
    private String baName;

    /**
     * 会员标识
     */
    private String memberId;

    /**
     * 当前周期，汉字
     */
    private String currentCycle;

    /**
     * 会员名称
     */
    private String memberName;

    /**
     * 会员手机号
     */
    private String memberPhone;

    /**
     * 入会日期
     */
    private String signupDate;

    /**
     * 入会等级
     */
    private String signupMemberLevel;

    /**
     * 当前等级
     */
    private String currentMemberLevel;

    /**
     * 首单金额
     */
    private BigDecimal firstOrderAmt;

    /**
     * 7天底线护理，次数
     */
    private String nursingLimitOf7days;

    /**
     * 7天基础护理，次数
     */
    private String nursingBasicOf7days;

    /**
     * 7天已护理，次数
     */
    private String qtyOf7daysNursed;

    /**
     * 7天底线销售，次数
     */
    private String saleLimitOf7days;

    /**
     * 7天基础销售，次数
     */
    private String saleBasicOf7days;

    /**
     * 7天已销售，次数
     */
    private String qtyOf7daysSale;

    /**
     * 7天完成状态
     */
    private String statusOf7days;

    /**
     * 21天底线护理，次数
     */
    private String nursingLimitOf21days;

    /**
     * 21天基础护理，次数
     */
    private String nursingBasicOf21days;

    /**
     * 21天已护理，次数
     */
    private String qtyOf21daysNursed;

    /**
     * 21天底线销售，次数
     */
    private String saleLimitOf21days;

    /**
     * 21天基础销售，次数
     */
    private String saleBasicOf21days;

    /**
     * 21天已销售，次数
     */
    private String qtyOf21daysSale;

    /**
     * 21天完成状态
     */
    private String statusOf21days;

    /**
     * 60天底线护理，次数
     */
    private String nursingLimitOf60days;

    /**
     * 60天基础护理，次数
     */
    private String nursingBasicOf60days;

    /**
     * 60天已护理，次数
     */
    private String qtyOf60daysNursed;

    /**
     * 60天底线销售，次数
     */
    private String saleLimitOf60days;

    /**
     * 60天基础销售，次数
     */
    private String saleBasicOf60days;

    /**
     * 60天已销售，次数
     */
    private String qtyOf60daysSale;

    /**
     * 60天完成状态
     */
    private String statusOf60days;

    /**
     * 90天底线护理，次数
     */
    private String nursingLimitOf90days;

    /**
     * 90天基础护理，次数
     */
    private String nursingBasicOf90days;

    /**
     * 90天已护理，次数
     */
    private String qtyOf90daysNursed;

    /**
     * 90天底线销售，次数
     */
    private String saleLimitOf90days;

    /**
     * 90天基础销售，次数
     */
    private String saleBasicOf90days;

    /**
     * 90天已销售，次数
     */
    private String qtyOf90daysSale;

    /**
     * 90天完成状态
     */
    private String statusOf90days;

    /**
     * 90天销售目标，金额
     */
    private String salesTargetOf90days;

    /**
     * 90天销售金额，金额
     */
    private String salesAmtOf90days;

    /**
     * 90天目标剩余金额
     */
    private String remainingAmtOf90days;

    /**
     * 周期截至日
     */
    private String deadline;

    /**
     * 本周期剩余天数
     */
    private String remainingDays;

}
