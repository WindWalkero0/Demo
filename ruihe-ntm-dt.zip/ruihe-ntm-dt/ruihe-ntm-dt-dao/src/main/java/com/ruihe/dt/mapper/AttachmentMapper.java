package com.ruihe.dt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.AttachmentPo;
import com.ruihe.dt.po.InvUnConfirmQtyPo;
import com.ruihe.dt.po.InvitationTaskPo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * AI邀约任务子表
 *
 * @author fly
 */
@Mapper
public interface AttachmentMapper extends BaseMapper<AttachmentPo> {

}
