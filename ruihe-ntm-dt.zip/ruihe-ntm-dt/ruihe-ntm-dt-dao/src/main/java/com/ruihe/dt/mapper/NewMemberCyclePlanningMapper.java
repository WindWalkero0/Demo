package com.ruihe.dt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.NewMemberCyclePlanningPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface NewMemberCyclePlanningMapper extends BaseMapper<NewMemberCyclePlanningPo> {

    /**
     * 批量插入新会员数据
     *
     * @param newMemberCyclePlanningPos
     * @return
     */
    int batchInsert(List<?> newMemberCyclePlanningPos);
}
