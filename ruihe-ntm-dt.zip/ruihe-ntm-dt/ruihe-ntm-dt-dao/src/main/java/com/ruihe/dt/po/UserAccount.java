package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author 梁远
 * @Description 用于存储用户的账号和密码，在将用户设置成无效的时候，需要将此表中的用户同步设置为无效
 * @create 2019-06-13 16:49
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_user_account")
public class UserAccount implements Serializable {

    //人员唯一键，用于判断重复和更新
    private String userId;

    //登录帐号
    private String account;

    //登录密码
    private String password;

    //状态
    private Integer status;

    /**
     * 创建用户id
     */
    private String createId;

    /**
     * 修改用户id
     */
    private String updateId;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 修改时间
     */
    private LocalDateTime updateTime;

}
