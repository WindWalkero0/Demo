package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author 梁远
 * @Description 会员等级维护
 * @create 2019-06-26 10:59
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_member_level")
public class MemberLevel implements Serializable {
    //会员等级编码，唯一键
    @TableId(value = "level_code", type = IdType.AUTO)
    private String levelCode;

    //会员等级名称
    private String levelName;

    //品牌
    private String brandName;

    //是否是默认等级
    private Integer isDefaultLevel;

    //会员等级级别
    private Integer level;

    //有效期
    private Integer duration;

    //会员等级描述
    private String description;

    //状态
    private Integer status;

    //建立日期
    private LocalDateTime createTime;

    //更新日期
    private LocalDateTime updateTime;
}
