package com.ruihe.dt.po.css;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author fly
 * @description
 * @date 2020年10月28日10:30:52
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_css_eval_score")
public class CssEvalScorePo implements Serializable {

    /**
     * 计划编号
     */
    @TableId(value = "task_id", type = IdType.AUTO)
    private Long taskId;

    /**
     * 任务编码
     */
    private Long planNo;

    /**
     * 评价标签
     */
    private String evalTag;

    /**
     * 得分
     */
    private Integer score;

    /**
     * 回复文本
     */
    private String statement;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;
}
