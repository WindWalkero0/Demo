package com.ruihe.dt.po.css;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author fly
 * @description
 * @date 2020年10月28日10:30:52
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_css_task")
public class CssTaskPo implements Serializable {

    /**
     * 自增id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 计划编号
     */
    private String planNo;

    /**
     * 柜台编码
     */
    private String counterId;

    /**
     * 柜台名称
     */
    private String counterName;

    /**
     * 柜台编码
     */
    private String baCode;

    /**
     * 柜台名称
     */
    private String baName;

    /**
     * 大区
     */
    private String orgAreaCode;

    /**
     * 大区
     */
    private String orgAreaName;

    /**
     * 办事处
     */
    private String orgOfficeCode;

    /**
     * 办事处
     */
    private String orgOfficeName;

    /**
     * 主管
     */
    private String orgPrincipalCode;

    /**
     * 主管
     */
    private String orgPrincipalName;

    /**
     * 手机号
     */
    private String memberPhone;

    /**
     * 名称
     */
    private String memberName;

    /**
     * 名称
     */
    private String memberSex;

    /**
     * 生日
     */
    private LocalDate birthday;

    /**
     * 注册时间
     */
    private LocalDateTime cardIssueTime;

    /**
     * 等级
     */
    private String memberLevelCode;

    /**
     * 等级
     */
    private String memberLevelName;

    /**
     * 积分
     */
    private Integer integralQty;

    /**
     * 最后一次购买时间
     */
    private LocalDateTime lastestTrxTime;

    /**
     * 等级变化时间
     */
    private LocalDateTime levelChangeTime;

    /**
     * 标签
     */
    private String tag;

    /**
     * 标签
     */
    private String aiType;


    /**
     * 状态  0未选中  1已选中
     */
    private Integer status;

    /**
     * 状态  0未选中  1已选中
     */
    private Integer cssStatus;

    /**
     * 录音url
     */
    private String audioUrl;

    /**
     * 分配拨打时间
     */
    private LocalDate planCallTime;

    /**
     * 分配拨打时间
     */
    private LocalDateTime callTime;

    /**
     * 领取时间
     */
    private LocalDateTime createTime;

    /**
     * 激活时间
     */
    private LocalDateTime updateTime;
}
