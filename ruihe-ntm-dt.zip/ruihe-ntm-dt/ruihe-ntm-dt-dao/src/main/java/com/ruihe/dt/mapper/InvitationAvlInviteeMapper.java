package com.ruihe.dt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * AI邀约可选人
 *
 * @author fly
 */
@Mapper
public interface InvitationAvlInviteeMapper extends BaseMapper<InvitationAvlInviteePo> {

    /**
     * 批量导入
     *
     * @param list
     * @return
     */
    int batchInsert(@Param("list") List<InvitationAvlInviteePo> list);


    /**
     * 根据id批量更新
     *
     * @param ids
     * @param status
     * @return
     */
    int updateByIds(@Param("ids") List<Long> ids, @Param("status") Integer status, @Param("oldStatus") Integer oldStatus);

}
