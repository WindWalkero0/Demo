package com.ruihe.dt.mapper.css;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.InvitationImportPo;
import com.ruihe.dt.po.css.CssImportPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * AI回访会员导入主表
 *
 * @author fly
 */
@Mapper
public interface CssImportMapper extends BaseMapper<CssImportPo> {

}
