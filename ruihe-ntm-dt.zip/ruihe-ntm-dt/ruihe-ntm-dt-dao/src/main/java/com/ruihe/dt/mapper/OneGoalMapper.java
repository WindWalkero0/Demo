package com.ruihe.dt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.BaVisitGoalPo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface OneGoalMapper extends BaseMapper<BaVisitGoalPo> {
    /**
     * 批量插入1.0目标
     *
     * @param oneGoalPoList
     * @return
     */
    int batchInsert(List<?> oneGoalPoList);
}
