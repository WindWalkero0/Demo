package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author fly
 * @description
 * @date 2020年10月28日10:30:52
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_invitation_task")
public class InvitationTaskPo implements Serializable {

    /**
     * 计划编号
     */
    @TableId(value = "task_id", type = IdType.AUTO)
    private Long taskId;

    /**
     * 计划名称
     */
    private Long jobId;

    /**
     * 操作人id
     */
    private String planNo;

    /**
     * 邀约人id
     */
    private Long avlId;

    /**
     * 操作人名称
     */
    private String baCode;

    /**
     * 过期时间
     */
    private String baName;

    /**
     * 柜台编码
     */
    private String counterId;

    /**
     * 柜台名称
     */
    private String counterName;

    /**
     * 会员名称
     */
    private String memberName;

    /**
     * 会员手机号
     */
    private String memberPhone;

    /**
     * 会员手机号
     */
    private String memberLevel;

    /**
     * 性别
     */
    private String memberSex;

    /**
     * 生日
     */
    private LocalDate memberBirthday;

    /**
     * 新增消息
     */
    private String addInformation;

    /**
     * 标签
     */
    private String tag;

    /**
     * 状态 0未开始 1接受 2拒绝 3待确认 4终止
     */
    private Integer status;

    /**
     * 邀约结果描述
     */
    private String invResult;

    /**
     * 期望到店时间
     */
    private LocalDate expectArrTime;

    /**
     * 会员签到时间
     */
    private LocalDateTime signinTime;

    /**
     * 到店状态 0为处理 1未到店 2已签到
     */
    private Integer arrStatus;

    /**
     * 领取时间
     */
    private LocalDateTime createTime;

    /**
     * 激活时间
     */
    private LocalDateTime updateTime;

    /**
     * 激活时间
     */
    private Boolean isRead;

    /**
     * 7天之后可以重复选择 0没有执行过 false  , 1 执行过 true
     */
    private Boolean recheck;
}
