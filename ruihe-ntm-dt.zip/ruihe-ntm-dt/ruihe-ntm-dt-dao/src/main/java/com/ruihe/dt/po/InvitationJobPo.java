package com.ruihe.dt.po;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author fly
 * @description
 * @date 2020年10月28日10:30:52
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_invitation_job")
public class InvitationJobPo implements Serializable {

    /**
     * 工作id
     */
    @TableId
    private Long jobId;

    /**
     * 计划编号
     */
    private String planNo;

    /**
     * 操作人id
     */
    private String baCode;

    /**
     * 操作人名称
     */
    private String baName;

    /**
     * 柜台id
     */
    private String counterId;

    /**
     * 柜台名称
     */
    private String counterName;

    /**
     * 期望到店时间
     */
    private LocalDate expectArrTime;

    /**
     * 邀约人数
     */
    private Integer invQty;

    /**
     * 接收人数
     */
    private Integer acceptQty;

    /**
     * 待确认人数
     */
    private Integer tbcQty;

    /**
     * 状态  0未开始 1进行中 2已完成 3已停止
     */
    private Integer status;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 任务完成数
     */
    private Integer commitCot;
}
