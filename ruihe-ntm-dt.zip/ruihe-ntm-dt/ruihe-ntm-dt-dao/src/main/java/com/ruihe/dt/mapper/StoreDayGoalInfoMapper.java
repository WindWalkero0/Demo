package com.ruihe.dt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.StoreDayGoalInfoPo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface StoreDayGoalInfoMapper extends BaseMapper<StoreDayGoalInfoPo> {

    /**
     * 批量插入门店单日目标
     *
     * @param storeDayGoalInfoPos
     * @return
     */
    int batchInsert(List<?> storeDayGoalInfoPos);
}
