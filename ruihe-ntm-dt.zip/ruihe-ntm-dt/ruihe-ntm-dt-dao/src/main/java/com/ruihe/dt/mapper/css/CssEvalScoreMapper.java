package com.ruihe.dt.mapper.css;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruihe.dt.po.css.CssEvalScorePo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


/**
 * AI回访标签
 *
 * @author fly
 */
@Mapper
public interface CssEvalScoreMapper extends BaseMapper<CssEvalScorePo> {

    /**
     * 批量导入
     *
     * @param list
     * @return
     */
    int batchInsert(@Param("list") List<CssEvalScorePo> list);
}
